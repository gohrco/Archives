<?php
/**
 * Group Management Model for J!WHMCS Integrator
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since		1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelSync
 * Extends:		JwhmcsModel
 * Purpose:		Used to synchronize the WHMCS user table with J!
 * 
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsModelCheck extends JwhmcsModel
{
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
		
	}
	
	
	function getData()
	{
		$params	= & JComponentHelper::getParams( 'com_jwhmcs' );
		$data = $this->checkInstall(&$params);
		
		$data['plugin-auth'] = $this->_checkPluginStatus('authentication');
		$data['plugin-sysm'] = $this->_checkPluginStatus('system');
		$data['plugin-user'] = $this->_checkPluginStatus('user');
		return $data;
	}
	
	
	function getPluginParams()
	{
		$db = & JFactory::getDBO();
		$params	= & JComponentHelper::getParams('com_jwhmcs');
		
		$query	= 'SELECT `params` FROM #__plugins WHERE `folder` IN ("authentication", "system", "user") and `element` LIKE "%jwhmcs%"';
		$db->setQuery($query);
		$paramset	= $db->loadAssocList();
		
		foreach ($paramset as $param)
		{
			unset($tmpp);
			$tmpp = new JParameter($param['params']);
			$params->merge($tmpp);
		}
		
		return $params;
	}
	
	
	function process()
	{
		$db		= & JFactory::getDBO();
		$params	= & JComponentHelper::getParams('com_jwhmcs');
		$jcurl	= & JwhmcsCurl::getInstance();
		
		if (!$params->get( 'licensekey' )) {
			$action = 'install';
		}
		else {
			$jcurl->setCall();
			$url = 'http://'.$params->get('jwhmcsurl').'/jwhmcs.php?task=checkinstall&joomadmin=1';
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
			$jcurl->setRoot('PARAM');
			$items = $jcurl->loadResult();
//			echo '<pre>'.print_r($items,1).'</pre>';
			$action = 'upgrade';
//			die();
		}
		
	}
	
	
	/* ----------------------------------------- *\
	 *              SUB FUNCTIONS                *
	\* ----------------------------------------- */
	
	
	private function _checkPluginStatus( $plugin = 'authentication' )
	{
		$db = & JFactory::getDBO();
		
		$query = 'SELECT `params` FROM #__plugins WHERE `folder` = "'.$plugin.'" AND `element` LIKE "%jwhmcs%"';
		$db->setQuery($query);
		$result	= $db->loadResult();
		
		if (!$result) return false;
		else return $result;
	}
	
	
}