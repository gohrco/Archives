<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');
JHTML::_('behavior.formvalidation');

$data = $this->data;
$j48install = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-48-settings.png';
$j32abort	= JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-abort.png';
$j32forward = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-forward.png';
?>
<script language="javascript">
function myValidate(f) {
	
	    if (document.formvalidator.isValid(f)) {
                return true; 
        }
        else {
                alert('Some values are not acceptable.  Please retry.');
        }
        return false;
}

function submitbutton(pressbutton) {
	var form = document.adminForm;
	var apiconnection = document.getElementById('apiconnection').value;

	if (pressbutton == 'abort') {
		submitform( pressbutton );
		return;
	}
	
	if (apiconnection == '0') {
		alert('Please enter the API Username and Password and ensure the connection is successful.');
		return;
	}
	else {
		if (myValidate(form) == true) {
			submitform( pressbutton );
		}
	}
}
</script>
<style type="text/css" >
input.invalid { color: #fff; background-color: #f00; }
.icon-48-install { background-image: url('<?php echo $j48install; ?>'); }
.icon-32-abort { background-image: url(<?php echo $j32abort; ?>); }
.icon-32-forward { background-image: url(<?php echo $j32forward; ?>); }
td.paramlabel { font-style: italic; color: #333; }
.paramname { font-size: medium; font-weight: bold; }
.paramdesc { font-size: xx-small; clear: both; }
</style>
<form action="index.php" method="post" name="adminForm">
<div id="adminInput">
	<table class="admintable" width="675px" border="0">
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				API Username
				</div>
				<div class="paramdesc">
				Enter the API Username for WHMCS (configured in WHMCS).
				</div>
			</td>
			<td rowspan="8" width="220px" valign="top">
				<div id="apistatus">
				&nbsp;
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="text" name="jwhmcsadminus" value="<?php echo $data->jwhmcsadminus; ?>" size="40" style="font-size: 14px; " id="jwhmcsadminus" onChange="ajaxCheckAPI();" />
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				API Password
				</div>
				<div class="paramdesc">
				Enter the API Password for WHMCS (configured in WHMCS).
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="password" name="jwhmcsadminpw" value="<?php echo $data->jwhmcsadminpw; ?>" size="40" style="font-size: 14px; " id="jwhmcsadminpw" onChange="ajaxCheckAPI();" />
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				API Access Key (optional)
				</div>
				<div class="paramdesc">
				If you have installed iWHMCS or another module from WHMCS that requires use of an API Access Key, please enter it below.  Your access key would have been configured in the WHMCS configuration.php file.
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area" type="text" name="accesskey" value="<?php echo $data->accesskey; ?>" size="40" style="font-size: 14px; " id="accesskey" onChange="ajaxCheckAPI();" />
			</td>
		</tr>
	</table>
</div>
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="apiconnection" id="apiconnection" value="0" />
<input type="hidden" name="task" value="stepfive" />
<input type="hidden" name="controller" value="install" />
</form>
<script language="javascript">
window.onload = ajaxCheckAPI();
</script>