<?php defined('_JEXEC') or die('Restricted access');
jimport('joomla.html.pane');
JHTML::_('behavior.mootools');
JHTML::_('behavior.tooltip');

$lang	= &JFactory::getLanguage();

$tmp	= explode('-', $this->data->get( 'licensekey' ));
$lictype	= $tmp[0];

$j48jwhmcs = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-48-jwhmcs.png';
$j32license = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-license.png';
$j32apiconxn = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-apiconxn.png';
?>
<style type="text/css">
.icon-48-jwhmcs { background-image: url(<?php echo $j48jwhmcs; ?>); }
.icon-32-license { background-image: url(<?php echo $j32license; ?>); }
.icon-32-apiconxn { background-image: url(<?php echo $j32apiconxn; ?>); }
span.hasTip {
	text-align: right !important;
	font-weight: bold !important;
}
</style>

<div id="cpanel" style="width: 98%; clear: both; ">
	<div style="width: 400px; float: left; ">
		<?php
		  foreach ($this->icondefs as $icon):
		  	$imglnk	= JRoute::_('index.php?option='.JRequest::getCmd('option','com_jwhmcs') . (is_null($icon['controller']) ? '' : '&amp;controller='.$icon['controller']) . (is_null($icon['task']) ? '' : '&amp;task='.$icon['task']) . ( is_null($icon['view']) ? '' : '&amp;view='.$icon['view'] ));
		  	$imgsrc = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/'.$icon['icon'];
		?>
		<div style="float: left; ">
			<div class="icon">
				<a <?php if ($this->lic['valid']) : ?>href="<?php echo $imglnk; ?>"<?php endif; ?>>
					<img
						src="<?php echo $imgsrc; ?>"
						border="0" alt="<?php echo $icon['label']; ?>" />
					<span><?php echo $icon['label']; ?></span>
				</a>
			</div>
		</div>
		<?php endforeach; ?>
	</div>
	<div id="jpmodules" style="width: 450px; float: right;">
		<h1 style="text-align: center; width: 100%; margin: 0px; padding: 0px; " class="title">J!WHMCS Integrator</h1>
		<h4 style="text-align: center; width: 100%; margin: 0px; padding: 0px; " class="title">version <?php echo $this->data->get( 'jwhmcsvers' ); ?></h4>
		
		<table width="400px" align="center" border="0" cellpadding="5" cellspacing="0" style="margin: 0px auto; ">
			<tr>
				<td align="right" valign="top">
					Licensed To:
				</td>
				<td align="left" valign="top" style="font-weight: bold; ">
					<?php echo $this->lic['registeredname']; ?>
					<?php echo ( isset($this->lic['companyname']) ? '<br />' . $this->lic['companyname'] : '' ); ?>
					<?php echo ( isset($this->lic['email']) ? '<br />' . $this->lic['email'] : '' ); ?>
				</td>
			</tr>
			<tr>
				<td align="right" valign="top">
					Registered On:
				</td>
				<td align="left" valign="top" style="font-weight: bold; ">
					<?php echo date("F j, Y", strtotime($this->lic['regdate'])); ?>
				</td>
			</tr>
			<tr>
				<td align="right" valign="top">
					License Details:
				</td>
				<td align="left" valign="top" style="font-weight: bold; ">
					<?php echo $this->data->get( 'licensekey' ); ?><br />
					<span style="text-align: left; color: <?php echo ($this->lic['valid'] ? '#008800' : '#FF0000'); ?>;"><?php echo $lictype; ?> License</span>
				</td>
			</tr>
			<tr>
				<td align="right" valign="top">
					Last Synchronized On:
				</td>
				<td align="left" valign="top" style="font-weight: bold; ">
					<?php echo ($this->data->get( 'lastsync' ) ? date("F j, Y h:i:s a", $this->data->get( 'lastsync' ) ) : 'Not yet synced' ); ?>
				</td>
			</tr>
		</table>
	</div>
</div>
<form action="index.php" method="post" name="adminForm">
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="controller" value="default" />
<input type="hidden" name="task" value="" />
</form>