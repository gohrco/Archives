<?php
/**
 * J!WHMCS Integrator - System Language Plugin
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2010 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: jwhmcs_sysm.php 99 2010-01-11 18:57:35Z Steven $
 * @since		2.0.2
 * 
 * @desc		This plugin handles adding the language=xx to external links
 * 				in the Joomla system that are tied to the component parameters.
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.plugin.plugin');

/**
 * System Language Plugin
 *
 * @package		J!WHMCS Integrator 
 * @since 		2.0.2
 */
class plgSystemJwhmcs_sysmlang extends JPlugin {

	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param object $subject The object to observe
	 * @param 	array  $config  An array that holds the plugin configuration
	 * @since 1.5
	 */
	function plgSystemJwhmcs_sysmlang(& $subject, $config)
	{
		parent::__construct($subject, $config);
	}
	
	
	function onAfterInitialise()
	{
		
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	onAfterRender (private)
	 * Purpose:		Handle adding language= to links
	 * As of:		version 2.0.2 (March 2010)
	\* ------------------------------------------------------------ */
	function onAfterRender()
	{
		
		return;
	}
	
	
	private function _multiLingualWHMCS()
	{
		$menu	= &JMenu::getInstance('site');
		$lang	=& JFactory::getLanguage();
		$buffer = JResponse::getBody();
		
		$component	= JComponentHelper::getComponent( 'com_jwhmcs' );
  		$params		= new JParameter( $component->params, JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jwhmcs'.DS.'config.xml' );
  		
		$paramset	= $params->renderToArray();
		
		foreach ($paramset as $k => $varray)
		{
			$tmp = substr($k, 0, 5);
			if ($tmp == 'jwlnk')
			{
				$tmp = substr($key, (5-strlen($key)));
				// Set each page to either the default link or the selected link
				if ($varray[4]) {
					$check[$k] = $varray[4];
				}
			}
		}
		
		echo '<pre>'.print_r($check,1).'</pre>'; die();
		
		if ( $defItem = $this->params->get( 'jwlnkdefault' ) ) {
			
			$lang->getTag();
			
			$defItm = $menu->getItem( $defItem );
			
			$regex     = sprintf('`(?P<link>%s)`',$defItm->link);
        	$buffer    = preg_replace($regex, "$1$addlang", $buffer);
			
        	JResponse::setBody($buffer);
		}
	}
}