<table width="100%" class="jwhmcslogin-clientareatable" cellspacing="1">
	<tr class="jwhmcslogin-clientareatableactive">
		<td style="padding:10px;">
			<strong><?php echo $jwhmcs->firstname.' '.$jwhmcs->lastname.(empty($jwhmcs->companyname) ? '' : '<br />'.$jwhmcs->companyname ); ?></strong><br />
			<?php echo $jwhmcs->address1.(empty($jwhmcs->address2) ? '' : '<br />'.$jwhmcs->address2 ); ?><br />
			<?php echo $jwhmcs->city.', '.$jwhmcs->state.', '.$jwhmcs->postcode; ?><br />
			<?php echo (isset( $jwhmcs->countryname ) ? $jwhmcs->countryname : (isset( $jwhmcs->country ) ? $jwhmcs->country : null ) ); ?><br />
			<?php echo $jwhmcs->email; ?><br /><br />
			<?php if (! $contact ): ?>
			<?php if ( $params->get( "displaycredit", "0" ) ):?>
			Current Credit: <?php echo $params->get( "displaycreditsymbol", "$" ); ?>&nbsp;<?php echo $jwhmcs->credit; ?><br />
			<?php endif; ?>
			<a href="<?php echo $jwhmcs->clienturl; ?>/clientarea.php?action=details"><img src="<?php echo $jwhmcs->clienturl; ?>/images/details.gif" border="0" hspace="5" align="absmiddle" alt="" /> <?php echo JText::_('UPDATE YOUR DETAILS'); ?></a><?php if ($params->get( 'addfunds' )): ?><a href="<?php echo $jwhmcs->clienturl; ?>/clientarea.php?action=addfunds"><img src="<?php echo $jwhmcs->clienturl; ?>/images/affiliates.gif" border="0" align="absmiddle" alt="" /> Add Funds</a><?php endif; ?>
			<?php endif; ?>
		</td>
	</tr>
</table>
<form action="<?php echo $jwhmcs->whmcsurl; ?>" method="post" name="login" id="form-login">
	<div align="center">
		<input type="submit" name="Submit" class="button" value="<?php echo JText::_( 'BUTTON_LOGOUT'); ?>" />
	</div>
	<input type="hidden" name="task" value="ulogout" />
</form>
