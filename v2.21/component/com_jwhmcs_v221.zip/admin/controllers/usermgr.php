<?php
/**
 * Default Controller for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: usermgr.php 131 2010-12-22 14:21:11Z steven_gohigher $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsControllerDefault
 * Extends:		JwhmcsController
 * Purpose:		Used as the default controller for user management
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsControllerUsermgr extends JwhmcsController
{
	/* ------------------------------------------------------------ *\
	 * Task:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();

		// Register Extra tasks
		$this->registerTask( 'whmcsadd',		'whmcsedit' );
		$this->registerTask( 'joomadd',			'joomedit' );
		$this->registerTask( 'joomaddsave', 	'joomeditsave' );
		$this->registerTask( 'whmcsaddsave',	'whmcseditsave' );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		joomedit
	 * Purpose:		Allows for adding of Joomla users.
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function joomedit()
	{
		JRequest::setVar( 'view', 'usermgr' );
		JRequest::setVar( 'layout', 'formjoomla' );
		JRequest::setVar( 'hidemainmenu', 1 );
		parent::display();
	}
	
	/* ------------------------------------------------------------ *\
	 * Task:		whmcsedit
	 * Purpose:		Allows for adding of WHMCS users.
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function whmcsedit()
	{
		JRequest::setVar( 'view', 'usermgr' );
		JRequest::setVar( 'layout', 'formwhmcs' );
		JRequest::setVar( 'hidemainmenu', 1 );
		parent::display();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		joomeditsave
	 * Purpose:		Handles saving of Joomla user info
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function joomeditsave()
	{
		$model		= $this->getModel( 'usermgr' );
		$form		= JRequest::get( 'method' );
		$task		= JRequest::get( 'task' );
		
		if ( $model->joomsave($form, $task) )
		{
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_USRJSY' );
		} else {
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_USRJSN' );
		}
		
		$link = 'index.php?option=com_jwhmcs&controller=usermgr';
		$this->setRedirect($link, $msg);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		whmcseditsave
	 * Purpose:		Handles saving of WHMCS user info
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function whmcseditsave()
	{
		$model		= $this->getModel( 'usermgr' );
		$post		= JRequest::get( 'post' );
		$task		= JRequest::get( 'task' );
		
		$result		= $model->whmcsaddsave($post, $task);
		if ($result['result'] != 'success')
		{
			$msg = JText::sprintf( 'JWHMCS_ADMIN_CONTR_USRWSN', $result['message'] );
		} else {
			$msg = JText::_( 'JWHMCS_ADMIN_CONTR_USRWSY' );
		}
		
		$link = 'index.php?option=com_jwhmcs';
		$this->setRedirect($link, $msg);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		changeUsername
	 * Purpose:		Set xref type so username is requested at login
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function changeUsername()
	{
		$model	= $this->getModel('usermgr');
		$post	= JRequest::get( 'method' );
		
		if ($model->changeUsername($post))
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_CUSY' );
		else
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_CUSN' );
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', $msg );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		changeAllusername
	 * Purpose:		Set xref type so username is requested at login for all
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function changeAllusername()
	{
		$model	= $this->getModel('usermgr');
		
		if ($model->changeAllusername())
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_CUSY' );
		else
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_CUSN' );
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', $msg );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		sync
	 * Purpose:		Syncronize users found by email (setting xref type=2)
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function sync()
	{
		$model	= $this->getModel('usermgr');
		$post	= JRequest::get( 'method' );
		
		if ($model->syncUser($post))
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_USRSY' );
		else
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_USRSN' );
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', $msg );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		syncBreak
	 * Purpose:		Break syncronization of user
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function syncBreak()
	{
		$model	= $this->getModel('usermgr');
		$post	= JRequest::get( 'method' );
		
		if ($model->syncBreak($post))
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_USRSBY' );
		else
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_USRSBN' );
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', $msg );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		matchAll
	 * Purpose:		Find all possible matches
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	function matchAll()
	{
		$model	= $this->getModel('usermgr');
		
		if ($model->matchAll())
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_USRSMY' );
		else
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_USRSMN' );
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', $msg );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		cancel
	 * Purpose:		Handle cancelation requests
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function cancel()
	{
		$msg = JText::_( 'JWHMCS_ADMIN_CONTR_MSGCNCL' );
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', $msg );
	}
}