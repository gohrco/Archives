<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: group.php 131 2010-12-22 14:21:11Z steven_gohigher $
 * @since      1.5.1
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class TableGroup extends JTable
{
	var $id			= null;
	var $fname		= null;
	var	$lname		= null;
	var $cname		= null;
	var $email		= null;
	var $password	= null;

	function TableGroup(& $db) {
		parent::__construct('#__jwhmcs_group', 'id', $db);
	}
}