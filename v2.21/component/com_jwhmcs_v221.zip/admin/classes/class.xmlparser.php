<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: class.xmlparser.php 131 2010-12-22 14:21:11Z steven_gohigher $
 * @since      1.5.3
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class JwhmcsXml
{
	 
	/**
	 * @var instance to contain object when created
	 */
	private static $instance = null;
	
    /* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Called upon initialization of object class
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	private function __construct()
	{
		$this->parseOn		= false;
		$this->parseCnt		= 0;
		$this->parseTag		= '';
		$this->parseRet		= array();
		$this->root			= 'whmcsapi';
		$this->parseData	= array();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getInstance
	 * Purpose:		Called to create an instance of the class
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public static function getInstance()
	{
		if (self::$instance == null)
		{
			self::$instance = new self;
		}
		return self::$instance;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setRoot
	 * Purpose:		This sets the root of the xml to search for.
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function setRoot($root)
	{
		$this->root = strtolower($root);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setData
	 * Purpose:		This function sets the data for usage
	 * As of:		version 1.5.3
	 * 
	 * Significant Revisions:
	 * 	2.0.2 (Mar 2010)
	 * 		+ Added convert characterset class for non-utf8 encoding
	\* ------------------------------------------------------------ */
	public function setData($data)
	{
		$params = & JwhmcsParams::getInstance();
		$wchars = trim($params->get( 'WhmcsCharacterset' ));
		if (( strtolower( $wchars ) != 'utf-8') && ($wchars != '' ) && ( $params->get( 'AdvConvertcharset' ) ) ) {
			require_once('ConvertCharset.class.php');
			$character = new ConvertCharset($wchars, "utf-8", true);
			$data = $character->convert($data);
		}
		
		$this->data	= $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		loadResult
	 * Purpose:		This will call loadResults and then only return the first item
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function loadResult()
	{
		if ($data = $this->_parseXml())
		{
			foreach ($data as $d)
			{
				return $d;
			}
		}
		else
		{
			return false;
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		loadResults
	 * Purpose:		This loads the xml parser and returns the data or false on failure
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function loadResults()
	{
		if ($data = $this->_parseXml())
		{
			return $data;
		}
		else
		{
			return false;
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setPairs
	 * Purpose:		This sets the data to split
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function setPairs($data)
	{
		$this->data = explode(';', $data);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		loadPairs
	 * Purpose:		This splits the data pairs and returns as an array
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function loadPairs()
	{
		foreach ($this->data as $items)
		{
			if (is_array($items))
			{
				foreach ($items as $item)
				{
					$tmp = explode('=', $item);
					$ret[trim($tmp[0])] = trim($tmp[1]);
				}
			}
			else
			{
				$tmp = explode('=', $items);
				$ret[trim($tmp[0])] = ( isset( $tmp[1] ) ? trim($tmp[1]) : null );
			}
		}
		return $ret;
	}
	
    /* ------------------------------------------------------------ *\
	 * Function:	_parseXml()
	 * Purpose:		This function parses an xml response from the
	 * 				WHMCS API interface.
	 * As of:		version 1.5.2 (October 2009)
	 * 
	 * Significant Revisions:
	 *  2.0.2 (Mar 2010)
	 *  	- dropped utf8_encode function - moved to setData
	 * 	1.5.3 (Nov 2009)
	 * 		* changed the way the xml was parsed to be able to handle
	 * 		  utf8_encode function
	\* ------------------------------------------------------------ */
	private function _parseXml()
	{
		$this->xml = xml_parser_create();
		xml_set_object($this->xml, $this);
        xml_set_element_handler($this->xml, "_tagOpen", "_tagClose");
        xml_set_character_data_handler($this->xml, "_cData");
		xml_parse($this->xml, $this->data);
		$this->error = (xml_get_error_code($this->xml) ? 'Error at '.$this->parseTag.': '. xml_error_string(xml_get_error_code($this->xml)) : false );
		xml_parser_free($this->xml);
		return $this->parseData;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_tagOpen
	 * Purpose:		This function is part of the xml parser.
	 * As of:		version 1.5.3 (November 2009)
	\* ------------------------------------------------------------ */
	private function _tagOpen($parser, $tag, $attributes)
	{
		$tag = strtolower($tag);
		if ($tag == $this->root) {
			$this->parseOn = true;
		}
		if ($tag != $this->parseTag) {
			$this->parseTag = $tag;
			$this->elemCnt	= 0;
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_cData
	 * Purpose:		This function is part of the xml parser.
	 * As of:		version 1.5.3 (November 2009)
	\* ------------------------------------------------------------ */
	private function _cData($parser, $cdata)
	{
		if ($this->elemCnt == 0) {
			$this->parseData[$this->parseCnt][$this->parseTag] = trim($cdata);
			$this->elemCnt++;
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_tagClose
	 * Purpose:		This function is part of the xml parser.
	 * As of:		version 1.5.3 (November 2009)
	\* ------------------------------------------------------------ */
	private function _tagClose($parser, $tag)
	{
		$tag = strtolower($tag);
		if ($tag == $this->root) {
			$this->parseOn = false;
			$this->parseCnt++;
		}
	}
}