<?php
/**
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: jwhmcs.php 202 2010-04-23 20:49:10Z Steven $
 * @since		1.5.0
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Require the base controller
require_once (JPATH_COMPONENT.DS.'controller.php');
require_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'model.php' );

// Require specific controller if requested
$controller = JRequest::getWord('controller', 'default');
require_once (JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php');

// Create the controller
$classname	= 'JwhmcsController'.$controller;
$controller = new $classname();

// Perform the Request task
$controller->execute( JRequest::getWord('task'));

// Redirect if set by the controller
$controller->redirect();

?>
