<?php
/**
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id$
 * @since		1.5.3
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once ('class.database.php');
require_once ('class.vars.php');
require_once ('class.curl.php');

class JwhmcsCache
{
	
	/**
	 * @var instance to contain object when created
	 */
	private static $instance = null;
	
    /* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Called upon initialization of object class
	 * 
	 * As of:		version 2.0
	 * 
	 * Significant Revisions:
	 * 	none
	\* ------------------------------------------------------------ */
	private function __construct()
	{
		global $db, $params, $vars, $jcurl;
		
		// If the hook is making the call, set debug off
		if ($vars->get( 'jwhmcs' ))		$params->set( 'jwhmcsdebug', 0 );
		
		// If the debug is on, then don't use caching (use live site)
		if ($params->get( 'jwhmcsdebug' ))	$vars->set( 'caching', 0, 'request');
		
		// Build Cache Directory
		$cachedir	= JPATH_CONFIG.DS.'cache'.DS.'jwhmcs';
		$this->cachedir  = $cachedir;
		
		// Verify cache directory exists
		$this->_checkDirectory();
		
		// Build Cache Filename
		$cachename = $vars->get( 'filename' ) . '.a' . ($vars->get( 'action' ) ? $vars->get( 'action' ) : '' ) . '.g' . ($vars->get( 'goto' ) ? $vars->get( 'goto' ) : '' ) . '.s' . ($vars->get( 'usessl' ) ? 't' : 'f' ) . '.l' . ($vars->get( 'loggedin' ) ? 'in' : 'out') . '.i' . ($vars->get( 'clientid' ) ? $vars->get( 'clientid' ) : '0' ) . ( $vars->get( 'lang' ) ? $vars->get( 'lang' ) : '' ) . '.php';
		
		// Set the filename for the cache file based on login status
		$this->cachefile = $cachedir .DS. $cachename; 
		
		// Set the URL Scheme for the page site based on variables passed and parameters set
		//$this->urlscheme = $parse->get( 'scheme' );
		
		if (($vars->get('task') == 'updateclient') && ($vars->get('jwhmcs'))) {
			$this->_clearClientCache($vars->get('clientid'));
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getInstance
	 * Purpose:		Called to create an instance of the class
	 * 
	 * As of:		version 2.0
	 * 
	 * Significant Revisions:
	 * 	none
	\* ------------------------------------------------------------ */
	public static function getInstance()
	{
		if (self::$instance == null)
		{
			self::$instance = new self;
		}
		return self::$instance;
	}
	

	public function cacheExists()
	{
		return file_exists($this->cachefile);
	}
	
	
	public function useCache()
	{
		global $vars;
		return $vars->get( 'caching' );
	}
	
	
	public function getCache()
	{
		if (!$this->cacheExists())
		{
			// Error trapping for non existant cache file "just in case"
			return false;
		}
		
		$cache = file_get_contents($this->cachefile);
		$lines = explode(';', $cache);
		
		if (count($lines)<=1)
		{
			// Error trapping for no lines returned
			return false; 
		}
		
		$this->validcache = $this->_checkCache($lines[1]);
		$off = array_shift($lines);
		
		return $lines;
	}
	
	
	public function delCache()
	{
		$vars = JwhmcsVars::getInstance();
		
		if (!$this->cacheExists())
		{
			// Error trapping for non existant cache file "just in case"
			return false;
		}
		
		unlink($this->cachefile);
		$vars->set( 'usecache', false );
		return true;
	}
	
	
	public function newCache()
	{
		$vars = JwhmcsVars::getInstance();
		
		if (isset($this->cachedata)) unset($this->cachedata);
		
		$this->cachedata[]	= "<?php defined( '_JEXEC' ) or die( 'Restricted access' ) ?>";
		$this->cachedata[]	= time() + ( $vars->get( 'cachetime' ) * 60);
	}
	
	
	public function addCache($line)
	{
		$this->cachedata[]	= $line;
	}
	
	
	public function saveCache()
	{
		$data	= implode(';', $this->cachedata);
		file_put_contents($this->cachefile, $data);
	}
	
	
	private function _checkDirectory()
	{
		if (! is_dir($this->cachedir))
		{
			@mkdir($this->cachedir, 0755);
		}
		return true;
	}
	
	
	private function _checkCache($c)
	{
		if ($c > time())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	
	public function clearCache()
	{
		$params	= & JwhmcsParams::getInstance();
		
		if (! is_dir($this->cachedir))
		{
			@mkdir($this->cachedir, 0755);
		}
		
		$this->_removeDir($this->cachedir);
		$params->set( 'clearcache', 0, true);
		return;
	}
	
	
	public function _removeDir($dir, $DeleteMe = false)
	{
		if (!$dh = @opendir($dir)) return;
		while (($obj = readdir($dh)))
		{
			if($obj=='.' || $obj=='..') continue;
			if (!@unlink($dir.'/'.$obj)) $this->_removeDir($dir.'/'.$obj, true);
		}
		if ($DeleteMe)
		{
			closedir($dh);
			@rmdir($dir);
		}
	}
	
	
	private function _clearClientCache($id)
	{
		if ($handle = opendir($this->cachedir)) {
			while (false !== ($file = readdir($handle))) {
				$fparts = explode(".", $file);
				$fid = ltrim($fparts[5], "i");
				if ($fid == $id) {
					@unlink($this->cachedir.DS.$file);
				}
				unset($fparts, $fid);
			}
		}
		closedir($handle);
	}
}