function runCheck(step)
{
	var ajaxStatus = document.getElementById('checkStep'+step);
	var ajaxMessage = document.getElementById('checkMessage'+step);
	var url = document.getElementById('thisUrl').getProperty('value')+"?option=com_jwhmcs&controller=ajax&task=checkinstall&step="+step;
	var laststep = document.getElementById('laststep').getProperty('value');
	
	ajaxStatus.removeClass('ajaxInitial');
	ajaxStatus.addClass('ajaxLoading');
	ajaxMessage.setHTML('');
	
	var xhr = createXHR();
	//alert(url);
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var resp = parseXml(xhr.responseText);
				var nextStep = resp.getElementsByTagName("nextstep")[0].childNodes[0].nodeValue;
				var curStatus = resp.getElementsByTagName("status")[0].childNodes[0].nodeValue;
				var message  = resp.getElementsByTagName("message");
				var txt = ajaxMessage.innerHTML;
				var i=0;
				
				for (i=0; i<message.length; i++) {
					txt = message[i].childNodes[0].nodeValue + "\n" + txt;
				}
				ajaxMessage.setHTML(txt);
				
				document.getElementById('step').setProperty('value', nextStep);
				
				ajaxStatus.removeClass('ajaxLoading');
				if (curStatus == '1') {
					ajaxStatus.addClass('ajaxSuccess');
				}
				else if (curStatus == '0' ) {
					ajaxStatus.addClass('ajaxError');
				}
				else {
					ajaxStatus.addClass('ajaxAlert');
				}
				
				if (step != laststep) {
					runCheck(nextStep);
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function URLEncode (clearString) {
	var output = '';
	var x = 0;
	clearString = clearString.toString();
	var regex = /(^[a-zA-Z0-9_.]*)/;
	while (x < clearString.length) {
		var match = regex.exec(clearString.substr(x));
		if (match != null && match.length > 1 && match[1] != '') {
			output += match[1];
			x += match[1].length;
		} else {
			if (clearString[x] == ' ')
				output += '+';
			else {
				var charCode = clearString.charCodeAt(x);
				var hexVal = charCode.toString(16);
				output += '%' + ( hexVal.length < 2 ? '0' : '' ) + hexVal.toUpperCase();
			}
			x++;
		}
	}
	return output;
}


function parseXml(data) {
	try //Internet Explorer
	{
		xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
		xmlDoc.async="false";
		xmlDoc.loadXML(data);
	}
	catch(e)
	{
		try //Firefox, Mozilla, Opera, etc.
		{
			parser=new DOMParser();
			xmlDoc=parser.parseFromString(data,"text/xml");
		}
		catch(e) {alert(e.message)}
	}
	return xmlDoc.getElementsByTagName("param").item(0);
}


function createXHR() {
	var xhr = null;
		if (window.XMLHttpRequest) {
			xhr = new XMLHttpRequest();
		} else if (window.ActiveXObject) {
			try {
				xhr = new ActiveXObject('Microsoft.XMLHTTP');
			} catch (e) {}
		}
	return xhr;
}