<?php
/**
 * Help Page Controller for J!WHMCS Integrator
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since		1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsControllerHelppage
 * Extends:		JwhmcsController
 * Purpose:		Used as the controller for providing support
 * As of:		version 2.1.0
\* ------------------------------------------------------------ */
class JwhmcsControllerHelppage extends JwhmcsController
{
	/* ------------------------------------------------------------ *\
	 * Task:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
	}
}