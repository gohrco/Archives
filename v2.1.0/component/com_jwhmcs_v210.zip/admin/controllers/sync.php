<?php
/**
 * Group Management Controller for J!WHMCS Integrator
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since		1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsControllerSync
 * Extends:		JwhmcsController
 * Purpose:		Used for WHMCS User Synchronization
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsControllerSync extends JwhmcsController
{
	/* ------------------------------------------------------------ *\
	 * Task:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		requery
	 * Purpose:		Requeries WHMCS API for current info and stores it
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function requery()
	{
		$model	= $this->getModel( 'sync' );
		$post	= JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$model->requery($post);
		
		$msg = JText::_( 'JWHMCS_ADMIN_CONTR_SYNCREQ' );
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=sync', $msg );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		reload
	 * Purpose:		Empties the user table and rebuilds it completely
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function reload()
	{
		$model	= $this->getModel( 'sync' );
		$model->reload();
		
		$msg = JText::_( 'JWHMCS_ADMIN_CONTR_SYNCREB' );
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=sync', $msg );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		refresh
	 * Purpose:		Searches empty WHMCS ID positions for missing data
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function refresh()
	{
		$model	= $this->getModel( 'sync' );
		$model->refresh();
		
		$msg = JText::_( 'JWHMCS_ADMIN_CONTR_SYNCREF' );
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=sync', $msg );
	}
}