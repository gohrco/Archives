<?php
/**
 * Group Management Model for J!WHMCS Integrator
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since		1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelSync
 * Extends:		JwhmcsModel
 * Purpose:		Used to synchronize the WHMCS user table with J!
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsModelSync extends JwhmcsModel
{
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
		
		global $mainframe, $option;
		
		// Get pagination request variables
		$limit			= $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart		= $mainframe->getUserStateFromRequest($option.'.limitstart', 'limitstart', 0, 'int');
		$search			= $mainframe->getUserStateFromRequest('articleelement.search',				'search',			'',	'string');
		$search			= JString::strtolower($search);
		
		// In case limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
		$this->setState('search', $search);
		
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getData
	 * Purpose:		This model retrieves the data for the view based
	 * 				on the parameters and task sent to it.
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function getData($task = null)
	{
		// 0:  Initialize Common Variables
		global $mainframe, $option;
		$db		= &JFactory::getDBO();
		$uri	= &JURI::getInstance();
		
		$filter_order		= $mainframe->getUserStateFromRequest( "$option.filter_order",		'filter_order',		'a.name',	'cmd' );
		$filter_order_Dir	= $mainframe->getUserStateFromRequest( "$option.filter_order_Dir",	'filter_order_Dir',	'',			'word' );
		$filter_type		= $mainframe->getUserStateFromRequest( "$option.filter_type",		'filter_type', 		0,			'string' );
		$search				= $mainframe->getUserStateFromRequest( "$option.search",			'search', 			'',			'string' );
		$search				= JString::strtolower( $search );
		
		$limit				= $mainframe->getUserStateFromRequest( 'global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int' );
		$limitstart			= $mainframe->getUserStateFromRequest( $option.'.limitstart', 'limitstart', 0, 'int' );
		
		// 1:  Switch on task
		switch ($task):
		default:
			$query	= " ( SELECT SQL_CALC_FOUND_ROWS '1' AS 'type', w.* FROM #__jwhmcs_user AS w ) 
						UNION ALL
						( SELECT '5' AS 'type', c.* FROM jos_jwhmcs_usersub AS c ) ORDER BY lname";
						
			$db->setQuery($query, $limitstart, $limit);
			$items	= $db->loadObjectList();
			
			// Fetch Pagination
			$db->setQuery('SELECT FOUND_ROWS();');
			jimport('joomla.html.pagination');
			$pagination = new JPagination($db->loadResult(), $this->getState('limitstart'), $this->getState('limit') );
			
			$data->items		= $items;
			$data->pagination	= $pagination;
		endswitch;
		
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	requery
	 * Purpose:		Takes the user and finds updated info
	 * As of:		version 1.5.1 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.0 (Dec 2009)
	 *  	+ Added usage of JwhmcsCurl class
	 *  	- Dropped usage of _wCurl function
	\* ------------------------------------------------------------ */
	public function requery($cid)
	{
		// 0:  Initialize Variables
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$cnt	=   0;
		$cot	=   0;
		
		// 1:  For each cid, pull current WHMCS user data
		foreach ($cid as $id)
		{
			$tmp = explode(",", $id);
			switch ($tmp[1]):
			case '1':
				$jcurl->setAction('getclientsdata', array('clientid' => $tmp[0]));
				$acct[$cnt] = $jcurl->loadResult();
				$cnt++;
				break;
			case '5':
				$jcurl->setAction('jwhmcsgetcontact', array('get' => 'id='.$tmp[0]));
				$sub[$cot] = $jcurl->loadResult();
				$cot++;
				break;
			endswitch;
		}
		
		$qmain = "UPDATE %1\$s SET fname=%2\$s, lname=%3\$s, cname=%4\$s, email=%5\$s, address1=%6\$s, address2=%7\$s, city=%8\$s, state=%9\$s, postal=%10\$s, country=%11\$s, phonenumber=%12\$s WHERE id=%13\$d";
		
		if (count($acct) > 0) {
			foreach ($acct as $item) {
				if ($item['result'] == 'success') {
					$query = sprintf($qmain, '#__jwhmcs_user', $db->Quote($item['firstname']), $db->Quote($item['lastname']), $db->Quote($item['companyname']), $db->Quote($item['email']), $db->Quote($item['address1']), $db->Quote($item['address2']), $db->Quote($item['city']),$db->Quote($item['state']), $db->Quote($item['postcode']), $db->Quote($item['country']), $db->Quote($item['phonenumber']), $item['id']);
				}
				else {
					$query = 'DELETE FROM #__jwhmcs_user WHERE id='.$item['id'];
				}
				$db->setQuery($query);
				$db->query();
			}
		}
		
		if (count($sub)>0) {
			foreach ($sub as $item) {
				if ($item['result'] == 'success') {
					$query = sprintf($qmain, '#__jwhmcs_usersub', $db->Quote($item['firstname']), $db->Quote($item['lastname']), $db->Quote($item['companyname']), $db->Quote($item['email']), $db->Quote($item['address1']), $db->Quote($item['address2']), $db->Quote($item['city']),$db->Quote($item['state']), $db->Quote($item['postcode']), $db->Quote($item['country']), $db->Quote($item['phonenumber']), $item['id']);
				}
				else {
					$query = 'DELETE FROM #__jwhcms_usersub WHERE id='.$item['id'];
				}
				$db->setQuery($query);
				$db->query();
			}
		}
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	reload
	 * Purpose:		Clears WHMCS users from table and reloads them
	 * As of:		version 1.5.1 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 *  	* Modified parameters to reflect database change
	 *  2.0 (Dec 2009)
	 *  	+ Calls function in root file instead of using API
	 *  	- Dropped numerous slow calls to API
	\* ------------------------------------------------------------ */
	public function reload()
	{
		// 0:  Initialize Variables
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		$data	=   array();
		
		// 1:  Empty current jwhmcs_user table
		$query	= 'TRUNCATE TABLE #__jwhmcs_user';
		$db->setQuery($query);
		$db->query();
		
		$query	= 'TRUNCATE TABLE #__jwhmcs_usersub';
		$db->setQuery($query);
		$db->query();
		
		// 2:  Retrieve data from root file
		$jcurl->setCall();
		$url = $params->get( 'ApiUrl' ).'/jwhmcs.php?task=syncReload&jwhmcs=1&joomadmin='.$params->get( 'Secret' );
		$jcurl->set(CURLOPT_URL, $url);
		$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
		$jcurl->setRoot('SUB');
		$ret = $jcurl->loadResults();
		
		// 3:  Store gathered data
		$query_useract	= 'INSERT INTO #__jwhmcs_user (`id`, `fname`, `lname`, `cname`, `email`, `address1`, `address2`, `city`, `state`, `postal`, `country`, `phonenumber`) VALUES ';
		$query_usersub	= 'INSERT INTO #__jwhmcs_usersub (`id`, `fname`, `lname`, `cname`, `email`, `address1`, `address2`, `city`, `state`, `postal`, `country`, `phonenumber`) VALUES ';
		
		// Test to see if we got anything back 
		if (count($ret)>0) {
			// Set vars
			$run = true;
			$cnt = -1;
			$max = 1000;
			
			do {
				
				for ($j = 0; $j < $max; $j++) {
					$cnt++;
					if (! isset($ret[$cnt])) {
						$run = false;
						continue;
					}
					$item = $ret[$cnt];
					$qitem = ' ('.$db->Quote($item['id']).', '
								.$db->Quote($item['firstname']).', '
								.$db->Quote($item['lastname']).', '
								.$db->Quote($item['companyname']).', '
								.$db->Quote($item['email']).', '
								.$db->Quote($item['address1']).', '
								.$db->Quote($item['address2']).', '
								.$db->Quote($item['city']).', '
								.$db->Quote($item['state']).', '
								.$db->Quote($item['postcode']).', '
								.$db->Quote($item['country']).', '
								.$db->Quote($item['phonenumber']).')';
					if ( $item['type'] == '1' ) {
						$act[] = $qitem;
					}
					elseif ( $item['type'] == '5' ) {
						$sub[] = $qitem;
					}
				}
				
				if ( count($act) > 0 ) {
					$queryt = $query_useract.implode(',', $act);
					$db->setQuery($queryt);
					$db->query();
				}
				if ( count( $sub) > 0 ) {
					$queryt = $query_usersub.implode(',', $sub);
					$db->setQuery($queryt);
					$db->query();
				}
				unset ($sub, $act, $qitem, $queryt);
			} while ($run === true);
		}
		
		$this->_timeStamp();
		
		// 5:  Return
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	refresh
	 * Purpose:		Finds missing users and adds them into database
	 * As of:		version 1.5.3 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 *  	* Modified parameters to reflect database change
	 *  2.0 (Dec 2009)
	 *  	+ Added usage of JwhmcsCurl class
	 *  	- Dropped usage of _wCurl function
	\* ------------------------------------------------------------ */
	public function refresh ()
	{
		// 0:  Initialize variables
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		$chkids = array();
		$data	= array();
		
		// 1:  Select current ids from jwhmcs_user table
		$query	= 'SELECT id FROM #__jwhmcs_user ORDER BY id DESC';
		$db->setQuery($query);
		$curids	= $db->loadResultArray();
		
		$maxid = $curids[0] + 20;
		
		// 2:  Assemble array of potential ids to check
		for ($i=1; $i<=$maxid; $i++) {
			$chkids[$i] = true;
		}
		
		// 3:  Set each id that already exists to false
		foreach ($curids as $curid) {
			$chkids[$curid] = false;
		}
		
		// 4:  One by one, pull user data from WHMCS
		for($i=1; $i<=$maxid; $i++):
			
			if ($chkids[$i]===false)
			{
				continue;
			}
			
			$jcurl->setAction('getclientsdata', array('clientid' => $i));
			$whmcs	= $jcurl->loadResult();
			
			if ($whmcs['result']=='success')
			{
				$data[]	= $whmcs;
				if ($i>$maxid)
					$maxid = $i;		// Reset maximum to new highest
			}
		endfor;
		
		// 5:  Store gathered data
		if (count($data) > 0) {
			$query	= 'REPLACE INTO #__jwhmcs_user (`id`, `fname`, `lname`, `cname`, `email`, `address1`, `address2`, `city`, `state`, `postal`, `country`, `phonenumber`) VALUES '; 
			foreach ($data as $item):
				$q[]	= ' ('	.$db->Quote($item['userid']).', '
								.$db->Quote($item['firstname']).', '
								.$db->Quote($item['lastname']).', '
								.$db->Quote($item['companyname']).', '
								.$db->Quote($item['email']).', '
								.$db->Quote($item['address1']).', '
								.$db->Quote($item['address2']).', '
								.$db->Quote($item['city']).', '
								.$db->Quote($item['state']).', '
								.$db->Quote($item['postcode']).', '
								.$db->Quote($item['country']).', '
								.$db->Quote($item['phonenumber']).')';
			endforeach;
			$query	= $query.implode(',', $q);
			$db->setQuery($query);
			$db->query();
		}
		
		$this->_timeStamp();
		
		// 7:  Return
		return true;
	}
	
	
	/* ----------------------------------------- *\
	 *              SUB FUNCTIONS                *
	\* ----------------------------------------- */
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_timeStamp (private)
	 * Purpose:		This sets the time stamp for latest user sync
	 * As of:		version 2.0.3
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 *  	* Modified parameters to reflect database change
	\* ------------------------------------------------------------ */
	private function _timeStamp()
	{
		$params	= & JwhmcsParams::getInstance();
		
		$date = & JFactory::getDate();
		$params->set( 'LastSync', $date->toUnix(), true, 'user' );
		return;
	}
}