<?php
/**
 * Group Management Model for J!WHMCS Integrator
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since		1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelCheck
 * Extends:		JwhmcsModel
 * Purpose:		Checks the installation
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsModelCheck extends JwhmcsModel
{
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getData
	 * Purpose:		Retrieves the parameters for 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function getData()
	{
		$params = & JwhmcsParams::getInstance();
		$uri	=   JURI::getInstance();
		
		$data->thisUrl = $uri->current();
		
		return $data;
	}
	
	
	function process($step = 10)
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params = & JwhmcsParams::getInstance();
		
		$data['nextstep'] = $step + 10;
		
		switch($step):
		/* ----------------------------------------------------------------- STEP  10 *\
		 * CHECK INSTALLATION - Component Installed
		\* -------------------------------------------------------------------------- */
		case 10:
			// Obviously if we are here the component is at least installed - future revisions may include health check
			$data['status'] = 1;
			
			break;
		/* ----------------------------------------------------------------- STEP  20 *\
		 * CHECK INSTALLATION - Authentication Plugin installed and on
		\* -------------------------------------------------------------------------- */
		case 20:
			$query	= "SELECT `id`, `published`, `params` FROM #__plugins WHERE `element` = 'jwhmcs_auth' AND `folder` = 'authentication'";
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 0;
				$data['message'][] = "The Authentication - JWHMCS plugin could not be found!  It may not be installed at all!";
			}
			elseif ($result['published'] == '0') {
				$data['status'] = 2;
				$data['message'][] = "The Authentication - JWHMCS plugin was found but it is not enabled!  Be sure that you have an authentication plugin enabled, and if you enable the Authentication - JWHMCS plugin, you should deactivate the Authentication - Joomla plugin.";
			}
			else {
				$data['status'] = 1;
			}
			break;
			
		/* ----------------------------------------------------------------- STEP  30 *\
		 * CHECK INSTALLATION - System Plugin installed and on
		\* -------------------------------------------------------------------------- */
		case 30:
			$query	= "SELECT `id`, `published`, `params` FROM #__plugins WHERE `element` = 'jwhmcs_sysm' AND `folder` = 'system'";
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 0;
				$data['message'][] = "The System - JWHMCS plugin could not be found!  It may not be installed at all!";
			}
			elseif ($result['published'] == '0') {
				$data['status'] = 2;
				$data['message'][] = "The System - JWHMCS plugin was found but it is not enabled!  The System - JWHMCS plugin handles redirecting user registration requests from your Joomla site.";
			}
			else {
				$data['status'] = 1;
			}
			break;
			
		/* ----------------------------------------------------------------- STEP  40 *\
		 * CHECK INSTALLATION - System Language Plugin installed and on
		\* -------------------------------------------------------------------------- */
		case 40:
			$query	= "SELECT `id`, `published`, `params` FROM #__plugins WHERE `element` = 'jwhmcs_sysmlang' AND `folder` = 'system'";
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 2;
				$data['message'][] = "The System - JWHMCS Language plugin could not be found!  It may not be installed at all!  If you don't require language support, this plugin is not required to be installed.";
			}
			elseif ($result['published'] == '0') {
				$data['status'] = 2;
				$data['message'][] = "The System - JWHMCS Language plugin was found but it is not enabled!  The System - JWHMCS Language plugin handles Joomfish integration between WHMCS and Joomla.  If you don't require language support, this plugin may be disabled.";
			}
			else {
				$data['status'] = 1;
			}
			break;
		
		/* ----------------------------------------------------------------- STEP  50 *\
		 * CHECK INSTALLATION - User Plugin installed and on
		\* -------------------------------------------------------------------------- */
		case 50:
			$query	= "SELECT `id`, `published`, `params` FROM #__plugins WHERE `element` = 'jwhmcs_user' AND `folder` = 'user'";
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 1;
				$data['message'][] = "The User - JWHMCS Language plugin could not be found!  It may not be installed at all!";
			}
			elseif ($result['published'] == '0') {
				$data['status'] = 2;
				$data['message'][] = "The User - JWHMCS plugin was found but it is not enabled!  The User - JWHMCS plugin handles user redirection to WHMCS for logging in purposes and is required if you intend to utilize the user integration features.";
			}
			else {
				$data['status'] = 1;
			}
			break;
			
		/* ----------------------------------------------------------------- STEP  60 *\
		 * CHECK INSTALLATION - Hidden Menu created
		\* -------------------------------------------------------------------------- */
		case 60:
			$query	= "SELECT `id` FROM `#__menu_types` WHERE `menutype` = 'jwhmcs-hidden'";
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 2;
				$data['message'][] = "The installer didn't install the J!WHMCS Hidden Menu or it has been deleted.  The hidden menu holds the pages used for the visual integration.  Although it is checked, it isn't required, as the pages used for visual integration can be on any menu.";
			}
			else {
				$data['status'] = 1;
			}
			break;
			
		/* ----------------------------------------------------------------- STEP  70 *\
		 * CHECK INSTALLATION - WHMCS Root Files Installed
		\* -------------------------------------------------------------------------- */
		case 70:
			$jcurl->setCall();
			$url = $params->get( 'ApiUrl' ).'/jwhmcs.php?task=installCheck&check=root&joomadmin='.$params->get( 'Secret' );
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
			$jcurl->setRoot('root');
			$result = $jcurl->loadResult();
			
			if ($result['result'] == 'success') {
				$data['status'] = 1;
			}
			else {
				$message = "The installer was unable to locate the the J!WHMCS Integrator root files at the location (http://{$params->get( 'ApiUrl' )}) specified in your settings.  Please double check the settings for the WHMCS Url or install the root files in the correct location.";
				$data['status'] = 0;
				$data['message'][] = $message;
			}
			break;
		
		/* ----------------------------------------------------------------- STEP  80 *\
		 * CHECK INSTALLATION - WHMCS Hook Files Installed
		\* -------------------------------------------------------------------------- */
		case 80:
			$jcurl->setCall();
			$url = $params->get( 'ApiUrl' ).'/jwhmcs.php?task=installCheck&check=hook&joomadmin='.$params->get( 'Secret' );
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
			$jcurl->setRoot('root');
			$result = $jcurl->loadResult();
			
			if ($result['result'] == 'success') {
				$data['status'] = 1;
			}
			else {
				$message	= "The installer was unable to locate some of the J!WHMCS Integrator hook files at the location (http://{$params->get( 'ApiUrl' )}/includes/hooks) specified in your settings.  ";
				if ($result['message'] & 1)
					$message .= "The file `jwhmcs.php` is missing.";
				if ($result['message'] & 2)
					$message .= "The file `jwhmcs-lang.php` is missing.";
				if (!$result['message'])
					$message .= "Please double check the settings for the WHMCS Url.";
				
				$data['status'] = 0;
				$data['message'][] = $message;
			}
			break;
		
		/* ----------------------------------------------------------------- STEP  90 *\
		 * CHECK INSTALLATION - WHMCS API Files Installed
		\* -------------------------------------------------------------------------- */
		case 90:
			$jcurl->setCall();
			$url = $params->get( 'ApiUrl' ).'/jwhmcs.php?task=installCheck&check=api&joomadmin='.$params->get( 'Secret' );
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
			$jcurl->setRoot('root');
			$result = $jcurl->loadResult();
			
			if ($result['result'] == 'success') {
				$data['status'] = 1;
			}
			else {
				$message	= "The installer was unable to locate some of the J!WHMCS Integrator api files at the location (http://{$params->get( 'ApiUrl' )}/includes/api) specified in your settings.  ";
				if ($result['message'] & 1)
					$message .= "The file `jwhmcsconfig.php` is missing.";
				if ($result['message'] & 2)
					$message .= "The file `jwhmcsgetsettings.php` is missing.";
				if (!$result['message'])
					$message .= "Please double check the settings for the WHMCS Url.";
				
				$data['status'] = 0;
				$data['message'][] = $message;
			}
			break;
			
		/* ----------------------------------------------------------------- STEP 100 *\
		 * CHECK INSTALLATION - WHMCS Template Files Installed
		\* -------------------------------------------------------------------------- */
		case 100:
			$jcurl->setCall();
			$url = $params->get( 'ApiUrl' ).'/jwhmcs.php?task=installCheck&check=template&joomadmin='.$params->get( 'Secret' );
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
			$jcurl->setRoot('root');
			$result = $jcurl->loadResult();
			
			if ($result['result'] == 'success') {
				$data['status'] = 1;
			}
			else {
				$message	= "The installer was unable to locate the template directories setup by the J!WHMCS Integrator in the http://{$params->get( 'ApiUrl' )}/templates folder.  ";
				if ($result['message'] & 1)
					$message .= "The directory `jwhmcs-defaul` is missing.";
				if ($result['message'] & 2)
					$message .= "The directory `jwhmcs-portal` is missing.";
				if (!$result['message'])
					$message .= "Please double check the settings for the WHMCS Url.";
				
				$message .= "  It may not be necessary to have these directories in place if you have already installed your templates elsewhere and it is functional.";
				$data['status'] = 2;
				$data['message'][] = $message;
			}
			break;
			
		/* ----------------------------------------------------------------- STEP 110 *\
		 * CHECK INSTALLATION - Check License
		\* -------------------------------------------------------------------------- */
		case 110:
			$license = $this->checkLicense();
			
			if ($license['return'] == 'Active') {
				$data['status'] = 1;
			}
			elseif (($license['return'] == 'Expired') && ($license['valid'] == 1)) {
				$data['status'] = 2;
				$data['message'] = "Your license is valid and J!WHMCS Integrator will continue to operate, however your account is not active and you are no longer eligible for upgrades and premium support.";
			}
			elseif (isset($license['response'])) {
				$data['status'] = 0;
				$data['message'] = "Your license could not be validated.  Please verify your setting for the WHMCS Url and ensure the J!WHMCS Integrator root file is installed.";
			}
			else {
				$data['status'] = 0;
				$data['message'] = "Your license is not valid.  Please double check your settings in the License Manager or contact a vendor to purchase a license.";
			}
			break;
			
		/* ----------------------------------------------------------------- STEP 120 *\
		 * CHECK INSTALLATION - Check API Connection
		\* -------------------------------------------------------------------------- */
		case 120:
			$apichck = $this->getApiConnection();
			
			if ($apichck['result'] == 'success') {
				$data['status'] = 1;
			}
			else {
				$data['status'] = 0;
				$data['message'] = $apichck['message'];
			}
			break;
			
		/* ----------------------------------------------------------------- STEP 130 *\
		 * CHECK INSTALLATION - Check API Connection
		\* -------------------------------------------------------------------------- */
		case 130:
			$query	= "SELECT `id` FROM `#__menu_types` WHERE `menutype` = 'client-menu'";
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 2;
				$data['message'][] = "The installer didn't install the Client Menu or it has been deleted.  This menu provides convenient links from Joomla to WHMCS.  Although it is checked, it isn't required, as the links can be created anywhere without the need for this menu.";
			}
			else {
				$data['status'] = 1;
			}
			break;
		endswitch;
		
		return $data;
	}
	
	/* ----------------------------------------- *\
	 *              SUB FUNCTIONS                *
	\* ----------------------------------------- */
	
	
}