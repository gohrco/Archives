<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_( 'behavior.mootools' );

$data = $this->data;

$j32jwhmcs = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-jwhmcs.png';
$j32helppage = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-helppage.png';
$j48check = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-48-chinst.png';
$j32yes = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-yes.png';
$j16yes = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-16-yes.png';
$j32no = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-no.png';
$j16no = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-16-no.png';
?>

<style type="text/css">
	.icon-48-chinst { background-image: url('<?php echo $j48check; ?>'); }
	.icon-32-jwhmcs { background-image: url('<?php echo $j32jwhmcs; ?>'); }
	.icon-32-helppage { background-image: url('<?php echo $j32helppage; ?>'); }
	.ajaxStatus		{ width: 100%; padding: 0px; margin: 0px auto; height: 32px; }
</style>

<table class="admintable">
	<tbody>
		<tr>
			<td class="stepTitle" colspan="2">
				Component Installed
			</td>
			<td width="50px">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep10"></div></div>
			</td>
			<td width="750px">
				<div class="ajaxMessage" id="checkMessage10">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle" colspan="3">
				Plugin Installation
			</td>
			<td></td>
		</tr>
		<tr>
			<td width="25px">
				&nbsp;</td>
			<td class="stepSubtitle">
				Authentication - J!WHMCS
			</td>
			<td>
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep20"></div></div>
			</td>
			<td>
				<div class="ajaxMessage" id="checkMessage20">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td width="25px">
				&nbsp;</td>
			<td class="stepSubtitle">
				System - J!WHMCS
			</td>
			<td>
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep30"></div></div>
			</td>
			<td>
				<div class="ajaxMessage" id="checkMessage30">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td width="25px">
				&nbsp;</td>
			<td class="stepSubtitle">
				System - J!WHMCS Language 
			</td>
			<td>
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep40"></div></div>
			</td>
			<td>
				<div class="ajaxMessage" id="checkMessage40">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td width="25px">
				&nbsp;</td>
			<td class="stepSubtitle">
				User - J!WHMCS
			</td>
			<td>
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep50"></div></div>
			</td>
			<td>
				<div class="ajaxMessage" id="checkMessage50">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle" colspan="2">
				Hidden Menu Created
			</td>
			<td width="50px">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep60"></div></div>
			</td>
			<td width="750px">
				<div class="ajaxMessage" id="checkMessage60">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle" colspan="3">
				WHMCS File Installation
			</td>
			<td></td>
		</tr>
		<tr>
			<td width="25px">
				&nbsp;</td>
			<td class="stepSubtitle">
				Root Files Installed
			</td>
			<td>
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep70"></div></div>
			</td>
			<td>
				<div class="ajaxMessage" id="checkMessage70">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td width="25px">
				&nbsp;</td>
			<td class="stepSubtitle">
				Hook Files Installed
			</td>
			<td>
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep80"></div></div>
			</td>
			<td>
				<div class="ajaxMessage" id="checkMessage80">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td width="25px">
				&nbsp;</td>
			<td class="stepSubtitle">
				Custom API Files Installed
			</td>
			<td>
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep90"></div></div>
			</td>
			<td>
				<div class="ajaxMessage" id="checkMessage90">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td width="25px">
				&nbsp;</td>
			<td class="stepSubtitle">
				Template Directories Installed
			</td>
			<td>
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep100"></div></div>
			</td>
			<td>
				<div class="ajaxMessage" id="checkMessage100">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle" colspan="2">
				Product License
			</td>
			<td width="50px">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep110"></div></div>
			</td>
			<td width="750px">
				<div class="ajaxMessage" id="checkMessage110">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle" colspan="2">
				API Connection
			</td>
			<td width="50px">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep120"></div></div>
			</td>
			<td width="750px">
				<div class="ajaxMessage" id="checkMessage120">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle" colspan="2">
				Client Menu Created
			</td>
			<td width="50px">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep130"></div></div>
			</td>
			<td width="750px">
				<div class="ajaxMessage" id="checkMessage130">&nbsp;</div>
			</td>
		</tr>
	</tbody>
</table>

<form action="index.php" method="post" name="adminForm" id="adminForm">
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="thisUrl" id="thisUrl" value="<?php echo $data->thisUrl; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="controller" value="check" />
<input type="hidden" name="step" id="step" value="10" />
<input type="hidden" name="laststep" id="laststep" value="130" />
</form>

<script language="javascript">
window.addEvent( 'domready', function() {
	runCheck($('step').getProperty('value'));
} );
</script>