<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');
jimport('joomla.html.pane');

$pane =& JPane::getInstance('tabs'); 

$data = $this->data;
$j32jwhmcs = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-jwhmcs.png';
$j32helppage = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-helppage.png';
$j48settings = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-48-settings.png';
$j32yes = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-yes.png';
$j16yes = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-16-yes.png';
$j32no = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-no.png';
$j16no = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-16-no.png';

$glob_config = $this->data->global;
$style_config = $this->data->style;
$user_config = $this->data->user;
$whmcs_config = $this->data->whmcs;
$menus_config = $this->data->menu;
$kayako_config = $this->data->kayako;
$recap_config = $this->data->recaptcha;
$reg_config = $this->data->registration;
?>
<style type="text/css">
	.icon-48-settings	{ background-image: url('<?php echo $j48settings; ?>'); }
	.icon-32-jwhmcs		{ background-image: url('<?php echo $j32jwhmcs; ?>'); }
	.icon-32-helppage	{ background-image: url('<?php echo $j32helppage; ?>'); }
table.adminlist thead tr {
	border-spacing: 0px;
}
table.adminlist thead tr th.hdr {
	border-bottom: 0px;
	font-size: 12pt;
	line-height: 1.1em;
	margin: 0px;
	padding: 4px 0px;
}
table.adminlist tr td.status {
	vertical-align: top;
	text-align: center;
}
table.adminlist tr td.title, table.adminlist tr td.title2 {
	font-weight: bold;
	text-align: center;
	vertical-align: top;
}
table.adminlist tr td.value {
	font-weight: bold;
	text-align: center;
	vertical-align: top;
}
table.adminlist tr td.detail {
	vertical-align: top;
	font-style: italic;
}
table.adminlist tr td.title2 {
	border-left: 1px solid #999999;
}
td.paramlabel { font-style: italic; color: #333; }
.paramname { font-size: medium; font-weight: bold; color: #555; font-style: italic; float: left; }
.parameter, .desconly { font-size: medium; width: 350px; float: right; color: #555; font-style: italic; font-weight: bold; }
.parameter input, .parameter select { color: #333; font-size: medium !important; margin: 4px; }
.parameter select { width: 310px; }
.paramdesc { font-size: x-small; clear: both; float: right; color: #666; font-style: italic; width: 100%; }
.paramitem { padding: 10px 0 !important; border-bottom: #ccc 1px solid; }
.desconly { border-bottom: 1px dotted #CCCCCC; }
</style>
<!--  <div style="float: right; width: 300px; background-color: #ff0000; ">&nbsp;</div> -->
<div style="float: left; width: 680px; ">
<form action="index.php" method="post" name="adminForm">

<?php 
echo $pane->startPane( 'tabs' );
echo $pane->startPanel( 'Global Configuration', 'global_config' );

?>

<div id="globalCell">
	<table class="admintable">
		<?php foreach ($glob_config as $item): ?>
		<?php if (!$item->display) continue; ?>
		<tr>
			<td class="paramitem">
				<div class="paramname">
					<?php echo $item->name; ?></div>
				<div class="parameter">
					<?php echo $item->field; ?></div>
				<div class="paramdesc">
					<?php echo $item->desc; ?></div>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</div>

<?php 
echo $pane->endPanel();
echo $pane->startPanel( 'User Integration', 'user_config' );
?>

<div id="userCell">
	<table class="admintable">
		<?php foreach ($user_config as $item): ?>
		<?php if (!$item->display) continue; ?>
		<tr>
			<td class="paramitem">
				<div class="paramname">
					<?php echo $item->name; ?></div>
				<div class="parameter">
					<?php echo $item->field; ?></div>
				<div class="paramdesc">
					<?php echo $item->desc; ?></div>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</div>

<?php
echo $pane->endPanel();
if ($this->lic['kayako']):
echo $pane->startPanel( 'Kayako', 'kayako_config' );
?>

<div id="kayakoCell">
	<table class="admintable">
		<?php foreach ($kayako_config as $item): ?>
		<?php if (!$item->display) continue; ?>
		<tr>
			<td class="paramitem">
				<div class="paramname">
					<?php echo $item->name; ?></div>
				<div class="parameter">
					<?php echo $item->field; ?></div>
				<div class="paramdesc">
					<?php echo $item->desc; ?></div>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</div>

<?php
echo $pane->endPanel();
endif;
echo $pane->startPanel( 'Visual Integration', 'style_config' );

?>

<div id="styleCell">
	<table class="admintable">
		<?php foreach ($style_config as $item): ?>
		<?php if (!$item->display) continue; ?>
		<tr>
			<td class="paramitem">
				<div class="paramname">
					<?php echo $item->name; ?></div>
				<div class="parameter">
					<?php echo $item->field; ?></div>
				<div class="paramdesc">
					<?php echo $item->desc; ?></div>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</div>

<?php
echo $pane->endPanel();
echo $pane->startPanel( 'Registration', 'reg_config' );

?>

<div id="regCell">
	<table class="admintable">
		<?php foreach ($reg_config as $item): ?>
		<?php if (!$item->display) continue; ?>
		<tr>
			<td class="paramitem">
				<div class="paramname">
					<?php echo $item->name; ?></div>
				<div class="parameter">
					<?php echo $item->field; ?></div>
				<div class="paramdesc">
					<?php echo $item->desc; ?></div>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</div>

<?php
echo $pane->endPanel();
echo $pane->startPanel( 'reCaptcha', 'recap_config' );

?>

<div id="recapCell">
	<table class="admintable">
		<?php foreach ($recap_config as $item): ?>
		<?php if (!$item->display) continue; ?>
		<tr>
			<td class="paramitem">
				<div class="paramname">
					<?php echo $item->name; ?></div>
				<div class="parameter">
					<?php echo $item->field; ?></div>
				<div class="paramdesc">
					<?php echo $item->desc; ?></div>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</div>

<?php
echo $pane->endPanel();
echo $pane->startPanel( 'Menu Highlight', 'menu_config' );

?>

<div id="menusCell">
	<table class="admintable">
		<?php foreach ($menus_config as $item): ?>
		<?php if (!$item->display) continue; ?>
		<tr>
			<td class="paramitem">
				<div class="paramname">
					<?php echo $item->name; ?></div>
				<div class="parameter">
					<?php echo $item->field; ?></div>
				<div class="paramdesc">
					<?php echo $item->desc; ?></div>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</div>

<?php
echo $pane->endPanel();
echo $pane->endPane();

?>

<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="config" />
</form>
</div>