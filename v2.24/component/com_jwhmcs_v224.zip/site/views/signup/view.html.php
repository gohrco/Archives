<?php
/**
 * Default View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: view.html.php 134 2010-12-27 16:54:02Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsViewDefault
 * Extends:		JView
 * Purpose:		Handles the default view
 * As of:		version 1.5.0
\* ------------------------------------------------------------ */
class JwhmcsViewSignup extends JView
{
	/* ------------------------------------------------------------ *\
	 * Handler:		display
	 * Purpose:		Needed for building the class
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	function display($tpl = null)
	{
		// Load data for register layout
		global $mainframe;
		
		$tmplparams	=   $mainframe->getParams();
		$pathway	= & $mainframe->getPathway();
		$params		= & JwhmcsParams::getInstance();
		$uri		= & JURI::getInstance();
		$document	= & JFactory::getDocument();
		$layout		= & JRequest::getVar( 'layout' );
		$model		= & $this->getModel();
		$user		= & JFactory::getUser();
		$thisurl	=   rtrim( $uri->base(), "/") . "/";
		
		switch($layout):
		case 'default':
		default:
			
		 	// Page Title
			$menus	= & JSite::getMenu();
			$menu	=   $menus->getActive();
			$menups	=   new JParameter( $menu->params );
			
			if ( $menups->get( 'page_title' ) ) $document->setTitle( $menups->get( 'page_title' ) );
			$pathway->addItem( JText::_( 'New' ));
			
			// Load the form validation behavior
			JHTML::_('behavior.formvalidation');
			JHTML::_( 'behavior.mootools' );
			
			$user 	= & JFactory::getUser();
			$post	=   JRequest::get('post');
			
			// Build Country Select
			$country	= JHTML::_('select.genericlist', $this->_buildCountry(), 'country', null, 'value', 'text', ( $post['country'] ? $post['country'] : $params->get( 'WhmcsDefaultcountry' ) ) );
			
			JHTML::script('jquery.js',			rtrim( $params->get( 'ApiUrl' ), "/" ).'/includes/jscript/', true);
			JHTML::script('noconflict.js',		'components/com_jwhmcs/js/', true);
			JHTML::script('ajax.js',			'components/com_jwhmcs/js/', true);
			JHTML::script('signup.default.js',	'components/com_jwhmcs/js/', true);
			
			JHTML::stylesheet( 'signup.css', 	'administrator/components/com_jwhmcs/assets/' );
			
			$tmplparams->set( 'RecaptchaEnable',	$params->get( 'RecaptchaEnable' ));
			$tmplparams->set( 'RecaptchaTheme',		$params->get( 'RecaptchaTheme' ));
			$tmplparams->set( 'RecaptchaLang',		$params->get( 'RecaptchaLang' ));
			$tmplparams->set( 'RecaptchaPublickey',	$params->get( 'RecaptchaPublickey' ));
			
			$params->set( 'scheme', $uri->getScheme() );
			
			$this->assignRef( 'tmplparams',	$tmplparams );
			$this->assignRef( 'params',		$params );
			$this->assignRef( 'user',		$user );
			$this->assignRef( 'country',	$country );
			$this->assignRef( 'post',		$post );
			$this->assignRef( 'tmp', 		$params );
			$this->assignRef( 'thisurl',	$thisurl );
			
			break;
		endswitch;
		
		parent::display($tpl);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Handler:		_buildCountry (private)
	 * Purpose:		Returns the country array
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	private function _buildCountry()
	{
		$country[] = array('value' => 'AF', 'text' => 'Afghanistan');
		$country[] = array('value' => 'AX', 'text' => 'Aland Islands');
		$country[] = array('value' => 'AL', 'text' => 'Albania');
		$country[] = array('value' => 'DZ', 'text' => 'Algeria');
		$country[] = array('value' => 'AS', 'text' => 'American Samoa');
		$country[] = array('value' => 'AD', 'text' => 'Andorra');
		$country[] = array('value' => 'AO', 'text' => 'Angola');
		$country[] = array('value' => 'AI', 'text' => 'Anguilla');
		$country[] = array('value' => 'AQ', 'text' => 'Antarctica');
		$country[] = array('value' => 'AG', 'text' => 'Antigua And Barbuda');
		$country[] = array('value' => 'AR', 'text' => 'Argentina');
		$country[] = array('value' => 'AM', 'text' => 'Armenia');
		$country[] = array('value' => 'AW', 'text' => 'Aruba');
		$country[] = array('value' => 'AU', 'text' => 'Australia');
		$country[] = array('value' => 'AT', 'text' => 'Austria');
		$country[] = array('value' => 'AZ', 'text' => 'Azerbaijan');
		$country[] = array('value' => 'BS', 'text' => 'Bahamas');
		$country[] = array('value' => 'BH', 'text' => 'Bahrain');
		$country[] = array('value' => 'BD', 'text' => 'Bangladesh');
		$country[] = array('value' => 'BB', 'text' => 'Barbados');
		$country[] = array('value' => 'BY', 'text' => 'Belarus');
		$country[] = array('value' => 'BE', 'text' => 'Belgium');
		$country[] = array('value' => 'BZ', 'text' => 'Belize');
		$country[] = array('value' => 'BJ', 'text' => 'Benin');
		$country[] = array('value' => 'BM', 'text' => 'Bermuda');
		$country[] = array('value' => 'BT', 'text' => 'Bhutan');
		$country[] = array('value' => 'BO', 'text' => 'Bolivia');
		$country[] = array('value' => 'BA', 'text' => 'Bosnia And Herzegovina');
		$country[] = array('value' => 'BW', 'text' => 'Botswana');
		$country[] = array('value' => 'BV', 'text' => 'Bouvet Island');
		$country[] = array('value' => 'BR', 'text' => 'Brazil');
		$country[] = array('value' => 'IO', 'text' => 'British Indian Ocean Territory');
		$country[] = array('value' => 'BN', 'text' => 'Brunei Darussalam');
		$country[] = array('value' => 'BG', 'text' => 'Bulgaria');
		$country[] = array('value' => 'BF', 'text' => 'Burkina Faso');
		$country[] = array('value' => 'BI', 'text' => 'Burundi');
		$country[] = array('value' => 'KH', 'text' => 'Cambodia');
		$country[] = array('value' => 'CM', 'text' => 'Cameroon');
		$country[] = array('value' => 'CA', 'text' => 'Canada');
		$country[] = array('value' => 'CV', 'text' => 'Cape Verde');
		$country[] = array('value' => 'KY', 'text' => 'Cayman Islands');
		$country[] = array('value' => 'CF', 'text' => 'Central African Republic');
		$country[] = array('value' => 'TD', 'text' => 'Chad');
		$country[] = array('value' => 'CL', 'text' => 'Chile');
		$country[] = array('value' => 'CN', 'text' => 'China');
		$country[] = array('value' => 'CX', 'text' => 'Christmas Island');
		$country[] = array('value' => 'CC', 'text' => 'Cocos Keeling Islands');
		$country[] = array('value' => 'CO', 'text' => 'Colombia');
		$country[] = array('value' => 'KM', 'text' => 'Comoros');
		$country[] = array('value' => 'CG', 'text' => 'Congo');
		$country[] = array('value' => 'CD', 'text' => 'Congo, Democratic Republic');
		$country[] = array('value' => 'CK', 'text' => 'Cook Islands');
		$country[] = array('value' => 'CR', 'text' => 'Costa Rica');
		$country[] = array('value' => 'CI', 'text' => 'Cote D\'Ivoire');
		$country[] = array('value' => 'HR', 'text' => 'Croatia');
		$country[] = array('value' => 'CU', 'text' => 'Cuba');
		$country[] = array('value' => 'CY', 'text' => 'Cyprus');
		$country[] = array('value' => 'CZ', 'text' => 'Czech Republic');
		$country[] = array('value' => 'DK', 'text' => 'Denmark');
		$country[] = array('value' => 'DJ', 'text' => 'Djibouti');
		$country[] = array('value' => 'DM', 'text' => 'Dominica');
		$country[] = array('value' => 'DO', 'text' => 'Dominican Republic');
		$country[] = array('value' => 'EC', 'text' => 'Ecuador');
		$country[] = array('value' => 'EG', 'text' => 'Egypt');
		$country[] = array('value' => 'SV', 'text' => 'El Salvador');
		$country[] = array('value' => 'GQ', 'text' => 'Equatorial Guinea');
		$country[] = array('value' => 'ER', 'text' => 'Eritrea');
		$country[] = array('value' => 'EE', 'text' => 'Estonia');
		$country[] = array('value' => 'ET', 'text' => 'Ethiopia');
		$country[] = array('value' => 'FK', 'text' => 'Falkland Islands Malvinas');
		$country[] = array('value' => 'FO', 'text' => 'Faroe Islands');
		$country[] = array('value' => 'FJ', 'text' => 'Fiji');
		$country[] = array('value' => 'FI', 'text' => 'Finland');
		$country[] = array('value' => 'FR', 'text' => 'France');
		$country[] = array('value' => 'GF', 'text' => 'French Guiana');
		$country[] = array('value' => 'PF', 'text' => 'French Polynesia');
		$country[] = array('value' => 'TF', 'text' => 'French Southern Territories');
		$country[] = array('value' => 'GA', 'text' => 'Gabon');
		$country[] = array('value' => 'GM', 'text' => 'Gambia');
		$country[] = array('value' => 'GE', 'text' => 'Georgia');
		$country[] = array('value' => 'DE', 'text' => 'Germany');
		$country[] = array('value' => 'GH', 'text' => 'Ghana');
		$country[] = array('value' => 'GI', 'text' => 'Gibraltar');
		$country[] = array('value' => 'GR', 'text' => 'Greece');
		$country[] = array('value' => 'GL', 'text' => 'Greenland');
		$country[] = array('value' => 'GD', 'text' => 'Grenada');
		$country[] = array('value' => 'GP', 'text' => 'Guadeloupe');
		$country[] = array('value' => 'GU', 'text' => 'Guam');
		$country[] = array('value' => 'GT', 'text' => 'Guatemala');
		$country[] = array('value' => 'GG', 'text' => 'Guernsey');
		$country[] = array('value' => 'GN', 'text' => 'Guinea');
		$country[] = array('value' => 'GW', 'text' => 'Guinea-Bissau');
		$country[] = array('value' => 'GY', 'text' => 'Guyana');
		$country[] = array('value' => 'HT', 'text' => 'Haiti');
		$country[] = array('value' => 'HM', 'text' => 'Heard Island & Mcdonald Islands');
		$country[] = array('value' => 'VA', 'text' => 'Holy See Vatican City State');
		$country[] = array('value' => 'HN', 'text' => 'Honduras');
		$country[] = array('value' => 'HK', 'text' => 'Hong Kong');
		$country[] = array('value' => 'HU', 'text' => 'Hungary');
		$country[] = array('value' => 'IS', 'text' => 'Iceland');
		$country[] = array('value' => 'IN', 'text' => 'India');
		$country[] = array('value' => 'ID', 'text' => 'Indonesia');
		$country[] = array('value' => 'IR', 'text' => 'Iran, Islamic Republic Of');
		$country[] = array('value' => 'IQ', 'text' => 'Iraq');
		$country[] = array('value' => 'IE', 'text' => 'Ireland');
		$country[] = array('value' => 'IM', 'text' => 'Isle Of Man');
		$country[] = array('value' => 'IL', 'text' => 'Israel');
		$country[] = array('value' => 'IT', 'text' => 'Italy');
		$country[] = array('value' => 'JM', 'text' => 'Jamaica');
		$country[] = array('value' => 'JP', 'text' => 'Japan');
		$country[] = array('value' => 'JE', 'text' => 'Jersey');
		$country[] = array('value' => 'JO', 'text' => 'Jordan');
		$country[] = array('value' => 'KZ', 'text' => 'Kazakhstan');
		$country[] = array('value' => 'KE', 'text' => 'Kenya');
		$country[] = array('value' => 'KI', 'text' => 'Kiribati');
		$country[] = array('value' => 'KR', 'text' => 'Korea');
		$country[] = array('value' => 'KW', 'text' => 'Kuwait');
		$country[] = array('value' => 'KG', 'text' => 'Kyrgyzstan');
		$country[] = array('value' => 'LA', 'text' => 'Lao People\'s Democratic Republic');
		$country[] = array('value' => 'LV', 'text' => 'Latvia');
		$country[] = array('value' => 'LB', 'text' => 'Lebanon');
		$country[] = array('value' => 'LS', 'text' => 'Lesotho');
		$country[] = array('value' => 'LR', 'text' => 'Liberia');
		$country[] = array('value' => 'LY', 'text' => 'Libyan Arab Jamahiriya');
		$country[] = array('value' => 'LI', 'text' => 'Liechtenstein');
		$country[] = array('value' => 'LT', 'text' => 'Lithuania');
		$country[] = array('value' => 'LU', 'text' => 'Luxembourg');
		$country[] = array('value' => 'MO', 'text' => 'Macao');
		$country[] = array('value' => 'MK', 'text' => 'Macedonia');
		$country[] = array('value' => 'MG', 'text' => 'Madagascar');
		$country[] = array('value' => 'MW', 'text' => 'Malawi');
		$country[] = array('value' => 'MY', 'text' => 'Malaysia');
		$country[] = array('value' => 'MV', 'text' => 'Maldives');
		$country[] = array('value' => 'ML', 'text' => 'Mali');
		$country[] = array('value' => 'MT', 'text' => 'Malta');
		$country[] = array('value' => 'MH', 'text' => 'Marshall Islands');
		$country[] = array('value' => 'MQ', 'text' => 'Martinique');
		$country[] = array('value' => 'MR', 'text' => 'Mauritania');
		$country[] = array('value' => 'MU', 'text' => 'Mauritius');
		$country[] = array('value' => 'YT', 'text' => 'Mayotte');
		$country[] = array('value' => 'MX', 'text' => 'Mexico');
		$country[] = array('value' => 'FM', 'text' => 'Micronesia, Federated States Of');
		$country[] = array('value' => 'MD', 'text' => 'Moldova');
		$country[] = array('value' => 'MC', 'text' => 'Monaco');
		$country[] = array('value' => 'MN', 'text' => 'Mongolia');
		$country[] = array('value' => 'ME', 'text' => 'Montenegro');
		$country[] = array('value' => 'MS', 'text' => 'Montserrat');
		$country[] = array('value' => 'MA', 'text' => 'Morocco');
		$country[] = array('value' => 'MZ', 'text' => 'Mozambique');
		$country[] = array('value' => 'MM', 'text' => 'Myanmar');
		$country[] = array('value' => 'NA', 'text' => 'Namibia');
		$country[] = array('value' => 'NR', 'text' => 'Nauru');
		$country[] = array('value' => 'NP', 'text' => 'Nepal');
		$country[] = array('value' => 'NL', 'text' => 'Netherlands');
		$country[] = array('value' => 'AN', 'text' => 'Netherlands Antilles');
		$country[] = array('value' => 'NC', 'text' => 'New Caledonia');
		$country[] = array('value' => 'NZ', 'text' => 'New Zealand');
		$country[] = array('value' => 'NI', 'text' => 'Nicaragua');
		$country[] = array('value' => 'NE', 'text' => 'Niger');
		$country[] = array('value' => 'NG', 'text' => 'Nigeria');
		$country[] = array('value' => 'NU', 'text' => 'Niue');
		$country[] = array('value' => 'NF', 'text' => 'Norfolk Island');
		$country[] = array('value' => 'MP', 'text' => 'Northern Mariana Islands');
		$country[] = array('value' => 'NO', 'text' => 'Norway');
		$country[] = array('value' => 'OM', 'text' => 'Oman');
		$country[] = array('value' => 'PK', 'text' => 'Pakistan');
		$country[] = array('value' => 'PW', 'text' => 'Palau');
		$country[] = array('value' => 'PS', 'text' => 'Palestinian Territory, Occupied');
		$country[] = array('value' => 'PA', 'text' => 'Panama');
		$country[] = array('value' => 'PG', 'text' => 'Papua New Guinea');
		$country[] = array('value' => 'PY', 'text' => 'Paraguay');
		$country[] = array('value' => 'PE', 'text' => 'Peru');
		$country[] = array('value' => 'PH', 'text' => 'Philippines');
		$country[] = array('value' => 'PN', 'text' => 'Pitcairn');
		$country[] = array('value' => 'PL', 'text' => 'Poland');
		$country[] = array('value' => 'PT', 'text' => 'Portugal');
		$country[] = array('value' => 'PR', 'text' => 'Puerto Rico');
		$country[] = array('value' => 'QA', 'text' => 'Qatar');
		$country[] = array('value' => 'RE', 'text' => 'Reunion');
		$country[] = array('value' => 'RO', 'text' => 'Romania');
		$country[] = array('value' => 'RU', 'text' => 'Russian Federation');
		$country[] = array('value' => 'RW', 'text' => 'Rwanda');
		$country[] = array('value' => 'BL', 'text' => 'Saint Barthelemy');
		$country[] = array('value' => 'SH', 'text' => 'Saint Helena');
		$country[] = array('value' => 'KN', 'text' => 'Saint Kitts And Nevis');
		$country[] = array('value' => 'LC', 'text' => 'Saint Lucia');
		$country[] = array('value' => 'MF', 'text' => 'Saint Martin');
		$country[] = array('value' => 'PM', 'text' => 'Saint Pierre And Miquelon');
		$country[] = array('value' => 'VC', 'text' => 'Saint Vincent And Grenadines');
		$country[] = array('value' => 'WS', 'text' => 'Samoa');
		$country[] = array('value' => 'SM', 'text' => 'San Marino');
		$country[] = array('value' => 'ST', 'text' => 'Sao Tome And Principe');
		$country[] = array('value' => 'SA', 'text' => 'Saudi Arabia');
		$country[] = array('value' => 'SN', 'text' => 'Senegal');
		$country[] = array('value' => 'RS', 'text' => 'Serbia');
		$country[] = array('value' => 'SC', 'text' => 'Seychelles');
		$country[] = array('value' => 'SL', 'text' => 'Sierra Leone');
		$country[] = array('value' => 'SG', 'text' => 'Singapore');
		$country[] = array('value' => 'SK', 'text' => 'Slovakia');
		$country[] = array('value' => 'SI', 'text' => 'Slovenia');
		$country[] = array('value' => 'SB', 'text' => 'Solomon Islands');
		$country[] = array('value' => 'SO', 'text' => 'Somalia');
		$country[] = array('value' => 'ZA', 'text' => 'South Africa');
		$country[] = array('value' => 'GS', 'text' => 'South Georgia And Sandwich Isl.');
		$country[] = array('value' => 'ES', 'text' => 'Spain');
		$country[] = array('value' => 'LK', 'text' => 'Sri Lanka');
		$country[] = array('value' => 'SD', 'text' => 'Sudan');
		$country[] = array('value' => 'SR', 'text' => 'Suriname');
		$country[] = array('value' => 'SJ', 'text' => 'Svalbard And Jan Mayen');
		$country[] = array('value' => 'SZ', 'text' => 'Swaziland');
		$country[] = array('value' => 'SE', 'text' => 'Sweden');
		$country[] = array('value' => 'CH', 'text' => 'Switzerland');
		$country[] = array('value' => 'SY', 'text' => 'Syrian Arab Republic');
		$country[] = array('value' => 'TW', 'text' => 'Taiwan');
		$country[] = array('value' => 'TJ', 'text' => 'Tajikistan');
		$country[] = array('value' => 'TZ', 'text' => 'Tanzania');
		$country[] = array('value' => 'TH', 'text' => 'Thailand');
		$country[] = array('value' => 'TL', 'text' => 'Timor-Leste');
		$country[] = array('value' => 'TG', 'text' => 'Togo');
		$country[] = array('value' => 'TK', 'text' => 'Tokelau');
		$country[] = array('value' => 'TO', 'text' => 'Tonga');
		$country[] = array('value' => 'TT', 'text' => 'Trinidad And Tobago');
		$country[] = array('value' => 'TN', 'text' => 'Tunisia');
		$country[] = array('value' => 'TR', 'text' => 'Turkey');
		$country[] = array('value' => 'TM', 'text' => 'Turkmenistan');
		$country[] = array('value' => 'TC', 'text' => 'Turks And Caicos Islands');
		$country[] = array('value' => 'TV', 'text' => 'Tuvalu');
		$country[] = array('value' => 'UG', 'text' => 'Uganda');
		$country[] = array('value' => 'UA', 'text' => 'Ukraine');
		$country[] = array('value' => 'AE', 'text' => 'United Arab Emirates');
		$country[] = array('value' => 'GB', 'text' => 'United Kingdom');
		$country[] = array('value' => 'US', 'text' => 'United States');
		$country[] = array('value' => 'UM', 'text' => 'United States Outlying Islands');
		$country[] = array('value' => 'UY', 'text' => 'Uruguay');
		$country[] = array('value' => 'UZ', 'text' => 'Uzbekistan');
		$country[] = array('value' => 'VU', 'text' => 'Vanuatu');
		$country[] = array('value' => 'VE', 'text' => 'Venezuela');
		$country[] = array('value' => 'VN', 'text' => 'Viet Nam');
		$country[] = array('value' => 'VG', 'text' => 'Virgin Islands, British');
		$country[] = array('value' => 'VI', 'text' => 'Virgin Islands, U.S.');
		$country[] = array('value' => 'WF', 'text' => 'Wallis And Futuna');
		$country[] = array('value' => 'EH', 'text' => 'Western Sahara');
		$country[] = array('value' => 'YE', 'text' => 'Yemen');
		$country[] = array('value' => 'ZM', 'text' => 'Zambia');
		$country[] = array('value' => 'ZW', 'text' => 'Zimbabwe');
		
		return $country;
	}
}