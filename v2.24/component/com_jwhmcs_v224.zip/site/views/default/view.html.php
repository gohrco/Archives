<?php
/**
 * Default View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: view.html.php 131 2010-12-22 14:21:11Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsViewDefault
 * Extends:		JView
 * Purpose:		Handles the default view
 * As of:		version 1.5.0
\* ------------------------------------------------------------ */
class JwhmcsViewDefault extends JView
{
	/* ------------------------------------------------------------ *\
	 * Handler:		display
	 * Purpose:		Needed for building the class
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	function display($tpl = null)
	{
		// Load data for register layout
		global $mainframe;
		
		$tplparams	=	$mainframe->getParams();
		$params		= &	JwhmcsParams::getInstance();
		$uri		= &	JURI::getInstance();
		$document	= &	JFactory::getDocument();
		$layout		= &	JRequest::getVar( 'layout' );
		
		$whmcsurl = $this->_buildWhmcsUrl();
		
		switch( $layout ):
		case 'default':
		default:
			if ($params->get( 'RenderJqueryenable' ))
			{
				JHTML::script('jquery.js', $whmcsurl.'includes/jscript/', true);
				JHTML::script('noconflict.js', 'components/com_jwhmcs/js/', true);
			}
			
			$base = & $document->getBase();
			if(empty($base))
			{
				$document->setBase( $uri->toString( array('scheme', 'host', 'path') ) );
			}
			
			break;
		endswitch;
		
		$this->assignRef('params',	$tplparams);
		
		parent::display($tpl);
		
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Handler:		_buildWhmcsUrl
	 * Purpose:		Builds the WHMCS Url
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	private function _buildWhmcsUrl()
	{
		global $mainframe;
		
		$viewparams	= &	$mainframe->getParams();
		$params		= & JwhmcsParams::getInstance();
		$uri		= & JURI::getInstance();
		
		$urlparse	=   parse_url( $params->get( 'ApiUrl' ) );
		
		if (! $urlparse['path'] ) $urlparse['path'] = '/';
		if ( $urlparse['path'] && ( ( strlen( $urlparse['path'] ) > 1 ) || empty( $urlparse['path'] ) ) ) $urlparse['path'] .= '/';
		
		$whmcsurl	= $uri->getScheme() . '://' . ( isset( $urlparse['host'] ) ? $urlparse['host'] : '' ) . $urlparse['path'];
		
		$viewparams->set( 'scheme', 	$uri->getScheme() );
		$viewparams->set( 'whmcsurl',	$whmcsurl );
		
		return $whmcsurl;
	}
}