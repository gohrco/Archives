<?php
/**
 * Kayako LoginShare for J!WHMCS Integrator
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: jwhmcs_integrator.login.php 131 2010-12-22 14:21:11Z steven_gohigher $
 * @since      2.1.2
 */

if (!defined("INSWIFT")) {
	trigger_error("Unable to process " . htmlentities($_SERVER['PHP_SELF']), E_USER_ERROR);
}

/**
* Initialization function. You can connect to your database etc over here.
*/
function loginShareInit()
{
	global $loginshare;

	$loginshare->moduleloaded = true;
}

/**
* Authorize a user based on email and password
*/
function loginShareAuthorize($username, $password)
{
	global $dbCore, $_SWIFT, $loginshare, $settings;

	$_loginshare = $settings->getSection("loginshare");
	$dbLoginShare = new dbCore($_loginshare["whmcshostname"], $_loginshare["whmcsdbuser"], $_loginshare["whmcsdbpass"], $_loginshare["whmcsdbname"], "mysql", false);

	$_user = $dbLoginShare->queryFetch("SELECT * FROM `". $_loginshare["whmcsdbprefix"] ."clients` WHERE `email` = '". $dbCore->escape($username) ."';");
	if (empty($_user["id"]))
	{
		#return false;
	}
	
	// Use WHMCS MD5 Algorithm 
	$tablesalt = substr($_user["password"], 33, 5);
	$userpassword = md5($tablesalt . $password) . ':' . $tablesalt;
	
	$regpassword = substr(buildHash(),0,8);

	if ($_user["password"] == $userpassword && !empty($_user["password"]))
	{
		// We have a match, Seems like a valid user.. now see if he is registered..
		$userid = getLoginShareUser(LOGINAPI_WHMCS, $_user["id"]);
		if (!$userid)
		{
			// Not registered, Register him
			$userid = insertUser(true, $_user["email"], $regpassword, $_SWIFT["tgroup"]["regusergroupid"], LOGINAPI_WHMCS, $_user["id"], $_user["firstname"]." ".$_user["lastname"], $_SWIFT["tgroup"]["languageid"], 0, false, 1, true);
		}

		if (!$userid)
		{
			// ======= GET THE USER WITH THE EMAIL AND TAG HIM UNDER VB =======
			$_swiftuser = $dbCore->queryFetch("SELECT `userid` FROM `". TABLE_PREFIX ."useremails` WHERE `email` = '". $dbCore->escape($_user["email"]) ."' LIMIT 1;");
			if (!empty($_swiftuser["userid"]))
			{
				$dbCore->query("UPDATE `". TABLE_PREFIX ."users` SET `loginapi_moduleid` = '". LOGINAPI_WHMCS ."', `loginapi_userid` = '". intval($_user["id"]) ."' WHERE `userid` = '". intval($_swiftuser["userid"]) ."';");

				$userid = $_swiftuser["userid"];
			} else {
				#return false;
			}
		}

		$_swiftuser = $loginshare->loadSWIFTUser($userid);
		if (!$_swiftuser)
		{
			#return false;
		}

		$_SWIFT["user"] = $_swiftuser;

		return $_swiftuser["userid"];
	}
    // If we cant find a user in WHMCS database, look for a SupportSuite user;
    // Get the user id associated with this email
    // Contributed by CallanM in Kayako Forums
    $_email = $dbCore->queryFetch("SELECT `userid` FROM `". TABLE_PREFIX ."useremails` WHERE `email` = '". $dbCore->escape($username) ."';");
    if (empty($_email["userid"]))
    {
        return false;
    }

    $_user = $dbCore->queryFetch("SELECT * FROM `". TABLE_PREFIX ."users` WHERE `userid` = '". intval($_email["userid"]) ."';");

    $loginmod = false;

    $password_chk = $password;
    $password_chk_md5 = md5($password);
    

    if (($_user["userpassword"] == $password_chk || $_user["userpassword"] == $password_chk_md5) && $_user["enabled"] == 1 && $loginmod = true)
    {
        // Authenticated
        $_SWIFT["user"] = $_user;

        return $_user["userid"];
    } else {
        unset($_SWIFT["user"]);

        return false;
    }  
	#return false;
}

/**
* Return the Unique User ID of the current user
*/
function loginShareUserID()
{
	global $_SWIFT;

	if (empty($_SWIFT["user"]["userid"]))
	{
		return false;
	} else {
		return $_SWIFT["user"]["userid"];
	}
}

/**
* Logout the current user
*/
function loginShareLogout()
{
	global $session, $_SWIFT;

	$session->updateSession($_SWIFT["session"]["sessionid"], 0);

	return true;
}

/**
* Load the user credentials into current workspace. The following variables should be declared for proper working:
* userid - User id that is set in the "users" table
* fullname
* email - Array
* password (MD5 Hashed)
* usergroupid - If this is not set, then it will use the default registered user group for this template group
*/
function loginShareLoadUser()
{
	global $dbCore, $_SWIFT, $loginshare;

	if (empty($_SWIFT["session"]["typeid"]))
	{
		$_SWIFT["user"]["loggedin"] = false;
		return false;
	}

	$_user = $loginshare->loadSWIFTUser($_SWIFT["session"]["typeid"]);
	if (!$_user)
	{
		$_SWIFT["user"]["loggedin"] = false;

		return false;
	}

	$_SWIFT["user"] = $_user;

	return true;
}

/**
* Renders the Login Share Form
*/
function renderLoginShareForm()
{
	global $_SWIFT;

	$forms = array();

	$forms[0]["title"] = $_SWIFT["language"]["hostname"];
	$forms[0]["name"] = "whmcshostname";
	$forms[1]["title"] = $_SWIFT["language"]["dbname"];
	$forms[1]["name"] = "whmcsdbname";
	$forms[2]["title"] = $_SWIFT["language"]["dbuser"];
	$forms[2]["name"] = "whmcsdbuser";
	$forms[3]["title"] = $_SWIFT["language"]["dbpass"];
	$forms[3]["name"] = "whmcsdbpass";	
	$forms[4]["title"] = "DB Table Prefix";
	$forms[4]["name"] = "whmcsdbprefix";
	$forms[5]["title"] = "WHMCS Url";
	$forms[5]["name"] = "whmcsurl";
	$forms[6]["title"] = "Secret Word";
	$forms[6]["name"] = "jwhmcssecret";
	$forms[7]["title"] = "Joomfish - iso-codes";
	$forms[7]["name"] = "whmcslang";
	
	return $forms;

}
?>