<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_( 'behavior.mootools' );

$data = $this->data;
$j32jwhmcs = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-jwhmcs.png';
$j32helppage = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-helppage.png';
?>
<style type="text/css">
.icon-32-jwhmcs {	background-image: url('<?php echo $j32jwhmcs; ?>'); }
.icon-32-helppage { background-image: url('<?php echo $j32helppage; ?>'); }
#reqFtp				{ visibility: collapse; }
.text_area			{ font-size: 14px; color: #000; border-color: #aaa; padding: 3px; font-family: Verdana; }
#adminInput .button	{ background-color:#EEEEEE; border-color:#333333; cursor:pointer; font-family:verdana; font-size:14px; padding:3px; min-width: 64px; visibility: visible; }
</style>
<form action="index.php" method="post" name="adminForm" id="adminForm">
<div id="ajaxWrap">
	<div id="ajaxStatus" class="ajaxInitial"></div>
	<div id="ajaxMessage" class="ajaxMessageInitial">Initializing</div>
	<div id="ajaxLog"></div>
</div>

<div id="adminInput">
	<table class="admintable visDisplay" width="400px" border="0" id="textWelcome">
		<tr>
			<td class="paramlabel">
				<div class="installHdr">
					Automatic Installation
				</div>
				<div class="installTxt">
					<p>Please wait while the automatic installer initializes and begins processing the rest of the files.</p>
					<p>As the installer requires information you will be asked for it to complete the installation.  Please have ready the following:</p>
					<ul>
						<li>The Username and Password you would like to use for the WHMCS API Interface (can be your WHMCS admin account, and it can be changed later)</li>
						<li>The license you received when you purchased your license for J!WHMCS Integrator</li>
						<li>The path to your install of WHMCS</li>
					</ul>
				</div>
			</td>
		</tr>
	</table>
	<table class="admintable visHidden" width="400px" border="0" id="textApivalid">
		<tr>
			<td class="paramlabel">
				<div class="installHdr">
					Continuing Installation
				</div>
				<div class="installTxt">
					<p>Your API settings have been validate and the installer is continuing.</p>
					<p>If you change the password in WHMCS for the administrative account that you have set as the API user here, be sure to update the password to ensure your users are able to login properly!</p>
				</div>
			</td>
		</tr>
	</table>
	<table class="admintable visHidden" width="400px" border="0" id="textFileinstall">
		<tr>
			<td class="paramlabel">
				<div class="installHdr">
					Continuing Installation
				</div>
				<div class="installTxt">
					<p>The automatic installer is proceeding to install the files in your WHMCS site.  Your default and portal templates will be copied and used for custom templates and modifications.</p>
					<p>Your WHMCS database is also being updated to reflect the use of one of the custom template styles provided with the J!WHMCS Integrator.</p>
				</div>
			</td>
		</tr>
	</table>
	<table class="admintable visHidden" width="400px" border="0" id="textLicensevalid">
		<tr>
			<td class="paramlabel">
				<div class="installHdr">
					Continuing Installation
				</div>
				<div class="installTxt">
					<p>Your product license is valid and the installer is continuing.</p>
					<p>Remember, if you purchased a leased license, you can always upgrade your license to an owned license without reinstalling your Integrator!</p>
				</div>
			</td>
		</tr>
	</table>
	<table class="admintable visHidden" width="400px" border="0" id="textComplete">
		<tr>
			<td class="paramlabel">
				<div class="installHdr">
					Installation Completing
				</div>
				<div class="installTxt">
					<p>Please wait while the installer completes.</p>
				</div>
			</td>
		</tr>
	</table>
	<table class="admintable" width="400px" border="0" id="reqWhmcsPath">
		<tr>
			<td class="paramlabel">
				<div class="paramname">
					WHMCS Path
				</div>
				<div class="paramdesc">
				<p>Enter the path to your install of WHMCS.  Your WHMCS must be located on the same server and be accessible to Joomla in order for this automatic installation to proceed.</p>
				<p><span style="font-weight: bold; ">If your WHMCS is not accessible directly from Joomla, click the box below to enter FTP credentials to complete the installation.</p> 
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="text" name="whmcspath" value="<?php echo $data->path; ?>" size="40" style="font-size: 14px; " id="whmcspath" />
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input type="button" class="button" name="enterFtp" id="enterFtp" onClick="$('reqWhmcsPath').setStyle('visibility', 'collapse'); $('reqFtp').setStyle('visibility', 'visible');" value="Use FTP" onmouseover="this.setStyle('background-color', '#eeffee') " onmouseout="this.setStyle('background-color', '#eeeeee') " />
				<input type="button" class="button" name="PathVerify" id="pathVerify" onClick="verifyPath($('step').getProperty('value'))" value="Verify Path" onmouseover="this.setStyle('background-color', '#eeffee') " onmouseout="this.setStyle('background-color', '#eeeeee') " />
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input type="checkbox" class="text_area required" name="bypasspath" onClick="if (this.checked) { var r = confirm('Are you sure you want to bypass this portion of the install?'); if (r == true) { runInstall(998); $('reqWhmcsPath').setStyle('visibility', 'collapse'); } else { this.checked = false; } } " /> Path is not accessible to Joomla
			</td>
		</tr>
	</table>
	<table class="admintable" width="400px" border="0" id="reqFtp">
		<tr>
			<td class="paramlabel">
				<div class="paramname">
					FTP Credentials
				</div>
				<div class="paramdesc">
				<p>Enter the FTP credentials to access your WHMCS site.  Once you have entered them, click "Verify" to validate your credentials and ensure the installer can reach them.</p>
				<p>Do not put "ftp://" in front of the hostname, simply enter the hostname without the scheme (ie the domain name such as ftp.yourdomain.com or an IP Address such as 192.168.1.1)</p>
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input type="text" name="FtpHostname" id="FtpHostname" value="<?php echo $data->ftphostname; ?>" size="40" class="text_area" onFocus="if(this.value == 'hostname') { this.value=''; } " onBlur="if(this.value == '') { this.value='hostname' } " />&nbsp;:&nbsp;<input type="text" name="FtpPort" id="FtpPort" value="<?php echo $data->ftpport; ?>" size="4" onBlur="if(this.value == '') { this.value='21' } " class="text_area" />
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input type="text" name="FtpUsername" id="FtpUsername" value="<?php echo $data->ftpusername; ?>" size="22" class="text_area" onFocus="if(this.value == 'username') { this.value=''; } " onBlur="if(this.value == '') { this.value='username' } " /> / <input type="password" name="FtpPassword" id="FtpPassword" value="<?php echo $data->ftppassword; ?>" size="22" onFocus="if(this.value == 'password') { this.value=''; } " onBlur="if(this.value == '') { this.value='password' } " class="text_area" />
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input type="button" class="button" name="enterPath" id="enterPath" onClick="$('reqWhmcsPath').setStyle('visibility', 'visible'); $('reqFtp').setStyle('visibility', 'collapse');" value="Use Path" onmouseover="this.setStyle('background-color', '#eeffee') " onmouseout="this.setStyle('background-color', '#eeeeee') " />
				<input type="button" class="button" name="FtpVerify" id="ftpVerify" onClick="verifyFtp($('step').getProperty('value'))" value="Verify FTP" onmouseover="this.setStyle('background-color', '#eeffee') " onmouseout="this.setStyle('background-color', '#eeeeee') " />
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input type="checkbox" class="text_area required" name="bypassftp" onClick="if (this.checked) { var r = confirm('Are you sure you want to bypass this portion of the install?'); if (r == true) { runInstall(998); $('reqWhmcsPath').setStyle('visibility', 'collapse'); } else { this.checked = false; } } " /> I don't have FTP credentials to my WHMCS site
			</td>
		</tr>
	</table>
	<table class="admintable" width="400px" border="0" id="reqLicense">
		<tr>
			<td class="paramlabel">
				<div class="paramname">
					J!WHMCS Integrator License
				</div>
				<div class="paramdesc">
				<p>Enter the product license you received when you purchased J!WHMCS Integrator.</p>
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="text" name="licensekey" value="<?php echo $data->license; ?>" size="40" style="font-size: 14px; " onChange="ajaxCheckLicense($('step').value);" id="licensekey" />
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input type="checkbox" class="text_area required" name="bypasslicense" onClick="if (this.checked) { var r = confirm('Are you sure you want to bypass this portion of the install?'); if (r == true) { runInstall(998); $('reqLicense').setStyle('visibility', 'collapse'); } else { this.checked = false; } } " /> Skip license check
			</td>
		</tr>
	</table>
	<table class="admintable" width="400px" border="0" id="reqApi">
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				WHMCS Url
				</div>
				<div class="paramdesc">
				Enter the URL to your WHMCS Installation
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="text" name="whmcsurl" value="<?php echo $data->whmcsurl; ?>" size="40" style="font-size: 14px; " id="whmcsurl" onChange="ajaxCheckAPI($('step').value);" />
			</td>
		</tr>
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				API Username
				</div>
				<div class="paramdesc">
				Enter the API Username for WHMCS (configured in WHMCS).
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="text" name="jwhmcsadminus" value="<?php echo $data->jwhmcsadminus; ?>" size="40" style="font-size: 14px; " id="jwhmcsadminus" onChange="ajaxCheckAPI($('step').value);" />
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				API Password
				</div>
				<div class="paramdesc">
				Enter the API Password for WHMCS (configured in WHMCS).
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="password" name="jwhmcsadminpw" value="<?php echo $data->jwhmcsadminpw; ?>" size="40" style="font-size: 14px; " id="jwhmcsadminpw" onChange="ajaxCheckAPI($('step').value);" />
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				API Access Key (optional)
				</div>
				<div class="paramdesc">
				If you have installed iWHMCS or another module from WHMCS that requires use of an API Access Key, please enter it below.  Your access key would have been configured in the WHMCS configuration.php file.
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area" type="text" name="accesskey" value="<?php echo $data->accesskey; ?>" size="40" style="font-size: 14px; " id="accesskey" onChange="ajaxCheckAPI($('step').value);" />
			</td>
		</tr>
	</table>
</div>
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="starttime" value="<?php echo $data->startdate; ?>" />
<input type="hidden" name="task" value="complete" />
<input type="hidden" name="controller" value="install" />
<input type="hidden" name="thisUrl" id="thisUrl" value="<?php echo $data->thisUrl; ?>" />
<input type="hidden" name="step" id="step" value="1" />
<textarea name="installLog" id="installLog" cols="40" rows="10" style="visibility: hidden; "></textarea>
</form>

<script language="javascript">
window.addEvent( 'domready', function() {
	runInstall($('step').getProperty('value'));
} );
</script>