<?php
/**
 * J!WHMCS Integrator - User Plugin
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: jwhmcs_user.php 187 2010-03-22 20:23:43Z Steven $
 * @since		1.5.0
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.plugin.plugin');
jimport( 'joomla.environment.uri' );

include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jwhmcs'.DS.'classes'.DS.'class.curl.php');

/**
 * User Plugin
 *
 * @package		J!WHMCS Integrator
 * @since 		1.5.0
 */
class plgUserJwhmcs_user extends JPlugin {

	/* ------------------------------------------------------------ *\
	 * Function:	plgUserJwhmcs_user
	 * Purpose:		This is the constructor task
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	function plgUserJwhmcs_user(& $subject, $config)
	{
		parent::__construct($subject, $config);
		
		// Retrieve the component and plugin parameters and set them
		$component	  = JComponentHelper::getComponent( 'com_jwhmcs' );
  		$this->params = new JParameter( $component->params );
  		$this->_parseUrls();
  		$this->_setComid();
	}


	/* ------------------------------------------------------------ *\
	 * Function:	onAfterStoreUser
	 * Purpose:		Task after Joomla user is stored by Joomla
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.0.2 (Feb 2010)
	 *  	* Corrected company name not being passed to addclient
	 *  1.5.3 (Oct 2009)
	 *  	+ Check for password being reset by user added
	 * 	1.5.1 (Sep 2009)
	 * 		+ encrypt passwords for user edits (WHMCS < 4.1 bug)
	\* ------------------------------------------------------------ */
	function onAfterStoreUser($user, $isnew, $succes, $msg)
	{
		global $mainframe;
		
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		
		// Check if the user is new - if so then addclient function
		if ($isnew):
			$action	= 'addclient';
			if (JRequest::getVar( 'usedata' )):
				$company = (JRequest::getVar('company') ? JRequest::getVar('company') : JRequest::getVar('companyname'));
				$fields['firstname']	= JRequest::getVar( 'firstname' );
				$fields['lastname']		= JRequest::getVar( 'lastname' );
				$fields['companyname']	= $company;
				$fields['address1']		= JRequest::getVar( 'address1' );
				$fields['address2']		= JRequest::getVar( 'address2' );
				$fields['city']			= JRequest::getVar( 'city' );
				$fields['state']		= JRequest::getVar( 'state' );
				$fields['postcode']		= JRequest::getVar( 'postcode' );
				$fields['country']		= JRequest::getVar( 'country' );
				$fields['phonenumber']	= JRequest::getVar( 'phonenumber' );
				$fields['currency']		= '1';
			else:
				$name = explode(' ', $user['name']);
				if (count($name)< 2) $name[1] = $name[0]; 
				$fields['firstname'] = $name[0];
				$fields['lastname']  = $name[1];
				$fields['address1']		= 'New Client';
				$fields['city']			= 'New City';
				$fields['state']		= 'New State';
				$fields['postcode']		= '12345';
				$fields['country']		= 'US';
				$fields['phonenumber']	= '1234567890';
				$fields['currency']		= '1';
			endif;
			$fields['email']		= $user['email'];
			$fields['password2']	= $_POST['password'];
		else:
			
			// Retrieve existing whmcsid from xref db based on user_id
			$query = 'SELECT `xref_b` as `clientid` FROM #__jwhmcs_xref '
						.'WHERE xref_a='.$user['id'].' AND xref_type=1';
			$db->setQuery($query);
			$result = $db->loadAssoc();
			
			if (!$result)
				return;
			
			// v 1.5.3 - If password reset requested by user, use password1
			$pass1 = $_POST['password1']?$_POST['password1']:$_POST['password'];
			
			// v 1.5.1 - To save the new password, we have to encrypt it in the DB for WHMCS
			$pass2	= $this->_changeWhmcspw($result['clientid'], $pass1);
			
			// Create the fields array for retrieving existing WHMCS user
			$action					= 'updateclient';
			$fields['clientid']		= $result['clientid'];
			$fields['email']		= $user['email'];
			$fields['password2']	= $pass2;
			$fields['jwhmcs']		= 1;
			
			if ($mainframe->isAdmin())
				$fields['status']	= (JRequest::getVar( 'block' )==1?'Inactive':'Active');
		endif;
		
		// Pass function and parameters to cURL getting back the whmcs_id
		$jcurl->setAction($action, $fields);
		$whmcs	= $jcurl->loadResult();
		
		if ($isnew):
			// Store this new id w/ the user id in the xref db
			$query = 'INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) '
						.'VALUES ('.$user['id'].', 1, '.$whmcs['clientid'].')';
			$db->setQuery($query);
			$db->query();
		else:
			if ($mainframe->isAdmin())
				return;		// Don't redirect to WHMCS if Administrator
			
			// Send to _storeSess and get stored token back
			$token = $this->_storeSess($whmcs['clientid'], $user['email'], $user['password'], null);
			
			// Create URL for redirecting to WHMCS for loggin in
			$url = 'http'.($this->params->get( 'jwhmcsssl' )?'s':'').'://'.$this->params->get( 'jwhmcsurl' ).'/jwhmcs.php?task=login&a='.$token.'&b='.$this->params->get( 'comid' );
			$mainframe->redirect($url);
		endif;
	}

	
	/* ------------------------------------------------------------ *\
	 * Function:	onBeforeDeleteUser
	 * Purpose:		Task run before deleting user in Joomla
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	function onBeforeDeleteUser($user)
	{
		global $mainframe;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	onAfterDeleteUser
	 * Purpose:		Task run after deleting a user in Joomla
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	function onAfterDeleteUser($user, $succes, $msg)
	{
		global $mainframe;
	}

	
	/* ------------------------------------------------------------ *\
	 * Function:	onLoginUser
	 * Purpose:		Task run after user authenticated
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	function onLoginUser($user, &$options)
	{
		// 0:  Initialize variables
		global $mainframe;
		$db =& JFactory::getDBO();
		
		// $options['return'] contains the unencoded url to return with
		
		if ($mainframe->isAdmin())
			return; // Dont run in admin
		
		// 1:  Check to make sure user can login to WHMCS
		$user = $this->_checkLogin($user);
		if (!$user) return;
		
		// 2:  Store variables to database and get token back from function
		$juri = & JURI::getInstance();
		
		// TODO:  Move email / password to param field and eliminate fields
		$param['email']	= $user['email'];
		$param['password']	= $user['password'];
		if ($goto = JRequest::getVar( 'goto' )) $param['goto'] = $goto;
		
		$param['return'] = $this->_getReturn($options);
		
		$token = $this->_storeSess(1, $user['email'], $user['password'], $param);
		
		// 3:  Create URL for redirecting to WHMCS for loggin in
		$url = 'http'.($this->params->get( 'jwhmcsssl' )?'s':'').'://'.$this->params->get( 'jwhmcsurl' ).'/jwhmcs.php?task=login&a='.$token.'&b='.$this->params->get( 'comid' );
		$mainframe->redirect($url);
	}

	
	/* ------------------------------------------------------------ *\
	 * Function:	onLogoutUser
	 * Purpose:		Task run after user logs out
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	function onLogoutUser($user)
	{
		global $mainframe;
		
		if ($mainframe->isAdmin())
			return; // Dont run in admin
		
		// Create URL for redirecting to WHMCS for loggin out
		$url = 'http'.($this->params->get( 'jwhmcsssl' )?'s':'').'://'.$this->params->get( 'jwhmcsurl' ).'/logout.php?goto=jwhmcs';
		$mainframe->redirect($url);
	}
	
		
	/* ------------------------------------------------------------ *\
	 * Function:	_storeSess (private)
	 * Purpose:		Stores values to database and returns token
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	private function _storeSess($id, $email, $pw, $values = null)
	{
		$db =& JFactory::getDBO();
		
		// Create a new token
		$token = JUtility::getToken(true);
		
		if (!is_null($values))
		{
			foreach ($values as $k => $v)
			{
				$val[] = $k.'='.$v;
			}
			$value = implode("\n", $val);
		}
		else
		{
			$value = null;
		}
		
		// Store UID, UEM and UPW in database for retrieval
		$query = 'INSERT INTO `#__jwhmcs_sess` (`token`, `value`, `uid`, `uem`, `upw`) '
					.'VALUES ("'.$token.'", "'.$value.'", '.$id.', "'.$email.'", "'.$pw.'")';
		$db->setQuery($query);
		$db->query();
		
		return $token;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_setComid (private)
	 * Purpose:		Pulls the component ID to pass along to WHMCS
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	private function _setComid()
	{
		$db =& JFactory::getDBO();
		
		// Find the installed instance of com_jwhmcs and pull the id for storage
		$query	= 'SELECT `id` FROM #__components WHERE `option`="com_jwhmcs"';
		$db->setQuery($query);
		$cjw	= $db->loadAssoc();
		
		$this->params->set( 'comid', $cjw['id'] );
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkLogin (private)
	 * Purpose:		Checks the xref_type for the user that is logging
	 * 				in to see if additional actions need to be taken.
	 * 				1 = all is matched up ok - proceed
	 * 				2 = change password in WHMCS first, then proceed
	 * 				3 = redirect to component asking for new password
	 * 				4 = user belongs to a group, pull that grp info
	 * 
	 * As of:		version 1.5.0
	 * Revisions:
	 *   1) Added group ability (v 1.5.1)
	\* ------------------------------------------------------------ */
	private function _checkLogin(&$user)
	{
		// 0:  Initialize variables
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		
		// 1:  Set query to pull xref table to check type
		$query = 'SELECT `xref_a` as `joomlaid`, `xref_type` as `type`, `xref_b` as `clientid` FROM #__jwhmcs_xref AS x INNER JOIN #__users AS a ON x.xref_a = a.id '
					.'WHERE a.username ="'.$user['username'].'" AND (xref_type=1 OR xref_type=2 OR xref_type=3 OR xref_type=4)';
		$db->setQuery($query);
		$result = $db->loadAssoc();
		
		// 2:  Test for types, failing if none found
		if (!$result)	// User isn't matched to anyone in WHMCS don't bother logging in
			return false;
		
		switch ($result['type']):
		case 1:			// Everything is ok - user already matched up
			$return = $user;
			break;
		case 2:			// User was matched up by Admin, change pw in WHMCS
		case 3:			// User account added by admin in Joomla, change pw in WHMCS
			// We only change the password in WHMCS after the user signs in with 
			//   the new credentials to ensure they don't have trouble and to
			//   ensure they are receiving email at the same address.
				
			// Create the fields array for retrieving existing WHMCS user
			$fields['clientid']		= $result['clientid'];
			$fields['password2']	= $this->_changeWhmcspw($result['clientid'], $user['password']);
			
			// Pass function and parameters to cURL getting back the whmcs_id
			$jcurl->setAction('updateclient', $fields);
			$whmcs	= $jcurl->loadResult();
		 	
			// Test to see if successful, if so update xref table
			if ($whmcs['result']=='success'):
				$query	= 'UPDATE `#__jwhmcs_xref` SET `xref_type`="1" WHERE `xref_a`='.$result['joomlaid'].' AND `xref_b`='.$result['clientid'];
				$db->setQuery($query);
				if ($db->query())
					$return = $user;
				else
					$return = false;
			else:
				$return = false;
			endif;
			break;
		case 4:			// User belongs to a group
			$query	= 'SELECT u.`password` as `passwd`, u.`email` as `email` '
						.' FROM #__jwhmcs_group as u '
						.' WHERE u.id = '.$result['clientid'];
			$db->setQuery($query);
			
			if ($result = $db->loadAssoc()):
				$user['email']		= $result['email'];
				$user['username']	= $result['username'];
				$user['password']	= $result['passwd'];
				$return = $user;
			else:
				$return = false;
			endif;
			break;
		endswitch;
		
		// 3:  Return user array or false
		if ($return):
			return $user;
		else:
			return $return;
		endif;
	}

	
	/* ------------------------------------------------------------ *\
	 * Function:	_changeWhmcspw (private)
	 * Purpose:		Pulls the current WHMCS password, grabbing the salt
	 * 				and md5's the new password, returning it to calling
	 * 				function
	\* ------------------------------------------------------------ */
	private function _changeWhmcspw($clientid, $password)
	{
		$jcurl	= & JwhmcsCurl::getInstance();
		
		// To save the new password, we have to encrypt it in the DB for WHMCS
		// Begn by retrieving current PW hash
		$jcurl->setAction('getadmindetails', array());
		$vers	= $jcurl->loadResult();
		
		// WHMCS is version 4.1 or higher (since it has this action in the API)
		//   Password can be sent clear text and it will be encoded
		if ($vers['result']=='success')
			return $password;
		
		// We've confirmed that WHMCS is not set at version 4.1 or higher
		// Pass function and parameters to cURL getting back result
		$jcurl->setAction('getclientpassword', array('userid' => $clientid));
		$whmcs	= $jcurl->loadResult();
		
		// Explode password hash to get salt and resalt new password and return
		$pwexp	= explode(':', $whmcs['password']);
		return md5($pwexp[1].$password).':'.$pwexp[1];
	}
	
	
	private function _parseUrls()
	{
		// Parameters to parse for URLs
		$purls = array('jwhmcsjurl', 'jwhmcsjrootimgurl', 'jwhmcsurl', 'jwhmcsjin', 'jwhmcsjout');
		
		foreach ($purls as $purl):
			if (!is_null($this->params->get( $purl ))):
				$tmp = parse_url($this->params->get( $purl ));
				// Remove a slash if added to the end of the url
				if ($tmp['path']=='/') unset($tmp['path']);
				// Test for which parameter
				if ($purl == 'jwhmcsjurl') {
					$this->params->set( 'jwhmcsjurl', $tmp['host'].(isset($tmp['path'])?$tmp['path']:'').(isset($tmp['query'])?$tmp['query']:'').(isset($tmp['fragment'])?$tmp['fragment']:''));
					$this->params->set( 'jwhmcsjrooturl', $tmp['host']);
				} else {
					$this->params->set( $purl, $tmp['host'].(isset($tmp['path'])?$tmp['path']:'').(isset($tmp['query'])?$tmp['query']:'').(isset($tmp['fragment'])?$tmp['fragment']:''));
				}
				unset($tmp);
			endif;
		endforeach;
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getReturn (private)
	 * Purpose:		Sends correct return back based on login method
	 * As of:		2.0.2 (Mar 2010)
	 * 
	 * Significant Revisions:
	 * 	2.0.4 (Mar 2010)
	 * 		* Corrected return variable issue
	\* ------------------------------------------------------------ */
	private function _getReturn(&$options)
	{
		$juri = & JURI::getInstance();
		
		if (JRequest::getVar( 'whmcs' )) {
			return JRequest::getVar( 'return' );
		}
		
		// Test for base64 encoding and return decoded return variable
		$tmpurl = ( preg_match('`^([A-Za-z0-9]|\+|\/|\-|\=)+$`', $options['return']) ? base64_decode($options['return']) : $options['return'] );
		
		// Get an instance of the return variable
		$returi = & JURI::getInstance($tmpurl);
		
		// Test to see if there was a scheme - if not, we assume we should use the component landing page
		if (! $returi->getScheme() ) {
		
			// We should use the component landing page here
			$landing = & JURI::getInstance( $this->params->get( 'jwhmcsjin' ) );
			$landing->setScheme( 'http'.( $this->params->get( 'jwhmcsjinssl' ) == 1 ? 's' : '' ) );
		}
		
		return base64_encode( $landing->toString() );
		
	}
}