<?php
/**
 * -------------------------------------------
 * J!Blesta
 * -------------------------------------------
 * @package         J!Blesta
 * @version         1.0.0
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */

/**
 * Define the J!Blesta version here
 */
if (! defined( 'DUN_MOD_JBLESTA' ) ) define( 'DUN_MOD_JBLESTA', "1.0.0" );
if (! defined( 'DUN_MOD_COM_JBLESTA' ) ) define( 'DUN_MOD_COM_JBLESTA', "1.0.0" );

/**
 * JBlesta Core Module
 * @desc		This class is used by Dunamis to initialise J!Blesta for Joomla
 * @package		J!Blesta
 * @subpackage	Joomla
 * @author		Go Higher Information Services, LLC
 * @link		https://www.gohigheris.com
 * @copyright	2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license		GNU General Public License version 2, or later
 */
class Com_jblestaDunModule extends DunModule
{
	/**
	 * Method to initialise the Dunamis Framework for J!Blesta
	 * @access		public
	 * @version		1.0.0
	 *
	 * @since		1.0.0
	 */
	public function initialise()
	{
		
	}
}