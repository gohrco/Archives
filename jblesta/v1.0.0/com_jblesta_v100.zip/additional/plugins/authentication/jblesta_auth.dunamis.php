<?php
/**
 * -------------------------------------------
 * J!Blesta
 * -------------------------------------------
 * @package         J!Blesta
 * @version         1.0.0
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */

defined('_JEXEC') or die( 'Restricted access' );

/**
 * Define the J!Blesta version here
 */
if (! defined( 'DUN_MOD_JBLESTA' ) ) define( 'DUN_MOD_JBLESTA', "1.0.0" );
if (! defined( 'DUN_MOD_JBLESTA_AUTH' ) ) define( 'DUN_MOD_JBLESTA_AUTH', "1.0.0" );


/**
 * JBlesta Authentication Plugin Dunamis Extension
 * @desc		This class is used to enable us to call up the plugin through Dunamis
 * @package		J!Blesta
 * @subpackage	Joomla
 * @author		Go Higher Information Services, LLC
 * @link		https://www.gohigheris.com
 * @copyright	2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license		GNU General Public License version 2, or later
 */
class Jblesta_authDunModule extends DunModule
{
	/**
	 * Initializes the class
	 * @access		public
	 * @version		1.0.0
	 *
	 * @return		void
	 * @since		1.0.0
	 */
	public function initialise()
	{
		
	}
}