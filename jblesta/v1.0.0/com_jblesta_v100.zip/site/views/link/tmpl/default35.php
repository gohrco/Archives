<?php 
/**
 * J!Blesta
 * 
 * @package    J!Blesta
 * @copyright  2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.0 ( $Id: default.php 469 2012-05-04 20:04:56Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      2.1.0
 * 
 * @desc       Register View - default layout:  The default layout for the registration view
 *  
 */

defined('_JEXEC') or die('Restricted access');

