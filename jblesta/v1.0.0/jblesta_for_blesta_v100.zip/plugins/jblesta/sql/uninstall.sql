
DROP TABLE `jblesta_settings`;