<?php
/**
 * -------------------------------------------
 * J!Blesta
 * -------------------------------------------
 * @package         J!Blesta
 * @version         1.1.0
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */

defined('_JEXEC') or die( 'Restricted access' );

/**
 * Define the J!Blesta version here
 */
if (! defined( 'DUN_MOD_JBLESTA' ) ) define( 'DUN_MOD_JBLESTA', "1.1.0" );
if (! defined( 'DUN_MOD_JBLESTA_USER' ) ) define( 'DUN_MOD_JBLESTA_USER', "1.1.0" );


/**
 * JBlesta User Plugin Dunamis Extension
 * @desc		This is used to access settings for the user plugin in Dunamis
 * @package		J!Blesta
 * @subpackage	Joomla
 * @author		Go Higher Information Services, LLC
 * @link		https://www.gohigheris.com
 * @copyright	2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license		GNU General Public License version 2, or later
 */
class Jblesta_userDunModule extends DunModule
{
	/**
	 * Initializes the class
	 * @access		public
	 * @version		1.1.0
	 *
	 * @return		void
	 * @since		1.0.0
	 */
	public function initialise()
	{
		
	}
}