<?php
/**
 * -------------------------------------------
 * J!Blesta
 * -------------------------------------------
 * @package         J!Blesta
 * @version         1.1.0
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */

defined('_JEXEC') or die( 'Restricted access' );

/**
 * Define the JWHMCS version here
 */
if (! defined( 'DUN_MOD_JBLESTA' ) ) define( 'DUN_MOD_JBLESTA', "1.1.0" );
if (! defined( 'DUN_MOD_JBLESTA_SYSM' ) ) define( 'DUN_MOD_JBLESTA_SYSM', "1.1.0" );

/**
 * JBlesta System Plugin Dunamis Extension
 * @desc		This class enables us to call up the sytem plugin settings and updates through Dunamis
 * @package		J!Blesta
 * @subpackage	Joomla
 * @author		Go Higher Information Services, LLC
 * @link		https://www.gohigheris.com
 * @copyright	2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license		GNU General Public License version 2, or later
 */
class Jblesta_sysmDunModule extends DunModule
{
	public function initialise()
	{
		
	}
}