J!Blesta
------------------------------------------------------------------------

 Release Version: 1.1.0
    Release Date: 2014 October 15

 PLEASE READ ALL THE ENCLOSED INSTRUCTIONS

        Forums: https://www.gohigheris.com/forum/
       Support: https://support.gohigheris.com
 Documentation: https://support.gohigheris.com/docs/display/JBL/J!Blesta+Home
   Client Area: https://client.gohigheris.com


[ CONTENTS ] 
------------------------------------------------------------------------

1. Server Requirements
2. Version 1.1.0 Release Notes
3. New Installation Instructions


[ SERVER REQUIREMENTS ]
------------------------------------------------------------------------

1. Joomla! 2.5 / 3.x
2. Blesta version 3.0 or above
3. PHP Version 5.3 or later
4. MySQL Version 5 or later
5. Curl Support (with SSL)
6. Ioncube Loaders Support (required for Blesta portion of installation)


[ RELEASE NOTES ]
------------------------------------------------------------------------

To review the details and notes for the Version 1.1.0 release, please see:

https://support.gohigheris.com/docs/display/JBL/J!Blesta+Home


[ NEW INSTALLATION INSTRUCTIONS ]
------------------------------------------------------------------------

For instructions on performing a new installation of J!Blesta, please see:

https://support.gohigheris.com/docs/display/JBL/New+Installations

