<?php
/**
 * -------------------------------------------
 * J!Blesta
 * -------------------------------------------
 * @package         J!Blesta
 * @version         1.1.0
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );


/**
 * JBlesta Default Model
 * @desc		This class is used by Dunamis to initialise J!Blesta for Joomla
 * @package		J!Blesta
 * @subpackage	Joomla
 * @author		Go Higher Information Services, LLC
 * @link		https://www.gohigheris.com
 * @copyright	2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license		GNU General Public License version 2, or later
 */
class JblestaModelDefault extends JblestaModelExt
{
	/**
	 * Constructor task
	 * @access		public
	 * @version		1.1.0
	 *
	 * @since		1.0.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Method to synchronize settings with WHMCS
	 * @access		public
	 * @version		1.1.0
	 *
	 * @return		string on error or true on success
	 * @since		1.0.0
	 */
	public function settingssync()
	{
		$api	=	dunloader( 'api', 'com_jblesta' );
		$config	=	dunloader( 'config', 'com_jblesta' );
		
		// Verify API is enabled and working
		if (! $api->isEnabled() ) {
			return 'APIDISABLED';
		}
		
		$data	=	array(
				'enable'				=>	$config->get( 'enable' ),
				'debug'					=>	$config->get( 'debug' ),
				'token'					=>	$config->get( 'token' ),
				'enableuserbridging'	=>	$config->get( 'enableuserbridging' ),
				'languageenable'		=>	$config->get( 'languageenable' ),
				'regmethod'				=>	$config->get( 'regmethod' )
				);
		
		if (! $api->updatesettings( $data ) ) {
			return 'APIERROR';
		}
		
		return true;
	}
}