<?php
/**
 * -------------------------------------------
 * J!Blesta
 * -------------------------------------------
 * @package         J!Blesta
 * @version         1.1.0
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */

defined('JPATH_BASE') or die;

jimport('joomla.html.html');
jimport('joomla.form.formfield');
jimport('joomla.form.helper');


// -------------------------------------------------------
// Ensure we have Dunamis and it's loaded
if (! function_exists( 'get_dunamis' ) ) {
	$path	= dirname( dirname( dirname( dirname( dirname( dirname(__FILE__) ) ) ) ) ) . DS . 'libraries' . DS . 'dunamis' . DS . 'dunamis.php';
	if ( file_exists( $path ) ) require_once( $path );
}

if (! function_exists( 'get_dunamis' ) ) {
	// EPIC FAILURE HERE
	return;
}

get_dunamis( 'com_jblesta' );

/**
 * JBlesta Page List Field
 * @desc		This class retrieves a list of pages that can be used for menu items in Joomla
 * @package		J!Blesta
 * @subpackage	Joomla
 * @author		Go Higher Information Services, LLC
 * @link		https://www.gohigheris.com
 * @copyright	2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license		GNU General Public License version 2, or later
 */
class JFormFieldPageList extends JFormFieldList
{
	/**
	 * Our field name type
	 * @access		public
	 * @var			string
	 * @since		2.5.0
	 */
	public $_name		= 'PageList';
	
	
	/**
	 * Method to fetch the options for the element
	 * @access		public
	 * @version		1.1.0 ( $id$ )
	 * 
	 * @return		array of objects
	 * @since		1.0.0
	 */
	protected function getOptions()
	{
		static $options	= null;
		
		if ( $options == null ) {
			
			$options[]	=   (object) array( 'value' => '', 'text' => '- Select a Page -');
			$config		=	dunloader( 'config', 'com_jblesta' );
			$pagetxt	=	explode( "\r\n", trim( $config->get( 'pagelist' ) ) );
			
			foreach( $pagetxt as $page ) {
				$page	=	trim( $page );
				if ( empty( $page ) ) continue;
				$tmp	=	explode( "=", $page );
				$name	=	array_shift( $tmp );
				$options[]	=	(object) array( 'value'	=> base64_encode( implode( "=", $tmp ) ), 'text' => $name );
			}
			
		}
		
		return $options;
	}
}
