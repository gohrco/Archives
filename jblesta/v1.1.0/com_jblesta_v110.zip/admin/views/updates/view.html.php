<?php
/**
 * -------------------------------------------
 * J!Blesta
 * -------------------------------------------
 * @package         J!Blesta
 * @version         1.1.0
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

/**
 * JBlesta Updates View Handler
 * @desc		This is the view handler for the updates area of the admin area of J!Blesta
 * @package		J!Blesta
 * @subpackage	Joomla
 * @author		Go Higher Information Services, LLC
 * @link		https://www.gohigheris.com
 * @copyright	2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license		GNU General Public License version 2, or later
 */
class JblestaViewUpdates extends JblestaViewExt
{
	
	/**
	 * Assembles the page for the application to send to user
	 * @access		public
	 * @version		1.1.0
	 * @param		string		$tpl		Internal tpl override option
	 * 
	 * @since		1.0.0
	 */
	function display( $tpl = null )
	{
		$model	=	$this->getModel();
		$data	=	$model->getData( true );
		
		$doc	=	dunloader( 'document', true );
		load_bootstrap( 'jblesta' );
		
		// Retrieve ACL permitted actions
		$canDo	= JblestaHelper :: getActions();
		
		JblestaToolbar :: build( 'updates', null, $canDo );
		
		JblestaHelper :: addMedia( 'common/js' );
		JblestaHelper :: addMedia( 'ajax/js' );
		JblestaHelper :: addMedia( 'icons/css' );
		
		$this->data	= $data;
		
		parent::display($tpl);
	}
	
	
	/**
	 * Displays the proces view
	 * @access		public
	 * @version		1.1.0
	 * @param		string		- $tpl: conains the template to overload with
	 * 
	 * return		parent :: display()
	 * @since		1.0.0
	 */
	function process( $tpl = null )
	{
		$this->setLayout( 'process' );
		
		parent::display($tpl);
	}
}