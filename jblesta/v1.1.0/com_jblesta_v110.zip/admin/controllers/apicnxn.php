<?php
/**
 * -------------------------------------------
 * J!Blesta
 * -------------------------------------------
 * @package         J!Blesta
 * @version         1.1.0
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * JblestaControllerApicnxn class is the task handler for the api connection checker in the admin area
 * @version		1.1.0
 *
 * @since		1.0.0
 * @author		Steven
 */
class JblestaControllerApicnxn extends JblestaControllerExt
{

	/**
	 * Constructor task
	 * @access		public
	 * @version		1.1.0
	 *
	 * @since		1.0.0
	 */
	public function __construct()
	{
		parent::__construct();
	}



	/**
	 * Display task
	 * @access		public
	 * @version		1.1.0
	 *
	 * @since		1.0.0
	 * @see			JblestaController :: display()
	 */
	public function display()
	{
		$input	=	dunloader( 'input', true );
		$input->setVar( 'view', 'apicnxn' );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			$input->setVar( 'layout', 'default35' );
		}

		parent::display();
	}
	
	
	/**
	 * Task to return user to main screen of JBLESTA
	 * @access		public
	 * @version		1.1.0
	 * 
	 * @since		1.0.0
	 */
	public function mainscreen()
	{
		$this->setRedirect( 'index.php?option=com_jblesta&controller=default' );
		$this->redirect();
	}
}