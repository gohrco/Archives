<?php
/**
 * -------------------------------------------
 * J!Blesta
 * -------------------------------------------
 * @package         J!Blesta
 * @version         1.1.0
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */

defined( '_JEXEC' ) or die( 'Restricted access' );
defined('DUNAMIS') OR exit('No direct script access allowed');

/**
 * JBlesta Updates handler
 * @desc		This class is used by Dunamis to handle J!Blesta updates for Joomla
 * @package		J!Blesta
 * @subpackage	Joomla
 * @author		Go Higher Information Services, LLC
 * @link		https://www.gohigheris.com
 * @copyright	2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license		GNU General Public License version 2, or later
 */
class Com_jblestaDunUpdates extends JoomlaDunUpdates
{
	protected $_exceptions	=	array( 'README.txt' );
	protected $_expires		=	86400; // TTL
	protected $_installpath	=	null;
	protected $_url			=	'https://www.gohigheris.com/updates/jblesta/joomla-package';
	protected $_version		=	'1.1.0';
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.1.0
	 * @param		array		- $options: anything we want to set
	 *
	 * @since		1.0.0
	 */
	public function __construct( $options = array() )
	{
		$options	=	parent :: __construct( $options );
		$options	=	$this->setProperties( array( 'url', 'installpath', 'exceptions' ), $options );
		
		// Read / find / write any updates we have from the database
		$this->_updateRead();
		$this->_updateFind();
		$this->_updateWrite();
	}
	
	
	/**
	 * Singleton
	 * @access		public
	 * @static
	 * @version		1.1.0
	 * @param		array		- $options: contains an array of arguments
	 *
	 * @return		object
	 * @since		1.0.0
	 */
	public static function getInstance( $options = array() )
	{
		static $instance = array();
		
		$serialize	=	serialize( $options );
		
		if (! isset( $instance[$serialize] ) ) {
			$instance[$serialize]	=	new self ( $options );
		}
		
		return $instance[$serialize];
	}
	
	
	/**
	 * Method for reading an update in
	 * @access		protected
	 * @version		1.1.0
	 *
	 * @return		boolean
	 * @since		1.0.0
	 */
	protected function _updateRead()
	{
		$config	=	dunloader( 'config', 'com_jblesta' );
		$data	=	$config->get( 'updates', null );
		
		// If the store doesn't exist return false
		if( $data == null || empty( $data ) ) {
			return false;
		}
		
		// Decode the data
		$data	= json_decode( $data );
		$this->setLastrun( $data->lastrun );
		$this->setUpdate( $data->update );
		
		return true;
	}
	
	
	/**
	 * Method for getting a download URL for update
	 * @access		protected
	 * @version		1.1.0
	 *
	 * @return		false on empty update
	 * @return		string
	 * @since		1.0.0
	 */
	protected function _updateUrl()
	{
		$config	=	dunloader( 'config', 'com_jblesta' );
		$dlid	=	$config->get( 'downloadid', null );
		
		$url	=	parent :: _updateUrl();
		$uri	=	DunUri :: getInstance( $url );
		
		if ( $dlid ) {
			$uri->setVar( 'dlid', $dlid );
		}
		
		return $uri->toString();
	}
	
	
	/**
	 * Method for writing an update out
	 * @access		protected
	 * @version		1.1.0
	 *
	 * @return		boolean
	 * @since		1.0.0
	 */
	protected function _updateWrite()
	{
		$db			=	dunloader( 'database', true );
		$config		=	dunloader( 'config', 'com_jblesta' );
		
		$update	=	new stdClass();
		$update->lastrun	=	$this->getLastrun();
		$update->update		=	$this->getUpdate();
		
		$data	=	json_encode( $update );
		
		// If the store doesn't exist return false
		if( $data == null || empty( $data ) ) {
			return false;
		}
		
		$config->set( 'updates', $data );
		return $config->save();
	}
}