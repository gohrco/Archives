<?php
/**
 * -------------------------------------------
 * J!Blesta
 * -------------------------------------------
 * @package         J!Blesta
 * @version         1.1.0
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
include_once( JPATH_SITE . DIRECTORY_SEPARATOR . 'administrator' . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_jblesta' . DIRECTORY_SEPARATOR . 'jblesta.legacy.php' );


/**
 * JBlesta Controller
 * @desc		This is the base controller for the front end of J!Blesta
 * @package		J!Blesta
 * @subpackage	Joomla
 * @author		Go Higher Information Services, LLC
 * @link		https://www.gohigheris.com
 * @copyright	2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license		GNU General Public License version 2, or later
 */
class JblestaController extends JblestaControllerExt
{

	/**
	 * Constructor task
	 * @access		public
	 * @version		1.1.0
	 *
	 * @since		1.0.0
	 */
	public function __construct()
	{
		parent::__construct();
	}



	/**
	 * Display task
	 * @access		public
	 * @version		1.1.0
	 *
	 * @since		1.0.0
	 */
	public function display()
	{
		$input	=	dunloader( 'input', true );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			//$input->setVar( 'layout', 'default35' );
		}
		
		parent::display();
	}
}