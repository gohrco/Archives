<?php
/**
 * -------------------------------------------
 * J!Blesta
 * -------------------------------------------
 * @package         J!Blesta
 * @version         1.1.0
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
jimport( 'joomla.application.component.view' );


/**
 * JBlesta Link View
 * @desc		This is the view handler for the Link Menu Type of J!Blesta
 * @package		J!Blesta
 * @subpackage	Joomla
 * @author		Go Higher Information Services, LLC
 * @link		https://www.gohigheris.com
 * @copyright	2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license		GNU General Public License version 2, or later
 */
class JBlestaViewLink extends JBlestaViewExt
{
	/**
	 * Builds the view from the display task for the user
	 * @access		public
	 * @version		1.1.0
	 * @param 		string		$tpl - presumably a template name never used
	 * 
	 * @since		1.0.0
	 */
	public function display($tpl = null)
	{
		$app		=	JFactory::getApplication();
		$config		=	dunloader( 'config', 'com_jblesta' );
		$params		=	$app->getParams();
		
		$url		=	$params->get( 'blestaapiurl' );
		$location	=	rtrim( $url, '/' ) . '/' . ltrim( base64_decode( $params->get( 'location' ) ), '/' );
		
		//		Languages don't get translated properly when on Joomla and going to WHMCS with language settings enabled
// 		if ( $config->get( 'languageenable' ) ) {
			
// 			$uri = JUri::getInstance();
// 			$jconfig	=	dunloader( 'config', true );
			
// 			if ( $jconfig->get( 'sef_rewrite' ) ) {
// 				$parts	=	explode( '/', ltrim( $uri->getPath(), '/' ) );
// 				$sef	=	array_shift( $parts );
// 			}
// 			else {
// 				$sef	=	$uri->getVar( 'lang', false );
// 			}
				
// 			$langs	=	JLanguageHelper::getLanguages('sef');
// 			if ( isset( $langs[$sef] ) ) {
// 				$mylang	=	$config->findLanguage( $langs[$sef]->lang_code );
		
// 				$locuri	=	DunUri :: getInstance( $location );
// 				$locuri->setVar( 'language', $mylang );
// 				$location	=	$locuri->toString();
// 			}
// 		}
		
		$app->redirect( $location );
		$app->close();
	}
}