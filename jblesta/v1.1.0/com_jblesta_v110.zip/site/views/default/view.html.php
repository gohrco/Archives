<?php
/**
 * -------------------------------------------
 * J!Blesta
 * -------------------------------------------
 * @package         J!Blesta
 * @version         1.1.0
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );


/**
 * JBlesta Default View
 * @desc		This class renders the default view back to Blesta
 * @package		J!Blesta
 * @subpackage	Joomla
 * @author		Go Higher Information Services, LLC
 * @link		https://www.gohigheris.com
 * @copyright	2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license		GNU General Public License version 2, or later
 */
class JblestaViewDefault extends JblestaViewExt
{
	/**
	 * Builds the view from the display task for the user
	 * @access		public
	 * @version		1.1.0
	 * @param 		string			presumably a template name never used
	 * 
	 * @since		1.0.0
	 */
	public function display($tpl = null)
	{
		$app		=	JFactory::getApplication();
		$params		=	$app->getParams();
		
		$this->assignRef('params',	$params);
		parent :: display( $tpl );
	}
}