<?php
/**
 * -------------------------------------------
 * J!Blesta
 * -------------------------------------------
 * @package         J!Blesta
 * @version         1.1.0
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */

defined('_JEXEC') or die( 'Restricted access' );

/**
 * JBlesta System Plugin API Language Items
 * @desc		This file handles the retrieval of Language Items through our API
 * @package		J!Blesta
 * @subpackage	Joomla
 * @author		Go Higher Information Services, LLC
 * @link		https://www.gohigheris.com
 * @copyright	2013-2014 Go Higher Information Services, LLC.  All rights reserved.
 * @license		GNU General Public License version 2, or later
 */
class LanguageitemsJblestaAPI extends JblestaAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		1.1.0
	 * 
	 * @since		1.0.0
	 */
	public function execute()
	{
		$db		=	dunloader( 'database', true );
		$query	=	"SHOW TABLES LIKE " . $db->Quote( "%languages" );
		
		mysql_set_charset( 'utf8' );
		
		$db->setQuery( $query );
		$result	=	$db->loadResult();
		
		if (! $result ) {
			$this->error( JText :: _( 'JBLESTA_SYSM_API_LANGITEMS_NOTABLE' ) );
		}
		
		$query	=	"SELECT `title` as `name`, `lang_code` as `code`, `sef` as `shortcode` FROM #__languages WHERE `published` <> '-2' ORDER BY name";
		$db->setQuery( $query );
		$langs	=	$db->loadObjectList();
		
		$return	=	(object) array( 'languageitems' => base64_encode( serialize( $langs ) ), 'version' => DUN_ENV_VERSION );
		$this->success( $return );
	}
}