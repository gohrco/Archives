<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: class.xmlparser.php 217 2011-05-19 18:00:46Z steven_gohigher $
 * @since      1.5.3
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class JwhmcsXml
{
	 
	/**
	 * @var instance to contain object when created
	 */
	private static $instance = null;
	
	/**
	 * Sets the XML Object to use simple xml instead
	 * @var		boolean
	 * @since	2.25
	 */
	private $simple		= false;
	
    /* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Called upon initialization of object class
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	private function __construct()
	{
		$this->parseOn		= false;
		$this->parseCnt		= 0;
		$this->parseTag		= '';
		$this->parseRet		= array();
		$this->root			= 'whmcsapi';
		$this->parseData	= array();
	}
	
	
	/**
	 * Getter function returning default and setting if necessary
	 * @access		public
	 * @version		2.3.4
	 * @param 		string		- $var: the variable name to get
	 * @param 		varies		- $default: the default value if not set
	 * @param 		boolean		- $set: allows function to set the variable to default if not set
	 * 
	 * @return		varies depending on value of variable
	 * @since		2.25
	 */
	public function get( $var = null, $default = null, $set = true )
	{
		if ( $var == null ) return false;
		
		if ( isset( $this->$var ) ) {
			return $this->$var;
		}
		
		if ( ( $set ) ) {
			$this->set( $var, $default );
			return $default;
		}
		
		return $default;
	}
	
	
	/**
	 * Setter function
	 * @access		public
	 * @version		2.3.4
	 * @param		string		- $name:  the name to set
	 * @param		varies		- $value: the value to set name to
	 * 
	 * @since		2.25
	 */
	public function set( $name, $value )
	{
		$this->$name = $value;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getInstance
	 * Purpose:		Called to create an instance of the class
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public static function getInstance( $options = array() )
	{
		$force	= ( isset( $options["force"] ) ? $options["force"] : false );
		
		if ( ( self::$instance == null ) || ( $force === true ) ) {
			self::$instance = new self;
		}
		
		return self::$instance;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setRoot
	 * Purpose:		This sets the root of the xml to search for.
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function setRoot($root)
	{
		$this->root = strtolower($root);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setData
	 * Purpose:		This function sets the data for usage
	 * As of:		version 1.5.3
	 * 
	 * Significant Revisions:
	 * 	2.0.2 (Mar 2010)
	 * 		+ Added convert characterset class for non-utf8 encoding
	\* ------------------------------------------------------------ */
	public function setData($data)
	{
		$params = & JwhmcsParams::getInstance();
		$wchars = trim($params->get( 'WhmcsCharacterset' ));
		if (( strtolower( $wchars ) != 'utf-8') && ($wchars != '' ) && ( $params->get( 'AdvConvertcharset' ) ) ) {
			require_once('ConvertCharset.class.php');
			$character = new ConvertCharset($wchars, "utf-8", true);
			$data = $character->convert($data);
		}
		
		$this->data	= $data;
	}
	
	
	/**
	 * This loads the xml result and returns the first item
	 * @access		public
	 * @version		2.3.4
	 * 
	 * @return		mixed result of the data row or false on error
	 * @since		1.5.3
	 */
	public function loadResult()
	{
		if ( $data = $this->loadResults() ) {
			return $data[0];
		}
		else {
			return false;
		}
	}
	
	
	/**
	 * Entry point for parsing the results from curl
	 * @access		public
	 * @version		2.3.4
	 * 
	 * @return		array containing the data or false on error / nothing to parse
	 * @since		1.5.3
	 */
	public function loadResults()
	{
		if ( $this->simple ) {
			if ( $data = $this->_parseSimple() ) {
				return $data;
			}
			else return false;
		}
		elseif ($data = $this->_parseXml()) {
			return $data;
		}
		else {
			return false;
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setPairs
	 * Purpose:		This sets the data to split
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function setPairs($data)
	{
		$this->data = explode(';', $data);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		loadPairs
	 * Purpose:		This splits the data pairs and returns as an array
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function loadPairs()
	{
		foreach ($this->data as $items)
		{
			if (is_array($items))
			{
				foreach ($items as $item)
				{
					$tmp = explode('=', $item);
					$ret[trim($tmp[0])] = trim($tmp[1]);
				}
			}
			else
			{
				$tmp = explode('=', $items);
				$ret[trim($tmp[0])] = ( isset( $tmp[1] ) ? trim($tmp[1]) : null );
			}
		}
		return $ret;
	}
	
	
	/**
	 * Parses data using simple xml method
	 * @access		private
	 * @version		2.3.4
	 * 
	 * $return		array containing parsed data
	 * @since		2.25 (May 2011)
	 */
	private function _parseSimple()
	{
		$data	= simplexml_load_string( $this->data );
		$data	= $this->_parseSimpleItems( $data );
		return $data;
	}
	
	
	/**
	 * Parses individual items for the simple xml method (allowing for recursion)
	 * @access		private
	 * @version		2.3.4
	 * @param		simplexml object	- $data: contains data retrieved by curl formatted as simplexml
	 * 
	 * @return		array containing data items parsed out
	 * @since		2.25 (May 2011)
	 */
	private function _parseSimpleItems( $data )
	{
		$return	= array();
		$cnt	= array();
		
		foreach ( $data as $name => $value ) {
			if (! isset( $cnt[$name] ) ) $cnt[$name] = 0;
			if ( count( $value ) == 0 ) {
				$return[$name] = (string) $value;
			}
			else {
				$return[$name][$cnt[$name]] = $this->_parseSimpleItems( $value );
				$cnt[$name]++;
			}
		}
		
		if ( isset( $cnt["result"] ) ) {
			unset( $cnt["result"] );
			foreach ($cnt as $key => $c ) {
				if ( $c == 1 ) {
					$return[$key] = $return[$key][0];
				}
			}
		}
		 
		return $return;
	}
	
	
    /* ------------------------------------------------------------ *\
	 * Function:	_parseXml()
	 * Purpose:		This function parses an xml response from the
	 * 				WHMCS API interface.
	 * As of:		version 1.5.2 (October 2009)
	 * 
	 * Significant Revisions:
	 *  2.0.2 (Mar 2010)
	 *  	- dropped utf8_encode function - moved to setData
	 * 	1.5.3 (Nov 2009)
	 * 		* changed the way the xml was parsed to be able to handle
	 * 		  utf8_encode function
	\* ------------------------------------------------------------ */
	private function _parseXml()
	{
		$this->xml = xml_parser_create();
		xml_set_object($this->xml, $this);
        xml_set_element_handler($this->xml, "_tagOpen", "_tagClose");
        xml_set_character_data_handler($this->xml, "_cData");
		xml_parse($this->xml, $this->data);
		$this->error = (xml_get_error_code($this->xml) ? 'Error at '.$this->parseTag.': '. xml_error_string(xml_get_error_code($this->xml)) : false );
		xml_parser_free($this->xml);
		return $this->parseData;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_tagOpen
	 * Purpose:		This function is part of the xml parser.
	 * As of:		version 1.5.3 (November 2009)
	\* ------------------------------------------------------------ */
	private function _tagOpen($parser, $tag, $attributes)
	{
		$tag = strtolower($tag);
		if ($tag == $this->root) {
			$this->parseOn = true;
		}
		if ($tag != $this->parseTag) {
			$this->parseTag = $tag;
			$this->elemCnt	= 0;
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_cData
	 * Purpose:		This function is part of the xml parser.
	 * As of:		version 1.5.3 (November 2009)
	\* ------------------------------------------------------------ */
	private function _cData($parser, $cdata)
	{
		if ($this->elemCnt == 0) {
			$this->parseData[$this->parseCnt][$this->parseTag] = trim($cdata);
			$this->elemCnt++;
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_tagClose
	 * Purpose:		This function is part of the xml parser.
	 * As of:		version 1.5.3 (November 2009)
	\* ------------------------------------------------------------ */
	private function _tagClose($parser, $tag)
	{
		$tag = strtolower($tag);
		if ($tag == $this->root) {
			$this->parseOn = false;
			$this->parseCnt++;
		}
	}
}