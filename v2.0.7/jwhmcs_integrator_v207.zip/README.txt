J!WHMCS Integrator
------------------------------------------------------------------------

 Release Version: 2.0.7
    Release Date: 2010 April 1

 PLEASE READ ALL THE ENCLOSED INSTRUCTIONS

        Forums: http://forums.jwhmcs.com
       Support: http://support.jwhmcs.com
 Documentation: http://wiki.jwhmcs.com
   Client Area: http://members.jwhmcs.com


[ CONTENTS ]
------------------------------------------------------------------------

1. Server Requirements
2. Version 2.0.7 Release Notes
3. New Installation Instructions
4. Upgrade Instructions


[ SERVER REQUIREMENTS ]
------------------------------------------------------------------------

1. Joomla 1.5 (version 1.5.15 or above recommended)
2. WHMComplete Solution (WHMCS) version 4.0 or above (4.2.1 recommended)
3. PHP Version 5.x or later
4. MySQL Version 5.x or later
5. Curl Support (with SSL)
6. Ioncube Loaders Support


[ RELEASE NOTES ]
------------------------------------------------------------------------

To review the details and notes for the Version 2.0.7 release, please see:

http://wiki.jwhmcs.com/Version_2.0.7_Release_Notes


[ NEW INSTALLATION INSTRUCTIONS ]
------------------------------------------------------------------------

For instructions on performing a new installation of WHMCS, please see:

http://wiki.jwhmcs.com/Installing_JWHMCS#Installing_JWHMCS


[ UPGRADE INSTRUCTIONS ]
------------------------------------------------------------------------

The recommended steps for upgrading from an earlier version of J!WHMCS
Integrator to this latest release can be found at:

http://wiki.jwhmcs.com/Version_2.0.7_Release_Notes#Upgrade_Steps
