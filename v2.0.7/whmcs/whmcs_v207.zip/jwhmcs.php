<?php
/**
 * WHMCS root file for J!WHMCS Integrator
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009-2010 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: jwhmcs.php 193 2010-03-31 01:45:42Z Steven $
 * @since		1.5.0
 */
define( 'JWHMCSINI', 'true' );
define(	'JPATH_BASE', dirname(__FILE__) );
define( 'DS', DIRECTORY_SEPARATOR );
define( 'JWHMCSVERS', '2.0.5' );
define( '_JEXEC', true );
define( 'JWHMCS_URL', "http://client.gohigheris.com/" );
define( 'JWHMCS_UNIQUEID', "JwhmcsInt" );

require_once (JPATH_BASE.DS.'jconfig.php');
if (! defined(JCONFIG_FILE) ) define( 'JCONFIG_FILE', 'configuration.php' );

define( 'JWHMCS_BASE_PATH', JPATH_CONFIG.DS.'administrator'.DS.'components'.DS.'com_jwhmcs'.DS );
define( 'JWHMCS_CLASS_PATH', JWHMCS_BASE_PATH.'classes'.DS );
define( 'JWHMCS_FILE_PATH', JWHMCS_BASE_PATH.'files');

require_once (JWHMCS_CLASS_PATH.'class.database.php');
require_once (JWHMCS_CLASS_PATH.'class.params.php');
require_once (JWHMCS_CLASS_PATH.'class.vars.php');
require_once (JWHMCS_CLASS_PATH.'class.curl.php');
require_once (JWHMCS_CLASS_PATH.'class.parse.php');
require_once (JWHMCS_CLASS_PATH.'class.cache.php');


function add_hook() {}

if (!is_readable('./includes/hooks/jwhmcs.php')) {
	$hookver = false;
} else {
	ob_start();
		include('./includes/hooks/jwhmcs.php');
	ob_end_clean();
	if (function_exists('hook_version'))
		$hookver = hook_version(true, 'HOOK');
	else
		$hookver = '1.5.3 beta 5 or earlier';
}
define( 'JWHMCSHOOKVERS', $hookver );

if (!is_readable('./includes/hooks/jwhmcs-lang.php')) {
	$hookver = false;
} else {
	ob_start();
		include('./includes/hooks/jwhmcs-lang.php');
	ob_end_clean();
	
	$hookver = hook_version(true, 'LANG');
}
define( 'JWHMCSLANGVERS', $hookver );

// Pull Joomla Configuration - but see if it is readable first
if (!is_readable(JPATH_CONFIG.DS.JCONFIG_FILE)) {
	die('Your configuration file is not readable at '.JPATH_CONFIG.DS.JCONFIG_FILE.'!  JWHMCS cannot proceed');
}
require_once (JPATH_CONFIG.DS.JCONFIG_FILE);
$jconfig	= new JConfig();

$db		= & JwhmcsDBO::getInstance($jconfig);	// Joomla DB
$params	= & JwhmcsParams::getInstance();
$vars	= & JwhmcsVars::getInstance();
$parse	= & JwhmcsParse::getInstance();
$cache	= & JwhmcsCache::getInstance();
$jcurl	= & JwhmcsCurl::getInstance();
$xml	= & JwhmcsXml::getInstance();

/* ------------------------------------------------------------ *\
 * Begin JWHMCS Class
\* ------------------------------------------------------------ */

$jwhmcs = new JWHMCS();

// If the task doesn't exist then run sendback
if (! (method_exists($jwhmcs, $vars->get( 'task' ) ) ) ) $vars->set( 'task', 'sendback' );

// Set the task variable and run appropriate task
if (!($task = $vars->get( 'task' ))) $task = 'sendback';

// Call task
$jwhmcs->$task( );

class JWHMCS
{
	
	private $license	= null;
	private $valid		= false;
	
	/* ------------------------------------------------------------ *\
	 * Function:	JWHMCS
	 * Purpose:		This is the constructor task
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 * 	2.0 (Nov 2009)
	 * 		+ Database, variable and parameters moved to class
	\* ------------------------------------------------------------ */
	function JWHMCS()
	{
		global $params, $vars;
		
		// Set defaults that aren't already set
		$this->_setDefaults();
		
		// Get the license
		$this->license = $this->_checkLicense();
		
		// Check the license to allow program to run (true)
		if ($this->license["status"] == 'Active')
		{
			$this->valid = true;
		}
		else
		{
			$this->valid = false;
		}
		
		// Figure out license type and activation
		// If license is owned, then expired should be allowed to run
		$license = explode('-', trim($params->get( 'licensekey' )));
		if ( $license[0] == 'Owned' )
		{
			if ( $this->license['status'] == 'Expired' )
			{
				$this->valid = true;
			}
		}
		
		if ($vars->get( 'joomadmin' ))
			$params->set( 'jwhmcsdebug', false );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	checkinstall
	 * Purpose:		Check the installation
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	 *  1.5.3 (Oct 2009)
	 *  	+ Added debug variable to prevent display to outside
	 *  	+ Removed requirement for WHMCS Client ID
	 *  	+ Added check for no data response without url param
	 *  	+ Moved curl function to common _cUrl fnxn
	 * 	1.5.2 (Oct 2009)
	 * 		+ Added check for xml response from v.4.1 WHMCS
	\* ------------------------------------------------------------ */
	public function checkinstall()
	{
		global $db, $params, $jcurl, $vars;
		
		// Initialize Value Array
		$val	= array();
		
		// Check WHMCS Version, set correctly in Parameters
		$wvers	= $this->_getWVersion();
		if ($wvers != $params->get( 'whmcsvers' )) $params->set( 'whmcsvers', $wvers, true);
		
		// Check for connection to API Interface
		$apicxn	= $this->_getApiConnection();
		
		// Create name reference
		$user	= $params->get( 'jwhmcsjstoreus' );
		$udisp	= ($user==1?'First Last':($user==2?'Last, First':($user==3?'First Last (Company)':'Last, First (Company)')));
		
		// Build Value array
		$val['rootvers']		= JWHMCSVERS;
		$val['hookvers']		= JWHMCSHOOKVERS;
		$val['langvers']		= JWHMCSLANGVERS;
		$val['jwhmcsvers']		= $params->get( 'jwhmcsvers' );
		$val['whmcsvers']		= $wvers;
		$val['whmcsdir']		= dirname(__FILE__);
		$val['configdir']		= JPATH_CONFIG;
		$val['configexists']	= ( file_exists(JPATH_CONFIG.DS.JCONFIG_FILE) ? true : false );
		$val['configreadable']	= ( is_readable(JPATH_CONFIG.DS.JCONFIG_FILE) ? true : false );
		$val['curlinstalled']	= ( function_exists('curl_init') ? true : false );
		$val['apiaccess']		= $apicxn['message'];
		$val['apiurl']			= $apicxn['url'];
		$val['apiusername']		= $params->get( 'jwhmcsadminus' );
		$val['license']			= ( $this->license['status'] == 'Invalid' ? ( isset($this->license['message']) ? $this->license['message'] : $this->license['status'] ) : $this->license['status'] );
		$val['licensevalid']	= $this->valid;
		$val['jurl']			= $params->get( 'jwhmcsjurl' );
		$val['jrootimgurl']		= $params->get( 'jwhmcsjrootimgurl' );
		$val['jssl']			= ( $params->get( 'jwhmcsjssl' ) ? true : false );
		$val['jin']				= $params->get( 'jwhmcsjin' );
		$val['jinssl']			= ( $params->get( 'jwhmcsjinssl' ) ? true : false );
		$val['jout']			= $params->get( 'jwhmcsjout' );
		$val['joutssl']			= ( $params->get( 'jwhmcsjoutssl' ) ? true : false );
		$val['whmcsurl']		= $params->get( 'jwhmcsurl' );
		$val['whmcsssl']		= ( $params->get( 'jwhmcsssl' ) ? true : false );
		$val['jquery']			= ( $params->get( 'jwhmcsjquery' ) ? true : false );
		$val['jstorename']		= $udisp;
		$val['pagein']			= 'http://'.$params->get( 'jwhmcsjurl' ).'/index.php?option=com_jwhmcs&view=default&Itemid='.$params->get( 'jwloggedinurl' );
		$val['pageout']			= 'http://'.$params->get( 'jwhmcsjurl' ).'/index.php?option=com_jwhmcs&view=default&Itemid='.$params->get( 'jwloggedouturl' );
		$val['overridecache']	= ( $params->get( 'overridecache' ) ? true : false );
		$val['clearcache']		= ( $params->get( 'clearcache' ) ? true : false );
		
		// Set definitions for above items
		$this->_setDefinitions();
		
		// Test to see what type of response to send (debug is plain text pairs)
		$type	= ( $vars->get( 'joomadmin' ) ? 'xml' : ($params->get( 'jwhmcsdebug') ? 'checkinstall' : 'none' ) );
		
		// Response package
		$return = $this->_buildResponse($val, $type);
		if ($vars->get('return')) {
			$vars->set( 'return', false );
			return $return;
		}
		$this->_sendResponse($return, $type);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	validate
	 * Purpose:		Validate WHMCS against Joomla to ensure no dupes
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	 * 		+ Set common responses and use XML
	 *  1.5.3 (Nov 2009)
	 *  	+ Moved curl function to common curl class
	 *  	+ Cleaned up messy function - wasn't working properly
	 * 	1.5.1c (Oct 2009)
	 * 		+ Fixed validation for groups - now groups cannot be changed
	\* ------------------------------------------------------------ */
	public function validate()
	{
		global $db, $params, $jcurl, $vars;
		
		if (!$this->valid)
			return;
		
		// 1a:  First pull the xref in the database for the clientid
		$query	= 'SELECT x.xref_a, x.xref_type, x.xref_b FROM #__jwhmcs_xref as x WHERE xref_b="'.$vars->get( 'clientid' ).'"';
		$db->setQuery($query);
		$xref	= $db->loadAssoc();
		
		// 1b:  Is there an xref?  Check if it's a group (4) if so, deny change
		if ($xref) {
			if ( $xref['xref_type'] == '4' ) {
				echo 'valid=false;reason=<br />You cannot change the details for your group account.  Please contact us for assistance.';
				return;
			} else {
				$juserid = $xref['xref_a'];
			}
		} else {
			$juserid = 0;
		}
		
		$query	= 'SELECT u.email, u.id FROM `#__users` u WHERE id <> '.$juserid;
		$db->setQuery($query);
		$users	= $db->loadAssocList();
		
		$result = true;
		foreach ($users as $user)
		{
			if (trim($vars->get( 'email' )) == trim($user['email']))
			{
				$result = false;
				break;
			}
		}
		
		if ($result)
		{
			$ret['result']	= 'success';
		}
		else
		{
			$ret['result']	= 'error';
			$ret['message']	= 'A user already has that email address';
		}
		
		// Test to see what type of response to send (debug is plain text pairs)
		$type	= ($params->get( 'jwhmcsdebug') ? 'pair' : 'xml' );
		
		// Response package
		$return = $this->_buildResponse($ret, $type);
		if ($vars->get('return')) {
			$vars->set( 'return', false );
			return $return;
		}
		$this->_sendResponse($return, $type);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	chpassword
	 * Purpose:		Change password in Joomla from WHMCS
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 * 	2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	 *  	+ Set common responses and use XML
	\* ------------------------------------------------------------ */
	public function chpassword()
	{
		global $db, $params, $vars;
		
		if (!$this->valid)
			return;
		
		$salt = $this->_genRandomPassword(32);
		$salted = $vars->get( 'password' ).$salt;
		$password = md5($salted).':'.$salt;
		
		$query	= 'UPDATE `#__users` SET `password` = "'.$password.'" WHERE id = (SELECT `xref`.`xref_a` FROM `#__jwhmcs_xref` as xref WHERE xref_b = '.$vars->get( 'clientid' ).')';
		$db->setQuery($query);
		$result	= $db->query();
		
		if ($result)
		{
			if($db->getAffectedRows()<1)
			{
				$ret['result']	=	'error';
				$ret['message']	=	'No user found in main site to update password for.  Please contact your administrator.';
			}
			else
			{
				$ret['result']	=	'success';
			}
		}
		else
		{
			$ret['result']	=	'error';
			$ret['message']	=	'There was a problem writing to the database.  Please contact your administrator.';
		}
		
		// Test to see what type of response to send (debug is plain text pairs)
		$type	= ($params->get( 'jwhmcsdebug') ? 'pair' : 'xml' );
		
		// Response package
		$return = $this->_buildResponse($ret, $type);
		if ($vars->get('return')) {
			$vars->set( 'return', false );
			return $return;
		}
		$this->_sendResponse($return, $type);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	addclient
	 * Purpose:		Add new client from WHMCS into Joomla
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	 *  	+ Set common responses and use XML
	 * 	1.5.1 (Sept 2009)
	 * 		+ URL for cUrl call changed to be strictly http (no ssl)
	\* ------------------------------------------------------------ */
	public function addclient($fromjwhmcs = 1)
	{
		global $db, $params, $jcurl, $vars;
		
		if (!$this->valid)
			return;
		
		// Retrieve name to use
		$name	= $this->_buildName();
		
		// Set token and value fields for insertion
		$token	= md5($_COOKIE['PHPSESSID'].date("s"));
		$val[]	= 'name='.$name;
		$val[]	= 'username='.$vars->get( 'username' );
		$val[]	= 'email='.$vars->get( 'email' );
		$val[]	= 'password='.$vars->get( 'password' );
		$val[]	= 'password2='.$vars->get( 'password2' );
		$val[]	= 'task=register_save';
		$val[]	= 'id=0';
		$val[]	= 'gid=0';
		$value	= implode("\n", $val);
		
		$query	= 'INSERT INTO `#__jwhmcs_sess` (`token`, `value`) VALUES ("'.$token.'", "'.$value.'");';
		$db->setQuery($query);
		$result	= $db->query();
		
		$url	= 'http://'.$params->get( 'jwhmcsjurl' ).'/index2.php?option=com_jwhmcs&task=register_save&fromjwhmcs='.$fromjwhmcs.'&token='.$token;
		
		$jcurl->setCall();
		$jcurl->set(CURLOPT_URL, $url);
		$jcurl->set(CURLOPT_HEADER, false);
		$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
		$jcurl->set(CURLOPT_RETURNTRANSFER, true);
		
		$return = $jcurl->loadResults();
		
		if ($return['result']=='success')
		{
			// Store this new id w/ the user id in the xref db
			$query	= 'INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) VALUES ('.$return['userid'].', 1, '.$vars->get( 'clientid' ).')';
			$db->setQuery($query);
			$result	= $db->query();
			
			$query	= 'INSERT INTO `#__jwhmcs_user` (`fname`, `lname`, `cname`, `email`, `address1`, `address2`, `city`, `state`, `postal`, `country`, `phonenumber` ) VALUES ("'.$vars->get( 'firstname' ).'", "'.$vars->get( 'lastname' ).'", "'.$vars->get( 'company' ).'", "'.$vars->get( 'email' ).'",  "'.$vars->get( 'address1' ).'", "'.$vars->get( 'address2' ).'", "'.$vars->get( 'city' ).'", "'.$vars->get( 'state' ).'", "'.$vars->get( 'postcode' ).'", "'.$vars->get( 'country' ).'", "'.$vars->get( 'phonenumber' ).'")';
			$db->setQuery($query);
			$result	= $db->query();
			
			$ret['result']		= 'success';
			$ret['joomlaid']	= $return['userid'];
		}
		else
		{
			$ret['result']		= 'error';
			$ret['message']		= $return['error'];
		}
		
		// Test to see what type of response to send (debug is plain text pairs)
		$type	= ($params->get( 'jwhmcsdebug') ? 'pair' : 'xml' );
		
		// Response package
		$return = $this->_buildResponse($ret, $type);
		if ($vars->get('return')) {
			$vars->set( 'return', false );
			return $return;
		}
		$this->_sendResponse($return, $type);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	updateclient
	 * Purpose:		Update information from WHMCS to Joomla
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 * 	2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	 *  	+ Set common responses and use XML
	\* ------------------------------------------------------------ */
	public function updateclient()
	{
		global $db, $params, $vars;
		
		if (!$this->valid)
			return;
		
		$name	= $this->_buildName();
		
		$query	= 'UPDATE `#__users` SET `name` = "'.$db->getEscaped($vars->get( 'name' )).'", `email` = "'.$db->getEscaped($vars->get( 'email' )).'" WHERE `id` = (SELECT `xref`.`xref_a` FROM `#__jwhmcs_xref` as xref WHERE xref.xref_b='.$vars->get( 'clientid' ).')';
		$db->setQuery($query);
		$result	= $db->query();
		
		$query	= 'UPDATE `#__jwhmcs_user` SET `fname` = "'.$vars->get( 'firstname' ).'", `lname` = "'.$vars->get( 'lastname' ).'", `cname` = "'.$vars->get( 'company' ).'", `email` = "'.$vars->get( 'email' ).'", `address1` = "'.$vars->get( 'address1' ).'", `address2` = "'.$vars->get( 'address2' ).'", `city` = "'.$vars->get( 'city' ).'", `state` = "'.$vars->get( 'state' ).'", `postal` = "'.$vars->get( 'postcode' ).'", `country` = "'.$vars->get( 'country' ).'", `phonenumber` = "'.$vars->get( 'phonenumber' ).'" WHERE `#__jwhmcs_user`.`id` = '.$vars->get( 'clientid' );
		$db->setQuery($query);
		$result	= $db->query();
		
		if ($result)
		{
			if($db->getAffectedRows()<1)
			{
				$ret['result']	= 'failure';
				$ret['reason']	= 'No user found in main site to update information for.  Please contact your administrator.';
			}
			else
			{
				$ret['result']	= 'success';
			}
		} else {
			$ret['result']	= 'error';
			$ret['reason']	= 'There was a problem writing to the database.  Please contact your administrator.';
		}
		
		// Test to see what type of response to send (debug is plain text pairs)
		$type	= ($params->get( 'jwhmcsdebug') ? 'pair' : 'xml' );
		
		// Response package
		$return = $this->_buildResponse($ret, $type);
		if ($vars->get('return')) {
			$vars->set( 'return', false );
			return $return;
		}
		$this->_sendResponse($return, $type);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	login
	 * Purpose:		Handle client login from Joomla to WHMCS
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.0.2 (Mar 2010)
	 *  	+ Sets return cookie instead of redirecting to correct page
	 * 	2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	 *  	+ Post variables to form for login (securely if SSL enabled)
	\* ------------------------------------------------------------ */
	public function login()
	{
		global $db, $params, $vars;
		
		if (!$this->valid)
			$this->sendback();
		
		// Load uid and upw from database with matching token
		$query	= 'SELECT `value` FROM `#__jwhmcs_sess` WHERE token="'.$vars->get( 'a' ).'"';
		$db->setQuery($query);
		$result	= $db->loadAssoc();
		
		// Parse value field
		$tmp = preg_split('/\n/', $result['value']);
		foreach ($tmp as $t):
			$var = explode('=', $t);
			$k = $var[0];
			unset($var[0]);
			$param[$k] = implode("=", $var);
			unset($k, $var);
		endforeach;
		
		// Delete row from database with matching token to prevent hacks
		$query	= 'DELETE FROM `#__jwhmcs_sess` WHERE token="'.$vars->get( 'a' ).'" LIMIT 1';
		$db->setQuery($query);
		$delete	= $db->query();
		
//		$url = 'http'.($params->get( 'jwhmcsssl' )?'s':'').'://'.$params->get( 'jwhmcsurl' ).'/dologin.php?goto='.($param['goto']?$param['goto']:'jwhmcs');
		$url = 'http'.($params->get( 'jwhmcsssl' )?'s':'').'://'.$params->get( 'jwhmcsurl' ).'/dologin.php?goto=jwhmcs';
		$fields['username']		= $param['email'];
		$fields['password']		= $param['password'];
		$fields['return']		= $param['return'];
		$fields['rememberme']	= true;
		
		unset($_COOKIE['return']);
		setcookie('return', $param['return'], time()+30);
//		$_COOKIE['return'] = $param['return'];
		
		$this->_formRedirect($url, $fields);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	jlogin
	 * Purpose:		Handle client login from WHMCS into Joomla
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 * 	2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	\* ------------------------------------------------------------ */
	public function jlogin()
	{
		global $db, $params, $vars;
		
		if (!$this->valid)
			$this->sendBack();
		
		$val[]	= 'passwd='.$vars->get( 'password' );
		
		$post	= $vars->getMethod('request');
		
		foreach ($post as $k => $v)
		{
			$val[]	= $k.'='.$v;
		}
		
		$posarray = array("http://".$params->get('jwhmcsurl')."/", "https://".$params->get('jwhmcsurl')."/", "http://".$params->get('jwhmcsurl')."/".($vars->get('goto') ? $vars->get('goto').".php" : "index.php" ), "https://".$params->get('jwhmcsurl')."/".($vars->get('goto') ? $vars->get('goto').".php" : "index.php" ));
		
		// Check for return variable being set
		if (!isset($post['return'])) {
			if ( isset($_SERVER['HTTP_REFERER']) ) {
				if (in_array($_SERVER['HTTP_REFERER'], $posarray)) {
					$val[] = 'whmcs=1';
				}
			}
			
			if ((! isset($_SERVER['HTTP_REFERER'])) || in_array('whmcs=1', $val)) {
				// Build return variable
				$getVars = $vars->getMethod( 'get' );
				
				foreach ($getVars as $k => $v) {
					if (in_array($k, array('task', 'usessl', 'loggedin', 'filename', 'action', 'goto'))) continue;
					$qryitem[] = $k.'='.$v;
				}
				if (is_array($qryitem)) $qry = "?".implode("&",$qryitem);
				else $qry = '';
				
				$qrystr = "http".($vars->get('usessl') ? "s":"")."://".$params->get('jwhmcsurl')."/".($vars->get('goto') ? $vars->get('goto').".php" : "index.php" ).$qry;
				$val[] = 'return='.base64_encode($qrystr);
			}
			else {
				$val[] = 'return='.base64_encode($_SERVER['HTTP_REFERER']);
			}
		}
		
		// 1c:  Use the session cookie as the token and implode the value array
		$token	= md5($vars->get( 'PHPSESSID' ).date("s"));
		$value	= implode("\n", $val);
		
		// 2:  Write to DB
		$query	= 'INSERT INTO `#__jwhmcs_sess` (`token`, `value`) VALUES ("'.$token.'", "'.$value.'")';
		$db->setQuery($query);
		$result	= $db->query();
		
		// 3:  Redirect to Joomla
		$url = 'http://'.$params->get( 'jwhmcsjurl' ).'/index.php?option=com_jwhmcs&task=whmcs_login&token='.$token;
		$this->_redirect($url);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	logout
	 * Purpose:		handle client logout
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 * 	2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	\* ------------------------------------------------------------ */
	public function logout()
	{
		global $params, $vars;
		
		if (!$this->valid)
			$this->sendBack();
		
		$ssl	= ($params->get( 'jwhmcsjoutssl' )?'s':'');
		$dest = $params->get( 'jwhmcsjout' );
		
		$url = 'http'.$ssl.'://'.$dest;
		$this->_redirect($url);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	logoutJoomla
	 * Purpose:		handle client logout from WHMCS to Joomla
	 * As of:		version 2.0.0 (January 2010)
	\* ------------------------------------------------------------ */
	public function logoutJoomla()
	{
		global $params, $vars;
		
		if (!$this->valid) $this->sendBack();
		
		// Redirect to Joomla for logout
		$url = 'http://'.$params->get( 'jwhmcsjurl' ).'/index.php?option=com_user&task=logout';
		$this->_redirect($url);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	sendback
	 * Purpose:		Redirect to Joomla if no task sent
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.0.2 (Mar 2010)
	 *  	+ Added check for return variable in cookie
	 * 	2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	\* ------------------------------------------------------------ */
	public function sendBack()
	{
		global $params, $vars;
		
		if ($return = $vars->get( 'return' )) {
			$url = base64_decode($return);
		} elseif ($vars->get( 'PHPSESSID' ) != '') {
			$url = 'http'.( $params->get( 'jwhmcsjinssl' ) ? 's' : '' ).'://'.$params->get( 'jwhmcsjin' );
		} else {
			$url = 'http'.( $params->get( 'jwhmcsjoutssl' ) ? 's' : '' ).'://'.$params->get( 'jwhmcsjout' );
		}
		
		$this->_redirect($url);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	syncReload
	 * Purpose:		retrieve users from WHMCS direct from database 
	 * As of:		version 2.0.0 (January 2010)
	\* ------------------------------------------------------------ */
	public function syncReload()
	{
		global $params, $vars;
		
		if (!$this->valid) $this->sendBack();
		if (!$vars->get( 'joomadmin' )) $this->sendBack();
		
		$wconfig = $this->_getWhmcsDB();
		$wb		 = & JwhmcsDBO::getInstance($wconfig);	// WHMCS DB
		
		$query	= 'SELECT `id`, `firstname`, `lastname`, `companyname`, `email`, `address1`, `address2`, `city`, `state`, `postcode`, `country`, `phonenumber` FROM `#__clients`';
		$wb->setQuery($query);
		$result	= $wb->loadAssocList();
		
		// Test to see what type of response to send (debug is plain text pairs)
		$type	= ($params->get( 'jwhmcsdebug') ? 'pair' : 'xml' );
		
		// Response package
		$return = $this->_buildResponse($result, $type);
		if ($vars->get('return')) {
			$vars->set( 'return', false );
			return $return;
		}
		$this->_sendResponse($return, $type);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	whmcsParamUpdate
	 * Purpose:		retrieve parameters from WHMCS to update params 
	 * As of:		version 2.0.0 (January 2010)
	\* ------------------------------------------------------------ */
	public function whmcsParamUpdate()
	{
		global $params, $vars;
		$result = array();
		
		$wconfig = $this->_getWhmcsDB();
		$GLOBALS['wb'] = & JwhmcsDBO::getInstance($wconfig);
		$result = $this->_getWhmcsSettings();
		
		// Cycle through each result looking for wanted whmcs params
		$whmcs_toget = array('defaultcountry', 'requiredpwstrength', 'nomd5', 'version');
		foreach ($whmcs_toget as $v) $data[$v] = $result[$v];
		$data['result'] = ($data['version']?'success':'error');
		
		// Test to see what type of response to send (debug is plain text pairs)
		$type	= ($params->get( 'jwhmcsdebug') ? 'pair' : 'xml' );
		
		// Response package
		$return = $this->_buildResponse($data, $type);
		if ($vars->get('return')) {
			$vars->set( 'return', false );
			return $return;
		}
		$this->_sendResponse($return, $type);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	parse
	 * Purpose:		Called to render template from Joomla
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	 *  	- Functionality moved to parse class
	 *  	+ Common responses set
	 *  1.5.3 b5 (Oct 2009)
	 *  	+ Check for usessl and loggedin to create them if not set
	 *  1.5.3 b3 (Oct 2009)
	 *  	+ Created option array for cUrl to use
	 *  	+ Ability to hide WHMCS content if site offline
	 * 	1.5.1 (Sept 2009)
	 * 		+ Rooturl parameter (for clients with J! installed in subdirectories)
	\* ------------------------------------------------------------ */
	public function parse()
	{
		global $db, $params, $vars, $jcurl, $parse, $cache;
		
		if (!$this->valid) {
			$ret['return'] = 'success';
			$ret['htmlheader']	= base64_encode('<div style="width: 200px; margin: 0px auto; text-align: center; ">Licensing Error</div>');
			$ret['htmlfooter']	= base64_encode('<div style="width: 200px; margin: 0px auth; text-align: center; ">Please contact Go Higher for more information</div>');
			
			// Test to see what type of response to send (debug is plain text pairs)
			$type	= ($params->get( 'jwhmcsdebug') ? 'pair' : 'xml' );
			$return = $this->_buildResponse($ret, $type);
			
			if ($vars->get('return'))
			{
				$vars->set( 'return', false );
				return $return;
			}
			$this->_sendResponse($return, $type);
			return;
		}
		
		// Check to see if the cache is to be used
		if ($cache->useCache())
		{
			// Check to see if the cache exists for the requested location
			if ($cache->cacheExists())
			{
				// Retrieve the cache
				$cdata	= $cache->getCache();
				
				// Check to see if the cache is invalid
				if (!$cache->validcache)
				{
					if (! $cache->delCache())
					{
						// Error trapping to be done for file deletion failure
					}
					unset($cdata);
				}
				// Use the cache if it is valid
				else
				{
					$ret['return'] = 'success';
					$ret['htmlheader']	= $cdata[1];
					$ret['htmlfooter']	= $cdata[2];
					$vars->set( 'usecache', true);
				}
			}
		}
		
		// If we didn't use the cache or caching is off, then usecache is set to false
		if (! $vars->get( 'usecache' ))
		{
			$jcurl->setCall();
			$jcurl->setParse(false);
			$jcurl->set(CURLOPT_URL, $parse->get( 'url' ));
			
			$site = $jcurl->loadResults();
			$parse->setData($site);
			
			$ret['return'] = 'success';
			$ret['htmlheader']	= $parse->get( 'htmlhdr' );
			$ret['htmlfooter']	= $parse->get( 'htmlftr' );
			
			// Test the variables to see if we need to save the cache to the server
			if ($vars->get( 'caching' ))
			{
				$cache->newCache();
				$cache->addCache($ret['htmlheader']);
				$cache->addCache($ret['htmlfooter']);
				$cache->saveCache();
			}
			
		} // End Cache check
		
		// Test to see what type of response to send (debug is plain text pairs)
		$type	= ($params->get( 'jwhmcsdebug') ? 'pair' : 'xml' );
		
		$return = $this->_buildResponse($ret, $type);
		
		if ($vars->get('return'))
		{
			$vars->set( 'return', false );
			return $return;
		}
		
		$this->_sendResponse($return, $type);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	checklicense
	 * Purpose:		quick check of J!WHMCS license 
	 * As of:		version 2.0.0 (January 2010)
	\* ------------------------------------------------------------ */
	public function checklicense()
	{
		global $vars;
		
		if (!$vars->get( 'joomadmin' )) return;
		
		$ret['return']			= $this->license['status'];
		$ret['registeredname']	= ( isset( $this->license['registeredname'] ) ? $this->license['registeredname'] : '' );
		$ret['companyname']		= ( isset( $this->license['companyname'] ) ? $this->license['companyname'] : '' );
		$ret['email']			= ( isset( $this->license['email'] ) ? $this->license['email'] : '' );
		$ret['regdate']			= ( isset( $this->license['regdate'] ) ? $this->license['regdate'] : '' );
		$ret['valid']			= $this->valid;
		
		$return = $this->_buildResponse($ret);
		$this->_sendResponse($return);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	process
	 * Purpose:		handle installation, upgrade and removal from J! 
	 * As of:		version 2.0.0 (January 2010)
	\* ------------------------------------------------------------ */
	public function process()
	{
		global $vars, $params, $db, $cache;
		
		$process_array = array('install' => 1, 'upgrade' => 2, 'uninstall' => 4);
		$this->task = $process_array[$vars->get( 'action' )];
		
		$wconfig			= $this->_getWhmcsDB();
		$GLOBALS['wb']		= & JwhmcsDBO::getInstance($wconfig);	// WHMCS DB
		$GLOBALS['whmcs_db'] = $this->_getWhmcsSettings();
		
		global $wb, $whmcs_db;
		
		$files = $this->_preCheck();
		
		// Install, Upgrade or Uninstall check failed - notify calling curl
		if (!$files) {
			// return xml indicating failure
			$return['result'] = 'error';
			$return['message'] = 'Was not able to complete precheck process.';
		}
		else {
			// Installation:  Set JWHMCS Component Parameters to return to installer
			if ( ( $this->task & 1 ) == true ) {
				$return['whmcs_version']		= $whmcs_db['version'];
				$return['whmcs_template']		= $whmcs_db['template'];
				$return['whmcs_systemurl']		= $whmcs_db['systemurl'];
				$return['whmcs_systemsslurl']	= $whmcs_db['systemsslurl'];
				$return['whmcs_defaultcountry']	= $whmcs_db['defaultcountry'];
				$return['whmcs_requiredpwstrength'] = $whmcs_db['requiredpwstrength'];
				$return['whmcs_nomd5']			= $whmcs_db['nomd5'];
				$return['whmcs_charset']		= $whmcs_db['charset'];
			}
			
			// Install / Upgrade:  Check IP list from WHMCS and set it
			if ( ( $this->task & 3 ) == true ) {
				$ips = explode("\n", $whmcs_db['apiallowedips']);
				if (!in_array($_SERVER['SERVER_ADDR'], $ips)) {
					array_unshift($ips, $_SERVER['SERVER_ADDR']);
					$ip_list = trim(implode("\n", $ips));
					
					$query = 'UPDATE #__configuration SET `value` = "'.$ip_list.'" WHERE `setting` = "APIAllowedIPs"';
					$wb->setQuery($query);
					$wb->query();
				}
			}
			
			// Change database settings after install
			if (($whmcs_db['template'] == 'portal') || ($whmcs_db['template'] == 'default' )) {
				$template = $whmcs_db['template'];
			}
			elseif (substr($whmcs_db['template'],0,6) == 'jwhmcs') {
				$tmp = explode('-', $whmcs_db['template']);
				$template = $tmp[1];
			}
			else {
				$template = 'portal';
			}
			$q[] = 'UPDATE #__configuration SET `value` = "jwhmcs-'.$template.'" WHERE `setting` = "Template"';
			$q[] = 'UPDATE #__configuration SET `value` = "0" WHERE `setting` = "RequiredPWStrength"';
			
			// Change database settings after upgrade
			
			
			// Change database settings prior to delete
			// First ensure WHMCS hasn't been upgraded since install (don't change if so)
			if ($params->get( 'whmcs_version' ) == $whmcs_db['version']) {
				if ('jwhmcs-'.$whmcs_db['template'] == $whmcs_db['template']) {
					// If the current template is the jwhmcs-template then change it
					$q[] = 'UPDATE #__configuration SET `value` = "'.$params->get( 'whmcs_template' ).'" WHERE `setting` = "Template"';
				}
				if (($whmcs_db['requiredpwstrength'] == '0') && $whmcs_db['requiredpwstrength'] != $params->get( 'whmcs_requiredpwstrength') ) {
					// If the current pw strength is = 0 and the original wasn't 0, then change it
					$q[] = 'UPDATE #__configuration SET `value` = "'.$params->get('whmcs_requiredpwstrength').'" WHERE `setting` = "RequiredPWStrength"';
				}
			}
			
			// Make database updates
			if (count($q)>0) {
				foreach ($q as $query) {
					$wb->setQuery($query);
					$wb->query();
				}
			}
			
			// Process $files according to task selected and return true
			foreach ($files as $f) {
				if (!$f[0]) continue; // If false, skip this file
				// Install and Upgrade Files
				if ( ( $this->task & 3 ) == true ) {
					if ( ( $f[3] & 3 ) == true ) {
						$this->_recursive_copy($f[5], $f[6], ( ( ( $f[4] & 4 ) == true ) ? true : false ), ( ( ( $f[4] & 2 ) == true ) ? true : false ) );
					}
				}
				// Uninstallation Files
				if ( ( $this->task & 4 ) == true ) {
					if ( ( $f[3] & 4 ) == true ) {
						if ( ( $f[4] & 8 ) == true ) {
							$this->_recursive_delete($f[6]);
						}
						else {
							$this->_recursive_copy($f[6], $f[5], true, false);
						}
					}
				}
			}
			$return['result'] = 'success';
		}
		$return = $this->_buildResponse($return);
		$this->_sendResponse($return);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_preCheck (private)
	 * Purpose:		run tests to verify install can proceed 
	 * As of:		version 2.0.0 (January 2010)
	\* ------------------------------------------------------------ */
	private function _preCheck($install = false)
	{
		global $vars, $params, $db, $whmcs_db;
		
		// Check for token passed by Curl
		if (!$vars->get( 'token' )) return false;
		
		// Check token against params from database to confirm valid uninstall req
		if ($vars->get( 'token' ) != $params->get( 'installtok' )) return false;
		
		// Check that the action was passed and found
		if (!$this->task) return false;
		
		// Pull JWHMCS Version from setting and set local variable
		$install_jwhmcs = str_replace('.', '', JWHMCSVERS);
		
		// Pull WHMCS Version from WHMCS Database and set local variable
		$install_whmcs	= str_replace('.', '', trim($whmcs_db['version']));
		
		// Pull File Manifest from Joomla install location
		$lines = file(JWHMCS_BASE_PATH.'filemanifest.csv');
		$lines = preg_replace('/\//i', DS, $lines);
		$lines = preg_replace('/<%J%>/i', JWHMCS_FILE_PATH, $lines);
		$lines = preg_replace('/<%W%>/i', JPATH_BASE, $lines);
		$lines = preg_replace('/[\t\r\n]/i', '',$lines);
		
		foreach($lines as $l) {
			$files[] = explode(",", $l);
		}
		
		clearstatcache();
		// Check through each file source and destination to verify existance and permitted
		for($i=0; $i<count($files); $i++) {
			$result = true;
			
			$files[$i][0] = str_replace('.', '', $files[$i][0]);
			$files[$i][1] = str_replace('.', '', $files[$i][1]);
			
			// If this file task options don't appear in current task
			if (($files[$i][2] & $this->task) == false) $result = false;
			
			// Install / Upgrade Logic
			if ((($this->task & 3) == true) && (($files[$i][2] & 3) == true)) {
				// Check to see if the source file exists
				if (!file_exists($files[$i][4])) $result = false;
				
				// Check to see if the destination file exists
				if (file_exists($files[$i][5])) {
					// If the file exists, can this file be overwritten?  False on no
					if (($files[$i][3] & 4) == false) $result = false;
				}
				// Check to see if the installed WHMCS is a lower version than this file is intended for
				if ($install_whmcs < $files[$i][1]) $result = false;
				
				// We know the installed WHMCS must be = or > than the file version
				// so is the file only intended for the exact matching versions?
				if ((($files[$i][3] & 32) == true) && ($install_whmcs != $files[$i][1])) $result = false;
				
				// So is the current version < installed WHMCS vers AND the file intended for lesser vers?
				if ((($files[$i][3] & 16) == true) && ($install_whmcs > $files[$i][1])) $result = false;
			}
			// Uninstall Logic
			elseif ((($this->task & 4) == true) && (($files[$i][2] & 4)) == true) {
				// Check to see if the file exists (no, nothing to delete)
				if (!file_exists($files[$i][5])) $result = false;
				
				// Check to see if delete is set otherwise it's a move
//				if (($files[$i][3] & 8 ) != true) {
					// It must be a move, so check destination exist
//					if (file_exists($files[$i][4])) $result = false;
//				} 
			}
			array_unshift($files[$i], $result);
		}
		
		return $files;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_recursive_copy (private)
	 * Purpose:		handle copying files from directories 
	 * As of:		version 2.0.0 (January 2010)
	\* ------------------------------------------------------------ */
	private function _recursive_copy($src, $dst, $ow = false, $copy = true)
	{
		// Test to see if src is a directory
		if ( is_dir($src) ) {
			$dir = opendir($src);
			@mkdir($dst);
			while(false !== ( $file = readdir($dir)) ) {
				if (( $file != '.' ) && ( $file != '..' )) {
					if ( is_dir($src . DS . $file) ) {
						$this->_recursive_copy($src .DS. $file,$dst .DS. $file, $ow, $copy);
					}
					else {
						if ((file_exists($dst.DS.$file)) && ($ow == false)) {
							continue;
						}
						if ($copy) {
							copy($src.DS.$file,$dst.DS.$file);
						}
						else {
							if (file_exists($dst.DS.$file)) {
								unlink($dst.DS.$file);
							}
							rename($src.DS.$file,$dst.DS.$file);
						}
					}
				}
			}
			closedir($dir);
		}
		else {
			if ((file_exists($dst)) && ($ow == false)) {
				return;
			}
			if ($copy) {
				copy($src, $dst);
			}
			else {
				if (file_exists($dst)) {
					unlink($dst);
				}
				rename($src,$dst);
			}
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_recursive_delete (private)
	 * Purpose:		recursively delete files and folders 
	 * As of:		version 2.0.0 (January 2010)
	\* ------------------------------------------------------------ */
	private function _recursive_delete($str){
        if(is_file($str)){
            return @unlink($str);
        }
        elseif(is_dir($str)){
            $scan = glob(rtrim($str,'/').'/*');
            foreach($scan as $index=>$path){
                $this->_recursive_delete($path);
            }
            return @rmdir($str);
        }
    }
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getWhmcsDB (private)
	 * Purpose:		Gather database connection variables for WHMCS DB
	 * As of:		version 2.0.0 (December 2009)
	\* ------------------------------------------------------------ */
	private function _getWhmcsDB()
	{
		include('./configuration.php');
		$config['host']		= $db_host;
		$config['user']		= $db_username;
		$config['password']	= $db_password;
		$config['database']	= $db_name;
		$config['prefix']	= 'tbl';
		return $config;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getWhmcsSettings (private)
	 * Purpose:		Pulls the current settings from WHMCS
	 * As of:		version 2.0.0 (December 2009)
	\* ------------------------------------------------------------ */
	private function _getWhmcsSettings()
	{
		global $wb;
		$data	= array();
		
		$query	= 'SELECT `setting`, `value` FROM #__configuration ORDER BY setting';
		$wb->setQuery($query);
		$result	= $wb->loadAssocList();
		
		foreach ($result as $r) {
			$data[strtolower($r['setting'])] = $r['value'];
		}
		
		$query	= 'SELECT `id` FROM #__currencies WHERE `default` = 1';
		$wb->setQuery($query);
		$data['defaultcurrency'] = $wb->loadResult();
		
		return $data; 
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_genRandomPassword (private)
	 * Purpose:		Generate random salt for password
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	private function _genRandomPassword($length = 8) {
		$salt = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		$len = strlen($salt);
		$makepass = '';
		$stat = array(php_uname());
		mt_srand(crc32(microtime() . implode('|', $stat)));
		for ($i = 0; $i < $length; $i ++)
			$makepass .= $salt[mt_rand(0, $len -1)];
		return $makepass;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_buildName (private)
	 * Purpose:		Provide uniform naming for storing in Joomla
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	\* ------------------------------------------------------------ */
	private function _buildName()
	{
		global $params, $vars;
		
		switch ($params->get( 'jwhmcsjstoreus' )):
		case '3':
			$name = $vars->get( 'company' ) ? ' ('.$vars->get( 'company' ).')' : '' ;
		case '1':
			$name = $vars->get( 'firstname' ).' '.$vars->get( 'lastname' ).$name;
			break;
		case '4':
			$name = ($vars->get( 'company' ) ? ' ('.$vars->get( 'company' ).')':'');
		case '2':
			$name = $vars->get( 'lastname' ).', '.$vars->get( 'firstname' ).$name;
			break;
		endswitch;
		return $name;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkLicense (private)
	 * Purpose:		Check a local license against remote license
	 * As of:		version 1.5.2 (October 2009)
	 * 
	 * Significant Revisions:
	 *  2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	 *  	- Removed curl to Gohigher
	 *  	+ Added request to validate license for remote check
	 * 	1.5.3 (Oct 2009)
	 * 		+ Made curl function use common _cUrl fnxn
	\* ------------------------------------------------------------ */
	private function _checkLicense()
	{
		global $params, $vars, $jcurl;
		
		// Fetch local license from params
		$licensekey = trim($params->get( 'licensekey' ));
		
		// Fetch local key from file
		if (file_exists(JWHMCS_BASE_PATH.'license.txt'))
		{
			$localkey = file_get_contents(JWHMCS_BASE_PATH.'license.txt');
		}
		
		$results = $this->_validateLicense($licensekey,$localkey);
		
		// For Debugging, Echo Results
		if ($vars->get( 'licensekey' ))
		{
			if ($vars->get( 'licensekey' ) == JWHMCS_UNIQUEID )
			{
				echo "<textarea cols=100 rows=20>"; print_r($results); echo "</textarea>";
			}
		}
		
		// Test results returned
		$licparts = explode('-', $licensekey);
		if (( $results["status"] == "Active" ) || (($results["status"] == "Expired" ) && ($licparts[0] == 'Owned' )))
		{
			// Check to see if a new localkey was sent back
			if ($results["localkey"])
			{
				// Save Updated Local Key to DB or File
				$localkeydata = $results["localkey"];
				@file_put_contents(JWHMCS_BASE_PATH.'license.txt', $localkeydata);
			}
		}
		
		return $results;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_validateLicense (private)
	 * Purpose:		Check local info against remote license key 
	 * As of:		version 2.0 (December 2009)
	\* ------------------------------------------------------------ */
	private function _validateLicense($licensekey,$localkey="")
	{
		$whmcsurl = JWHMCS_URL;
		$licensing_secret_key = JWHMCS_UNIQUEID; # Set to unique value of chars
		$checkdate = date("Ymd"); # Current date
		$usersip = isset($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : ( $_SERVER['LOCAL_ADDR'] ? $_SERVER['LOCAL_ADDR'] : '192.168.1.1' );
		$localkeydays = 15; # How long the local key is valid for in between remote checks
		$allowcheckfaildays = 5; # How many days to allow after local key expiry before blocking access if connection cannot be made
		$localkeyvalid = false;
		
		if ($localkey)
		{
			$localkey = str_replace("\n",'',$localkey); # Remove the line breaks
			$localdata = substr($localkey,0,strlen($localkey)-32); # Extract License Data
			$md5hash = substr($localkey,strlen($localkey)-32); # Extract MD5 Hash
			
			if ($md5hash==md5($localdata.$licensing_secret_key))
			{
				$localdata = strrev($localdata); # Reverse the string
				$md5hash = substr($localdata,0,32); # Extract MD5 Hash
				$localdata = substr($localdata,32); # Extract License Data
				$localdata = base64_decode($localdata);
				$localkeyresults = unserialize($localdata);
				$originalcheckdate = $localkeyresults["checkdate"];
				
				if ($md5hash==md5($originalcheckdate.$licensing_secret_key))
				{
					$localexpiry = date("Ymd",mktime(0,0,0,date("m"),date("d")-$localkeydays,date("Y")));
					
					if ($originalcheckdate>$localexpiry)
					{
						$localkeyvalid = true;
						$results = $localkeyresults;
						$validdomains = explode(",",$results["validdomain"]);
						
						if (!in_array($_SERVER['SERVER_NAME'], $validdomains))
						{
							$localkeyvalid = false;
							$localkeyresults["status"] = "Invalid";
							$results = array();
						}
						
						$validips = explode(",",$results["validip"]);
						
						if (!in_array($usersip, $validips))
						{
							$localkeyvalid = false;
							$localkeyresults["status"] = "Invalid";
							$results = array();
						}
						
						if ($results["validdirectory"]!=dirname(__FILE__))
						{
							$localkeyvalid = false;
							$localkeyresults["status"] = "Invalid";
							$results = array();
						}
					}
				}
			}
		}
		
		if (!$localkeyvalid)
		{
			$postfields["licensekey"] = $licensekey;
			$postfields["domain"] = $_SERVER['SERVER_NAME'];
			$postfields["ip"] = $usersip;
			$postfields["dir"] = dirname(__FILE__);
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $whmcsurl."modules/servers/licensing/verify.php");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $postfields);
			curl_setopt($ch, CURLOPT_TIMEOUT, 30);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			$data = curl_exec($ch);
			curl_close($ch);
			
			if (!$data)
			{
				$localexpiry = date("Ymd",mktime(0,0,0,date("m"),date("d")-($localkeydays+$allowcheckfaildays),date("Y")));
				
				if ($originalcheckdate>$localexpiry)
				{
					$results = $localkeyresults;
				}
				else
				{
					$results["status"] = "Remote Check Failed";
					return $results;
				}
				
			}
			else
			{
				preg_match_all('/<(.*?)>([^<]+)<\/\\1>/i', $data, $matches);
				$results = array();
				
				foreach ($matches[1] AS $k=>$v)
				{
					$results[$v] = $matches[2][$k];
				}
			}
			
			$licparts = explode('-', $licensekey);
			if (( $results["status"] == "Active" ) || (($results["status"] == "Expired" ) && ($licparts[0] == 'Owned' )))
			{
				$results["checkdate"] = $checkdate;
				$data_encoded = serialize($results);
				$data_encoded = base64_encode($data_encoded);
				$data_encoded = md5($checkdate.$licensing_secret_key).$data_encoded;
				$data_encoded = strrev($data_encoded);
				$data_encoded = $data_encoded.md5($data_encoded.$licensing_secret_key);
				$data_encoded = wordwrap($data_encoded,80,"\n",true);
				$results["localkey"] = $data_encoded;
			}
			
			$results["remotecheck"] = true;
		}
		unset($postfields,$data,$matches,$whmcsurl,$licensing_secret_key,$checkdate,$usersip,$localkeydays,$allowcheckfaildays,$md5hash);
		return $results;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getWVersion (private)
	 * Purpose:		Determine what version of WHMCS is being run 
	 * As of:		version 2.0 (December 2009)
	\* ------------------------------------------------------------ */
	private function _getWVersion()
	{
		$file = @fopen('./dbconnect.php', 'r');
		if ($file)
		{
			while (!feof($file))
			{
				$line = fgets($file);
				preg_match('/.*Version (?P<version>[^\s]+).*/', $line, $matches);
				if ($matches[0])
				{
					$ret = $matches['version'];
					break;
				}
			}
		}
		fclose($file);
		return $ret;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getApiConnection (private)
	 * Purpose:		Retrieve API Connection results 
	 * As of:		version 2.0 (December 2009)
	\* ------------------------------------------------------------ */
	private function _getApiConnection()
	{
		global $jcurl;
		
		$jcurl->setAction('getclientsdata', array('clientid' => 1));
		
		$data	= $jcurl->loadResults();
		$ret['url']	= $jcurl->get( CURLOPT_URL );
		if (!isset($data['result'])) $data = $data[0];
		
		// Build array of variables to display
		if (isset($data['result']))
		{
			if ($data['result']=="error"):
				if ($data['message']=='Client ID Not Found' || $data['message']=='Client Not Found'):
					$ret['result']	= true;
					$ret['message']	= 'Successfully Connected!';
				else:
					$ret['result']	= false;
					$ret['message']	= 'Error Returned:<br />'.$data['message'];
				endif;
			else:
				$ret['result']	= true;
				$ret['message']	= 'Successfully Connected!';
			endif;
		} else {
			$ret['result']	= false;
			$ret['message']	= 'No setting for WHMCS: URL to root WHMCS file';
		}
		
		return $ret;
	}
	
	/* ------------------------------------------------------------ *\
	 * Function:	_setDefaults (private)
	 * Purpose:		Establish default variables at initialization 
	 * As of:		version 2.0 (December 2009)
	\* ------------------------------------------------------------ */
	private function _setDefaults()
	{
		global $db, $params, $vars, $cache, $jconfig;
		
		$vars->set('offline', $jconfig->offline, 'request');
		$vars->set('caching', $jconfig->caching, 'request');
		$vars->set('cachetime', $jconfig->cachetime, 'request');
		$vars->set('force_ssl', $jconfig->force_ssl, 'request');
		
		if ($vars->get( 'jwhmcs' )) $params->set( 'jwhmcsdebug', 0 );
		if ($params->get( 'overridecache' )) $vars->set( 'caching', 0, 'request' );
		if ($params->get( 'clearcache' )) $cache->clearCache();
		
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_setDefinitions (private)
	 * Purpose:		create definitions for checkinstall display 
	 * As of:		version 2.0 (November 2009)
	\* ------------------------------------------------------------ */
	private function _setDefinitions()
	{
		$val	= array();
		
		// Array configuration:  [0] name, [1], [2] null, true, false for formatting, [3] definition
		$val['rootvers']		= array('Root File Version',		true,	true,	'This is the version of the WHMCS root file of J!WHMCS Integrator.');
		$val['hookvers']		= array('Hook File Version',		true,	false,	'This is the version of the WHMCS hook file of J!WHMCS Integrator.');
		$val['langvers']		= array('Language Hook File Version',		true,	false,	'This is the version of the WHMCS Language hook file of J!WHMCS Integrator.');
		$val['whmcsdir']		= array('WHMCS Directory',		true, false, 'This is the directory the J!WHMCS root file (this one) is located in.');
		$val['configdir']		= array('Joomla Directory',		true,	false,	'This setting is located in the jconfig.php file in the root install directory of WHMCS.  It is used to pull the configuration data from Joomla in order to not have to store that data in the Joomla database or in another file.');
		$val['configexists']	= array('Joomla '.JCONFIG_FILE.' Exists',		true,	false,	'Does the Joomla configuration file actually exist in the location specified in the jconfig.php file?');
		$val['configreadable']	= array('Joomla '.JCONFIG_FILE.' Readable',		true,	false,	'Can the Joomla configuration file actually be read?');
		$val['curlinstalled']	= array('PHP Curl Installed',		true,	false,	'This is a quick double check to be sure the curl library is actually installed with the web servers php');
		$val['whmcsvers']		= array('WHMCS Version Installed',		true,	true,	'This is the version of WHMCS that you have running on your server.');
		$val['jwhmcsvers']		= array('J!WHMCS Integrator Version',	true,	true,	'This is the version of J!WHMCS Integrator that you are running on your server.');
		$val['apiaccess']		= array('WHMCS API Connection',		true,	false,	'The result output of a test to the API interface of WHMCS given the variables you provided.');
		$val['apiurl']			= array('WHMCS API Url',		true,	false,	'The URL used to connect to the WHMCS API interface.');
		$val['apiusername']		= array('WHMCS API Username',		true,	false,	'The username used to connect to the WHMCS API interface.');
		$val['license']			= array('J!WHMCS Integrator License',		true,	false,	'This is the current status of your J!WHMCS Integrator License.');
		$val['licensevalid']	= array('J!WHMCS Integrator Functional',		true,	false,	'If your license is not valid, your J!WHMCS Integrator will not function.');
		$val['jurl']			= array('Joomla Url',		null,	null,	'This is the URL you entered for your Joomla site.');
		$val['jrootimgurl']		= array('Joomla Image Url',		null,	null,	'This is the URL you entered for pointing your images, css and javascript from Joomla to.');
		$val['jssl']			= array('Using SSL on WHMCS',		null,	'You are changing image, css and javascript references in your Joomla template to use SSL for pages that are being rendered for an SSL view.',	'You are not using SSL in WHMCS, or for some reason are not wanting to change the image, css and javascript references to use SSL on those pages.');
		$val['jin']				= array('Login Landing Page',		null, null, 'When your users login, this is the destination URL they will land on if successful.');
		$val['jinssl']			= array('Login Land with SSL',		null, 'When your users login, they are redirected to a page with SSL.', 'When your users login, they are redirected to a standard unsecure page.');
		$val['jout']			= array('Logout Landing Page',		null, null, 'When your users logout, this is the destination URL they will land on if successful.');
		$val['joutssl']			= array('Logout Land with SSL',		null, 'When your users logout, they are redirected to a page with SSL.', 'When your users logout, they are redirected to a standard unsecure page.');
		$val['whmcsurl']		= array('WHMCS Url',		null, null, 'This is the URL you entered for WHMCS.');
		$val['whmcsssl']		= array('WHMCS SSL for Redirect',		null, 'This setting tells JWHMCS to use ssl for redirecting content in WHMCS.', 'This setting would tell JWHMCS to use ssl to redirect to WHMCS pages for security purposes.');
		$val['jquery']			= array('WHMCS Enable jquery.js',		null, 'This is inserting the jquery.js file at the top of your JWHMCS rendered pages.  If you are experiencing errors, try setting this to No.', 'This setting would insert the jquery.js file at the top of your JWHMCS rendered pages.  If you are missing some javascript functionality in your WHMCS pages, try setting this to Yes.');
		$val['jstorename']		= array('Store Joomla Username Method',		null, null, 'This is the manner of storing your new Joomla user in the Joomla user database if they signup through WHMCS.');
		$val['pagein']			= array('Logged In Template Page',		null, null, 'This is the page that is pulled from Joomla to render around your WHMCS content for LOGGED IN users.');
		$val['pageout']			= array('Visitor Template Page',		null, null, 'This is the page that is pulled from Joomla to render around your WHMCS content for visitors.');
		$val['overridecache']	= array('Override Joomla Cache Setting',		null, 'This setting is overriding your cache settings in Joomla and is set NOT to use caching for JWHMCS rendered pages.', 'If you have caching on your Joomla site, but do not wish to use caching for JWHMCS rendered pages, you should set this to Yes.');
		$val['clearcache']		= array('Clear JWHMCS Cache',		null, 'This setting will clear the cache on the next load, and be set back to No once complete.', 'This setting would clear the cache on the next load if set to Yes.');
		$this->chdef = $val;
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * REDIRECTION AND RESPONSE FUNCTIONS
	\* ------------------------------------------------------------ */
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_redirect (private)
	 * Purpose:		Provide uniform redirection functionality 
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	private function _redirect($url) {
		header( 'Location: '.$url);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_formRedirect (private)
	 * Purpose:		Provide uniform form redirection functionality
	 * As of:		version 2.0 (December 2009)
	\* ------------------------------------------------------------ */
	private function _formRedirect($url, $fields)
	{
		global $params, $vars, $parse, $xml;
		
		$xml->setRoot('root');
		$vars->set( 'jwhmcs', 1 );
		$params->set( 'jwhmcsdebug', 0 );
		$vars->set( 'filename', 'clientarea' );
		$vars->set( 'return', true);
		
		$site	= $this->parse();
		$xml->setData($site);
		$site = $xml->loadResults();
		$site = $site[0];
		
		unset($site['return']);
		
		$hidden = '';
		foreach ($fields as $k => $v)
		{
			$hidden .= '<input type="hidden" name="'.$k.'" value="'.$v.'" />';
		}
		
		$tmpdir	= 'images/';
		$bgimg	= $tmpdir.'jwhmcs-trans-bg.png';
		$barimg	= $tmpdir.'jwhmcs-progress-bar.gif';
		$cssloc = $tmpdir.'jwhmcs.css';
		
		echo base64_decode($site['htmlheader']);
		echo <<< HTMLFORM
<link rel="stylesheet" type="text/css" href="$cssloc" />
<script>
<!--//--><![CDATA[//><!--

img1 = new Image();
img2 = new Image();
	
img1.src = "$bgimg";
img2.src = "$barimg";

//--><!]]>
</script>
		<div class="redirect-wrapper" id="jwhmcsredirect">
		<div class="redirect-texthdr"><span>Logging In</span><br />
		<div class="redirect-imagebar">&nbsp;</div>
		</div></div>
<form action="$url" method="post" name="frmlogin" id="frmlogin">
$hidden
</form>
<script language="javascript"><!--
setTimeout ( "autoForward()", 1500 );
function autoForward() {
	document.forms['frmlogin'].submit()
}
//--></script>
HTMLFORM;
		echo base64_decode($site['htmlfooter']);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_buildResponse (private)
	 * Purpose:		Build uniform responses 
	 * As of:		version 2.0 (December 2009)
	\* ------------------------------------------------------------ */
	private function _buildResponse($data, $type = 'xml')
	{
		global $params;
		
		switch ($type):
		case 'xml':
			foreach ($data as $k => $v) {
				if (is_array($v)) {
					foreach ($v as $k2 => $v2) {
						$sub[] = '<'.$k2.'><![CDATA['.$v2.']]></'.$k2.'>';
					}
					$return .= '<sub>'.implode("\n", $sub).'</sub>';
					unset($sub);
				}
				else {
					$return .= '<'.$k.'><![CDATA['.$v.']]></'.$k.'>';
				}
			}
			$return = '<?xml version="1.0" encoding="utf-8"?><root><param>'.$return.'</param></root>';
			break;
		case 'pair':
			foreach ($data as $k => $v) {
				if (is_array($v)) {
					foreach ($v as $k2 => $v2) {
						$sub[] = '['.$k2.'] = '.$v2;
					}
					$r[] = implode("\n", $sub);
				}
				else {
					$r[] = '['.$k.'] = '.$v;
				}
			}
			$return	= implode("\n", $r);
			break;
		case 'checkinstall':
			$cok = ' class="checkinstall-ok"';
			$cno = ' class="checkinstall-no"';
			
			foreach ($data as $k => $v) {
				$style	= ((!is_null($this->chdef[$k][1])) ? ( $v ? $cok : $cno ) : '' );
				$def	= ((!is_null($this->chdef[$k][1])) ? $this->chdef[$k][3] : (is_null($this->chdef[$k][2])) ? $this->chdef[$k][3] : ((!$v) ? $this->chdef[$k][3] : $this->chdef[$k][2] ) );
				$v		= (is_bool($v) ? ($v ? 'Yes' : 'No') : $v );
				if (($k == 'pagein') || ($k == 'pageout' )) $v = '<a href="'.$v.'" target="_blank">'.ucfirst($k).' Template Page</a>';
				if ( $k == 'license' ) {
					$style	= ( $data['licensevalid'] ? $cok : $cno );
					$v		= ($v == 'Invalid' ? (($this->license['message']) ? $this->license['message'] : 'Invalid License' ) : $v );
				}
				$r[]	= '<tr><td width="200" align="right" valign="top">'.$this->chdef[$k][0].'</td><td'.$style.' valign="top" width="300">'.$v.'</td><td class="checkinstall-def">'.$def.'</td></tr>';
			}
			$cssloc = 'images/jwhmcs.css';
			$return = "<link rel=\"stylesheet\" type=\"text/css\" href=\"$cssloc\" />";
			$return	.= '<table border=1 cellpadding="5" cellspacing="0">'.implode("\n", $r).'</table>';
			break;
		endswitch;
		return $return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_sendResponse (private)
	 * Purpose:		Provide uniform responses 
	 * As of:		version 2.0 (December 2009)
	\* ------------------------------------------------------------ */
	private function _sendResponse($response, $type = 'xml')
	{
		if ($type != 'xml')
		{
			echo $response;
		}
		else
		{
			header("Content-type: text/xml");
			echo $response;
		}
	}
}