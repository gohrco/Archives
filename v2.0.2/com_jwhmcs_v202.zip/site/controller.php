<?php
/**
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: controller.php 1 2009-09-02 00:16:45Z Steven $
 * @since		1.5.0
 */

jimport('joomla.application.component.controller');

/**
 * @package		J!WHMCS Controller
 */
class JwhmcsController extends JController
{
	/**
	 * task:  display
	 *     Default view display handler
	 */
	function display()
	{
		// If the view hasn't been set, set it to default
		if (is_null(JRequest::getVar( 'view'))) JRequest::setVar('view', 'default' );
		
		// Call up the parent display task
		parent::display();
	}
}
?>
