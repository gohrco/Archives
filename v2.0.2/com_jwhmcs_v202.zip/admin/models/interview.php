<?php
/**
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009-2010 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id$
 * @since		2.0.2
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );
jimport( 'joomla.installer.installer' );
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');
jimport('joomla.filesystem.path');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelInterview
 * Purpose:		Provide object for data for interview process
 * As of:		version 2.0.2 (March 2010)
\* ------------------------------------------------------------ */
class JwhmcsModelInterview extends JwhmcsModel
{
	var $buffer = null;
	
	/* ------------------------------------------------------------ *\
	 * Function:	__construct
	 * Purpose:		Builds class object upon calling
	 * As of:		version 2.0.2 (March 2010)
	\* ------------------------------------------------------------ */
	function __construct() {
		parent::__construct();
		
		$this->comid = $this->_comId();
		$this->params = $this->_getParams();
		
		$this->plugins = array(	'auth'		=> array('folder' => 'authentication', 	'element' => 'jwhmcs_auth', 	'path' => 'plg_jwhmcs_auth'		),
								'sysm'		=> array('folder' => 'system', 			'element' => 'jwhmcs_sysm', 	'path' => 'plg_jwhmcs_sysm'		),
								'sysmlang'	=> array('folder' => 'system', 			'element' => 'jwhmcs_sysmlang', 'path' => 'plg_jwhmcs_sysmlang'	),
								'user'		=> array('folder' => 'user', 			'element' => 'jwhmcs_user', 	'path' => 'plg_jwhmcs_user'		),
								'jauth'		=> array('folder' => 'authentication', 	'element' => 'joomla', 			'path' => '' 					)
		);
		$this->mtypes = array(	'hidden'	=> array('menutype' => 'jwhmcs-hidden',	'title' => 'JWHMCS Hidden Menu', 'desc' => 'This menu was created by the J!WHMCS Installer to store the Logged In and Logged Out pages'	),
								'client'	=> array('menutype' => 'client-menu',	'title' => 'Client Menu',		'desc' => 'This menu was created to be displayed on the client pages')
		);
		$this->mitems = array(	'hidden'	=> 	array( 
									'login'		=>	array( "Logged In",		"jwhmcs-logged-in",		"index.php?option=com_jwhmcs&view=default",		"component",	1, $this->comid, 1, ""),
									'logout'	=>	array( "Logged Out",	"jwhmcs-logged-out",	"index.php?option=com_jwhmcs&view=default",		"component",	1, $this->comid, 2, ""),
									'register'	=>	array( "Registration",	"jwhmcs-registration",	"index.php?option=com_jwhmcs&view=register",	"component",	1, $this->comid, 3, "")
												),
								'client'	=> array(
									'cportal'	=>	array( "Client Portal",				"jwhmcs-client-portal",		sprintf("http://%s/index.php", $this->params['jwhmcsurl']),							"url",	1, 0, 1, ""),
									'carea'		=>	array( "Client Area",				"jwhmcs-client-area",		sprintf("http://%s/clientarea.php", $this->params['jwhmcsurl']),					"url",	1, 0, 2, ""),
									'mydetails' =>	array( "My Details",				"jwhmcs-my-details",		sprintf("http://%s/clientarea.php?action=details", $this->params['jwhmcsurl']),		"url",	1, 0, 3, ""),
									'myproduct' =>	array( "My Products / Services",	"jwhmcs-my-products",		sprintf("http://%s/clientarea.php?action=products", $this->params['jwhmcsurl']),	"url",	1, 0, 4, ""),
									'mydomains'	=>	array( "My Domains",				"jwhmcs-my-domains",		sprintf("http://%s/clientarea.php?action=domains", $this->params['jwhmcsurl']),		"url",	1, 0, 5, ""),
									'myinvoice'	=>	array( "My Invoices",				"jwhmcs-my-invoices",		sprintf("http://%s/clientarea.php?action=invoices", $this->params['jwhmcsurl']),	"url",	1, 0, 6, ""),
									'mysupport'	=>	array( "My Support Tickets",		"jwhmcs-my-support-tickets",sprintf("http://%s/supporttickets.php", $this->params['jwhmcsurl']),				"url",	1, 0, 7, ""),
									'myemails'	=>	array( "My Emails",					"jwhmcs-my-emails",			sprintf("http://%s/clientarea.php?action=emails", $this->params['jwhmcsurl']),		"url",	1, 0, 8, ""),
									'addfunds'	=>	array( "Add Funds",					"jwhmcs-add-funds",			sprintf("http://%s/clientarea.php?action=addfunds", $this->params['jwhmcsurl']),	"url",	1, 0, 9, ""),
									'logout'	=>	array( "Logout",					"jwhmcs-logout",			sprintf("http://%s/?option=com_user&task=logout", $this->params['jwhmcsjurl']),		"url",	1, 0, 10, "")
												)
		);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	process
	 * Purpose:		Handles the installation process step by step
	 * As of:		version 2.0.2 (March 2010)
	\* ------------------------------------------------------------ */
	function process($step = 1)
	{
		$jname = "JWHMCS Integrator";
		$path	= trim( urldecode( JRequest::getVar( 'whmcspath' ) ) );
		$rununinstall	= ( JRequest::getVar( 'rununinstall' ) ? true : false );
		
		switch ($step):
		case 1:					// Check Task
			// Logic performed to determine the task being run
			//   $data = 1 for install, 2 for upgrade, 4 for uninstall
			
			if ($this->params['jwhmcsvers'] == '') {
				$data['task'] = 1;
			}
			elseif ($this->params['jwhmcsvers'] == JWHMCS_VERS) {
				// This may be uninstallation - check defined variable
				if ($rununinstall)
					$data['task'] = 4;
				else
					$data['task'] = 8;
			}
			else {
				$data['task'] = 2;
			}
			
			switch($data['task']):
			case 1:		// Installation task determined
				$uri = & JURI::getInstance();
				$uri->setPath( rtrim($uri->getPath(), 'administrator/index.php' ) );
				$this->params['jwhmcsdebug']	= 1;
				$this->params['jwlnkdefault']	= 1;
				$this->params['jwhmcsmenustyle'] = 'joomla';
				$this->params['jwhmcsjurl']		= $uri->toString(array('host', 'path'));
				$this->params['jwhmcsjrootimgurl'] = $uri->toString(array('host', 'path'));
				$this->params['jwhmcsjout'] = $uri->toString(array('host', 'path'));
				$this->params['jwhmcsvers'] = JWHMCS_VERS;
				$this->_saveParams($this->params, $this->comid);
				
				$data['nextstep']	= 101;
				$data['message'][]	= "New Install of version ".JWHMCS_VERS." Proceeding";
				break;
			case 2:		// Upgrad task determined
				$data['nextstep']	= 201;
				$data['message'][]	= "Upgrade of version ".$this->params['jwhmcsvers']." to ".JWHMCS_VERS." Proceeding";
				$this->params['jwhmcsvers'] = JWHMCS_VERS;
				break;
			case 4:		// Uninstall task determined
				$data['nextstep']	= 401;
				$data['message'][]	= "Uninstallation Proceeding";
				break;
			case 8:		// Running install again
				$data['nextstep']	= 101;
				$data['message'][]	= "Running Installation of version ".JWHMCS_VERS." again";
			endswitch;
			$this->_saveParams($this->params, $this->comid);
			break;
			
		/* ----------------------------------------------------------------- STEP 101 *\
		 * INSTALLATION PROCEDURE - Install Authentication Plugin
		\* -------------------------------------------------------------------------- */
		case 101:				// Install Authentication Plugin
		case 201:				// Upgrade Authentication Plugin
			$data['message'][]	= $this->_pluginHandler('auth', 'install');
			$data['message'][]	= $this->_pluginHandler('jauth', 'deactivate' );
			$data['nextstep'] = $step + 1;
			break;
			
		/* ----------------------------------------------------------------- STEP 102 *\
		 * INSTALLATION PROCEDURE - Install System Plugin
		\* -------------------------------------------------------------------------- */
		case 102:				// Install System Plugin
		case 202:				// Upgrade System Plugin
			$data['message'][]	= $this->_pluginHandler('sysm', 'install');
			$data['nextstep'] = $step + 1;
			break;
			
		/* ----------------------------------------------------------------- STEP 103 *\
		 * INSTALLATION PROCEDURE - Install System Language Plugin
		\* -------------------------------------------------------------------------- */
		case 103:				// Install System Language Plugin
		case 203:				// Upgrade System Language Plugin
			$data['message'][]	= $this->_pluginHandler('sysmlang', 'install');
			$data['nextstep'] = $step + 1;
			break;
		
		/* ----------------------------------------------------------------- STEP 104 *\
		 * INSTALLATION PROCEDURE - Install User Plugin
		\* -------------------------------------------------------------------------- */
		case 104:				// Install User Plugin
		case 204:				// Upgrade User Plugin
			$data['message'][]	= $this->_pluginHandler('user', 'install');
			$updates			= $this->_pluginHandler('user', 'update', true, array('ordering' => 10001));
			foreach ($updates as $update) $data['message'][] = $update;
			$data['nextstep'] = $step + 6;
			break;
		
		/* ----------------------------------------------------------------- STEP 110 *\
		 * INSTALLATION PROCEDURE - Create Hidden Menu
		\* -------------------------------------------------------------------------- */
		case 110:			// Create Hidden Menu
		case 210:			// Create Hidden Menu
			$data['message'][]	= $this->_menuHandler('hidden', 'typeadd');
			$msg				= $this->_menuHandler('hidden', 'itemsadd');
			$data['message']	= array_merge($data['message'], $msg);
			
			// Retrieve IDs of corresponding menu items
			$this->params['jwloggedinurl']	= $this->_menuHandler('hidden', 'itemexists', 'login', false );
			$this->params['jwloggedouturl']	= $this->_menuHandler('hidden', 'itemexists', 'logout', false );
			$this->_saveParams($this->params, $this->comid);
			
			$data['message'][]	= $this->_fileHandler(JPATH_CACHE.DS.'jwhmcs', 'foldercreate');
			$data['nextstep'] = $step + 5;
			break;
			
		/* ----------------------------------------------------------------- STEP 115 *\
		 * INSTALLATION PROCEDURE - Check WHMCS Path -- Major break point
		\* -------------------------------------------------------------------------- */
		case 115:			// Install Check WHMCS Path
		case 215:			// Upgrade Check WHMCS Path
			if (!$path) {
				$data['valid'] = false;
			}
			else {
				if (! JFile::exists($path.DS.'configuration.php' )) {
					$data['valid'] = false;
				}
				else {
					if (! JFile::exists($path.DS.'dbconnect.php')) {
						$data['valid'] = false;
					}
					else {
						$data['valid']		= true;
						$data['message'][]	= "WHMCS Path validated proceeding with installation";
					}
				}
			}
			
			// So we know the path is legit, can we write to it?
			if ($data['valid']) {
				if (! JPath::canChmod($path) ) {
					$data['valid'] = false;
				}
			}
			$data['nextstep'] = ( $data['valid'] ? ( $step + 5 ) : $step );
			break;
			
		/* ----------------------------------------------------------------- STEP 120 *\
		 * INSTALLATION PROCEDURE - Install Root Files
		\* -------------------------------------------------------------------------- */
		case 120:			// Install Root Files
		case 220:			// Upgrade Root Files
			$src = JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.'whmcs'.DS.'jwhmcs.php';
			$dst = $path.DS.'jwhmcs.php';
			
			$data['message'][]	= $this->_fileHandler($src, 'copy', true, $dst, true );
			
			// Jconfig file
			$src = JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.'whmcs'.DS.'jconfig.php';
			$dst = $path.DS.'jconfig.php';
			
			$this->_fileHandler( $dst, 'delete', false ); // Delete destination if it exists
			$this->_fileHandler( $src, 'readbuffer', false ); // Read the file into the buffer
			$this->buffer = sprintf( $this->buffer, JPATH_CONFIGURATION, 'configuration.php' );
			
			$result = $this->_fileHandler( $dst, 'writebuffer', false );
			
			$data['message'][]	= ( $result ? "Root file `jconfig.php` installed" : "Root file `jconfig.php` install failed" );
			$data['nextstep'] = $step + 5;
			break;
			
		/* ----------------------------------------------------------------- STEP 125 *\
		 * INSTALLATION PROCEDURE - Retrieve WHMCS DB settings
		\* -------------------------------------------------------------------------- */
		case 125:
		case 225:
			$exists = $this->_fileHandler($path.DS.'configuration.php', 'exists', false );
			$data['message'][]	= "WHMCS file `configuration.php` " . ( $exists ? "found" : "not found" );
			$data['nextstep']	= ( $exists ? $step + 5 : $step + 15 );
			
			include($path.DS.'configuration.php');
			
			$options['host']		= $db_host;
			$options['user']		= $db_username;
			$options['password']	= $db_password;
			$options['database']	= $db_name;
			$options['prefix']		= 'tbl';
			
			$wdb	= & JDatabase::getInstance($options);
			
			$query	= 'SELECT `setting`, `value` FROM #__configuration ORDER BY setting';
			$wdb->setQuery($query);
			$result	= $wdb->loadAssocList();
			$wsettings = $this->_setToArray($result);
			
			$uri = JURI::getInstance($wsettings['systemurl']);
			$ssl = false;
			if (trim($wsettings['systemsslurl'])) {
				$suri = JURI::getInstance($wsettings['systemsslurl']);
				$ssl = $suri->getScheme() == 'https' ? true : false;
			}
			
			$this->params[ 'jwhmcsurl' ]				= $uri->toString(array('host', 'path'));
			$this->params[ 'jwhmcsjssl' ]				= $ssl ? 1 : 0;
			$this->params[ 'whmcs_version' ]			= $wsettings[ 'version' ];
			$this->params[ 'whmcs_template' ]			= $wsettings[ 'template' ];
			$this->params[ 'whmcs_systemurl' ]			= $wsettings[ 'systemurl' ];
			$this->params[ 'whmcs_systemsslurl' ]		= $wsettings[ 'systemsslurl' ];
			$this->params[ 'whmcs_defaultcountry' ]		= $wsettings[ 'defaultcountry' ];
			$this->params[ 'whmcs_requiredpwstrength' ] = $wsettings[ 'requiredpwstrength' ];
			$this->params[ 'whmcs_nomd5' ]				= $wsettings[ 'nomd5' ];
			
			$this->_saveParams($this->params, $this->comid);
			break;
			
		/* ----------------------------------------------------------------- STEP 130 *\
		 * INSTALLATION PROCEDURE - Change WHMCS DB settings
		\* -------------------------------------------------------------------------- */
		case 130:
		case 230:
			
			include($path.DS.'configuration.php');
			
			$options['host']		= $db_host;
			$options['user']		= $db_username;
			$options['password']	= $db_password;
			$options['database']	= $db_name;
			$options['prefix']		= 'tbl';
			
			$wdb	= & JDatabase::getInstance($options);
			
			$query	= 'SELECT `setting`, `value` FROM #__configuration ORDER BY setting';
			$wdb->setQuery($query);
			$result	= $wdb->loadAssocList();
			$wsettings = $this->_setToArray($result);
			
			if (($wsettings['template'] == 'portal') || ($wsettings['template'] == 'default' )) {
				$template = 'jwhmcs-'.$wsettings['template'];
			}
			else {
				$template = 'jwhmcs-portal';
			}
			
			$qry['template']	= sprintf('UPDATE #__configuration SET `value` = "%s" WHERE `setting` = "Template"', $template);
			$qry['pwstrength']	= 'UPDATE #__configuration SET `value` = "0" WHERE `setting` = "RequiredPWStrength"';
			
			if (count($qry)>0) {
				foreach ($qry as $k => $q) {
					$wdb->setQuery($q);
					$data['message'][]	= "WHMCS Database variable `$k` " . ( $wdb->query() ? "changed successfully" : "not changed" );
				}
			}
			
			// Update IP Address
			$ips = explode("\n", $wsettings['apiallowedips']);
			$sip = isset($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : $_SERVER['LOCAL_ADDR'];
			
			if (!in_array($sip, $ips)) {
				array_unshift($ips, $sip);
				$ip_list = trim(implode("\n", $ips));
				
				$query = 'UPDATE #__configuration SET `value` = "'.$ip_list.'" WHERE `setting` = "APIAllowedIPs"';
				$wdb->setQuery($query);
				$data['message'][]	= sprintf("API IP address list %s updated", ( $wdb->query() ? "was" : "was not" ) );
			}
			
			$data['nextstep']	= $step + 5;
			break;
			
		/* ----------------------------------------------------------------- STEP 135 *\
		 * INSTALLATION PROCEDURE - Install Template Files
		\* -------------------------------------------------------------------------- */
		case 135:			// Install Template Files
		case 235:			// Upgrade Template Files
			$wvers	= str_replace( ".", "", $this->params[ 'whmcs_version' ] );
			
			$vers	= "v" . ( $wvers <= 410 ? '4.0.2' : ( $wvers < 420 ? "4.1.2" : "4.2.1" ) );
			$src	= JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.'whmcs'.DS.'templates'.DS.$vers.DS;
			$tpl	= $path.DS.'templates'.DS;
			
			// Create copies of existing default and portal directories
			$data['message'][]	= $this->_fileHandler($tpl.'default', 'foldercopy', true, $tpl.'jwhmcs-default' );
			$data['message'][]	= $this->_fileHandler($tpl.'portal', 'foldercopy', true, $tpl.'jwhmcs-portal');
			
			// Move altered files over to new location
			$data['message'] = array_merge( $data['message'], $this->_fileHandler( $src.'jwhmcs-default', 'foldercopyfiles', true, $tpl.'jwhmcs-default', true ) );
			$data['message'] = array_merge( $data['message'], $this->_fileHandler( $src.'jwhmcs-portal', 'foldercopyfiles', true, $tpl.'jwhmcs-portal', true ) );
			$data['message'] = array_merge( $data['message'], $this->_fileHandler( $src.'orderforms', 'folderbackupfiles', true, $tpl.'orderforms', true ) );
			$data['message'] = array_merge( $data['message'], $this->_fileHandler( $src.'orderforms', 'foldercopyfiles', true, $tpl.'orderforms', true ) );
			
			$data['nextstep'] = $step + 5;
			break;
		
		/* ----------------------------------------------------------------- STEP 140 *\
		 * INSTALLATION PROCEDURE - Install Image Files
		\* -------------------------------------------------------------------------- */
		case 140:			// Install Image Files
		case 240:			// Upgrade Image Files
			$src	= JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.'whmcs'.DS.'images';
			$img	= $path.DS.'images';
			
			$data['message'] = $this->_fileHandler($src, 'foldercopyfiles', true, $img, true );
			$data['nextstep'] = $step + 5;
			break;
			
		/* ----------------------------------------------------------------- STEP 145 *\
		 * INSTALLATION PROCEDURE - Install Includes Files
		\* -------------------------------------------------------------------------- */
		case 145:			// Install Hook Files
		case 245:			// Upgrade Hook Files
			$src	= JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.'whmcs'.DS.'includes';
			$hook	= $path.DS.'includes';
			
			$data['message'] = $this->_fileHandler( $src, 'foldercopyfiles', true, $hook, true );
			$data['nextstep'] = $step + 5;
			break;
			
		/* ----------------------------------------------------------------- STEP 150 *\
		 * INSTALLATION PROCEDURE - Check License
		\* -------------------------------------------------------------------------- */
		case 150:			// Install Check J!WHMCS License
		case 250:			// Upgrade Check J!WHMCS License
			$license = trim( urldecode( JRequest::getVar( 'license' ) ) );
			
			if ($license) {
				$this->params['licensekey'] = $license;
				$this->_saveParams($this->params, $this->params['id']);
			}
			
			$this->_fileHandler(JPATH_COMPONENT_ADMINISTRATOR.DS.'license.txt', 'delete', false);
				
			$params	= & JComponentHelper::getParams('com_jwhmcs');
			$data = $this->checkLicense(&$params);
			
			if ($data['valid']) {
				$data['message'][]	= "License validated";
				$data['nextstep'] = ( $step + 10 );
			} else {
				$data['nextstep'] = $step;
			}
			
			break;
			
		/* ----------------------------------------------------------------- STEP 160 *\
		 * INSTALLATION PROCEDURE - Check WHMCS API Credentials
		\* -------------------------------------------------------------------------- */
		case 160:			// Check WHMCS API Credentials
		case 260:			// Check WHMCS API Credentials
			$jwhmcsadminus	= trim( urldecode( JRequest::getVar( 'jwhmcsadminus' ) ) );
			$jwhmcsadminpw	= trim( urldecode( JRequest::getVar( 'jwhmcsadminpw' ) ) );
			$accesskey		= trim( urldecode( JRequest::getVar( 'accesskey' ) ) );
			
			$this->params['jwhmcsadminus'] = $jwhmcsadminus;
			$this->params['jwhmcsadminpw'] = $jwhmcsadminpw;
			$this->params['accesskey'] = $accesskey;
			$this->_saveParams($this->params, $this->params['id']);
			
			$data = $this->_getApiConnection();
			$data['nextstep'] = ( $data['valid'] ? $step + 10 : $step );
			break;
			
		/* ----------------------------------------------------------------- STEP 170 *\
		 * INSTALLATION PROCEDURE - Create Client Menu
		\* -------------------------------------------------------------------------- */
		case 170:			// Install Create Client Menu
		case 270:			// Upgrade Create Client Menu
			$data['message'][]	= $this->_menuHandler('client', 'typeadd');
			$data['message']	= array_merge($data['message'], $this->_menuHandler('client', 'itemsadd'));
			
			$data['nextstep'] = ( $step + 10 );
			break;
		
		/* ----------------------------------------------------------------- STEP 180 *\
		 * INSTALLATION PROCEDURE - Synchronize Users
		\* -------------------------------------------------------------------------- */
		case 180:			// Install sync users
		case 280:			// Upgrade sync users
			include('usermgr.php');
			
			$result = JwhmcsModelUsermgr::matchAll();
			$data['message'][] = $result ? "User Synchronization Performed" : "User Synchronization Failed!";
			$data['nextstep'] = ($step == 170 ? 999 : 989 );
			break;
		/* ----------------------------------------------------------------- STEP 988 *\
		 * ABORT PROCEDURE - Deactivate plugins, reactivate J! plugins
		\* -------------------------------------------------------------------------- */
		case 988:			// Upgrade aborted - deactivate new plugins, reactivate Joomla
			$data['message'][]	= $this->_pluginHandler('auth', 'deactivate' );
			$data['message'][]	= $this->_pluginHandler('sysm', 'deactivate' );
			$data['message'][]	= $this->_pluginHandler('sysmlang', 'deactivate' );
			$data['message'][]	= $this->_pluginHandler('user', 'deactivate' );
			$data['message'][]	= $this->_pluginHandler('jauth', 'activate' );
			$data['message'][]	= "Installation aborted by user";
			
		/* ----------------------------------------------------------------- STEP 989 *\
		 * WRAPUP PROCEDURE - Final task just in case we add something later
		\* -------------------------------------------------------------------------- */
		case 989:			// Upgrade wrap up - write log file
			$data['message'][]	= "Upgrade completed";
			$data['nextstep']	= 1000;
			break;
		/* ----------------------------------------------------------------- STEP 998 *\
		 * ABORT PROCEDURE - Deactivate plugins, reactivate J! plugins
		\* -------------------------------------------------------------------------- */
		case 998:			// Installation aborted - deactivate new plugins, reactivate Joomla
			
			$data['message'][]	= "$jname Authentication Plugin ".( $this->_pluginHandler( 'auth', 'deactivate' ) ? "deactivated" : "failed to deactivate" );
			$data['message'][]	= "$jname System Plugin ". ( $this->_pluginHandler( 'sysm', 'deactivate' ) ? "deactivated" : "failed to deactivate" );
			$data['message'][]	= "$jname System Language Plugin " . ( $this->_pluginHandler( 'sysmlang', 'deactivate' ) ? "deactivated" : "failed to deactivate" );
			$data['message'][]	= "$jname User Plugin " . ( $this->_pluginHandler( 'user', 'deactivate' ) ? "deactivated" : "failed to deactivate" );
			$data['message'][]	= "Joomla Authentication Plugin " . ( $this->_pluginHandler( 'jauth', 'activate' ) ? "reactivated" : "FAILED TO REACTIVATE - DO NOT LOG OUT OF JOOMLA BEFORE RE-ENABLING JOOMLA PLUGIN!" );
			$data['message'][]	= "Installation aborted by user";
			
		/* ----------------------------------------------------------------- STEP 999 *\
		 * WRAPUP PROCEDURE - Final task just in case we add something later
		\* -------------------------------------------------------------------------- */
		case 999:			// Interview wrap up - write log file
			$data['message'][]	= "Installation completed";
			$data['nextstep']	= 1000;
			break;
		endswitch;
		$data['message'][] = '<hr size="1" style="margin: 0; padding: 0px; " />';
		return $data;
	}
	
	
	/* ----------------------------------------- *\
	 *              SUB FUNCTIONS                *
	\* ----------------------------------------- */
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_pluginHandler (private)
	 * Purpose:		Takes care of all plugin handling for installer
	 * As of:		version 2.0.2 (March 2010)
	\* ------------------------------------------------------------ */
	private function _pluginHandler( $plugin, $task = 'exists', $verbose = true, $options = null )
	{
		// Initialize variables first
		$plg		= $this->plugins[$plugin];
		$db			= & JFactory::getDBO();
		$path		= JFolder::makesafe(JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.$plg['path']);
		$installer	= new JInstaller;
		
		// Make a query to the database to retrieve the plugin id if it is there
		$query	= "SELECT `id`, `published` FROM #__plugins WHERE `element` = '" . $plg['element'] . "' AND `folder` = '" . $plg['folder'] ."'";
		$db->setQuery($query);
		$result	= $db->loadAssoc();
		
		// Switch off on tasks
		switch($task):
		
		// Check if the plugin exists
		case 'exists':
			
			// If not verbose then send either the id or false back
			if (! $verbose) return ( $result ? $result['id'] : false );
			
			return ( $result ? JText::sprintf( 'INSTALL_PLG_DOESEXIST', $plg['element'] ) : JText::sprintf( 'INSTALL_PLG_ERROR_7', $plg['element'] ) );
			break;
		
		// Activate or Deactivate the plugin
		case 'activate':
		case 'deactivate':
			
			// Set the value based on the task
			$pub	= ( $task == 'activate' ? 1 : 0 );
			
			// Set the text response based on the task
			$txt	= ( $task == 'activate' ? '' : 'de' );
			
			// Make a call to do the update
			$return = $this->_pluginHandler($plugin, 'update', false, array('published' => $pub));
			
			// If not verbose then send back the result as it was received
			if (! $verbose) return $return;
			
			return ( $return ? JText::sprintf( 'INSTALL_PLG_ACTIVAT_SUCCESS', $plg['element'], $txt ) : JText::sprintf( 'INSTALL_PLG_ERROR_4', $txt, $plg['element'] ) );
			break;
			
		// Install the plugin
		case 'install':
			
			// First check to see if the source files exist
			if (! JFolder::exists($path))
				return (! $verbose ? false : JText::sprintf( 'INSTALL_PLG_ERROR_1', $plg['element'] ) );
			
			// Now check to see if it already exists - if it does, uninstall so we can install the new one
			if ($result) {
				if (! $this->_pluginHandler( $plugin, 'uninstall', false ) )
					return (! $verbose ? false : JText::sprintf( 'INSTALL_PLG_ERROR_2', $plg['element'] ) );
			}
			
			// Now perform the actual installation
			if (! $installer->install($path))
				return (! $verbose ? false : JText::sprintf( 'INSTALL_PLG_ERROR_3', $plg['element'] ) );
			else
				if (! $this->_pluginHandler( $plugin, 'activate', false ) ) {
					return (! $verbose ? false : JText::sprintf( 'INSTALL_PLG_ERROR_8', $plg['element'] ) );
				} else {
					return (! $verbose ? true : JText::sprintf( 'INSTALL_PLG_INSTALL_SUCCESS', $plg['element'] ) );
				}
			break;
			
		// Uninstall the plugin
		case 'uninstall':
			
			// Lets see if we found the plugin
			if ($result) {
				
				// Perform uninstall
				$return = $installer->uninstall( 'plugin', $result['id'] );
				
				// If not verbose then send back the result as it was received
				if (! $verbose) return $return;
				
				return ( $return ? JText::sprintf( 'INSTALL_PLG_UNINSTA_SUCCESS', $plg['element'] ) : JText::sprintf( 'INSTALL_PLG_ERROR_5', $plg['element'] ) );
			}
			// Plugin wasn't found
			else {
				
				// If not verbose then send back false else send back text
				return (! $verbose ? false : JText::sprintf('INSTALL_PLG_ERROR_6', $plg['element'] ) );
			}
			break;
		case 'update':
			
			// Test first to see if we received options and if they are an array
			if (is_null($options) || (! is_array($options))) {
				
				// If not verbose then send back false else send back text
				return (! $verbose ? false : JText::sprintf( 'INSTALL_PLG_ERROR_A', $plg['element'] ) );
			}
			
			// Initialize query array
			$q = array();
			
			// Cycle through each option creating the queries
			foreach ($options as $k => $v) {
				$q[] = sprintf("UPDATE `#__plugins` SET `%s` = '%s' WHERE `id` = %d", $k, $v, $result['id'] );
			}
			
			// Cycle through each query
			foreach ($q as $query)
			{
				$db->setQuery($query);
				$result = $db->query();
				
				// If the update failed - Note: if failure occurs, the whole process fails and is sent back
				if (! $result) {
					
					// If not verbose then send back false else send back text
					return (! $verbose ? false : JText::sprintf( 'INSTALL_PLG_ERROR_9', $plg['element']) );
				}
				else {
					
					// Create the messages to send back
					$return[] = JText::sprintf( 'INSTALL_PLG_UPDATE_SUCCESS', $plg['element'], $k, $v );
				}
			}
			
			// Clean up return variable - if not verbose just send back true
			return (! $verbose ? true : $return );
			break;
		endswitch;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_menuHandler (private)
	 * Purpose:		Takes care of all menu handling for installer
	 * As of:		version 2.0.2 (March 2010)
	\* ------------------------------------------------------------ */
	private function _menuHandler($name, $task = 'typeexists', $item = null, $verbose = true)
	{
		// Initialize variables
		$db		= & JFactory::getDBO();
		$menu	= $this->mtypes[$name];
		$mitem	= $this->mitems[$name][$item];
		
		// Switch off on tasks
		switch ($task):
		
		// Check if the menu type exists
		case 'typeexists':
			
			// Query to see if the menu type exists
			$query = sprintf("SELECT `id` FROM `#__menu_types` WHERE `menutype` = '%s'", $menu['menutype']);
			$db->setQuery($query);
			$result = $db->loadResult();
			
			// If not verbose then send back false or id
			if (!$verbose) return $result;
			
			// Build text response based on result
			$does = ( $result ? '' : 'not ' );
			return JText::sprintf( 'INSTALL_MENU_TYPE_EXIST', $menu['title'], $does );
			break;
			
		// Add the menu type to the database
		case 'typeadd':
			
			// Check to see if the menu type doesn't exist
			if (! $this->_menuHandler($name, 'typeexists', null, false)) {
				
				// Query to add menu type to database
				$query = "INSERT INTO `#__menu_types` (`menutype`, `title`, `description`) VALUES ".
							"('".$menu['menutype']."', '".$menu['title']."', '".$menu['desc']."')";
				$db->setQuery($query);
				$result = $db->query();
				
				// If not verbose then send back result
				if (! $verbose) return $result;
				
				// Build text response based on result
				$was = ( $result ? '' : 'not ' );
				return JText::sprintf( 'INSTALL_MENU_TYPE_ADD', $menu['title'], $was );
			}
			// Menu type does exist
			else {
				
				// If not verbose send back false else send back text
				return (! $verbose ? false : JText::sprintf( 'INSTALL_MENU_TYPE_EXIST', $menu['title'], '') );
			}
			break;
			
		// Check if the menu item exists already
		case 'itemexists':
			
			// Query for the menu item
			$query = sprintf("SELECT `id` FROM `#__menu` WHERE `menutype` = '%s' AND `alias` = '%s'", $menu['menutype'], $mitem[1]);
			$db->setQuery($query);
			$result = $db->loadResult();
			
			// If not verbose then send back result
			if (! $verbose) return $result;
			
			// Build text response based on result
			$does = ( $result ? 'already exists' : 'does not exist' );
			return JText::sprintf( 'INSTALL_MENU_ITEM_EXIST', $mitem[0], $menu['title'], $does);
			break;
			
		// Add the menu item to the database
		case 'itemadd':
			
			// Chceck to make sure the menu item doesn't already exist
			if (! $this->_menuHandler($name, 'itemexists', $item, false)) {
				
				// Query to add menu item to the database
				$query	= "INSERT INTO `#__menu` (`menutype`, `name`, `alias`, `link`, `type`, `published`, `componentid`, `ordering`, `params`) VALUES
							('".$menu['menutype']."', '{$mitem[0]}', '{$mitem[1]}', '{$mitem[2]}', '{$mitem[3]}', '{$mitem[4]}', '{$mitem[5]}', '{$mitem[6]}', '{$mitem[7]}')";
				$db->setQuery($query);
				$result	= $db->query();
				
				// If not verbose then send back result
				if (! $verbose) return $result;
				
				// Build response based on result
				$was = ( $result ? '' : 'not ' );
				return JText::sprintf( 'INSTALL_MENU_ITEM_ADD', $mitem[0], $menu['title'], $was );
			}
			// The menu item exists already
			else {
				
				// If not verbose then send back false else send back text
				return (! $verbose ? false : JText::sprintf( 'INSTALL_MENU_ITEM_EXIST', $mitem[0], $menu['title'], 'already exists' ) );
			}
			break;
			
		// Add multiple items to the database
		//		Note that only a verbose response is possible
		case 'itemsadd':
			
			// Cycle through each menu item
			foreach ($this->mitems[$name] as $k => $v ){
				
				// Build response array
				$return[] = $this->_menuHandler($name, 'itemadd', $k );
			}
			
			// Send back response
			return $return;
			break;
		endswitch;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_fileHandler (private)
	 * Purpose:		Takes care of all file handling for installer
	 * As of:		version 2.0.2 (March 2010)
	\* ------------------------------------------------------------ */
	private function _fileHandler($src, $task = 'exists', $verbose = true, $dst = null, $overwrite = false )
	{
		// Switch off on tasks
		switch($task):
		// Check to see if the file exists
		case 'exists':
			
			// Check existance
			$result = JFile::exists($src);
			
			// If not verbose send result
			if (! $verbose) return $result;
			
			// Build response based on result
			$txt = ($result ? 'does' : 'does not' );
			return JText::sprintf( 'INSTALL_FILE_EXIST', $src, $txt );
			break;
		
		// Copy the file over to the new location
		case 'copy':
			
			// Check to see if dst is null
			if (is_null($dst)) return (! $verbose ? false : JText::sprintf( 'INSTALL_FILE_ERROR_1', $src ) );
			
			// Check if the file exists
			if ($this->_fileHandler($dst, 'exists', false ) ) {
				
				// Should we delete the destination?
				if ($overwrite) {
					
					// We can overwrite, so we delete destination
					if (! $this->_fileHandler($dst, 'delete', false) ) {
						
						// There was a problem deleting destination so fail
						return (! $verbose ? false : JText::sprintf( 'INSTALL_FILE_ERROR_3', $dst) );
					}
				}
				// We can't delete destination so we fail
				else {
					return (! $verbose ? false : JText::sprintf( 'INSTALL_FILE_ERROR_2', $dst ) );
				}
			}
			
			// At this point the destination file doesn't exist so proceed with copy
			$result = JFile::copy($src, $dst);
			
			// If not verbose send result
			if (! $verbose ) return $result;
			
			// Build response based on result
			$txt = ($result ? 'was' : 'was not' );
			return JText::sprintf( 'INSTALL_FILE_COPIED', $src, $txt );
			break;
		
		// Delete the file specified
		case 'delete':
			
			// Check to see if the file exists
			if (! $this->_fileHandler($src, 'exists', false ) ) {
				
				// If not verbose then false else send text
				return (! $verbose ? false : JText::sprintf( 'INSTALL_FILE_ERROR_4', $src) );
			}
			
			// Delete the file
			$result = JFile::delete($src);
			
			// If not verbose send result
			if (! $verbose ) return $result;
			
			// Build response based on result
			$txt = ( $result ? 'was' : 'was not' );
			return JText::sprintf( 'INSTALL_FILE_DELETED', $src, $txt );
			break;
		
		// Create a new folder
		case 'foldercreate':
			
			// Check existance of folder prior to creation
			if (! $this->_fileHandler($src, 'folderexists', false)) {
				
				// If not verbose then false else send text
				return (! $verbose ? false : JText::sprintf( 'INSTALL_FOLDER_ERROR_6', $src ) );
			}
			
			// Create folder
			$result = JFile::create($src);
			
			// If not verbose send result
			if (! $verbose) return $result;
			
			// Build response based on result
			$txt = ($result ? 'was' : 'was not' );
			return JText::sprintf( 'INSTALL_FOLDER_CREATE', $src, $txt );
			break;
			
		// Check to see if the folder exists
		case 'folderexists':
			
			// Check existance
			$result = JFolder::exists($src);
			
			// If not verbose send result
			if (! $verbose) return $result;
			
			// Build response based on result
			$txt = ($result ? 'does' : 'does not' );
			return JText::sprintf( 'INSTALL_FOLDER_EXIST', $src, $txt );
			break;
			
		// Copy an entire folder over
		case 'foldercopy':
			
			// Check to see if dst is null
			if (is_null($dst)) return (! $verbose ? false : JText::sprintf( 'INSTALL_FOLDER_ERROR_1', $src ) );
			
			// Check to see if the source folder exists
			if (! $this->_fileHandler($src, 'folderexists', false ) ) {
				
				// If not verbose then false else send text
				return (! $verbose ? false : JText::sprintf( 'INSTALL_FOLDER_ERROR_5', $src) );
			}
			
			// Check to see if the destination folder exists
			if ( $this->_fileHandler( $dst, 'folderexists', false ) ) {
				
				// Should we delete the destination?
				if ($overwrite) {
					
					// We can overwrite, so we delete destination
					if (! $this->_fileHandler($dst, 'folderdelete', false) ) {
						
						// There was a problem deleting destination so fail
						return (! $verbose ? false : JText::sprintf( 'INSTALL_FOLDER_ERROR_3', $dst) );
					}
				}
				// We can't delete destination so we fail
				else {
					return (! $verbose ? false : JText::sprintf( 'INSTALL_FOLDER_ERROR_2', $dst ) );
				}
			}
			
			// At this point the destination file doesn't exist so proceed with copy
			$result = JFolder::copy($src, $dst);
			
			// If not verbose send result
			if (! $verbose ) return $result;
			
			// Build response based on result
			$txt = ($result ? 'was' : 'was not' );
			return JText::sprintf( 'INSTALL_FOLDER_COPIED', $src, $txt );
			break;
			
		// Delete the folder specified
		case 'folderdelete':
			
			// Check to see if the folder exists
			if (! $this->_fileHandler($src, 'folderexists', false ) ) {
				
				// If not verbose then false else send text
				return (! $verbose ? false : JText::sprintf( 'INSTALL_FOLDER_ERROR_4', $src) );
			}
			
			// Delete the file
			$result = JFolder::delete($src);
			
			// If not verbose send result
			if (! $verbose ) return $result;
			
			// Build response based on result
			$txt = ( $result ? 'was' : 'was not' );
			return JText::sprintf( 'INSTALL_FOLDER_DELETED', $src, $txt );
			break;
			
		// Copy files from src folder with messages
		//		Note that only a verbose array response is possible
		case 'foldercopyfiles':
			
			// Initialize array variables
			$return	= array();
			$ret	= array();
			
			// Check to see if the folder exists
			if (! $this->_fileHandler($src, 'folderexists', false ) ) {
				
				// If not verbose then false else send text
				return array( JText::sprintf( 'INSTALL_FOLDER_ERROR_4', $src) );
			}
			
			$folders = JFolder::folders($src);
			$files = JFolder::files($src);
			
			$files = array_merge($files, $folders);
			
			foreach ($files as $f) {
				$ret = $this->_fileHandler( $src.DS.$f, ( is_dir( $src.DS.$f ) ? 'foldercopyfiles' : 'copy' ), true, $dst.DS.$f, true );
				if (! is_array($ret)) $ret = array($ret);
				$return = array_merge($return, $ret);
				unset($ret);
			}
			
			return $return;
			break;
			
		// Backup files found in copy directory
		//		Note that only a verbose array response is possible
		case 'folderbackupfiles':
			
			// Initialize array variables
			$return = array();
			$ret	= array();
			
			// Check to see if the source exists
			if (! $this->_fileHandler($src, 'folderexists', false ) ) {
				
				return array( JText::sprintf( 'INSTALL_BACKUP_ERROR_1', $src ) );
			}
			
			$folders = JFolder::folders($src);
			$files = JFolder::files($src);
			
			$files = array_merge($files, $folders);
			
			// Cycle through files found
			foreach ($files as $f) {
				
				// Check first if file is actually a folder
				if (is_dir( $src.DS.$f)) {
					$ret = $this->_fileHandler($src.DS.$f, 'folderbackupfiles', true, $dst.DS.$f, true );
				}
				else {
				
					// Create backup filename
					$tmp = explode(".", $f);
					array_pop( $tmp );
					$bak = implode(".", $tmp).'.jwhmcs';
					
					// Check to see if the backup already exists
					if ( $this->_fileHandler($dst.DS.$bak, 'exists', false) ) continue;
					
					// Copy file to backup
					$ret = $this->_fileHandler($dst.DS.$f, 'copy', true, $dst.DS.$bak, true);
				}
				
				// Combine responses into one array
				if (! is_array($ret)) $ret = array($ret);
				$return = array_merge($return, $ret);
				unset($ret);
			}
			
			return $return;
			break;
			
		// Read a file into the buffer
		case 'readbuffer':
			
			// Check to see if the file exists
			if (! $this->_fileHandler($src, 'exists', false)) {
				
				// If not verbose then false else send text
				return (! $verbose ? false : JText::sprintf( 'INSTALL_BUFFER_ERROR_1', $src ) );
			}
			
			// Now read the file into the buffer
			$this->buffer = JFile::read( $src );
			
			if (! $verbose) return ( ! $this->buffer ? false : true );
			
			// Build response based on result
			$txt = ( ! $this->buffer ? 'was not' : 'was' );
			return JText::sprintf( 'INSTALL_BUFFER_READ', $src, $txt );
			break;
			
		// Write the buffer to the file
		//		$src is the destintion in this instance
		case 'writebuffer':
			
			// Check to see if the file exists
			if ( $this->_fileHandler( $src, 'exists', false ) ) {
				
				// Can we overwrite the file
				if ($overwrite) {
					
					// We can overwrite, so we delete destination
					if (! $this->_fileHandler($src, 'filedelete', false) ) {
						
						// There was a problem deleting destination so fail
						return (! $verbose ? false : JText::sprintf( 'INSTALL_BUFFER_ERROR_3', $src) );
					}
				}
				// We can't delete destination so we fail
				else {
					return (! $verbose ? false : JText::sprintf( 'INSTALL_FOLDER_ERROR_2', $src ) );
				}
			}
			
			// Check to see if the buffer is null
			if (! $this->buffer) {
				
				// If not verbose then false else send text
				return (! $verbose ? false : JText::sprintf( 'INSTALL_BUFFER_ERROR_4', $src ) );
			}
			
			$result = JFile::write( $src, $this->buffer );
			
			// If not verbose send result
			if (! $verbose ) return $result;
			
			// Build response based on result
			$txt = ( $result ? 'was' : 'was not' );
			return JText::sprintf( 'INSTALL_BUFFER_WRITTEN', $src, $txt );
			break;
		endswitch;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_setToArray (private)
	 * Purpose:		Sets an array forcing all to lowercase
	 * As of:		version 2.0.2 (March 2010)
	\* ------------------------------------------------------------ */
	private function _setToArray($settings)
	{
		foreach ($settings as $v) {
			$ret[strtolower($v['setting'])] = $v['value'];
		}
		return $ret;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_comId (private)
	 * Purpose:		Retrieves the id for the component
	 * As of:		version 2.0.2 (March 2010)
	\* ------------------------------------------------------------ */
	private function _comId()
	{
		$db =& JFactory::getDBO();
		
		// Find the installed instance of com_jwhmcs and pull the id for storage
		$query	= 'SELECT `id` FROM #__components WHERE `option`="com_jwhmcs"';
		$db->setQuery($query);
		return $db->loadResult();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getApiConnection (private)
	 * Purpose:		Checks the Connection to the API
	 * As of:		version 2.0.2 (March 2010)
	\* ------------------------------------------------------------ */
	private function _getApiConnection()
	{
		$jcurl = & JwhmcsCurl::getInstance();
		
		$jcurl->setAction('getclientsdata', array('clientid' => 1));
		$data	= $jcurl->loadResults();
		
		if (is_array($data[0])) $data = $data[0];
		
		if ( $data['result'] == 'success' ) {
			$ret['valid'] = true;
			$ret['message'][] = 'API Successfully connected!';
		}
		else {
			if ($data['message'] == 'Client Not Found' || $data['message'] == 'Client ID Not Found') {
				$ret['valid'] = true;
				$ret['message'][] = 'API Successfully connected!';
			}
			elseif (empty($data)) {
				$ret['valid'] = false;
				$ret['message'][] = $jcurl->info['http_code'].' received with URL';
			}
			else {
				$ret['valid'] = false;
				$ret['message'][] = $data['message'];
			}
			
		}
		return $ret;
	}
}