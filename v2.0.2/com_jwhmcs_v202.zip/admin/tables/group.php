<?php
/**
 * Hello World table class
 * 
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_4
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Hello Table class
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class TableGroup extends JTable
{
	var $id			= null;
	var $fname		= null;
	var	$lname		= null;
	var $cname		= null;
	var $email		= null;
	var $password	= null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableGroup(& $db) {
		parent::__construct('#__jwhmcs_group', 'id', $db);
	}
}