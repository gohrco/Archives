<?php
/**
 * WHMCS User Synchrization View for J!WHMCS Integrator
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since		1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsViewSync
 * Extends:		JView
 * Purpose:		Used as the WHMCS User Synchrization view
 * 
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsViewInstall extends JView
{
	/* ------------------------------------------------------------ *\
	 * Method:		display
	 * Purpose:		Assembles the page for the application to send to
	 * 				the user
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function display($tpl = null)
	{
		$model	= & $this->getModel( 'install' );
		$task	= JRequest::getVar( 'task' );
		$data	= $model->$task();
		
		switch($task):
		case 'steptwo' :
			JToolBarHelper :: title( JText::_( 'JWHMCS_ADMIN_INSTALL_TITLE' ).': <small><small>[ ' . JText::_( 'JWHMCS_ADMIN_INSTALL_STEPTWO' ).' ]</small></small>', 'install.png' );
			JToolBarHelper :: custom( 'abort', 'abort.png', '', JText::_( 'JWHMCS_ADMIN_BUTTON_STOP' ), false, false );
			JToolBarHelper :: custom( 'stepthree', 'forward.png', '', JText::_( 'JWHMCS_ADMIN_BUTTON_NEXT' ), false, false );
			JToolBarHelper :: divider();
			JToolBarHelper :: help('jwhmcs.install.2o4', true);
			break;
		case 'stepthree' :
			JToolBarHelper :: title( JText::_( 'JWHMCS_ADMIN_INSTALL_TITLE' ).': <small><small>[ ' . JText::_( 'JWHMCS_ADMIN_INSTALL_STEPTHREE' ).' ]</small></small>', 'install.png' );
			JToolBarHelper :: custom( 'abort', 'abort.png', '', JText::_( 'JWHMCS_ADMIN_BUTTON_STOP' ), false, false );
			JToolBarHelper :: custom( 'stepfour', 'forward.png', '', JText::_( 'JWHMCS_ADMIN_BUTTON_NEXT' ), false, false );
			JToolBarHelper :: divider();
			JToolBarHelper :: help('jwhmcs.install.3o4', true);
			break;
		case 'stepfour':
			JToolBarHelper :: title( JText::_( 'JWHMCS_ADMIN_INSTALL_TITLE' ).': <small><small>[ ' . JText::_( 'JWHMCS_ADMIN_INSTALL_STEPFOUR' ).' ]</small></small>', 'install.png' );
			JToolBarHelper :: custom( 'abort', 'abort.png', '', JText::_( 'JWHMCS_ADMIN_BUTTON_STOP' ), false, false );
			JToolBarHelper :: custom( 'stepfive', 'forward.png', '', JText::_( 'JWHMCS_ADMIN_BUTTON_NEXT' ), false, false );
			JToolBarHelper :: divider();
			JToolBarHelper :: help('jwhmcs.install.4o4', true);
			break;
		case 'apiconxn' :
			JToolBarHelper :: title( JText::_( 'JWHMCS_ADMIN_CHECK_API' ), 'apiconxn.png' );
			JToolBarHelper :: custom( 'apiconxnAccept', 'save.png', '', JText::_( 'JWHMCS_ADMIN_BUTTON_APICONSV' ), false, false );
			JToolBarHelper :: divider();
			JToolBarHelper :: help('jwhmcs.apiconxn', true);
			break;
		case 'license' :
			JToolBarHelper :: title( JText::_( 'JWHMCS_ADMIN_CHECK_LIC' ), 'license.png' );
			JToolBarHelper :: custom( 'licenseAccept', 'save.png', '', JText::_( 'JWHMCS_ADMIN_BUTTON_LICSAVE' ), false, false );
			JToolBarHelper :: divider();
			JToolBarHelper :: help('jwhmcs.license', true);
			break;
		case 'interview':
			JToolBarHelper :: title( JText::_( 'JWHMCS_ADMIN_INSTALL_TITLE' ).': <small><small>[ ' . JText::_( 'JWHMCS_ADMIN_INSTALL_INTERVIEW' ).' ]</small></small>', 'settings.png' );
			break;
		case 'manual' :
		default:
			JToolBarHelper :: title( JText::_( 'JWHMCS_ADMIN_INSTALL_TITLE' ).': <small><small>[ ' . JText::_( 'JWHMCS_ADMIN_INSTALL_MANUAL' ).' ]</small></small>', 'install.png' );
			JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
			JToolBarHelper::divider();
			JToolBarHelper::help('jwhmcs.install.manual', true);
		endswitch;
		
		JHTML::script('ajax.js', 'administrator/components/com_jwhmcs/js/', true);
		JHTML::stylesheet( 'install.css', 'administrator/components/com_jwhmcs/assets/' );
		
		$this->assignRef('data', $data);
		parent::display($tpl);
	}
}