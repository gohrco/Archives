<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');

$data = $this->data;
$j32jwhmcs = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-jwhmcs.png';
$j48check = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-48-chinst.png';
$j32yes = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-yes.png';
$j16yes = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-16-yes.png';
$j32no = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-no.png';
$j16no = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-16-no.png';
?>
<style type="text/css">
.icon-48-chinst{
	background-image: url('<?php echo $j48check; ?>');	
}
.icon-32-jwhmcs {
	background-image: url('<?php echo $j32jwhmcs; ?>');	
}
table.adminlist thead tr {
	border-spacing: 0px;
}
table.adminlist thead tr th.hdr {
	border-bottom: 0px;
	font-size: 12pt;
	line-height: 1.1em;
	margin: 0px;
	padding: 4px 0px;
}
table.adminlist tr td.status {
	vertical-align: top;
	text-align: center;
}
table.adminlist tr td.title, table.adminlist tr td.title2 {
	font-weight: bold;
	text-align: center;
	vertical-align: top;
}
table.adminlist tr td.value {
	font-weight: bold;
	text-align: center;
	vertical-align: top;
}
table.adminlist tr td.detail {
	vertical-align: top;
	font-style: italic;
}
table.adminlist tr td.title2 {
	border-left: 1px solid #999999;
}
</style>

<table class="adminlist">
	<thead>
		<tr>
			<th colspan="4" class="hdr">
				Basic Settings
			</th>
		</tr>
		<tr>
			<th width="30">
				Status
			</th>
			<th width="150">
				Setting
			</th>
			<th width="250">
				Value
			</th>
			<th>
				Explanation
			</th>
		</tr>
	</thead>
	<?php 
	$valid	= ( strtolower($data['configdir']) == strtolower(JPATH_CONFIGURATION) ? true : false );
	$img	= ( $valid ? $j32yes : $j32no );
	?>
	<tr class="row0">
		<td align="center" class="status">
			<p><img src ="<?php echo $img; ?>" /></p>
		</td>
		<td class="title">
			<p>Joomla Configuration Directory</p>
		</td>
		<td class="value">
			<p><?php echo $data['configdir']; ?></p>
		</td>
		<td class="detail">
			<p>This is the directory path you entered in the "jconfig.php" file in WHMCS.  This directory should point to the same directory as this Joomla install.</p>
			<p><img src="<?php echo $j16yes; ?>" /> = Directory is correct<br />
			<img src="<?php echo $j16no; ?>" /> = Directory is incorrect - double check the setting and try again.</p>
		</td>
	</tr>
	<?php $img = ($data['configexists'] ? $j32yes : $j32no ); ?>
	<tr class="row1">
		<td align="center" class="status">
			<p><img src ="<?php echo $img; ?>" /></p>
		</td>
		<td class="title">
			<p>Joomla Configuration File Found</p>
		</td>
		<td class="value">
			<p><?php echo ( $data['configexists'] ? 'Yes' : 'No' ); ?></p>
		</td>
		<td class="detail">
			<p>This indicates that J!WHMCS Integrator was able to find the configuration.php file in the directory you entered above.</p>
			<p><img src="<?php echo $j16yes; ?>" /> = configuration.php file found<br />
			<img src="<?php echo $j16no; ?>" /> = configuration.php file not found.  Check the setting for the Joomla Configuration Directory above.</p>
		</td>
	</tr>
	<?php $img = ($data['configreadable'] ? $j32yes : $j32no ); ?>
	<tr class="row0">
		<td align="center" class="status">
			<p><img src ="<?php echo $img; ?>" /></p>
		</td>
		<td class="title">
			<p>Joomla Configuration File Readable</p>
		</td>
		<td class="value">
			<p><?php echo ( $data['configreadable'] ? 'Yes' : 'No' ); ?></p>
		</td>
		<td class="detail">
			<p>This indicates that J!WHMCS Integrator was able to read the configuration.php file in the directory you entered above.</p>
			<p><img src="<?php echo $j16yes; ?>" /> = configuration.php file is readable.<br />
			<img src="<?php echo $j16no; ?>" /> = configuration.php file is not readable.  You may need to check the permissions for the file.</p>
		</td>
	</tr>
	<?php $img = ($data['curlinstalled'] ? $j32yes : $j32no ); ?>
	<tr class="row1">
		<td align="center" class="status">
			<p><img src ="<?php echo $img; ?>" /></p>
		</td>
		<td class="title">
			<p>CURL Installed</p>
		</td>
		<td class="value">
			<p><?php echo ( $data['curlinstalled'] ? 'Yes' : 'No' ); ?></p>
		</td>
		<td class="detail">
			<p>This indicates that the CURL library is installed on your server.  For most, this is not an issue.  If it for some reason is not installed, you need to install the library for PHP.  Contact php.net for more information on how to accomplish this.</p>
			<p><img src="<?php echo $j16yes; ?>" /> = CURL library installed.<br />
			<img src="<?php echo $j16no; ?>" /> = CURL library not installed.</p>
		</td>
	</tr>
</table>
<p>&nbsp;</p>
<table class="adminlist">
	<thead>
		<tr>
			<th colspan="4" class="hdr">
				J!WHMCS Licensing Information
			</th>
		</tr>
		<tr>
			<th width="30">
				Status
			</th>
			<th width="150">
				Setting
			</th>
			<th width="250">
				Value
			</th>
			<th>
				Explanation
			</th>
		</tr>
	</thead>
	<?php 
	$img	= ( $this->params->get( 'licensekey' ) ? $j32yes : $j32no );
	?>
	<tr class="row0">
		<td align="center" class="status">
			<p><img src ="<?php echo $img; ?>" /></p>
		</td>
		<td class="title">
			<p>J!WHMCS License</p>
		</td>
		<td class="value">
			<p><?php echo $this->params->get( 'licensekey' ); ?></p>
		</td>
		<td class="detail">
			<p>This is the license you have entered in the settings area.</p>
			<p><img src="<?php echo $j16yes; ?>" /> = License entered<br />
			<img src="<?php echo $j16no; ?>" /> = No license entered.</p>
		</td>
	</tr>
	<?php $img = ($data['licensevalid'] ? $j32yes : $j32no ); ?>
	<tr class="row1">
		<td align="center" class="status">
			<p><img src ="<?php echo $img; ?>" /></p>
		</td>
		<td class="title">
			<p>License Status</p>
		</td>
		<td class="value">
			<p><?php echo $data['license']; ?></p>
		</td>
		<td class="detail">
			<p>This indicates the status of your J!WHMCS Integrator license.</p>
			<p><img src="<?php echo $j16yes; ?>" /> = Active (for Owned or Leased licenses), Expired (for Owned licenses)<br />
			<img src="<?php echo $j16no; ?>" /> = Invalid or Suspended (for Owned or Leased licenses), Expired (for Leased licenses)</p>
		</td>
	</tr>
	<?php $img = ($data['licensevalid'] ? $j32yes : $j32no ); ?>
	<tr class="row0">
		<td align="center" class="status">
			<p><img src ="<?php echo $img; ?>" /></p>
		</td>
		<td class="title">
			<p>J!WHMCS Integrator Active</p>
		</td>
		<td class="value">
			<p><?php echo ( $data['licensevalid'] ? 'Yes' : 'No' ); ?></p>
		</td>
		<td class="detail">
			<p>This indicates that J!WHMCS Integrator is functional or not based on the status of your license.</p>
			<p><img src="<?php echo $j16yes; ?>" /> = Yes, J!WHMCS Integrator is functional.<br />
			<img src="<?php echo $j16no; ?>" /> = No, J!WHMCS Integrator is not functional - please contact Go Higher for more information.</p>
		</td>
	</tr>
</table>
<p>&nbsp;</p>
<table class="adminlist">
	<thead>
		<tr>
			<th colspan="4" class="hdr">
				WHMCS API Connection - Settings and Status
			</th>
		</tr>
		<tr>
			<th width="30">
				Status
			</th>
			<th width="150">
				Setting
			</th>
			<th width="250">
				Value
			</th>
			<th>
				Explanation
			</th>
		</tr>
	</thead>
	<?php 
	$url = $data['apiurl'];
	$valid = @fsockopen("$url", 80, $errno, $errstr, 30);
	$img	= ( $valid ? $j32no : $j32yes );
	?>
	<tr class="row0">
		<td align="center" class="status">
			<p><img src ="<?php echo $img; ?>" /></p>
		</td>
		<td class="title">
			<p>WHMCS API Url</p>
		</td>
		<td class="value">
			<p><?php echo $data['apiurl']; ?></p>
		</td>
		<td class="detail">
			<p>This is the URL that is used to connect to the WHMCS API interface.  The API Interface is the only method that J!WHMCS Integrator uses to interact with your WHMCS install.</p>
			<p><img src="<?php echo $j16yes; ?>" /> = URL exists<br />
			<img src="<?php echo $j16no; ?>" /> = URL does not exist - check the WHMCS URL you entered in your parameters, or verify WHMCS is installed properly.</p>
		</td>
	</tr>
	<?php $img = ($data['apiusername'] ? $j32yes : $j32no ); ?>
	<tr class="row1">
		<td align="center" class="status">
			<p><img src ="<?php echo $img; ?>" /></p>
		</td>
		<td class="title">
			<p>WHMCS API Username</p>
		</td>
		<td class="value">
			<p><?php echo $data['apiusername']; ?></p>
		</td>
		<td class="detail">
			<p>This is the username that is being used to connect to the WHMCS API Interface.  If you change your settings in WHMCS for this user, be sure to reflect any changes here.</p>
			<p><img src="<?php echo $j16yes; ?>" /> = Username entered in parameters<br />
			<img src="<?php echo $j16no; ?>" /> = Username not entered in parameters.  Double check your settings and try again.</p>
		</td>
	</tr>
	<?php $img = (($data['apiaccess'] == 'Successfully Connected!' ) ? $j32yes : $j32no ); ?>
	<tr class="row0">
		<td align="center" class="status">
			<p><img src ="<?php echo $img; ?>" /></p>
		</td>
		<td class="title">
			<p>WHMCS API Connection</p>
		</td>
		<td class="value">
			<p><?php echo $data['apiaccess']; ?></p>
		</td>
		<td class="detail">
			<p>This is the result of J!WHMCS Integrator attempting to connect to the WHMCS API Interface.  There are a number of possible results:</p>
			<p><img src="<?php echo $j16yes; ?>" /> = Successfully Connected!  J!WHMCS Integrator was able to establish a connection and retrieve data.<br />
			<img src="<?php echo $j16no; ?>" /> = Errors:</p>
			<ul><li><strong>Error Returned:  Invalid IP</strong> - The IP address for your server needs to be added to your WHMCS backend under General Settings > Security > Allowed API IP Address</li>
			<li><strong>Error Returned:  Access Denied</strong> - The Username and Password you entered did not allow access to the WHMCS API Interface.  Double check both the username and password, and also verify the account you are using has API privileges in the WHMCS Settings under Administrator Roles.</li>
			<li><strong>Error Returned:  Authentication Failed</strong> - The Username and Password you entered did not allow access to the WHMCS API Interface.  Double check both the username and password.</li></ul>
		</td>
	</tr>
</table>
<p>&nbsp;</p>
<table class="adminlist">
	<thead>
		<tr>
			<th colspan="3" class="hdr">
				Joomla Settings
			</th>
		</tr>
		<tr>
			<th width="150">
				Setting
			</th>
			<th width="150">
				Value
			</th>
			<th>
				Definition
			</th>
		</tr>
	</thead>
	<tr class="row0">
		<td class="title">
			<p>Joomla URL</p>
		</td>
		<td class="value">
			<p><?php echo $data['jurl']; ?></p>
		</td>
		<td class="detail">
			<p>This is the setting you have put in the parameters pointing to your Joomla web site URL.</p>
		</td>
	</tr>
	<tr class="row1">
		<td class="title">
			<p>Joomla Image URL</p>
		</td>
		<td class="value">
			<p><?php echo $data['jrootimgurl']; ?></p>
		</td>
		<td class="detail">
			<p>This should be identical to your Joomla URL setting, <u>unless:</u> a) you have your WHMCS installed on a subdomain, b) you only have one SSL certificate for that WHMCS subdomain, c) you are getting errors on SSL enabled pages in WHMCS.  If these three conditions are true, then you should take a copy of the Joomla template folder and copy it to your WHMCS / templates directory.  Then enter your WHMCS subdomain for this setting so when the site goes secure, it can find the images securely.</p>
		</td>
	</tr>
	<tr class="row0">
		<td class="title">
			<p>WHMCS URL</p>
		</td>
		<td class="value">
			<p><?php echo $data['whmcsurl']; ?></p>
		</td>
		<td class="detail">
			<p>This is the setting you have put in the parameters pointing to your WHMCS install.</p>
		</td>
	</tr>
	<tr class="row1">
		<td class="title">
			<p>Using SSL on WHMCS</p>
		</td>
		<td class="value">
			<p><?php echo ( $data['jssl'] ? 'Yes' : 'No' ); ?></p>
		</td>
		<td class="detail">
			<p>If you are using SSL on WHMCS, you should set this to Yes, otherwise your pages will not be SSL rendered.</p>
		</td>
	</tr>
</table>
<p>&nbsp;</p>
<table class="adminlist">
	<thead>
		<tr>
			<th colspan="3" class="hdr">
				Login, Logout and User Settings
			</th>
		</tr>
		<tr>
			<th width="150">
				Setting
			</th>
			<th width="150">
				Value
			</th>
			<th>
				Definition
			</th>
		</tr>
	</thead>
	<tr class="row0">
		<td class="title">
			<p>Joomla Username Creation</p>
		</td>
		<td class="value">
			<p><?php echo $data['jstorename']; ?></p>
		</td>
		<td class="detail">
			<p>If a user is being created in WHMCS first, the name of the user in Joomla will be combined in this manner from the fields in WHMCS.</p>
		</td>
	</tr>
	<tr class="row1">
		<td class="title">
			<p>Login Landing Page</p>
		</td>
		<td class="value">
			<p>http<?php echo ( $data['jinssl'] ? 's' : '' );?>://<?php echo $data['jin']; ?><br />
			Land with SSL?  <?php echo ( $data['jinssl'] ? 'Yes' : 'No' ); ?></p>
		</td>
		<td class="detail">
			<p>This is the landing page for your users when the login.  If you want SSL to be enabled upon landing, that is indicated as well.</p>
		</td>
	</tr>
	<tr class="row0">
		<td class="title">
			<p>Logout Landing Page</p>
		</td>
		<td class="value">
			<p>http<?php echo ( $data['joutssl'] ? 's' : '' );?>://<?php echo $data['jout']; ?><br />
			Land with SSL?  <?php echo ( $data['joutssl'] ? 'Yes' : 'No' ); ?></p>
		</td>
		<td class="detail">
			<p>This is the landing page for your users when they logout.  If you want SSL to be enabled upon landing, that is indicated as well.</p>
		</td>
	</tr>
	<tr class="row1">
		<td class="title">
			<p>Use SSL on WHMCS Redirects</p>
		</td>
		<td class="value">
			<p><?php echo ( $data['whmcsssl'] ? 'Yes' : 'No' ); ?></p>
		</td>
		<td class="detail">
			<p>If you have an SSL certificate, you can enable secure redirects here.</p>
		</td>
	</tr>
</table>
<p>&nbsp;</p>
<table class="adminlist">
	<thead>
		<tr>
			<th colspan="2" class="hdr">
				Software Versions
			</th>
			<th colspan="3" class="hdr">
				Aesthetic Settings
			</th>
		</tr>
		<tr>
			<th width="150">
				Software Package
			</th>
			<th width="75">
				Version
			</th>
			<th width="150">
				Setting
			</th>
			<th width="150">
				Value
			</th>
			<th>
				Definition
			</th>
		</tr>
	</thead>
	<tr class="row0">
		<td class="title">
			<p>J!WHMCS Version</p>
		</td>
		<td class="value">
			<p><?php echo $data['jwhmcsvers']; ?></p>
		</td>
		<td class="title2">
			<p>Load jquery.js</p>
		</td>
		<td class="value">
			<p><?php echo ( $data['jwhmcsjquery'] ? 'Yes' : 'No' ); ?></p>
		</td>
		<td class="detail">
			<p>For some of the javascript functionality of WHMCS pages, you need to have jquery.js loaded.  Sometimes you can already have it loaded in your Joomla template, and sometimes it conflicts with mootools.  If this is set to Yes then jquery.js will load on WHMCS pages.  If you are receiving javascript errors on WHMCS pages, try setting this to No.</p>
		</td>
	</tr>
	<tr class="row1">
		<td class="title">
			<p>J!WHMCS:  Authentication Plugin</p>
		</td>
		<td class="value">
			<p><?php echo ( ($this->params->get( 'authvers' ) ) ? $this->params->get( 'authvers' ) : 'Not found' ); ?></p>
		</td>
		<td class="title2">
			<p>Template Page for Logged In Users</p>
		</td>
		<td class="value">
			<p><a href="<?php echo $data['pagein']; ?>" target="_blank">Logged In Page</a></p>
		</td>
		<td class="detail">
			<p>This is the Joomla page that will be rendered around your WHMCS content for logged in users.</p>
		</td>
	</tr>
	<tr class="row0">
		<td class="title">
			<p>J!WHMCS:  System Plugin</p>
		</td>
		<td class="value">
			<p><?php echo ( ($this->params->get( 'sysmvers' ) ) ? $this->params->get( 'sysmvers' ) : 'Not found' ); ?></p>
		</td>
		<td class="title2">
			<p>Template Page for Logged Out Users</p>
		</td>
		<td class="value">
			<p><a href="<?php echo $data['pageout']; ?>" target="_blank">Logged Out Page</a></p>
		</td>
		<td class="detail">
			<p>This is the Joomla page that will be rendered around your WHMCS content for visitors.</p>
		</td>
	</tr>
	<tr class="row1">
		<td class="title">
			<p>J!WHMCS:  User Plugin</p>
		</td>
		<td class="value">
			<p><?php echo ( ( $this->params->get( 'uservers' ) ) ? $this->params->get( 'uservers' ) : 'Not found' ); ?></p>
		</td>
		<td class="title2">
			<p>Override Joomla Cache Setting</p>
		</td>
		<td class="value">
			<p><?php echo ($data['overridecache'] ? 'Yes' : 'No' ); ?></p>
		</td>
		<td class="detail">
			<p>If you are using Joomla cache on your site, but you don't want to enable the caching in J!WHMCS, you can override that setting and force J!WHMCS to render the template each time.</p>
		</td>
	</tr>
	<tr class="row0">
		<td class="title">
			<p>J!WHMCS Root File Version</p>
		</td>
		<td class="value">
			<p><?php echo $data['rootvers']; ?></p>
		</td>
		<td colspan="3" class="title2">
			<p>&nbsp;</p>
		</td>
	</tr>
	<tr class="row1">
		<td class="title">
			<p>J!WHMCS Hook File Version</p>
		</td>
		<td class="value">
			<p><?php echo $data['hookvers']; ?></p>
		</td>
		<td colspan="3" class="title2">
			<p>&nbsp;</p>
		</td>
	</tr>
	<tr class="row0">
		<td class="title">
			<p>WHMCS Version</p>
		</td>
		<td class="value">
			<p><?php echo $data['whmcsvers']; ?></p>
		</td>
		<td colspan="3" class="title2">
			<p>&nbsp;</p>
		</td>
	</tr>
</table>

<form action="index.php" method="post" name="adminForm">
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="check" />
</form>