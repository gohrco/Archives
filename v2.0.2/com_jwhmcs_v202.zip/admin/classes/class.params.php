<?php
/**
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id$
 * @since		1.5.3
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once ('class.database.php');

class JwhmcsParams
{
	
	/**
	 * @var instance to contain object when created
	 */
	private static $instance = null;
	
    /* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Called upon initialization of object class
	 * 
	 * As of:		version 1.5.3
	 * 
	 * Significant Revisions:
	 * 	none
	\* ------------------------------------------------------------ */
	private function __construct()
	{
		$this->jdb	= class_exists('JFactory');
		$params = $this->_getParams();
		
		// Assign parameters retrieved to class array
		$this->_buildParams($params);
		
		// Clean the URL variables
		$this->_cleanUrls();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getInstance
	 * Purpose:		Called to create an instance of the class
	 * 
	 * As of:		version 1.5.3
	 * 
	 * Significant Revisions:
	 * 	none
	\* ------------------------------------------------------------ */
	public static function getInstance()
	{
		if (self::$instance == null)
		{
			self::$instance = new self;
		}
		return self::$instance;
	}
	
	
	public function get($key)
	{
		if (!$this->_multiArrayKeyExists($key, $this->params))
		{
			// Error trapping for non-existant parameter
			return false;
		}
		$prime = $this->_arrayFindPrimeKey($key, $this->params);
		return $this->params[$prime][$key];
	}
	
	
	public function set($key, $value, $save = false, $prime = 'component')
	{
		if ($this->_multiArrayKeyExists($key, $this->params))
			$prime = $this->_arrayFindPrimeKey($key, $this->params);
		
		$this->params[$prime][$key] = $value;
		
		if ($save)
		{
			$this->_saveParams($prime);
		}
	}
	
	
	private function _getParams()
	{
		// Call appropriate database object
		if ($this->jdb) {
			$db = & JFactory::getDBO();
		} else {
			$db	= & JwhmcsDBO::getInstance();
		}
		
		$query['component'] = "SELECT `id`, `params` FROM #__components WHERE `option`= 'com_jwhmcs'";
		$query['auth']		= "SELECT `id`, `params` FROM #__plugins WHERE `element`='jwhmcs_auth' AND `folder`='authentication'";
		$query['system']	= "SELECT `id`, `params` FROM #__plugins WHERE `element`='jwhmcs' AND `folder`='system'";
		$query['user']		= "SELECT `id`, `params` FROM #__plugins WHERE `element`='jwhmcs' AND `folder`='user'";
		
		foreach ($query as $qk => $qv)
		{
			$db->setQuery($qv);
			$result	= $db->loadAssoc();
			$params[$qk]			= $result['params'] ? $result['params'] : $this->_loadDefaults($qk);
			$this->paramids[$qk]	= $result['id'];
		}
		
		return $params;
	}
	
	
	private function _buildParams($paramset)
	{
		foreach ($paramset as $set => $params)
		{
			$tmp = preg_split('/\n/', $params);
			
			foreach ($tmp as $t)
			{
				$v = explode('=', $t);
				
				if (count($v)>1)
				{
					$key = $v[0];
					unset($v[0]);
					$value = implode('=',$v);
					$this->params[$set][$key] = $value;
				}
				unset($v, $key, $value);
			}
		}
	}
	
	
	private function _saveParams($prime)
	{
	// Call appropriate database object
		if ($this->jdb) {
			$db = & JFactory::getDBO();
		} else {
			$db	= & JwhmcsDBO::getInstance();
		}
		
		$p	= $this->params[$prime];
		foreach ($p as $k => $v)
		{
			$params[]	= $k."=".$v;
		}
		$param	= implode("\n", $params);
		
		
		switch ($prime)
		{
			case 'component':
				$query	= "UPDATE #__components SET `params` = '%s' WHERE `id` = %d";
				break;
			default:
				$query	= "UPDATE #__plugins SET `params` = '%s' WHERE `id` = %d";
		}
		$query	= sprintf($query, $param, $this->paramids[$prime]);
		$db->setQuery($query);
		$result	= $db->query();
	}
	
	
	private function _loadDefaults($paramset)
	{
		switch ($paramset):
			case 'component':
				$ret	= 'whmcsvers=4.0.0
jwhmcsdebug=1
jwhmcsjurl=
jwhmcsjrootimgurl=
jwhmcsjssl=0
jwhmcsjin=
jwhmcsjinssl=1
jwhmcsjout=
jwhmcsjoutssl=0
jwhmcsjstoreus=1
jwhmcssecret=jwhmcsint
jwhmcsurl=
jwhmcsssl=0
jwhmcsadminus=
jwhmcsadminpw=
jwhmcsjquery=1
jwloggedinurl=
jwloggedouturl=
jwlnkdefault=
jwhmcsmenustyle=joomla
jwlnkaffiliates=
jwlnkannouncements=
jwlnkbanned=
jwlnkcart=
jwlnkclientarea=
jwlnkconfiguressl=
jwlnkcontact=
jwlnkdomainchecker=
jwlnkdownloads=
jwlnkindex=
jwlnkknowledgebase=
jwlnklogout=
jwlnknetworkissues=
jwlnkorder=
jwlnkpasswordreminder=
jwlnkpwreset=
jwlnkregister=
jwlnkserverstatus=
jwlnksubmitticket=
jwlnksupporttickets=
jwlnktutorials=
jwlnkupgrade=
jwlnkviewinvoice=
jwlnkviewticket=';
				break;
			case 'auth':
				$ret	= 'autoaddjoomla=1
autoupdatejoomlapw=1
autoaddwhmcs=0
autoupdatewhmcspw=1
whmcsaddress=Client Address
whmcscity=City
whmcsstate=State
whmcspostal=Postal Code
whmcscntry=US
whmcsphone=000-000-0000';
				break;
			case 'system':
				$ret	= 'jwhmcsredirwhmcs=0
menuid=';
				break;
			case 'user':
				$ret	= '';
				break;
		endswitch;
		
		return $ret;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_cleanUrls
	 * Purpose:		Cleans the urls in the parameters for usability
	 * 
	 * As of:		version 1.5.3
	 * 
	 * Significant Revisions:
	 * 	none
	\* ------------------------------------------------------------ */
	private function _cleanUrls()
	{
		// Parameters to parse for URLs
		$purls = array(	'jwhmcsjurl',			// Joomla Root URL
						'jwhmcsjrootimgurl',	// Joomla Root URL for Images
						'jwhmcsurl',			// WHMCS Root URL
						'jwhmcsjin',			// Landing Page - Login
						'jwhmcsjout');			// Landing Page - Logout
		
		foreach ($purls as $purl)
		{
			$tmp	= parse_url ($this->get($purl));
			
			// Remove a slash if added to the end of the url
			if ($tmp['path']=='/') unset($tmp['path']);
			
			// Test for which parameter
			if ($purl == 'jwhmcsjurl') {
				$this->set( 'jwhmcsjurl', 		(isset($tmp['host'])?$tmp['host']:'').(isset($tmp['path'])?rtrim($tmp['path'],'/'):'').(isset($tmp['query'])?'?'.$tmp['query']:'').(isset($tmp['fragment'])?'#'.$tmp['fragment']:''), true);
				$this->set( 'jwhmcsjrooturl',	(isset($tmp['host'])?$tmp['host']:''), true);
			} else {
				$this->set( $purl, (isset($tmp['host'])?$tmp['host']:'').(isset($tmp['path'])?rtrim($tmp['path'],'/'):'').(isset($tmp['query'])?'?'.$tmp['query']:'').(isset($tmp['fragment'])?'#'.$tmp['fragment']:''), true);
			}
			unset($tmp);
		}
		return;
	}
	
	
	private function _multiArrayKeyExists( $needle, $haystack )
	{
		foreach ( $haystack as $key => $value )
		{
			if ( $needle == $key )
				return true;
			
			if ( is_array( $value ) ) {
				if ( $this->_multiArrayKeyExists( $needle, $value ) == true )
				{
					return true;
				}
				else
				{
					continue;
				}
			}
		}
		
		return false;
	}
	
	
	private function _arrayFindPrimeKey($key, $form)
	{
		if (array_key_exists($key, $form))
		{
			return true;
		}
		
		foreach ($form as $k => $v)
		{
			$ret = & $this->_arrayFindPrimeKey($key, $form[$k]);
			if ($ret===true)	// Test if the key was found in the previous check
			{
				return $k;		// Return the primary key
			}
			if ($ret)
			{
				$ret[$k] = $ret;
				return $ret;
			}
		}
		return false;
	}
}