<?php
/**
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: debug.php 1 2009-09-02 00:16:45Z Steven $
 * @since		1.5.0
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/**
 * Debug Class
 *
 * @package    com_jwhmcs
 */
class Debug
{
	var $active		=	true;
	var	$usefeed	=	false;
	
	function Arrays($val, $msg = null) {
		if ($this->active):
			if(!$this->usefeed):
				echo '<strong><u>'.$msg.'</u></strong>';
				echo '<pre>';
				print_r($val);
				echo '</pre>';
			else:
				$this->feed	.= '<strong><u>'.$msg.'</u></strong><pre>'.print_r($val, true).'</pre>';
			endif;
		endif;
	}
	
	function Paths() {
		$path = array(
					'JPATH_ADMINISTRATOR'			=>	JPATH_ADMINISTRATOR,
					'JPATH_BASE'					=>	JPATH_BASE,
					'JPATH_CACHE'					=>	JPATH_CACHE,
					'JPATH_COMPONENT'				=>	JPATH_COMPONENT,
					'JPATH_COMPONENT_ADMINISTRATOR'	=>	JPATH_COMPONENT_ADMINISTRATOR,
					'JPATH_COMPONENT_SITE'			=>	JPATH_COMPONENT_SITE,
					'JPATH_CONFIGURATION'			=>	JPATH_CONFIGURATION,
					'JPATH_INSTALLATION'			=>	JPATH_INSTALLATION,
					'JPATH_LIBRARIES'				=>	JPATH_LIBRARIES,
					'JPATH_PLUGINS'					=>	JPATH_PLUGINS,
					'JPATH_ROOT'					=>	JPATH_ROOT,
					'JPATH_SITE'					=>	JPATH_SITE,
					'JPATH_THEMES'					=>	JPATH_THEMES,
					'JPATH_XMLRPC'					=>	JPATH_XMLRPC
				);
		$this->Arrays($path);
	}
	
	function Query($val, $msg = null)
	{
		$val = str_replace('#_','jos',$val);
		if ($this->active):
			if (!$this->usefeed):
				echo '<strong><u>'.$msg.'</u></strong>';
				echo '<p>'.$val.'</p>';
			else:
				$this->feed	.=	'<strong><u>'.$msg.'</u></strong><p>'.$val.'</p>';
			endif;
		endif;
	}
	
	function LinkDisplay($link)
	{
		if ($this->active):
			if (!$this->usefeed):
				echo 'To go to the redirect page:<br /><a href="'.$link.'">Redirect Page</a>';
			else:
				echo '<p><h3>To go to the redirect page:<br /><a href="'.$link.'">Redirect Page</a></h3></p>'.$this->feed;
			endif;
		endif;
	}
}