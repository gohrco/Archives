J!WHMCS Integrator 2.0
----------------------

1. Unzip the main archive onto your local computer
2. To do an automatic install, you only need to install the com_jwhmcs_v200.zip arvhive and follow the directions.
3. For a manual installation, install the com_jwhmcs_v200.zip file and select "Manual Install" and follow the directions there.  You will need each of these archive files for this process.