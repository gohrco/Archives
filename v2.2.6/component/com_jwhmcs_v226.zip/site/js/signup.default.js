function validInfo(type, value)
{
	var msg = $('message');
	var img = $(type+"Result");
	var chk = $(type+"Checkmsg");
	var val = $(type+"Valid");
	var thisurl = $('thisurl');
	var url = thisurl.value + "index2.php?option=com_jwhmcs&controller=signup&task=validInfo&type="+URLEncode(type)+"&value="+URLEncode(value);
	
	msg.removeClass('msginvalid').removeClass('msgvalid').addClass('msgnotice');
	msg.setHTML(chk.value);
	img.removeClass('imginvalid').removeClass('imgrequired').removeClass('imgnotice').removeClass('imgvalid').addClass('imgcheck');
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var resp = parseXml(xhr.responseText);
				var result = resp.getElementsByTagName("result")[0].childNodes[0].nodeValue;
				var message  = resp.getElementsByTagName("message")[0].childNodes[0].nodeValue;
				
				msg.setHTML(message);
				
				if (result == 1) {
					msg.removeClass('msgnotice').removeClass('msginvalid').addClass('msgvalid');
					img.removeClass('imgnotice').removeClass('imginvalid').removeClass('imgcheck').addClass('imgvalid');
					val.setProperty('value', "1");
				} else {
					msg.removeClass('msgnotice').addClass('msginvalid');
					img.removeClass('imgcheck').addClass('imginvalid');
					val.setProperty('value', "");
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}