<?php
/**
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id$
 * @since		1.5.3
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once ('class.database.php');
require_once ('class.vars.php');
require_once ('class.curl.php');

class JwhmcsParse
{
	
	/**
	 * @var instance to contain object when created
	 */
	private static $instance = null;
	
    /* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Called upon initialization of object class
	 * 
	 * As of:		version 2.0
	 * 
	 * Significant Revisions:
	 * 	none
	\* ------------------------------------------------------------ */
	private function __construct()
	{
		global $params, $vars;
		
		// Test to see if debug set and no filename, if so set default filename for testing
		if (($params->get( 'jwhmcsdebug' ) == 1) && (!$vars->get( 'filename' )))
			$vars->set( 'filename', 'clientarea');
		
		$parse->parse	= $this->_buildParse();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getInstance
	 * Purpose:		Called to create an instance of the class
	 * 
	 * As of:		version 2.0
	 * 
	 * Significant Revisions:
	 * 	none
	\* ------------------------------------------------------------ */
	public static function getInstance()
	{
		if (self::$instance == null)
		{
			self::$instance = new self;
		}
		return self::$instance;
	}
	
	
	public function get($name = null, $prime = 'vars')
	{
		if ($name)
		{
			return $this->parse[$prime][$name];
		}
		else
		{
			return $this->parse;
		}
	}
	
	
	public function set($name, $value, $prime = 'vars')
	{
		$this->parse[$prime][$name] = $value;
		return;
	}
	
	
	public function setData(&$site)
	{
		$params = & JwhmcsParams::getInstance();
		
//		$this->set( 'site', $site );
		
		// Make the replacements to the URLS, HREFs, etc...
//		$site	= $this->_makeReplacements($site);
		$needles	= $this->_getNeedles();
		$site		= $this->_findNeedles(&$needles, &$site);
		
		// Fix the menu style so the correct menu is active
		$site	= $this->_menuStyling($site);
		
		// Replace Title and Breadcrumbs
		$site	= $this->_breadCrumber($site);
		
		// Turn off jquery script call if it conflicts
		if ($params->get( 'jwhmcsjquery' )) {
//			$site = str_replace('</head>', '<script type="text/javascript" src="includes/jscript/jquery.js"></script></head>', $site);
//			$this->set( 'site', $site );
		}
		
		// Split the site setting the html variables
		$this->_splitSite($site);
	}
	
	
	private function _buildParse()
	{
		$params	= & JwhmcsParams::getInstance();
		$vars	= & JwhmcsVars::getInstance();
		
		// Setting SSL scheme
		// 1a: Check if usessl passed in vars (coming from WHMCS)
		if ( $vars->get( 'usessl' ) == 1) {
			// 2: Check if parameter set to use ssl on site (should be deprecated)
			if ( $params->get( 'jwhmcsjssl' ) ) {
				$ssl = true;
			}
			else {
				$ssl = false;
			}
		}
		// 1b: Check if current page is using SSL (not coming from WHMCS)
		else {
			// 2: Check if current page is using SSL
			if ( $vars->get( 'HTTPS' ) == 'on') {
				$ssl = true;
			}
			else {
				$ssl = false;
			}
		}
		
		// 3: Build and set scheme
		$this->set( 'scheme',	'http'.( $ssl ? 's' : '' ).'://');
		$params->set( 'urlscheme', $this->get( 'scheme ') );
		
		$this->set( 'homeurl',		'http://'.$params->get( 'jwhmcsjurl' ) );
		$this->set( 'rooturl',		$this->get( 'scheme' ).$params->get( 'jwhmcsjurl' ) );
		$this->set( 'imgurl',		$this->get( 'scheme' ).$params->get( 'jwhmcsjrootimgurl' ) );
		$this->set( 'newbase',		$this->get( 'scheme' ).$params->get( 'jwhmcsurl' ) );
		
		if ($vars->get( 'loggedin' ))
		{
			$jpage	= $params->get( 'jwloggedinurl' );
			$wuser	= '&loggedin=1&clientid='.$vars->get( 'clientid' );
		}
		else
		{
			$jpage	= $params->get( 'jwloggedouturl' );
			$wuser	= '';
		}
		
		if ($vars->get( 'usessl' )) $wuser.='&usessl=1';
		
		$this->set( 'url', 'http://'.$params->get( 'jwhmcsjurl' ).'/index.php?option=com_jwhmcs&Itemid='.$jpage.$wuser );
		
		$this->set( 'breakpcs',		'<!-- J!WHMCS -->' );
		$this->set( 'rep_content',	'<!-- J!WHMCS:  COMPONENT -->' );
		
		// Build the various parameter options for the pages in WHMCS
		$this->_buildPages();
	}
	
	
	private function _buildPages()
	{
		$params = & JwhmcsParams::getInstance();
		
		$default	= $params->get( 'jwlnkdefault' );
		$paramset	= $params->params;
		foreach ($paramset as $ps)
		{
			foreach($ps as $key => $value)
			{
				$tmp = substr($key, 0, 5);
				if ($tmp == 'jwlnk')
				{
					$tmp = substr($key, (5-strlen($key)));
					// Set each page to either the default link or the selected link
					$this->set( $tmp,	( strlen($value)==0 ? $default : $value ), 'page' );
				}
			}
		}
	}
	
	
	private function _getNeedles() {
		$params		= & JwhmcsParams::getInstance();
		$vars		= & JwhmcsVars::getInstance();
		
		$filename	= $vars->get( 'filename' );
		
		/* ----------- *\
		 * Find Array:
		 *  [0] = Debug name
		 * 	[1] = regular expression
		 *  [2] = replacement value
		 *  [3] = t:f - true to replace entire content; false to parse url
		 *  [4] = t:f - true to replace entire scheme and host; false to only prepend
		 *  [5] = t:f - true to replace scheme (ssl for css, js and imgs)
		 *   
		 */
		
		// <link> Replacements
		$find[0][0] = '&lt;link&gt;';
		$find[0][1] = '/(?P<front><link.+?href=\"?\'?)\/?(?P<link>[^>\"\']+)(?P<back>\'?\"?.*?\/>)/u';
		$find[0][2] = $this->get( 'imgurl' );
		$find[0][3] = false;
		$find[0][4]	= true; 
		$find[0][5] = true;
		
		// <a href> Replacements
		$find[1][0] = '&lt;a href&gt;';
		$find[1][1] = '/(?P<front><a.+?href=\'?\"?)\/?(?P<link>[^>\"\']+)(?P<back>\"?\'?.*?>)/u';
		$find[1][2] = $this->get( 'homeurl' );
		$find[1][3] = false;
		$find[1][4]	= false;
		$find[1][5] = false;
		
		// <script> Replacements
		$find[2][0] = '&lt;script src&gt;';
		$find[2][1] = '/(?P<front><script.+?src=\"?\'?)\/?(?P<link>[^>\"\']+)(?P<back>\'?\"?.*?>)/u';
		$find[2][2] = $this->get( 'imgurl' );
		$find[2][3] = false;
		$find[2][4]	= true;
		$find[2][5] = true;
		
		// <img> Replacements
		$find[3][0] = '&lt;img src&gt;';
		$find[3][1] = '/(?P<front><img.+?src=\"?\'?)\/?(?P<link>[^>\"\']+)(?P<back>\"?\'?.*?>)/u';
		$find[3][2] = $this->get( 'imgurl' );
		$find[3][3] = false;
		$find[3][4]	= true;
		$find[3][5] = true;
		
		// "style" Replacements
		$find[4][0] = 'css url()';
		$find[4][1] = '/(?P<front>style=\"?\'?.+?url\(\"?\'?)\/?(?P<link>[^\)]+\..{3})(?P<back>\"?\'?\);?[^>]*>)/ui';
		$find[4][2] = $this->get( 'imgurl' );
		$find[4][3] = false;
		$find[4][4]	= true;
		$find[4][5] = true;
		
		// <style> Replacements
		$find[5][0] = '&lt;style&gt;';
		$find[5][1] = '/(?P<front>{[\w\s]*.*background[-\w]*:[^\)]*url\(\"?\'?)\/?(?P<link>[^\)]+\..{3})(?P<back>\"?\'?\)[^}]*})/ui';
		$find[5][2] = $this->get( 'imgurl' );
		$find[5][3] = false;
		$find[5][4]	= true;
		$find[5][5] = true;
		
		// <base> Replacements
		$find[6][0] = '&lt;base&gt;';
		$find[6][1]	= '/(?P<front><base.+?href=\"?\'?)(?P<link>https?:\/\/[^>\'\" ]+)(?P<back>\'?\"?.*?\/>)/ui';
		$find[6][2]	= rtrim($this->get( 'newbase' ), '/').'/';
		$find[6][3] = true;
		$find[6][4]	= true;
		$find[6][5] = false;
		
		return $find;
	}
	
	
	private function _findNeedles(&$needles, &$site) {
		$params	= & JwhmcsParams::getInstance();
		$vars	= & JwhmcsVars::getInstance();
		
		$cnt	= 0;
		foreach ($needles as $needle):
			preg_match_all($needle[1], $site, $matches, PREG_SET_ORDER);
			
			foreach ($matches as $match):
				$cnt++;
				
				// Hang on to original match so we can find it again later
				$item[$cnt]['find']	= $match[0];
				$item[$cnt]['type']	= $needle[0];
				$item[$cnt]['regx'] = $needle[1];
				$item[$cnt]['nedl'] = $needle[2];
				
				// Check to see if we are replacing the entire find
				if ($needle[3] == true) {
					$item[$cnt]['repl']	= $match['front'].$needle[2].$match['back'];
					continue;
				}
				
				// Parse the match and the replacement into pieces
				$furl	= parse_url($match['link']);	// Found
				$nurl	= parse_url($needle[2]);		// Replacement
				
				// Test to see if we got nothing but a fragment
				if (count($furl)==1 && isset($furl['fragment'])) {
					$item[$cnt]['repl'] = $match[0];
					continue;
				}
				
				// Check to see if we replace the entire scheme (css, js, imgs)
				//   Note:  The scheme should already be handled when needle built
				if ($needle[4] == true) {
					$turl = parse_url($this->get( 'homeurl' ));
					if (isset($furl['host'])) {
						if ($turl['host'] == $furl['host']) {
							$furl['host'] = $nurl['host'];
						}
					}
					else {
						$furl['host'] = $nurl['host'];
					}
					$furl['scheme']	= $nurl['scheme'];
//					$furl['host']	= $nurl['host'];
					$filler	= $this->_buildUrl($furl);
					$item[$cnt]['repl'] = $match['front'].$filler.$match['back'];
					continue;
				}
				
				// Check to see if the found item has a scheme (and host).  If so then
				//   assume we leave host / scheme alone unless we update the scheme
				if (isset($furl['scheme'])) {
					if ($needle[5]) {
						$furl['scheme'] = $nurl['scheme'];
					}
					
					// Test the Joomla URL against the found url, and if the same,
					//	 replace the found URL with the new url
					/*$turl = parse_url($this->get( 'homeurl' ));
					if ($turl['host'] == $furl['host']) {
						$furl['host'] = $nurl['host'];
						$furl['path'] = $this->_checkDuplicatePaths($furl['path'], $turl['path']);
					}
					unset ($turl);
					*/
					$filler = $this->_buildUrl($furl);
					$item[$cnt]['repl'] = $match['front'].$filler.$match['back'];
					continue;
				}
				// We are going to force absolute paths here since there is not
				//	 scheme set, and therefore no host - necessary for subdomains
				else {
					$furl['scheme'] = $nurl['scheme'];
					$furl['host'] = $nurl['host'];
				}
				
				// Check to see if there are duplicate paths
				if (isset($nurl['path']) && isset($furl['path'])) {
					$furl['path']  = $this->_checkDuplicatePaths($furl['path'], $nurl['path']);
				}
				
				$filler = $this->_buildUrl($furl);
				$item[$cnt]['repl'] = $match['front'].$filler.$match['back'];
				
			endforeach; // Match foreach
		endforeach; // Needle foreach
		
		$type = false;
		// Perform actual replacements here
		if ($item) {
			foreach ($item as $run) {
				if ($run['type'] != $type) {
					$debug .= '<div style="border-top: 2px solid #000; font-family: arial; font-size: medium; clear: both; padding: 0; font-weight: bold; ">Needle Type:  '.$run['type'].'</div>';
					$debug .= '<div style="font-family: arial; font-size: medium; clear: both; padding: 0; font-weight: bold; ">Regular Expression is:  '.htmlentities($run['regx']).'</div>';
					$debug .= '<div style="border-bottom: 1px solid #000; font-family: arial; font-size: medium; clear: both; padding: 0; font-weight: bold; ">Needle is:  '.htmlentities($run['nedl']).'</div>';
					$type = $run['type'];
				}
				$debug	.= '<div style="font-family: arial; font-size: small; clear: both; "><div style="width: 200px; text-align: right; float: left; ">This is what was found</div><div style="float: left; padding-left: 5px; font-weight: bold; ">'.htmlentities($run['find']).'</div></div>';
				$debug	.= '<div style="border-bottom: 1px solid #000; height: 20px; margin-bottom: 4px; font-family: arial; font-size: small; clear: both; "><div style="width: 200px; text-align: right; float: left; ">This is to replace it</div><div style="float: left; padding-left: 5px; font-weight: bold; ">'.htmlentities($run['repl']).'</div></div>';
				$site = str_replace($run['find'], $run['repl'], $site);
			}
		}
		
		if ($params->get( 'jwhmcsdebug' ) == 1) echo $debug;
		return $site;
	}
	
	
	private function _buildUrl($url)
	{
		// Test for the path
		if (isset($url['path'])) {
			if ( count($url['path'] > 1 )) {
				$url['path'] = '/'.ltrim($url['path'], '/');
			}
		}
		// Test to see if the scheme is set, if so the host must also be
		if (isset($url['scheme'])) {
			if ($url['scheme'] == 'javascript') {
				$url['scheme'] .= ':';
			}
			else {
				$url['scheme']	.= '://';
			}
		}
		else {
			$url['scheme']	= '';
			$url['host']	= '';
		}
		return $url['scheme'].$url['host'].$url['path'].(isset($url['query'])?'?'.$url['query']:'').(isset($url['fragment'])?'#'.$url['fragment']:'');
	}
	
	
	private function _makeReplacements(&$site)
	{
		$params		= & JwhmcsParams::getInstance();
		$vars		= & JwhmcsVars::getInstance();
		
//		$site		= $this->get( 'site' );
		$filename	= $vars->get( 'filename' );
		
		// Test to see if debug set and no filename, if so set default filename for testing
		if (($params->get( 'jwhmcsdebug' ) == 1) && (!$vars->get( 'filename' )))
			$filename = 'clientarea';
		
		/* ----------- *\
		 * Find Array:
		 * 	[0] = regular expression
		 *  [1] = replacement value
		 *  [2] = t:f - true to replace entire content; false to parse url
		 *  [3] = t:f - true to replace entire scheme and host; false to only prepend
		 *  [4] = t:f - true to replace scheme (ssl for css, js and imgs) 
		 */
		
		// <link> Replacements
		$find[0][0] = '/(?P<front><link.+?href=\"?\'?)\/?(?P<link>[^>\"\']+)(?P<back>\'?\"?.*?\/>)/';
		$find[0][1] = $this->get( 'imgurl' );
		$find[0][2] = false;
		$find[0][3]	= false; 
		$find[0][4] = true;
		
		// <a href> Replacements
		$find[1][0] = '/(?P<front><a.+?href=\'?\"?)\/?(?P<link>[^>\"\']+)(?P<back>\"?\'?.*?>)/';
		$find[1][1] = $this->get( 'homeurl' );
		$find[1][2] = false;
		$find[1][3]	= false;
		$find[1][4] = false;
		
		// <script> Replacements
		$find[2][0] = '/(?P<front><script.+?src=\"?\'?)\/?(?P<link>[^>\"\']+)(?P<back>\'?\"?.*?>)/';
		$find[2][1] = $this->get( 'imgurl' );
		$find[2][2] = false;
		$find[2][3]	= false;
		$find[2][4] = true;
		
		// <img> Replacements
		$find[3][0] = '/(?P<front><img.+?src=\"?\'?)\/?(?P<link>[^>\"\']+)(?P<back>\"?\'?.*?>)/';
		$find[3][1] = $this->get( 'imgurl' );
		$find[3][2] = false;
		$find[3][3]	= false;
		$find[3][4] = true;
		
		// "style" Replacements
		$find[4][0] = '/(?P<front>style=\"?\'?.+?url\(\"?\'?)\/?(?P<link>[^\)]+\..{3})(?P<back>\"?\'?\);?[^>]*>)/i';
		$find[4][1] = $this->get( 'imgurl' );
		$find[4][2] = false;
		$find[4][3]	= false;
		$find[4][4] = true;
		
		// <style> Replacements
		$find[5][0] = '/(?P<front>{[\w\s]*.*background[-\w]*:[^\)]*url\(\"?\'?)\/?(?P<link>[^\)]+\..{3})(?P<back>\"?\'?\)[^}]*})/i';
		$find[5][1] = $this->get( 'imgurl' );
		$find[5][2] = false;
		$find[5][3]	= false;
		$find[5][4] = true;
		
		// <base> Replacements
		$find[6][0]	= '/(?P<front><base.+?href=\"?\'?)(?P<link>https?:\/\/[^>\'\" ]+)(?P<back>\'?\"?.*?\/>)/i';
		$find[6][1]	= rtrim($this->get( 'newbase' ), '/').'/';
		$find[6][2] = true;
		$find[6][3]	= true;
		$find[6][4] = false;
		
		// Call up the regexer to make replacements
		$site = $this->_regExer($find, &$site);
		
		return $site;
		
		// Pattern array - to be replaced in v 1.5.4
		
//		v 1.5.3 - Add ability to change form action on login forms (Oct 8 - alpha ready)
/*		$formaction	= '/(?P<front><form.+?action=\"?\'?)\/?(?P<link>[^>\"\']+)(?P<back>\"?\'?.*?>)/';
		$pattern[11]	= '/(<input.+type=\"hidden\".*name=\"task\".+value=\")login(\" \/>)/';
*/		
		
		
//		$pcs	= str_replace("<li class=\"item".$this->page->$filename."\"", "<li id=\"current\" class=\"active item".$this->page->$filename."\"", $pcs);
//		$pcs	= str_replace("<li class=\"parent item".$this->page->$filename."\"", "<li id=\"current\" class=\"active parent item".$this->page->$filename."\"", $pcs);
		
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_regExer
	 * Purpose:		This function accepts an array that contains both
	 * 				the needle and the replacement string.  The needle
	 * 				is stored at [0] and the replacement at [1].  It
	 * 				searches through the pcs string to do regular
	 * 				expression replacements.  If [2] is set to true, then
	 * 				the fnxn replaces the entire "link", else it parses it.
	 * 				
	 * As of:		version 1.5.3 (October 2009)
	 * 
	 * Significant Revisions:
	 * 	1)  none
	\* ------------------------------------------------------------ */
	private function _regExer($needles, &$site)
	{
		$params	= & JwhmcsParams::getInstance();
		$vars	= & JwhmcsVars::getInstance();
		
		$debug = '<pre>';
		$cnt = 0;
		
		// 2:  Run through each of the sent needles
		foreach ($needles as $needle):
			// 3:  Find all of this needle's regular expression matches
			preg_match_all($needle[0], $site, $matches, PREG_SET_ORDER);
			
			$debug .= '<hr /><strong>Needle Type:  '.$needle_name[$cnt].'</strong><br />Regular Expression is:  '.htmlentities($needle[0]).'<br />Needle is:  '.htmlentities($needle[1]).'<br />';
			$cnt++;
			
			foreach ($matches as $match):
				
				$find	= $match[0]; // This is what we need to find in $pcs later on
				
				// 4:  Check to see if we are replacing the entire found <link> array portion
				if ($needle[2] == true) {
					
					$repl	= $match['front'].$needle[1].$match['back'];
					
				// 5:  We know we aren't replacing the entire match item, so we must parse it as a URL
				} else {
					
					// 6:  Parse the found match into it's component pieces
					$url	= parse_url($match['link']);
					
					// 6b:  Parse replacement url to get pieces
					$nurl	= parse_url($needle[1]);
					
					if (isset($nurl['path'])) $nurl['path'] = trim($nurl['path'], '/');
					
					$debug .= 'This is the parsed match:<br />'.print_r($url, true);
					$debug .= 'This is the parsed needle:<br />'.print_r($nurl, 1);
					
					// 7:  Begin by doing nothing for # matches (place holders only)
					if (count($url)==1 && isset($url['fragment'])) {
						
						// Nothing to do but set the replace = the find
						$repl = $find;
						
					} else {
						
						// 8:  Should we replace the entire scheme and host (this is for img, css and js replacements)
						if ($needle[3]==true){
							
							$host = $needle[1];
							
						} else {
							
							// 9:  We know we cannot just arbitrarily replace the scheme and host so we must test for them
							//	   If the scheme exists, we know it is a full url not to be replaced
							if (isset($url['scheme'])) {
								
								// 9a:  Test to see if the parsed host = new host - if so use needle
								if ($url['host']==$nurl['host']) {
								
									$host = $nurl['scheme'].'://'.$nurl['host'];
									
								} else {
									
									// 9b:  Test to see if scheme = javascript - if so no // after :
									if ($url['scheme']=='javascript') {
										
										$sep = ':';
										
									} else {
										
										// 9c:  Test to see if $needle[4] == true
										$sep = (($needle[4]==true)&&($vars->get( 'usessl' ))?'s':'').'://';
										
									}
									
									$host = $url['scheme'].$sep.$url['host'];
								
								}
								
							} else {
								// 9d:  There is no scheme or host in front, but we must check for duplicate paths
								if (isset($nurl['path']) && isset($url['path'])) {
									
									$tmp = $this->_checkDuplicatePaths($url['path'], $nurl['path']);
									$debug .= 'Returned from checkDups: '.$tmp."<br />";
									$nurl['path']  = $tmp;
								}
								else {
									$nurl['path'] = trim($nurl['path'], '/');
								}
								$debug .= "New Path: ".$nurl['path']."<p>";
								$host = $nurl['scheme'].'://'.trim($nurl['host'],'/').'/'.$nurl['path'].'**TEST**';
								
							}
							
						}
						
						// 9d:  Test to see if there is a / at the front of the path and trim it and add it to the host no matter what
						if (isset($url['path'])) {
							
							if (strlen($url['path']) > 1) {
								
								$url['path'] = ltrim($url['path'], '/');
								
								// 9e:  Only add a slash if the scheme isn't javascript
								if ($url['scheme'] != 'javascript')
									$host .= '/';
							}
						}
						
						// 10:  Create the replacement value here
						$repl = $match['front'].$host.$url['path'].(isset($url['query'])?'?'.$url['query']:'').(isset($url['fragment'])?'#'.$url['fragment']:'').$match['back'];
						
					}
					
				}
				
				$debug .= 'This:  <strong>'.htmlentities($find).'</strong><br />To:    <strong>'.htmlentities($repl).'</strong><hr />';
				
				// 11:  Run the replacement
				$site = str_replace($find, $repl, $site);
				
				// 12:  Unset the variables to do again
				unset($find, $repl, $host);
			endforeach;
		endforeach;
		
		if ($params->get( 'jwhmcsdebug' ) == 1) echo $debug;
		return $site;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_parseMenuStyles
	 * Purpose:		This function parses the various menu styles that
	 * 					are found on many different templates.
	 * 				
	 * As of:		version 1.5.3b6 (November 2009)
	 * 
	 * Significant Revisions:
	 * 	1) 2.0 - Nov 2009
	 *  	-> Database, variable, curl and parameters moved to class
	\* ------------------------------------------------------------ */
	private function _menuStyling($site)
	{
		$db		= & JwhmcsDBO::getInstance();
		$params = & JwhmcsParams::getInstance();
		$vars	= & JwhmcsVars::getInstance();
		
		$filename	= $vars->get( 'filename' );
		$page		= $this->get( $filename, 'page' );
		
		if (($params->get( 'jwhmcsdebug' ) == 1) && (!$vars->get( 'filename' )))
			$filename = 'clientarea';
		
		switch ($params->get( 'jwhmcsmenustyle' ))
		{
			// Yoo Theme style template
			case 'yoo':
				$cnt	= 1;
				$sid	= $page;
				for ($i=0; $i<$cnt; $i++) {
					$query	= 'SELECT parent, ordering, name, sublevel FROM `#__menu` WHERE `#__menu`.`id` = '.$sid;
					$db->setQuery($query);
					$result	= $db->loadAssocList();
					
					foreach($result as $row) {
						$sublvl = $row[ 'sublevel' ];
						$menus[$sublvl] = array('parent' => ($sublvl + 1), 'ordering' => $row[ 'ordering' ], 'name' => $row[ 'name' ]);
					}
					if ($sublvl != 0) {
						$cnt++;
						$sid = $menus[$sublvl]['parent'];
						unset ($menus[$sublvl]);
					}
					
				}
				
				foreach ($menus as $menu) {
					$find[0] = array(	sprintf('/(?P<front><li[^>]+class=\"?\'?[^\"\'>]*)(?P<link>level1 item8)(?P<back>[^\"\']*\'?\"?[^>]*>)/i', $menu['parent'], $menu['ordering']),
										sprintf('level%d item%d active current', $menu['parent'], $menu['ordering']),
										true, false, false);
					$find[1] = array(	sprintf('/(?P<front><a[^>]+class=\"?\'?[^\"\'>]*)(?P<link>level%d item%d)(?P<back>[^\"\']*\'?\"?[^>]*>)/i', $menu['parent'], $menu['ordering']),
										sprintf('level%d item%d active current', $menu['parent'], $menu['ordering']),
										true, false, false);
					
					// Call up the regexer to make replacements
					$site = $this->_regExer($find, $site);
				}
				break;
			// Default Joomla menu styling
			default:
				$find[0][0]	= '/(?P<front><li.+?class=\"?\'?[^\"\']*)(?P<link>item'.$page.'[^\"\']*)(?P<back>\'?\"?[^>]*>)/i';
				$find[0][1]	= 'item'.$page.' active';
				$find[0][2]	= true;
				$find[0][3] = false;
				$find[0][4] = false;
				
				$site = $this->_regExer($find, $site);
				break;
		}
//		$this->set( 'site', $site );
		return $site;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_breadCrumber
	 * Purpose:		This function replaces the breadcrumbs found in Joomla
	 * 					with the breadcrumbs sent to it by the hook file.
	 * 				
	 * As of:		version 1.5.3b6 (November 2009)
	 * 
	 * Significant Revisions:
	 * 	1) 2.0 - Nov 2009
	 *  	-> Database, variable, curl and parameters moved to class
	\* ------------------------------------------------------------ */
	private function _breadCrumber($site)
	{
		$vars	= & JwhmcsVars::getInstance();
//		$site	= $this->get( 'site' );
		
		$needle[0] = '/(?P<front><title>)(?P<link>[^<\/]+?)(?P<back><\/title>)/';
		$needle[1] = $vars->get( 'pagetitle' );
		
		preg_match_all($needle[0], $site, $matches, PREG_SET_ORDER);
		$find	= $matches[0][0];
		$repl	= $matches[0]['front'].$needle[1].$matches[0]['back'];
		$title	= $matches[0]['link'];
		$site = str_replace($find, $repl, $site);
		unset ($needle, $find, $repl);
		
		$needle[0] = sprintf('/(?P<front><span.+?class=\"[^\"]*breadcrumbs[^\"]*\"[^>]*>[\w\s]*.*)(?P<link>%s)(?P<back><\/span>)/i', $title);
		$needle[1] = $vars->get( 'title' );
		
		preg_match_all($needle[0], $site, $matches, PREG_SET_ORDER);
		$find	= $matches[0][0];
		$repl	= $matches[0]['front'].$needle[1].$matches[0]['back'];
		$site = str_replace($find, $repl, $site);
		
//		$this->set( 'site', $site );
		return $site;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_tplSplit
	 * Purpose:		This method splits the template along the needle
	 * 				points and returns
	 * 				
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 * 	1)  none
	\* ------------------------------------------------------------ */
	private function _splitSite ($haystack)
	{
		$vars	= & JwhmcsVars::getInstance();
		
		$needle		= $this->get( 'breakpcs' );
//		$haystack	= $this->get( 'site' );
		$replace	= $this->get( 'rep_content' );
		
		$pcs		= explode($needle, $haystack);
		
		for($i=0; $i<count($pcs); $i++):
			$exists = preg_match($replace, $pcs[$i]);
			if ($exists) $hit = $i;
		endfor;
		$hdr = array_slice($pcs, 0, $hit);
		for ($i=0; $i<count($hdr); $i++) $htmlhdr.= $hdr[$i];
		$ftr = array_slice($pcs, $hit+1);
		for ($i=0; $i<count($ftr); $i++) $htmlftr.= $ftr[$i];
		
//		$htmlhdr .= '<pre>'.print_r($params,1).print_r($vars,1).'</pre>';
		
		// v 1.5.3 - Add hidden div for offline site
		if ($vars->get( 'offline' ))
		{
			$htmlhdr .= '<div style="display: none; ">';
			$htmlftr  = '</div>'.$this->htmlftr;
		}
		
		$this->set( 'htmlhdr', base64_encode($htmlhdr) );
		$this->set( 'htmlftr', base64_encode($htmlftr) );
	}
	
	
	private function _checkDuplicatePaths($orig, $new)
	{
		// The original path is coming out of the template
		// The new path is held in the needle
		
		$npath = explode('/', trim($new, '/'));
		$upath = explode('/', trim($orig, '/'));
		
		$start = false;
		// Take the first path item from original and check for existance in new path
		if (in_array($upath[0], $npath) ) {
			$start = array_search($upath[0], $npath);
		}
		
		// We know that we found the first item in the new path, now compare the rest of the path to see if it matches
		if ($start !== false) {
			$chop = true;
			for ($i=0; $i<count($npath); $i++) {
				if ($npath[$start+$i] != $upath[$i]) {
					$chop = false;
					break;
				}
			}
			if ($chop) {
				array_splice($npath, $start);
			}
		}
		
		// Reassemble the needle now and return
		return implode('/', $npath).'/'.ltrim($orig, '/');
	}
}