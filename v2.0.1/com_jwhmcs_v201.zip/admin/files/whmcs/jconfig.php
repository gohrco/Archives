<?php
/**
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: jwhmcs.php 1 2009-09-02 00:16:45Z Steven $
 * @since		1.5.0
 */
defined('JWHMCSINI') or die('Restricted access');
/**
 * The following settings are the only settings that need to be
 * configured or changed.
 * 
 * JPATH_CONFIG:  Define the path to the Joomla configuration file
 *   (typically /home/username/public_html)
 */
define( 'JPATH_CONFIG', '%s' );

?>