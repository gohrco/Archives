<?php

define( 'JWHMCSHOOKVERS', '2.0.0' );

/**
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: jwhmcs.php 90 2009-11-30 20:48:58Z Steven $
 * @since		1.5.0
 */

add_hook("ClientLogin",20,"hook_ClientLogin","");
add_hook("ClientLogout",20,"hook_ClientLogout","");
add_hook("ClientDetailsValidation",20,"hook_ClientDetailsValidate","");
add_hook("ClientChangePassword",20,"hook_ClientChangePW","");
add_hook("ClientEdit",20,"hook_ClientEdit","");
add_hook("ClientAreaPage",20,"hook_ClientAreaPage","");
add_hook("ClientAdd",20,"hook_ClientAdd","");

/* ------------------------------------------------------------ *\
 * Function:	hook_ClientAreaPage
 * Purpose:		This hook requests the Joomla template from the 
 * 				root file and then sets the returned variables for
 * 				the smarty to replace in the template files.
 * 
 * As of:		version 1.5.0 (August 2009)
 * 
 * Significant Revisions:
 * 	1)  ver 1.5.3 - Oct 2009
 * 			Added ability to replace titlebar text
\* ------------------------------------------------------------ */
function hook_ClientAreaPage() {
	global $smarty, $errormessage;
	$title				= $smarty->_tpl_vars['pagetitle'].($smarty->_tpl_vars['kbarticle']['title']?' - '.$smarty->_tpl_vars['kbarticle']['title']:'');
	
	$data['filename']	= $smarty->_tpl_vars['filename'];
	$data['systemurl']	= $smarty->_tpl_vars['systemurl'];
	$data['loggedin']	= (isset($smarty->_tpl_vars['loggedin'])?true:false);
	$data['pagetitle']	= $smarty->_tpl_vars['companyname'].' - '.$title;
	$data['title']		= $title;
	
//	v 1.5.3 - send the userid to the jwhmcs if logged in for pulling user info
	if ($data['loggedin'])
		$data['clientid']	= $_COOKIE['WHMCSUID'];
	
	// Set the action data variable if it exists
	if ($_REQUEST['action']) $data['action'] = $_REQUEST['action'];
	
	// v 1.5.3 - returned format changed to xml
	$info = goCurl('parse', $data, false);
	$var = xmlParse($info);
	
	if ( $var['return'] == 'success' )
	{
		// v 1.5.3 - fixed character encoding issue
		foreach ($var as $key => $value) {
			$value = base64_decode($value);
			if ($key != 'return') $smarty->assign($key, $value);
		}
		if ($faxn = $smarty->_tpl_vars['formaction']):
			$tmp	= explode('?', $faxn);
			if (substr($tmp[0], -11) == 'dologin.php') $tmp[0] = substr_replace($tmp[0], 'jwhmcs.php', -11);
			$smarty->_tpl_vars['formaction'] = $tmp[0].'?'.$tmp[1].'&task=jlogin';
			$smarty->_tpl_vars['LANG']['loginemail'] = 'Username';
		endif;
		$smarty->_tpl_vars['LANG']['loginemail'] = 'Username';
		
		$repl	= print_r(get_html_translation_table(HTML_ENTITIES), 1);
		for($i=0; $i<count($repl); $i++) {
			$repl[$i] = '';
		}
	}
}


/* ------------------------------------------------------------ *\
 * Function:	hook_ClientAdd
 * Purpose:		This hook sends new user info to the root jwhmcs
 * 				file for inserting into Joomla.
 * 
 * As of:		version 1.5.0 (August 2009)
 * 
 * Significant Revisions:
 * 	1)  ver 1.5.2 - Oct 2009
 * 			Added check test for $vars as an array (WHMCS v4.1 change)
\* ------------------------------------------------------------ */
function hook_ClientAdd($vars) {
	global $errormessage;
	
	if (!$_POST['jwhmcs']):
		// Prior to WHMCS v4.1, $vars contained only clientid
		// J!WHMCS v 1.5.2 - add test for vars as array
		$data['clientid']	= (is_array($vars)?$vars['userid']:$vars);
		
		$data['firstname']	= $_POST['firstname'];
		$data['lastname']	= $_POST['lastname'];
		$data['email']		= $_POST['email'];
		$data['company']	= $_POST['companyname'];
		$data['username']	= $_POST['firstname'].'.'.$_POST['lastname'];
		$data['password']	= $_POST['password'];
		$data['password2']	= $_POST['password2'];
		$data['address1']	= $_POST['address1'];
		$data['address2']	= $_POST['address2'];
		$data['city']		= $_POST['city'];
		$data['state']		= $_POST['state'];
		$data['postcode']	= $_POST['postcode'];
		$data['country']	= $_POST['country'];
		$data['phonenumber']= $_POST['phonenumber'];
		
		$info = goCurl('addclient', $data);
		$var = xmlParse($info);
		
		if ($var['result']=='error')
			$errormessage .= '<strong>There was a problem adding your information to the main site.  Please contact the administrator.</strong>';
	endif;
}


/* ------------------------------------------------------------ *\
 * Function:	hook_ClientEdit
 * Purpose:		This hook sends updated user info to the root jwhmcs
 * 				file for updating in Joomla.
 * 
 * As of:		version 1.5.0 (August 2009)
 * 
 * Significant Revisions:
 * 	1)  ver 1.5.2 - Oct 2009
 * 			Added check test for $vars as an array (WHMCS v4.1 change)
\* ------------------------------------------------------------ */
function hook_ClientEdit($vars) {
	global $errormessage;
	
	if (!$_POST['jwhmcs']):
		// Prior to WHMCS v4.1, $vars contained only clientid
		// J!WHMCS v 1.5.2 - add test for vars as array
		$data['clientid']	= (is_array($vars)?$vars['userid']:$vars);
		
		$data['firstname']	= $_POST['firstname'];
		$data['lastname']	= $_POST['lastname'];
		$data['email']		= $_POST['email'];
		$data['company']	= $_POST['companyname'];
		$data['address1']	= $_POST['address1'];
		$data['address2']	= $_POST['address2'];
		$data['city']		= $_POST['city'];
		$data['state']		= $_POST['state'];
		$data['postcode']	= $_POST['postcode'];
		$data['country']	= $_POST['country'];
		$data['phonenumber']= $_POST['phonenumber'];
		
		$info = goCurl('updateclient', $data);
		$var = xmlParse($info);
		
		if ($var['result']=='error')
			$errormessage .= '<strong>There was a problem saving your information.  Please contact the administrator.</strong>';
	endif;
}

/**
 * Hook for logging clients into Joomla after logging into WHMCS
 */
function hook_ClientLogin($vars) {
	
	if (!$_POST['jwhmcs']):
//		echo '<pre>';
//		echo headers_sent();
//		print_r(headers_list());
		
	endif;
}

/**
 * Hook for logging out clients
 */
function hook_ClientLogout($vars)
{
	global $smarty;
	
	$url = $smarty->_tpl_vars['systemurl'].'jwhmcs.php?task=logout';
	header( 'Location: '.$url);
} 

/**
 * Hook for validating client email address, checking for duplicate in Joomla
 */
function hook_ClientDetailsValidate($vars) {
	global $errormessage;
	
	if (!$_POST['jwhmcs']):
		// Create data array to send to curl
		$data['email']		= $_POST['email'];
		$data['clientid']	= $_COOKIE['WHMCSUID'];
		
		// Test to see if the cookie was set, if not then don't curl
		if ($data['clientid']):
			// Call cURL function with validate task and data
			$info	= goCurl('validate', $data);
			$var	= xmlParse($info);
			
			// If return cURL data is false (invalid)
			if ($var['result'] == 'error' )
				$errormessage .= '<strong>You cannot change your email address to '.$_POST['email'].'.  '.$var['message'];
		endif;
	endif;
}


/* ------------------------------------------------------------ *\
 * Function:	hook_ClientChangePW
 * Purpose:		This hook changes the password in Joomla when it is
 * 				changed in WHMCS.
 * 
 * As of:		version 1.5.0 (August 2009)
 * 
 * Significant Revisions:
 * 	1)  ver 1.5.3 - Oct 2009
 * 			Added check test for $vars as an array (WHMCS v4.1 change) 
\* ------------------------------------------------------------ */
function hook_ClientChangePW($vars) {
	global $errormessage;
	
	if (!$_POST['jwhmcs']):
		// Prior to WHMCS v4.1, $vars contained only clientid
		// v 1.5.3 - add test for vars as array
		$data['clientid']	= (is_array($vars)?$vars['userid']:$vars);
		$data['password']	= $_POST['newpw'];
		
		// Call cURL function with validate task and data
		$info = goCurl('chpassword', $data);
		$var = xmlParse($info);
		
		if ( $var['result'] == 'error' )
			$errormessage .= '<strong>There was an error changing your password</strong>';
	endif;
}


/**
 * This function is a cURL call that can be made by the hooks to bypass WHMCS and retrieve info
 * 
 * @param	(string)	$task	This is the task to send to the /jwhmcs.php file
 * @param	(array)		$post	This contains the data to send to the /jwhmcs.php file
 * 
 * @return	(array)		$var	This contains the returned info in an array
 */
function goCurl($task, array $post, $parse = true) {
	global $smarty;
	
	$post['jwhmcs'] = 1;
	
	// Set the postfields items for the cURL call
	foreach ($post as $key => $value) $data .= '&'.urlencode($key).'='.urlencode($value);
	$url = buildCurl($smarty->_tpl_vars['systemurl'].'jwhmcs.php?task='.$task.$data);
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_TIMEOUT, 100);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_NOPROGRESS, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postfields);
	ob_start();
	$data = curl_exec($ch);
	ob_end_clean();
	curl_close($ch);
	
	if ($parse) {
		$data = explode(';', $data);
		foreach ($data as $temp):
			$temp = explode('=', $temp);
			if (count($temp)>1):
				$key = $temp[0];
				unset($temp[0]);
				$value = implode('=', $temp);
				$var[$key] = $value;
			endif;
			unset ($key, $value, $temp);
		endforeach;
	} else {
		$var = $data;
	}
	return $var;
}


/* ------------------------------------------------------------ *\
 * Function:	buildCurl
 * Purpose:		Test the system url to see if SSL being used.  If
 * 				so, change scheme of URL for cUrl to ensure it works
 * 
 * As of:		version 1.5.1 (September 2009)
\* ------------------------------------------------------------ */
function buildCurl($systemurl)
{
	// Parse URL sent for testing purposes
	$url = parse_url($systemurl);
	
	// Test to see if SSL is set
	if ($url['scheme']=='https'):
		$url['scheme']='http';
		$url['query']=$url['query'].'&usessl=1';
	endif;
	
	// Return the URL back to the calling function
	return $url['scheme'].'://'.$url['host'].$url['path'].'?'.$url['query'];
}


function unicode_urldecode($url)
{
    preg_match_all('/%u([[:alnum:]]{4})/', $url, $a);
   
    foreach ($a[1] as $uniord)
    {
        $dec = hexdec($uniord);
        $utf = '';
       
        if ($dec < 128)
        {
            $utf = chr($dec);
        }
        else if ($dec < 2048)
        {
            $utf = chr(192 + (($dec - ($dec % 64)) / 64));
            $utf .= chr(128 + ($dec % 64));
        }
        else
        {
            $utf = chr(224 + (($dec - ($dec % 4096)) / 4096));
            $utf .= chr(128 + ((($dec % 4096) - ($dec % 64)) / 64));
            $utf .= chr(128 + ($dec % 64));
        }
       
        $url = str_replace('%u'.$uniord, $utf, $url);
    }
   
    return urldecode($url);
}

function hook_version($internal = false) {
	if ($internal)
		return JWHMCSHOOKVERS;
	else
		echo JWHMCSHOOKVERS;
}

function xmlParse($data)
{
	$xml = xml_parser_create();
	xml_parse_into_struct($xml, $data, $vals, $index);
	xml_parser_free($xml);
	 
	foreach ($vals as $p):
		if ($p['type']=='complete')
		{
			// Error trapping for error_reporting(-1)
			if(isset($p['value']))
				$items[strtolower($p['tag'])] = $p['value'];
		}
	endforeach;
	
	return $items;
}


?>