DROP TABLE IF EXISTS `#__jwhmcs_xref`;
DROP TABLE IF EXISTS `#__jwhmcs_sess`;

--
-- Added for ver 1.5.1
--

DROP TABLE IF EXISTS `#__jwhmcs_user`;
DROP TABLE IF EXISTS `#__jwhmcs_group`;