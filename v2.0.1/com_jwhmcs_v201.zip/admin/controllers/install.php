<?php
/**
 * Group Management Controller for J!WHMCS Integrator
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since		1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsControllerSync
 * Extends:		JwhmcsController
 * Purpose:		Used for WHMCS User Synchronization
 * 
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsControllerInstall extends JwhmcsController
{
	/* ------------------------------------------------------------ *\
	 * Task:		__construct
	 * Purpose:		Needed for building the class
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
		
		$this->registerTask( 'apiconxnAccept',	'licenseAccept' );
	}
	
	
	function steptwo()
	{
		global $mainframe;
		
		$model	= $this->getModel( 'install' );
		
		// Install plugins first
		if (! $model->steptwoPlugins() ) {
			$msg	= JText::_( 'JWHMCS_ADMIN_INSTALL_FAILED_STEPTWOPLGIN' );
			$lnk	= 'index.php?option=com_jwhmcs';
			$this->setRedirect($lnk, $msg);
		}
		
		// Request WHMCS paths
		JRequest::setVar( 'hidemainmenu', 1 );
		JRequest::setVar( 'layout', '02steptwo' );
		
		$mainframe->enqueueMessage( JText::_( 'JWHMCS_ADMIN_INSTALL_SUCCESS_STEPTWO' ), 'message');
		parent::display();
	}
	
	
	function stepthree()
	{
		global $mainframe;
		$model = $this->getModel( 'install' );
		
		// Save WHMCS paths
		if (! $model->stepthreeinstall() ) {
			$msg = JText::_( 'JWHMCS_ADMIN_INSTALL_FAILED_STEPTHREE' );
			$lnk = 'index.php?option=com_jwhmcs';
			$this->setRedirect($lnk, $msg);
		}
		
		// Request License
		JRequest::setVar( 'hidemainmenu', 1 );
		JRequest::setVar( 'layout', '03stepthree' );
		
		$mainframe->enqueueMessage( JText::_( 'JWHMCS_ADMIN_INSTALL_SUCCESS_STEPTHREE' ), 'message' );
		parent::display();
	}
	
	
	function stepfour()
	{
		$model	= $this->getModel( 'install' );
		
		if (! $model->stepfourinstall() ) {
			$msg = JText::_( 'JWHMCS_ADMIN_INSTALL_FAILED_STEPFOUR' );
			$lnk = 'index.php?option=com_jwhmcs';
			$this->setRedirect( $lnk, $msg );
		}
		else {
			// Sync WHMCS users into Joomla
			$sync = $this->getModel( 'sync' );
			$sync->reload();
			
			// Remove Files directory - its no longer needed
			$model->removeFiles();
			
			if ( $model->menuExists() ) {
				$msg = JText::_( 'JWHMCS_ADMIN_INSTALL_MENU_EXISTS' );
				$lnk	= 'index.php?option=com_jwhmcs&controller=install&task=stepfive';
			}
			else {
				if (! $model->addMenu() ) {
					$msg = JText::_( 'JWHMCS_ADMIN_INSTALL_FAILED_STEPFOURMENU' );
					$lnk = 'index.php?option=com_jwhmcs';
					$this->setRedirect( $lnk, $msg );
				}
				else {
					$msg = JText::_( 'JWHMCS_ADMIN_INSTALL_SUCCEEDED_STEPFOUR' );
					$lnk	= 'index.php?option=com_jwhmcs&controller=install&task=stepfive';
				}
			}
		}
		JRequest::setVar( 'hidemainmenu', 1 );
		JRequest::setVar( 'layout', '04stepfour' );
		parent::display();
	}
	
	
	function stepfive()
	{
		$user = $this->getModel( 'usermgr' );
		$user->matchAll();
		
		$lnk = 'index.php?option=com_jwhmcs';
		$this->setRedirect( $lnk );
	}
	
	
	function abort()
	{
		$msg = JText::_( 'JWHMCS_ADMIN_CONTR_MSGCNCL' );
		$this->setRedirect( 'index.php?option=com_jwhmcs', $msg );
	}
	
	
	function manual()
	{
		JRequest::setVar( 'layout', 'manual' );
		parent::display();
	}
	
	
	function license()
	{
		$params	= & JComponentHelper::getParams('com_jwhmcs');
		$model	= $this->getModel('install');
		
		$licchk = $model->checkLicense(&$params);
		if (isset($licchk['response'])) {
			$this->setRedirect( 'index.php?option=com_jwhmcs&controller=install&task=apiconxn', JText::_( 'JWHMCS_ADMIN_INSTALL_FAILED_LICCHK' ) );
		}
		else {
			JRequest::setVar( 'hidemainmenu', 1 );
			JRequest::setVar( 'layout', 'license' );
			parent::display();
		}
	}
	
	
	function apiconxn()
	{
		JRequest::setVar( 'hidemainmenu', 1 );
		JRequest::setVar( 'layout', 'apiconxn' );
		parent::display();
	}
	
	
	function licenseAccept()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs', null );
	}
}