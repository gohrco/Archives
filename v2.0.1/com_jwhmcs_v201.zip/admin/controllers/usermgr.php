<?php
/**
 * Default Controller for J!WHMCS Integrator
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since		1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsControllerDefault
 * Extends:		JwhmcsController
 * Purpose:		Used as the default controller for user management
 * 
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsControllerUsermgr extends JwhmcsController
{
	/* ------------------------------------------------------------ *\
	 * Task:		__construct
	 * Purpose:		Needed for building the class
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();

		// Register Extra tasks
		$this->registerTask( 'whmcsadd',		'whmcsedit' );
		$this->registerTask( 'joomadd',			'joomedit' );
		$this->registerTask( 'joomaddsave', 	'joomeditsave' );
		$this->registerTask( 'whmcsaddsave',	'whmcseditsave' );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		joomedit
	 * Purpose:		Allows for adding and eventual editing of Joomla
	 * 				users.
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function joomedit()
	{
		JRequest::setVar( 'view', 'usermgr' );
		JRequest::setVar( 'layout', 'formjoomla' );
		JRequest::setVar( 'hidemainmenu', 1 );
		parent::display();
	}
	
	/* ------------------------------------------------------------ *\
	 * Task:		whmcsedit
	 * Purpose:		Allows for adding and eventual editing of WHMCS
	 * 				users.
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function whmcsedit()
	{
		JRequest::setVar( 'view', 'usermgr' );
		JRequest::setVar( 'layout', 'formwhmcs' );
		JRequest::setVar( 'hidemainmenu', 1 );
		parent::display();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		joomeditsave
	 * Purpose:		Handles saving of Joomla user info from either add
	 * 				or edit task
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function joomeditsave()
	{
		$model		= $this->getModel( 'usermgr' );
		$form		= JRequest::get( 'method' );
		$task		= JRequest::get( 'task' );
		
		if ( $model->joomsave($form, $task) )
		{
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_USRJSY' );
		} else {
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_USRJSN' );
		}
		
		$link = 'index.php?option=com_jwhmcs&controller=usermgr';
		if (!$model->debug->active) $this->setRedirect($link, $msg);
		$model->debug->LinkDisplay($link);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		whmcseditsave
	 * Purpose:		Handles saving of WHMCS user info from either add
	 * 				or edit task
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function whmcseditsave()
	{
		$model		= $this->getModel( 'usermgr' );
		$post		= JRequest::get( 'post' );
		$task		= JRequest::get( 'task' );
		
		$result		= $model->whmcsaddsave($post, $task);
		if ($result['result'] != 'success')
		{
			$msg = JText::sprintf( 'JWHMCS_ADMIN_CONTR_USRWSN', $result['message'] );
		} else {
			$msg = JText::_( 'JWHMCS_ADMIN_CONTR_USRWSY' );
		}
		
		$link = 'index.php?option=com_jwhmcs';
		if (!$model->debug->active) $this->setRedirect($link, $msg);
		$model->debug->LinkDisplay($link);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		sync
	 * Purpose:		Syncronize users that are found by email not by
	 * 				xref database (setting xref type=2)
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function sync()
	{
		$model	= $this->getModel('usermgr');
		$post	= JRequest::get( 'method' );
		
		if ($model->syncUser($post))
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_USRSY' );
		else
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_USRSN' );
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', $msg );
	}
	
	
	function syncBreak()
	{
		$model	= $this->getModel('usermgr');
		$post	= JRequest::get( 'method' );
		
		if ($model->syncBreak($post))
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_USRSBY' );
		else
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_USRSBN' );
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', $msg );
	}
	
	
	function matchAll()
	{
		$model	= $this->getModel('usermgr');
		
		if ($model->matchAll())
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_USRSMY' );
		else
			$msg	= JText::_( 'JWHMCS_ADMIN_CONTR_USRSMN' );
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', $msg );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		cancel
	 * Purpose:		Handle cancelation requests
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function cancel()
	{
		$msg = JText::_( 'JWHMCS_ADMIN_CONTR_MSGCNCL' );
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', $msg );
	}
}