function ajaxCheckLicense()
{
	var license = document.getElementById('licensekey').value;
	license = encodeURIComponent(license);
	document.getElementById('whmcsstatus').innerHTML='<div style="width: 32px; margin: 0px auto; padding: 10px; "><img src="components/com_jwhmcs/assets/ajax-img.gif" /></div><div style="width: 200px; margin: 0px auto; font-size: small; font-weight: bold; clear: both; padding: 10px; text-align: center; ">One moment...</div>';
	var xhr = createXHR();
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var whmcsstatus=document.getElementById("whmcsstatus");
				try //Internet Explorer
				{
					xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
					xmlDoc.async="false";
					xmlDoc.loadXML(xhr.responseText);
				}
				catch(e)
				{
					try //Firefox, Mozilla, Opera, etc.
					{
						parser=new DOMParser();
						xmlDoc=parser.parseFromString(xhr.responseText,"text/xml");
					}
					catch(e) {alert(e.message)}
				}
				var result =xmlDoc.getElementsByTagName("param").item(0);
				whmcsstatus.innerHTML='';
				
				var dsc = result.getElementsByTagName("result")[0].childNodes[0].nodeValue;
				var msg = result.getElementsByTagName("message")[0].childNodes[0].nodeValue;
				
				if (dsc == "success") {
					img = "j-32-yes.png";
					document.getElementById('license').setAttribute("value", "1");
				} else {
					img = "j-32-no.png";
					document.getElementById('license').setAttribute("value", "0");
				}
				txt = "<div style=\"width: 32px; margin: 0px auto; padding: 10px; \"><img src=\"components/com_jwhmcs/assets/icons/"+img+"\" /></div>";
				txt = txt + "<div style=\"width: 200px; margin: 0px auto; font-size: small; font-weight: bold; clear: both; padding: 10px; text-align: center; \">"+msg+"</div>";
				whmcsstatus.innerHTML = txt;
				
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
	xhr.open("GET","index2.php?option=com_jwhmcs&controller=ajax&task=checkValidLicense&license="+license,true);
	xhr.send(null);
}


function ajaxCheckPath()
{
	var whmcsurl = document.getElementById('whmcsurl').value;
	var whmcspath = document.getElementById('whmcspath').value;
	whmcsurl = encodeURIComponent(whmcsurl);
	whmcspath = encodeURIComponent(whmcspath);
	document.getElementById('whmcsstatus').innerHTML='<div style="width: 32px; margin: 0px auto; padding: 10px; "><img src="components/com_jwhmcs/assets/ajax-img.gif" /></div><div style="width: 200px; margin: 0px auto; font-size: small; font-weight: bold; clear: both; padding: 10px; text-align: center; ">One moment...</div>';
	var xhr = createXHR();
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var whmcsstatus=document.getElementById("whmcsstatus");
				try //Internet Explorer
				{
					xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
					xmlDoc.async="false";
					xmlDoc.loadXML(xhr.responseText);
				}
				catch(e)
				{
					try //Firefox, Mozilla, Opera, etc.
					{
						parser=new DOMParser();
						xmlDoc=parser.parseFromString(xhr.responseText,"text/xml");
					}
					catch(e) {alert(e.message)}
				}
				var result =xmlDoc.getElementsByTagName("param").item(0);
				whmcsstatus.innerHTML='';
				
				var dsc = result.getElementsByTagName("result")[0].childNodes[0].nodeValue;
				var msg = result.getElementsByTagName("message")[0].childNodes[0].nodeValue;
				
				if (dsc == "success") {
					img = "j-32-yes.png";
					document.getElementById('paths').setAttribute("value", "1");
				} else {
					img = "j-32-no.png";
					document.getElementById('paths').setAttribute("value", "0");
				}
				txt = "<div style=\"width: 32px; margin: 0px auto; padding: 10px; \"><img src=\"components/com_jwhmcs/assets/icons/"+img+"\" /></div>";
				txt = txt + "<div style=\"width: 200px; margin: 0px auto; font-size: small; font-weight: bold; clear: both; padding: 10px; text-align: center; \">"+msg+"</div>";
				whmcsstatus.innerHTML = txt;
				
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
	xhr.open("GET","index2.php?option=com_jwhmcs&controller=ajax&task=checkPath&whmcsurl="+whmcsurl+"&whmcspath="+whmcspath,true);
	xhr.send(null);
}


function ajaxCheckAPI()
{
	var jwhmcsadminus = document.getElementById('jwhmcsadminus').value;
	var jwhmcsadminpw = document.getElementById('jwhmcsadminpw').value;
	var accesskey = document.getElementById('accesskey').value;
	document.getElementById('apistatus').innerHTML='<div style="width: 32px; margin: 0px auto; padding: 10px; "><img src="components/com_jwhmcs/assets/ajax-img.gif" /></div><div style="width: 200px; margin: 0px auto; font-size: small; font-weight: bold; clear: both; padding: 10px; text-align: center; ">One moment...</div>';
	var xhr = createXHR();
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var apistatus=document.getElementById("apistatus");
				try //Internet Explorer
				{
					xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
					xmlDoc.async="false";
					xmlDoc.loadXML(xhr.responseText);
				}
				catch(e)
				{
					try //Firefox, Mozilla, Opera, etc.
					{
						parser=new DOMParser();
						xmlDoc=parser.parseFromString(xhr.responseText,"text/xml");
					}
					catch(e) {alert(e.message)}
				}
				var result =xmlDoc.getElementsByTagName("param").item(0);
				apistatus.innerHTML='';
				
				var dsc = result.getElementsByTagName("result")[0].childNodes[0].nodeValue;
				var msg = result.getElementsByTagName("message")[0].childNodes[0].nodeValue;
				
				if (dsc == "success") {
					img = "j-32-yes.png";
					document.getElementById('apiconnection').setAttribute("value", "1");
				} else {
					img = "j-32-no.png";
				}
				txt = "<div style=\"width: 32px; margin: 0px auto; padding: 10px; \"><img src=\"components/com_jwhmcs/assets/icons/"+img+"\" /></div>";
				txt = txt + "<div style=\"width: 200px; margin: 0px auto; font-size: small; font-weight: bold; clear: both; padding: 10px; text-align: center; \">"+msg+"</div>";
				apistatus.innerHTML = txt;
				
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
	xhr.open("GET","index2.php?option=com_jwhmcs&controller=ajax&task=checkApi&jwhmcsadminus="+jwhmcsadminus+"&jwhmcsadminpw="+jwhmcsadminpw+"&accesskey="+accesskey,true);
	xhr.send(null);
}


function ajaxCheckAPIU()
{
	var jwhmcsadminus = document.getElementById('jwhmcsadminus').value;
	var jwhmcsadminpw = document.getElementById('jwhmcsadminpw').value;
	var accesskey = document.getElementById('accesskey').value;
	var jwhmcsurl = document.getElementById('jwhmcsurl').value;
	jwhmcsurl = encodeURIComponent(jwhmcsurl);
	document.getElementById('apistatus').innerHTML='<div style="width: 32px; margin: 0px auto; padding: 10px; "><img src="components/com_jwhmcs/assets/ajax-img.gif" /></div><div style="width: 200px; margin: 0px auto; font-size: small; font-weight: bold; clear: both; padding: 10px; text-align: center; ">One moment...</div>';
	var xhr = createXHR();
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var apistatus=document.getElementById("apistatus");
				try //Internet Explorer
				{
					xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
					xmlDoc.async="false";
					xmlDoc.loadXML(xhr.responseText);
				}
				catch(e)
				{
					try //Firefox, Mozilla, Opera, etc.
					{
						parser=new DOMParser();
						xmlDoc=parser.parseFromString(xhr.responseText,"text/xml");
					}
					catch(e) {alert(e.message)}
				}
				var result =xmlDoc.getElementsByTagName("param").item(0);
				apistatus.innerHTML='';
				
				var dsc = result.getElementsByTagName("result")[0].childNodes[0].nodeValue;
				var msg = result.getElementsByTagName("message")[0].childNodes[0].nodeValue;
				
				if (dsc == "success") {
					img = "j-32-yes.png";
					document.getElementById('apiconnection').setAttribute("value", "1");
				} else {
					img = "j-32-no.png";
				}
				txt = "<div style=\"width: 32px; margin: 0px auto; padding: 10px; \"><img src=\"components/com_jwhmcs/assets/icons/"+img+"\" /></div>";
				txt = txt + "<div style=\"width: 200px; margin: 0px auto; font-size: small; font-weight: bold; clear: both; padding: 10px; text-align: center; \">"+msg+"</div>";
				apistatus.innerHTML = txt;
				
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
	xhr.open("GET","index2.php?option=com_jwhmcs&controller=ajax&task=checkApiu&jwhmcsadminus="+jwhmcsadminus+"&jwhmcsadminpw="+jwhmcsadminpw+"&accesskey="+accesskey+"&jwhmcsurl="+jwhmcsurl,true);
	xhr.send(null);
}


function createXHR() {
	var xhr = null;
		if (window.XMLHttpRequest) {
			xhr = new XMLHttpRequest();
		} else if (window.ActiveXObject) {
			try {
				xhr = new ActiveXObject('Microsoft.XMLHTTP');
			} catch (e) {}
		}
	return xhr;
}

function URLEncode (clearString) {
	var output = '';
	var x = 0;
	clearString = clearString.toString();
	var regex = /(^[a-zA-Z0-9_.]*)/;
	while (x < clearString.length) {
		var match = regex.exec(clearString.substr(x));
		if (match != null && match.length > 1 && match[1] != '') {
			output += match[1];
			x += match[1].length;
		} else {
			if (clearString[x] == ' ')
				output += '+';
			else {
				var charCode = clearString.charCodeAt(x);
				var hexVal = charCode.toString(16);
				output += '%' + ( hexVal.length < 2 ? '0' : '' ) + hexVal.toUpperCase();
			}
			x++;
		}
	}
	return output;
}
