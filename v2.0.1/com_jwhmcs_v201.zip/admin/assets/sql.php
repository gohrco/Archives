<?php
/**
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: sql.php 1 2009-09-02 00:16:45Z Steven $
 * @since		1.5.0
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/**
 * SQL Class
 *
 * @package    com_mmg
 */
class Sql
{
	
	/**
	 * Common function to build Where statements
	 * 
	 * @param $wh
	 * @return unknown_type
	 */
	function _where($wh, $type = 'AND') {
		$where = (count($wh) ? ' WHERE '.implode(' '.$type.' ', $wh) : '');
		return $where;
	}
}