<?php
/**
 * Group Management Model for J!WHMCS Integrator
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since		1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model
jimport( 'joomla.installer.installer' );
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');

include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelSync
 * Extends:		JwhmcsModel
 * Purpose:		Used to synchronize the WHMCS user table with J!
 * 
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsModelInstall extends JwhmcsModel
{
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
		
	}
	
	
	function steptwoPlugins()
	{
		$db = & JFactory::getDBO();
		$plugin_array = array('plg_jwhmcs_auth', 'plg_jwhmcs_sysm', 'plg_jwhmcs_user');
		
		$data['plg_jwhmcs_auth'] = array( 'authentication', 'exists' => $this->_checkPluginStatus('authentication') );
		$data['plg_jwhmcs_sysm'] = array( 'system', 'exists' => $this->_checkPluginStatus('system') );
		$data['plg_jwhmcs_user'] = array( 'user', 'exists' => $this->_checkPluginStatus('user') );
		
		// Verify files exist to install / upgrade with return false if not
		foreach ($plugin_array as $plugin) {
			$path = JFolder::makesafe(JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.$plugin);
			if (! JFolder::exists($path)) {
				return false;
			}
		}
		
		$plugin_installer = new JInstaller;
		
		foreach ($data as $k => $array) {
			if ($array['exists']) {
				// Run Uninstall of plugin
				if ($plugin_installer->uninstall('plugin', $array['exists'])) {
					$data[$k]['exists'] = false;
				}
			}
		}
		
		// Install Plugins
		foreach ($plugin_array as $plugin) {
			$status = 'Failed';
			if ($plugin_installer->install(JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.$plugin) ) {
				$status = 'Success';
			}
			$install_status[$plugin] = $status;
		}
		
		// Activate Plugins
		$query = 'SELECT `id`, `element` FROM #__plugins WHERE `folder` IN ("authentication", "system", "user") AND `element` LIKE "%jwhmcs%"';
		$db->setQuery($query);
		$result = $db->loadAssocList();
		
		foreach ($result as $tmp) {
			$map[$tmp['element']] = $tmp['id'];
		}
		
		$query = 'SELECT `id`, `element` FROM #__plugins WHERE `folder` IN ("authentication") AND `element` LIKE "%joomla%"';
		$db->setQuery($query);
		$result = $db->loadAssoc();
		$map[$result['element']] = $result['id'];
		
		$qry[] = 'UPDATE #__plugins SET `published` = 1 WHERE `id` = '.$map['jwhmcs_auth'];
		$qry[] = 'UPDATE #__plugins SET `published` = 1 WHERE `id` = '.$map['jwhmcs_sysm'];
		$qry[] = 'UPDATE #__plugins SET `published` = 1, `ordering` = 10001 WHERE `id` = '.$map['jwhmcs_user'];
		$qry[] = 'UPDATE #__plugins SET `published` = 0, WHERE `id` = '.$map['joomla'];
		
		foreach ($qry as $q) {
			$db->setQuery($q);
			$db->query();
		}
		return true;
	}
	
	
	function steptwo()
	{
		$params	= & JComponentHelper::getParams('com_jwhmcs');
		$uri	= JURI::getInstance();
		
		if ($params->get( 'jwhmcsurl' )) {
			$data->url	= $uri->getScheme().'://'.$params->get( 'jwhmcsurl' );
			$install = $this->checkInstall(&$params);
			
			if ($install['whmcsdir']) {
				$data->path	= $install['whmcsdir'];
			}
			else {
				$data->path = JPATH_ROOT;
			}
		}
		else {
			$data->url	= JURI::base();
			$data->path = JPATH_ROOT;
		}
		
		return $data;
	}
	
	
	function stepthree()
	{
		$params	= & JComponentHelper::getParams('com_jwhmcs');
		$data->license = $params->get( 'licensekey' );
		return $data;
	}
	
	
	function license()
	{
		return $this->stepthree();
	}
	
	
	function stepthreeinstall()
	{
		$db = & JFactory::getDBO();
		$params = $this->_getParams();
		$jcurl	= & JwhmcsCurl::getInstance();
		$juri	= & JURI::getInstance();
		
		$whmcspath = JRequest::getVar( 'whmcspath' );
		$whmcsurl  = JRequest::getVar( 'whmcsurl' );
		$juri->setPath( rtrim($juri->getPath(), 'administrator/index.php' ) );
		$joomlaurl = $juri->toString();
		
		// Cleanup URLs before saving to parameters
		$params[ 'jwhmcsjurl' ]	= ( $params[ 'jwhmcsjurl' ] ? $params[ 'jwhmcsjurl' ] : $this->_quickParseUrl($joomlaurl) );
		$params[ 'jwhmcsurl' ]	= ( $params[ 'jwhmcsurl' ] ? $params[ 'jwhmcsurl' ] : $this->_quickParseUrl($whmcsurl) );
		$params[ 'jwhmcsjrootimgurl' ] = ( $params['jwhmcsjrootimgurl'] ? $params['jwhmcsjrootimgurl'] : $params[ 'jwhmcsjurl' ] );
		$params[ 'jwhmcsjin' ] = ( $params[ 'jwhmcsjin' ] ? $params[ 'jwhmcsjin' ] : $params[ 'jwhmcsjurl' ] );
		$params[ 'jwhmcsjout' ]	= ( $params[ 'jwhmcsjout' ] ? $params[ 'jwhmcsjout' ] : $params[ 'jwhmcsjurl' ] );
		
		// Now set install token
		$params[ 'installtok' ] = md5($whmcspath.$whmcsurl.date("Ymd"));
		$params[ 'jwhmcsvers' ] = '2.0.1';
		$this->_saveParams($params, $params['id']);
		
		// We know both path and url are valid, check to see if previous install
		$url = $this->_buildUrl($whmcsurl, 'jwhmcs.php');
		$jcurl->set(CURLOPT_HEADER, false);
		$jcurl->set(CURLOPT_URL, $url);
		$jcurl->setParse(false);
		$response = $jcurl->loadResults();
		
		$jconfig = true;
		
		if ($jcurl->info['http_code'] < 400 ) {
			// Previous install detected - delete root file and move new one over
			if (! JFile::delete($whmcspath.DS.'jwhmcs.php') ) {
				return false;
			}
			$jconfig = false;
		}
		
		// Move new root file over
		$src = JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.'whmcs'.DS.'jwhmcs.php';
		$dst = $whmcspath.DS.'jwhmcs.php';
		
		if (! JFile::exists($src)) {
			return false;
		}
		
		if (! JFile::copy($src, $dst)) {
			return false;
		}
		
		// Perform work for jconfig file
		if ($jconfig) {
			// Double check to make sure it doesn't exist
			if (JFile::exists($whmcspath.DS.'jconfig.php')) {
				return false;
			}
			// We must move the jconfig over also
			$jconfig = file_get_contents(JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.'whmcs'.DS.'jconfig.php');
			$jconfig = sprintf($jconfig, JPATH_SITE);
			
			if (! file_put_contents($whmcspath.DS.'jconfig.php', $jconfig) ) {
				return false;
			}
		}
		
		// Curl to new file and finish install
		$url = $this->_buildUrl($whmcsurl, 'jwhmcs.php?task=process&action='.($jconfig?'install':'upgrade').'&token='.$params[ 'installtok' ]);
		$jcurl->set(CURLOPT_HEADER, false);
		$jcurl->set(CURLOPT_URL, $url);
		$jcurl->setParse(true);
		$jcurl->setRoot('root');
		$response = $jcurl->loadResult();
		
		if ($response['result'] != 'success' ) {
			return false;
		}
		
		// This must have been an install, so we must save the original WHMCS params
		if ($jconfig) {
			$params[ 'whmcs_version' ]		= $response[ 'whmcs_version' ];
			$params[ 'whmcs_template']		= $response[ 'whmcs_template' ];
			$params[ 'whmcs_systemurl' ]	= $response[ 'whmcs_systemurl' ];
			$params[ 'whmcs_systemsslurl' ]	= $response[ 'whmcs_systemsslurl' ];
			$params[ 'whmcs_defaultcountry' ] = $response[ 'whmcs_defaultcountry' ];
			$params[ 'whmcs_requiredpwstrength' ] = $response[ 'whmcs_requiredpwstrength' ];
			$params[ 'whmcs_nomd5' ]		= $response[ 'whmcs_nomd5' ];
			
			$this->_saveParams($params, $params['id']);
		}
		return true;
	}
	
	
	function stepfourinstall()
	{
		$params = $this->_getParams();
		
		// Validate form first
		$license	= JRequest::getVar( 'licensekey' );
		
		// Now set licensekey and install token
		$params[ 'licensekey' ] = $license;
		$this->_saveParams($params, $params['id']);
		
		return true;
	}
	
	
	function menuExists()
	{
		$db = & JFactory::getDBO();
		$params  = $this->_getParams();
		$existed = false;
		
		// Lookup menutype for duplicates
		$query = 'SELECT `id` FROM `#__menu_types` WHERE `menutype` = "jwhmcs-hidden"';
		$db->setQuery($query);
		$existed = $db->loadResult();
		
		// Check to see if it already exists
		if ($params['jwhloggedinurl']) return true;
		if ($params['jwhloggedouturl']) return true;
		return $existed;
	}
	
	
	function addMenu()
	{
		$db = & JFactory::getDBO();
		$params  = $this->_getParams();
		
		// Create new menu type
		$query = 'INSERT INTO `#__menu_types` (`menutype`, `title`, `description`) VALUES '.
					'("jwhmcs-hidden", "JWHMCS Hidden Menu", "This menu was created by the J!WHMCS Installer to store the Logged In and Logged Out pages")';
		$db->setQuery($query);
		$db->query();
		$menu_id = $db->insertid();
		
		// Add new items to menu
		$rootqry = 	'INSERT INTO `#__menu` (`menutype`, `name`, `alias`, `link`, `type`, `published`, `componentid`, `ordering`, `params`) VALUES ';
		$query = $rootqry .'("jwhmcs-hidden", "Logged In", "jwhmcs-logged-in", "index.php?option=com_jwhmcs&view=default", "component", 1, '.$params['id'].', 1, "")';
		$db->setQuery($query);
		$db->query();
		$params['jwloggedinurl'] = $db->insertid();
		
		$query = $rootqry .'("jwhmcs-hidden", "Logged Out", "jwhmcs-logged-out", "index.php?option=com_jwhmcs&view=default", "component", 1, '.$params['id'].', 2, "")';
		$db->setQuery($query);
		$db->query();
		$params['jwloggedouturl'] = $db->insertid();
		
		// Store new item ids to params
		if ($this->_saveParams($params, $params['id']) ) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
	function stepfour()
	{
		$params	= & JComponentHelper::getParams('com_jwhmcs');
		$data->jwhmcsurl	 = 'http://'.$params->get( 'jwhmcsurl' );
		$data->jwhmcsadminus = $params->get( 'jwhmcsadminus' );
		$data->jwhmcsadminpw = $params->get( 'jwhmcsadminpw' );
		$data->accesskey	 = $params->get( 'accesskey' );
		return $data;
	}
	
	
	function apiconxn()
	{
		return $this->stepfour();
	}
	
	
	function removeFiles()
	{
		// We know that the files have been installed, we don't need the directory any longer
		return JFolder::delete(JPATH_COMPONENT_ADMINISTRATOR.DS.'files');
	}
	
	
	function manual()
	{
		return true;
	}
	
	
	/* ----------------------------------------- *\
	 *              SUB FUNCTIONS                *
	\* ----------------------------------------- */
	
	
	private function _checkPluginStatus( $plugin = 'authentication' )
	{
		$db = & JFactory::getDBO();
		
		$query = 'SELECT `id` FROM #__plugins WHERE `folder` = "'.$plugin.'" AND `element` LIKE "%jwhmcs%"';
		$db->setQuery($query);
		$result	= $db->loadResult();
		
		if (!$result) return false;
		else return $result;
	}
	
	
	private function _buildUrl($path, $file)
	{
		$uri = JURI::getInstance( rtrim($path, '/').'/'.$file );
		return $uri->toString();
	}
	
	
	private function _quickParseUrl($url)
	{
		$tmp = parse_url($url);
		
		// Remove a slash if added to the end of the url and set parameter
		if ($tmp['path']=='/') unset($tmp['path']);
		return $tmp['host'].(isset($tmp['path'])?$tmp['path']:'').(isset($tmp['query'])?$tmp['query']:'').(isset($tmp['fragment'])?$tmp['fragment']:'');
	}
}