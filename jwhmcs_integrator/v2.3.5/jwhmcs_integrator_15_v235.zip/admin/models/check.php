<?php
/**
 * Group Management Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: check.php 169 2011-02-04 05:39:14Z steven_gohigher $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelCheck
 * Extends:		JwhmcsModel
 * Purpose:		Checks the installation
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsModelCheck extends JwhmcsModel
{
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getData
	 * Purpose:		Retrieves the parameters for 
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function getData()
	{
		$params = & JwhmcsParams::getInstance();
		$uri	=   JURI::getInstance();
		
		$data->thisUrl = $uri->current();
		
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		process
	 * Purpose:		Called by ajax to check various aspects of install 
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function process($step = 10)
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params = & JwhmcsParams::getInstance();
		$uri	= & JURI::getInstance();
		$url	=   $uri->toString(array('scheme', 'host', 'path'));
		
		$data['nextstep'] = $step + 10;
		
		switch($step):
		/* ----------------------------------------------------------------- STEP  10 *\
		 * CHECK INSTALLATION - Component Installed
		\* -------------------------------------------------------------------------- */
		case 10:
			// Obviously if we are here the component is at least installed - future revisions may include health check
			$data['status'] = 1;
			break;
		
		/* ----------------------------------------------------------------- STEP  20 *\
		 * CHECK INSTALLATION - Hidden Menu created
		\* -------------------------------------------------------------------------- */
		case 20:
			$query	= "SELECT `id` FROM `#__menu_types` WHERE `menutype` = 'jwhmcs-hidden'";
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 2;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_('CHECK_MSG_FIXIT') ."</a></div>" . JText::_('CHECK_MSG_HIDDENMENU');
			}
			else {
				$data['status'] = 1;
			}
			break;
		
		/* ----------------------------------------------------------------- STEP 30 *\
		 * CHECK INSTALLATION - Check API Connection
		\* -------------------------------------------------------------------------- */
		case 30:
			$query	= "SELECT `id` FROM `#__menu_types` WHERE `menutype` = 'client-menu'";
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 2;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_('CHECK_MSG_FIXIT') ."</a></div>" . JText::_('CHECK_MSG_CLIENTMENU');
			}
			else {
				$data['status'] = 1;
			}
			break;
			
		/* ----------------------------------------------------------------- STEP 100 *\
		 * CHECK INSTALLATION - Authentication Plugin installed and on
		\* -------------------------------------------------------------------------- */
		case 100:
			$query	= "SELECT `id`, `published`, `params` FROM #__plugins WHERE `element` = 'jwhmcs_auth' AND `folder` = 'authentication'";
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 0;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_('CHECK_MSG_FIXIT') ."</a></div>" . JText::_('CHECK_MSG_AUTHPLG_00');
			}
			elseif ($result['published'] == '0') {
				$data['status'] = 2;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_('CHECK_MSG_FIXIT') ."</a></div>" . JText::_('CHECK_MSG_AUTHPLG_02');
			}
			else {
				$data['status'] = 1;
			}
			break;
			
		/* ----------------------------------------------------------------- STEP 110 *\
		 * CHECK INSTALLATION - System Plugin installed and on
		\* -------------------------------------------------------------------------- */
		case 110:
			$query	= "SELECT `id`, `published`, `params` FROM #__plugins WHERE `element` = 'jwhmcs_sysm' AND `folder` = 'system'";
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 0;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_('CHECK_MSG_FIXIT') ."</a></div>" . JText::_('CHECK_MSG_SYSMPLG_00');
			}
			elseif ($result['published'] == '0') {
				$data['status'] = 2;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_('CHECK_MSG_FIXIT') ."</a></div>" . JText::_('CHECK_MSG_SYSMPLG_02');
			}
			else {
				$data['status'] = 1;
			}
			break;
			
		/* ----------------------------------------------------------------- STEP 120 *\
		 * CHECK INSTALLATION - System Language Plugin installed and on
		\* -------------------------------------------------------------------------- */
		case 120:
			$query	= "SELECT `id`, `published`, `params` FROM #__plugins WHERE `element` = 'jwhmcs_sysmlang' AND `folder` = 'system'";
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 2;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_('CHECK_MSG_FIXIT') ."</a></div>" . JText::_('CHECK_MSG_SLNGPLG_00');
			}
			elseif ($result['published'] == '0') {
				$data['status'] = 2;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_('CHECK_MSG_FIXIT') ."</a></div>" . JText::_('CHECK_MSG_SLNGPLG_02');
			}
			else {
				$data['status'] = 1;
			}
			break;
		
		/* ----------------------------------------------------------------- STEP 130 *\
		 * CHECK INSTALLATION - User Plugin installed and on
		\* -------------------------------------------------------------------------- */
		case 130:
			$query	= "SELECT `id`, `published`, `params` FROM #__plugins WHERE `element` = 'jwhmcs_user' AND `folder` = 'user'";
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 1;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_('CHECK_MSG_FIXIT') ."</a></div>" . JText::_('CHECK_MSG_USERPLG_00');
			}
			elseif ($result['published'] == '0') {
				$data['status'] = 2;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_('CHECK_MSG_FIXIT') ."</a></div>" . JText::_('CHECK_MSG_USERPLG_00');
			}
			else {
				$data['status'] = 1;
			}
			break;
		
		/* ----------------------------------------------------------------- STEP 200 *\
		 * CHECK INSTALLATION - WHMCS Root Files Installed
		\* -------------------------------------------------------------------------- */
		case 200:
			$jcurl->setCall();
			$url = $params->get( 'ApiUrl' ).'/jwhmcs.php?task=installCheck&check=root&joomadmin='.$params->get( 'Secret' );
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
			$jcurl->setRoot('root');
			$result = $jcurl->loadResult();
			
			if ($result['result'] == 'success') {
				$data['status'] = 1;
			}
			else {
				$message = "The installer was unable to locate the the J!WHMCS Integrator root files at the location ({$params->get( 'ApiUrl' )}) specified in your settings.  Please double check the settings for the WHMCS Url or install the root files in the correct location.";
				$data['status'] = 0;
				$data['message'][] = $message;
			}
			break;
		
		/* ----------------------------------------------------------------- STEP 210 *\
		 * CHECK INSTALLATION - WHMCS Hook Files Installed
		\* -------------------------------------------------------------------------- */
		case 210:
			$jcurl->setCall();
			$url = $params->get( 'ApiUrl' ).'/jwhmcs.php?task=installCheck&check=hook&joomadmin='.$params->get( 'Secret' );
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
			$jcurl->setRoot('root');
			$result = $jcurl->loadResult();
			
			if ($result['result'] == 'success') {
				$data['status'] = 1;
			}
			else {
				$message	= "The installer was unable to locate some of the J!WHMCS Integrator hook files at the location ({$params->get( 'ApiUrl' )}/includes/hooks) specified in your settings.  ";
				if ($result['message'] & 1)
					$message .= "The file `jwhmcs.php` is missing.";
				if ($result['message'] & 2)
					$message .= "The file `jwhmcs-lang.php` is missing.";
				if (!$result['message'])
					$message .= "Please double check the settings for the WHMCS Url.";
				
				$data['status'] = 0;
				$data['message'][] = $message;
			}
			break;
		
		/* ----------------------------------------------------------------- STEP 220 *\
		 * CHECK INSTALLATION - WHMCS API Files Installed
		\* -------------------------------------------------------------------------- */
		case 220:
			$jcurl->setCall();
			$url = $params->get( 'ApiUrl' ).'/jwhmcs.php?task=installCheck&check=api&joomadmin='.$params->get( 'Secret' );
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
			$jcurl->setRoot('root');
			$result = $jcurl->loadResult();
			
			if ($result['result'] == 'success') {
				$data['status'] = 1;
			}
			else {
				$message	= "The installer was unable to locate some of the J!WHMCS Integrator api files at the location ({$params->get( 'ApiUrl' )}/includes/api) specified in your settings.  ";
				if ($result['message'] & 1)
					$message .= "The file `jwhmcsconfig.php` is missing.";
				if ($result['message'] & 2)
					$message .= "The file `jwhmcsgetsettings.php` is missing.";
				if (!$result['message'])
					$message .= "Please double check the settings for the WHMCS Url.";
				
				$data['status'] = 0;
				$data['message'][] = $message;
			}
			break;
			
		/* ----------------------------------------------------------------- STEP 230 *\
		 * CHECK INSTALLATION - WHMCS Template Files Installed
		\* -------------------------------------------------------------------------- */
		case 230:
			$jcurl->setCall();
			$url = $params->get( 'ApiUrl' ).'/jwhmcs.php?task=installCheck&check=template&joomadmin='.$params->get( 'Secret' );
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
			$jcurl->setRoot('root');
			$result = $jcurl->loadResult();
			
			if ($result['result'] == 'success') {
				$data['status'] = 1;
			}
			else {
				$message	= "The installer was unable to locate the template directories setup by the J!WHMCS Integrator in the {$params->get( 'ApiUrl' )}/templates folder.  ";
				if ($result['message'] & 1)
					$message .= "The directory `jwhmcs-default` is missing.";
				if ($result['message'] & 2)
					$message .= "The directory `jwhmcs-portal` is missing.";
				if (!$result['message'])
					$message .= "Please double check the settings for the WHMCS Url.";
				
				$message .= "  It may not be necessary to have these directories in place if you have already installed your templates elsewhere and it is functional.";
				$data['status'] = 2;
				$data['message'][] = $message;
			}
			break;
			
		/* ----------------------------------------------------------------- STEP 300 *\
		 * CHECK INSTALLATION - Check License
		\* -------------------------------------------------------------------------- */
		case 240:
			$jcurl->setAction('jwhmcsconfig', array("init" => "2" ) );
			$whmcs	= $jcurl->loadResult();
			
			$data['status'] = 1;
			$data['message'][] = JText::_( $whmcs['message'] );
			unset ($whmcs);
			
			break;
			
		/* ----------------------------------------------------------------- STEP 300 *\
		 * CHECK INSTALLATION - Check License
		\* -------------------------------------------------------------------------- */
		case 300:
			$license = $this->checkLicense();
			
			if ($license['return'] == 'Active') {
				$data['status'] = 1;
			}
			elseif (($license['return'] == 'Expired') && ($license['valid'] == 1)) {
				$data['status'] = 2;
				$data['message'] = JText::_('CHECK_MSG_LICENSE_02');
			}
			elseif (isset($license['response'])) {
				$data['status'] = 0;
				$data['message'] = "<div class='checkFix'><a href='{$url}?option=com_jwhmcs&controller=install&task=apiconxn'>" . JText::_('CHECK_MSG_FIXIT') ."</a></div>" . JText::_('CHECK_MSG_LICENSE_01');
			}
			else {
				$data['status'] = 0;
				$data['message'] = "<div class='checkFix'><a href='{$url}?option=com_jwhmcs&controller=install&task=license'>" . JText::_('CHECK_MSG_FIXIT') ."</a></div>" . JText::_('CHECK_MSG_LICENSE_00');
			}
			break;
			
		/* ----------------------------------------------------------------- STEP 310 *\
		 * CHECK INSTALLATION - Check API Connection
		\* -------------------------------------------------------------------------- */
		case 310:
			$apichck = $this->getApiConnection();
			
			if ($apichck['result'] == 'success') {
				$data['status'] = 1;
			}
			else {
				$data['status'] = 0;
				$data['message'] = "<div class='checkFix'><a href='{$url}?option=com_jwhmcs&controller=install&task=apiconxn'>" . JText::_('CHECK_MSG_FIXIT') ."</a></div>{$apichck['message']}";
			}
			break;
		endswitch;
		
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		fixinstall
	 * Purpose:		Called by user through ajax to fix install step 
	 * As of:		version 2.1.0b2
	\* ------------------------------------------------------------ */
	function fixinstall($step = 10)
	{
		$db			= & JFactory::getDBO();
		$jcurl		= & JwhmcsCurl::getInstance();
		$params		= & JwhmcsParams::getInstance();
		$install	= & JModel::getInstance('interview', 'JwhmcsModel');
		
		$result		=   $install->process( $step );
		$data		=   $this->process( $step );
		
		return $data;
	}
	
	
	/* ----------------------------------------- *\
	 *              SUB FUNCTIONS                *
	\* ----------------------------------------- */
	
	
}