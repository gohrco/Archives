<?php
/**
 * Help Page Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: helppage.php 169 2011-02-04 05:39:14Z steven_gohigher $
 * @since      2.1.0
 */
 
// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelHelppage
 * Extends:		JwhmcsModel
 * Purpose:		Used as the model for providing support
 * As of:		version 2.1.0
\* ------------------------------------------------------------ */
class JwhmcsModelHelppage extends JwhmcsModel
{
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
	}
}