<?php
/**
 * Default Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since      1.5.1
 */
 
// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelDefault
 * Extends:		JwhmcsModel
 * Purpose:		Used as the default model for user management
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsModelDefault extends JwhmcsModel
{
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getIconDefinitions
	 * Purpose:		Creates icons for display on the default page
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function getIconDefinitions()
	{
		$ret = array();
		
		$ret[] = $this->_makeIconDefinition( 'j-48-usrmgr.png', JText::_('JWHMCS_ADMIN_BUTTON_USRMGR'), 'usermgr' );
		$ret[] = $this->_makeIconDefinition( 'j-48-grpmgr.png', JText::_('JWHMCS_ADMIN_BUTTON_GRPMGR'), 'grpmgr' );
		$ret[] = $this->_makeIconDefinition( 'j-48-sync.png', JText::_('JWHMCS_ADMIN_BUTTON_WHSYNC'), 'sync' );
		$ret[] = $this->_makeIconDefinition( 'j-48-chinst.png', JText::_('JWHMCS_ADMIN_HEADER_CHINST'), 'check' );
		$ret[] = $this->_makeIconDefinition( 'j-48-settings.png', JText::_('JWHMCS_ADMIN_BUTTON_SETTINGS'), 'config');
		$ret[] = $this->_makeIconDefinition( 'j-48-helppage.png', JText::_('JWHMCS_ADMIN_BUTTON_HELPPAGE'), 'helppage');
		return $ret;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_makeIconDefinition (private)
	 * Purpose:		Assembles into an array the icons in a standard
	 *				definition.
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	private function _makeIconDefinition($iconFile, $label, $controller = null, $view = null, $task = null )
	{
		return array(
			'icon'		=> $iconFile,
			'label'		=> $label,
			'controller'=> $controller,
			'view'		=> $view,
			'task'		=> $task
		);
	}
}