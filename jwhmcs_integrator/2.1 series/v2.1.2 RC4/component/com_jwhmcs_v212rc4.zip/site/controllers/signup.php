<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: default.php 202 2010-04-23 20:49:10Z Steven $
 * @since      2.1.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsControllerRegister
 * Extends:		JController
 * Purpose:		Used to set tasks for default controller
 * As of:		version 2.1.0
\* ------------------------------------------------------------ */
class JwhmcsControllerSignup extends JwhmcsController
{
	/* ------------------------------------------------------------ *\
	 * Task:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
	}
	
	
	function validInfo()
	{
		global $mainframe;
		$type		=   ( ( $type = JRequest::getVar( 'type' ) ) ? $type : JRequest::getVar( 'token' ) );
		$value		=   ( ( $value = JRequest::getVar( 'value' ) ) ? $value : JRequest::getVar( 'jwhmcs' ) );
		$model		= & $this->getModel( 'signup' );
		$result		= & $model->validInfo( $type, $value );
		
		foreach ($result as $k => $v) $data[$k] = $v;
		echo $model->buildResponse($data);
		$mainframe->close();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	register_save
	 * Purpose:		This function saves the registration info sent via
	 * 				the JWHMCS registration form.  It must first validate
	 * 				and then enter the info into the database.
	 * 
	 * As of:		version 1.5.0
	 * 
	 * Significant Revisions:
	 * 	1)  ver 1.5.3 - Oct 2009
	 * 		* Added reCaptcha
	\* ------------------------------------------------------------ */
	function register_save()
	{
		global $mainframe;
		
		$fromjwhmcs = JRequest::getVar( 'fromjwhmcs' );
		 
		// Check for request forgeries
		if (! $fromjwhmcs) // if this variable exists, then we are coming from the jwhmcs root file
		{
			JRequest::checkToken() or jexit( 'Invalid Token' );
		}
		
		// Get required system objects
		$model		= $this->getModel('signup');
		$user 		= clone(JFactory::getUser());
		$pathway 	=& $mainframe->getPathway();
		$config		=& JFactory::getConfig();
		$authorize	=& JFactory::getACL();
		$document   =& JFactory::getDocument();
		$params		=& JwhmcsParams::getInstance();
		$session	=& JFactory::getSession();
		$jcurl		= & JwhmcsCurl::getInstance();
		$db			= & JFactory::getDBO();
		
		JRequest::setVar('layout', 'default');
		
		/* reCaptcha if option set */
		if ( ( ! $fromjwhmcs) && ( $params->get( 'RecaptchaEnable' ) ) )
		{
			// b. put together cUrl parameters
			$fields['privatekey']	= $params->get( 'RecaptchaPrivatekey' );
			$fields['remoteip']		= $_SERVER["REMOTE_ADDR"];
			$fields['challenge']	= JRequest::getVar( 'recaptcha_challenge_field' );
			$fields['response']		= JRequest::getVar( 'recaptcha_response_field' );
			
			// c. save original url and write new url
			$url = 'http://api-verify.recaptcha.net/verify';
			$orig_url = $jcurl->get(CURLOPT_URL);
			$jcurl->set(CURLOPT_URL, $url);
			
			$jcurl->set(CURLOPT_HEADER, false);
			$jcurl->setPostArray($fields);
			$jcurl->setParse(false);
			
			// d. receive response
			$recaptcha = $jcurl->loadResults();
			$recap = preg_split('/\n/', $recaptcha);
			
			// e. reset for next call
			$jcurl->set(CURLOPT_URL, $orig_url);
			$jcurl->setParse(true);
			
			// f. validate setting msg and redirect url if invalid
			if ($recap[0]!= 'true')
			{
				JError::raiseWarning( 200, JText::_( $recap[1] ) );
				JRequest::setVar( 'layout', 'default' );
				parent::display();
				return;
			}
		}
		
		// If user registration is not allowed, show 403 not authorized.
		$usersConfig = &JComponentHelper::getParams( 'com_users' );
		if ($usersConfig->get('allowUserRegistration') == '0') {
			if ($fromjwhmcs)
				$this->_stop('result=failed;error='.JText::_( 'Access Forbidden'));
			else
				JError::raiseError( 403, JText::_( 'Access Forbidden' ));
			return;
		}
		
		// Initialize new usertype setting
		$newUsertype = $usersConfig->get( 'new_usertype' );
		if (!$newUsertype) {
			$newUsertype = 'Registered';
		}
		
		// Build the user array for binding
		$ubind = $this->_getUserArray();
		
		// Check to see if the email is in use - if so, should we match it up?
		if ( ( $userid = $this->_checkEmail( $ubind['email'] ) ) && ( $fromjwhmcs ) )
		{
			if ( $params->get( 'JuserEmailsync' ) )
			{
				$this->_stop('result=success;existing=1;userid='.$userid);
			}
			else
			{
				$this->_stop('result=failed;error='.JText::_( "Email address already in use" ));
			}
		}
		
		// Bind the post array to the user object
		if (!$user->bind( $ubind, 'usertype' )) {
			if($fromjwhmcs)
				$this->_stop('result=failed;error='.JText::_( $user->getError()));
			else
				JError::raiseError( 500, $user->getError());
		}
		
		// Set some initial user values
		$user->set('id', 0);
		$user->set('usertype', '');
		$user->set('gid', $authorize->get_group_id( '', $newUsertype, 'ARO' ));
		
		$date =& JFactory::getDate();
		$user->set('registerDate', $date->toMySQL());
		
		// If user activation is turned on, we need to set the activation information
		$useractivation = ( $fromjwhmcs ? $params->get( 'JuserAuthorize' ) : $usersConfig->get( 'useractivation' ) );
		
		// Dont send welcome email by default
		$sendEmail = false;
		if ($useractivation == '1')
		{
			if ($fromjwhmcs!=2)		// If coming from jwhmcs as type 2, we don't want to send activation email
			{
				jimport('joomla.user.helper');
				$user->set('activation', JUtility::getHash( JUserHelper::genRandomPassword()) );
				$user->set('block', '1');
				$sendEmail = true;
			}
		}
		
		// If there was an error with registration, set the message and display form
		if ( !$user->save() )
		{
			if ($fromjwhmcs)
				$this->_stop('result=failed;error='.JText::_( $user->getError()));
			else
				JError::raiseWarning('', JText::_( $user->getError()));
				$this->_register();
			return false;
		}
		
		// Send registration confirmation mail
		if ($fromjwhmcs)
			$password = $ubind['password'];
		else
			$password = JRequest::getString('password', '', 'post', JREQUEST_ALLOWRAW);
		
		$password = preg_replace('/[\x00-\x1F\x7F]/', '', $password); //Disallow control chars in the email
		
		// Send email message if we have activation set
		if ($sendEmail) {
			$this->_sendMail($user, $password);
		}
		
		// Everything went fine, set relevant message depending upon user activation state and display message
		if ( $useractivation == 1 ) {
			$message  = JText::_( 'REG_COMPLETE_ACTIVATE' );
		} else {
			$message = JText::_( 'REG_COMPLETE' );
		}
		
		if ($fromjwhmcs)
			$this->_stop('result=success;userid='.$user->id);
		else
			$this->setRedirect( '/index.php', $message);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_sendMail (private)
	 * Purpose:		Send email to newly registered user
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	private function _sendMail(&$user, $password)
	{
		global $mainframe;
		
		$db			= &JFactory::getDBO();
		$name 		= $user->get('name');
		$email 		= $user->get('email');
		$username 	= $user->get('username');
		
		$usersConfig 	= &JComponentHelper::getParams( 'com_users' );
		$sitename 		= $mainframe->getCfg( 'sitename' );
		$useractivation = $usersConfig->get( 'useractivation' );
		$mailfrom 		= $mainframe->getCfg( 'mailfrom' );
		$fromname 		= $mainframe->getCfg( 'fromname' );
		$siteURL		= JURI::base();
		
		$subject 	= sprintf ( JText::_( 'Account details for' ), $name, $sitename);
		$subject 	= html_entity_decode($subject, ENT_QUOTES);
		
		if ( $useractivation == 1 ){
			$message = sprintf ( JText::_( 'SEND_MSG_ACTIVATE' ), $name, $sitename, $siteURL."index.php?option=com_user&task=activate&activation=".$user->get('activation'), $siteURL, $username, $password);
		} else {
			$message = sprintf ( JText::_( 'SEND_MSG' ), $name, $sitename, $siteURL);
		}
		
		$message = html_entity_decode($message, ENT_QUOTES);
		
		//get all super administrator
		$query = 'SELECT name, email, sendEmail' .
				' FROM #__users' .
				' WHERE LOWER( usertype ) = "super administrator"';
		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		
		// Send email to user
		if ( ! $mailfrom  || ! $fromname ) {
			$fromname = $rows[0]->name;
			$mailfrom = $rows[0]->email;
		}
		
		JUtility::sendMail($mailfrom, $fromname, $email, $subject, $message);

		// Send notification to all administrators
		$subject2 = sprintf ( JText::_( 'Account details for' ), $name, $sitename);
		$subject2 = html_entity_decode($subject2, ENT_QUOTES);
		
		// get superadministrators id
		foreach ( $rows as $row )
		{
			if ($row->sendEmail)
			{
				$message2 = sprintf ( JText::_( 'SEND_MSG_ADMIN' ), $row->name, $sitename, $name, $email, $username);
				$message2 = html_entity_decode($message2, ENT_QUOTES);
				JUtility::sendMail($mailfrom, $fromname, $row->email, $subject2, $message2);
			}
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_register (private)
	 * Purpose:		Function to register a user
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	private function _register()
	{
		$usersConfig = &JComponentHelper::getParams( 'com_users' );
		if (!$usersConfig->get( 'allowUserRegistration' )) {
			JError::raiseError( 403, JText::_( 'Access Forbidden' ));
			return;
		}

		$user 	=& JFactory::getUser();

		if ( $user->get('guest')) {
			JRequest::setVar('layout', 'default');
		} else {
			$this->setredirect('index.php?option=com_user&task=edit',JText::_('You are already registered.'));
		}

		parent::display();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getUserArray (private)
	 * Purpose:		Retrieve the user array from either the db or post
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	private function _getUserArray()
	{
		if (JRequest::getVar( 'fromjwhmcs' ))
		{
			$ubind	= $this->_getSess(JRequest::getVar( 'token' ));
		}
		else
		{
			// Because we can't send the entire post value to bind, we have to create new array
			$ubind = array(	'name'		=> $this->_buildName(),
							'username'	=> JRequest::getVar('username'),
							'email'		=> JRequest::getVar('email'),
							'password'	=> JRequest::getVar('password'),
							'password2'	=> JRequest::getVar('password2'),
							'task'		=> JRequest::getVar('task'),
							'id'		=> JRequest::getVar('id'),
							'gid'		=> JRequest::getVar('gid'));
		}
		return $ubind;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_buildName (private)
	 * Purpose:		Build the Name field for a new J! registrant
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	private function _buildName()
	{
		$params = & JwhmcsParams::getInstance();
		
		// Name Compilation for Joomla based on setting in component
		$coname	= (JRequest::getVar('companyname')?' ('.JRequest::getVar('companyname').')':'');
		
		switch ($params->get( 'JuserStore' ) ):
		case 3:
			$name = $coname;
		case 1:
			$name = JRequest::getVar('firstname').' '.JRequest::getVar('lastname').$name;
			break;
		case 4:
			$name = $coname;
		case 2:
			$name = JRequest::getVar('lastname').', '.JRequest::getVar('firstname').$name;
			break;
		endswitch;
		
		return $name;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkEmail (private)
	 * Purpose:		Check to see if the email address exists
	 * As of:		version 2.12 rc3
	\* ------------------------------------------------------------ */
	private function _checkEmail( $email )
	{
		$db = & JFactory::getDBO();
		
		$email = trim( $email );
		$query	= "SELECT u.id FROM #__users u WHERE email = '{$email}'";
		$db->setQuery( $query );
		$result = $db->loadResult();
		
		return ( $result ? $result : false );
	}
}