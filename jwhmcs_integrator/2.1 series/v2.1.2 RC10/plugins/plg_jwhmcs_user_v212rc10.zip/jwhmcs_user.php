<?php
/**
 * J!WHMCS Integrator - User Plugin
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: jwhmcs_user.php 199 2010-04-23 20:40:44Z Steven $
 * @since      1.5.0
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.router' );
jimport( 'joomla.environment.uri' );
jimport( 'joomla.plugin.plugin' );

$curlfile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jwhmcs'.DS.'classes'.DS.'class.curl.php';
if (is_readable($curlfile)) include_once($curlfile);

/* ------------------------------------------------------------ *\
 * Class:		plgUserJwhmcs_user
 * Extends:		JPlugin
 * Purpose:		Handles user integration and redirection
 * As of:		version 1.5.0
\* ------------------------------------------------------------ */
class plgUserJwhmcs_user extends JPlugin
{
	public $changeLock	= false;	// New with WHMCS 4.3 - lockable fields
	
	/* ------------------------------------------------------------ *\
	 * Function:	plgUserJwhmcs_user
	 * Purpose:		This is the constructor task
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	function plgUserJwhmcs_user(& $subject, $config)
	{
		parent::__construct($subject, $config);
	}
	
	
	function onBeforeStoreUser( $user, $isnew )
	{
		global $mainframe;
		if (! class_exists('JwhmcsParams') ) return;
		if ( defined( 'JWHMCS_AUTH' ) ) return;	// This must be coming from our own authentication plugin - don't try to add it back to WHMCS (loop)
		
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		if ((! $params->get( 'UserEnable' )) || (! $params->get( 'Enable' )))
			return;	// Don't run if product or user integration disabled
		
		if ( $isnew )
			return;	// Nothing to do if this is new
		
		if (! $params->get( 'WchangeLockables' ) )
			return; // We aren't allowed to change the lockable fields
		
		$jcurl->setAction( 'jwhmcsgetsettings', array( "get" => "ClientsProfileUneditableFields" ) );
		$whmcs	= $jcurl->loadResult();
		
		if ( $whmcs['result'] != 'success' )
			return; // Either a problem with api or WHMCS version not applicable
		
		$this->changeLock = $whmcs['clientsprofileuneditablefields'];
		
		$jcurl->setAction( 'jwhmcsgetsettings', array( "set" => "ClientsProfileUneditableFields=" ) );
		$whmcs = $jcurl->loadResult();
		
		if ( $whmcs['result'] != 'success' )
			$this->changeLock = false;
		
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	onAfterStoreUser
	 * Purpose:		Task after Joomla user is stored by Joomla
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 * 		* Modified parameters to reflect database change
	 *  2.0.2 (Feb 2010)
	 *  	* Corrected company name not being passed to addclient
	 *  1.5.3 (Oct 2009)
	 *  	+ Check for password being reset by user added
	 * 	1.5.1 (Sep 2009)
	 * 		+ encrypt passwords for user edits (WHMCS < 4.1 bug)
	\* ------------------------------------------------------------ */
	function onAfterStoreUser($user, $isnew, $succes, $msg)
	{
		global $mainframe;
		if (! class_exists('JwhmcsParams') ) return;
		if ( defined( 'JWHMCS_AUTH' ) ) return;	// This must be coming from our own authentication plugin - don't try to add it back to WHMCS (loop)
		
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		if ((! $params->get( 'UserEnable' )) || (! $params->get( 'Enable' )))
			return;	// Don't run if product or user integration disabled
		
		// Check if the user is new - if so then addclient function
		if ($isnew):
			$action	= 'addclient';
			if (JRequest::getVar( 'usedata' )):
				$company = (JRequest::getVar('company') ? JRequest::getVar('company') : JRequest::getVar('companyname'));
				$fields['firstname']	= JRequest::getVar( 'firstname' );
				$fields['lastname']		= JRequest::getVar( 'lastname' );
				$fields['companyname']	= $company;
				$fields['address1']		= JRequest::getVar( 'address1' );
				$fields['address2']		= JRequest::getVar( 'address2' );
				$fields['city']			= JRequest::getVar( 'city' );
				$fields['state']		= JRequest::getVar( 'state' );
				$fields['postcode']		= JRequest::getVar( 'postcode' );
				$fields['country']		= JRequest::getVar( 'country' );
				$fields['phonenumber']	= JRequest::getVar( 'phonenumber' );
				$fields['currency']		= '1';
			else:
				$name = explode(' ', $user['name']);
				if (count($name)< 2) $name[1] = $name[0]; 
				$fields['firstname']	= $name[0];
				$fields['lastname']		= $name[1];
				$fields['address1']		= $params->get( 'WuserDefaultaddress' );
				$fields['city']			= $params->get( 'WuserDefaultcity' );
				$fields['state']		= $params->get( 'WuserDefaultstate' );
				$fields['postcode']		= $params->get( 'WuserDefaultpostal' );
				$fields['country']		= $params->get( 'WuserDefaultcountry' );
				$fields['phonenumber']	= $params->get( 'WuserDefaultphone' );
				$fields['currency']		= '1';
			endif;
			$fields['email']		= $user['email'];
			$fields['password2']	= JRequest::getVar( 'password' );
		else:
			
			// Retrieve existing whmcsid from xref db based on user_id
			$query = 'SELECT `xref_b` as `clientid`, `xref_type` FROM #__jwhmcs_xref '
						.'WHERE xref_a='.$user['id'].' AND xref_type BETWEEN 1 AND 9';
			$db->setQuery($query);
			$result = $db->loadAssoc();
			
			if (!$result)
				return;
			
			$type	= $this->_getType( $result['xref_type'] );
			$wuser	= $this->_getWhmcsData( $result['clientid'], 'id', $type );
			$passwd	= $this->_getPassword( $wuser, $type );
			
			if (! $wuser )
				return;	// No user found to update
			
			switch ( $type ):
			case 'client':
				
				// Create the fields array for retrieving existing WHMCS user
				$action					= 'updateclient';
				$fields['clientid']		= $result['clientid'];
				$fields['email']		= $user['email'];
				if ( $passwd )
					$fields['password2']= $passwd;
				
				$fields['jwhmcs']		= 1;
				
				if ($mainframe->isAdmin())
					$fields['status']	= (JRequest::getVar( 'block' )==1?'Inactive':'Active');
				
				break;
			case 'contact':
				$action = 'jwhmcsgetcontact';
				$newPw	= $passwd ? ";password={$passwd}" : "";
				
				$status	= '';
				if ( $mainframe->isAdmin() )
					$status	= ";subaccount=" . ( JRequest::getVar( 'block' ) == 1 ? 0 : 1 );
					
				$fields['set']			= "id={$wuser['id']};email={$user['email']}" . $newPw . $status;
				
				break;
			endswitch;
		endif;
		
		// Pass function and parameters to cURL getting back the whmcs_id
		$jcurl->setAction($action, $fields);
		$whmcs	= $jcurl->loadResult();
		
		if ($isnew):
			// Store this new id w/ the user id in the xref db
			$query = 'INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) '
						.'VALUES ('.$user['id'].', 1, '.$whmcs['clientid'].')';
			$db->setQuery($query);
			$db->query();
		else:
			
			// WHMCS 4.3 - if lockable fields set, reset them here
			if ( $this->changeLock !== false )
			{
				$jcurl->setAction( 'jwhmcsgetsettings', array( "set" => "ClientsProfileUneditableFields={$this->changeLock}" ) );
				$whmcs = $jcurl->loadResult();
			}
			
			if ($mainframe->isAdmin())
				return;		// Don't redirect to WHMCS if Administrator
			
			// Send to _storeSess and get stored token back
			$token = $this->_storeSess($whmcs['clientid'], $user['email'], $user['password'], null);
			
			// Create URL for redirecting to WHMCS for loggin in
			$uri = & JURI::getInstance($params->get( 'ApiUrl' ));
			$uri->setScheme( 'http' . ( $params->get( 'RedirGatewayssl' ) ? 's' : '' ) );
			$uri->setPath( $uri->getPath() . '/jwhmcs.php' );
			$uri->setVar( 'task', 'ulogin' );
			$uri->setVar( 'a', $token );
			$uri->setVar( 'jwhmcs', '1' );
			$url = $uri->toString();
			$mainframe->redirect($url);
		endif;
	}

	
	/* ------------------------------------------------------------ *\
	 * Function:	onBeforeDeleteUser
	 * Purpose:		Task run before deleting user in Joomla
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	function onBeforeDeleteUser($user)
	{
		global $mainframe;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	onAfterDeleteUser
	 * Purpose:		Task run after deleting a user in Joomla
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	function onAfterDeleteUser($user, $succes, $msg)
	{
		global $mainframe;
	}

	
	/* ------------------------------------------------------------ *\
	 * Function:	onLoginUser
	 * Purpose:		Task run after user authenticated
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 * 		* Modified parameters to reflect database change
	\* ------------------------------------------------------------ */
	function onLoginUser($user, $options)
	{
		// 0:  Initialize variables
		global $mainframe;
		if (! class_exists('JwhmcsParams') ) return;
		$db		= & JFactory::getDBO();
		$params	= & JwhmcsParams::getInstance();
		
		if ($mainframe->isAdmin())
			return; // Dont run in admin
		
		if ((! $params->get( 'UserEnable' )) || (! $params->get( 'Enable' )))
			return;	// Don't run if product or user integration disabled
		
		if ( $user['type'] != 'jwhmcs_auth' )
			return; // Something else authenticated, so we dont have a clear password to send to WHMCS
		
		// Check to make sure user can login to WHMCS
		if ( $this->_checkLogin($user) !== true )
			return;
		
		// 2:  Store variables to database and get token back from function
		$juri = & JURI::getInstance();
		
		$param['email']	= $user['email'];
		$param['password']	= $user['password'];
		if ($goto = JRequest::getVar( 'goto' )) $param['goto'] = $goto;
		
		$jwhmcstask = JRequest::getVar( 'jwhmcstask' );
		if ( trim ($jwhmcstask) == '' ) $jwhmcstask = 'ulogin';
		
		$param['remember']	= JRequest::getVar( 'remember' );
		$param['return'] = $this->_getReturn($options);
		
		$date = & JFactory::getDate( strtotime(gmdate("M d Y H:i:s", time())) + 30 );
		$param['timestamp']	= $date->toUnix();
		
		$token = $this->_storeSess($param);
		
		$uri = & JURI::getInstance($params->get( 'ApiUrl' ));
		$uri->setScheme( 'http' . ( $params->get( 'RedirGatewayssl' ) ? 's' : '' ) );
		$uri->setPath( $uri->getPath() . '/jwhmcs.php' );
		$uri->setVar( 'task', $jwhmcstask );
		$uri->setVar( 'a', $token );
		$uri->setVar( 'jwhmcs', '1' );
		// 3:  Create URL for redirecting to WHMCS for loggin in
		$url = $uri->toString(); // 'http'.($params->get( 'RedirGatewayssl' )?'s':'').'://'.$params->get( 'ApiUrl' ).'/jwhmcs.php?task=login&a='.$token;
		$mainframe->redirect($url);
	}

	
	/* ------------------------------------------------------------ *\
	 * Function:	onLogoutUser
	 * Purpose:		Task run after user logs out
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 * 		* Modified parameters to reflect database change
	\* ------------------------------------------------------------ */
	function onLogoutUser($user)
	{
		global $mainframe;
		if (! class_exists('JwhmcsParams') ) return;
		$params	= & JwhmcsParams::getInstance();
		
		if ($mainframe->isAdmin())
			return; // Dont run in admin
		
		if ((! $params->get( 'UserEnable' )) || (! $params->get( 'Enable' )))
			return;	// Don't run if product or user integration disabled
		
		// Since we are the last user plugin to run before redirection kill cookie
		setcookie( JUtility::getHash('JLOGIN_REMEMBER'), false, time() - 86400, '/' );
		
		// Create URL for redirecting to WHMCS for loggin out
		$uri = & JURI::getInstance($params->get( 'ApiUrl' ));
		$uri->setScheme( 'http' . ( $params->get( 'RedirGatewayssl' ) ? 's' : '' ) );
		$uri->setPath( $uri->getPath() . '/jwhmcs.php' );
		$uri->setVar( 'task', 'ulogout' );
		$uri->setVar( 'jwhmcsout', '1' );
		$url = $uri->toString();	// 'http'.($params->get( 'RedirGatewayssl' )?'s':'').'://'.$params->get( 'ApiUrl' ).'/logout.php?goto=jwhmcs';
		$mainframe->redirect($url);
	}
	
		
	/* ------------------------------------------------------------ *\
	 * Function:	_storeSess (private)
	 * Purpose:		Stores values to database and returns token
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	private function _storeSess($values = null)
	{
		$db =& JFactory::getDBO();
		
		// Create a new token
		$token = JUtility::getToken(true);
		
		if (!is_null($values))
		{
			foreach ($values as $k => $v)
			{
				$val[] = $k.'='.$v;
			}
			$value = implode("\n", $val);
		}
		else
		{
			$value = null;
		}
		
		// Store UID, UEM and UPW in database for retrieval
		$query = 'INSERT INTO `#__jwhmcs_sess` (`token`, `value`) '
					.'VALUES ("'.$token.'", "'.$value.'")';
		$db->setQuery($query);
		$db->query();
		
		return $token;
	}
	
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkLogin (private)
	 * Purpose:		Checks the xref_type for the user that is logging
	 * 				in to see if additional actions need to be taken.
	 * 				1 = all is matched up ok - proceed
	 * 				2 = change password in WHMCS first, then proceed
	 * 				3 = redirect to component asking for new password
	 * 				4 = user belongs to a group, pull that grp info
	 * As of:		version 1.5.0
	 * 
	 * Revisions:
	 *  1.5.1 (Sept 2009)
	 *   	+ Added group ability
	\* ------------------------------------------------------------ */
	private function _checkLogin(&$user)
	{
		// 0:  Initialize variables
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		// 1:  Set query to pull xref table to check type
		$query = 'SELECT `xref_a` as `joomlaid`, `xref_type` as `type`, `xref_b` as `clientid` FROM #__jwhmcs_xref AS x INNER JOIN #__users AS a ON x.xref_a = a.id '
					.'WHERE a.username ="'.$user['username'].'" AND xref_type BETWEEN 1 AND 9';
		$db->setQuery($query);
		$result = $db->loadAssoc();
		
		// 2:  Test for types, failing if none found
		if (!$result)	// User isn't matched to anyone in WHMCS don't bother logging in
			return false;
		
		$type	= $this->_getType( $result['type'] );
		
		switch ($result['type']):
		case 1:			// Everything is ok - user already matched up
		case 5:			// Subaccount user is matched without issue
			return true;
			break;
		case 2:			// User was matched up by Admin, change pw in WHMCS
		case 3:			// User account added by admin in Joomla, change pw in WHMCS
		case 6:			// Subaccount was matched up by Admin, change pw in WHMCS
		case 7:			// Subaccount was added by admin in Joomla, change pw in WHMCS (used?)
			// Retrieve matching data from WHMCS
			$whmcs	= $this->_getWhmcsData($user['email'], 'email', $type );
			
			// Test password in WHMCS first
			$testpw	= $this->_testWhmcsPassword($whmcs['password'], $user['password']);
			
			// If correct we will update xref
			if ($testpw) {
				$return = true;
			}
			// Password is incorrect, so can we resync it?
			elseif ($params->get( 'WuserAutosync')) {
				$change = $this->_changeWhmcsPassword($whmcs['id'], $user['password'], $whmcs['xref_type']);
			
				// Negative result on change
				if (! $change)
					return false;
			}
			// Password is incorrect and we can't resync it
			else {
				return false;
			}
			
			$query	= "UPDATE `#__jwhmcs_xref` SET `xref_type` = ".( $whmcs['xref_type'] == 2 ? "1" : "5" )." WHERE xref_a = {$result['joomlaid']} AND xref_b = {$result['clientid']}";
			$db->setQuery($query);
			return $db->query();
			
			break;
		case 4:			// User belongs to a group
			$query	= 'SELECT u.`password` as `passwd`, u.`email` as `email` '
						.' FROM #__jwhmcs_group as u '
						.' WHERE u.id = '.$result['clientid'];
			$db->setQuery($query);
			
			if ($result = $db->loadAssoc()) {
				$user['email']		= $result['email'];
				$user['username']	= $result['username'];
				$user['password']	= $result['passwd'];
				$return = true;
			}
			else
				$return = false;
			
			break;
		case 8:
		case 9:
			global $mainframe;
			
			$uri = & JURI::getInstance();
			
			// We have to store the password for the next jump
			$token = $this->_storeSess( array( 'password' => $user['password'] ) );
			
			$uri->setVar( 'option',	'com_jwhmcs' );
			$uri->setVar( 'view',	'register' );
			$uri->setVar( 'layout',	'username' );
			$uri->setVar( 'task',	'display' );
			$uri->setVar( 'token',	$token );
			if ( JRequest::getVar( 'jwhmcs' ) ) $uri->setVar( 'jwhmcs', JRequest::getVar( 'jwhmcs' ) );
			
			$query = $uri->getQuery();
			
			$url = JRoute::_( "index.php?{$query}" );
			
			$mainframe->redirect( $url );
			
		endswitch;
		
		// 3:  Return true or false
		if ($return)
			return true;
		
		return false;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_testWhmcsPassword (private)
	 * Purpose:		Validates a WHMCS Password
	 * As of:		2.1.0 (April 2010)
	\* ------------------------------------------------------------ */
	private function _testWhmcsPassword($encoded, $clear)
	{
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		if ($params->get( 'WhmcsNomd5' )) {	// We are not using MD5
			$jcurl->setAction('decryptpassword', array('password2' => $encoded));
			$whmcs	= $jcurl->loadResult();
			
			if ($whmcs['result'] == 'success') { 
				$return = ( $whmcs['password'] == $clear ? true : false );
			}
		}
		else {	// We are using MD5 here
			$testpw = $this->_parseWPassword($encoded, $clear);
			$return = ( $testpw == $encoded ? $testpw : false );
		}
		return $return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_parseWPassword (private)
	 * Purpose:		This function parses and returns encrypted WHMCS
	 * 				password for comparison purposes.
	 * ------------------------------------------------------------ */
	private function _parseWPassword($encoded, $clear)
	{
		$pwexp	= explode(':', $encoded);
		return md5($pwexp[1].$clear).':'.$pwexp[1];
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_getWhmcsData
	 * Purpose:		Retrieves data from WHMCS
	 * As of:		2.1.0
	\* ------------------------------------------------------------ */
	function _getWhmcsData($method, $by = 'email', $type = 'client' )
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		switch ($type):
		case 'client':
			
			if ($by == 'email') {
				$jcurl->setAction('getclientsdatabyemail', array('email' => $method));
			}
			else {
				$jcurl->setAction('getclientsdata', array('clientid' => $method));
			}
			
			$whmcs	= $jcurl->loadResult();
		
			// WHMCS v421:  Now receive array of array -- need to test for it
			if ( isset($whmcs[0]['result']) ) $whmcs = $whmcs[0];
			
			if (( isset($whmcs['result'])) && ($whmcs['result'] == 'success')) {
				$whmcs['xref_type'] = 2;
				return $whmcs;
			}
			break;
			
		case 'contact':
			
			$jcurl->setAction('jwhmcsgetcontact', array("get" => "$by=$method"));
			$whmcs = $jcurl->loadResult();
			
			if ($whmcs['result'] == 'success') {
				$whmcs['userid'] = $whmcs['id'];
				$whmcs['xref_type'] = 6;
				return $whmcs;
			}
			
			break;
		endswitch;
		
		return false;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getPassword (private)
	 * Purpose:		Wrapper for retrieving what the password should be
	 * As of:		2.1.12rc2 (August 2010)
	\* ------------------------------------------------------------ */
	private function _getPassword( $wuser, $type )
	{
		$newPassword	= ( ( $pass = JRequest::getVar( 'password1' ) ) ? $pass : ( $pass = JRequest::getVar( 'password' ) ) ? $pass : false );
		 
		if ( $newPassword === false ) {
			return false;
		}
		else 
		{
			return $this->_findWhmcsPassword( ($type == 'client' ? $wuser['clientid'] : $wuser['id'] ), $newPassword, $type );
		} 
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_findWhmcsPassword (private)
	 * Purpose:		Determine the password to use for WHMCS
	 * As of:		2.1.0 (April 2010)
	\* ------------------------------------------------------------ */
	private function _findWhmcsPassword($clientid, $password, $type = 'client' )
	{
		$jcurl			= & JwhmcsCurl::getInstance();
		$params			= & JwhmcsParams::getInstance();
		$usepassword	=   $password;
		
		// If WHMCS version 4.1 or higher, return password clear text
		if ( ( str_replace(".", "", $params->get( 'WhmcsVersion' ) ) < 410 ) || $type == 'contact' ) {
			// We must encode the password for WHMCS < 4.1
			switch ( $type ):
			case 'contact':
				$jcurl->setAction( "jwhmcsgetcontact", array( 'get' => "id={$clientid}" ) );
				break;
			case 'client':
				$jcurl->setAction ( "getclientpassword", array( 'userid' => $clientid ) );
				break;
			endswitch;
			
			$whmcs	= $jcurl->loadResult();
			
			// Explode password hash to get salt and resalt new password and return
			$pwexp	= explode(':', $whmcs['password']);
			$usepassword = md5($pwexp[1].$password).':'.$pwexp[1];
		}
		
		return $usepassword;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_changeWhmcsPassword (private)
	 * Purpose:		Pulls the current WHMCS password, grabbing the salt
	 * 				and md5's the new password, returning it to calling
	 * 				function
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 * 		* Modified parameters to reflect database change
	 * 		- Removed call to WHMCS through curl to test for version
	\* ------------------------------------------------------------ */
	private function _changeWhmcsPassword($clientid, $password, $type = 2)
	{
		$jcurl			= & JwhmcsCurl::getInstance();
		
		$usepassword	=   $this->_findWhmcsPassword($clientid, $password);
		
		// Subaccounts
		if ($type == 6 ) {
			$fields['set']			= "id={$clientid};password=$usepassword";
			$action = 'jwhmcsgetcontact';
		}
		// Regular clients
		else {
			$fields['clientid']		= $clientid;
			$fields['password2']	= $usepassword;
			$action = 'updateclient';
		}
		
		$jcurl->setAction($action, $fields);
		$whmcs	= $jcurl->loadResult();
		
		return ( $whmcs['result']=='success' ? true : false );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getReturn (private)
	 * Purpose:		Sends correct return back based on login method
	 * As of:		2.0.2 (Mar 2010)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 * 		* Modified parameters to reflect database change
	 * 	2.0.4 (Mar 2010)
	 * 		* Corrected return variable issue
	\* ------------------------------------------------------------ */
	private function _getReturn(&$options)
	{
		$juri	= & JURI::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		if (JRequest::getVar( 'whmcs' ) || JRequest::getVar( 'return' )) {
			return JRequest::getVar( 'return' );
		}
		
		return base64_encode( $params->get( 'RedirLoginurl' ) );
//		$return = & JURI::getInstance( $params->get( 'RedirLoginurl' ) );
//		$return->setScheme( 'http'.( $params->get( 'RedirLoginssl' ) == 1 ? 's' : '' ) );
//		return base64_encode($return->toString());
	}
	
	
	private function _getType( $xref_type )
	{
		$ret				= false;
		$xtypes				= array();
		$xtypes['client']	= array( 1, 2, 3, 8 );
		$xtypes['contact']	= array( 5, 6, 7, 9 );
		$xtypes['group']	= array( 4 );
		
		foreach ( $xtypes as $type => $values )
		{
			foreach ( $values as $value )
			{
				if ( $xref_type == $value )
				{
					$ret	= $type;
				}
			}
		}
		
		return $ret;
	}
}