<?php
/**
 * Group Management Controller for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsControllerSync
 * Extends:		JwhmcsController
 * Purpose:		Used for WHMCS User Synchronization
 * 
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsControllerConfig extends JwhmcsController
{
	/* ------------------------------------------------------------ *\
	 * Task:		__construct
	 * Purpose:		Needed for building the class
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
	}
	
	
	function save()
	{
		$model	= $this->getModel( 'config' );
		
		if ($model->storeData())
			$msg = JText::_( 'JWHMCS_ADMIN_CONTR_CONFIGY' );
		else
			$msg = JText::_( 'JWHMCS_ADMIN_CONTR_CONFIGN' );
		
		$link = 'index.php?option=com_jwhmcs';
		$this->setRedirect($link, $msg);
		
	}
}