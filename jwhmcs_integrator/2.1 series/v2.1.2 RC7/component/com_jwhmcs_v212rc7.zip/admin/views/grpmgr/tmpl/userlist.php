<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');

$j32jwhmcs = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-jwhmcs.png';
$j32grpmgr = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-grpmgr.png';
$j32helppage = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-helppage.png';
$j48grpmgr = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-48-grpmgr.png';
?>
<style type="text/css">
.icon-32-jwhmcs		{ background-image: url(<?php echo $j32jwhmcs; ?>); }
.icon-32-grpmgr		{ background-image: url(<?php echo $j32grpmgr; ?>); }
.icon-32-helppage	{ background-image: url('<?php echo $j32helppage; ?>'); }
.icon-48-grpmgr		{ background-image: url(<?php echo $j48grpmgr; ?>); }
</style>

<form action="index.php" method="post" name="adminForm">
<div id="adminCell">
	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_( 'JWHMCS_ADMIN_LABEL_ID' ); ?>
			</th>
			<th width="20">
				<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->data ); ?>);" />
			</th>
			<th>
				<?php echo JText::_( 'JWHMCS_ADMIN_LABEL_MEMBER' ); ?>
			</th>
			<th>
				<?php echo JText::_( 'JWHMCS_ADMIN_LABEL_MEMAIL' ); ?>
			</th>
		</tr>
	</thead>
	<?php
	$k = 0;
	for ($i=0, $n=count( $this->data ); $i < $n; $i++)	{
		$row = &$this->data[$i];
		$checked 	= JHTML::_('grid.id',   $i, $row->id );
		?>
		<tr class="<?php echo "row$k"; ?>">
			<td>
				<?php echo $row->id; ?>
			</td>
			<td>
				<?php echo $checked; ?>
			</td>
			<td>
				<?php echo $row->name; ?>
			</td>
			<td>
				<?php echo $row->email; ?>
			</td>
		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	</table>
</div>

<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="grpmgr" />
<input type="hidden" name="groupid" value="<?php echo $this->groupid; ?>" />
</form>