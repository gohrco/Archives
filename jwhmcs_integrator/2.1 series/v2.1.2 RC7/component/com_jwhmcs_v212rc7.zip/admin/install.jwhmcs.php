<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id$
 * @since      2.0.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');	

class Status {
	var $STATUS_FAIL = 'Failed';
	var $STATUS_SUCCESS = 'Success';
	var $infomsg = array();
	var $errmsg = array();
	var $status;
}

$db	= & JFactory::getDBO();
$install_status = array();

$status = new Status();
$status->status = $status->STATUS_SUCCESS;

$install_status['com_jwhmcs'] =$status; 

function com_install() {
	return true;
}

?>
<style type="text/css" >
table.adminform {
	font-size: 1.1em;
	font-weight: normal;
	line-height: 120%;
}
p.install {
	color: #000000;
	text-align: left;
	text-indent: 1.8em;
}
div#cpanel {
	clear: both;
	margin: 0px auto;
	width: 400px;
}
#cpanel div.icon {
	margin: 10px 40px;
	text-align:center;
}
div.icon span {
	font-size: 0.8em;
}
ul#adminMenu {
	list-style-type: disc;
}
ol#adminMenu, ul#adminMenu {
	color:#000000;
	font-weight:normal;
	margin: 0px 16px;
	text-align:left;
	text-indent:1.8em;
}
</style>
<table width="100%" border="0" cellpadding="0" cellspacing="5">
	<tr>
		<td width="300" align="center" valign="top">
			<img src="<? echo JURI::base(); ?>components/com_jwhmcs/assets/logo.jpg" width="281" height="64" />
		</td>
		<td>
			
		</td>
	</tr>
	<tr>
		<td colspan="2">
			<p class="install">
			Thank you for purchasing and installing J!WHMCS Integrator!  The Joomla component portion of J!WHMCS Integrator has been installed.  To complete installation, you can select from either having the installation completed automatically for you, or to complete the installation manually yourself.</p>
			<p class="install">
			If your Joomla site and your WHMCS site are live and active and you wish to proceed cautiously with the installation, then it is recommended you do a MANUAL install.  On the WHMCS portion of the install, a hook file is installed in your WHMCS / includes/hooks diretory that will be immediately active upon installation.</p>
			<p class="install">
			The following steps will be completed if you select the automatic installation:</p>
			<ol id="adminMenu">
				<li>Plugins installed (authentication, system and user plugins) and activated</li>
				<li>WHMCS files installed</li>
				<li>License verified</li>
				<li>API connection established</li>
				<li>Existing users from WHMCS imported into J!WHMCS Integrator table</li>
				<li>User accounts are matched up based upon email addresses</li>
			</ol>
			
			<p class="install">
			To complete your installation using the Automatic method below, you will require the following information:</p>
			<ul id="adminMenu">
				<li>Your J!WHMCS Integrator License (available to you when you purchased the product)</li>
				<li>URL to your WHMCS Installation</li>
				<li>File Path to your WHMCS Installation (for automatic install, this path must be accessible by Joomla!)</li>
				<li>WHMCS API Username</li>
				<li>WHMCS API Password</li>
				<li>WHMCS API Access Key (if required by your WHMCS)</li>
			</ul>
			
			<div id="cpanel">
				<div class="icon">
					<a href="<?php echo JURI::base(); ?>index.php?option=com_jwhmcs&controller=install&task=interview">
						<img
							src="<?php echo JURI::base().'components/com_jwhmcs/assets/icons/Automatic.png'; ?>"
							border="0" alt="Automatic Installation" />
						<span>Automatic Install</span>
					</a>
				</div>
				<div class="icon">
					<a href="<?php echo JURI::base(); ?>index.php?option=com_jwhmcs&controller=install&task=manual">
						<img
							src="<?php echo JURI::base().'components/com_jwhmcs/assets/icons/Manual.png'; ?>"
							border="0" alt="Manual Installation" />
						<span>Manual Install</span>
					</a>
				</div>
			</div>
		</td>
	</tr>
</table>