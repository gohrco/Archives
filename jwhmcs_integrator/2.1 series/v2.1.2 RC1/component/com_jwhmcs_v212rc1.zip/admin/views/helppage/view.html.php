<?php
/**
 * Help Page View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: view.html.php 97 2010-01-11 18:56:24Z Steven $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsViewHelppage
 * Extends:		JView
 * Purpose:		Used to view support options
 * As of:		version 2.1.0
\* ------------------------------------------------------------ */
class JwhmcsViewHelppage extends JView
{
	/* ------------------------------------------------------------ *\
	 * Method:		display
	 * Purpose:		Assembles the page for the application to send to
	 * 				the user
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function display($tpl = null)
	{
		
		JToolBarHelper :: title( JText::_( 'JWHMCS_ADMIN_TITLE_HELPPAGE' ), 'helppage.png' );
		JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
		
		parent::display($tpl);
	}
}