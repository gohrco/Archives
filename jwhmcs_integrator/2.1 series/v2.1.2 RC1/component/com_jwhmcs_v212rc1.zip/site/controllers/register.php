<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: default.php 202 2010-04-23 20:49:10Z Steven $
 * @since      2.1.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsControllerRegister
 * Extends:		JController
 * Purpose:		Used to set tasks for default controller
 * As of:		version 2.1.0
\* ------------------------------------------------------------ */
class JwhmcsControllerRegister extends JController
{
	/* ------------------------------------------------------------ *\
	 * Task:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		validateUsername
	 * Purpose:		Called through Ajax to validate a username
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function validateUsername()
	{
		global $mainframe;
		$username	= & JRequest::getVar( 'username' );
		$userid		= & JRequest::getVar( 'joomlaid' );
		$model		= & $this->getModel( 'register' );
		$result		= & $model->validateUsername( $username, $userid);
		
		foreach ($result as $k => $v) $data[$k] = $v;
		echo $model->buildResponse($data);
		$mainframe->close();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		submit
	 * Purpose:		Global submit handler
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function submit()
	{
		$model	= $this->getModel( 'register' );
		$name	= "submit" . ucfirst( JRequest::getVar( 'layout' ) );
		$result	= $model->$name();
		
		JRequest::setVar('view', 'register' );
		parent::display();
	}
}