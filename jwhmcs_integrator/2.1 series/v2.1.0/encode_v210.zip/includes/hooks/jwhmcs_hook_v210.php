<?php

define( 'JWHMCSHOOKVERS', '2.1.0' );

/**
 * @package		J!WHMCS Integrator
 * @copyright		2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license		GNU General Public License version 2, or later
 * @version		$Id: jwhmcs.php 198 2010-04-23 20:38:51Z Steven $
 * @since			1.5.0
 */

add_hook("ClientAreaPage",20,"hook_ClientAreaPage","");
add_hook("ClientDetailsValidation",20,"hook_ClientDetailsValidate","");
add_hook("ClientChangePassword",20,"hook_ClientChangePW","");
add_hook("ClientAdd",20,"hook_ClientAdd","");
add_hook("ClientEdit",20,"hook_ClientEdit","");
add_hook("ClientLogin",20,"hook_ClientLogin","");
add_hook("ClientLogout",20,"hook_ClientLogout","");
add_hook("ContactAdd", 20, "hook_ContactHandler", "");
add_hook("ContactEdit",20,"hook_ContactHandler","");

/* ------------------------------------------------------------ *\
 * Function:	hook_ClientAreaPage
 * Purpose:		request Joomla template and render for WHMCS
 * As of:		version 1.5.0 (August 2009)
 * 
 * Significant Revisions:
 *  2.1.0 (Apr 2010)
 *  	+ Added setting considerations for enable/disable
 *  2.0.3 (Mar 2010)
 *  	* Language Support moved to separate hook file
 *  2.0.2 (Mar 2010)
 *  	+ Joomfish support
 *  1.5.3 (Oct 2009)
 * 		+ Ability to replace titlebar text
\* ------------------------------------------------------------ */
function hook_ClientAreaPage() {
	global $smarty, $errormessage;
	$settings			= getJwhmcsSettings();
	
	if (!$settings['Enable']) return;
	if (!$settings['RenderEnable']) return;
	
	$title				= $smarty->_tpl_vars['pagetitle'].($smarty->_tpl_vars['kbarticle']['title']?' - '.$smarty->_tpl_vars['kbarticle']['title']:'');
	
	$data['filename']	= $smarty->_tpl_vars['filename'];
	$data['systemurl']	= $smarty->_tpl_vars['systemurl'];
	$data['loggedin']	= (isset($smarty->_tpl_vars['loggedin'])?true:false);
	$data['pagetitle']	= $smarty->_tpl_vars['companyname'].' - '.$title;
	$data['title']		= $title;
	
//	v 1.5.3 - send the userid to the jwhmcs if logged in for pulling user info
	if ($data['loggedin']) {
		$clientid = (isset($smarty->_tpl_vars['clientsdetails']['userid']) ? $smarty->_tpl_vars['clientsdetails']['userid'] : $_COOKIE['WHMCSUID'] );
		$data['clientid']	= $clientid;
	}
	
	// Set the action data variable if it exists
	if ($_REQUEST['action']) $data['action'] = $_REQUEST['action'];
	
	// v 1.5.3 - returned format changed to xml
	$info = goCurl('parse', $data, false);
	$var = xmlParse($info['data']);
	
	if ( $var['return'] == 'success' )
	{
		foreach ($var as $key => $value) {
			if ($key == 'return') continue;
			$body[$key] = base64_decode($value);
		}
		
		$smarty->assign('htmlheader', $body['htmlheader']);
		$smarty->assign('htmlfooter', $body['htmlfooter']);
	}
	else {
		if ($settings['Debug']) {
			$smarty->assign( 'htmlfooter', "<pre>".print_r($info['info'],1)."</pre>");
		}
	}
	
}


/* ------------------------------------------------------------ *\
 * Function:	hook_ClientAdd
 * Purpose:		send new client info to jwhmcs root for Joomla insert
 * As of:		version 1.5.0 (August 2009)
 * 
 * Significant Revisions:
 *  2.1.0 (Apr 2010)
 *  	+ Added setting considerations for enable/disable
 *  1.5.2 (Oct 2009)
 * 		+ Added check test for $vars as array (WHMCS v4.1 change)
\* ------------------------------------------------------------ */
function hook_ClientAdd($vars) {
	global $errormessage;
	$settings = getJwhmcsSettings();
	
	if (!$settings['Enable']) return;		// The Integrator is disabled
	if (!$settings['UserEnable']) return;	// User Integration is disabled
	if ($_POST['jwhmcs']) return;			// This account is already setup in Joomla
	
	// Prior to WHMCS v4.1, $vars contained only clientid
	// J!WHMCS v 1.5.2 - add test for vars as array
	if (is_array($vars)) {
		$usevar				= $vars;
		$data['clientid']	= $vars['userid'];
		$data['password2']	= $vars['password'];
	}
	else {
		$usevar				= $_POST;
		$data['clientid']	= $vars;
	}
	
	foreach ($usevar as $k => $v) {
		$data[$k] = $v;
	}
	
	$info = goCurl('clienthandler', $data, false);
	$var = xmlParse($info['data']);
	
	if ($var['result']=='error')
		$errormessage .= '<strong>There was a problem adding your information to the main site.  Please contact the administrator.</strong>';
}


/* ------------------------------------------------------------ *\
 * Function:	hook_ClientEdit
 * Purpose:		send client update info to jwhmcs root for Joomla
 * As of:		version 1.5.0 (August 2009)
 * 
 * Significant Revisions:
 *  2.1.0 (Apr 2010)
 *  	+ Added setting considerations for enable/disable
 *  1.5.2 (Oct 2009)
 * 		+ Added check test for $vars as array (WHMCS v4.1 change)
\* ------------------------------------------------------------ */
function hook_ClientEdit($vars) {
	global $errormessage;
	$settings = getJwhmcsSettings();
	
	if (!$settings['Enable']) return;		// The Integrator is disabled
	if (!$settings['UserEnable']) return;	// User Integration is disabled
	if ($_POST['jwhmcs']) return;			// Account already updated in Joomla
	
	// Prior to WHMCS v4.1, $vars contained only clientid
	// J!WHMCS v 1.5.2 - add test for vars as array
	$data['clientid']	= (is_array($vars)?$vars['userid']:$vars);
	$data['name']		= $_POST['firstname'].' '.$_POST['lastname'];
	$data['firstname']	= $_POST['firstname'];
	$data['lastname']	= $_POST['lastname'];
	$data['email']		= $_POST['email'];
	$data['company']	= $_POST['companyname'];
	$data['address1']	= $_POST['address1'];
	$data['address2']	= $_POST['address2'];
	$data['city']		= $_POST['city'];
	$data['state']		= $_POST['state'];
	$data['postcode']	= $_POST['postcode'];
	$data['country']	= $_POST['country'];
	$data['phonenumber']= $_POST['phonenumber'];
	
	$info = goCurl('clienthandler', $data);
	$var = xmlParse($info['data']);
	
	if ($var['result']=='error')
		$errormessage .= '<strong>There was a problem saving your information.  Please contact the administrator.</strong>';
}


/* ------------------------------------------------------------ *\
 * Function:	hook_ContactHandler
 * Purpose:		Add or Update a subaccount for Joomla
 * As of:		version 2.1.0 (April 2010)
\* ------------------------------------------------------------ */
function hook_ContactHandler($vars)
{
	global $errormessage;
	$settings = getJwhmcsSettings();
	
	if (!$settings['Enable'])
		return; // If J!WHMCS Integrator is disabled dont run
	if (!$settings['UserEnable'])
		return; // If J!WHMCS Integrator User Integration is disabled dont run
	
	if ( isset($vars['subaccount'] ) ) {
		if (!$vars['subaccount'])
			return; // If this contact isn't a subaccount dont run
	}
	
	// Available fields from $vars:
	//		userid, contactid, firstname, lastname, companyname, email, address1, address2, city, state, postcode, country, phonenumber, subaccount, permissions, generalemails, productemails, domainemails, invoiceemails, supportemails
	foreach ($vars as $k => $v) {
		$data[$k] = $v;
	}
	
	if ($_POST['password']) $data['password'] = $_POST['password'];
	if ($_POST['password2']) $data['password2'] = $_POST['password2'];
	
	$info	= goCurl('subaccounthandler', $data);
	$var	= xmlParse($info['data']);
	
	if ($var['result']=='error')
		$errormessage .= '<strong>There was a problem saving your information.</strong>';
}


/* ------------------------------------------------------------ *\
 * Function:	hook_ClientLogin
 * Purpose:		logic for handling client login
 * As of:		version 1.5.0 (August 2009)
\* ------------------------------------------------------------ */
function hook_ClientLogin($vars)
{
//	$settings = getJwhmcsSettings();
//	
//	if (!$settings['Enable']) return;
//	if (!$settings['UserEnable']) return;
//	
//	$tail	= ( isset($GLOBALS['jwhmcs']) ? '&jwhmcs=2' : '' );
//	$url = rtrim($GLOBALS['PHP_SELF'], 'dologin.php')."jwhmcs.php?task=ulogin&jwhmcsadmin={$settings['Secret']}$tail";
//	//echo $url.'<pre>'.print_r($GLOBALS,1).'</pre>'; die();
//	header( 'Location: '.$url);
}


/* ------------------------------------------------------------ *\
 * Function:	hook_ClientLogout
 * Purpose:		handle client logout information
 * As of:		version 1.5.0 (August 2009)
 * 
 * Significant Revisions:
 *  2.1.0 (Apr 2010)
 *  	+ Added setting considerations for enable/disable
\* ------------------------------------------------------------ */
function hook_ClientLogout($vars)
{
	global $smarty;
	$settings = getJwhmcsSettings();
	
	if (!$settings['Enable']) return;
	if (!$settings['UserEnable']) return;
	
	$tail	= ( isset($_REQUEST['jwhmcsout']) ? '&jwhmcsout=2' : '' );
	
	$url = $smarty->_tpl_vars['systemurl']."jwhmcs.php?task=ulogout&jwhmcsadmin={$settings['Secret']}$tail";
	header( 'Location: '.$url);
} 


/* ------------------------------------------------------------ *\
 * Function:	hook_ClientDetailsValidate
 * Purpose:		validate client credentials for duplicate in Joomla
 * As of:		version 1.5.0 (August 2009)
 * 
 * Significant Revisions:
 *  2.1.0 (Apr 2010)
 *  	+ Added setting considerations for enable/disable
\* ------------------------------------------------------------ */
function hook_ClientDetailsValidate($vars)
{
	global $errormessage;
	$settings = getJwhmcsSettings();
	
	if (!$settings['Enable']) return;
	if (!$settings['UserEnable']) return;
	echo '<pre>'.print_r($vars,1).print_r($_POST,1).'</pre>'; die();
	if (!$_POST['jwhmcs']):
		// Create data array to send to curl
		$data['email']		= $_POST['email'];
		$data['clientid']	= $_COOKIE['WHMCSUID'];
		
		// Test to see if the cookie was set, if not then don't curl
		if ($data['clientid']):
			// Call cURL function with validate task and data
			$info	= goCurl('validate', $data);
			$var	= xmlParse($info['data']);
			
			// If return cURL data is false (invalid)
			if ($var['result'] == 'error' )
				$errormessage .= '<strong>You cannot change your email address to '.$_POST['email'].'.  '.$var['message'];
		endif;
	endif;
}


/* ------------------------------------------------------------ *\
 * Function:	hook_ClientChangePW
 * Purpose:		changes the password in Joomla when changed in WHMCS
 * As of:		version 1.5.0 (August 2009)
 * 
 * Significant Revisions:
 *  2.1.0 (Apr 2010)
 *  	+ Added setting considerations for enable/disable
 *  1.5.3 (Oct 2009)
 * 		+ Added check test for $vars as array (WHMCS v4.1 change)
\* ------------------------------------------------------------ */
function hook_ClientChangePW($vars)
{
	global $errormessage;
	$settings = getJwhmcsSettings();
	
	if (!$settings['Enable']) return;
	if (!$settings['UserEnable']) return;
	
	if (!$_POST['jwhmcs']):
		// Prior to WHMCS v4.1, $vars contained only clientid
		// v 1.5.3 - add test for vars as array
		$data['clientid']	= (is_array($vars)?$vars['userid']:$vars);
		$data['password']	= $_POST['newpw'];
		
		// Call cURL function with validate task and data
		$info = goCurl('chpassword', $data);
		$var = xmlParse($info['data']);
		
		if ( $var['result'] == 'error' )
			$errormessage .= '<strong>There was an error changing your password</strong>';
	endif;
}


/* ------------------------------------------------------------ *\
 * Function:	goCurl
 * Purpose:		curl function to call jwhmcs root file
 * As of:		version 1.5.1 (September 2009)
 * 
 * Significant Revisions:
 *  2.1.0 (Apr 2010)
 *  	+ Added setting considerations for retrieving root data
\* ------------------------------------------------------------ */
function goCurl($task, array $post, $parse = true) {
	global $smarty;
	$settings = getJwhmcsSettings();
	
	$post['jwhmcs'] = 1;
	$post['joomadmin'] = $settings['Secret'];
	
	// Set the postfields items for the cURL call
	foreach ($post as $key => $value) $data .= '&'.urlencode($key).'='.urlencode($value);
	
	$host = ((isset($smarty->_tpl_vars['systemurl']) || (! is_null($smarty->_tpl_vars['systemurl']))) ? $smarty->_tpl_vars['systemurl'] : $GLOBALS['CONFIG']['SystemURL'] );
	
	$url = buildCurl(trim($host,'/').'/jwhmcs.php?task='.$task.$data);
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_TIMEOUT, 100);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_NOPROGRESS, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postfields);
	ob_start();
		$data = curl_exec($ch);
		$info = curl_getinfo($ch);
	ob_end_clean();
	curl_close($ch);
	
	if ($parse) {
		$data = explode(';', $data);
		foreach ($data as $temp):
			$temp = explode('=', $temp);
			if (count($temp)>1):
				$key = $temp[0];
				unset($temp[0]);
				$value = implode('=', $temp);
				$var[$key] = $value;
			endif;
			unset ($key, $value, $temp);
		endforeach;
	} else {
		$var['data'] = $data;
	}
	$var['info'] = $info;
	return $var;
}


/* ------------------------------------------------------------ *\
 * Function:	buildCurl
 * Purpose:		test system url for SSL and return rebuilt url for curl
 * As of:		version 1.5.1 (September 2009)
 * 
 * Significant Revisions:
 *  2.0.3 (Apr 2010)
 *  	* Language check pulls from smarty variable now
 *  2.0.2 (Mar 2010)
 * 		* Modified query building to use common function
\* ------------------------------------------------------------ */
function buildCurl($systemurl)
{
	global $smarty;
	
	// Parse URL sent for testing purposes
	$url = parse_url($systemurl);
	parse_str($url['query'], $qry);
	
	// Test to see if SSL is set
	if ($url['scheme']=='https'):
		$url['scheme']='http';
		$qry['usessl'] = 1;
	endif;
	
	if (isset($smarty->_tpl_vars['language'])) {
		$qry['lang'] = $smarty->_tpl_vars['langarray'][$smarty->_tpl_vars['language']];
	}
	
	$url['query'] = buildQuery($qry);
	return queryToString($url);
}


/* ------------------------------------------------------------ *\
 * Function:	hook_version
 * Purpose:		return hook version to internal or echo back
 * As of:		version 1.5.3 (October 2009)
\* ------------------------------------------------------------ */
function hook_version($internal = false, $hook = 'HOOK') {
	$ret = constant('JWHMCS'.$hook.'VERS');
	if ($internal)
		return $ret;
	else
		echo $ret;
}


/* ------------------------------------------------------------ *\
 * Function:	xmlParse
 * Purpose:		xml parser for returned data from root file
 * As of:		version 1.5.2 (October 2009)
\* ------------------------------------------------------------ */
function xmlParse($data)
{
	$xml = xml_parser_create();
	xml_parse_into_struct($xml, $data, $vals, $index);
	xml_parser_free($xml);
	 
	foreach ($vals as $p):
		if ($p['type']=='complete')
		{
			// Error trapping for error_reporting(-1)
			if(isset($p['value']))
				$items[strtolower($p['tag'])] = $p['value'];
		}
	endforeach;
	
	return $items;
}


/* ------------------------------------------------------------ *\
 * Function:	queryToString
 * Purpose:		Build a url string from an array of uri variables
 * As of:		version 2.0.2 (March 2010)
\* ------------------------------------------------------------ */
function queryToString($uri)
{
	$tmp = '';
	$tmp .= isset($uri['scheme'])  ? (!empty($uri['scheme']) ? $uri['scheme'].'://' : '') : '';
	$tmp .= isset($uri['user'])	? $uri['user'] : '';
	$tmp .= isset($uri['pass'])	? (!empty ($uri['pass']) ? ':' : '') .$uri['pass']. (!empty ($uri['user']) ? '@' : '') : '';
	$tmp .= isset($uri['host'])	? $uri['host'] : '';
	$tmp .= isset($uri['port'])	? (!empty ($uri['port']) ? ':' : '').$uri['port'] : '';
	$tmp .= isset($uri['path'])	? $uri['path'] : '';
	$tmp .= isset($uri['query'])	? (!empty ($uri['query']) ? '?'.$uri['query'] : '') : '';
	$tmp .= isset($uri['fragment'])? (!empty ($uri['fragment']) ? '#'.$uri['fragment'] : '') : '';
	return $tmp;
}


/* ------------------------------------------------------------ *\
 * Function:	buildQuery
 * Purpose:		Build a query string from an array of parameters
 * As of:		version 2.0.2 (March 2010)
\* ------------------------------------------------------------ */
function buildQuery ($params = null)
{
	if (is_null($params)) return false;
	$out = array();
	foreach ( $params as $k => $v ) $out[] = $k."=".urlencode($v);
	return implode("&",$out);
}


function getJwhmcsSettings()
{
	$query = "SELECT * FROM mod_jwhmcs_config";
	$result	= mysql_query($query);
	
	$ret = array();
	while ($row = mysql_fetch_assoc($result)) {
		$ret[$row['key']] = $row['value'];
	}
	return $ret;
}
?>