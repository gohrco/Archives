<?php
/**
 * J!WHMCS Integrator
 * Custom API Function - jwhmcsgetcontact
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009-2010 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: jwhmcs.php 184 2010-03-18 23:21:35Z Steven $
 * @since		2.1.0
 */

/*
 * Usage:
 * 		action:		jwhmcsgetcontact
 * 		get:		"all" | "email=value" | "id=value"
 * 		set:		"id=x;var1=setting1;var2=setting2" * id is required
 * 
 * Returns:
 * 		result:		success | error
 * 		message:	result description | retrieved variables
 */
include_once('../../dbconnect.php');

$todo	= ( $set ? 'set' : 'get' );
$qset	= "";

switch ($todo):
case 'get':
	if ($get != 'all') {
		$gets	= explode("=", $get);
		switch($gets[0]):
		case 'email':
			$qset = "email = ";
			$gets[1] = "'{$gets[1]}'";
			break;
		case 'id':
			$qset = "id = ";
			break;
		endswitch;
		$qset	= " WHERE $qset{$gets[1]}";
	}
	
	$query	= "SELECT * FROM `tblcontacts`".$qset;
	$result	= mysql_query($query);
	
	$rows['result'] = 'error';
	while ($row = mysql_fetch_assoc($result)) {
		$rows['result'] = 'success';
		foreach ($row as $key => $value) {
			$rows[$key] = $value;
		}
	}
	
	break;
case 'set':
	$sets	= explode(";", $set);
	foreach ($sets as $s) {
		$tmp = explode("=", $s);
		$rows[$tmp[0]] = $tmp[1];
	}
	if (!isset($rows['id'])) {
		unset($rows);
		$rows['result'] = 'error';
		$rows['message'] = 'No ID specified';
		break;
	}
	foreach ($rows as $key => $value) {
		$keys[] = "`$key`";
		$vals[] = "'$value'";
		$kval[]	= "`$key` = '$value'";
	}
	unset($rows);
	
	$query = "INSERT INTO `tblcontacts` (".implode(",",$keys).") VALUES (".implode(",",$vals).") ON DUPLICATE KEY UPDATE ".implode(",",$kval);
	$result= mysql_query($query);
	
	$rows['result'] = 'success';
	$rows['message'] = 'Configuration updated!';
	
	if (!$result) {
		$rows['result'] = 'error';
		$rows['message'] = 'Error updating database';
	}
	
	break;
endswitch;

$xml  = '<?xml version="1.0" encoding="utf-8"?><whmcsapi version="4.2.1">';
if (is_array($rows)) {
	foreach ($rows as $key => $value) {
		$xml .= "<{$key}>{$value}</{$key}>";
	}
}
else {
	$xml .= "<result>error</result>";
	$xml .= "<message>Nothing to do</message>";
}
$xml .= "</whmcsapi>";

echo $xml;

?>