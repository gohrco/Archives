<?php
/**
 * J!WHMCS Integrator
 * Custom API Function - jwhmcsconfig
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009-2010 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: jwhmcs.php 184 2010-03-18 23:21:35Z Steven $
 * @since		2.1.0
 */

/*
 * Usage:
 * 		action:		jwhmcsconfig
 * 		get:		"all" | "var1,var2,var3"
 * 		set:		"var1=setting1;var2=setting2"
 * 		init:		"all"
 * 
 * Returns:
 * 		result:		success | error
 * 		message:	result description | retrieved variables
 */
include_once('../../dbconnect.php');

$todo	= ( $init ? 'init' : ( $set ? 'set' : 'get' ) );
$qset	= "";

switch ($todo):
case 'init':
	$query =	"CREATE TABLE IF NOT EXISTS `mod_jwhmcs_config` (
					`key` VARCHAR(100) NOT NULL,
					`value` VARCHAR(255) NOT NULL,
					PRIMARY KEY (`key`)
				) ENGINE = MYISAM";
	$result1 = mysql_query($query);
	
	if ($result1) {
		$query = "INSERT INTO `mod_jwhmcs_config` (`key`, `value`) VALUES
					('Debug', '1'),
					('Enable', '1'),
					('UserEnable', '1'),
					('RenderEnable', '1'),
					('Secret', 'JwhmcsInt')";
		$result2 = mysql_query($query);
	}
	
	$rows['result'] = 'error';
	if ($result1) {
		if ($result2) {
			$rows['result'] = 'success';
			$rows['message'] = ($init == 2 ? 'INSTALL_WHMCS_DB_INIT_SUCCESS' : 'Database initialized' );
		}
		else {
			$rows['message'] = ( $init == 2 ? 'INSTALL_WHMCS_DB_INIT_FAIL_01' : 'Database table already created; data not reinitialized' );
		}
	}
	else {
		$rows['message'] = ( $init == 2 ? 'INSTALL_WHMCS_DB_INIT_FAIL_02' : 'Database table create failed!' );
	}
	 
	break;
case 'get':
	if ($get != 'all') {
		$gets	= explode(",", $get);
		$qset	= " WHERE `key` IN ('".implode("', '", $gets)."')";
	}
	
	$query	= "SELECT * FROM mod_jwhmcs_config".$qset;
	$result	= mysql_query($query);
	
	$rows['result'] = 'error';
	while ($row = mysql_fetch_assoc($result)) {
		$rows['result'] = 'success';
		$rows[$row['key']] = $row['value'];
	}
	
	break;
case 'set':
	$sets	= explode(";", $set);
	foreach ($sets as $s) {
		$tmp = explode("=", $s);
		$rows[$tmp[0]] = $tmp[1];
	}
	
	foreach ($rows as $key => $value) {
		$qry[] = 'INSERT INTO `mod_jwhmcs_config` (`key`, `value`) VALUES ("'.$key.'", "'.$value.'") ON DUPLICATE KEY UPDATE `value`="'.$value.'"';
	}
	unset($rows);
	
	$rows['result'] = 'success';
	$rows['message'] = 'Configuration updated!';
	foreach ($qry as $q ) {
		$result = mysql_query($q);
		if (!$result) { $rows['result'] = 'error'; $rows['message'] = 'Error updating database!'; }
	}
	
	break;
endswitch;

$xml  = '<?xml version="1.0" encoding="utf-8"?><whmcsapi version="4.2.1">';
if (is_array($rows)) {
	foreach ($rows as $key => $value) {
		$xml .= "<{$key}>{$value}</{$key}>";
	}
}
else {
	$xml .= "<result>error</result>";
	$xml .= "<message>Nothing to do</message>";
}
$xml .= "</whmcsapi>";

echo $xml;

?>