<?php
/**
 * J!WHMCS Integrator
 * Custom API Function - jwhmcsgetsettings
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009-2010 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: jwhmcs.php 184 2010-03-18 23:21:35Z Steven $
 * @since		2.1.0
 */

include_once('../../dbconnect.php');

$todo	= ( $set ? 'set' : ( $addip ? 'addip' : 'get' ) );

switch ($todo):
case 'get':
	if ($get != 'all') {
		$gets	= explode(",", $get);
	}
	else {
		$gets = array( "Version", "Template", "SystemURL", "SystemSSLURL", "DefaultCountry", "RequiredPWStrength");
	}
	
	$query	= "SELECT * FROM tblconfiguration WHERE `setting` IN ('".implode("', '", $gets)."')";
	$result	= mysql_query($query);
	
	$rows['result'] = 'error';
	
	while ($row = mysql_fetch_assoc($result)) {
		$rows['result'] = 'success';
		$rows[$row['setting']] = $row['value'];
	}
	
	break;
case 'set':
	$sets	= explode(";", $set);
	foreach ($sets as $s) {
		$tmp = explode("=", $s);
		$rows[$tmp[0]] = $tmp[1];
	}
	
	foreach ($rows as $key => $value) {
		$qry[] = "UPDATE tblconfiguration SET value = '$value' WHERE setting='$key'";
	}
	unset($rows);
	
	$rows['result'] = 'success';
	$rows['message'] = 'Configuration updated!';
	foreach ($qry as $q ) {
		$result = mysql_query($q);
		if (!$result) { $rows['result'] = 'error'; $rows['message'] = 'Error updating database!'; }
	}
	
	break;
case 'addip':
	$query	= "SELECT `value` FROM tblconfiguration WHERE `setting` = 'APIAllowedIPs')";
	$result	= mysql_query($query);
	$field	= mysql_result($result, 0);
	$ips	= explode("\n", $field);
	
	if (!in_array($addip, $ips)) {
		array_unshift($ips, $addip);
		$ip_list = trim(implode("\n", $ips));
		
		$query = 'UPDATE tblconfiguration SET `value` = "'.$ip_list.'" WHERE `setting` = "APIAllowedIPs"';
		if (mysql_query($query)) {
			$rows['result'] = 'success';
			$rows['message'] = 'IP Added to list';
		}
		else {
			$rows['result'] = 'error';
			$rows['message'] = 'A problem occurred updating the database';
		}
		
	}
	else {
		$rows['result'] = 'success';
		$rows['message'] = 'IP was already on Allowed list';
	}
	break;
endswitch;

$xml  = '<?xml version="1.0" encoding="utf-8"?><whmcsapi version="4.2.1">';
if (is_array($rows)) {
	foreach ($rows as $key => $value) {
		$xml .= "<{$key}>{$value}</{$key}>";
	}
}
else {
	$xml .= "<result>error</result>";
	$xml .= "<message>Nothing to do</message>";
}
$xml .= "</whmcsapi>";

echo $xml;

?>