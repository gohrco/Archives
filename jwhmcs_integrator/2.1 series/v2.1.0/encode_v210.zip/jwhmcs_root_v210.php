<?php
/**
 * WHMCS root file for J!WHMCS Integrator
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009-2010 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: jwhmcs.php 198 2010-04-23 20:38:51Z Steven $
 * @since		1.5.0
 */
define( 'JWHMCSINI', 'true' );
define(	'JPATH_BASE', dirname(__FILE__) );
define( 'DS', DIRECTORY_SEPARATOR );
define( 'JWHMCSVERS', '2.1.0' );
define( '_JEXEC', true );
define( 'JWHMCS_URL', "http://client.gohigheris.com/" );
define( 'JWHMCS_UNIQUEID', "JwhmcsInt" );
define( 'JWHMCS_BRANDREMOVAL', "Branding" );
define( 'JWHMCS_KAYAKOENABLE', "Kayako" );
define( 'JWHMCS_BRANDDATE', "2010-05-15" );

require_once (JPATH_BASE.DS.'jconfig.php');
if (! defined(JCONFIG_FILE) ) define( 'JCONFIG_FILE', 'configuration.php' );

if (! defined(JWHMCS_BASE_PATH) )	define( 'JWHMCS_BASE_PATH', JPATH_CONFIG.DS.'administrator'.DS.'components'.DS.'com_jwhmcs'.DS );
if (! defined(JWHMCS_CLASS_PATH) )	define( 'JWHMCS_CLASS_PATH', JWHMCS_BASE_PATH.'classes'.DS );
if (! defined(JWHMCS_FILE_PATH) )	define( 'JWHMCS_FILE_PATH', JWHMCS_BASE_PATH.'files');

require_once (JWHMCS_CLASS_PATH.'class.database.php');
require_once (JWHMCS_CLASS_PATH.'class.params.php');
require_once (JWHMCS_CLASS_PATH.'class.vars.php');
require_once (JWHMCS_CLASS_PATH.'class.curl.php');
require_once (JWHMCS_CLASS_PATH.'class.parse.php');
require_once (JWHMCS_CLASS_PATH.'class.cache.php');
require_once (JWHMCS_CLASS_PATH.'class.uri.php');

function add_hook() {}

if (!is_readable('./includes/hooks/jwhmcs.php')) {
	$hookver = false;
} else {
	ob_start();
		include('./includes/hooks/jwhmcs.php');
	ob_end_clean();
	if (function_exists('hook_version'))
		$hookver = hook_version(true, 'HOOK');
	else
		$hookver = '1.5.3 beta 5 or earlier';
}
define( 'JWHMCSHOOKVERS', $hookver );

if (!is_readable('./includes/hooks/jwhmcs-lang.php')) {
	$hookver = false;
} else {
	ob_start();
		include('./includes/hooks/jwhmcs-lang.php');
	ob_end_clean();
	
	$hookver = hook_version(true, 'LANG');
}
define( 'JWHMCSLANGVERS', $hookver );

// Pull Joomla Configuration - but see if it is readable first
if (!is_readable(JPATH_CONFIG.DS.JCONFIG_FILE)) {
	die('Your configuration file is not readable at '.JPATH_CONFIG.DS.JCONFIG_FILE.'!  JWHMCS cannot proceed');
}
require_once (JPATH_CONFIG.DS.JCONFIG_FILE);
$jconfig	= new JConfig();

$db		= & JwhmcsDBO::getInstance($jconfig);	// Joomla DB
$params	= & JwhmcsParams::getInstance();
$vars	= & JwhmcsVars::getInstance();
//$parse	= & JwhmcsParse::getInstance();
//$cache	= & JwhmcsCache::getInstance();
$jcurl	= & JwhmcsCurl::getInstance();
$xml	= & JwhmcsXml::getInstance();

/* ------------------------------------------------------------ *\
 * Begin JWHMCS Class
\* ------------------------------------------------------------ */

$jwhmcs = new JWHMCS();

// If the task doesn't exist then run sendback
if (! (method_exists($jwhmcs, $vars->get( 'task' ) ) ) ) $vars->set( 'task', 'sendback' );

// Set the task variable and run appropriate task
if (!($task = $vars->get( 'task' ))) $task = 'sendback';

// Call task
$jwhmcs->$task( );

class JWHMCS
{
	
	private $license	= null;
	private $valid		= false;
	private $branded	= true;
	private $kayako		= false;
	
	/* ------------------------------------------------------------ *\
	 * Function:	JWHMCS
	 * Purpose:		This is the constructor task
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 *  	* Modified parameters to reflect database change
	 * 	2.0.0 (Nov 2009)
	 * 		+ Database, variable and parameters moved to class
	\* ------------------------------------------------------------ */
	function JWHMCS()
	{
		global $params, $vars;
		
		// Set defaults that aren't already set
		$this->_setDefaults();
		
		// Get the license
		$this->license = $this->_checkLicense();
		
		// Check the license to allow program to run (true)
		if ($this->license["status"] == 'Active')
		{
			$this->valid = true;
		}
		else
		{
			$this->valid = false;
		}
		
		// Figure out license type and activation
		// If license is owned, then expired should be allowed to run
		$license = explode('-', trim($params->get( 'LicenseKey' )));
		if ( $license[0] == 'Owned' )
		{
			if ( $this->license['status'] == 'Expired' )
			{
				$this->valid = true;
			}
		}
		
		// If we are checking the status of the install, then we will allow access but only to that task
		if ($vars->get( 'task' ) == 'installCheck')
			$this->valid = true;
		
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	checkinstall
	 * Purpose:		Check the installation
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 *  	+ Added call to custom API to retrieve live settings
	 *  	- Dropped _getWVersion method
	 *  2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	 *  1.5.3 (Oct 2009)
	 *  	+ Added debug variable to prevent display to outside
	 *  	+ Removed requirement for WHMCS Client ID
	 *  	+ Added check for no data response without url param
	 *  	+ Moved curl function to common _cUrl fnxn
	 * 	1.5.2 (Oct 2009)
	 * 		+ Added check for xml response from v.4.1 WHMCS
	\* ------------------------------------------------------------ */
	public function checkinstall()
	{
		global $db, $params, $jcurl, $vars;
		
		// Initialize Value Array
		$val	= array();
		
		// Get WHMCS Settings
		$jcurl->setAction('jwhmcsgetsettings', array("get" => "version,systemurl,systemsslurl,defaultcountry,template,charset,nomd5,requiredpwstrength" ));
		$whmcs	= $jcurl->loadResult();
		
		// Check for connection to API Interface
		$apicxn	= $this->_checkApiConnection($whmcs);
		
		if ($whmcs['version'] != $params->get( 'WhmcsVersion' )) $params->set( 'WhmcsVersion', $whmcs['version'], true);
		
		// Create name reference
		$user	= $params->get( 'JuserStore' );
		$udisp	= ($user==1?'First Last':($user==2?'Last, First':($user==3?'First Last (Company)':'Last, First (Company)')));
		
		// Build Value array
		$val['rootvers']		= JWHMCSVERS;
		$val['hookvers']		= JWHMCSHOOKVERS;
		$val['langvers']		= JWHMCSLANGVERS;
		$val['jwhmcsvers']		= $params->get( 'Version' );
		$val['whmcsvers']		= $whmcs['version'];
		$val['whmcsdir']		= dirname(__FILE__);
		$val['configdir']		= JPATH_CONFIG;
		$val['configexists']	= ( file_exists(JPATH_CONFIG.DS.JCONFIG_FILE) ? true : false );
		$val['configreadable']	= ( is_readable(JPATH_CONFIG.DS.JCONFIG_FILE) ? true : false );
		$val['curlinstalled']	= ( function_exists('curl_init') ? true : false );
		$val['apiaccess']		= $apicxn['message'];
		$val['apiurl']			= $jcurl->get( CURLOPT_URL );
		$val['apiusername']		= $params->get( 'ApiUsername' );
		$val['license']			= ( $this->license['status'] == 'Invalid' ? ( isset($this->license['message']) ? $this->license['message'] : $this->license['status'] ) : $this->license['status'] );
		$val['licensevalid']	= $this->valid;
		$val['jurl']			= $params->get( 'JoomlaUrl' );
		$val['jrootimgurl']		= $params->get( 'RenderImageurl' );
		$val['jssl']			= ( $params->get( 'RenderSslenable' ) ? true : false );
		$val['jin']				= $params->get( 'RedirLoginurl' );
		$val['jinssl']			= ( $params->get( 'RedirLoginssl' ) ? true : false );
		$val['jout']			= $params->get( 'RedirLogouturl' );
		$val['joutssl']			= ( $params->get( 'RedirLogoutssl' ) ? true : false );
		$val['whmcsurl']		= $params->get( 'ApiUrl' );
		$val['whmcsssl']		= ( $params->get( 'RedirGatewayssl' ) ? true : false );
		$val['jquery']			= ( $params->get( 'RenderJqueryenable' ) ? true : false );
		$val['jstorename']		= $udisp;
		$val['pagein']			= $params->get( 'JoomlaUrl' ).'/index.php?option=com_jwhmcs&view=default&Itemid='.$params->get( 'RenderLoggedin' );
		$val['pageout']			= $params->get( 'JoomlaUrl' ).'/index.php?option=com_jwhmcs&view=default&Itemid='.$params->get( 'RenderLoggedout' );
		$val['overridecache']	= ( $params->get( 'RenderOverridecache' ) ? true : false );
		$val['clearcache']		= ( $params->get( 'RenderClearcache' ) ? true : false );
		$val['whmcs_systemurl']		= $whmcs['systemurl'];
		$val['whmcs_systemsslurl']	= $whmcs['systemsslurl'];
		$val['whmcs_defaultcountry']= $whmcs['defaultcountry'];
		$val['whmcs_template']		= $whmcs['template'];
		$val['whmcs_charset']		= $whmcs['charset'];
		$val['whmcs_nomd5']			= ( $whmcs['nomd5'] ? 'Disabled' : 'Enabled' );
		$val['whmcs_reqpwstrength']	= $whmcs['requiredpwstrength'];
		
		// Set definitions for above items
		$this->_setDefinitions();
		
		// Test to see what type of response to send (debug is plain text pairs)
		$type	= $this->_getType();
		if ($type == 'pair') $type = 'checkinstall';
		
		// Response package
		$return = $this->_buildResponse($val, $type);
		if ($vars->get('return')) {
			$vars->set( 'return', false );
			return $return;
		}
		$this->_sendResponse($return, $type);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	validate
	 * Purpose:		Validate WHMCS against Joomla to ensure no dupes
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	 * 		+ Set common responses and use XML
	 *  1.5.3 (Nov 2009)
	 *  	+ Moved curl function to common curl class
	 *  	+ Cleaned up messy function - wasn't working properly
	 * 	1.5.1c (Oct 2009)
	 * 		+ Fixed validation for groups - now groups cannot be changed
	\* ------------------------------------------------------------ */
	public function validate()
	{
		global $db, $params, $jcurl, $vars;
		
		if (!$this->valid)
			return;
		
		// 1a:  First pull the xref in the database for the clientid
		$query	= 'SELECT x.xref_a, x.xref_type, x.xref_b FROM #__jwhmcs_xref as x WHERE xref_b="'.$vars->get( 'clientid' ).'"';
		$db->setQuery($query);
		$xref	= $db->loadAssoc();
		
		// 1b:  Is there an xref?  Check if it's a group (4) if so, deny change
		if ($xref) {
			if ( $xref['xref_type'] == '4' ) {
				echo 'valid=false;reason=<br />You cannot change the details for your group account.  Please contact us for assistance.';
				return;
			} else {
				$juserid = $xref['xref_a'];
			}
		} else {
			$juserid = 0;
		}
		
		$query	= 'SELECT u.email, u.id FROM `#__users` u WHERE id <> '.$juserid;
		$db->setQuery($query);
		$users	= $db->loadAssocList();
		
		$result = true;
		foreach ($users as $user)
		{
			if (trim($vars->get( 'email' )) == trim($user['email']))
			{
				$result = false;
				break;
			}
		}
		
		if ($result)
		{
			$return['result']	= 'success';
		}
		else
		{
			$return['result']	= 'error';
			$return['message']	= 'A user already has that email address';
		}
		
		// Respond and close
		$this->_close($return);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	chpassword
	 * Purpose:		Change password in Joomla from WHMCS
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 * 	2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	 *  	+ Set common responses and use XML
	\* ------------------------------------------------------------ */
	public function chpassword()
	{
		global $db, $params, $vars;
		
		if (!$this->valid)
			return;
		
		$salt = $this->_genRandomPassword(32);
		$salted = $vars->get( 'password' ).$salt;
		$password = md5($salted).':'.$salt;
		
		$query	= 'UPDATE `#__users` SET `password` = "'.$password.'" WHERE id = (SELECT `xref`.`xref_a` FROM `#__jwhmcs_xref` as xref WHERE xref_b = '.$vars->get( 'clientid' ).')';
		$db->setQuery($query);
		$result	= $db->query();
		
		if ($result)
		{
			if($db->getAffectedRows()<1)
			{
				$return['result']	=	'error';
				$return['message']	=	'No user found in main site to update password for.  Please contact your administrator.';
			}
			else
			{
				$return['result']	=	'success';
			}
		}
		else
		{
			$return['result']	=	'error';
			$return['message']	=	'There was a problem writing to the database.  Please contact your administrator.';
		}
		
		// Respond and close
		$this->_close($return);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	addclient
	 * Purpose:		Add new client from WHMCS into Joomla
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	 *  	+ Set common responses and use XML
	 * 	1.5.1 (Sept 2009)
	 * 		+ URL for cUrl call changed to be strictly http (no ssl)
	\* ------------------------------------------------------------ *
	public function addclient($fromjwhmcs = 1)
	{
		global $db, $params, $jcurl, $vars;
		
		if (!$this->valid)
			return;
		
		// Retrieve name to use
		$name	= $this->_buildName();
		
		// Set token and value fields for insertion
		$token	= md5($_COOKIE['PHPSESSID'].date("s"));
		$val[]	= 'name='.$name;
		$val[]	= 'username='.$vars->get( 'username' );
		$val[]	= 'email='.$vars->get( 'email' );
		$val[]	= 'password='.$vars->get( 'password' );
		$val[]	= 'password2='.$vars->get( 'password2' );
		$val[]	= 'task=register_save';
		$val[]	= 'id=0';
		$val[]	= 'gid=0';
		$value	= implode("\n", $val);
		
		$query	= 'INSERT INTO `#__jwhmcs_sess` (`token`, `value`) VALUES ("'.$token.'", "'.$value.'");';
		$db->setQuery($query);
		$result	= $db->query();
		
		$url	= 'http://'.$params->get( 'jwhmcsjurl' ).'/index2.php?option=com_jwhmcs&task=register_save&fromjwhmcs='.$fromjwhmcs.'&token='.$token;
		
		$jcurl->setCall();
		$jcurl->set(CURLOPT_URL, $url);
		$jcurl->set(CURLOPT_HEADER, false);
		$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
		$jcurl->set(CURLOPT_RETURNTRANSFER, true);
		
		$curl = $jcurl->loadResults();
		
		if ($curl['result']=='success')
		{
			// Store this new id w/ the user id in the xref db
			$query	= 'INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) VALUES ('.$curl['userid'].', 1, '.$vars->get( 'clientid' ).')';
			$db->setQuery($query);
			$result	= $db->query();
			
			$query	= 'INSERT INTO `#__jwhmcs_user` (`fname`, `lname`, `cname`, `email`, `address1`, `address2`, `city`, `state`, `postal`, `country`, `phonenumber` ) VALUES ("'.$vars->get( 'firstname' ).'", "'.$vars->get( 'lastname' ).'", "'.$vars->get( 'company' ).'", "'.$vars->get( 'email' ).'",  "'.$vars->get( 'address1' ).'", "'.$vars->get( 'address2' ).'", "'.$vars->get( 'city' ).'", "'.$vars->get( 'state' ).'", "'.$vars->get( 'postcode' ).'", "'.$vars->get( 'country' ).'", "'.$vars->get( 'phonenumber' ).'")';
			$db->setQuery($query);
			$result	= $db->query();
			
			$return['result']		= 'success';
			$return['joomlaid']	= $curl['userid'];
		}
		else
		{
			$return['result']		= 'error';
			$return['message']		= $curl['error'];
		}
		
		// Respond and close
		$this->_close($return);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	updateclient
	 * Purpose:		Update information from WHMCS to Joomla
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 * 	2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	 *  	+ Set common responses and use XML
	\* ------------------------------------------------------------ */
	public function updateclient()
	{
		global $db, $params, $vars;
		
		if (!$this->valid)
			return;
		
		$name	= $this->_buildName();
		
		$query	= 'UPDATE `#__users` SET `name` = "'.$db->getEscaped($vars->get( 'name' )).'", `email` = "'.$db->getEscaped($vars->get( 'email' )).'" WHERE `id` = (SELECT `xref`.`xref_a` FROM `#__jwhmcs_xref` as xref WHERE xref.xref_b='.$vars->get( 'clientid' ).' AND xref.xref_type IN (\'1\', \'2\', \'3\'))';
		$db->setQuery($query);
		$result	= $db->query();
		
		$query	= 'UPDATE `#__jwhmcs_user` SET `fname` = "'.$vars->get( 'firstname' ).'", `lname` = "'.$vars->get( 'lastname' ).'", `cname` = "'.$vars->get( 'company' ).'", `email` = "'.$vars->get( 'email' ).'", `address1` = "'.$vars->get( 'address1' ).'", `address2` = "'.$vars->get( 'address2' ).'", `city` = "'.$vars->get( 'city' ).'", `state` = "'.$vars->get( 'state' ).'", `postal` = "'.$vars->get( 'postcode' ).'", `country` = "'.$vars->get( 'country' ).'", `phonenumber` = "'.$vars->get( 'phonenumber' ).'" WHERE `#__jwhmcs_user`.`id` = '.$vars->get( 'clientid' );
		$db->setQuery($query);
		$result	= $db->query();
		
		if ($result)
		{
			if($db->getAffectedRows()<1)
			{
				$return['result']	= 'failure';
				$return['reason']	= 'No user found in main site to update information for.  Please contact your administrator.';
			}
			else
			{
				$return['result']	= 'success';
			}
		} else {
			$return['result']	= 'error';
			$return['reason']	= 'There was a problem writing to the database.  Please contact your administrator.';
		}
		
		// Respond and close
		$this->_close($return);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	clienthandler
	 * Purpose:		Add / Update client information from WHMCS to Joomla
	 * As of:		version 2.1.0 (April 2010)
	 * 
	 * Significant Revisions
	 * 	2.1.0 (Apr 2010)
	 * 		* Merged addclient and updateclient functionality into one
	\* ------------------------------------------------------------ */
	public function clienthandler( $fromjwhmcs = 1)
	{
		global $db, $params, $jcurl, $vars;
		$uri	= & JwhmcsUri::getInstance( $params->get( 'JoomlaUrl' ) );
		
		if (!$this->valid)
			return;
		
		// Retrieve name to use
		$name	= $this->_buildName();
		
		// Find out if this id exists in user table already
		$query	= "SELECT u.* FROM #__users AS u WHERE u.id = ( SELECT xref.xref_a FROM #__jwhmcs_xref AS xref WHERE xref.xref_b = %1\$s AND xref.xref_type IN ('1', '2', '3') )";
		$query	= sprintf($query, $vars->get( 'clientid' ));
		$db->setQuery($query);
		$user	= $db->loadAssoc();
		
		// If nothing found, we need to add the client account
		if (!$user) {
			// Available fields from $vars:
			//	  clientid, firstname, lastname, companyname, email, address1, address2, city, state, postcode, country, phonenumber, password, password2, userid, jwhmcs, joomadmin, usessl, loggedin, filename, action, goto 
			
			// Set token and value fields for insertion
			$token	= md5($_COOKIE['PHPSESSID'].date("s"));
			$val[]	= 'name='.$name['name'];
			$val[]	= 'username='.$name['username'];
			$val[]	= 'email='.$vars->get( 'email' );
			$val[]	= 'password='.$vars->get( 'password' );
			$val[]	= 'password2='.$vars->get( 'password2' );
			$val[]	= 'task=register_save';
			$val[]	= 'id=0';
			$val[]	= 'gid=0';
			$value	= implode("\n", $val);
			
			$query	= 'INSERT INTO `#__jwhmcs_sess` (`token`, `value`) VALUES ("'.$token.'", "'.$value.'");';
			$db->setQuery($query);
			$result	= $db->query();
			
			$uri->setPath( $uri->getPath().'/index2.php');
			$uri->setVar( 'option', 	'com_jwhmcs' );
			$uri->setVar( 'task',		'register_save' );
			$uri->setVar( 'token',		$token );
			$uri->setVar( 'fromjwhmcs', $fromjwhmcs );
			
			$url	= $uri->toString(); 	//$params->get( 'JoomlaUrl' ).'/index2.php?option=com_jwhmcs&task=register_save&fromjwhmcs='.$fromjwhmcs.'&token='.$token;
			
			$jcurl->setCall();
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->set(CURLOPT_HEADER, false);
			$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
			$jcurl->set(CURLOPT_RETURNTRANSFER, true);
			
			$return = $jcurl->loadResults();
			
			// Adding client account failed
			if ($return['result']!='success')
			{
				$ret['result']	= 'error';
				$ret['message']	= "Failed to create matching account in Joomla";
				
				// Respond and close
				$this->_close($ret);
				return;
			}
			// Adding client account succeeded, so insert new id into xref table
			else {
				$query	= 'INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) VALUES ('.$return['userid'].', 1, '.$vars->get( 'clientid' ).')';
				$db->setQuery($query);
				$result	= $db->query();
				
				$user['id'] = $return['userid'];
			}
		}
		// User already exists, so we should update name and email
		else {
			$query	= "UPDATE #__users SET `name` = '%1\$s', `email` = '%2\$s' WHERE `id` = '%3\$s'";
			$query	= sprintf($query, $name['name'], $db->getEscaped($vars->get( 'email' )), $user['id'] );
			$db->setQuery($query);
			$db->query();
		}
		
		// We have added any missing client and updated the Joomla user now we can insert / update JWHMCS user appropriately
		$query	= "INSERT INTO #__jwhmcs_user (id, fname, lname, cname, email, address1, address2, city, state, postal, country, phonenumber) VALUES ('%1\$s', '%2\$s', '%3\$s', '%4\$s', '%5\$s', '%6\$s', '%7\$s', '%8\$s', '%9\$s', '%10\$s', '%11\$s', '%12\$s') ON DUPLICATE KEY UPDATE fname = '%2\$s', lname = '%3\$s', cname = '%4\$s', email = '%5\$s', address1 = '%6\$s', address2 = '%7\$s', city = '%8\$s', state = '%9\%s', postal = '%10\$s', country = '%11\$s', phonenumber = '%12\$s'";
		$query	= sprintf($query, $user['id'], $vars->get( 'firstname' ), $vars->get( 'lastname' ), $vars->get( 'company' ), $vars->get( 'email' ), $vars->get( 'address1' ), $vars->get( 'address2' ), $vars->get( 'city' ), $vars->get( 'state' ), $vars->get( 'postcode' ), $vars->get( 'country' ), $vars->get( 'phonenumber' ));
		$db->setQuery($query);
		$result = $db->query();
		
		if ($result)
		{
			if($db->getAffectedRows()<1)
			{
				$ret['result']	= 'error';
				$ret['reason']	= 'No user found in main site to update information for.  Please contact your administrator.';
			}
			else
			{
				$ret['result']	= 'success';
			}
		} else {
			$ret['result']	= 'error';
			$ret['reason']	= 'There was a problem writing to the database.  Please contact your administrator.';
		}
		
		// Respond and close
		$this->_close($ret);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	subaccounthandler
	 * Purpose:		Add / Update subaccount information from WHMCS to Joomla
	 * As of:		version 2.1.0 (April 2010)
	\* ------------------------------------------------------------ */
	public function subaccounthandler( $fromjwhmcs = 1 )
	{
		global $db, $jcurl, $params, $vars;
		$uri	= & JwhmcsUri::getInstance( $params->get( 'JoomlaUrl' ) );
		
		if (!$this->valid)
			return;
		
		// Retrieve name to use
		$name	= $this->_buildName();
		
		// Find out if this id exists in user table already
		$query	= "SELECT u.* FROM #__users AS u WHERE u.id = ( SELECT xref.xref_a FROM #__jwhmcs_xref AS xref WHERE xref.xref_b = %1\$s AND xref.xref_type IN ('5', '6', '7') )";
		$query	= sprintf($query, $vars->get( 'contactid' ));
		$db->setQuery($query);
		$user	= $db->loadAssoc();
		
		// If nothing found, we need to add the sub account
		if (!$user) {
			// Available fields from $vars:
			// 	  userid, firstname, lastname, companyname, email, address1, address2, city, state, postcode, country, phonenumber, subaccount, password, permissions, generalemails, productemails, domainemails, invoiceemails, supportemails 
			
			// Set token and value fields for insertion
			$token	= md5($_COOKIE['PHPSESSID'].date("s"));
			$val[]	= 'name='.$name['name'];
			$val[]	= 'username='.$name['username'];
			$val[]	= 'email='.$vars->get( 'email' );
			$val[]	= 'password='.$vars->get( 'password' );
			$val[]	= 'password2='.$vars->get( 'password2' );
			$val[]	= 'task=register_save';
			$val[]	= 'id=0';
			$val[]	= 'gid=0';
			$value	= implode("\n", $val);
			
			$query	= 'INSERT INTO `#__jwhmcs_sess` (`token`, `value`) VALUES ("'.$token.'", "'.$value.'");';
			$db->setQuery($query);
			$result	= $db->query();
			
			$uri->setPath( $uri->getPath().'/index2.php');
			$uri->setVar( 'option', 	'com_jwhmcs' );
			$uri->setVar( 'task',		'register_save' );
			$uri->setVar( 'token',		$token );
			$uri->setVar( 'fromjwhmcs', $fromjwhmcs );
			
			$url	= $uri->toString();		// $params->get( 'JoomlaUrl' ).'/index2.php?option=com_jwhmcs&task=register_save&fromjwhmcs='.$fromjwhmcs.'&token='.$token;
			
			$jcurl->setCall();
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->set(CURLOPT_HEADER, false);
			$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
			$jcurl->set(CURLOPT_RETURNTRANSFER, true);
			
			$return = $jcurl->loadResults();
			
			// Adding subaccount failed
			if ($return['result']!='success')
			{
				$ret['result']	= 'error';
				$ret['message']	= "Failed to create matching account in Joomla";
				
				// Respond and close
				$this->_close($ret);
				return;
			}
			// Adding subaccount succeeded, so insert new id into xref table
			else {
				$query	= 'INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) VALUES ('.$return['userid'].', 5, '.$vars->get( 'contactid' ).')';
				$db->setQuery($query);
				$result	= $db->query();
				
				$user['id'] = $return['userid'];
			}
		}
		// User already exists, so we should update name and email
		else {
			$query	= "UPDATE #__users SET `name` = '%1\$s', `email` = '%2\$s' WHERE `id` = '%3\$s'";
			$query	= sprintf($query, $name['name'], $db->getEscaped($vars->get( 'email' )), $user['id'] );
			$db->setQuery($query);
			$db->query();
		}
		
		// We have added any missing contact and updated the Joomla user now we can insert / update JWHMCS usersub appropriately
		$query	= "INSERT INTO #__jwhmcs_usersub (id, fname, lname, cname, email, address1, address2, city, state, postal, country, phonenumber) VALUES ('%1\$s', '%2\$s', '%3\$s', '%4\$s', '%5\$s', '%6\$s', '%7\$s', '%8\$s', '%9\$s', '%10\$s', '%11\$s', '%12\$s') ON DUPLICATE KEY UPDATE fname = '%2\$s', lname = '%3\$s', cname = '%4\$s', email = '%5\$s', address1 = '%6\$s', address2 = '%7\$s', city = '%8\$s', state = '%9\%s', postal = '%10\$s', country = '%11\$s', phonenumber = '%12\$s'";
		$query	= sprintf($query, $user['id'], $vars->get( 'firstname' ), $vars->get( 'lastname' ), $vars->get( 'company' ), $vars->get( 'email' ), $vars->get( 'address1' ), $vars->get( 'address2' ), $vars->get( 'city' ), $vars->get( 'state' ), $vars->get( 'postcode' ), $vars->get( 'country' ), $vars->get( 'phonenumber' ));
		$db->setQuery($query);
		$result = $db->query();
		
		if ($result)
		{
			if($db->getAffectedRows()<1)
			{
				$ret['result']	= 'failure';
				$ret['reason']	= 'No user found in main site to update information for.  Please contact your administrator.';
			}
			else
			{
				$ret['result']	= 'success';
			}
		} else {
			$ret['result']	= 'error';
			$ret['reason']	= 'There was a problem writing to the database.  Please contact your administrator.';
		}
		
		// Respond and close
		$this->_close($ret);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	login
	 * Purpose:		Handle client login from Joomla to WHMCS
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.0.2 (Mar 2010)
	 *  	+ Sets return cookie instead of redirecting to correct page
	 * 	2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	 *  	+ Post variables to form for login (securely if SSL enabled)
	\* ------------------------------------------------------------ */
	public function login()
	{
		global $db, $params, $vars;
		$uri	= & JwhmcsUri::getInstance( $params->get( 'ApiUrl' ) );
		
		if (!$this->valid)
			$this->sendback();
		
		// Load uid and upw from database with matching token
		$query	= 'SELECT `value` FROM `#__jwhmcs_sess` WHERE token="'.$vars->get( 'a' ).'"';
		$db->setQuery($query);
		$result	= $db->loadAssoc();
		
		// Parse value field
		$tmp = preg_split('/\n/', $result['value']);
		foreach ($tmp as $t):
			$var = explode('=', $t);
			$k = $var[0];
			unset($var[0]);
			$param[$k] = implode("=", $var);
			unset($k, $var);
		endforeach;
		
		// Delete row from database with matching token to prevent hacks
		$query	= 'DELETE FROM `#__jwhmcs_sess` WHERE token="'.$vars->get( 'a' ).'" LIMIT 1';
		$db->setQuery($query);
		$delete	= $db->query();
		
		$uri->setScheme( 'http'.($params->get( 'RedirGatewayssl' ) ? 's' : '' ) );
		$uri->setPath( $uri->getPath() .'/dologin.php' );
		$uri->setVar( 'goto', 'jwhmcs' );
		
//		$url = 'http'.($params->get( 'jwhmcsssl' )?'s':'').'://'.$params->get( 'jwhmcsurl' ).'/dologin.php?goto='.($param['goto']?$param['goto']:'jwhmcs');
		$url = $uri->toString();	// 'http'.($params->get( 'RedirGatewayssl' )?'s':'').'://'.$params->get( 'ApiUrl' ).'/dologin.php?goto=jwhmcs';
		$fields['username']		= $param['email'];
		$fields['password']		= $param['password'];
		$fields['return']		= $param['return'];
		$fields['rememberme']	= true;
		
		unset($_COOKIE['return']);
		setcookie('return', $param['return'], time()+30);
		
		$this->_formRedirect($url, $fields);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	ulogin
	 * Purpose:		Global handler for logging in procedure
	 * As of:		version 2.1.0 (April 2010)
	\* ------------------------------------------------------------ */
	public function ulogin()
	{
		global $db, $params, $vars;
		
		// Check to see if we are valid - if not send back
		if (!$this->valid)
			$this->sendback();
		
		// Retrieve variable set through login procedure
		$curtask = $vars->get( 'jwhmcs' );
		
		/* ------------------------------------------------------------ *\
		 *  No cookie set - this is the first time through
		\* ------------------------------------------------------------ */
		if (!$curtask)
		{
			// Test to see if this is coming from Kayako
			if ( ( $vars->get( 'loginemail', 'post' ) ) )
			{
				$val[]	= 'passwd='.$vars->get( 'loginpassword', 'request' );
				$val[]	= 'remember='.$vars->get( 'rememberme', 'request' );
				
				// Return variable to be set
				$val[]	= 'return='.base64_encode( $params->get( 'KayakoUrl' ) );
			}
			// Test to see if this is coming from WHMCS
			elseif (! $vars->get( 'password' )  )
			{
				$val[]	= 'passwd='.$vars->get( 'password', 'request' );
				$val[]	= 'remember='.$vars->get( 'rememberme', 'request' );
				
				// Return variable to be set
				$uri	= & JwhmcsUri::getInstance( $params->get( 'ApiUrl' ) );
				$uri->setScheme( 'http' . ( $vars->get( 'usessl' ) ? 's' : '' ) );
				$uri->setPath( $uri->getPath() . '/' . ( $vars->get( 'goto' ) ? $vars->get( 'goto' ) : 'index' ) . '.php' );
				
				// Build return variable
				$getVars = $vars->getMethod( 'get' );
				
				foreach ($getVars as $k => $v) {
					if (in_array($k, array('task', 'usessl', 'loggedin', 'filename', 'action', 'goto'))) continue;
					$uri->setVar( $k, $v ); //$qryitem[] = $k.'='.$v;
				}
				
				$val[]	= 'whmcs=1';
				$val[]	= 'return='.base64_encode( $uri->toString() );
			}
			// Assume this is coming from JWHMCS Integrator or Joomla somehow
			else
			{
				// If this is coming from Joomla, then a return variable is set, we need to complete the return variable though
				if ($return = $vars->get( 'return' ) ) {
					$return	= base64_decode($return);
					$returi = & JwhmcsUri::getInstance($return);
					$joomla = & JwhmcsUri::getInstance($params->get( 'JoomlaUrl' ));
					$returi->setHost($joomla->getHost());
					$returi->setScheme($joomla->getScheme());
					$return = base64_encode($returi->toString());
					$val[]	= 'return='.$return;
				}
				
				$val[]	= 'remember=' . $vars->get( 'remember' );
				$val[]	= 'passwd='.$vars->get( 'password', 'request' );
			}
			// Set the step for the cookie
//			setcookie( "jwhmcs[step]", "1", time() + 45 );
			
			$post	= $vars->getMethod('request');
			
			foreach ($post as $k => $v) $val[]	= $k.'='.$v;
			$val[]	= 'jwhmcstask=ulogin';
			
			$token	= md5($vars->get( 'PHPSESSID' ).date("s"));
			$value	= implode("\n", $val);
			
			$query	= 'INSERT INTO `#__jwhmcs_sess` (`token`, `value`) VALUES ("'.$token.'", "'.$value.'")';
			$db->setQuery($query);
			$result	= $db->query();
			
			$uri	= & JwhmcsUri::getInstance( $params->get( 'JoomlaUrl' ) );
			$uri->setPath( $uri->getPath() . '/index.php' );
			$uri->setVar( 'option',		'com_jwhmcs' );
			$uri->setVar( 'task',		'whmcs_login' );
			$uri->setVar( 'jwhmcs', 2 );
			//$uri->setVar( 'jwhmcstask',	'ulogin' );
			$uri->setVar( 'token',		$token );
			$url = $uri->toString();
			$this->_redirect($url);
		}
		
		/* ------------------------------------------------------------ *\
		 *  Cookie step is 1 so expect the login to Joomla was a success
		\* ------------------------------------------------------------ */
		elseif ($curtask == 1)
		{
			// Load uid and upw from database with matching token
			$query	= 'SELECT `value` FROM `#__jwhmcs_sess` WHERE token="'.$vars->get( 'a' ).'"';
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			// Parse value field
			$tmp = preg_split('/\n/', $result['value']);
			foreach ($tmp as $t)
			{
				$var = explode('=', $t);
				$k = $var[0];
				unset($var[0]);
				$param[$k] = implode("=", $var);
				unset($k, $var);
			}
			
			// Delete row from database with matching token to prevent hacks
			$query	= 'DELETE FROM `#__jwhmcs_sess` WHERE token="'.$vars->get( 'a' ).'" LIMIT 1';
			$db->setQuery($query);
			$delete	= $db->query();
			
			$uri	= & JwhmcsUri::getInstance( $params->get( 'ApiUrl' ) );
			$uri->setScheme( 'http'.($params->get( 'RedirGatewayssl' ) ? 's' : '' ) );
			$uri->setPath( $uri->getPath() .'/dologin.php' );
			$uri->setVar( 'goto',		'jwhmcs'	);
			$uri->setVar( 'jwhmcs',		'1'			);
			
			$url = $uri->toString();	// 'http'.($params->get( 'RedirGatewayssl' )?'s':'').'://'.$params->get( 'ApiUrl' ).'/dologin.php?goto=jwhmcs';
			$fields['username']		= $param['email'];
			$fields['password']		= $param['password'];
			$fields['rememberme']	= $param['remember'];
			$fields['return']		= $param['return'];
			
			// Set the return in a cookie for later retrieval
			setcookie( "jwk_return", $fields['return'], time() + 15 );
			
			if ( $params->get( 'KayakoEnable' ) )
			{
				setcookie( "jwk[loginemail]",		$param['email'],	time() + 30 );
				setcookie( "jwk[loginpassword]",	$param['password'],	time() + 30 );
				setcookie( "jwk[rememberme]",		$param['remember'],	time() + 30 );
				setcookie( "jwk[return]",			$param['return'],	time() + 30 );
			}
			
			$this->_formRedirect($url, $fields, 'whmcs');
		}
		
		/* ------------------------------------------------------------ *\
		 *  Cookie step is 3 or not sent to Kayako, sp wrap up and return
		\* ------------------------------------------------------------ */
		else
		{
			$cookie = $vars->get('jwk', 'cookie');
			
			/* ------------------------------------------------------------ *\
			 *  Cookie step is 2 so expect the login to WHMCS was a success
			\* ------------------------------------------------------------ */
			if ( ( is_array($cookie) ) && ($this->kayako) && ( $params->get( 'KayakoEnable' ) && ($vars->get( 'jwhmcs' ) != 3 ) ) )
			{
				// We need to test for SSL
				if (( $vars->get( 'HTTPS' ) == 'on' ) && ( $params->get( 'KayakoUsessl' ) != '1' ))
				{
					// Redirect back here without ssl
					$uri = & JwhmcsUri::getInstance($params->get( 'ApiUrl' ));
					$uri->setScheme( 'http' );
					$uri->setPath( $uri->getPath( 'ApiUrl' ) . '/jwhmcs.php' );
					$uri->setVar( 'task', 'ulogin' );
					$uri->setVar( 'jwhmcs', '2' );
					$this->_redirect($uri->toString());
					return;
				}
				
				$cookie = $vars->get( 'jwk', 'cookie' );
				
				$fields['loginemail']		= $cookie['loginemail'];
				$fields['loginpassword']	= $cookie['loginpassword'];
				$fields['rememberme']		= $cookie['rememberme'];
				
				$url = & JwhmcsUri::getInstance( $params->get( 'KayakoUrl' ));
				$url->setVar( 'Submit', 'Log in' );
				$url->setVar( '_m', 'core' );
				$url->setVar( '_a', 'login' );
				$url->setVar( 'querystring', '' );
				
				$this->_formRedirect( $url->toString(), $fields, 'kayako');
			}
			
			else {
				
				$url = $vars->get( 'jwk_return', 'cookie' );
				
				if (! $url ) {
					if ($vars->get( 'PHPSESSID' ) != '') {
						$url = $params->get( 'RedirLoginurl' );
					} else {
						$url = $params->get( 'RedirLogouturl' );
					}
				}
				else {
					setcookie( "jwk_return", "", time() - 3600 );
					$url = base64_decode($url);
				}
				
				$this->_redirect($url);
			}
		}
	}
	
	
	public function ulogout()
	{
		global $db, $params, $vars;
		
		// Check to see if we are valid - if not send back
		if (!$this->valid)
			$this->sendback();
		
		// Retrieve current task
		$curtask = $vars->get( 'jwhmcsout' );
		
		/* ------------------------------------------------------------ *\
		 *  No cookie set - this is the first time through
		\* ------------------------------------------------------------ */
		if (! $curtask )
		{
			// Create URL for redirecting to Joomla for logging out
			$uri	= & JwhmcsUri::getInstance( $params->get( 'JoomlaUrl' ) );
			$uri->setPath( $uri->getPath() . '/index.php' );
			$uri->setVar( 'option',		'com_user' );
			$uri->setVar( 'task',		'logout' );
			$uri->setVar( 'jwhmcsout',	'1' );
			
			// Redirect to Joomla for logout
			$url = $uri->toString();
		}
		
		/* ------------------------------------------------------------ *\
		 *  Cookie step is 1 so expect the logout of Joomla was a success
		\* ------------------------------------------------------------ */
		elseif ($curtask == 1)
		{
			// Create URL for redirecting to WHMCS for loggin out
			$uri = & JwhmcsUri::getInstance($params->get( 'ApiUrl' ));
			$uri->setPath( $uri->getPath() . '/logout.php' );
			$uri->setVar( 'goto',		'jwhmcs'	);
			$uri->setVar( 'jwhmcsout',	'2'			);
			$url = $uri->toString();
		}
		
		/* ------------------------------------------------------------ *\
		 *  Cookie step is 2 so expect the logout of WHMCS was a success
		\* ------------------------------------------------------------ */
		elseif ( ( $curtask == 2 ) && ($this->kayako) && ( $params->get( 'KayakoEnable' ) ) )
		{
			// Create URL for redirecting to WHMCS for loggin out
			$uri = & JwhmcsUri::getInstance($params->get( 'KayakoUrl' ));
			$uri->setPath( $uri->getPath() . '/index.php' );
			$uri->setVar( '_m', 'core' );
			$uri->setVar( '_a', 'logout' );
			$url = $uri->toString();
		}
		
		/* ------------------------------------------------------------ *\
		 *  Cookie step is 3 or not sent to Kayako, so wrap up and return
		\* ------------------------------------------------------------ */
		else
		{
			$url = $params->get( 'RedirLogouturl' );
		}
		
		$this->_redirect($url);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	jlogin
	 * Purpose:		Handle client login from WHMCS into Joomla
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 * 	2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	\* ------------------------------------------------------------ */
	public function jlogin()
	{
		global $db, $params, $vars;
		
		if (!$this->valid)
			$this->sendBack();
		
		$val[]	= 'passwd='.$vars->get( 'password' );
		
		$post	= $vars->getMethod('request');
		
		foreach ($post as $k => $v)
		{
			$val[]	= $k.'='.$v;
		}
		
		// Check for return variable being set
		if (!isset($post['return'])) {
			
			$uri	= & JwhmcsUri::getInstance( $params->get( 'ApiUrl' ) );
			$uri->setScheme( 'http' . ( $vars->get( 'usessl' ) ? 's' : '' ) );
			$uri->setPath( $uri->getPath() . '/' . ( $vars->get( 'goto' ) ? $vars->get( 'goto' ) : 'index' ) . '.php' );
			
			// Build return variable
			$getVars = $vars->getMethod( 'get' );
			
			foreach ($getVars as $k => $v) {
				if (in_array($k, array('task', 'usessl', 'loggedin', 'filename', 'action', 'goto'))) continue;
				$uri->setVar( $k, $v ); //$qryitem[] = $k.'='.$v;
			}
			//if (is_array($qryitem)) $qry = "?".implode("&",$qryitem);
			//else $qry = '';
			
			//$qrystr = "http".($vars->get('usessl') ? "s":"")."://".$params->get('ApiUrl')."/".($vars->get('goto') ? $vars->get('goto').".php" : "index.php" ).$qry;
			$url	= $uri->toString();
			$val[]	= 'whmcs=1';
			$val[]	= 'return='.base64_encode($url);
		}
		
		// 1c:  Use the session cookie as the token and implode the value array
		$token	= md5($vars->get( 'PHPSESSID' ).date("s"));
		$value	= implode("\n", $val);
		
		// 2:  Write to DB
		$query	= 'INSERT INTO `#__jwhmcs_sess` (`token`, `value`) VALUES ("'.$token.'", "'.$value.'")';
		$db->setQuery($query);
		$result	= $db->query();
		
		// 3:  Redirect to Joomla
		$uri	= & JwhmcsUri::getInstance( $params->get( 'JoomlaUrl' ) );
		$uri->setPath( $uri->getPath() . '/index.php' );
		$uri->setVar( 'option',		'com_jwhmcs' );
		$uri->setVar( 'task',		'whmcs_login' );
		$uri->setVar( 'token',		$token );
		$url = $uri->toString(); //$params->get( 'JoomlaUrl' ).'/index.php?option=com_jwhmcs&task=whmcs_login&token='.$token;
		$this->_redirect($url);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	logout
	 * Purpose:		handle client logout
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 * 	2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	\* ------------------------------------------------------------ */
	public function logout()
	{
		global $params, $vars;
		
		if (!$this->valid)
			$this->sendBack();
		
		$url = $params->get( 'RedirLogouturl' );
		$this->_redirect($url);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	logoutJoomla
	 * Purpose:		handle client logout from WHMCS to Joomla
	 * As of:		version 2.0.0 (January 2010)
	\* ------------------------------------------------------------ */
	public function logoutJoomla()
	{
		global $params, $vars;
		
		if (!$this->valid) $this->sendBack();
		
		$uri	= & JwhmcsUri::getInstance( $params->get( 'JoomlaUrl' ) );
		$uri->setPath( $uri->getPath() . '/index.php' );
		$uri->setVar( 'option',		'com_user' );
		$uri->setVar( 'task',		'logout' );
		
		// Redirect to Joomla for logout
		$url = $uri->toString(); //$params->get( 'JoomlaUrl' ).'/index.php?option=com_user&task=logout';
		$this->_redirect($url);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	sendback
	 * Purpose:		Redirect to Joomla if no task sent
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.0.2 (Mar 2010)
	 *  	+ Added check for return variable in cookie
	 * 	2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	\* ------------------------------------------------------------ */
	public function sendBack()
	{
		global $params, $vars;
		
		$curtask = $vars->get( 'jwhmcs' );
		$outtask = $vars->get( 'jwhmcsout' );
		
		if ($curtask) {
			$this->ulogin();
			return;
		}
		
		if ($outtask) {
			$this->ulogout();
			return;
		}
		
		if ($return = $vars->get( 'return' )) {
			$url = base64_decode($return);
		} elseif ($vars->get( 'PHPSESSID' ) != '') {
			
			$cookie = $vars->get( 'jwk', 'cookie' );
			
			if ($cookie)
			{
				$vars->set('jwhmcs', '2');
				$this->ulogin();
				return;
			}
			$url = $params->get( 'RedirLoginurl' );
				
		} else {
			$url = $params->get( 'RedirLogouturl' );
		}
		
		$this->_redirect($url);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	syncReload
	 * Purpose:		retrieve users from WHMCS direct from database 
	 * As of:		version 2.0.0 (January 2010)
	\* ------------------------------------------------------------ */
	public function syncReload()
	{
		global $params, $vars;
		
		if (!$this->valid) $this->sendBack();
		if (!$vars->get( 'joomadmin' )) $this->sendBack();
		
		$wconfig = $this->_getWhmcsDB();
		$wb		 = & JwhmcsDBO::getInstance($wconfig);	// WHMCS DB
		
		$query	= "SELECT `id`, '1' as `type`, `firstname`, `lastname`, `companyname`, `email`, `address1`, `address2`, `city`, `state`, `postcode`, `country`, `phonenumber` FROM `#__clients`";
		$wb->setQuery($query);
		$result1	= $wb->loadAssocList();
		
		$query	= "SELECT `id`, '5' as `type`, `firstname`, `lastname`, `companyname`, `email`, `address1`, `address2`, `city`, `state`, `postcode`, `country`, `phonenumber` FROM #__contacts WHERE `subaccount`='1'";
		$wb->setQuery($query);
		$result2	= $wb->loadAssocList();
		
		if ($result1) foreach ($result1 as $row) $return[] = $row;
		if ($result2) foreach ($result2 as $row) $return[] = $row;
		
		$this->_close($return);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	parse
	 * Purpose:		Called to render template from Joomla
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	 *  	- Functionality moved to parse class
	 *  	+ Common responses set
	 *  1.5.3 b5 (Oct 2009)
	 *  	+ Check for usessl and loggedin to create them if not set
	 *  1.5.3 b3 (Oct 2009)
	 *  	+ Created option array for cUrl to use
	 *  	+ Ability to hide WHMCS content if site offline
	 * 	1.5.1 (Sept 2009)
	 * 		+ Rooturl parameter (for clients with J! installed in subdirectories)
	\* ------------------------------------------------------------ */
	public function parse($page = 'default')
	{
		global $db, $params, $vars, $jcurl, $cache;
		$parse = JwhmcsParse::getInstance($page);
		$cache	= & JwhmcsCache::getInstance();
		
		if (!$this->valid) {
			$ret['return'] = 'success';
			$ret['htmlheader']	= base64_encode('<div style="width: 200px; margin: 0px auto; text-align: center; ">Licensing Error</div>');
			$ret['htmlfooter']	= base64_encode('<div style="width: 200px; margin: 0px auth; text-align: center; ">Please contact Go Higher for more information</div>');
			
			// Test to see what type of response to send (debug is plain text pairs)
			$type	= ($params->get( 'Debug') ? 'pair' : 'xml' );
			$return = $this->_buildResponse($ret, $type);
			
			if ($vars->get('return'))
			{
				$vars->set( 'return', false );
				return $return;
			}
			$this->_sendResponse($return, $type);
			return;
		}
		
		// Check to see if the cache is to be used
		if ($cache->useCache())
		{
			// Check to see if the cache exists for the requested location
			if ($cache->cacheExists())
			{
				// Retrieve the cache
				$cdata	= $cache->getCache();
				
				// Check to see if the cache is invalid
				if (!$cache->validcache)
				{
					if (! $cache->delCache())
					{
						// Error trapping to be done for file deletion failure
					}
					unset($cdata);
				}
				// Use the cache if it is valid
				else
				{
					$ret['return'] = 'success';
					$ret['htmlheader']	= $cdata[1];
					$ret['htmlfooter']	= $cdata[2];
					$vars->set( 'usecache', true);
				}
			}
		}
		
		// If we didn't use the cache or caching is off, then usecache is set to false
		if (! $vars->get( 'usecache' ))
		{
			$jcurl->setCall();
			$jcurl->setParse(false);
			$jcurl->set(CURLOPT_URL, $parse->get( 'url' ));
			
			$site = $jcurl->loadResults();
			$parse->setData($site);
			
			$ret['return'] = 'success';
			$ret['htmlheader']	= $parse->get( 'htmlhdr' );
			
			if ($this->branded) {
				$htmlfooter = base64_decode($parse->get( 'htmlftr' ));
				$htmlfooter = "<p style=\"font-size: x-small; \" align=\"center\"><a href=\"http://gohigheris.com\" target=\"blank\" alt=\"custom joomla whmcs integration joomla integration\">J!WHMCS Integration</a></p>" . $htmlfooter;
				$htmlfooter = base64_encode($htmlfooter);
				$parse->set( 'htmlftr', $htmlfooter );
			}
			
			$ret['htmlfooter']	= $parse->get( 'htmlftr' );
			
			// Test the variables to see if we need to save the cache to the server
			if ($vars->get( 'caching' ))
			{
				$cache->newCache();
				$cache->addCache($ret['htmlheader']);
				$cache->addCache($ret['htmlfooter']);
				$cache->saveCache();
			}
			
		} // End Cache check
		
		// Test to see what type of response to send (debug is plain text pairs)
		$type	= ($params->get( 'Debug') ? 'pair' : 'xml' );
		
		$return = $this->_buildResponse($ret, $type);
		
		if ($vars->get('return'))
		{
			$vars->set( 'return', false );
			return $return;
		}
		
		$this->_sendResponse($return, $type);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	checklicense
	 * Purpose:		quick check of J!WHMCS license 
	 * As of:		version 2.0.0 (January 2010)
	\* ------------------------------------------------------------ */
	public function checklicense()
	{
		global $params, $vars;
		 
		if ($vars->get( 'force' )) {
			$params->set( 'License', '' );
			$this->license = $this->_checkLicense();
			$vars->set( 'joomadmin', $params->get( 'Secret' ));
		}
		elseif (!$vars->get( 'joomadmin' )) {
			return;
		}
		 
		$ret['return']			= $this->license['status'];
		$ret['registeredname']	= ( isset( $this->license['registeredname'] ) ? $this->license['registeredname'] : '' );
		$ret['companyname']		= ( isset( $this->license['companyname'] ) ? $this->license['companyname'] : '' );
		$ret['email']			= ( isset( $this->license['email'] ) ? $this->license['email'] : '' );
		$ret['regdate']			= ( isset( $this->license['regdate'] ) ? $this->license['regdate'] : '' );
		$ret['remotecheck']		= ( isset( $this->license['remotecheck'] ) ? $this->license['remotecheck'] : '' );
		$ret['branded']			= $this->branded;
		$ret['kayako']			= $this->kayako;
		$ret['valid']			= $this->valid;
		
		// Respond and close
		$this->_close($ret);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	installCheck
	 * Purpose:		Checks the health of the WHMCS side of install 
	 * As of:		version 2.1.0 (January 2010)
	\* ------------------------------------------------------------ */
	public function installCheck()
	{
		global $vars, $params, $db;
		
		if (!$this->valid) $this->sendBack();
		if (!$vars->get( 'joomadmin' )) $this->sendBack();
		
		$count = 0;
		if ($vars->get( 'check' ) == 'hook' ) {
			if (JWHMCSHOOKVERS === false) {
				$count = 1;
			} 
			if (JWHMCSLANGVERS === false) {
				$count += 2;
			}
		}
		elseif ($vars->get( 'check' ) == 'api' ) {
			if (!is_readable('./includes/api/jwhmcsconfig.php')) {
				$count = 1;
			}
			if (!is_readable('./includes/api/jwhmcsgetsettings.php')) {
				$count += 2;
			}
		}
		elseif ($vars->get( 'check' ) == 'template' ) {
			if (!is_dir('./templates/jwhmcs-default')) {
				$count = 1;
			}
			if (!is_dir('./templates/jwhmcs-portal')) {
				$count += 2;
			}
		}
		
		if ($count > 0) {
			$result['result'] = 'error';
			$result['message'] = $count;
		}
		else {
			$result['result'] = 'success';
		}
		
		// Respond and close
		$this->_close($result);
	}
	
	
	
	/* ------------------------------------------------------------ *\
	 * SUBFUNCTIONS
	\* ------------------------------------------------------------ */
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getWhmcsDB (private)
	 * Purpose:		Gather database connection variables for WHMCS DB
	 * As of:		version 2.0.0 (December 2009)
	\* ------------------------------------------------------------ */
	private function _getWhmcsDB()
	{
		include('./configuration.php');
		$config['host']		= $db_host;
		$config['user']		= $db_username;
		$config['password']	= $db_password;
		$config['database']	= $db_name;
		$config['prefix']	= 'tbl';
		return $config;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getWhmcsSettings (private)
	 * Purpose:		Pulls the current settings from WHMCS
	 * As of:		version 2.0.0 (December 2009)
	\* ------------------------------------------------------------ */
	private function _getWhmcsSettings()
	{
		global $wb;
		$data	= array();
		
		$query	= 'SELECT `setting`, `value` FROM #__configuration ORDER BY setting';
		$wb->setQuery($query);
		$result	= $wb->loadAssocList();
		
		foreach ($result as $r) {
			$data[strtolower($r['setting'])] = $r['value'];
		}
		
		$query	= 'SELECT `id` FROM #__currencies WHERE `default` = 1';
		$wb->setQuery($query);
		$data['defaultcurrency'] = $wb->loadResult();
		
		return $data; 
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_genRandomPassword (private)
	 * Purpose:		Generate random salt for password
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	private function _genRandomPassword($length = 8) {
		$salt = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		$len = strlen($salt);
		$makepass = '';
		$stat = array(php_uname());
		mt_srand(crc32(microtime() . implode('|', $stat)));
		for ($i = 0; $i < $length; $i ++)
			$makepass .= $salt[mt_rand(0, $len -1)];
		return $makepass;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_buildName (private)
	 * Purpose:		Provide uniform naming for storing in Joomla
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (April 2010)
	 *  	+ Added Username handler
	 *  2.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	\* ------------------------------------------------------------ */
	private function _buildName()
	{
		global $params, $vars;
		
		// No username sent to us to use so we must create one
		if (!$vars->get( 'username' )) {
			switch ($params->get( 'JusernameStore' )): 
			case '1':						// firstname.lastname
				$user = "{$vars->get( 'firstname' )}.{$vars->get( 'lastname' )}";
				break;
			case '2':						// lastname.firstname
				$user = "{$vars->get( 'lastname' )}.{$vars->get( 'firstname' )}";
				break;
			case '3':						// random
				for ($i=0; $i<12; $i++) {
					$d = rand(1,30)%2;
					$user .= ( $d ? chr(rand(65,90)) : chr(rand(48,57)));
				} 
				$user = ucfirst(strtolower($user));
				break;
			case '4':						// f.lastname
				$user = substr($vars->get( 'firstname' ), 0, 1).".{$vars->get( 'lastname' )}";
				break;
			case '5':						// firstname.l
				$user = "{$vars->get( 'firstname' )}.".substr($vars->get( 'lastname' ), 0, 1);
				break;
			case '6':						// firstname
				$user = "{$vars->get( 'firstname' )}";
				break;
			case '7':						// lastname
				$user = "{$vars->get( 'lastname' )}";
				break;
			endswitch;
			$data['username'] = $user;
		}
		
		switch ($params->get( 'JuserStore' )):
		case '3':
			$name = $vars->get( 'company' ) ? ' ('.$vars->get( 'company' ).')' : '' ;
		case '1':
			$name = $vars->get( 'firstname' ).' '.$vars->get( 'lastname' ).$name;
			break;
		case '4':
			$name = ($vars->get( 'company' ) ? ' ('.$vars->get( 'company' ).')':'');
		case '2':
			$name = $vars->get( 'lastname' ).', '.$vars->get( 'firstname' ).$name;
			break;
		endswitch;
		$data['name'] = $name;
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkApiConnection (private)
	 * Purpose:		Retrieve API Connection results 
	 * As of:		version 2.1.0 (December 2009)
	\* ------------------------------------------------------------ */
	private function _checkApiConnection($data = null)
	{
		$ret['result'] = false;
		if ((!$data) || empty($data)) {
			$ret['message'] = "No data was sent back by the API interface";
		}
		elseif( $data['result'] == "error") {
			$ret['message'] = "Error Returned:<br />{$data['message']}";
		} elseif ($data['result'] == "success") {
			$ret['result'] = true;
			$ret['message'] = "Successfully Connected!";
		} else {
			$ret['message'] = "An unknown error occurred";
		}
		return $ret;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_setDefaults (private)
	 * Purpose:		Establish default variables at initialization 
	 * As of:		version 2.0 (December 2009)
	\* ------------------------------------------------------------ */
	private function _setDefaults()
	{
		global $db, $params, $vars, $cache, $jconfig;
		
		$vars->set('offline', $jconfig->offline, 'request');
		$vars->set('caching', $jconfig->caching, 'request');
		$vars->set('cachetime', $jconfig->cachetime, 'request');
		$vars->set('force_ssl', $jconfig->force_ssl, 'request');
		
		if ($vars->get( 'jwhmcs' )) $params->set( 'Debug', 0 );
		if ($params->get( 'overridecache' )) $vars->set( 'caching', 0, 'request' );
		if ($params->get( 'clearcache' )) $cache->clearCache();
		
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_setDefinitions (private)
	 * Purpose:		create definitions for checkinstall display 
	 * As of:		version 2.0 (November 2009)
	\* ------------------------------------------------------------ */
	private function _setDefinitions()
	{
		$val	= array();
		
		// Array configuration:  [0] name, [1], [2] null, true, false for formatting, [3] definition
		$val['rootvers']		= array('Root File Version',		true,	true,	'This is the version of the WHMCS root file of J!WHMCS Integrator.');
		$val['hookvers']		= array('Hook File Version',		true,	false,	'This is the version of the WHMCS hook file of J!WHMCS Integrator.');
		$val['langvers']		= array('Language Hook File Version',		true,	false,	'This is the version of the WHMCS Language hook file of J!WHMCS Integrator.');
		$val['whmcsdir']		= array('WHMCS Directory',		true, false, 'This is the directory the J!WHMCS root file (this one) is located in.');
		$val['configdir']		= array('Joomla Directory',		true,	false,	'This setting is located in the jconfig.php file in the root install directory of WHMCS.  It is used to pull the configuration data from Joomla in order to not have to store that data in the Joomla database or in another file.');
		$val['configexists']	= array('Joomla '.JCONFIG_FILE.' Exists',		true,	false,	'Does the Joomla configuration file actually exist in the location specified in the jconfig.php file?');
		$val['configreadable']	= array('Joomla '.JCONFIG_FILE.' Readable',		true,	false,	'Can the Joomla configuration file actually be read?');
		$val['curlinstalled']	= array('PHP Curl Installed',		true,	false,	'This is a quick double check to be sure the curl library is actually installed with the web servers php');
		$val['whmcsvers']		= array('WHMCS Version Installed',		true,	true,	'This is the version of WHMCS that you have running on your server.');
		$val['jwhmcsvers']		= array('J!WHMCS Integrator Version',	true,	true,	'This is the version of J!WHMCS Integrator that you are running on your server.');
		$val['apiaccess']		= array('WHMCS API Connection',		true,	false,	'The result output of a test to the API interface of WHMCS given the variables you provided.');
		$val['apiurl']			= array('WHMCS API Url',		true,	false,	'The URL used to connect to the WHMCS API interface.');
		$val['apiusername']		= array('WHMCS API Username',		true,	false,	'The username used to connect to the WHMCS API interface.');
		$val['license']			= array('J!WHMCS Integrator License',		true,	false,	'This is the current status of your J!WHMCS Integrator License.');
		$val['licensevalid']	= array('J!WHMCS Integrator Functional',		true,	false,	'If your license is not valid, your J!WHMCS Integrator will not function.');
		$val['jurl']			= array('Joomla Url',		null,	null,	'This is the URL you entered for your Joomla site.');
		$val['jrootimgurl']		= array('Joomla Image Url',		null,	null,	'This is the URL you entered for pointing your images, css and javascript from Joomla to.');
		$val['jssl']			= array('Using SSL on WHMCS',		null,	'You are changing image, css and javascript references in your Joomla template to use SSL for pages that are being rendered for an SSL view.',	'You are not using SSL in WHMCS, or for some reason are not wanting to change the image, css and javascript references to use SSL on those pages.');
		$val['jin']				= array('Login Landing Page',		null, null, 'When your users login, this is the destination URL they will land on if successful.');
		$val['jinssl']			= array('Login Land with SSL',		null, 'When your users login, they are redirected to a page with SSL.', 'When your users login, they are redirected to a standard unsecure page.');
		$val['jout']			= array('Logout Landing Page',		null, null, 'When your users logout, this is the destination URL they will land on if successful.');
		$val['joutssl']			= array('Logout Land with SSL',		null, 'When your users logout, they are redirected to a page with SSL.', 'When your users logout, they are redirected to a standard unsecure page.');
		$val['whmcsurl']		= array('WHMCS Url',		null, null, 'This is the URL you entered for WHMCS.');
		$val['whmcsssl']		= array('WHMCS SSL for Redirect',		null, 'This setting tells JWHMCS to use ssl for redirecting content in WHMCS.', 'This setting would tell JWHMCS to use ssl to redirect to WHMCS pages for security purposes.');
		$val['jquery']			= array('WHMCS Enable jquery.js',		null, 'This is inserting the jquery.js file at the top of your JWHMCS rendered pages.  If you are experiencing errors, try setting this to No.', 'This setting would insert the jquery.js file at the top of your JWHMCS rendered pages.  If you are missing some javascript functionality in your WHMCS pages, try setting this to Yes.');
		$val['jstorename']		= array('Store Joomla Username Method',		null, null, 'This is the manner of storing your new Joomla user in the Joomla user database if they signup through WHMCS.');
		$val['pagein']			= array('Logged In Template Page',		null, null, 'This is the page that is pulled from Joomla to render around your WHMCS content for LOGGED IN users.');
		$val['pageout']			= array('Visitor Template Page',		null, null, 'This is the page that is pulled from Joomla to render around your WHMCS content for visitors.');
		$val['overridecache']	= array('Override Joomla Cache Setting',		null, 'This setting is overriding your cache settings in Joomla and is set NOT to use caching for JWHMCS rendered pages.', 'If you have caching on your Joomla site, but do not wish to use caching for JWHMCS rendered pages, you should set this to Yes.');
		$val['clearcache']		= array('Clear JWHMCS Cache',		null, 'This setting will clear the cache on the next load, and be set back to No once complete.', 'This setting would clear the cache on the next load if set to Yes.');
		$val['whmcs_systemurl']		= array('WHMCS System Url', true, false, 'This is the setting you have in WHMCS.  If this isnt set your site will not wrap.');
		$val['whmcs_systemsslurl']	= array('WHMCS System SSL Url', null, null, 'This is the setting you have in WHMCS.  If this isnt set you wont be using SSL.');
		$val['whmcs_defaultcountry']= array('WHMCS Default Country', null, null, 'This is the setting you have in WHMCS.  This is the default country for clients.');
		$val['whmcs_template']		= array('WHMCS Template', null, null, 'This is the setting you have in WHMCS.  This is the template you have selected in WHMCS.');
		$val['whmcs_charset']		= array('WHMCS Character Set', null, null, 'This is the setting you have in WHMCS.  For most this is utf8, but if it is something else you may encounter encoding issues.');
		$val['whmcs_nomd5']			= array('WHMCS MD5 Enabled', null, null, 'This is the setting you have in WHMCS.  This deals with how the password is encrypted in WHMCS.');
		$val['whmcs_reqpwstrength']	= array('WHMCS Required Password Strength', null, null, 'This is the setting you have in WHMCS.  If this is set too high, your customers may not be able to create accounts easily.');
		$this->chdef = $val;
		return;
	}
	
	
	
	/* ------------------------------------------------------------ *\
	 * LICENSING AND VALIDATION FUNCTIONS
	\* ------------------------------------------------------------ */
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkLicense (private)
	 * Purpose:		Check a local license against remote license
	 * As of:		version 1.5.2 (October 2009)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 *  	* Moved license key from text to database
	 *  2.0.0 (Nov 2009)
	 *  	+ Database, variable, curl and parameters moved to class
	 *  	- Removed curl to Gohigher
	 *  	+ Added request to validate license for remote check
	 * 	1.5.3 (Oct 2009)
	 * 		+ Made curl function use common _cUrl fnxn
	\* ------------------------------------------------------------ */
	private function _checkLicense()
	{
		global $params, $vars, $jcurl;
		
		// Fetch local license from params
		$licensekey = trim($params->get( 'LicenseKey' ));
		
		// Fetch local key from DB
		$localkey = trim($params->get( 'License' ));
		
		$results = $this->_validateLicense($licensekey,$localkey);
		
		// For Debugging, Echo Results
		if ($vars->get( 'licensekey' ))
		{
			if ($vars->get( 'licensekey' ) == JWHMCS_UNIQUEID )
			{
				echo "<textarea cols=100 rows=20>"; print_r($results); echo "</textarea>";
			}
		}
		
		// Test results returned
		$licparts = explode('-', $licensekey);
		if (( $results["status"] == "Active" ) || (($results["status"] == "Expired" ) && ($licparts[0] == 'Owned' )))
		{
			// Check to see if a new localkey was sent back
			if ($results["localkey"])
			{
				// Save Updated Local Key to DB
				$params->set( 'License', $results["localkey"], true, 'global' );
			}
		}
		
		if ($results['regdate'] < JWHMCS_BRANDDATE ) {
			$this->branded = false;
		}
		
		if (isset($results['addons'])) {
			foreach ( $results['addons'] as $addon ) {
				if ((strstr( $addon['name'], JWHMCS_BRANDREMOVAL ) !== false ) && ($addon['status'] == "Active" )) {
					$this->branded = false;
				}
				if ((strstr( $addon['name'], JWHMCS_KAYAKOENABLE ) !== false ) && ($addon['status'] == "Active" )) {
					$this->kayako = true;
				}
			}
		}
		
		return $results;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_validateLicense (private)
	 * Purpose:		Check local info against remote license key 
	 * As of:		version 2.0 (December 2009)
	\* ------------------------------------------------------------ */
	private function _validateLicense($licensekey,$localkey="")
	{
		global $vars; 
		
		$whmcsurl = JWHMCS_URL;
		$licensing_secret_key = JWHMCS_UNIQUEID; # Set to unique value of chars
		$checkdate = date("Ymd"); # Current date
		$usersip = isset($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : $_SERVER['LOCAL_ADDR'];
		$localkeydays = 15; # How long the local key is valid for in between remote checks
		$allowcheckfaildays = 5; # How many days to allow after local key expiry before blocking access if connection cannot be made
		$localkeyvalid = false;
		
		if ($localkey)
		{
			$localkey = str_replace("\n",'',$localkey); # Remove the line breaks
			$localdata = substr($localkey,0,strlen($localkey)-32); # Extract License Data
			$md5hash = substr($localkey,strlen($localkey)-32); # Extract MD5 Hash
			
			if ($md5hash==md5($localdata.$licensing_secret_key))
			{
				$localdata = strrev($localdata); # Reverse the string
				$md5hash = substr($localdata,0,32); # Extract MD5 Hash
				$localdata = substr($localdata,32); # Extract License Data
				$localdata = base64_decode($localdata);
				$localkeyresults = unserialize($localdata);
				$originalcheckdate = $localkeyresults["checkdate"];
				
				if ($md5hash==md5($originalcheckdate.$licensing_secret_key))
				{
					$localexpiry = date("Ymd",mktime(0,0,0,date("m"),date("d")-$localkeydays,date("Y")));
					
					if ($originalcheckdate>$localexpiry)
					{
						$localkeyvalid = true;
						$results = $localkeyresults;
						$validdomains = explode(",",$results["validdomain"]);
						
						if (!in_array($_SERVER['SERVER_NAME'], $validdomains))
						{
							$localkeyvalid = false;
							$localkeyresults["status"] = "Invalid";
							$results = array();
						}
						
						$validips = explode(",",$results["validip"]);
						
						if (!in_array($usersip, $validips))
						{
							$localkeyvalid = false;
							$localkeyresults["status"] = "Invalid";
							$results = array();
						}
						
						if ($results["validdirectory"]!=dirname(__FILE__))
						{
							$localkeyvalid = false;
							$localkeyresults["status"] = "Invalid";
							$results = array();
						}
					}
				}
			}
		}
		
		if (!$localkeyvalid) {
			$postfields["licensekey"] = $licensekey;
			$postfields["domain"] = $_SERVER['SERVER_NAME'];
			$postfields["ip"] = $usersip;
			$postfields["dir"] = dirname(__FILE__);
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $whmcsurl."modules/servers/licensing/verify.php");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $postfields);
			curl_setopt($ch, CURLOPT_TIMEOUT, 30);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			$data = curl_exec($ch);
			$info = curl_getinfo($ch);
			curl_close($ch);
			
			if (!$data) {
				$localexpiry = date("Ymd",mktime(0,0,0,date("m"),date("d")-($localkeydays+$allowcheckfaildays),date("Y")));
				
				if ($originalcheckdate>$localexpiry) {
					$results = $localkeyresults;
				}
				else {
					$results["status"] = "Remote Check Failed";
					return $results;
				}
			}
			else {
				preg_match_all('/<(.*?)>([^<]+)<\/\\1>/i', $data, $matches);
				$results = array();
				
				foreach ($matches[1] AS $k=>$v)	{
					$results[$v] = $matches[2][$k];
				}
				$remotecheck = true;
			}
			
			
			$licparts = explode('-', $licensekey);
			if (( $results["status"] == "Active" ) || (($results["status"] == "Expired" ) && ($licparts[0] == 'Owned' )))
			{
				$results["checkdate"] = $checkdate;
				$data_encoded = serialize($results);
				$data_encoded = base64_encode($data_encoded);
				$data_encoded = md5($checkdate.$licensing_secret_key).$data_encoded;
				$data_encoded = strrev($data_encoded);
				$data_encoded = $data_encoded.md5($data_encoded.$licensing_secret_key);
				$data_encoded = wordwrap($data_encoded,80,"\n",true);
				$results["localkey"] = $data_encoded;
			}
		}
		if ($remotecheck) $results["remotecheck"] = true;
		if ($vars->get( 'licensekey' ))
		{
			if ($vars->get( 'licensekey' ) == JWHMCS_UNIQUEID )
			{
				echo "<textarea cols=100 rows=20>"; print_r($postfields); print_r($info); echo "</textarea>";
			}
		}
		unset($postfields,$data,$matches,$whmcsurl,$licensing_secret_key,$checkdate,$usersip,$localkeydays,$allowcheckfaildays,$md5hash);
		
		if (isset($results['addons'])) {
			$addonarray = array();
			$i=0;
			
			$addonset = explode("|", $results['addons']);
			foreach ( $addonset as $addon ) {
				$addonvars	= explode(";", $addon);
				foreach ( $addonvars as $additem ) {
					$item	= explode("=", $additem);
					$key	= $item[0];
					unset($item[0]);
					$value	= implode("=", $item);
					$addonarray[$i][$key] = $value;
				}
				$i++;
			}
		}
		$results['addons'] = $addonarray;
		return $results;
	}
	
	
	
	/* ------------------------------------------------------------ *\
	 * REDIRECTION AND RESPONSE FUNCTIONS
	\* ------------------------------------------------------------ */
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_redirect (private)
	 * Purpose:		Provide uniform redirection functionality 
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	private function _redirect($url) {
		header( 'Location: '.$url);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_formRedirect (private)
	 * Purpose:		Provide uniform form redirection functionality
	 * As of:		version 2.0 (December 2009)
	\* ------------------------------------------------------------ */
	private function _formRedirect($url, $fields, $page = 'login')
	{
		global $params, $vars, $xml;
		
		$xml->setRoot('root');
		$vars->set( 'jwhmcs', 1 );
		$params->set( 'Debug', 0 );
		$vars->set( 'filename', 'clientarea' );
		$vars->set( 'return', true);
		
		$site	= $this->parse($page);
		$xml->setData($site);
		$site = $xml->loadResults();
		$site = $site[0];
		
		unset($site['return']);
		
		$hidden = '';
		foreach ($fields as $k => $v)
		{
			$hidden .= '<input type="hidden" name="'.$k.'" value="'.$v.'" />';
		}
		
		$tmpdir	= 'images/';
		$bgimg	= $tmpdir.'jwhmcs-trans-bg.png';
		$barimg	= $tmpdir.'jwhmcs-progress-bar.gif';
		$cssloc = $tmpdir.'jwhmcs.css';
		
		echo base64_decode($site['htmlheader']);
		//if ($page == 'whmcs')
		$redirect = "document.forms['frmlogin'].submit()";
		echo <<< HTMLFORM
<link rel="stylesheet" type="text/css" href="$cssloc" />
<script>
<!--//--><![CDATA[//><!--

img1 = new Image();
img2 = new Image();
	
img1.src = "$bgimg";
img2.src = "$barimg";

//--><!]]>
</script>
		<div class="redirect-wrapper" id="jwhmcsredirect">
		<div class="redirect-texthdr"><span>Logging In</span><br />
		<div class="redirect-imagebar">&nbsp;</div>
		</div></div>
<form action="$url" method="post" name="frmlogin" id="frmlogin">
$hidden
</form>
<script language="javascript"><!--
setTimeout ( "autoForward()", 250 );
function autoForward() {
	$redirect
}
//--></script>
HTMLFORM;
		echo base64_decode($site['htmlfooter']);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getType (private)
	 * Purpose:		Logic to determine which type of response to send 
	 * As of:		version 2.1.0 (April 2010)
	\* ------------------------------------------------------------ */
	private function _getType()
	{
		global $vars, $params;
		
		if ( $vars->get( 'joomadmin' ) ) {
			if ( $vars->get( 'joomadmin' ) == $params->get( 'Secret' )) {
				if ( $vars->get( 'debug' ) ) {
					$type = 2;
				}
				else {
					$type = 1;
				}
			}
			else {
				$type = 0;
			}
		}
		else {
			if ( $params->get( 'Debug' ) ) {
				$type = 2;
			}
			else {
				$type = 0;
			}
		}
		$type	= ( $type == 2 ? 'pair' : ( $type == 1 ? 'xml' : false ));		
		
		return $type;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_buildResponse (private)
	 * Purpose:		Build uniform responses 
	 * As of:		version 2.0 (December 2009)
	\* ------------------------------------------------------------ */
	private function _buildResponse($data, $type = 'xml')
	{
		global $params;
		
		switch ($type):
		case 'xml':
			foreach ($data as $k => $v) {
				if (is_array($v)) {
					foreach ($v as $k2 => $v2) {
						$sub[] = '<'.$k2.'><![CDATA['.$v2.']]></'.$k2.'>';
					}
					$return .= '<sub>'.implode("\n", $sub).'</sub>';
					unset($sub);
				}
				else {
					$return .= '<'.$k.'><![CDATA['.$v.']]></'.$k.'>';
				}
			}
			$return = '<?xml version="1.0" encoding="utf-8"?><root><param>'.$return.'</param></root>';
			break;
		case 'pair':
			foreach ($data as $k => $v) {
				if (is_array($v)) {
					foreach ($v as $k2 => $v2) {
						$sub[] = '['.$k2.'] = '.$v2;
					}
					$r[] = implode("\n", $sub);
				}
				else {
					$r[] = '['.$k.'] = '.$v;
				}
			}
			$return	= implode("\n", $r);
			break;
		case 'checkinstall':
			$cok = ' class="checkinstall-ok"';
			$cno = ' class="checkinstall-no"';
			
			foreach ($data as $k => $v) {
				$style	= ((!is_null($this->chdef[$k][1])) ? ( $v ? $cok : $cno ) : '' );
				$def	= ((!is_null($this->chdef[$k][1])) ? $this->chdef[$k][3] : (is_null($this->chdef[$k][2])) ? $this->chdef[$k][3] : ((!$v) ? $this->chdef[$k][3] : $this->chdef[$k][2] ) );
				$v		= (is_bool($v) ? ($v ? 'Yes' : 'No') : $v );
				if (($k == 'pagein') || ($k == 'pageout' )) $v = '<a href="'.$v.'" target="_blank">'.ucfirst($k).' Template Page</a>';
				if ( $k == 'license' ) {
					$style	= ( $data['licensevalid'] ? $cok : $cno );
					$v		= ($v == 'Invalid' ? (($this->license['message']) ? $this->license['message'] : 'Invalid License' ) : $v );
				}
				$r[]	= '<tr><td width="200" align="right" valign="top">'.$this->chdef[$k][0].'</td><td'.$style.' valign="top" width="300">'.$v.'</td><td class="checkinstall-def">'.$def.'</td></tr>';
			}
			$cssloc = 'images/jwhmcs.css';
			$return = "<link rel=\"stylesheet\" type=\"text/css\" href=\"$cssloc\" />";
			$return	.= '<table border=1 cellpadding="5" cellspacing="0">'.implode("\n", $r).'</table>';
			break;
		endswitch;
		return $return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_sendResponse (private)
	 * Purpose:		Provide uniform responses 
	 * As of:		version 2.0 (December 2009)
	\* ------------------------------------------------------------ */
	private function _sendResponse($response, $type = 'xml')
	{
		if ($type != 'xml')
		{
			echo $response;
		}
		else
		{
			header("Content-type: text/xml");
			echo $response;
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_close (private)
	 * Purpose:		Wrapper for building type and response 
	 * As of:		version 2.1.0 (April 2010)
	\* ------------------------------------------------------------ */
	private function _close($response)
	{
		global $vars;
		
		// Test to see what type of response to send (debug is plain text pairs)
		$type	= $this->_getType();
		
		// Response package
		$return = $this->_buildResponse($response, $type);
		if ($vars->get('return')) {
			$vars->set( 'return', false );
			return $return;
		}
		$this->_sendResponse($return, $type);
	}
}