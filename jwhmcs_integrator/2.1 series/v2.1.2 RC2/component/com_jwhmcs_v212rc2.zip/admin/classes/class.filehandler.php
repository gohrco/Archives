<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id$
 * @since      2.1.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once ('class.params.php');
jimport('joomla.filesystem.file');		// Import Filesystem JFile
jimport('joomla.filesystem.folder');	// Import Filesystem JFolder
jimport('joomla.filesystem.path');		// Import Filesystem JPath (just in case)

class JwhmcsFilehandler
{ 
	private static $error		= array();
	private static $instance	= null;
	private static $ftp			= null;
	private static $path		= array();
	private static $enabled		= false;
	
	var $backupext	= 'jwhmcs';
	var $buffer		= null;
	var $dst		= null;
	var $method		= "path";
	var $src		= null;
	var $tmp		= null;
	var $localsrc	= true;
	var $localdst	= false;
	
    /* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Called upon initialization of object class
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	private function __construct()
	{
		$params		= & JwhmcsParams::getInstance();
		
		if ( $params->get( 'FtpUse' ) )
		{
			$this->method		= "ftp";
			$options			= $this->_ftpGetoptions();
			$this->ftp			= $this->_ftpConnect( $options );
			$this->ftproot		= $options['rootpath'];
		}
		else
		{
			$this->method		= "path";
			$options			= array( 'path' => $params->get( 'FilePath' ) );
		}
		
		$verify = $this->validate( $options, $this->method );
		
		if ( $verify != 1 )
		{
			$this->error[] = "ERROR_VERIFYING_METHOD";
		}
		else
		{
			$this->enabled = true;
			
			if ( $this->method == 'path' )
			{
				$this->_setPath( $params->get( 'FilePath' ) );
			}
		}
		
		$this->tmp = JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.'tmp';
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getInstance
	 * Purpose:		Called to create an instance of the class
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	public static function getInstance($force = false)
	{
		if ((self::$instance == null) || ($force === true))
		{
			self::$instance = new self();
		}
		return self::$instance;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		isEnabled
	 * Purpose:		Check to see if the file handler is functional
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function isEnabled( $method = null )
	{
		// Default response
		$enabled = false;
		
		// If we have verified and set this flag then we are enabled
		if ( $this->enabled ) $enabled = true;
		
		// Test to see if we are checking for a specific method (ftp | path)
		if ( is_null($method) ) return $enabled;
		
		// Test to see if the requested method check is what is verified and if it is enabled
		return ( ( ( $method == $this->method ) && ( $this->enabled ) ) ? true : false );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		copy
	 * Purpose:		Wrapper to copy set file using ftp or path
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function copy( $src = null, $dst = null, $ow = null )
	{
		if (! is_null($ow)  ) $this->setOverwrite($ow);
		if (! is_null($src) ) $this->setSrc($src);
		if (! is_null($dst) ) $this->setDst($dst);
		
		// Check to ensure files are set
		if ( is_null($this->src) || is_null($this->dst) ) return false;
		
		// Perform copy
		if ( $this->isFtp() )
		{
			$result = $this->ftp->store( $this->src, $this->dst );
			if (! $result) $this->error[] = "ERROR_COPY_FTP";
		}
		else
		{
			$this->dst	= $this->_buildPath( $this->dst );
			$result = JFile::copy( $this->src, $this->dst );
			if (! $result) $this->error[] = "ERROR_COPY_PATH";
		}
		
		return $result;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		delete
	 * Purpose:		Wrapper to delete a file
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function delete( $type = 'dst' )
	{
		$local	= $this->_localCheck( $type );
		$file	= $this->$type;
		
		if ( $this->isFtp( $local ) )
		{
			$result = $this->ftp->delete( $file );
			if (! $result) $this->error[] = "ERROR_DELETE_FTP";
		}
		else
		{
			$result = JFile::delete( $file );
			if (! $result) $this->error[] = "ERROR_DELETE_PATHs";
		}
		
		return $result;
	}
	
	/* ------------------------------------------------------------ *\
	 * Method:		exists
	 * Purpose:		Wrapper to check existance of file
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function exists( $type = 'dst' )
	{
		$local	= $this->_localCheck( $type );
		$file	= $this->$type;
		
		if ( $this->isFtp( $local ) )
		{
			// Set null buffer
			$buffer = null;
			
			// Read the file from the FTP location to verify it exists
			$result = $this->ftp->read( $file, $buffer );
			
			if ($type == 'src' && (! $result ) )
			{
				$this->error[] = "ERROR_EXISTS_FTP_SRC_FALSE";
			}
			elseif ( $type == 'dst' && ( $result ) )
			{
				if ($this->backup)
				{
					$bfile	= $this->_getBackup( $file );
					$result = $this->ftp->rename( $file, $bfile );
				}
				else
				{
					$this->error[] = "ERROR_EXISTS_FTP_DST_TRUE";
				}
			}
		}
		else
		{
			if (! $local) $file	= $this->_buildPath( $file );
			$result = JFile::exists( $file );
			
			if ($type == 'src' && (! $result ) )
			{
				$this->error[] = "ERROR_EXISTS_PATH_SRC_FALSE";
			}
			elseif ( $type == 'dst' && ( $result ) )
			{
				if ($this->backup)
				{
					$bfile	= $this->_getBackup( $file );
					$result	= JFile::move( $file, $bfile );
				}
				else
				{
					$this->error[] = "ERROR_EXISTS_PATH_DST_TRUE";
				}
			}
		}
		
		return $result;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		get
	 * Purpose:		Wrapper to retrieve files from remote
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function get( $src = null, $dst = null, $ow = null )
	{
		if (! is_null($ow)  ) $this->setOverwrite($ow);
		if (! is_null($src) ) $this->setSrc($src);
		if (! is_null($dst) ) $this->setDst($dst);
		
		// Check to ensure files are set
		if ( is_null($this->src) || is_null($this->dst) ) return false;
		
		// Perform copy
		if ( $this->isFtp() )
		{
			$result = $this->ftp->get( $this->dst, $this->src );
			if (! $result) $this->error[] = "ERROR_GET_FTP";
		}
		else
		{
			$this->dst	= $this->_buildPath( $this->dst );
			$result = JFile::copy( $this->src, $this->dst );
			if (! $result) $this->error[] = "ERROR_GET_PATH";
		}
		
		return $result;
	}
	
	/* ------------------------------------------------------------ *\
	 * Method:		isDir
	 * Purpose:		Wrapper to test for directory
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function isDir( $item = null )
	{
		if (is_null($item)) return false;
		$orig	= $this->src;
		$result	= $this->setSrc( $item, 'folder' );
		$this->setSrc( $orig, 'folder' );
		return $result;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		isFtp
	 * Purpose:		Wrapper to indicate ftp or path
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function isFtp( $local = false )
	{
		$result = ( $this->method == "ftp" ? true : false );
		
		// Take into consideration local to local
		if ($result && $local)
		{
			$result = false;
		}
		
		return $result;
	}
	
	
	function listAll( $type = 'src' )
	{
		$local	= $this->_localCheck( $type );
		$folder = $this->$type;
		
		if ($this->isFtp( $local ))
		{
			// Retrieve folders
			$result = $this->ftp->listDetails( $folder, 'all' );
			
			for ($i=0, $n=count($result); $i<$n; $i++) {
				$result[$i] = $result[$i]['name'];
			}
		}
		else
		{
			if (! $local) $folder	= $this->_buildPath( $folder );
			$folders = JFolder::folders( $folder );
			$files	 = JFolder::files( $folder );
			$result	 = array_merge($files, $folders);
		}
		
		// If there aren't any files / folders, or the count is zero return
		if ($result === false || count($result) == 0) return false;
		
		return $result;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		listFolders
	 * Purpose:		Called to list folders
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function listFolders( $type = 'src' )
	{
		$local	= $this->_localCheck( $type );
		$folder = $this->$type;
		
		if ($this->isFtp())
		{
			// Retrieve folders
			$folders = $this->ftp->listDetails( $folder, 'folders' );
		}
		else
		{
			if (! $local) $folder	= $this->_buildPath( $folder );
			$folders = JFolder::folders( $folder );
		}
		
		// If there aren't any folders, or the count is zero return
		if ($folders === false || count($folders) == 0) return false;
		
		// Assign folder name to folder number
		for ($i=0, $n=count($folders); $i<$n; $i++) {
			$folders[$i] = $folders[$i]['name'];
		}
		
		return $folders;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		read
	 * Purpose:		Wrapper to read the contents of a file
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function read( $type = 'src', $src = null )
	{
		if (! is_null($src) ) $this->setSrc( $src );
		
		$local	= $this->_localCheck( $type );
		$file	= $this->$type;
		
		// Set null buffer
		$this->setBuffer();
		
		if ( $this->isFtp( $local ) )
		{
			// Read the file from the FTP location to verify it exists
			$result = $this->ftp->read( $file, $this->buffer );
			if (! $result) $this->error[] = "ERROR_READ_FTP";
		}
		else
		{
			$result = JFile::read( $file );
			$this->buffer = $result;
			if (! $result ) $this->error[] = "ERROR_READ_PATH";
		}
		
		if ($result)
		{
			$this->reset();
		}
		
		return $result;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		reset
	 * Purpose:		Provide means to reset the object
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function reset()
	{
		$this->dst		= null;
		$this->localdst	= false;
		$this->localsrc	= true;
		$this->src		= null;
		
		$this->setOverwrite( false );
		$this->setBackup( false );
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setBackup
	 * Purpose:		Set the backup flag for object
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function setBackup( $bu = false )
	{
		return $this->backup = $bu;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setBuffer
	 * Purpose:		Set the buffer for the object
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function setBuffer( $buffer = null )
	{
		$this->buffer = $buffer;
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setDst
	 * Purpose:		Sets the destination file
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function setDst( $file, $type = 'file' )
	{
		
		$this->dst = $file;
		$exists = ( $type == 'folder' ? 'folderexists' : 'exists' );
		
		if ( $this->$exists() )
		{
			if ($type == 'folder') return true;
			
			if (! $this->overwrite )
			{
				$this->dst = null;
				$this->error[] = "ERROR_DST_EXISTS_CANT_OVERWRITE";
				return false;
			}
			else
			{
				$this->delete();
			}
		}
		else
		{
			if ( $type == 'folder' )
			{
				$this->foldercreate();
			}
		}
		
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setOverwrite
	 * Purpose:		Set overwrite option
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function setOverwrite( $ow = false )
	{
		return $this->overwrite = $ow;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setSrc
	 * Purpose:		Sets the source file
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function setSrc( $file, $type = 'file' )
	{
		$this->src = $file;
		$exists = ( $type == 'folder' ? 'folderexists' : 'exists' );
		
		if (! $this->$exists( 'src' ) )
		{
			$this->src = null;
			$this->error[] = "ERROR_SRC_DOESNTEXIST";
			return false;
		}
		
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		write
	 * Purpose:		Wrapper to write a buffer to a file
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function write( $type = 'dst', $dst = null, $ow = null )
	{
		if (! is_null($ow)  ) $this->setOverwrite( $ow );
		if (! is_null($dst) ) $this->setDst( $dst );
		
		$local	= $this->_localCheck( $type );
		$file	= $this->$type;
		
		// Pull buffer
		$buffer = $this->buffer;
		
		if ( $this->isFtp( $local ) )
		{
			$result = $this->ftp->write( $file, $buffer );
			if (! $result) $this->error[] = "ERROR_WRITE_FTP";
		}
		else
		{
			$this->dst	= $this->_buildPath( $this->dst );
			$result = JFile::write( $this->dst, $buffer );
			if (! $result ) $this->error[] = "ERROR_WRITE_PATH {$this->dst}";
		}
		
		if ($result)
		{
			$this->reset();
		}
		
		return $result;
	}
	
	
	/* ----------------------------------------- *\
	 *              FOLDER FUNCTIONS             *
	\* ----------------------------------------- */
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		foldercreate
	 * Purpose:		Wrapper to create a folder
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function foldercreate( $type = 'dst' )
	{
		$local	= $this->_localCheck( $type );
		$folder	= $this->$type;
		
		if ($this->folderexists( $type )) return true;
		
		if ( $this->isFtp( $local ) )
		{
			// Read the file from the FTP location to verify it exists
			$result = $this->ftp->mkdir( $folder );
			
			if ($type == 'src' && (! $result ) )
			{
				$this->error[] = "ERROR_FOLDERCREATE_FTP_SRC_FALSE::$folder";
			}
			elseif ( $type == 'dst' && (! $result ) )
			{
				$this->error[] = "ERROR_FOLDERCREATE_FTP_DST_FALSE::$folder";
			}
		}
		else
		{
			if (! $local) $folder	= $this->_buildPath( $folder );
			$result = JFolder::create( $folder );
			
			if ($type == 'src' && (! $result ) )
			{
				$this->error[] = "ERROR_FOLDERCREATE_PATH_SRC_FALSE::$folder";
			}
			elseif ( $type == 'dst' && (! $result ) )
			{
				$this->error[] = "ERROR_FOLDERCREATE_PATH_DST_FALSE::$folder";
			}
		}
		
		return $result;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		foldercopy
	 * Purpose:		Wrapper to copy an entire folder
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function foldercopy( $src = null, $dst = null, $ow = null )
	{
		if (! is_null($ow)  ) $this->setOverwrite($ow);
		if (! is_null($src) ) $this->setSrc($src, 'folder');
		if (! is_null($dst) ) $this->setDst($dst, 'folder');
		
		// Check to ensure files are set
		if ( is_null($this->src) || is_null($this->dst) ) return false;
		
		// Read contents of src directory
		$contents	= $this->listAll();
		$osrc		= $this->src;
		$odst		= $this->dst;
		
		foreach($contents as $item)
		{
			$isDir	= $this->isDir($osrc . DS . $item);
			$action = ( (! $this->localsrc ) && ( $this->localdst ) ? 'get' : 'copy' );
			$type	= 'file';
			
			if ($isDir)
			{
				$action = 'foldercopy';
				$type	= 'folder';
				$this->foldercreate();
			}
			
			$this->setSrc( $osrc.DS.$item, $type );
			$this->setDst( $odst."/".$item, $type );
			$this->$action();
		}
		
		return $result;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		folderdelete
	 * Purpose:		Delete a folder
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function folderdelete( $type = 'dst' )
	{
		$local	= $this->_localCheck( $type );
		$folder	= $this->$type;
		
		if ( $this->isFtp( $local ) )
		{
			$result = $this->ftp->delete( $folder );
			if (! $result) $this->error[] = "ERROR_FOLDERDELETE_FTP";
		}
		else
		{
			$result = JFolder::delete( $folder );
			if (! $result) $this->error[] = "ERROR_FOLDERDELETE_FTP";
		}
		
		return $result;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		folderduplicate
	 * Purpose:		Duplicate a remote folder
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function folderduplicate( $src = null, $dst = null, $ow = null )
	{
		$this->localsrc = false;
		
		if (! is_null($ow)  ) $this->setOverwrite($ow);
		if (! is_null($src) ) $this->setSrc($src, 'folder');
		if (! is_null($dst) ) $this->setDst($dst, 'folder');
		
		if ( $this->src === null || $this->dst === null ) return false;
		if ( $this->isFtp( false ) )
		{
			// 1) Save dst filename for future retrieval
			$odst	= $this->dst;
			$tmp	= $this->tmp . DS . $odst;
			
			// 2) Set local tmp directory and retrieve files
			$this->localdst = true;
			$this->setDst( $tmp, 'folder' );
			$this->foldercopy();
			
			// 3) Set remote dst dir and local tmp to src and store
			$this->localdst = false;
			$this->localsrc = true;
			$this->setSrc( $tmp, 'folder' );
			$this->setDst( $odst );
			$this->foldercopy();
			
			// 4) Delete local temp directory
			$this->setSrc( $this->tmp, 'folder' );
			$this->folderdelete( 'src' );
			$result = true;
		}
		else
		{
			if (! $local) $this->src = $this->_buildPath( $this->src );
			$this->dst	= $this->_buildPath( $this->dst );
			$result = JFolder::copy( $this->src, $this->dst, '', $this->overwrite );
		}
		$this->reset();
		return $result;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		folderexists
	 * Purpose:		Wrapper to check existance of a folder
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function folderexists( $type = 'dst' )
	{
		$local	= $this->_localCheck( $type );
		$folder	= $this->$type;
		
		if ( $this->isFtp( $local ) )
		{
			// Read the file from the FTP location to verify it exists
			$result = $this->ftp->chdir( $folder );
			$this->ftp->chdir( $this->ftproot );
			
			if ($type == 'src' && (! $result ) )
			{
				$this->error[] = "ERROR_FOLDEREXISTS_FTP_SRC_FALSE::$folder";
			}
			elseif ( $type == 'dst' && ( $result ) )
			{
				$this->error[] = "ERROR_FOLDEREXISTS_FTP_DST_TRUE::$folder";
			}
		}
		else
		{
			if (! $local) $folder	= $this->_buildPath( $folder );
			$result = JFolder::exists( $folder );
			
			if ($type == 'src' && (! $result ) )
			{
				$this->error[] = "ERROR_FOLDEREXISTS_PATH_SRC_FALSE::$folder";
			}
			elseif ( $type == 'dst' && ( $result ) )
			{
				$this->error[] = "ERROR_FOLDEREXISTS_PATH_DST_TRUE::$folder";
			}
		}
		
		return $result;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		folderget
	 * Purpose:		Retrieve a remote folder and store locally
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function folderget( $type = 'src' )
	{
		$local	= $this->_localCheck( $type );
		$folder	= $this->$type;
		
		if ( $this->isFtp( $local ) )
		{
			switch ($type):
			case 'src':
				echo "Trying to get {$this->src} and save it to {$this->dst}<p>";
				$result = $this->ftp->get( $this->dst, $this->src );
				break;
			case 'dst':
				echo "Trying to get {$this->dst} and save it to {$this->src}<p>";
				$result = $this->ftp->get( $this->src, $this->dst );
				break;
			endswitch;
			
			if ($type == 'src' && (! $result ) )
			{
				$this->error[] = "ERROR_FOLDERGET_FTP_SRC_FALSE";
			}
			elseif ( $type == 'dst' && ( $result ) )
			{
				$this->error[] = "ERROR_FOLDERGET_FTP_DST_TRUE";
			}
		}
		else
		{
			// To do later
			$result = false;
		}
		return $result;
	}

	
	
	/* ----------------------------------------- *\
	 *              SUB FUNCTIONS                *
	\* ----------------------------------------- */
	
	/* ------------------------------------------------------------ *\
	 * Method:		_buildPath (private)
	 * Purpose:		Create the path
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	private function _buildPath( $file = null )
	{
		$path = $this->path . DS . $file;
		return str_replace("\\", "\\\\", $path);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_getBackup (private)
	 * Purpose:		Common location to get create the name of the backup file
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	private function _getBackup ( $file )
	{
		$fparts 	= explode( ".", $file );
		$ext		= array_pop( $fparts );
		$fparts[]	= $this->backupext;
		return implode( ".", $fparts );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_getSignature (private) -- NEED?
	 * Purpose:		Common location to generate signature
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	private function _getSignature( $options, $type = 'ftp' )
	{
		switch ($type):
		case 'ftp':
			$signature	= $options['username'].':'.$options['password'].'@'.$options['hostname'].':'.$options['port'];
			break;
		case 'path':
			$signature	= serialize($options);
			break;
		endswitch;
		return $signature;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_ftpConnect
	 * Purpose:		Connect to the FTP server and change directory
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	private function _ftpConnect( $options )
	{
		$ftp = & JFTP::getInstance($options['hostname'], $options['port'], null, $options['username'], $options['password']);
		$ftp->chdir($options['rootpath']);
		return $ftp;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_ftpGetoptions (private)
	 * Purpose:		Retrieves the options for FTP from the database
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	private function _ftpGetoptions()
	{
		$params	= & JwhmcsParams::getInstance();
		
		$options['hostname']	= $params->get( 'FtpHostname' );
		$options['port']		= $params->get( 'FtpPort' );
		$options['username']	= $params->get( 'FtpUsername' );
		$options['password']	= $params->get( 'FtpPassword' );
		$options['rootpath']	= $params->get( 'FtpPath' );
		return $options;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_setPath (private)
	 * Purpose:		Sets the path
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	private function _setPath( $path )
	{
		$this->path = preg_replace('#[/\\\\]+#', DS, $path);
		return;
	}
	
	
/* ------------------------------------------------------------ *\
	 * Method:		_localCheck (private)
	 * Purpose:		Common way to check if a file is to be local
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	private function _localCheck( $type )
	{
		$local	= $type == 'src' ? true : false;
		if ( $type == 'src' && (! $this->localsrc) )
			$local = false;
		
		if ( $type == 'dst' && (  $this->localdst) )
			$local = true;
		
		return $local;
	}
	
	
	/* ----------------------------------------- *\
	 *       SUB FUNCTIONS -- VERIFICATION       *
	\* ----------------------------------------- */
	
	/* ------------------------------------------------------------ *\
	 * Method:		validate
	 * Purpose:		Called to verify a path or ftp credentials
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	public function validate( $type = 'ftp' )
	{
		$params = & JwhmcsParams::getInstance();
		
		switch ($type):
		case 'ftp':
			
			// Connect to FTP First
			if (! self::ftpVerifyconxn( $options ) ) {
				return false;
			}
			
			// We connected, now lets try to login
			if (! self::ftpVerifylogin( $options ) ) {
				return false;
			}
			
			// All is well, lets connect like we should
			$ftp		= new self;
			$ftp->src	= $params->get( 'FtpPath' );
			
			// Retrieve the root path
			if (! $ftp->ftpVerifyroot( 0 ) )
			{
				return false;
			}
			
			break;
		case 'path':
			$path = $options['path'];
			
			if (! $path)
			{	// No path entered so return false
				return false;
			}
			else
			{	// Path was provided now test
				if (! JFile::exists($path.DS.'configuration.php' ))
				{	// Path doesn't contain configuration file
					return false;
				}
				else
				{	// Path has config file, test for dbconnect
					if (! JFile::exists($path.DS.'dbconnect.php'))
					{	// Path doesn't contain dbconnect file
						return false;
					}
				}
			}
		
			// So we know the path is legit, can we write to it?
			if (! JPath::canChmod($path) )
			{	// We can't write to the path with Joomla!
				return false;
			}
			break;
		endswitch;
		
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		verify
	 * Purpose:		Called to verify a path or ftp credentials
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	public function verify( $options, $type = 'ftp' )
	{
		$params = & JwhmcsParams::getInstance();
		
		switch ($type):
		case 'ftp':
			$params->set( 'FtpHostname',	$options['hostname'], false, 'install' );
			$params->set( 'FtpPort',		$options['port'],	  false, 'install' );
			$params->set( 'FtpUsername',	$options['username'], false, 'install' );
			$params->set( 'FtpPassword',	$options['password'], false, 'install' );
			$params->set( 'FtpUse', '1', false, 'install' );
				
			// Connect to FTP First
			if (! self::ftpVerifyconxn( $options ) ) {
				return 2;
			}
			
			// We connected, now lets try to login
			if (! self::ftpVerifylogin( $options ) ) {
				return 3;
			}
			
			// All is well, lets connect like we should
			$ftp		= new self;
			$ftp->src	= "/";
			
			// Retrieve the root path
			$rootpath = $ftp->ftpVerifyroot();
			
			// Test to see if we could find the root path
			if (! $rootpath ) {
				return 4;
			}
			
			$params->set( 'FtpPath', $rootpath, false, 'install' );
			$params->saveAll();
			
			return 1;
			break;
		case 'path':
			$path = $options['path'];
			
			if (! $path)
			{	// No path entered so return false
				return -1;
			}
			else
			{	// Path was provided now test
				if (! JFile::exists($path.DS.'configuration.php' ))
				{	// Path doesn't contain configuration file
					return -2;
				}
				else
				{	// Path has config file, test for dbconnect
					if (! JFile::exists($path.DS.'dbconnect.php'))
					{	// Path doesn't contain dbconnect file
						return -3;
					}
				}
			}
		
			// So we know the path is legit, can we write to it?
			if (! JPath::canChmod($path) )
			{	// We can't write to the path with Joomla!
				return -4;
			}
			else
			{
				$params->set( 'FilePath', preg_replace('#[/\\\\]+#', DS, $path) );
				return 1;
			}
			break;
		endswitch;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		ftpResetroot
	 * Purpose:		Method to clear root for upgrades
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function ftpResetroot()
	{
		$this->ftproot = "";
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		ftpVerifyroot
	 * Purpose:		Called to find the root of the ftp server
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function ftpVerifyroot( $max = 3 )
	{
		static $count = 0;
		
		// Count recursions - don't go past 2
		if ( $count >= $max )
		{
			return false;
		}
		
		// Retrieve folders
		$this->localsrc = false;
		$folders = $this->listAll();
		
		// If there aren't any folders, return false
		if (! is_array($folders) ) return false;
		
		// dirList = WHMCS folders to find
		// excList = Folders to exclude from search
		$dirList = array('includes', 'templates', 'modules', 'pipe', 'index.php', 'dbconnect.php');
		$excList = array('.cpanel', '.', '..', 'etc', 'mail', 'public_ftp', 'tmp');
		
		// If there is no difference (the dirs are found) then return the current dir
		if( count( array_diff( $dirList, $folders ) ) == 0 ) {
			return $this->src;
		}
		
		// Set originals so we can go back
		$orig = $this->src;
		if ($orig == "/") $orig = "";
		$count++;
		// Cycle through each folder and try to find the root in the folder
		foreach ($folders as $n => $name)
		{
			// Make sure the directory isn't in the exclude list
			if (in_array($name, $excList) ) continue;
			$this->src = $orig.'/'.$name;
			$ret = $this->ftpVerifyroot( $max );
			
			// If the current directory was returned, then send back to calling function
			if ($ret) return $ret;
		}
		
		// Reset the dir to the original before returning false
		$this->src = $orig;
		$count--;
		return false;
		
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		ftpVerifyconxn
	 * Purpose:		Called to verify an ftp connection
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function ftpVerifyconxn( $options )
	{
		$vftp = & JFTP::getInstance($options['hostname'], $options['port']);
		$return	= $vftp->isConnected();
		$vftp->quit();
		return $return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		ftpVerifylogin
	 * Purpose:		Called to verify an ftp host and port
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function ftpVerifylogin( $options )
	{
		$vftp	= & JFTP::getInstance($options['hostname'], $options['port'] );
		$return = $vftp->login($options['username'], $options['password']);
		$vftp->quit();
		return $return;
	}
}