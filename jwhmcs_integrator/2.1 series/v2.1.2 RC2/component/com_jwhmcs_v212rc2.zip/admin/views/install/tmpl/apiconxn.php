<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');
JHTML::_('behavior.formvalidation');

$data = $this->data;
$j48apiconxn = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-48-apiconxn.png';
$j32jwhmcs = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-jwhmcs.png';
$j32helppage = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-helppage.png';
?>

<style type="text/css" >
input.invalid { color: #fff; background-color: #f00; }
.icon-48-apiconxn { background-image: url('<?php echo $j48apiconxn; ?>'); }
.icon-32-helppage { background-image: url('<?php echo $j32helppage; ?>'); }
td.paramlabel { font-style: italic; color: #333; }
.paramname { font-size: medium; font-weight: bold; }
.paramdesc { font-size: xx-small; clear: both; }
</style>
<form action="index.php" method="post" name="adminForm">
<div id="adminInput">
	<table class="admintable" width="675px" border="0">
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				WHMCS Url
				</div>
				<div class="paramdesc">
				Enter the complete URL to your WHMCS install, including the scheme.  This would be the address that you or your users would enter into the browser to visit your WHMCS site.  For reference, your Joomla site's URL has been entered below.
				</div>
			</td>
			<td rowspan="11" width="220px" valign="top">
				<div id="apistatus">
				&nbsp;
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="text" name="jwhmcsurl" value="<?php echo $data->jwhmcsurl; ?>" size="40" style="font-size: 14px; " onChange="ajaxCheckAPIU();" id="jwhmcsurl" />
			</td>
		<tr><td>&nbsp;</td></tr>
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				API Username
				</div>
				<div class="paramdesc">
				Enter the API Username for WHMCS (configured in WHMCS).
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="text" name="jwhmcsadminus" value="<?php echo $data->jwhmcsadminus; ?>" size="40" style="font-size: 14px; " id="jwhmcsadminus" onChange="ajaxCheckAPIU();" />
			</td>
		</tr>
		<tr><td>&nbsp;</td></tr>
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				API Password
				</div>
				<div class="paramdesc">
				Enter the API Password for WHMCS (configured in WHMCS).
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="password" name="jwhmcsadminpw" value="<?php echo $data->jwhmcsadminpw; ?>" size="40" style="font-size: 14px; " id="jwhmcsadminpw" onChange="ajaxCheckAPIU();" />
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				API Access Key (optional)
				</div>
				<div class="paramdesc">
				If you have installed iWHMCS or another module from WHMCS that requires use of an API Access Key, please enter it below.  Your access key would have been configured in the WHMCS configuration.php file.
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area" type="text" name="accesskey" value="<?php echo $data->accesskey; ?>" size="40" style="font-size: 14px; " id="accesskey" onChange="ajaxCheckAPIU();" />
			</td>
		</tr>
	</table>
</div>
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="apiconnection" id="apiconnection" value="0" />
<input type="hidden" name="task" value="apiconxnAccept" />
<input type="hidden" name="controller" value="install" />
</form>
<script language="javascript">
window.onload = ajaxCheckAPIU();
</script>