<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: default.php 202 2010-04-23 20:49:10Z Steven $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsControllerDefault
 * Extends:		JController
 * Purpose:		Used to set tasks for default controller
 * As of:		version 1.5.0
\* ------------------------------------------------------------ */
class JwhmcsControllerDefault extends JwhmcsController
{
	/* ------------------------------------------------------------ *\
	 * Task:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	function __construct()
	{
		// If the view hasn't been set, set it to default
		if (is_null(JRequest::getVar( 'view'))) JRequest::setVar('view', 'default' );
		
		parent::__construct();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		cron
	 * Purpose:		Task for calling automated updates to database
	 * As of:		version 1.5.0
	 * 
	 * Significant Revisions
	 *  2.1.0 (Apr 2010)
	 *  	* Modified parameters to reflect database change
	\* ------------------------------------------------------------ */
	function cron()
	{
		// 0:  Initialize variables
		global $mainframe;
		$params	= & JwhmcsParams::getInstance();
		$this->addModelPath( JPATH_COMPONENT_ADMINISTRATOR.DS.'models' );
		
		$db		= & JFactory::getDBO();
		$uri	= & JURI::getInstance();
		$model	= & $this->getModel( 'sync' );
		
		// 1:  Check for secret value from querystring
		if (!($secret = JRequest::getVar( 'secret' )))
			return false;
		
		// 2:  Compare against parameter secret value (false == fail)
		if ($secret != $params->get( 'Secret'))
			return false;
		
		// 3:  Pull action from querystring to run
		if (!($action = JRequest::getVar( 'action' )))
			return false;
		
		// 4:  Run action
		if (! method_exists($model, $action))
			exit('No method');
		
		if (! ($cid = JRequest::getVar( 'cid', array(0), 'post', 'array' )))
			$cid = array();
		
		$model->$action($cid);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		whmcs_login
	 * Purpose:		Login a user from WHMCS
	 * As of:		1.5.3
	\* ------------------------------------------------------------ */
	function whmcs_login()
	{
		global $mainframe;
		$db		= & JFactory::getDBO();
		$uri	= & JURI::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		// 1: Retrieve variables based on token
		$vars	= $this->_getSess(JRequest::getVar( 'token' ));
		
		foreach ($vars as $k => $v) {
			$var[$k] = $v;
			if (in_array($k, array('username', 'passwd', 'password'))) continue;
			JRequest::setVar( $k, $v );
		}
		
		// Test to see if we are using User Integration, if not bypass login and return
		if ($params->get( 'UserEnable' ) ) {
			// 2: Set the return redirect (jwhmcs.php)
			$silent			= ( JRequest::getVar('whmcs')=="1" ? true : false );
			$options = array('remember' => true, 'return' => $var['return'], 'silent' => $silent);
			$credentials = array('username' => $var['username'], 'password' => $var['passwd']);
		
			//preform the login action
			$error = $mainframe->login($credentials, $options);
		}
		
		// If we are here then login failed, so determine where to return to
		if ($origin = JRequest::getVar( 'origin' ) ) {
			$org	= & JURI::getInstance(base64_decode($origin));
			$org->setVar('incorrect', 'true');
			$return = $org->toString();
		}
		elseif ( ! $return = JRequest::getVar( 'return' ) ) {
			$return = 'index.php?option=com_user';
		}
		else {
			// Return exists and is base64 encoded
			$return = trim(base64_decode($return), '?');
			
			$ret = & JURI::getInstance($return);
			$ret->setVar('incorrect', 'true');
			$return = $ret->toString();
		}
		
		$mainframe->redirect( $return );
	}
}