<?php
/**
 * Group Management Model for J!WHMCS Integrator
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since		1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model
jimport( 'joomla.database.table.plugin' );

include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelSync
 * Extends:		JwhmcsModel
 * Purpose:		Used to synchronize the WHMCS user table with J!
 * 
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsModelConfig extends JwhmcsModel
{
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
		
	}
	
	
	function getData()
	{
		// Gather Component Parameters
		$table	= & JTable::getInstance( 'component' );
		$table->loadByOption( 'com_jwhmcs' );
		
		$plugin = & JTable::getInstance( 'plugin' );
		
		$path	= JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jwhmcs'.DS.'config.xml';
		$comparams	= new JParameter( $table->params, $path );
		
		// Gather Authentication Plugin parameters
		$path	= JPATH_PLUGINS.DS.'authentication'.DS.'jwhmcs_auth.xml';
		$authparam	= new JParameter( $this->getPluginParams('authentication'), $path);
		
		// Gather System Plugin parameters
		$path	= JPATH_PLUGINS.DS.'system'.DS.'jwhmcs.xml';
		$sysmparam	= new JParameter( $this->getPluginParams('system'), $path);
		
		// Gather User Plugin Parameters
		$path	= JPATH_PLUGINS.DS.'user'.DS.'jwhmcs.xml';
		$userparam	= new JParameter( $this->getPluginParams('user'), $path);
		
		// Create Arrays for assigning parameters
		$comp_array = array( 'licensekey', 'jwhmcsdebug', 'jwhmcsjurl', 'jwhmcssecret' );
		$user_array = array( 'jwhmcsredirwhmcs', 'menuid', 'autoaddjoomla', 'autoupdatejoomlapw', 'autoaddwhmcs', 'autoupdatewhmcspw', 'whmcsaddress', 'whmcscity', 'whmcsstate', 'whmcspostal', 'whmcscntry', 'whmcsphone', 'jwhmcsjin', 'jwhmcsjinssl', 'jwhmcsjout', 'jwhmcsjoutssl', 'jwhmcsjstoreus' );
		$plug_array = array( 'authvers', 'sysmvers', 'uservers' );
		$style_array = array( 'jwhmcsjrootimgurl', 'jwhmcsjssl', 'jwhmcsssl', 'jwhmcsjquery', 'jwloggedinurl', 'jwloggedouturl', 'overridecache', 'clearcache', 'jwlnkdefault', 'jwhmcsmenustyle', 'jwlnkaffiliates', 'jwlnkannouncements', 'jwlnkbanned', 'jwlnkcart', 'jwlnkclientarea', 'jwlnkconfiguressl', 'jwlnkcontact', 'jwlnkdomainchecker', 'jwlnkdownloads', 'jwlnkindex', 'jwlnkknowledgebase', 'jwlnklogout', 'jwlnknetworkissues', 'jwlnkorder', 'jwlnkpasswordreminder', 'jwlnkpwreset', 'jwlnkpwresetvalidation', 'jwlnkregister', 'jwlnkserverstatus', 'jwlnksubmitticket', 'jwlnksupporttickets', 'jwlnktutorials', 'jwlnkupgrade', 'jwlnkviewinvoice', 'jwlnkviewticket' );
		$whmcs_array = array( 'jwhmcsurl', 'jwhmcsadminus', 'jwhmcsadminpw', 'accesskey' );
		
		// Loop through Parameters and create groups
		$tmp['comp'] = $comparams->getParams();
		$tmp['auth'] = $authparam->getParams();
		$tmp['sysm'] = $sysmparam->getParams();
		$tmp['user'] = $userparam->getParams();
		
		foreach ($tmp as $params) {
			foreach ($params as $param) {
				if (in_array($param[5], $comp_array)) {
					$data->comp[] = $param;
				}
				elseif (in_array($param[5], $user_array)) {
					$data->user[] = $param;
				}
				elseif (in_array($param[5], $plug_array)) {
					$data->plug[] = $param;
				}
				elseif (in_array($param[5], $style_array)) {
					$data->style[] = $param;
				}
				elseif (in_array($param[5], $whmcs_array)) {
					$data->whmcs[] = $param;
				}
			}
		}
		
		return $data;
	}
	
	
	function store()
	{
		// Setting array of parameters
		$component_array = array( 'licensekey', 'jwhmcsdebug', 'jwhmcsjurl', 'jwhmcssecret', 'jwhmcsjin', 'jwhmcsjinssl', 'jwhmcsjout', 'jwhmcsjoutssl', 'jwhmcsjstoreus',  'jwhmcsjrootimgurl', 'jwhmcsjssl', 'jwhmcsssl', 'jwhmcsjquery', 'jwloggedinurl', 'jwloggedouturl', 'overridecache', 'clearcache', 'jwlnkdefault', 'jwhmcsmenustyle', 'jwlnkaffiliates', 'jwlnkannouncements', 'jwlnkbanned', 'jwlnkcart', 'jwlnkclientarea', 'jwlnkconfiguressl', 'jwlnkcontact', 'jwlnkdomainchecker', 'jwlnkdownloads', 'jwlnkindex', 'jwlnkknowledgebase', 'jwlnklogout', 'jwlnknetworkissues', 'jwlnkorder', 'jwlnkpasswordreminder', 'jwlnkpwreset', 'jwlnkpwresetvalidation', 'jwlnkregister', 'jwlnkserverstatus', 'jwlnksubmitticket', 'jwlnksupporttickets', 'jwlnktutorials', 'jwlnkupgrade', 'jwlnkviewinvoice', 'jwlnkviewticket', 'jwhmcsurl', 'jwhmcsadminus', 'jwhmcsadminpw', 'accesskey' );
		$plug_auth_array = array( 'autoaddjoomla', 'autoupdatejoomlapw', 'autoaddwhmcs', 'autoupdatewhmcspw', 'whmcsaddress', 'whmcscity', 'whmcsstate', 'whmcspostal', 'whmcscntry', 'whmcsphone' );
		$plug_sysm_array = array( 'jwhmcsredirwhmcs', 'menuid' );
		$plug_user_array = array( );
		
		// Retrieve params from form submitted
		$params = JRequest::getVar('params');
		
		foreach ($params as $k => $v) {
			if (in_array($k, $component_array)) {
				$p['component'][$k] = $v;
			}
			elseif (in_array($k, $plug_auth_array)) {
				$p['authentication'][$k] = $v;
			}
			elseif (in_array($k, $plug_sysm_array)) {
				$p['system'][$k] = $v;
			}
			elseif (in_array($k, $plug_user_array)) {
				$p['user'][$k] = $v;
			}
		}
		
		foreach ($p as $type => $params) {
			$params = $this->_buildParams($params);
			$this->setParams($type, $params);
		}
		return true;
	}
	
	
	/* ----------------------------------------- *\
	 *              SUB FUNCTIONS                *
	\* ----------------------------------------- */
	
	
	function getPluginParams($type)
	{
		$db = & JFactory::getDBO();
		$params	= & JComponentHelper::getParams('com_jwhmcs');
		
		$query	= 'SELECT `params` FROM #__plugins WHERE `folder` = "'.$type.'" AND `element` LIKE "%jwhmcs%"';
		$db->setQuery($query);
		return $db->loadResult();
	}
	
	
	function setParams($type, $params)
	{
		$db = & JFactory::getDBO();
		
		switch ($type)
		{
			case 'component':
				$query	= "UPDATE #__components SET `params` = '%s' WHERE `option` = 'com_jwhmcs'";
				break;
			default:
				$query	= "UPDATE #__plugins SET `params` = '%s' WHERE `folder` = '".$type."' AND `element` LIKE '%s'";
		}
		$query	= sprintf($query, $params, '%jwhmcs%');
		$db->setQuery($query);
		return $db->query();
	}
	
	
	function _buildParams($params)
	{
		foreach ($params as $k => $v) {
			$p[] = $k .'='. $v;
		}
		return implode("\n", $p);
	}
	
	
	private function _checkPluginStatus( $plugin = 'authentication' )
	{
		$db = & JFactory::getDBO();
		
		$query = 'SELECT `params` FROM #__plugins WHERE `folder` = "'.$plugin.'" AND `element` LIKE "%jwhmcs%"';
		$db->setQuery($query);
		$result	= $db->loadResult();
		
		if (!$result) return false;
		else return $result;
	}
	
	
}