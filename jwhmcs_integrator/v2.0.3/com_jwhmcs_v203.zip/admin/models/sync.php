<?php
/**
 * Group Management Model for J!WHMCS Integrator
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since		1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelSync
 * Extends:		JwhmcsModel
 * Purpose:		Used to synchronize the WHMCS user table with J!
 * 
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsModelSync extends JwhmcsModel
{
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
		
		global $mainframe, $option;
		
		// Get pagination request variables
		$limit			= $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart		= $mainframe->getUserStateFromRequest($option.'.limitstart', 'limitstart', 0, 'int');
		$search			= $mainframe->getUserStateFromRequest('articleelement.search',				'search',			'',	'string');
		$search			= JString::strtolower($search);
		
		// In case limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
		$this->setState('search', $search);
		
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getData
	 * Purpose:		This model retrieves the data for the view based
	 * 				on the parameters and task sent to it.
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function getData(&$params, $task = null)
	{
		// 0:  Initialize Common Variables
		global $mainframe, $option;
		$db		= &JFactory::getDBO();
		$uri	= &JURI::getInstance();
		
		$filter_order		= $mainframe->getUserStateFromRequest( "$option.filter_order",		'filter_order',		'a.name',	'cmd' );
		$filter_order_Dir	= $mainframe->getUserStateFromRequest( "$option.filter_order_Dir",	'filter_order_Dir',	'',			'word' );
		$filter_type		= $mainframe->getUserStateFromRequest( "$option.filter_type",		'filter_type', 		0,			'string' );
		$search				= $mainframe->getUserStateFromRequest( "$option.search",			'search', 			'',			'string' );
		$search				= JString::strtolower( $search );
		
		$limit				= $mainframe->getUserStateFromRequest( 'global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int' );
		$limitstart			= $mainframe->getUserStateFromRequest( $option.'.limitstart', 'limitstart', 0, 'int' );
		
		// 1:  Switch on task
		switch ($task):
		default:
			$query	= 'SELECT SQL_CALC_FOUND_ROWS w.* '
						.' FROM #__jwhmcs_user AS w '
						.' ORDER BY id';
			$db->setQuery($query, $limitstart, $limit);
			$items	= $db->loadObjectList();
			
			// Fetch Pagination
			$db->setQuery('SELECT FOUND_ROWS();');
			jimport('joomla.html.pagination');
			$pagination = new JPagination($db->loadResult(), $this->getState('limitstart'), $this->getState('limit') );
			
			$data->items		= $items;
			$data->pagination	= $pagination;
		endswitch;
		
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	requery
	 * Purpose:		Takes the user and finds updated info
	 * As of:		version 1.5.1 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.0 (Dec 2009)
	 *  	+ Added usage of JwhmcsCurl class
	 *  	- Dropped usage of _wCurl function
	\* ------------------------------------------------------------ */
	public function requery($cid)
	{
		// 0:  Initialize Variables
		$db = &JFactory::getDBO();
		$params	= &JComponentHelper::getParams( 'com_jwhmcs' );
		$cnt	= 0;
		
		$jcurl	=& JwhmcsCurl::getInstance();
		
		// 1:  For each cid, pull current WHMCS user data
		foreach ($cid as $id)
		{
			$jcurl->setAction('getclientsdata', array('clientid' => $id));
			$data[$cnt] = $jcurl->loadResult();
			$data[$cnt]['clientid'] = $id;
			$cnt++;
		}
		
		// 2:  Run through collected data
		foreach ($data as $item):
			// 2a: Update the user information
			if ($item['result']=='success'):
				$query = 'UPDATE #__jwhmcs_user SET '
					.'fname='.$db->Quote($item['firstname']).', '
					.'lname='.$db->Quote($item['lastname']).', '
					.'cname='.$db->Quote($item['companyname']).', '
					.'email='.$db->Quote($item['email']).', '
					.'address1='.$db->Quote($item['address1']).', '
					.'address2='.$db->Quote($item['address2']).', '
					.'city='.$db->Quote($item['city']).', '
					.'state='.$db->Quote($item['state']).', '
					.'postal='.$db->Quote($item['postcode']).', '
					.'country='.$db->Quote($item['country']).', '
					.'phonenumber='.$db->Quote($item['phonenumber'])
					.' WHERE id='.$item['userid'];
			
			// 2b: If no user info found, remove user record from table
			else:
				$query = 'DELETE FROM #__jwhmcs_user WHERE id='.$item['clientid'];
			endif;
			$db->setQuery($query);
			$db->query();
		endforeach;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	reload
	 * Purpose:		Clears WHMCS users from table and reloads them
	 * As of:		version 1.5.1 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.0 (Dec 2009)
	 *  	+ Calls function in root file instead of using API
	 *  	- Dropped numerous slow calls to API
	\* ------------------------------------------------------------ */
	public function reload()
	{
		// 0:  Initialize Variables
		$db		= &JFactory::getDBO();
		$data	= array();
		$params	= &JComponentHelper::getParams( 'com_jwhmcs' );
		$jcurl	=& JwhmcsCurl::getInstance();
		
		// 1:  Empty current jwhmcs_user table
		$query	= 'TRUNCATE TABLE #__jwhmcs_user';
		$db->setQuery($query);
		$db->query();
		
		// 2:  Retrieve data from root file
		$jcurl->setCall();
		$url = 'http://'.$params->get('jwhmcsurl').'/jwhmcs.php?task=syncReload&jwhmcs=1&joomadmin=1';
		$jcurl->set(CURLOPT_URL, $url);
		$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
		$jcurl->setRoot('SUB');
		$ret = $jcurl->loadResults();
		
		// 3:  Store gathered data
		$query	= 'INSERT INTO #__jwhmcs_user (`id`, `fname`, `lname`, `cname`, `email`, `address1`, `address2`, `city`, `state`, `postal`, `country`, `phonenumber`) VALUES '; 
		if (count($ret)>0) {
			foreach ($ret as $item):
				$q[]	= ' ('	.$db->Quote($item['id']).', '
								.$db->Quote($item['firstname']).', '
								.$db->Quote($item['lastname']).', '
								.$db->Quote($item['companyname']).', '
								.$db->Quote($item['email']).', '
								.$db->Quote($item['address1']).', '
								.$db->Quote($item['address2']).', '
								.$db->Quote($item['city']).', '
								.$db->Quote($item['state']).', '
								.$db->Quote($item['postcode']).', '
								.$db->Quote($item['country']).', '
								.$db->Quote($item['phonenumber']).')';
			endforeach;
			$query	= $query.implode(',', $q);
			$db->setQuery($query);
			$db->query();
		}
		
		$this->_timeStamp();
		
		// 5:  Return
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	refresh
	 * Purpose:		Finds missing users and adds them into database
	 * As of:		version 1.5.3 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.0 (Dec 2009)
	 *  	+ Added usage of JwhmcsCurl class
	 *  	- Dropped usage of _wCurl function
	\* ------------------------------------------------------------ */
	public function refresh ()
	{
		// 0:  Initialize variables
		$db		= & JFactory::getDBO();
		$params	= & JComponentHelper::getParams( 'com_jwhmcs' );
		$jcurl	= & JwhmcsCurl::getInstance();
		
		$chkids = array();
		$data	= array();
		
		// 1:  Select current ids from jwhmcs_user table
		$query	= 'SELECT id FROM #__jwhmcs_user ORDER BY id DESC';
		$db->setQuery($query);
		$curids	= $db->loadResultArray();
		
		$maxid = $curids[0] + 20;
		
		// 2:  Assemble array of potential ids to check
		for ($i=1; $i<=$maxid; $i++) {
			$chkids[$i] = true;
		}
		
		// 3:  Set each id that already exists to false
		foreach ($curids as $curid) {
			$chkids[$curid] = false;
		}
		
		// 4:  One by one, pull user data from WHMCS
		for($i=1; $i<=$maxid; $i++):
			
			if ($chkids[$i]===false)
			{
				continue;
			}
			
			$jcurl->setAction('getclientsdata', array('clientid' => $i));
			$whmcs	= $jcurl->loadResult();
			
			if ($whmcs['result']=='success')
			{
				$data[]	= $whmcs;
				if ($i>$maxid)
					$maxid = $i;		// Reset maximum to new highest
			}
		endfor;
		
		// 5:  Store gathered data
		if (count($data) > 0) {
			$query	= 'REPLACE INTO #__jwhmcs_user (`id`, `fname`, `lname`, `cname`, `email`, `address1`, `address2`, `city`, `state`, `postal`, `country`, `phonenumber`) VALUES '; 
			foreach ($data as $item):
				$q[]	= ' ('	.$db->Quote($item['userid']).', '
								.$db->Quote($item['firstname']).', '
								.$db->Quote($item['lastname']).', '
								.$db->Quote($item['companyname']).', '
								.$db->Quote($item['email']).', '
								.$db->Quote($item['address1']).', '
								.$db->Quote($item['address2']).', '
								.$db->Quote($item['city']).', '
								.$db->Quote($item['state']).', '
								.$db->Quote($item['postcode']).', '
								.$db->Quote($item['country']).', '
								.$db->Quote($item['phonenumber']).')';
			endforeach;
			$query	= $query.implode(',', $q);
			$db->setQuery($query);
			$db->query();
		}
		
		$this->_timeStamp();
		
		// 7:  Return
		return true;
	}
	
	
	/* ----------------------------------------- *\
	 *              SUB FUNCTIONS                *
	\* ----------------------------------------- */
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_timeStamp (private)
	 * Purpose:		This sets the time stamp for latest user sync
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	private function _timeStamp()
	{
		$ps = $this->_getParams();
		$date = & JFactory::getDate();
		$ps[ 'lastsync' ] = $date->toUnix();
		$this->_saveParams( $ps, $ps['id']);
		return;
	}
}