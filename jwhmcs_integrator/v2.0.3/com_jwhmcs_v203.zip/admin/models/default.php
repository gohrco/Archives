<?php
/**
 * Default Model for J!WHMCS Integrator
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since		1.5.1
 */
 
// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelDefault
 * Extends:		JwhmcsModel
 * Purpose:		Used as the default model for user management
 * 
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsModelDefault extends JwhmcsModel
{
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getIconDefinitions
	 * Purpose:		Creates icons for display on the default page
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function getIconDefinitions()
	{
		$ret = array();
		
		$ret[] = $this->_makeIconDefinition( 'j-48-usrmgr.png', JText::_('JWHMCS_ADMIN_BUTTON_USRMGR'), 'usermgr' );
		$ret[] = $this->_makeIconDefinition( 'j-48-grpmgr.png', JText::_('JWHMCS_ADMIN_BUTTON_GRPMGR'), 'grpmgr' );
		$ret[] = $this->_makeIconDefinition( 'j-48-sync.png', JText::_('JWHMCS_ADMIN_BUTTON_WHSYNC'), 'sync' );
		$ret[] = $this->_makeIconDefinition( 'j-48-chinst.png', JText::_('JWHMCS_ADMIN_HEADER_CHINST'), 'check' );
//		$ret[] = $this->_makeIconDefinition( 'j-48-settings.png', JText::_('JWHMCS_ADMIN_BUTTON_SETTINGS'), 'config');
		return $ret;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_makeIconDefinition (private)
	 * Purpose:		Assembles into an array the icons in a standard
	 *				definition.
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function _makeIconDefinition($iconFile, $label, $controller = null, $view = null, $task = null )
	{
		return array(
			'icon'		=> $iconFile,
			'label'		=> $label,
			'controller'=> $controller,
			'view'		=> $view,
			'task'		=> $task
		);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_parseUrls (private)
	 * Purpose:		Create standard parameters to use for system plg
	 * 
	 * As of:		version 1.5.3 (October 2009)
	 * 
	 * Note:		Same as function from authentication plg
	 * Todo:		Create global reference in component to common fnxn
	 * 
	 * Significant Revisions:
	 * 	1)  none
	\* ------------------------------------------------------------ */
	private function _parseUrls(&$params)
	{
		// Parameters to parse for URLs
		$purls = array('jwhmcsjurl', 'jwhmcsjrootimgurl', 'jwhmcsurl', 'jwhmcsjin', 'jwhmcsjout');
		
		foreach ($purls as $purl):
			if (!is_null($params->get( $purl ))):
				$tmp = parse_url($params->get( $purl ));
				// Remove a slash if added to the end of the url
				if ($tmp['path']=='/') unset($tmp['path']);
				// Test for which parameter
				if ($purl == 'jwhmcsjurl') {
					$params->set( 'jwhmcsjurl', $tmp['host'].(isset($tmp['path'])?$tmp['path']:'').(isset($tmp['query'])?$tmp['query']:'').(isset($tmp['fragment'])?$tmp['fragment']:''));
					$params->set( 'jwhmcsjrooturl', $tmp['host']);
				} else {
					$params->set( $purl, $tmp['host'].(isset($tmp['path'])?$tmp['path']:'').(isset($tmp['query'])?$tmp['query']:'').(isset($tmp['fragment'])?$tmp['fragment']:''));
				}
				unset($tmp);
			endif;
		endforeach;
		return $params;
	}
	
	
	private function _setDefinitions()
	{
		$val	= array();
		
		// Array configuration:  [0] name, [1], [2] null, true, false for formatting, [3] definition
		$val['rootvers']		= array('Root File Version',		true,	true,	'This is the version of the WHMCS root file of J!WHMCS Integrator.');
		$val['hookvers']		= array('Hook File Version',		true,	false,	'This is the version of the WHMCS hook file of J!WHMCS Integrator.');
		$val['configdir']		= array('Joomla Directory',		true,	false,	'This setting is located in the jconfig.php file in the root install directory of WHMCS.  It is used to pull the configuration data from Joomla in order to not have to store that data in the Joomla database or in another file.');
		$val['configexists']	= array('Joomla configuration.php Exists',		true,	false,	'Does the Joomla configuration file actually exist in the location specified in the jconfig.php file?');
		$val['configreadable']	= array('Joomla configuration.php Readable',		true,	false,	'Can the Joomla configuration file actually be read?');
		$val['curlinstalled']	= array('PHP Curl Installed',		true,	false,	'This is a quick double check to be sure the curl library is actually installed with the web servers php');
		$val['whmcsvers']		= array('WHMCS Version Installed',		true,	true,	'This is the version of WHMCS that you have running on your server.');
		$val['apiaccess']		= array('WHMCS API Connection',		true,	false,	'The result output of a test to the API interface of WHMCS given the variables you provided.');
		$val['apiurl']			= array('WHMCS API Url',		true,	false,	'The URL used to connect to the WHMCS API interface.');
		$val['apiusername']		= array('WHMCS API Username',		true,	false,	'The username used to connect to the WHMCS API interface.');
		$val['license']			= array('J!WHMCS Integrator License',		true,	false,	'This is the current status of your J!WHMCS Integrator License.');
		$val['licensevalid']	= array('J!WHMCS Integrator Functional',		true,	false,	'If your license is not valid, your J!WHMCS Integrator will not function.');
		$val['jurl']			= array('Joomla Url',		null,	null,	'This is the URL you entered for your Joomla site.');
		$val['jrootimgurl']		= array('Joomla Image Url',		null,	null,	'This is the URL you entered for pointing your images, css and javascript from Joomla to.');
		$val['jssl']			= array('Using SSL on WHMCS',		null,	'You are changing image, css and javascript references in your Joomla template to use SSL for pages that are being rendered for an SSL view.',	'You are not using SSL in WHMCS, or for some reason are not wanting to change the image, css and javascript references to use SSL on those pages.');
		$val['jin']				= array('Login Landing Page',		null, null, 'When your users login, this is the destination URL they will land on if successful.');
		$val['jinssl']			= array('Login Land with SSL',		null, 'When your users login, they are redirected to a page with SSL.', 'When your users login, they are redirected to a standard unsecure page.');
		$val['jout']			= array('Logout Landing Page',		null, null, 'When your users logout, this is the destination URL they will land on if successful.');
		$val['joutssl']			= array('Logout Land with SSL',		null, 'When your users logout, they are redirected to a page with SSL.', 'When your users logout, they are redirected to a standard unsecure page.');
		$val['whmcsurl']		= array('WHMCS Url',		null, null, 'This is the URL you entered for WHMCS.');
		$val['whmcsssl']		= array('WHMCS SSL for Redirect',		null, 'This setting tells JWHMCS to use ssl for redirecting content in WHMCS.', 'This setting would tell JWHMCS to use ssl to redirect to WHMCS pages for security purposes.');
		$val['jquery']			= array('WHMCS Enable jquery.js',		null, 'This is inserting the jquery.js file at the top of your JWHMCS rendered pages.  If you are experiencing errors, try setting this to No.', 'This setting would insert the jquery.js file at the top of your JWHMCS rendered pages.  If you are missing some javascript functionality in your WHMCS pages, try setting this to Yes.');
		$val['jstorename']		= array('Store Joomla Username Method',		null, null, 'This is the manner of storing your new Joomla user in the Joomla user database if they signup through WHMCS.');
		$val['pagein']			= array('Logged In Template Page',		null, null, 'This is the page that is pulled from Joomla to render around your WHMCS content for LOGGED IN users.');
		$val['pageout']			= array('Visitor Template Page',		null, null, 'This is the page that is pulled from Joomla to render around your WHMCS content for visitors.');
		$val['overridecache']	= array('Override Joomla Cache Setting',		null, 'This setting is overriding your cache settings in Joomla and is set NOT to use caching for JWHMCS rendered pages.', 'If you have caching on your Joomla site, but do not wish to use caching for JWHMCS rendered pages, you should set this to Yes.');
		$val['clearcache']		= array('Clear JWHMCS Cache',		null, 'This setting will clear the cache on the next load, and be set back to No once complete.', 'This setting would clear the cache on the next load if set to Yes.');
		
		return $val;
	}
}