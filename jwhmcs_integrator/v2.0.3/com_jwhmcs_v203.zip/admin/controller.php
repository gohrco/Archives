<?php
/**
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: controller.php 121 2010-01-15 16:51:47Z Steven $
 * @since		1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

class JwhmcsController extends JController
{
	
	function display()
	{
		// If the view hasn't been set, set it to default
		if (is_null(JRequest::getVar( 'controller' ))) JRequest::setVar( 'controller', 'default' );
		if (is_null(JRequest::getVar( 'view'))) JRequest::setVar('view', JRequest::getVar( 'controller' ) );
		
		// Call up the parent display task
		parent::display();
	}
	
	
	function cpanel()
	{
		JRequest::setVar( 'controller', 'default' );
		JRequest::setVar( 'view', 'default' );
		
		parent::display();
	}
	
	
	function grpmgr()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=grpmgr', null );
	}
	
	
	function usrmgr()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', null );
	}
}