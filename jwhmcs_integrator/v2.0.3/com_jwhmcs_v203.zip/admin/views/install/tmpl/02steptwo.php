<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');
JHTML::_('behavior.formvalidation');

$data = $this->data;
$j48install = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-48-settings.png';
$j32abort	= JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-abort.png';
$j32forward = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-forward.png';
?>
<script language="javascript">
function myValidate(f) {
	    if (document.formvalidator.isValid(f)) {
                return true; 
        }
        else {
                alert('Some values are not acceptable.  Please retry.');
        }
        return false;
}

function submitbutton(pressbutton) {
	var form = document.adminForm;
	var paths = document.getElementById('paths').value;

	if (pressbutton == 'abort') {
		submitform( pressbutton );
		return;
	}
	
	if (paths == '0') {
		alert('Please enter the path and URL to your WHMCS install and ensure they are found and valid before proceeding.');
		return;
	}
	else {
		if (myValidate(form) == true) {
			submitform( pressbutton );
		}
	}
}
</script>
<style type="text/css" >
input.invalid { color: #fff; background-color: #f00; }
.icon-48-install { background-image: url('<?php echo $j48install; ?>'); }
.icon-32-abort { background-image: url(<?php echo $j32abort; ?>); }
.icon-32-forward { background-image: url(<?php echo $j32forward; ?>); }
td.paramlabel { font-style: italic; color: #333; }
.paramname { font-size: medium; font-weight: bold; }
.paramdesc { font-size: xx-small; clear: both; }
</style>
<form action="index.php" method="post" name="adminForm">
<div id="adminInput">
	<table class="admintable" width="675px" border="0">
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				WHMCS Url
				</div>
				<div class="paramdesc">
				Enter the complete URL to your WHMCS install, including the scheme.  This would be the address that you or your users would enter into the browser to visit your WHMCS site.  For reference, your Joomla site's URL has been entered below.
				</div>
			</td>
			<td rowspan="5" width="220px" valign="top">
				<div id="whmcsstatus">
				&nbsp;
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="text" name="whmcsurl" value="<?php echo $data->url; ?>" size="40" style="font-size: 14px; " onChange="ajaxCheckPath();" id="whmcsurl" />
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				WHMCS Path
				</div>
				<div class="paramdesc">
				Enter the <u>full path</u> to your WHMCS install.  This is the physical directory structure on your server that you have WHMCS installed in.  For reference, the path to your Joomla install has been entered below.
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="text" name="whmcspath" value="<?php echo $data->path; ?>" size="40" style="font-size: 14px; " onChange="ajaxCheckPath();" id="whmcspath" />
			</td>
		</tr>
	</table>
</div>
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="paths" id="paths" value="0" />
<input type="hidden" name="task" value="stepthree" />
<input type="hidden" name="controller" value="install" />
</form>
<script language="javascript">
window.onload = ajaxCheckPath();
</script>