<?php
defined( '_JEXEC' ) or die( 'Restricted access' );

class JwhmcsControllerAjax extends JwhmcsController {
	
	function __construct() {
		parent::__construct();
	}
	
	
	function checkApi()
	{
		global $mainframe;
		$model = $this->getModel( 'ajax' );
		$data = $model->checkApi();
		echo $model->buildResponse($data);
		$mainframe->close();
	}
	
	
	function checkApiu()
	{
		global $mainframe;
		$model = $this->getModel( 'ajax' );
		$data = $model->checkApiu();
		echo $model->buildResponse($data);
		$mainframe->close();
	}
	
	
	function checkPath()
	{
		global $mainframe;
		$model = $this->getModel( 'ajax' );
		$data = $model->checkPath();
		echo $model->buildResponse($data);
		$mainframe->close();
	}
	
	
	function checkValidLicense()
	{
		global $mainframe;
		$model = $this->getModel( 'ajax' );
		$data = $model->checkValidLicense();
		echo $model->buildResponse($data);
		$mainframe->close();
	}
	
	
	function interview()
	{
		global $mainframe;
		$data['step']	= JRequest::getVar( 'step' ) ? JRequest::getVar( 'step' ) : 1;
		$model			= $this->getModel( 'interview' );
		$result			= $model->process($data['step']);
		foreach ($result as $k => $v) $data[$k] = $v;
		echo $model->buildResponse($data);
		$mainframe->close();
		
	}
}
?>