<?php
/**
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: default.php 184 2010-03-18 23:21:35Z Steven $
 * @since		1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/*
 * J!WHMCS Default Controller
 *
 * @package    J!WHMCS Integrator
 */
class JwhmcsControllerDefault extends JController
{
	/*
	 * constructor (registers additional tasks to methods)
	 * @return void
	 */
	function __construct()
	{
		// If the view hasn't been set, set it to default
		if (is_null(JRequest::getVar( 'view'))) JRequest::setVar('view', 'default' );
		
		parent::__construct();
	}
	
	
	function display()
	{
		global $mainframe;
		parent::display();
	}
	
	
	/*
	 * 
	 */
	function cron()
	{
		// 0:  Initialize variables
		global $mainframe;
		$this->addModelPath( JPATH_COMPONENT_ADMINISTRATOR.DS.'models' );
		
		$db		= & JFactory::getDBO();
		$uri	= & JURI::getInstance();
		$params	= & $mainframe->getParams();
		$model	= & $this->getModel( 'sync' );
		
		// 1:  Check for secret value from querystring
		if (!($secret = JRequest::getVar( 'secret' )))
			return false;
		
		// 2:  Compare against parameter secret value (false == fail)
		if ($secret != $params->get( 'jwhmcssecret'))
			return false;
		
		// 3:  Pull action from querystring to run
		if (!($action = JRequest::getVar( 'action' )))
			return false;
		
		// 4:  Run action
		if (! method_exists($model, $action))
			exit('No method');
		
		if (! ($cid = JRequest::getVar( 'cid', array(0), 'post', 'array' )))
			$cid = array();
		
		$model->$action($cid);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		whmcs_login
	 * Purpose:		Receives request to login with token to pull info
	 * 				from database and redirect with new token to J!
	\* ------------------------------------------------------------ */
	function whmcs_login()
	{
		global $mainframe;
		$db	 = &JFactory::getDBO();
		$uri = &JURI::getInstance();
		$params	= & $mainframe->getParams();
		
		// 1: Retrieve variables based on token
		$vars	= $this->_getSess(JRequest::getVar( 'token' ));
		foreach ($vars as $key => $value) $var[$key] = $value;
		
		// 2: Set the return redirect (jwhmcs.php)
		$options = array('remember' => true, 'return' => $var['return'], 'silent' => true);
		$credentials = array('username' => $var['username'], 'password' => $var['passwd']);
		
		/* 2.0.2 */
		foreach ($var as $k => $v) {
			if (in_array($k, array('username', 'passwd', 'password'))) continue;
			JRequest::setVar( $k, $v );
		}
		
		//preform the login action
		$error = $mainframe->login($credentials, $options);
		
		// If we are here then login failed, so determine where to return to
		if ( ! $return = JRequest::getVar( 'return' ) ) {
			$return = 'index.php?option=com_user';
		}
		else {
			// Return exists and is base64 encoded
			$return = trim(base64_decode($return), '?');
			
			$ret = & JURI::getInstance($return);
			$ret->setVar('incorrect', 'true');
			$return = $ret->toString();
		}
		
		$mainframe->redirect( $return );
		
		/*if (JRequest::getVar('whmcs') == '1') {
			
		}
		else {
			$return = base64_decode($return);
		}
		
		if(!JError::isError($error))
		{
			// Redirect if the return url is not registration or login
			if ( ! $return ) {
				$return	= 'index.php?option=com_user';
			}
			else {
				$return = base64_decode($return);
			}
			$mainframe->redirect( $return );
		}
		else
		{
			// Facilitate third party login forms
			if ( ! $return ) {
				$return	= 'index.php?option=com_user&view=login';
			}
			else {
				$return = base64_decode($return);
			}
			
			$mainframe->redirect( $return ); 
		}
		*/
		
		
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	register_save
	 * Purpose:		This function saves the registration info sent via
	 * 				the JWHMCS registration form.  It must first validate
	 * 				and then enter the info into the database.
	 * 
	 * As of:		version 1.5.0
	 * 
	 * Significant Revisions:
	 * 	1)  ver 1.5.3 - Oct 2009
	 * 		* Added reCaptcha
	\* ------------------------------------------------------------ */
	function register_save()
	{
		global $mainframe;
		
		$fromjwhmcs = JRequest::getVar( 'fromjwhmcs' );
		 
		// Check for request forgeries
		if (!$fromjwhmcs) {
			JRequest::checkToken() or jexit( 'Invalid Token' );
		}
		
		// Get required system objects
		$model		= $this->getModel('default');
		$user 		= clone(JFactory::getUser());
		$pathway 	=& $mainframe->getPathway();
		$config		=& JFactory::getConfig();
		$authorize	=& JFactory::getACL();
		$document   =& JFactory::getDocument();
		$params		=& $mainframe->getParams();
		$session	=& JFactory::getSession();
		$this->params	=& $params;
		$jcurl		= & JwhmcsCurl::getInstance();
		$db			= & JFactory::getDBO();
		
		/* reCaptcha if option set */
		if (!$fromjwhmcs)
		{
			// a. check if param selected
			if ($this->params->get( 'jwhmcsrecaptcha' )):
				// b. put together cUrl parameters
				$fields['privatekey']	= $this->params->get( 'jwhmcsrcprikey' );
				$fields['remoteip']		= $_SERVER["REMOTE_ADDR"];
				$fields['challenge']	= JRequest::getVar( 'recaptcha_challenge_field' );
				$fields['response']		= JRequest::getVar( 'recaptcha_response_field' );
				
				// c. save original url and write new url
				$url = 'http://api-verify.recaptcha.net/verify';
				$orig_url = $jcurl->get(CURLOPT_URL);
				$jcurl->set(CURLOPT_URL, $url);
				
				$jcurl->set(CURLOPT_HEADER, false);
				$jcurl->setPostArray($fields);
				$jcurl->setParse(false);
				
				// d. reset for next call
				$jcurl->set(CURLOPT_URL, $orig_url);
				$jcurl->setParse(true);
				
				// e. receive response
				$recaptcha = $jcurl->loadResults();
				$recap = preg_split('/\n/', $recaptcha);
				
				// f. validate setting msg and redirect url if invalid
				if ($recap[0]!= 'true'):
					JError::raiseWarning( 200, JText::_( $recap[1] ));
					JRequest::setVar( 'layout', 'register' );
					parent::display();
					return;
				endif;
			endif;
		}
		
		// If user registration is not allowed, show 403 not authorized.
		$usersConfig = &JComponentHelper::getParams( 'com_users' );
		if ($usersConfig->get('allowUserRegistration') == '0') {
			if ($fromjwhmcs)
				$this->_stop('result=failed;error='.JText::_( 'Access Forbidden'));
			else
				JError::raiseError( 403, JText::_( 'Access Forbidden' ));
			return;
		}
		
		// Initialize new usertype setting
		$newUsertype = $usersConfig->get( 'new_usertype' );
		if (!$newUsertype) {
			$newUsertype = 'Registered';
		}
		
		// Build the user array for binding
		$ubind = $this->_getUserArray();
		
		// Bind the post array to the user object
		if (!$user->bind( $ubind, 'usertype' )) {
			if($fromjwhmcs)
				$this->_stop('result=failed;error='.JText::_( $user->getError()));
			else
				JError::raiseError( 500, $user->getError());
		}
		
		// Set some initial user values
		$user->set('id', 0);
		$user->set('usertype', '');
		$user->set('gid', $authorize->get_group_id( '', $newUsertype, 'ARO' ));
		
		$date =& JFactory::getDate();
		$user->set('registerDate', $date->toMySQL());
		
		// If user activation is turned on, we need to set the activation information
		$useractivation = ( $fromjwhmcs ? $this->params->get( 'jwhmcsjauth' ) : $usersConfig->get( 'useractivation' ) );
		
		// Dont send welcome email by default
		$sendEmail = false;
		if ($useractivation == '1')
		{
			if ($fromjwhmcs!=2)		// If coming from jwhmcs as type 2, we don't want to send activation email
			{
				jimport('joomla.user.helper');
				$user->set('activation', JUtility::getHash( JUserHelper::genRandomPassword()) );
				$user->set('block', '1');
				$sendEmail = true;
			}
		}
		
		// If there was an error with registration, set the message and display form
		if ( !$user->save() )
		{
			if ($fromjwhmcs)
				$this->_stop('result=failed;error='.JText::_( $user->getError()));
			else
				JError::raiseWarning('', JText::_( $user->getError()));
				$this->_register();
			return false;
		}
		
		// Send registration confirmation mail
		if ($fromjwhmcs)
			$password = $ubind['password'];
		else
			$password = JRequest::getString('password', '', 'post', JREQUEST_ALLOWRAW);
		
		$password = preg_replace('/[\x00-\x1F\x7F]/', '', $password); //Disallow control chars in the email
		
		// Send email message if we have activation set
		if ($sendEmail) {
			$this->_sendMail($user, $password);
		}
		
		// Everything went fine, set relevant message depending upon user activation state and display message
		if ( $useractivation == 1 ) {
			$message  = JText::_( 'REG_COMPLETE_ACTIVATE' );
		} else {
			$message = JText::_( 'REG_COMPLETE' );
		}
		
		if ($fromjwhmcs)
			$this->_stop('result=success;userid='.$user->id);
		else
			$this->setRedirect('index.php', $message);
	}
	
	
	/**
	 * Register new user upon signup - from com_users
	 * 
	 * @return	(void)
	 */
	private function _register()
	{
		$usersConfig = &JComponentHelper::getParams( 'com_users' );
		if (!$usersConfig->get( 'allowUserRegistration' )) {
			JError::raiseError( 403, JText::_( 'Access Forbidden' ));
			return;
		}

		$user 	=& JFactory::getUser();

		if ( $user->get('guest')) {
			JRequest::setVar('layout', 'register');
		} else {
			$this->setredirect('index.php?option=com_user&task=edit',JText::_('You are already registered.'));
		}

		parent::display();
	}
	
	
	/**
	 * Send new user email - from com_users
	 * 
	 * @param	(object)	$user
	 * @param	(string)	$password
	 * @return	(void)
	 */
	private function _sendMail(&$user, $password)
	{
		global $mainframe;
		
		$db			= &JFactory::getDBO();
		$name 		= $user->get('name');
		$email 		= $user->get('email');
		$username 	= $user->get('username');
		
		$usersConfig 	= &JComponentHelper::getParams( 'com_users' );
		$sitename 		= $mainframe->getCfg( 'sitename' );
		$useractivation = $usersConfig->get( 'useractivation' );
		$mailfrom 		= $mainframe->getCfg( 'mailfrom' );
		$fromname 		= $mainframe->getCfg( 'fromname' );
		$siteURL		= JURI::base();
		
		$subject 	= sprintf ( JText::_( 'Account details for' ), $name, $sitename);
		$subject 	= html_entity_decode($subject, ENT_QUOTES);
		
		if ( $useractivation == 1 ){
			$message = sprintf ( JText::_( 'SEND_MSG_ACTIVATE' ), $name, $sitename, $siteURL."index.php?option=com_user&task=activate&activation=".$user->get('activation'), $siteURL, $username, $password);
		} else {
			$message = sprintf ( JText::_( 'SEND_MSG' ), $name, $sitename, $siteURL);
		}
		
		$message = html_entity_decode($message, ENT_QUOTES);
		
		//get all super administrator
		$query = 'SELECT name, email, sendEmail' .
				' FROM #__users' .
				' WHERE LOWER( usertype ) = "super administrator"';
		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		
		// Send email to user
		if ( ! $mailfrom  || ! $fromname ) {
			$fromname = $rows[0]->name;
			$mailfrom = $rows[0]->email;
		}
		
		JUtility::sendMail($mailfrom, $fromname, $email, $subject, $message);

		// Send notification to all administrators
		$subject2 = sprintf ( JText::_( 'Account details for' ), $name, $sitename);
		$subject2 = html_entity_decode($subject2, ENT_QUOTES);
		
		// get superadministrators id
		foreach ( $rows as $row )
		{
			if ($row->sendEmail)
			{
				$message2 = sprintf ( JText::_( 'SEND_MSG_ADMIN' ), $row->name, $sitename, $name, $email, $username);
				$message2 = html_entity_decode($message2, ENT_QUOTES);
				JUtility::sendMail($mailfrom, $fromname, $row->email, $subject2, $message2);
			}
		}
	}
	
	
	/**
	 * Create User Array for storing, either from session or from new signup
	 * 
	 * @return	(array)
	 */
	private function _getUserArray()
	{
		if (JRequest::getVar( 'fromjwhmcs' )):
			$ubind	= $this->_getSess(JRequest::getVar( 'token' ));
		else:
			// Because we can't send the entire post value to bind, we have to create new array
			$ubind = array(	'name'		=> $this->_buildName(),
							'username'	=> JRequest::getVar('username'),
							'email'		=> JRequest::getVar('email'),
							'password'	=> JRequest::getVar('password'),
							'password2'	=> JRequest::getVar('password2'),
							'task'		=> JRequest::getVar('task'),
							'id'		=> JRequest::getVar('id'),
							'gid'		=> JRequest::getVar('gid'));
		endif;
		return $ubind;
	}
	
	
	private function _getSess($token)
	{
		$db =& JFactory::getDBO();
		$query = 'SELECT `value` FROM #__jwhmcs_sess WHERE token="'.$token.'"';
		$db->setQuery($query);
		$result = $db->loadResult();
		
		$tmp = preg_split('/\n/', $result);
		foreach ($tmp as $t):
			$var = explode('=', $t);
			$k = $var[0];
			unset($var[0]);
			$ubind[$k] = implode("=", $var);
			unset($var, $k);
		endforeach;
		$query = 'DELETE FROM #__jwhmcs_sess WHERE token="'.$token.'"';
		$db->setQuery($query);
		$res = $db->query();
		
		return $ubind;
	}
	
	
	/**
	 * Function to build the name for Joomla to store based on parameter set
	 * 
	 * @return	(string)
	 */
	private function _buildName()
	{
		// Name Compilation for Joomla based on setting in component
		$coname	= (JRequest::getVar('companyname')?' ('.JRequest::getVar('companyname').')':'');
		switch ($this->params->get('jwhmcsjstoreus')):
		case 3:
			$name = $coname;
		case 1:
			$name = JRequest::getVar('firstname').' '.JRequest::getVar('lastname').$name;
			break;
		case 4:
			$name = $coname;
		case 2:
			$name = JRequest::getVar('lastname').', '.JRequest::getVar('firstname').$name;
			break;
		endswitch;
		return $name;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_stop (private)
	 * Purpose:		Halts execution of Joomla with message
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	private function _stop($msg = '')
	{
		global $mainframe;
		echo $msg;
		$mainframe->close();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_stringBreak (private)
	 * Purpose:		Accepts query string and returns array
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ 
	private function _stringBreak($return)
	{
		$vals = explode("&", $return);
		
		foreach ($vals as $val) {
			$tmp = explode("=", $val);
			$k		= $tmp[0];
			unset($tmp[0]);
			$array[$k] = implode("=", $tmp);
			unset($tmp, $k);
		}
		
		return $array;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_stringBuild (private)
	 * Purpose:		Accepts array and exceptions and builds query string
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ *
	private function _stringBuild($array, $exceptions = array())
	{
		foreach($array as $k => $v) {
			if (in_array($k, $exceptions)) continue;
			$val[] = $k.'='.$v;
		}
		return implode("&", $val);
	}*/
}