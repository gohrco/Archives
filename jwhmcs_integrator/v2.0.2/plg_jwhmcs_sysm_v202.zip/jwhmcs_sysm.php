<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: jwhmcs_sysm.php 171 2010-03-16 16:00:50Z Steven $
 * @since		1.5.0
 * 
 * @desc		This plugin redirects links to option=com_user&task=register to
 * 				the J!WHMCS component (com_jwhmcs) user registration to request
 * 				information from end customer for WHMCS.
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.plugin.plugin');

/**
 * System Plugin
 *
 * @package		J!WHMCS Integrator 
 * @since 		1.5.0
 */
class plgSystemJwhmcs_sysm extends JPlugin {

	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param object $subject The object to observe
	 * @param 	array  $config  An array that holds the plugin configuration
	 * @since 1.5
	 */
	function plgSystemJwhmcs_sysm(& $subject, $config)
	{
		parent::__construct($subject, $config);
		
		// Retrieve the component and plugin parameters and set them
		$component	  = JComponentHelper::getComponent( 'com_jwhmcs' );
  		$params = new JParameter( $component->params );
  		$this->params->merge($params);
	}
	
	
	function onAfterInitialise()
	{
		
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	onAfterRender (private)
	 * Purpose:		After rendering site, redirect user if trying to
	 * 				visit com_user based on plugin parameters. 
	 * 
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 * 	1)  ver 1.5.3 - Oct 2009
	 * 			Added ability to redirect to WHMCS user reg or edit page
	\* ------------------------------------------------------------ */
	function onAfterRender()
	{
		global $mainframe;
		$user 	= &JFactory::getUser();
		$option =  JRequest::getCmd('option', '', 'default', 'string');		
		$task   =  JRequest::getCmd('task', '', 'default',   'string');
		$view	=  JRequest::getVar('view', '', 'default',   'string');
		
		if( $mainframe->isAdmin() )
			return;
		
		if ( $option=='com_user' && ($task=='register' || $view=='register') ):
			// load J!WHMCS Registration page
			if ( $user->get('guest') ):
				if ($this->params->get( 'jwhmcsredirwhmcs' )==1):
					$newlink = 'http'.($this->params->get( 'jwhmcsssl' )==1?'s':'').'://'.$this->params->get( 'jwhmcsurl' ).'/register.php';
				else:
					// force Itemid
					$menuitem	= ($this->params->get( 'menuid' )?'&Itemid='.$this->params->get( 'menuid' ):'');
					$newlink = JRoute::_('index.php?option=com_jwhmcs&layout=register'.$menuitem, false);
				endif;
				$mainframe->redirect($newlink);
			endif;
		endif;
		
		if ( $option=='com_user' && ($task=='edit' || $view=='edit') ):
			// load J!WHMCS Edit page
			if (! $user->get('guest') ):
				if ($this->params->get( 'jwhmcsredirwhmcs' )==1):
					$newlink = 'http'.($this->params->get( 'jwhmcsssl' )==1?'s':'').'://'.$this->params->get( 'jwhmcsurl' ).'/clientarea.php?action=details';
				else:
					// force Itemid
					$menuitem	= ($this->params->get( 'menuid' )?'&Itemid='.$this->params->get( 'menuid' ):'');
					$newlink	= JRoute::_('index.php?option=com_jwhmcs&layout=edit'.$menuitem, false);
				endif;
				$mainframe->redirect($newlink);
			endif;
		endif;
		return;
	}
}