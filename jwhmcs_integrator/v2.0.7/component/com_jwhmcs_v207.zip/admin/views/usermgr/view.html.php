<?php
/**
 * Default View for J!WHMCS Integrator
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since		1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

/**
 * Default View
 *
 * @package    J!WHMCS Integrator
 */
class JwhmcsViewUsermgr extends JView
{
	/**
	 * display method of Hello view
	 * @return void
	 **/
	function display($tpl = null)
	{
		$model	= & $this->getModel('usermgr');
		$params	= &JComponentHelper::getParams( 'com_jwhmcs' );
		$user	= &JFactory::getUser();
		$task	= JRequest::getVar( 'task' );
		$data	= $model->getData($params, $task);
		
		switch ($task):
		case 'joomadd':
		case 'joomedit':
			$isNew		= (isset($data->id)?($data->id < 1?true:false):true);
			$text		= $isNew ? JText::_( 'JWHMCS_ADMIN_TITLE_UMJADD' ) : JText::_( 'JWHMCS_ADMIN_TITLE_UMJEDIT' );
			
			JToolBarHelper::title(   JText::_( 'JWHMCS_ADMIN_TITLE_USRMGR' ).': <small><small>[ ' . $text.' ]</small></small>', 'usrmgr.png' );
			JToolBarHelper::back();
			if ($isNew)
				JToolBarHelper::save('joomaddsave', 'Save' );
			else
				JToolBarHelper::save('joomeditsave', 'Save' );
			
			if ($isNew)
				JToolBarHelper::cancel();
			else
				JToolBarHelper::cancel( 'cancel', 'Close' );
			
			JToolBarHelper :: help('jwhmcs.usermgr.joomla', true);
			$this->assignRef('data',	$data);
			break;
		case 'whmcsadd':
		case 'whmcsedit':
			$field	= array();
			$field['country'] = $this->_buildCountry();
			
			$isNew		= (isset($data->id)?($data->id < 1?true:false):true);
			$text		= $isNew ? JText::_( 'JWHMCS_ADMIN_TITLE_UMWADD' ) : JText::_( 'JWHMCS_ADMIN_TITLE_UMWEDIT' );
			
			JToolBarHelper::title(   JText::_( 'JWHMCS_ADMIN_TITLE_USRMGR' ).': <small><small>[ ' . $text.' ]</small></small>', 'usrmgr.png' );
			JToolBarHelper::back();
			if ($isNew)
				JToolBarHelper::save('whmcsaddsave', 'Save' );
			else
				JToolBarHelper::save('whmcseditsave', 'Save' );
			
			if ($isNew)
				JToolBarHelper::cancel();
			else
				JToolBarHelper::cancel( 'cancel', 'Close' );
			
			JToolBarHelper :: help('jwhmcs.usermgr.whmcs', true);
			$this->assignRef('data',	$data);
			$this->assignRef('field',	$field);
			break;
		case 'save':
		case 'sync':
		default:
			
			JToolBarHelper :: title( JText::_( 'JWHMCS_ADMIN_TITLE_USRMGR' ), 'usrmgr.png' );
			JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
			JToolBarHelper :: custom( 'grpmgr', 'grpmgr.png', 'grpmgr.png', JText::_( 'JWHMCS_ADMIN_BUTTON_GRPMGR' ), false, false );
			JToolBarHelper :: custom( 'matchAll', 'matchall.png', 'matchall.png', JText::_( 'JWHMCS_ADMIN_BUTTON_MATCHALL' ), false, false );
			JToolBarHelper :: divider();
			JToolBarHelper :: help('jwhmcs.usermgr', true);
			// Available Sort Fields
			$sort	= array('joomla' => array(
								'jid'		=> JText::_( 'JWHMCS_ADMIN_LABEL_ID' ),
								'jname'		=> JText::_( 'JWHMCS_ADMIN_LABEL_NAME' ),
								'jusername'	=> JText::_( 'JWHMCS_ADMIN_LABEL_USRNAME' ),
								'jblock'	=> JText::_( 'JWHMCS_ADMIN_LABEL_ENABLED' ),
								'jgroupname'=> JText::_( 'JWHMCS_ADMIN_LABEL_GROUP' )),
							'whmcs' => array(
								'wid'		=> JText::_( 'JWHMCS_ADMIN_LABEL_ID' ),
								'wfname'	=> JText::_( 'JWHMCS_ADMIN_LABEL_WFNAME' ),
								'wlname'	=> JText::_( 'JWHMCS_ADMIN_LABEL_WLNAME' ),
								'wcname'	=> JText::_( 'JWHMCS_ADMIN_LABEL_WCNAME2' ),
								'wcity'		=> JText::_( 'JWHMCS_ADMIN_LABEL_WCITY' ),
								'wstate'	=> JText::_( 'JWHMCS_ADMIN_LABEL_WSTATE' ),
								'wcountry'	=> JText::_( 'JWHMCS_ADMIN_LABEL_WPOSTAL' )));
			
			// Retrieve sort values from JRequest, set defaults otherwise
			$sortby		= (JRequest::getVar( 'sortby' ) ? JRequest::getVar( 'sortby' ) : 'wlname' );
			$sortord	= (JRequest::getVar( 'sortord' ) ? JRequest::getVar( 'sortord' ) : 1 );
			$sortjusers	= (JRequest::getVar( 'filter_jusers' ) ? JRequest::getVar( 'filter_jusers' ) : 0 );
			$sortwusers	= (JRequest::getVar( 'filter_wusers' ) ? JRequest::getVar( 'filter_wusers' ) : 0 );
			$sortmatch	= (JRequest::getVar( 'filter_matches' ) ? JRequest::getVar( 'filter_matches' ) : 0 );
			
			$baselnk = 'index.php?option=com_jwhmcs&controller=usermgr&filter_jusers='.$sortjusers.'&filter_wusers='.$sortwusers.'&filter_matches='.$sortmatch;
			
			foreach ($sort['joomla'] as $key => $value):
				if ( $sortby == $key )
					$thissort = ($sortord==1?-1:1);
				else
					$thissort = $sortord;
				$jsort[] = '<span class="jwhmcs-hdrsort"><a href="'.JRoute::_($baselnk.'&sortord='.$thissort.'&sortby='.$key).'">'.$value.'</a></span>';
			endforeach;
			foreach ($sort['whmcs'] as $key => $value):
				if ( $sortby == $key )
					$thissort = ($sortord==1?-1:1);
				else
					$thissort = $sortord;
				$wsort[] = '<span class="jwhmcs-hdrsort"><a href="'.JRoute::_($baselnk.'&sortord='.$thissort.'&sortby='.$key).'">'.$value.'</a></span>';
			endforeach;
			unset($sort['joomla'],$sort['whmcs']);
			$sort['joomla'] = implode(' | ', $jsort);
			$sort['whmcs']	= implode(' | ', $wsort);
			$sort['sortby']	= $sortby;
			$sort['sortord']= $sortord;
			$sort['user_search'] = $model->getState('user_search');
			$sort['jusers']	= (JRequest::getVar('filter_jusers')?JRequest::getVar('filter_jusers'):'0');
			$sort['matches']= (JRequest::getVar('filter_matches')?JRequest::getVar('filter_matches'):0);
			$sort['wusers']	= (JRequest::getVar('filter_wusers')?JRequest::getVar('filter_wusers'):0);
			
			// Assign template variables
			$this->assignRef('sort',		$sort);
			$this->assignRef('user',		$user);
			$this->assignRef('data',		$data->data);
			$this->assignRef('pagination',	$data->pagination);
		endswitch;
		parent::display($tpl);
	}
	
	
	/**
	 * Create an array of countries to return to calling function
	 * 
	 * @return	(array)
	 */
	private function _buildCountry() {
		$country = array('AF' => 'Afghanistan', 'AX' => 'Aland Islands', 'AL' => 'Albania', 'DZ' => 'Algeria', 'AS' => 'American Samoa', 'AD' => 'Andorra', 'AO' => 'Angola', 'AI' => 'Anguilla', 'AQ' => 'Antarctica', 'AG' => 'Antigua And Barbuda', 'AR' => 'Argentina', 'AM' => 'Armenia', 'AW' => 'Aruba', 'AU' => 'Australia', 'AT' => 'Austria', 'AZ' => 'Azerbaijan', 'BS' => 'Bahamas', 'BH' => 'Bahrain', 'BD' => 'Bangladesh', 'BB' => 'Barbados', 'BY' => 'Belarus', 'BE' => 'Belgium', 'BZ' => 'Belize', 'BJ' => 'Benin', 'BM' => 'Bermuda', 'BT' => 'Bhutan', 'BO' => 'Bolivia', 'BA' => 'Bosnia And Herzegovina', 'BW' => 'Botswana', 'BV' => 'Bouvet Island', 'BR' => 'Brazil', 'IO' => 'British Indian Ocean Territory', 'BN' => 'Brunei Darussalam', 'BG' => 'Bulgaria', 'BF' => 'Burkina Faso', 'BI' => 'Burundi', 'KH' => 'Cambodia', 'CM' => 'Cameroon', 'CA' => 'Canada', 'CV' => 'Cape Verde', 'KY' => 'Cayman Islands', 'CF' => 'Central African Republic', 'TD' => 'Chad', 'CL' => 'Chile', 'CN' => 'China', 'CX' => 'Christmas Island', 'CC' => 'Cocos (Keeling) Islands', 'CO' => 'Colombia', 'KM' => 'Comoros', 'CG' => 'Congo', 'CD' => 'Congo, Democratic Republic', 'CK' => 'Cook Islands', 'CR' => 'Costa Rica', 'CI' => 'Cote D\'Ivoire', 'HR' => 'Croatia', 'CU' => 'Cuba', 'CY' => 'Cyprus', 'CZ' => 'Czech Republic', 'DK' => 'Denmark', 'DJ' => 'Djibouti', 'DM' => 'Dominica', 'DO' => 'Dominican Republic', 'EC' => 'Ecuador', 'EG' => 'Egypt', 'SV' => 'El Salvador', 'GQ' => 'Equatorial Guinea', 'ER' => 'Eritrea', 'EE' => 'Estonia', 'ET' => 'Ethiopia', 'FK' => 'Falkland Islands (Malvinas)', 'FO' => 'Faroe Islands', 'FJ' => 'Fiji', 'FI' => 'Finland', 'FR' => 'France', 'GF' => 'French Guiana', 'PF' => 'French Polynesia', 'TF' => 'French Southern Territories', 'GA' => 'Gabon', 'GM' => 'Gambia', 'GE' => 'Georgia', 'DE' => 'Germany', 'GH' => 'Ghana', 'GI' => 'Gibraltar', 'GR' => 'Greece', 'GL' => 'Greenland', 'GD' => 'Grenada', 'GP' => 'Guadeloupe', 'GU' => 'Guam', 'GT' => 'Guatemala', 'GG' => 'Guernsey', 'GN' => 'Guinea', 'GW' => 'Guinea-Bissau', 'GY' => 'Guyana', 'HT' => 'Haiti', 'HM' => 'Heard Island & Mcdonald Islands', 'VA' => 'Holy See (Vatican City State)', 'HN' => 'Honduras', 'HK' => 'Hong Kong', 'HU' => 'Hungary', 'IS' => 'Iceland', 'IN' => 'India', 'ID' => 'Indonesia', 'IR' => 'Iran, Islamic Republic Of', 'IQ' => 'Iraq', 'IE' => 'Ireland', 'IM' => 'Isle Of Man', 'IL' => 'Israel', 'IT' => 'Italy', 'JM' => 'Jamaica', 'JP' => 'Japan', 'JE' => 'Jersey', 'JO' => 'Jordan', 'KZ' => 'Kazakhstan', 'KE' => 'Kenya', 'KI' => 'Kiribati', 'KR' => 'Korea', 'KW' => 'Kuwait', 'KG' => 'Kyrgyzstan', 'LA' => 'Lao People\'s Democratic Republic', 'LV' => 'Latvia', 'LB' => 'Lebanon', 'LS' => 'Lesotho', 'LR' => 'Liberia', 'LY' => 'Libyan Arab Jamahiriya', 'LI' => 'Liechtenstein', 'LT' => 'Lithuania', 'LU' => 'Luxembourg', 'MO' => 'Macao', 'MK' => 'Macedonia', 'MG' => 'Madagascar', 'MW' => 'Malawi', 'MY' => 'Malaysia', 'MV' => 'Maldives', 'ML' => 'Mali', 'MT' => 'Malta', 'MH' => 'Marshall Islands', 'MQ' => 'Martinique', 'MR' => 'Mauritania', 'MU' => 'Mauritius', 'YT' => 'Mayotte', 'MX' => 'Mexico', 'FM' => 'Micronesia, Federated States Of', 'MD' => 'Moldova', 'MC' => 'Monaco', 'MN' => 'Mongolia', 'ME' => 'Montenegro', 'MS' => 'Montserrat', 'MA' => 'Morocco', 'MZ' => 'Mozambique', 'MM' => 'Myanmar', 'NA' => 'Namibia', 'NR' => 'Nauru', 'NP' => 'Nepal', 'NL' => 'Netherlands', 'AN' => 'Netherlands Antilles', 'NC' => 'New Caledonia', 'NZ' => 'New Zealand', 'NI' => 'Nicaragua', 'NE' => 'Niger', 'NG' => 'Nigeria', 'NU' => 'Niue', 'NF' => 'Norfolk Island', 'MP' => 'Northern Mariana Islands', 'NO' => 'Norway', 'OM' => 'Oman', 'PK' => 'Pakistan', 'PW' => 'Palau', 'PS' => 'Palestinian Territory, Occupied', 'PA' => 'Panama', 'PG' => 'Papua New Guinea', 'PY' => 'Paraguay', 'PE' => 'Peru', 'PH' => 'Philippines', 'PN' => 'Pitcairn', 'PL' => 'Poland', 'PT' => 'Portugal', 'PR' => 'Puerto Rico', 'QA' => 'Qatar', 'RE' => 'Reunion', 'RO' => 'Romania', 'RU' => 'Russian Federation', 'RW' => 'Rwanda', 'BL' => 'Saint Barthelemy', 'SH' => 'Saint Helena', 'KN' => 'Saint Kitts And Nevis', 'LC' => 'Saint Lucia', 'MF' => 'Saint Martin', 'PM' => 'Saint Pierre And Miquelon', 'VC' => 'Saint Vincent And Grenadines', 'WS' => 'Samoa', 'SM' => 'San Marino', 'ST' => 'Sao Tome And Principe', 'SA' => 'Saudi Arabia', 'SN' => 'Senegal', 'RS' => 'Serbia', 'SC' => 'Seychelles', 'SL' => 'Sierra Leone', 'SG' => 'Singapore', 'SK' => 'Slovakia', 'SI' => 'Slovenia', 'SB' => 'Solomon Islands', 'SO' => 'Somalia', 'ZA' => 'South Africa', 'GS' => 'South Georgia And Sandwich Isl.', 'ES' => 'Spain', 'LK' => 'Sri Lanka', 'SD' => 'Sudan', 'SR' => 'Suriname', 'SJ' => 'Svalbard And Jan Mayen', 'SZ' => 'Swaziland', 'SE' => 'Sweden', 'CH' => 'Switzerland', 'SY' => 'Syrian Arab Republic', 'TW' => 'Taiwan', 'TJ' => 'Tajikistan', 'TZ' => 'Tanzania', 'TH' => 'Thailand', 'TL' => 'Timor-Leste', 'TG' => 'Togo', 'TK' => 'Tokelau', 'TO' => 'Tonga', 'TT' => 'Trinidad And Tobago', 'TN' => 'Tunisia', 'TR' => 'Turkey', 'TM' => 'Turkmenistan', 'TC' => 'Turks And Caicos Islands', 'TV' => 'Tuvalu', 'UG' => 'Uganda', 'UA' => 'Ukraine', 'AE' => 'United Arab Emirates', 'GB' => 'United Kingdom', 'US' => 'United States', 'UM' => 'United States Outlying Islands', 'UY' => 'Uruguay', 'UZ' => 'Uzbekistan', 'VU' => 'Vanuatu', 'VE' => 'Venezuela', 'VN' => 'Viet Nam', 'VG' => 'Virgin Islands, British', 'VI' => 'Virgin Islands, U.S.', 'WF' => 'Wallis And Futuna', 'EH' => 'Western Sahara', 'YE' => 'Yemen', 'ZM' => 'Zambia', 'ZW' => 'Zimbabwe');
		return $country;
	}
}