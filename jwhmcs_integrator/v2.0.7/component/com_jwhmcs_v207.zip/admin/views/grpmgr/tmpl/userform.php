<?php defined('_JEXEC') or die('Restricted access');

jimport('joomla.html.pane');
JHTML::_('behavior.mootools');
JHTML::_('behavior.tooltip');
JHTML::_('behavior.formvalidation');

$j48grpmgr = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-48-grpmgr.png';
?>
<style type="text/css" >
.jwhmcs-fieldwrap {
	font-size: 8px;
	font-style: italic;
	color: #666;
	float: left;
	text-align: center;
	margin: 2px 3px 0px;
	padding: 0px;
}
input.invalid {
	color: #fff;
	background-color: #f00; 
}
.icon-48-grpmgr {
	background-image: url(<?php echo $j48grpmgr; ?>);	
}
</style>

<form id="adminForm" name="adminForm" method="post" class="form-validate">
<div class="col100">
<table width="100%" class="admintable">
	<tr>
		<td width="100" align="right" class="key">
			<label for="name">
				<?php
				$title = JText::_( 'JWHMCS_ADMIN_LABEL_JUSER' );
				echo JHTML::_('tooltip', JText::_( 'JWHMCS_ADMIN_TIP_GMUSRADD' ), $title, null, $title); ?>
			</label>
		</td>
		<td>
			<div class="jwhmcs-fieldwrap">
				<?php echo $this->data->joomlaid; ?><br />
				<?php echo JText::_( 'JWHMCS_ADMIN_LABEL_GMUAN' ); ?>
			</div>
		</td>
	</tr>
</table>
</div>

<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="controller" value="grpmgr" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="groupid" value="<?php echo $this->data->groupid; ?>" />
<input type="hidden" name="id" value="<?php echo $this->data->id; ?>" />
</form>

<script language="javascript">
function myValidate(f) {
        if (document.formvalidator.isValid(f)) {
                return true; 
        }
        else {
                alert('<?php echo JText::_( 'JWHMCS_MSG_INVALID' ); ?>');
        }
        return false;
}

function submitbutton(pressbutton) {
	var form = document.adminForm;

	if (pressbutton == 'cancel') {
		submitform( pressbutton );
		return;
	}

	if (myValidate(form) == true) {
		submitform( pressbutton );
	}
	
}
</script>