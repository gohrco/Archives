<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: controller.php 131 2010-12-22 14:21:11Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

class JwhmcsController extends JController
{
	
	function display()
	{
		// If the view hasn't been set, set it to default
		if (is_null(JRequest::getVar( 'controller' ))) JRequest::setVar( 'controller', 'default' );
		if (is_null(JRequest::getVar( 'view'))) JRequest::setVar('view', JRequest::getVar( 'controller' ) );
		
		// Call up the parent display task
		parent::display();
	}
	
	
	function cpanel()
	{
		JRequest::setVar( 'controller', 'default' );
		JRequest::setVar( 'view', 'default' );
		
		parent::display();
	}
	
	
	function helppage()
	{
		JRequest::setVar( 'controller', 'helppage' );
		JRequest::setVar( 'view', 'helppage' );
		
		parent::display();
	}
	
	
	function grpmgr()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=grpmgr', null );
	}
	
	
	function usrmgr()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', null );
	}
}