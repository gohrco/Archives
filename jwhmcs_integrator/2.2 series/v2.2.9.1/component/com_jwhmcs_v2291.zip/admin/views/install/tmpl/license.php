<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');
JHTML::_('behavior.formvalidation');

$data = $this->data;
$j48license = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-48-license.png';
$j32helppage = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-helppage.png';
$j32licreload = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-licreload.png';

?>

<style type="text/css">

input.invalid { color: #fff; background-color: #f00; }
.icon-48-license { background-image: url('<?php echo $j48license; ?>'); }
.icon-32-licreload { background-image: url('<?php echo $j32licreload; ?>'); }
.icon-32-helppage { background-image: url('<?php echo $j32helppage; ?>'); }
td.paramlabel { font-style: italic; color: #333; }
.paramname { font-size: medium; font-weight: bold; }
.paramdesc { font-size: xx-small; clear: both; }
</style>
<form action="index.php" method="post" name="adminForm">
<div id="adminInput">
	<table class="admintable" width="675px">
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				Product License
				</div>
				<div class="paramdesc">
				Enter the product license you received when you purchased J!WHMCS Integrator.
				</div>
			</td>
			<td rowspan="2" width="220px" valign="top">
				<div id="whmcsstatus">
				&nbsp;
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="text" name="licensekey" value="<?php echo $data->license; ?>" size="40" style="font-size: 14px; " onChange="ajaxLicenseCheck();" id="licensekey" />
			</td>
		</tr>
	</table>
</div>
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="task" value="licenseAccept" />
<input type="hidden" name="license" id="license" value="0" />
<input type="hidden" name="controller" value="install" />
</form>
<script language="javascript">
window.onload = ajaxLicenseCheck();
</script>