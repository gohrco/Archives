<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: class.curl.php 212 2011-05-19 17:07:39Z steven_gohigher $
 * @since      1.5.3
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once ('class.xmlparser.php');
require_once ('class.params.php');

class JwhmcsCurl
{ 
	
	/**
	 * @var instance to contain object when created
	 */
	private static $instance = null;
	
    /* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Called upon initialization of object class
	 * As of:		version 1.5.3
	 * 
	 * Significant Revisions:
	 * 	2.1.0 (Apr 2010)
	 * 		* Modified references to parameters
	\* ------------------------------------------------------------ */
	private function __construct()
	{
		$params		= & JwhmcsParams::getInstance();
		
		$url		= $params->get( 'ApiUrl' ).'/includes/api.php';
		$username	= trim($params->get( 'ApiUsername' ));
		$password	= md5(trim($params->get( 'ApiPassword' )));
		
		$curlfollow	= ((ini_get('open_basedir') == '' && ini_get('safe_mode' == 'Off')) ? true : false );
		
		$this->xml	= & JwhmcsXml::getInstance( array( "force" => true ) );
		$this->parse = true;
		
		$this->root	= 'whmcsapi';
		$this->mainflds	= array(	'username'		=> $username,
									'password'		=> $password,
									'jwhmcs'		=> 1,
									'responsetype'	=> 'xml');
		
		if ( trim( $params->get( 'ApiAccesskey' ) ) ) {
			$this->mainflds['accesskey'] = trim( $params->get( 'ApiAccesskey' ) );
		}
		
		$this->setopt	= array(	CURLOPT_URL => $url,
									CURLOPT_RETURNTRANSFER => true,
									CURLOPT_USERAGENT => ( isset( $_SERVER['HTTP_USER_AGENT'] ) ? $_SERVER['HTTP_USER_AGENT'] : "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)" ),
									CURLOPT_MAXREDIRS => 5,
									CURLOPT_FOLLOWLOCATION => $curlfollow,
									CURLOPT_HEADER => true,
									CURLOPT_HTTPHEADER, array('Expect:'), 
									CURLOPT_SSL_VERIFYHOST => false,
									CURLOPT_SSL_VERIFYPEER => false);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getInstance
	 * Purpose:		Called to create an instance of the class
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public static function getInstance( $options = false )
	{
		// Legacy code support
		$force	= ( is_bool( $options ) ? $options : ( isset( $options["force"] ) ? $options["force"] : false ) );
		
		if ((self::$instance == null) || ($force === true)) {
			self::$instance = new self;
		}
		
		if ( is_array( $options ) ) {
			self::$instance->simple( ( isset( $options['simple'] ) ? $options['simple'] : false ) );
		}
		
		return self::$instance;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setRoot
	 * Purpose:		Sets the root xml for determining response
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function setRoot($root)
	{
		$this->root	= strtolower($root);
		$this->xml->root = strtolower($root);
	}
	
	
    /* ------------------------------------------------------------ *\
	 * Method:		set
	 * Purpose:		Sets a single option for the curl handler
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function set($option, $value)
	{
		$this->setopt[$option] = $value;
	} 
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		get
	 * Purpose:		Gets a single option for the curl handler
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function get($option)
	{
		if (!array_key_exists($option, $this->setopt))
			return false;
		else
			return $this->setopt[$option];
	}
	
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setParse
	 * Purpose:		Turns data parsing on or off (t / f) 
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function setParse($data = true)
	{
		$this->parse = $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setOptions
	 * Purpose:		Sets an array of options for the curl handler
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function setOptions($options)
	{
		foreach ($options as $key => $value)
		{
			$this->set($key, $value);
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setPost
	 * Purpose:		Sets a post field to be posted through curl
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function setPost($field, $value)
	{
		$this->fields[$field] = $value;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setPostArray
	 * Purpose:		Sets an array of post fields to be posted through curl
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function setPostArray($fields)
	{
		foreach ($fields as $key => $value)
		{
			$this->setPost($key, $value);
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setAction
	 * Purpose:		sets the action parameters so result can be loaded
	 * As of:		version 1.5.3
	 * 
	 * Significant Revisions:
	 * 	2.0 (Jan 2010)
	 *  	+ Added fix for header option
	\* ------------------------------------------------------------ */
	public function setAction($action, array $fields)
	{
		$this->_resetFields();
		
		// Since this is called to set a WHMCS API Action call, we need to unset the header option
		$this->setopt[CURLOPT_HEADER] = false;
		
		$this->setPost('action', $action);
		$this->setPostArray($fields);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setCall
	 * Purpose:		Sets a generic set of fields to the object so the
	 * 					result can be loaded for a generic curl call
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function setCall($fields = null)
	{
		$this->_resetFields(true);
		if (!is_null($fields))
			$this->setPostArray($fields);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		loadResults
	 * Purpose:		Makes a call to the curl handler setting the post fields
	 * 					and returns an array of values
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function loadResults()
	{
		// Set the options
		if (isset($this->fields)) {
			$this->setopt[CURLOPT_POSTFIELDS]	= $this->fields;
		}
		
		// Make the curl call
		$data	= $this->_cUrl();
		
		// Check response to see if we got back a legit code (200-206)
		if (($this->info['http_code'] < 300) && ($this->info['http_code'] >= 200)) {
			if (!$this->parse)
			{
				return $data;
			}
			
			// Check to see what response we got back (true = xml)
			if ($this->_checkResponse($data))
			{
				$this->xml->setData($data);
				$data = $this->xml->loadResults();
			}
			else
			{
				$this->xml->setPairs($data);
				$data = $this->xml->loadPairs();
			}
		}
		else 
		{
			return false;
		}
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		loadResult
	 * Purpose:		Wrapper to make a call to the curl handler and return
	 * 					only a single array of values
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function loadResult()
	{
		// Retrieve data
		$data	= $this->loadResults();
		
		// Error trapping - if false, return false;
		if (!$data)
		{
			return false;
		}
		else
		{
			if (! is_array( $data ) ) return $data;
			foreach ($data as $d)
			{
				return $d;
			}
		}
	}
	
	
	/**
	 * Calls xml object to use simple xml method
	 * @access		public
	 * @version		2.2.9.1
	 * @param		boolean		- $setting: optionally set true / false on the simple setting - leaving null toggles setting
	 * 
	 * @since		2.25 (May 2011)
	 */
	public function simple( $setting = null )
	{
		if ( $setting === null ) {
			$prev = $this->xml->get( "simple", false, false );
			$this->xml->set( "simple", ( $prev === false ? true : false ) );
		} else {
			$this->xml->set( "simple", $setting );
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_cUrl
	 * Purpose:		curl handler
	 * As of:		version 1.5.3
	 * 
	 * Significant Revisions:
	 *  2.1.0 (May 2010)
	 *  	A 303 header check for redirection (Joomla 1.5.17 issue) 
	 * 	2.0 (Jan 2010)
	 *  	+ Added regressive check in event of 301/302 and no follow
	\* ------------------------------------------------------------ */
	private function _cUrl($useopt = false)
	{
		$ch = curl_init();
		if ($useopt) {		// Check for regressive run
			curl_setopt_array($ch, $useopt);
			
		} else { 			// First time through
			curl_setopt_array($ch, $this->setopt);
			$curlopt = $this->setopt;
		}
		ob_start();
			$data = curl_exec($ch);
			$info	= curl_getinfo($ch);
			$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		ob_end_clean();
		curl_close($ch);
		
		if ($http_code == 301 || $http_code == 302 || $http_code == 303 ) { // Check for 301/302 return
			if ($url = $this->_findRedirect($data)) { // Find the redirect url
				$curlopt[CURLOPT_URL] = $url;		  // Set the redirect url
				$data = $this->_cUrl($curlopt);		  // Make another curl to url
			}
		} else {
			$this->info = $info;
		}
		
		if ($useopt)
			return $data;
		else {
			$hdr	= null;
			$body	= null;
			if ($this->setopt[CURLOPT_HEADER]) {
				list($hdr,$body) = explode("\r\n\r\n", $data, 2);
			}
			else {
				$body = $data;
			}
			return $body;
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_findRedirect
	 * Purpose:		Part of regressive check to find redirected urls
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	private function _findRedirect($data)
	{
		list($header) = explode("\r\n\r\n", $data, 2);
		$matches = array();
		preg_match('/(Location:|URI:)(.*?)\n/', $header, $matches);
		$url = trim(array_pop($matches));
		$url_parsed = parse_url($url);
		if (isset($url_parsed)) {
			return $url;
		} else {
			return false;
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_resetFields
	 * Purpose:		Resets the field array prior to making a subsequent call
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	private function _resetFields($clear = false)
	{
		if (isset($this->fields))
		{
			unset($this->fields);
			$this->xmlResponse = false;
		}
		if (isset($this->xml->parseData))
		{
			unset($this->xml->parseData);
			$this->xml->parseData = array();
		}
		if (!$clear)
			$this->fields = $this->mainflds;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkResponse (private)
	 * Purpose:		Response check to see if we got back xml
	 * As of:		version 1.5.3 (October 2009)
	 * 
	 * Significant Revisions:
	 *  2.0.2 (Feb 2010)
	 *  	* Modified Regex to accomodate root attributes (WHMCS 4.2)
	\* ------------------------------------------------------------ */
	private function _checkResponse($data)
	{
		if( preg_match('/<'.$this->root.'[^>]*>/i', $data) )
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}