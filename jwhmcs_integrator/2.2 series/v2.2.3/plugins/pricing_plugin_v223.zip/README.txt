J!WHMCS Integrator
------------------------------------------------------------------------

 Release Version: 2.23
    Release Date: 2011 February 18

 PLEASE READ ALL THE ENCLOSED INSTRUCTIONS

        Forums: https://www.gohigheris.com/forum
       Support: https://support.gohigheris.com
 Documentation: https://www.gohigheris.com/wiki
   Client Area: https://client.gohigheris.com


[ CONTENTS ]
------------------------------------------------------------------------

1. Server Requirements
2. Version 2.23 Release Notes
3. New Installation Instructions
4. Upgrade Instructions
5. Usage Instructions


[ SERVER REQUIREMENTS ]
------------------------------------------------------------------------

1. Joomla 1.5 (version 1.5.22 or above recommended)
2. WHMComplete Solution (WHMCS) version 4.0 or above (4.41 recommended)
3. PHP Version 5.x or later
4. MySQL Version 5.x or later
5. Curl Support (with SSL)
6. Ioncube Loaders Support (required for WHMCS portion of installation)
7. J!WHMCS Integrator version 2.2 or above


[ RELEASE NOTES ]
------------------------------------------------------------------------

To review the details and notes for the Version 2.23 release, please see:

https://www.gohigheris.com/wiki/Plugin_Pricing_Version_2.2_Release_Notes


[ INSTALLATION INSTRUCTIONS ]
------------------------------------------------------------------------

For instructions on performing a new installation of the J!WHMCS Integrator
Pricing Plugin, please see:

https://www.gohigheris.com/wiki/Plugin_Pricing_Version_2.2_Release_Notes#Installation


[ UPGRADE INSTRUCTIONS ]
------------------------------------------------------------------------

For instructions on performing an upgrade of a previous version of the 
J!WHMCS Integrator Pricing Plugin, please see:

https://www.gohigheris.com/wiki/Plugin_Pricing_Version_2.2_Release_Notes#Upgrade


[ USAGE INSTRUCTIONS ]
------------------------------------------------------------------------

For instructions on using the J!WHMCS Integrator Pricing Plugin in your
Joomla! web site, please visit our wiki at:

http://gohigheris.com/wiki/Plugin_Pricing_Version_2.2_Release_Notes#Usage
