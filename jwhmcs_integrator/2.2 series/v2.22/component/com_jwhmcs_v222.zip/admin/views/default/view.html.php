<?php
/**
 * Default View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: view.html.php 131 2010-12-22 14:21:11Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsViewGrpmgr
 * Extends:		JView
 * Purpose:		Used as the default view
 * As of:		version 1.5.0
\* ------------------------------------------------------------ */
class JwhmcsViewDefault extends JView
{
	/* ------------------------------------------------------------ *\
	 * Method:		display
	 * Purpose:		Assembles the page for the application to send to
	 * 				the user
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	function display($tpl = null)
	{
		$model	= & $this->getModel('default');
		$params	= & JwhmcsParams::getInstance();
		$user	= & JFactory::getUser();
		$lic	=   $model->checkLicense();		// Check J!WHMCS Integrator License
		$wup	=   $model->whmcsParamUpdate();	// Update WHMCS Parameters (bool)
		$task	=   JRequest::getVar( 'task' );
		$icons	=   $model->getIconDefinitions();
		
		JToolBarHelper :: title( JText::_( 'JWHMCS_ADMIN_TITLE_DEFAULT' ), 'jwhmcs.png' );
		JToolBarHelper :: custom( 'apiconxn', 'apiconxn.png', '', JText::_( 'JWHMCS_ADMIN_BUTTON_APICONXN'), false, false );
		JToolBarHelper :: custom( 'license', 'license.png', '', JText::_( 'JWHMCS_ADMIN_BUTTON_LICENSE'), false, false );
		JToolBarHelper :: custom( 'config', 'config.png', '', JText::_( 'JWHMCS_ADMIN_BUTTON_PARAMETERS'), false, false );
		
		$this->assignRef('lic',		$lic);		// Contains the license check data
		$this->assignRef('icondefs', $icons); // Icon definitions
		$this->assignRef('data',	$params);
		parent::display($tpl);
	}
}