function validateUsername(username)
{
	var msg = document.getElementById('servermsg');
	var val = document.getElementById('validusername');
	var jid = document.getElementById('joomlaid');
	var url = "index2.php?option=com_jwhmcs&controller=register&task=validateUsername&username="+URLEncode(username)+"&joomlaid="+jid.value;
	var frm = document.forms['registerForm'];
	frm.validate.disabled = true;
	frm.submitit.disabled = true;
	msg.removeClass('invalid').removeClass('valid').addClass('checking');
	msg.setHTML("Checking Username...");
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var resp = parseXml(xhr.responseText);
				var result = resp.getElementsByTagName("result")[0].childNodes[0].nodeValue;
				var message  = resp.getElementsByTagName("message")[0].childNodes[0].nodeValue;
				
				msg.setHTML(message);
				val.setProperty('value', result);
				
				if (result == 1) {
					msg.removeClass('checking').addClass('valid');
					frm.submitit.disabled = false;
					frm.validate.disabled = false;
				} else {
					msg.removeClass('checking').addClass('invalid');
					frm.validate.disabled = false;
					frm.submitit.disabled = true;
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function submitbutton(task) {
	var form = document.forms['registerForm'];
		
	if (task == 'validate') {
		validateUsername(document.getElementById('username').value);
	}
	else if (task == 'submit') {
		
		form.submitit.disabled = true;
		
		var valid = document.getElementById('validusername').value;

		if (valid == '1') {
			form.submit();
		}
		else {
			form.submitit.disabled = true;
		}
	}
}

function resetValid() {
	var msg = $('servermsg');
	var val = $('validusername');
	var form = document.forms['registerForm'];
	
	val.setProperty('value', '0');
	msg.removeClass('invalid').removeClass('valid');
	msg.setHTML("");
	form.submitit.disabled = true;
}