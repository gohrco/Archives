<?php

if (!defined("INSWIFT")) {
	trigger_error("Unable to process " . htmlentities($_SERVER['PHP_SELF']), E_USER_ERROR);
}

define("LOGINAPI_VBULLETIN", 2);
define("LOGINAPI_MODERNBILL", 3);
define("LOGINAPI_OSC", 100);
define("LOGINAPI_IPB", 101);
define("LOGINAPI_IONO", 102);
define("LOGINAPI_PLEXUM", 103);
define("LOGINAPI_AWBS", 104);
define("LOGINAPI_PHPAUDIT", 105);
define("LOGINAPI_WHMAUTOPILOT", 106);
define("LOGINAPI_ACTIVEDIRECTORY", 107);
define("LOGINAPI_XCART", 108);
define("LOGINAPI_PHPBB", 109);
define("LOGINAPI_SMF", 110);
define("LOGINAPI_MYBB", 111);
define("LOGINAPI_XMB", 112);
define("LOGINAPI_CLIENTEXEC", 113);
define("LOGINAPI_JOOMLA", 114);
define("LOGINAPI_HSPHERE", 115);
define("LOGINAPI_PHPPROBID", 116);
define("LOGINAPI_CUBECART", 117);
define("LOGINAPI_ACTIVEDIRECTORYSSL", 118);
define("LOGINAPI_MODERNBILLV5", 119);
define("LOGINAPI_TICKETPURCHASER",200);
define("LOGINAPI_CSCART", 210);
define("LOGINAPI_FSR", 220);
define("LOGINAPI_VIPERCART", 230);
define("LOGINAPI_XOOPS", 235);
define("LOGINAPI_WHMCSINTEGRATION", 300);
define("LOGINAPI_JWHMCS_INTEGRATOR", 310);

/**
* ###############################################
* Declare your LoginShare Modules below.
* moduleid - Unique Numerical Identifier for your Module. Please make sure you begin this with 100 to reserve the earlier numbers for official APIs
* title - Your LoginShare Module Title. Example: "Invision PB", "ModernBill"
* include - The Login Handler file
* ###############################################
*/
$_LOGINAPI[LOGINAPI_DEFAULT] = array("title" => $_SWIFT["language"]["defaultloginapi"], "include" => "default.login.php");
$_LOGINAPI[LOGINAPI_MODERNBILL] = array("title" => $_SWIFT["language"]["loginapi_modernbill"], "include" => "modernbill.login.php");
$_LOGINAPI[LOGINAPI_MODERNBILLV5] = array("title" => $_SWIFT["language"]["loginapi_modernbillv5"], "include" => "modernbillv5.login.php");
$_LOGINAPI[LOGINAPI_WHMCSINTEGRATION] = array("title" => $_SWIFT["language"]["loginapi_whmcsintegration"], "include" => "whmcsintegration.login.php");
$_LOGINAPI[LOGINAPI_VBULLETIN] = array("title" => $_SWIFT["language"]["loginapi_vb"], "include" => "vb.login.php");
$_LOGINAPI[LOGINAPI_XCART] = array("title" => $_SWIFT["language"]["loginapi_xcart"], "include" => "xcart.login.php");
$_LOGINAPI[LOGINAPI_ACTIVEDIRECTORY] = array("title" => $_SWIFT["language"]["loginapi_activedirectory"], "include" => "activedirectory.login.php");
$_LOGINAPI[LOGINAPI_ACTIVEDIRECTORYSSL] = array("title" => $_SWIFT["language"]["loginapi_activedirectoryssl"], "include" => "activedirectoryssl.login.php");
$_LOGINAPI[LOGINAPI_AWBS] = array("title" => $_SWIFT["language"]["loginapi_awbs"], "include" => "awbs.login.php");
$_LOGINAPI[LOGINAPI_OSC] = array("title" => $_SWIFT["language"]["loginapi_osc"], "include" => "osc.login.php");
$_LOGINAPI[LOGINAPI_IPB] = array("title" => $_SWIFT["language"]["loginapi_ipb"], "include" => "ipb.login.php");
$_LOGINAPI[LOGINAPI_PHPBB] = array("title" => $_SWIFT["language"]["loginapi_phpbb"], "include" => "phpbb.login.php");
$_LOGINAPI[LOGINAPI_IONO] = array("title" => $_SWIFT["language"]["loginapi_iono"], "include" => "iono.login.php");
$_LOGINAPI[LOGINAPI_PLEXUM] = array("title" => $_SWIFT["language"]["loginapi_plexum"], "include" => "plexum.login.php");
$_LOGINAPI[LOGINAPI_PHPAUDIT] = array("title" => $_SWIFT["language"]["loginapi_phpaudit"], "include" => "phpaudit.login.php");
$_LOGINAPI[LOGINAPI_WHMAUTOPILOT] = array("title" => $_SWIFT["language"]["loginapi_whmautopilot"], "include" => "whmautopilot.login.php");
$_LOGINAPI[LOGINAPI_TICKETPURCHASER] = array("title" => $_SWIFT["language"]["loginapi_ticketpurchaser"], "include" => "ticketpurchaser.login.php");
$_LOGINAPI[LOGINAPI_SMF] = array("title" => $_SWIFT["language"]["loginapi_smf"], "include" => "smf.login.php");
$_LOGINAPI[LOGINAPI_MYBB] = array("title" => $_SWIFT["language"]["loginapi_mybb"], "include" => "mybb.login.php");
$_LOGINAPI[LOGINAPI_XMB] = array("title" => $_SWIFT["language"]["loginapi_xmb"], "include" => "xmb.login.php");
$_LOGINAPI[LOGINAPI_CLIENTEXEC] = array("title" => $_SWIFT["language"]["loginapi_clientexec"], "include" => "clientexec.login.php");
$_LOGINAPI[LOGINAPI_HSPHERE] = array("title" => $_SWIFT["language"]["loginapi_hsphere"], "include" => "hsphere.login.php");
$_LOGINAPI[LOGINAPI_JOOMLA] = array("title" => $_SWIFT["language"]["loginapi_joomla"], "include" => "joomla.login.php");
$_LOGINAPI[LOGINAPI_PHPPROBID] = array("title" => $_SWIFT["language"]["loginapi_phpprobid"], "include" => "phpprobid.login.php");
$_LOGINAPI[LOGINAPI_CUBECART] = array("title" => $_SWIFT["language"]["loginapi_cubecart"], "include" => "cubecart.loginshare.php");
$_LOGINAPI[LOGINAPI_CSCART] = array("title" => $_SWIFT["language"]["loginapi_cscart"], "include" => "cscart.login.php");
$_LOGINAPI[LOGINAPI_FSR] = array("title" => $_SWIFT["language"]["loginapi_fsr"], "include" => "fsr.login.php");
$_LOGINAPI[LOGINAPI_VIPERCART] = array("title" => $_SWIFT["language"]["loginapi_viper"], "include" => "vipercart.login.php");
$_LOGINAPI[LOGINAPI_XOOPS] = array("title" => $_SWIFT["language"]["loginapi_xoops"], "include" => "xoops.login.php");
$_LOGINAPI[LOGINAPI_JWHMCS_INTEGRATOR] = array("title" => $_SWIFT["language"]["loginapi_jwhmcs_integrator"], "include" => "jwhmcs_integrator.login.php");

?>