<?php
/**
 * Register Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: register.php 131 2010-12-22 14:21:11Z steven_gohigher $
 * @since      2.1.0
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelDefault
 * Extends:		JwhmcsModel
 * Purpose:		Used as the default model for user management
 * 
 * As of:		version 2.1.0
\* ------------------------------------------------------------ */
class JwhmcsModelRegister extends JwhmcsModel
{
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * 
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		submitUsername
	 * Purpose:		Save data submitted for the username layout 
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function submitUsername()
	{
		global $mainframe;
		
		if (! defined( "JWHMCS_AUTH" ) )	// Set so we don't try to add the new user to WHMCS
			define("JWHMCS_AUTH", true);
		
		$db		= & JFactory::getDBO();
		$user	= & JFactory::getUser( JRequest::getVar( 'joomlaid' ) );
		
		// Validate token first or fail
		JRequest::checkToken() or jexit( 'Invalid Token' );
		
		$binder	= array(	'username'	=> JRequest::getVar('username') );
		
		if (! $user->bind($binder) ) {
			JError::raiseError( 500, $user->getError());
			return false;
		}
		
		if (! $user->save() ) {
			JError::raiseWarning('', JText::_( $user->getError()));
			return false;
		}
		
		// Update xref table
		$jid = JRequest::getVar( 'joomlaid' );
		$wid = JRequest::getVar( 'whmcsid' );
		
		$query	= "UPDATE #__jwhmcs_xref x SET xref_type=2 WHERE xref_a = $jid AND xref_b = $wid AND xref_type = 8";
		$db->setQuery($query);
		$db->query();
		
		$query	= "UPDATE #__jwhmcs_xref x SET xref_type=6 WHERE xref_a = $jid AND xref_b = $wid AND xref_type = 9";
		$db->setQuery($query);
		$db->query();
		
		// Build the credentials array
		$parameters['username']	= $user->get('username');
		$parameters['id']		= $user->get('id');
		
		$credentials['fullname']	= $user->get( 'name' );
		$credentials['username']	= $user->get( 'username' );
		$credentials['email']		= $user->get( 'email' );
		$credentials['password']	= JRequest::getVar( 'password' );
		$credentials['status']		= JAUTHENTICATE_STATUS_SUCCESS;
		$credentials['type']		= 'jwhmcs_auth';
		
		// Set clientid in the options array if it hasn't been set already
		$options['clientid'][] = $mainframe->getClientId();
		
		// Import the user plugin group
		JPluginHelper::importPlugin('user');

		// Now log in with correct credentials and allow Joomla to handle the rest
		$result = $mainframe->triggerEvent( 'onLoginUser', array( $credentials, array() ) );
		
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		username
	 * Purpose:		Assemble data to request new username from client 
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function username()
	{
		$db		= & JFactory::getDBO();
		$user	= & JFactory::getUser();
		
		// Pull user from DB
		$query	= "SELECT `xref_a` as joomlaid, `xref_type` as type, `xref_b` as whmcsid FROM #__jwhmcs_xref xref WHERE xref.xref_a = {$user->id} AND xref.xref_type BETWEEN 8 AND 9";
		$db->setQuery($query);
		$result	= $db->loadAssocList();
		
		// Make sure we got one
		if ( ( count( $result ) > 1 ) || ( count( $result ) == 0 ) )
			return false;
		
		$result	= $result[0];
		
		// Pull password from DB
		$sarray	= $this->getSess( JRequest::getVar( 'token' ) );
		$type	= $result['type'] == '8' ? 'client' : 'contact';
		$whmcs	= $this->getWhmcsData( $result['whmcsid'], 'id', $type );
		$whmcs['password'] = $sarray['password'];
		$data	= array_merge($result,$whmcs);
		
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		validateUsername
	 * Purpose:		Check a users' requested name against the db 
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function validateUsername( $username = null, $userid = 0 )
	{
		$db	= & JFactory::getDBO();
		
		// If nothing sent return false
		if ( is_null( $username ) || ( trim( $username ) == '' ) ) return array('result' => false, 'message' => JText::_( 'REGISTER_USERNAME_ERROR00' ) );
		
		// Check to see if username is an email address
		$pattern = "/\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,5}\b/i";
		$match = preg_match($pattern, $username);
		if ($match > 0) return array( 'result' => false, 'message' => JText::_( 'REGISTER_USERNAME_ERROR01' ) );
		
		// Check to see if the username is "too short"
		if ( strlen( $username ) < 3 ) return array( 'result' => false, 'message' => sprintf( JText::_( 'REGISTER_USERNAME_ERROR02' ), $username ) );
		
		// See if there is a user by that name
		$query	= "SELECT `id` FROM `#__users` WHERE `username` = " . $db->quote( $username );
		$db->setQuery($query);
		$result = $db->loadResult();
		
		// If we get an id back then the name is taken
		if ( $result )
		{
			if ($result == $userid)
			{
				return array( 'result' => true, 'message' => sprintf( JText::_( 'REGISTER_USERNAME_SUCCESS02' ), $username ) );
			}
			else
			{
				return array( 'result' => false, 'message' => sprintf( JText::_( 'REGISTER_USERNAME_ERROR03' ), $username ) );
			}
		}
		else
		{
			return array( 'result' => true, 'message' => sprintf( JText::_( 'REGISTER_USERNAME_SUCCESS' ), $username ) );
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	getSess
	 * Purpose:		Retrieve and remove the passed session info
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	function getSess($token)
	{
		$db =& JFactory::getDBO();
		$query = 'SELECT `value` FROM #__jwhmcs_sess WHERE token="'.$token.'"';
		$db->setQuery($query);
		$result = $db->loadResult();
		
		$tmp = preg_split('/\n/', $result);
		foreach ($tmp as $t):
			$var = explode('=', $t);
			$k = $var[0];
			unset($var[0]);
			$ubind[$k] = implode("=", $var);
			unset($var, $k);
		endforeach;
		$query = 'DELETE FROM #__jwhmcs_sess WHERE token="'.$token.'"';
		$db->setQuery($query);
		$res = $db->query();
		
		return $ubind;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getWhmcsData
	 * Purpose:		Request user information from WHMCS 
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function getWhmcsData($method, $by = 'email', $type = 'client' )
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		switch($type):
		case 'client':
			if ($by == 'email') {
				$jcurl->setAction('getclientsdatabyemail', array('email' => $method));
			}
			else {
				$jcurl->setAction('getclientsdata', array('clientid' => $method));
			}
		
			$whmcs	= $jcurl->loadResult();
			
			// WHMCS v421:  Now receive array of array -- need to test for it
			if ( isset($whmcs[0]['result']) ) $whmcs = $whmcs[0];
			
			if (( isset($whmcs['result'])) && ($whmcs['result'] == 'success')) {
				$ret = $whmcs;
			}
			else {
				$ret = false;
			}
			break;
		case 'contact':
			
			$jcurl->setAction('jwhmcsgetcontact', array("get" => "$by=$method"));
			$whmcs = $jcurl->loadResult();
			
			if ($whmcs['result'] == 'success') {
				$whmcs['userid'] = $whmcs['id'];
				$ret = $whmcs;
			}
			else {
				$ret = false;
			}
			break;
		endswitch;
		
		return $ret;
	}
}