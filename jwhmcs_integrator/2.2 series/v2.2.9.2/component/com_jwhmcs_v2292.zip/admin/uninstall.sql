DROP TABLE IF EXISTS `#__jwhmcs_xref`;
DROP TABLE IF EXISTS `#__jwhmcs_sess`;

--
-- Added for ver 1.5.1
--

DROP TABLE IF EXISTS `#__jwhmcs_user`;
DROP TABLE IF EXISTS `#__jwhmcs_group`;

--
-- Added for ver 2.1.0
--

DROP TABLE IF EXISTS `#__jwhmcs_config`;
DROP TABLE IF EXISTS `#__jwhmcs_usersub`;