<?php

/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: model.php 201 2010-04-23 20:48:23Z Steven $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.model');
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModel
 * Extends:		JModel
 * Purpose:		Used to set common functions for J!WHMCS Integrator
 * As of:		version 1.5.0
\* ------------------------------------------------------------ */
class JwhmcsModel extends JModel
{
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setId
	 * Purpose:		Common method to set id for any model
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	function setId($id)
	{
		// Set id and wipe data
		$this->_id		= $id;
		$this->_data	= null;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		storeData
	 * Purpose:		Common method to store dataset to tablename
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	function storeData($tablename, $datasets)
	{
		$row =& $this->getTable($tablename);
		
		// Check first to see if the dataset even has data
		if (count( $datasets ))
		{
			// The sent datasets does have data, so run this for each dataset
			foreach ($datasets as $dataset)
			{
				if (!$row->bind($dataset)) {
					$this->setError($this->_db->getErrorMsg());
					return false;
				}
		
				// Make sure the hello record is valid
				if (!$row->check()) {
					$this->setError($this->_db->getErrorMsg());
					return false;
				}
		
				// Store the web link table to the database
				if (!$row->store()) {
					$this->setError( $this->_db->getErrorMsg() );
					return false;
				}
			}
		}
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		deleteData
	 * Purpose:		Common method to delete dataset to tablename
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	function deleteData($tablename, $dataset)
	{
		$row =& $this->getTable($tablename);
		if (count( $dataset )) {
			foreach($dataset as $cid) {
				if (!$row->delete( $cid )) {
					$this->setError( $row->getErrorMsg() );
					return false;
				}
			}
		}
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Submethod:	getPagination
	 * Purpose:		Creates the pagination for default view
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function getPagination($query)
	{
		// Load the content if it doesn't already exist
		if (empty($this->_pagination)) {
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal($query), $this->getState('limitstart'), $this->getState('limit') );
		}
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Submethod:	getTotal
	 * Purpose:		Creates the total for the pagination for default view
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function getTotal($query)
	{
		// Load the content if it doesn't already exist
		if (empty($this->_total)) {
			$this->_total = $this->_getListCount($query);    
		}
		return $this->_total;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		checkInstall
	 * Purpose:		This calls the checkinstall task in the jwhmcs.php
	 * 				file for display in the Joomla backend.
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function checkInstall(&$params = null)
	{
		$jcurl	= & JwhmcsCurl::getInstance();
		$params = & JwhmcsParams::getInstance();
		
		$jcurl->setCall();
		
		$url = $params->get( 'ApiUrl' ).'/jwhmcs.php?task=checkinstall&joomadmin='.$params->get( 'Secret' );
		$jcurl->set(CURLOPT_URL, $url);
		$jcurl->setRoot('PARAM');
		
		$items = $jcurl->loadResult();
		return $items; 
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		checkLicense
	 * Purpose:		This calls the checklicense task to validate license
	 * As of:		version 2.0.0
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 *  	* Modified parameters to reflect database change
	\* ------------------------------------------------------------ */
	function checkLicense(&$params = null)
	{
		$jcurl	= & JwhmcsCurl::getInstance();
		$params = & JwhmcsParams::getInstance();
		
		$jcurl->setCall();
		$url = $params->get( 'ApiUrl' ).'/jwhmcs.php?task=checklicense&joomadmin='.$params->get( 'Secret' );
		$jcurl->set(CURLOPT_URL, $url);
		$jcurl->set( CURLOPT_HEADER, false);
		$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
		$jcurl->setRoot('PARAM');
		$ret = $jcurl->loadResult();
		
		if ($jcurl->info['http_code'] != '200')
		{
			$ret['return']			= '';
			$ret['registeredname']	= 'Your Install is Incomplete';
			$ret['companyname']		= 'Please complete installation';
			$ret['email']			= '';
			$ret['regdate']			= '';
			$ret['valid']			= false;
			$ret['response']		= $jcurl->info['http_code'];
		}
		else
		{
			if ( is_array( $ret ) )
			{
				foreach ($ret as $k => $v )
				{
					$ret[$k] = utf8_decode($v);
				}
			}
		}
		
		return $ret; 
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		whmcsParamUpdate
	 * Purpose:		This gets the parameters from the WHMCS DB to update
	 * As of:		version 2.0.0
	 * 
	 * NOTE:  TO BE VASTLY MODIFIED IN 2.1.0 - NOT EVEN SURE WHERE CALLED FROM
	\* ------------------------------------------------------------ */
	function whmcsParamUpdate()
	{
		$cparams = $this->_getParams();
		
		$component_id = $cparams['id'];			// params[id] gets unset we need it tho
		$params	= & JwhmcsParams::getInstance();
		$jcurl	= & JwhmcsCurl::getInstance();
		
		$jcurl->setCall();
		$url = $params->get( "ApiUrl" ).'/jwhmcs.php?task=whmcsParamUpdate&joomadmin=1';
		$jcurl->set(CURLOPT_URL, $url);
		$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
		$jcurl->setRoot('PARAM');
		$ret = $jcurl->loadResult();
		
		if (! isset( $ret['result'] ) ) $ret['result'] = 'error';
		if ($ret['result'] == 'success') {
			unset ($ret['result'], $cparams['id']);
			foreach ($ret as $k => $v) {
				if ($k == 'version') $k = 'whmcsvers';
				$cparams[$k] = $v;
			}
			$this->_saveParams($cparams, $component_id);
			return true;
		}
		else {
			return false;
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_parseUrls
	 * Purpose:		Create standard parameters to use for system plg
	 * 
	 * As of:		version 1.5.3 (October 2009)
	 * 
	 * Note:		Same as function from authentication plg
	 * Todo:		Create global reference in component to common fnxn
	 * 
	 * Significant Revisions:
	 * 	1)  none
	\* ------------------------------------------------------------ *
	function _parseUrls(&$params)
	{
		// Parameters to parse for URLs
		$purls = array('jwhmcsjurl', 'jwhmcsjrootimgurl', 'jwhmcsurl', 'jwhmcsjin', 'jwhmcsjout');
		
		foreach ($purls as $purl):
			if (!is_null($params->get( $purl ))):
				$tmp = parse_url($params->get( $purl ));
				// Remove a slash if added to the end of the url
				if ($tmp['path']=='/') unset($tmp['path']);
				// Test for which parameter
				if ($purl == 'jwhmcsjurl') {
					$params->set( 'jwhmcsjurl', (isset($tmp['host'])?$tmp['host']:'').(isset($tmp['path'])?$tmp['path']:'').(isset($tmp['query'])?$tmp['query']:'').(isset($tmp['fragment'])?$tmp['fragment']:''));
					$params->set( 'jwhmcsjrooturl', (isset($tmp['host'])?$tmp['host']:''));
				} else {
					$params->set( $purl, (isset($tmp['host'])?$tmp['host']:'').(isset($tmp['path'])?$tmp['path']:'').(isset($tmp['query'])?$tmp['query']:'').(isset($tmp['fragment'])?$tmp['fragment']:''));
				}
				unset($tmp);
			endif;
		endforeach;
		return $params;
	}
	
	*/
	function _getParams()
	{
		$db = & JFactory::getDBO();
		
		$query	= 'SELECT `id`, `params` FROM #__components WHERE `option` = "com_jwhmcs"';
		$db->setQuery($query);
		$results = $db->loadAssoc();
		
		$pars = explode("\n", $results['params']);
		foreach ($pars as $p) {
			$ps = explode("=", $p);
			$k = $ps[0]; unset ($ps[0]);
			$params[$k] = implode("=", $ps);
		}
		$params['id'] = $results['id'];
		return $params;
	}
	
	
	function _saveParams($params, $id)
	{
		$db = & JFactory::getDBO();
		if (isset($params['id'])) unset ($params['id']);
		
		foreach ($params as $k => $v)
		{
			$ps[]	= $k."=".$v;
		}
		$param	= implode("\n", $ps);
		
		$query	= "UPDATE #__components SET `params` = '%s' WHERE `id` = %d";
		$query	= sprintf($query, $param, $id);
		$db->setQuery($query);
		if ($result	= $db->query())
			return true;
		else
			return false;
	}
	
	
	function buildResponse($data) {
		$return[] = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>";
		$return[] = "<root><param>";
		foreach ($data as $k => $v) {
			if (is_array($v)) {
				foreach ($v as $k2 => $v2) {
					$sub[] = '<'.$k.'><![CDATA['.$v2.']]></'.$k.'>';
				}
				$return[] = '<'.$k.'s>'.implode("\n", $sub).'</'.$k.'s>';
			}
			else {
				$return[] = '<'.$k.'><![CDATA['.$v.']]></'.$k.'>';
			}
		}
		$return[] = "</param></root>";
		
		return implode("", $return);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getApiConnection
	 * Purpose:		Validate the API credentials
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function getApiConnection()
	{
		$jcurl = & JwhmcsCurl::getInstance();
		
		$jcurl->setAction('getclientsdata', array('clientid' => 1));
		$data	= $jcurl->loadResults();
		
		if (is_array($data[0])) $data = $data[0];
		
		if ( $data['result'] == 'success' ) {
			$ret['result'] = 'success';
			$ret['message'] = 'Successfully connected!';
		}
		else {
			if ($data['message'] == 'Client Not Found' || $data['message'] == 'Client ID Not Found') {
				$ret['result'] = 'success';
				$ret['message'] = 'Successfully connected!';
			}
			elseif (empty($data)) {
				$ret['result'] = 'error';
				$ret['message'] = $jcurl->info['http_code'].' received with URL';
			}
			else {
				$ret = $data;
			}
			
		}
		return $ret;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	getOldParams
	 * Purpose:		Retrieves the old parameters from component upgrade 
	 * As of:		version 2.1.0 (April 2010)
	\* ------------------------------------------------------------ */
	function getOldParams($plugins = null)
	{
		$db = & JFactory::getDBO();
		
		$query	= "SELECT NULLIF(c.params,'') as `exists` FROM #__components c WHERE `option` = 'com_jwhmcs'";
		$db->setQuery($query);
		$results = $db->loadAssoc();
		
		if ( is_null($results['exists']) ) return false;
		
		$query	= 'SELECT `id`, `params` FROM #__components WHERE `option` = "com_jwhmcs"';
		$db->setQuery($query);
		$results = $db->loadAssoc();
		
		$pars = explode("\n", $results['params']);
		foreach ($pars as $p) {
			$ps = explode("=", $p);
			$k = $ps[0]; unset ($ps[0]);
			$params[$k] = implode("=", $ps);
		}
		
		if (!is_null($plugins)) {
			foreach ($plugins as $key => $plg) {
				if ($key == 'jauth') continue;
				
				$query	= "SELECT `published`, `params` FROM #__plugins WHERE `element` = '" . $plg['element'] . "' AND `folder` = '" . $plg['folder'] ."'";
				$db->setQuery($query);
				$result	= $db->loadAssoc();
				
				$params[$plg['element']."enable"] = $result['published'];
				$tmps = explode("\n", $result['params']);
				foreach ($tmps as $tmp) {
					$ps = explode("=", $tmp);
					$k = $ps[0]; unset ($ps[0]);
					$params[$k] = implode("=", $ps);
				}
			}
			
			if ($params['menuid']) {
				$recap = array('jwhmcsrecaptcha', 'jwhmcsrcpubkey', 'jwhmcsrcprikey', 'jwhmcsrctheme', 'jwhmcsrclang');
				$query = "SELECT `params` FROM #__menu WHERE `id`='{$params['menuid']}'";
				$db->setQuery($query);
				$result = $db->loadAssoc();
				
				if ($result) {
					$tmps = explode("\n", $result['params']);
					foreach ($tmps as $tmp) {
						$ps = explode("=", $tmp);
						$k = $ps[0]; unset ($ps[0]);
						if (!in_array($k, $recap)) continue;
						$params[$k] = implode("=", $ps);
					}
				}
			}
		}
		
		return $params;
	}
}