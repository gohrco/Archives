<?php
/**
 * Default Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelDefault
 * Extends:		JwhmcsModel
 * Purpose:		Used as the default model for user management
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsModelUsermgr extends JwhmcsModel
{
	var $_data;
	var $_total;
	var $_pagination = null;
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
		
		global $mainframe, $option;
		
		// Set $this->_id to array containing selected ids
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
		
		// Get pagination request variables
		$limit			= $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart		= $mainframe->getUserStateFromRequest($option.'.limitstart', 'limitstart', 0, 'int');
		$search			= $mainframe->getUserStateFromRequest($option.'.user_search', 'user_search', '', 'string');
		$search			= JString::strtolower($search);
		
		// In case limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
		$this->setState('user_search', $search);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getData
	 * Purpose:		Retrieve data required for view
	 * As of:		version 1.5.0 (August 2009)
	 *
	 * Significant Revisions:
	 *  2.0.2 (Feb 2010)
	 *  	* Changed where data for Force Add Joomla User called from
	 *  		(was issuing curl req, now pulls from jwhmcs_user tbl)
	\* ------------------------------------------------------------ */
	function getData( $task = null )
	{
		global $mainframe, $option;
		$db		= & JFactory::getDBO();
		$uri	= & JURI::getInstance();
		$jcurl	= & JwhmcsCurl::getInstance();
		
		$filter_order		= $mainframe->getUserStateFromRequest( "$option.sortby",		'sortby',	'a.name',	'cmd' );
		$filter_order_Dir	= $mainframe->getUserStateFromRequest( "$option.sortord",		'sortord',	'',			'word' );
		$filter_type		= $mainframe->getUserStateFromRequest( "$option.filter_type",		'filter_type', 		0,			'string' );
		$search				= $mainframe->getUserStateFromRequest( "$option.search",			'search', 			'',			'string' );
		$search				= JString::strtolower( $search );
		
		$limit				= $mainframe->getUserStateFromRequest( 'global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int' );
		$limitstart			= $mainframe->getUserStateFromRequest( $option.'.limitstart', 'limitstart', 0, 'int' );
		
		// All this for the icon images...
		$urlpath		= $uri->base().'components/com_jwhmcs/assets/icons/';
		$img			= array();
		$img['match']	= $urlpath.'Security.png';
		$img['alert']	= $urlpath.'Alert.png';
		$img['error']	= $urlpath.'Close.png';
		
		// Switch off on tasks
		switch ($task):
		case 'joomadd':			// Add new user to Joomla DB
		case 'joomedit':		// Edit existing user in Joomla DB
			// 0:  Initialize Variables
			$contact = false;
			if ($wid = JRequest::getVar( 'wcontid' )) {
				$contact = true;
			}
			else {
				$wid	= JRequest::getVar( 'whmcsid' );
			}
			
			// 1:  Retrieve user data from Jwhmcs User table and bind to wuser
			$query	= "SELECT * FROM #__jwhmcs_user".($contact ? "sub" : "" )." WHERE id = $wid";
			$db->setQuery($query);
			$wuser	= $db->loadAssoc();
			
			// 3:  Get the Joomla user info (if set)
			if ($joomlaid	= JRequest::getVar( 'joomlaid' ))
			{
				$query = 'SELECT a.*, g.name AS groupname'
						. ' FROM #__users AS a'
						. ' INNER JOIN #__core_acl_aro AS aro ON aro.value = a.id'
						. ' INNER JOIN #__core_acl_groups_aro_map AS gm ON gm.aro_id = aro.id'
						. ' INNER JOIN #__core_acl_aro_groups AS g ON g.id = gm.group_id'
						. ' WHERE a.id = '.$joomlaid
						. ' GROUP BY a.id';
				$db->setQuery($query);
				$juser	= $db->loadAssoc();
				
				// 4a: Assign data variables for existing Joomla user
				$this->_data->name		= $juser['name'];
				$this->_data->email		= $juser['email'];
				$this->_data->username	= $juser['username'];
				$this->_data->gid		= $juser['groupname'];
			} else {
				// 4b: No user from Joomla exists, so assign email as default value
				$this->_data->email	= $wuser['email'];
				$this->_data->gid	= 'Registered';
			}
			
			// 5:  Build Groupbox
			$query = 'SELECT name AS value, name AS text'
					. ' FROM #__core_acl_aro_groups'
					. ' WHERE name != "ROOT"'
					. ' AND name != "USERS"';
			
			$db->setQuery( $query );
			$types[] 		= JHTML::_('select.option',  '0', '- '. JText::_( 'Select Group' ) .' -' );
			foreach( $db->loadObjectList() as $obj )
				$types[] = JHTML::_('select.option',  $obj->value, JText::_( $obj->text ) );
			
			$this->_data->gidtypes	= $types;
			$this->_data->wid	= $wid;
			$this->_data->contact = ($contact ? true : false );
			break;
		
		case 'whmcsadd':		// Add new user to WHMCS DB
		case 'whmcsedit':		// Edit existing user in WHMCS DB
			$jid	= JRequest::getVar( 'joomlaid' );
			$query	= 'SELECT a.email FROM #__users AS a WHERE a.id = '.$jid;
			$db->setQuery($query);
			$jemail	= $db->loadResult();
			
			// get the ID of selected user
			if ($clientid = JRequest::getVar( 'whmcsid' ))
			{
				$jcurl->setAction('getclientsdata', array('clientid' => $clientid));
				$this->_data = (object) $jcurl->loadResult();
				$this->_data->jid	= $jid;
			} else {
				$this->_data->email	= $jemail;
				$this->_data->jid	= $jid;
			}
			
			break;
		default:
			// Retrieve sort values from JRequest, set defaults otherwise
			$qp['sortby']	= (JRequest::getVar( 'sortby' ) ? JRequest::getVar( 'sortby' ) : 'jname' );
			$qp['sortord']	= (JRequest::getVar( 'sortord' ) ? (JRequest::getVar( 'sortord' ) == 1 ? 'ASC':'DESC') : 'ASC' );
			
			// Create Joomla user query
			$query	= $this->_buildQuery($task, $qp);
			$qry = str_replace('#_', 'jos', $query);
			
			// Retrieve users from Joomla
			$db->setQuery( $query, $limitstart, $limit ); 
			$items = $db->loadObjectList();
			
			// Fetch Pagination
			jimport('joomla.html.pagination');
			$pagination = new JPagination($this->getTotal($query), $limitstart, $limit );
			
			$this->_data->data			= $items;
			$this->_data->pagination	= $pagination;
			
		endswitch;
		
		return $this->_data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		joomsave
	 * Purpose:		Saves the new or edited Joomla user info and
	 * 				returns to controller
	 * 
	 * Requires:	$form		- Array containing data sent from form
	 * 				$task		- contains task from request string
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function joomsave(&$form, $task)
	{
		// 0:  Initialize variables
		global $mainframe;
		$db				= &JFactory::getDBO();
		
		if ( $task == 'joomeditsave' )
			$user		= new JUser(JRequest::getVar( 'joomlaid' ));
		else
			$user 		= clone(JFactory::getUser());
		
		$authorize		=& JFactory::getACL();
		$usersConfig	=& JComponentHelper::getParams( 'com_users' );
		$original_gid	= $user->get('gid');
		
		JRequest::checkToken() or jexit( 'Invalid Token' );
		
		// Initialize new usertype setting
		$newUsertype = $usersConfig->get( 'new_usertype' );
		if (!$newUsertype)
			$newUsertype = 'Registered';
		
		// Build the user array for binding
		$ubind = $this->_getUserArray($form);
		
		// Bind the post array to the user object
		if (!$user->bind( $ubind, 'usertype' ))
			JError::raiseError( 500, $user->getError());
		
		// Set some initial user values
		if ($task=='joomeditsave'):
			// if group has been changed and where original group was a Super Admin
			if ( $user->get('gid') != $original_gid && $original_gid == 25 )
			{
				// count number of active super admins
				$query = 'SELECT COUNT( id )'
					. ' FROM #__users'
					. ' WHERE gid = 25'
					. ' AND block = 0'
				;
				$db->setQuery( $query );
				$count = $db->loadResult();

				if ( $count <= 1 )
				{
					// disallow change if only one Super Admin exists
					$this->setRedirect( 'index.php?option=com_users', JText::_('WARN_ONLY_SUPER') );
					return false;
				}
			}
			break;
		endif;
		$user->set('gid', $authorize->get_group_id( '', $newUsertype, 'ARO' ));
		
		$date =& JFactory::getDate();
		$user->set('registerDate', $date->toMySQL());
		
		// If there was an error with registration, set the message and display form
		if ( !$user->save() )
		{
			JError::raiseWarning('', JText::_( $user->getError()));
			return false;
		}
		
		$type = ( JRequest::getVar( 'contact' ) ? 7 : 3 );
		$query = "INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) VALUES ({$user->id}, $type, {$form['whmcsid']})";
		$db->setQuery($query);
		$db->query();
		
		// Send registration confirmation mail
		$password = $form['password'];
		$this->_sendMail($user, $password);
		
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		whmcsaddsave
	 * Purpose:		Save the new or edited WHMCS user info and returns
	 * 				to the controller
	 * Requires:	$post		- Array containing data sent from form
	 * 				$task		- Contains task from request string
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function whmcsaddsave(&$post, $task)
	{
		// 0:  Initialize variables
		$db		= & JFactory::getDBO();
		$uri	= & JURI::getInstance();
		$jcurl	= & JwhmcsCurl::getInstance();
		
		// 0b: Create duplicate of $post for modifying for WHMCS
		$fields			= $post;
		$fields['currency'] = '1';
		
		// 1a: Create array of fields to unset for storing in WHMCS build fields for storing
		$unsets = array('option', 'whmcsid', 'joomlaid', 'task', 'subtask', 'controller');
		foreach ($unsets as $unset) unset($fields[$unset]);
		
		// 1b: Issue cUrl command to create new WHMCS user
		$func['action']	= 'addclient';
		
		$jcurl->setAction('addclient', $fields);
		$whmcs	= $jcurl->loadResult();
		
		if ($whmcs['result']=='success'):
			$query = 'INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) '
						.'VALUES ('.$post['joomlaid'].', 2, '.$whmcs['clientid'].')';
			$db->setQuery($query);
			$db->query();
		endif;
		return $whmcs;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		changeUsername
	 * Purpose:		Method to request a change in the username at next login
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function changeUsername($post)
	{
		$db		= & JFactory::getDBO();
		$newxt	=   ( $post['xt'] < 4 ? 8 : 9 );
		
		// We don't allow username changes to groups
		if ( $post['xt'] == 4 )
			return;
		
		// We don't need to change the username for an added user
		if ( $post['xt'] == 3 || $post['xt'] == 7 )
			return;
		
		$query	= "DELETE FROM `#__jwhmcs_xref` WHERE `xref_a` = {$post['xa']} AND `xref_b` = {$post['xb']} AND `xref_type` = {$post['xt']}";
		$db->setQuery($query);
		$db->query();
		
		$query	= "INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`)
					VALUES ({$post['xa']}, $newxt, {$post['xb']})";
		$db->setQuery($query);
		if ($db->query()) return true;
		return false;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		changeAllusername
	 * Purpose:		Method to request a change to all usernames
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function changeAllusername()
	{
		$db		= & JFactory::getDBO();
		
		$query	= "SELECT * FROM #__jwhmcs_xref";
		$db->setQuery($query);
		$xrefs	= $db->loadObjectList();
		
		$ret	= true;
		$return	= true;
		foreach ($xrefs as $xref) {
			$x['xa'] = $xref->xref_a;
			$x['xt'] = $xref->xref_type;
			$x['xb'] = $xref->xref_b;
			
			$ret = $this->changeUsername($x);
			if (! $ret)
				$return = false;
			
			unset($x);
		}
		
		return $return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		syncUser
	 * Purpose:		Synchronizes the user from WHMCS and Joomla by
	 * 				saving the two ids to the xref database
	 * 
	 * Requires:	$method		- Array containing data sent from query string
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function syncUser($method)
	{
		// 0:  Initialize Variables
		$db		= &JFactory::getDBO();
		$jcurl	=& JwhmcsCurl::getInstance();
		
		// 1:  Pull existing email address to find
		if ($whmcsid = JRequest::getVar( 'whmcsid' )):
			$find	= 'joomla';
			$type	= 2;
			$query	= "SELECT w.email FROM #__jwhmcs_user as w WHERE w.id = $whmcsid";
		elseif ($whmcsid = JRequest::getVar( 'whsubid' )):
			$find	= 'joomla';
			$type	= 6;
			$query	= "SELECT w.email FROM #__jwhmcs_usersub as w WHERE w.id = $whmcsid";
		else:
			$find = 'whmcs';
			$joomid = JRequest::getVar( 'joomid' );
			$query	= 'SELECT a.email FROM #__users as a WHERE a.id = '.$joomid;
		endif;
		$db->setQuery($query);
		$email	= $db->loadResult();
		
		// 2:  Search based on email address
		switch($find):
		case 'joomla':
			/* ------------------------------------ *\
			 * For this section we have a WHMCS ID
			\* ------------------------------------ */
			// J1: Lets start by pulling the data from Joomla based on the email
			$query	= 'SELECT a.id FROM #__users as a WHERE a.email='.$db->Quote($email);
			$db->setQuery($query);
			
			// J2: Does it return a result?  then continue
			if ($xref_a = $db->loadResult()):
				
				// J3: Now check the xref table to see if it exists already
				$query	= 'SELECT x.xref_b FROM #__jwhmcs_xref as x WHERE x.xref_a='.$xref_a.' AND x.xref_type BETWEEN 1 AND 9';
				$db->setQuery($query);
				
				// J4: Does it exist?  No?  Then proceed
				if (is_null($db->loadResult())):
					
					// J5: Create xref table record
					$query = "INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) 
								VALUES ($xref_a, $type, $whmcsid)";
					$db->setQuery($query);
					
					if ($db->query()):
						
						// J6: All is well, return succesful
						return true;
					endif;
				endif;
			endif;
			return false;
			break;
		case 'whmcs':
			/* ------------------------------------ *\
			 * For this section we have a Joomla ID
			\* ------------------------------------ */
			// W1: Lets start by pulling the data from WHMCS based on the email
			
			$fields['email'] = $email;
			$jcurl->setAction('getclientsdatabyemail', $fields);
			$whmcs	= $jcurl->loadResult();
			$tblsub = ""; $type = 2;
			
			if ( $whmcs['result'] != 'success' ) {
				$jcurl->setAction('jwhmcsgetcontact', array("get" => "email=$email"));
				$whcon	= $jcurl->loadResult();
				$type	= 6;
				
				if ( $whcon['result'] != 'success' ) {
					return false;
				}
				else {
					$whmcs = $whcon;
					$tblsub	= "sub";
					$whmcs['userid'] = $whcon['id'];
				}
			}
			
			// W3: Now find out if that matched ID from WHMCS already exists in the xref
			$query	= 'SELECT x.xref_a, x.xref_type FROM #__jwhmcs_xref as x WHERE x.xref_b='.$whmcs['userid'].' AND x.xref_type BETWEEN 1 AND 9';
			$db->setQuery($query);
			
			// W4: Is there an existing xref?  Yes - then check joomla id against what we have
			if (! is_null( $result = $db->loadAssoc() ) )
			{
				if ( $joomid != $result['xref_a'] ) $this->syncBreak( array( 'xa' => $result['xref_a'], 'xt' => $result['xref_type'], 'xb' => $whmcs['userid'] ) );
				else return false;
			}
			
			$query	= "INSERT INTO #__jwhmcs_user$tblsub (id, fname, lname, cname, email, address1, address2, city, state, postal, country, phonenumber) VALUES (%1\$s, %2\$s, %3\$s, %4\$s, %5\$s, %6\$s, %7\$s, %8\$s, %9\$s, %10\$s, %11\$s, %12\$s) 
						ON DUPLICATE KEY UPDATE fname=%2\$s, lname=%3\$s, cname=%4\$s, email=%5\$s, address1=%6\$s, address2=%7\$s, city=%8\$s, state=%9\$s, postal=%10\$s, country=%11\$s, phonenumber=%12\$s";
			
			$query	= sprintf($query, $whmcs['userid'], $db->Quote($whmcs['firstname']), $db->Quote($whmcs['lastname']), $db->Quote($whmcs['companyname']), $db->Quote($whmcs['email']), $db->Quote($whmcs['address1']), $db->Quote($whmcs['address2']), $db->Quote($whmcs['city']), $db->Quote($whmcs['state']), $db->Quote($whmcs['postcode']), $db->Quote($whmcs['country']), $db->Quote($whmcs['phonenumber']));
			
			$db->setQuery($query);
			$db->query();
			
			// W8: Create the xref record
			$query = 'INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) '
						.'VALUES ('.$joomid.', '.$type.', '.$whmcs['userid'].')';
			$db->setQuery($query);
			
			if ($db->query()) return true;
			
			break;
		endswitch;
		return false;
	}
	
	
	public function syncBreak($post)
	{
		// 0:  Initialize Variables
		$db = &JFactory::getDBO();
		
		// 1:  Create Query
		$query	= 'DELETE FROM #__jwhmcs_xref WHERE xref_a = '.$post['xa'].' AND xref_type = '.$post['xt'].' AND xref_b = '.$post['xb'];
		$db->setQuery($query);
		
		// 2:  Execute and return
		if ($db->query())
			return true;
		else
			return false;
	}
	
	
	public function matchAll()
	{
		// 0:  Initialize Variables
		$db				= & JFactory::getDBO();
		$jcurl			= & JwhmcsCurl::getInstance();
		$group_members	=   array();
		$ids			=   array();
		$jids			=   array();
		$qresult		=   array( 'client' => true, 'subs' => true );
		
		// 1:  Pull all ids of group members
		$query	=	'SELECT x.xref_a as id '.
					'FROM #__jwhmcs_xref x '.
					'WHERE x.xref_type IN (4)';
		$db->setQuery($query);
		$group_members = $db->loadResultArray();
		
		// 2:  Pull all emails from WHMCS user base (stored in Joomla) that AREN'T in xref
		$query	=	"	SELECT ju.id, ju.email
						FROM #__jwhmcs_user ju 
						WHERE ju.id NOT IN ( 
							SELECT DISTINCT ju.id 
							FROM #__jwhmcs_user ju 
								INNER JOIN #__jwhmcs_xref jx ON jx.xref_b = ju.id 
							WHERE jx.xref_type IN (1,2,3,8) 
						) AND ju.email NOT IN ( 
							SELECT DISTINCT jg.email 
							FROM #__jwhmcs_group jg 
								INNER JOIN #__jwhmcs_xref jx ON jx.xref_b = jg.id 
							WHERE jx.xref_type IN (4) 
						)";
		$db->setQuery($query);
		$wemails = $db->loadAssocList();
		
		// 3:  Cycle through each WHMCS email and add to new xref array
		foreach ($wemails as $wu) {
			$query	= 'SELECT u.id '.
						'FROM #__users u '.
						'WHERE u.email = "'.$wu['email'].'"';
			$db->setQuery($query);
			
			if ($jid = $db->loadResult()) {
				if (in_array($jid, $group_members)) continue;
				$ids[] = "($jid, 2, ".$wu['id'].")";
			}
		}
		
		// 4:  Execute SQL to add new ids to xref before pulling for WHMCS
		if (! empty($ids)) {
			$query	=	'INSERT INTO #__jwhmcs_xref (`xref_a`, `xref_type`, `xref_b`) VALUES '.implode(', ',$ids).';';
			$db->setQuery($query);
			$db->query();
		}
		unset ($ids, $jid, $wemails);
		
		// 2b:  Pull all emails from WHMCS subaccount base (stored in Joomla) that AREN'T in xref
		$query	=	"	SELECT ju.id, ju.email
						FROM #__jwhmcs_usersub ju 
						WHERE ju.id NOT IN ( 
							SELECT DISTINCT ju.id 
							FROM #__jwhmcs_usersub ju 
								INNER JOIN #__jwhmcs_xref jx ON jx.xref_b = ju.id 
							WHERE jx.xref_type IN (5,6,7,9) 
						) AND ju.email NOT IN ( 
							SELECT DISTINCT jg.email 
							FROM #__jwhmcs_group jg 
								INNER JOIN #__jwhmcs_xref jx ON jx.xref_b = jg.id 
							WHERE jx.xref_type IN (4) 
						)";
		
		$db->setQuery($query);
		$wemails = $db->loadAssocList();
		
		// 3b:  Cycle through each WHMCS email and add to new xref array
		foreach ($wemails as $wu) {
			$query	= 'SELECT u.id '.
						'FROM #__users u '.
						'WHERE u.email = "'.$wu['email'].'"';
			$db->setQuery($query);
			
			if ($jid = $db->loadResult()) {
				if (in_array($jid, $group_members)) continue;
				$ids[] = "($jid, 6, ".$wu['id'].")";
			}
		}
		
		// 4b:  Execute SQL to add new ids to xref before pulling for WHMCS
		if (! empty($ids)) {
			$query	=	'INSERT INTO #__jwhmcs_xref (`xref_a`, `xref_type`, `xref_b`) VALUES '.implode(', ',$ids).';';
			$db->setQuery($query);
			$db->query();
		}
		
		// 5:  Pull all emails from Joomla user base that AREN'T in xref
		$query	=	'SELECT u.id, u.email '.
					'FROM #__users u '.
					'WHERE u.id NOT IN ( '.
						'SELECT DISTINCT u.id '.
						'FROM #__users u '.
							'INNER JOIN #__jwhmcs_xref jx ON jx.xref_a = u.id '.
						'WHERE jx.xref_type BETWEEN 1 AND 9 '.
					')';
		$db->setQuery($query);
		$jemails = $db->loadObjectList();
		
		// 6:  Cycle through each email and check via api check
		foreach ($jemails as $ju) {
			$fields['email'] = $ju->email;
			$jcurl->setAction('getclientsdatabyemail', $fields);
			$whmcs	= $jcurl->loadResult();
			
			if ($whmcs['result']=='success') {
				$jids[] = "($ju->id, 2, ".$whmcs['userid'].")";
				
				$wuser[]='('.$db->Quote($whmcs['userid']).', '
							.$db->Quote($whmcs['firstname']).', '
							.$db->Quote($whmcs['lastname']).', '
							.$db->Quote($whmcs['companyname']).', '
							.$db->Quote($whmcs['email']).', '
							.$db->Quote($whmcs['address1']).', '
							.$db->Quote($whmcs['address2']).', '
							.$db->Quote($whmcs['city']).', '
							.$db->Quote($whmcs['state']).', '
							.$db->Quote($whmcs['postcode']).', '
							.$db->Quote($whmcs['country']).', '
							.$db->Quote($whmcs['phonenumber']).')';
				continue;
			}
			
			$fields['get'] = "email={$ju->email}";
			$jcurl->setAction('jwhmcsgetcontact', $fields);
			$whmcs	= $jcurl->loadResult();
			
			if ($whmcs['result']=='success') {
				$jids[] = "($ju->id, 6, ".$whmcs['id'].")";
				
				$wuser[]='('.$db->Quote($whmcs['id']).', '
							.$db->Quote($whmcs['firstname']).', '
							.$db->Quote($whmcs['lastname']).', '
							.$db->Quote($whmcs['companyname']).', '
							.$db->Quote($whmcs['email']).', '
							.$db->Quote($whmcs['address1']).', '
							.$db->Quote($whmcs['address2']).', '
							.$db->Quote($whmcs['city']).', '
							.$db->Quote($whmcs['state']).', '
							.$db->Quote($whmcs['postcode']).', '
							.$db->Quote($whmcs['country']).', '
							.$db->Quote($whmcs['phonenumber']).')';
			}
		}
		
		// 7:  Run SQL to insert into database
		if (! empty($jids)) {
			$query	=	'INSERT INTO #__jwhmcs_xref (`xref_a`, `xref_type`, `xref_b`) VALUES '.implode(', ', $jids).';';
			$db->setQuery($query);
			$qresult['client']	= $db->query();
			$query	= 'INSERT INTO #__jwhmcs_usersub (id, fname, lname, cname, email, address1, address2, city, state, postal, country, phonenumber) VALUES '.implode(', ', $wuser).';';
			$db->setQuery($query);
			$qresult['subs']	= $db->query();
		}
		
		if ( in_array( false, $qresult, true ) )
			return false;
		else
			return true;
	}
	
	
	/* ----------------------------------------- *\
	 *              SUB FUNCTIONS                *
	\* ----------------------------------------- */
	
	
	
	/* ------------------------------------------------------------ *\
	 * Submethod:	_buildQuery
	 * Purpose:		The query for pulling the user data is so massive
	 * 				it is hard to effectively go through getData without
	 * 				getting lost, so the query is built here.
	 * 
	 * Requires:	$task		- form data sent by request
	 * Optional:	$qp			- Query Parameters
	 * 
	 * As of:		version 1.5.1
	 * 
	 * Significant Revisions:
	 * 	1)  ver 1.5.3 - Oct 2009
	 * 		* Added refined user manager features - sql query adjusted
	\* ------------------------------------------------------------ */
	private function _buildQuery($task, $qp = null)
	{
		$db = & JFactory::getDBO();
		
		if ($this->getState('user_search')) {
			$needle   = $db->Quote( '%'.$db->getEscaped( $this->getState('user_search'), true ).'%', false );
			$usersrch = ' IFNULL( LOWER( %s ) LIKE %s, NULL )';
			
			$arsch[0] = array('a.name', 'a.username', 'a.email', 'w.fname', 'w.lname', 'w.cname', 'w.email', 'w.address1', 'w.address2', 'w.city', 'w.state', 'w.postal');
			$arsch[1] = array('a.name', 'a.username', 'a.email', 'w.fname', 'w.lname', 'w.cname', 'w.email');
			$arsch[2] = array('a.name', 'a.username', 'a.email');
			$arsch[3] = array('w.fname', 'w.lname', 'w.cname', 'w.email', 'w.address1', 'w.address2', 'w.city', 'w.state', 'w.postal', 'w.country', 'w.phonenumber');
			
			foreach ($arsch as $key => $scharray) {
				foreach ($scharray as $item ) {
					$srch[] = sprintf($usersrch, $item, $needle);
				}
				$search[$key] = ' AND ( '.implode(' OR', $srch).' )';
				unset ($srch);
			}
		}
		else {
			$search = array(null, null, null, null);
		}
		
		$jusers		= JRequest::getVar('filter_jusers')?JRequest::getVar('filter_jusers'):0;
		$wusers		= JRequest::getVar('filter_wusers')?JRequest::getVar('filter_wusers'):0;
		$matches	= JRequest::getVar('filter_matches')?JRequest::getVar('filter_matches'):0;
		
		$sqlseg		= array(array(),array(),array(),array());
		
		switch($matches):
		case '-1':
			$sqlseg[0][0] = false;			// Sql:  Joomla users joined to WHMCS users 
			$sqlseg[1][0] = false;			// Sql:  Joomla users groups to single WHMCS
			$sqlseg[2][0] = true;			// Sql:  unmatched Joomla users only
			$sqlseg[3][0] = true;			// Sql:  nmatched WHMCS users only
			$sqlseg[4][0] = false;			// Sql:  Joomla users joined to WHMCS subaccounts 
			$sqlseg[4][1] = null;			// 				null
			$sqlseg[5][0] = true;			// Sql:  unmatched WHMCS subaccounts only
			break;
		case 1:
			$sqlseg[0][0] = true;			// Sql:  Joomla users joined to WHMCS users 
			$sqlseg[0][1] = "IN ( '1' )";	// 				Specifies only silver matches
			$sqlseg[1][0] = false;			// Sql:  Joomla users groups to single WHMCS
			$sqlseg[2][0] = false;			// Sql:  unmatched Joomla users only
			$sqlseg[3][0] = false;			// Sql:  nmatched WHMCS users only
			$sqlseg[4][0] = true;			// Sql:  Joomla users joined to WHMCS subaccounts 
			$sqlseg[4][1] = "IN ( '5' )";	// 				Specifies only silver matches
			$sqlseg[5][0] = false;			// Sql:  unmatched WHMCS subaccounts only
			break;
		case 2:
			$sqlseg[0][0] = true;			// Sql:  Joomla users joined to WHMCS users 
			$sqlseg[0][1] = "IN ( '2' )";	// 				Specifies only orange matches (found) 
			$sqlseg[1][0] = false;			// Sql:  Joomla users groups to single WHMCS
			$sqlseg[2][0] = false;			// Sql:  unmatched Joomla users only
			$sqlseg[3][0] = false;			// Sql:  unmatched WHMCS users only
			$sqlseg[4][0] = true;			// Sql:  Joomla users joined to WHMCS subaccounts 
			$sqlseg[4][1] = "IN ( '6' )";	// 				Specifies only orange matches (found)
			$sqlseg[5][0] = false;			// Sql:  unmatched WHMCS subaccounts only
			break;
		case 3:
			$sqlseg[0][0] = true;			// Sql:  Joomla users joined to WHMCS users 
			$sqlseg[0][1] = "IN ( '3', '8' )";	// 				Specifies only purple matches (forced)
			$sqlseg[1][0] = false;			// Sql:  Joomla users groups to single WHMCS
			$sqlseg[2][0] = false;			// Sql:  unmatched Joomla users only
			$sqlseg[3][0] = false;			// Sql:  nmatched WHMCS users only
			$sqlseg[4][0] = true;			// Sql:  Joomla users joined to WHMCS subaccounts 
			$sqlseg[4][1] = "IN ( '7', '9' )";	// 				Specifies only purple matches (forced)
			$sqlseg[5][0] = false;			// Sql:  unmatched WHMCS subaccounts only
			break;
		case 4:
			$sqlseg[0][0] = false;			// Sql:  Joomla users joined to WHMCS users 
			$sqlseg[0][1] = null;			// 				null
			$sqlseg[1][0] = true;			// Sql:  Joomla users groups to single WHMCS
			$sqlseg[1][1] = "'4'";			// 			Specifies group xref id
			$sqlseg[2][0] = false;			// Sql:  unmatched Joomla users only
			$sqlseg[3][0] = false;			// Sql:  nmatched WHMCS users only
			$sqlseg[4][0] = false;			// Sql:  Joomla users joined to WHMCS subaccounts 
			$sqlseg[4][1] = null;			// 				null
			$sqlseg[5][0] = false;			// Sql:  unmatched WHMCS subaccounts only
			break;
		default:
			$sqlseg[0][0] = true;			// Sql:  Joomla users joined to WHMCS users 
			$sqlseg[0][1] = "IN ( '1', '2', '3', '8' ) OR x.xref_type='' ";	// Specifies all match types or no match type
			$sqlseg[1][0] = true;			// Sql:  Joomla users groups to single WHMCS
			$sqlseg[1][1] = "'4'";			// 			Specifies group xref id
			$sqlseg[2][0] = true;			// Sql:  unmatched Joomla users only
			$sqlseg[3][0] = true;			// Sql:  unmatched WHMCS users only
			$sqlseg[4][0] = true;			// Sql:  Joomla users joined to WHMCS subaccounts 
			$sqlseg[4][1] = "IN ( '5', '6', '7', '9' ) OR x.xref_type='' ";	// Specifies all match types or no match type
			$sqlseg[5][0] = true;			// Sql:  unmatched WHMCS subaccounts only
			
		endswitch;
		
		switch($jusers):
		case 1:
			if ($matches==0):
				$sqlseg[0][0] = true;			// Sql:  Joomla users joined to WHMCS users
				$sqlseg[1][0] = true;			// Sql:  Joomla users groups to single WHMCS
				$sqlseg[2][0] = false;			// Sql:  unmatched Joomla users only
				$sqlseg[3][0] = false;			// Sql:  unmatched WHMCS users only
				$sqlseg[4][0] = true;			// Sql:  Joomla users joined to WHMCS subaccounts
				$sqlseg[5][0] = false;			// Sql:  unmatched WHMCS subaccounts only
			else:
				JRequest::setVar('filter_jusers', 0);
			endif;
			break;
		case 2:
			if ($matches==0):
				$sqlseg[0][0] = false;			// Sql:  Joomla users joined to WHMCS users
				$sqlseg[1][0] = false;			// Sql:  Joomla users groups to single WHMCS
				$sqlseg[2][0] = true;			// Sql:  unmatched Joomla users only
				$sqlseg[3][0] = false;			// Sql:  unmatched WHMCS users only
				$sqlseg[4][0] = false;			// Sql:  Joomla users joined to WHMCS subaccounts
				$sqlseg[5][0] = true;			// Sql:  unmatched WHMCS subaccounts only
			else:
				JRequest::setVar('filter_jusers', 0);
			endif;
			break;
		endswitch;
		
		switch($wusers):
		case 1:
			if ($matches==0):
				$sqlseg[0][0] = true;			// Sql:  Joomla users joined to WHMCS users
				$sqlseg[1][0] = true;			// Sql:  Joomla users groups to single WHMCS
				$sqlseg[2][0] = false;			// Sql:  unmatched Joomla users only
				$sqlseg[3][0] = false;			// Sql:  unmatched WHMCS users only
				$sqlseg[4][0] = true;			// Sql:  Joomla users joined to WHMCS subaccounts
				$sqlseg[5][0] = false;			// Sql:  unmatched WHMCS subaccounts only
			else:
				JRequest::setVar('filter_wusers', 0);
			endif;
			break;
		case 2:
			if ($matches==0):
				$sqlseg[0][0] = false;			// Sql:  Joomla users joined to WHMCS users
				$sqlseg[1][0] = false;			// Sql:  Joomla users groups to single WHMCS
				$sqlseg[2][0] = false;			// Sql:  unmatched Joomla users only
				$sqlseg[3][0] = true;			// Sql:  unmatched WHMCS users only
				$sqlseg[4][0] = false;			// Sql:  Joomla users joined to WHMCS subaccounts
				$sqlseg[5][0] = true;			// Sql:  unmatched WHMCS subaccounts only
			else:
				JRequest::setVar('filter_wusers', 0);
			endif;
			break;
		endswitch;
		
		switch ($task):
		default:
			$orderby	= 'ORDER BY '.$qp['sortby'].' '.$qp['sortord'];
			
			$query 	= '';
			
			/* ------------------------------------------- *\
			 * Sql:  Joomla users joined to WHMCS users
			\* ------------------------------------------- */
			if ($sqlseg[0][0]):
				$query[]= "( SELECT 
								x.xref_type, a.id as `jid`, a.name as `jname`, a.username as `jusername`, a.email as `jemail`, a.block as `jblock`, g.name as `jgroupname`, 
								w.id as `wid`, w.fname as `wfname`, w.lname as `wlname`, w.cname as `wcname`, w.email as `wemail`, w.address1 as `waddress1`, 
								w.address2 as `waddress2`, w.city as `wcity`, w.state as `wstate`, w.postal as `wpostal`, w.country as `wcountry`, w.phonenumber as `wphone`  
							FROM (#__users AS a 
								INNER JOIN #__core_acl_aro AS aro ON aro.value = a.id INNER JOIN #__core_acl_groups_aro_map AS gm ON gm.aro_id = aro.id INNER JOIN #__core_acl_aro_groups AS g ON g.id = gm.group_id) 
								INNER JOIN (#__jwhmcs_xref as x INNER JOIN #__jwhmcs_user as w ON w.id=x.xref_b) ON a.id = x.xref_a 
							WHERE ( x.xref_type {$sqlseg[0][1]}) {$search[0]} ) ";
			endif;
			
			/* ------------------------------------------- *\
			 * Sql:  Joomla users groups to single WHMCS
			\* ------------------------------------------- */
			if ($sqlseg[1][0]):
				$query[]= "( SELECT 
								x.xref_type, a.id as `jid`, a.name as `jname`, a.username as `jusername`, a.email as `jemail`, a.block as `jblock`, g.name as `jgroupname`, 
								w.id as `wid`, w.fname as `wfname`, w.lname as `wlname`, w.cname as `wcname`, w.email as `wemail`, NULL as `waddress1`, 
								NULL as `waddress2`, NULL as `wcity`, NULL as `wstate`, NULL as `wpostal`, NULL as `wcountry`, NULL as `wphone` 
							FROM (#__users AS a 
								INNER JOIN #__core_acl_aro AS aro ON aro.value = a.id INNER JOIN #__core_acl_groups_aro_map AS gm ON gm.aro_id = aro.id INNER JOIN #__core_acl_aro_groups AS g ON g.id = gm.group_id) 
								INNER JOIN (#__jwhmcs_xref as x INNER JOIN #__jwhmcs_group as w ON w.id=x.xref_b) ON a.id = x.xref_a 
							WHERE x.xref_type = {$sqlseg[1][1]}{$search[1]} ) ";
			endif;
			
			
			/* ------------------------------------------- *\
			 * Sql:  unmatched Joomla users only
			\* ------------------------------------------- */
			if ($sqlseg[2][0]):
				$query[]= "( SELECT 
								x.xref_type, a.id as `jid`, a.name as `jname`, a.username as `jusername`, a.email as `jemail`, a.block as `jblock`, g.name as `jgroupname`, 
								NULL as `wid`, NULL as `wfname`, NULL as `wlname`, NULL as `wcname`, NULL as `wemail`, NULL as `waddress1`, NULL as `waddress2`, 
								NULL as `wcity`, NULL as `wstate`, NULL as `wpostal`, NULL as `wcountry`, NULL as `wphone`
							FROM (#__users AS a 
								INNER JOIN #__core_acl_aro AS aro ON aro.value = a.id INNER JOIN #__core_acl_groups_aro_map AS gm ON gm.aro_id = aro.id INNER JOIN #__core_acl_aro_groups AS g ON g.id = gm.group_id) 
								LEFT JOIN #__jwhmcs_xref as x ON a.id = x.xref_a 
							WHERE x.xref_type IS NULL {$search[2]} ) ";
			endif;
			
			/* ------------------------------------------- *\
			 * Sql:  unmatched WHMCS users only
			\* ------------------------------------------- */
			if ($sqlseg[3][0]):
				$query[]="( SELECT 
								NULL as `xref_type`, NULL as `jid`, NULL as `jname`, NULL as `jusername`, NULL as `jemail`, NULL as `jblock`, NULL as `jgroupname`,
								w.id as `wid`, w.fname as `wfname`, w.lname as `wlname`, w.cname as `wcname`, w.email as `wemail`, w.address1 as `waddress1`, 
								w.address2 as `waddress2`, w.city as `wcity`, w.state as `wstate`, w.postal as `wpostal`, w.country as `wcountry`, w.phonenumber as `wphone`
							FROM #__jwhmcs_user AS w 
								LEFT JOIN #__jwhmcs_xref as x ON w.id = x.xref_b 
							WHERE (( x.xref_type IS NULL OR x.xref_type = 4 ) 
								AND w.email NOT IN ( SELECT email FROM #__jwhmcs_group )) {$search[3]} ) ";
				
				/* ------------------------------------------- *\
				 * Sql:  Matched group to WHMCS users only
				\* ------------------------------------------- */
				// This is an additional Query to bridge 
				/*$query[]="( SELECT
								'0' as xref_type, g.id as `jid`, CONCAT(g.cname, ': ', g.lname, ', ', g.fname) as `jname`, NULL as `jusername`, NULL as `jemail`, NULL as `jblock`, NULL as `jgroupname`,
								w.id as `wid`, w.fname as `wfname`, w.lname as `wlname`, w.cname as `wcname`, w.email as `wemail`, w.address1 as `waddress1`,
								w.address2 as `waddress2`, w.city as `wcity`, w.state as `wstate`, w.postal as `wpostal`, w.country as `wcountry`, w.phonenumber as `wphone` 
							FROM #__jwhmcs_user AS w 
								INNER JOIN #__jwhmcs_group g ON g.email = w.email "
							.($search[3]?" WHERE ".substr(substr($search[3], 6), 0, -2) : "" )." ) ";*/
			endif;
			
			/* ------------------------------------------- *\
			 * Sql:  Matched WHMCS subaccount only
			\* ------------------------------------------- */
			if ($sqlseg[4][0]):
				$query[]= "( SELECT
								x.xref_type, a.id as `jid`, a.name as `jname`, a.username as `jusername`, a.email as `jemail`, a.block as `jblock`, g.name as `jgroupname`,
								w.id as `wid`, w.fname as `wfname`, w.lname as `wlname`, w.cname as `wcname`, w.email as `wemail`, w.address1 as `waddress1`,
								w.address2 as `waddress2`, w.city as `wcity`, w.state as `wstate`, w.postal as `wpostal`, w.country as `wcountry`, w.phonenumber as `wphone` 
							FROM (#__users AS a
								INNER JOIN #__core_acl_aro AS aro ON aro.value = a.id
									INNER JOIN #__core_acl_groups_aro_map AS gm ON gm.aro_id = aro.id
										INNER JOIN #__core_acl_aro_groups AS g ON g.id = gm.group_id)
								INNER JOIN
									(#__jwhmcs_xref as x INNER JOIN #__jwhmcs_usersub as w ON w.id=x.xref_b) ON a.id = x.xref_a
							WHERE ( x.xref_type {$sqlseg[4][1]}) {$search[0]} ) ";
			endif;
			/* ------------------------------------------- *\
			 * Sql:  Unmatched WHMCS subaccount only
			\* ------------------------------------------- */
			if ($sqlseg[5][0]):
				$query[]="( SELECT
								'-1' as xref_type, NULL as `jid`, NULL as `jname`, NULL as `jusername`, NULL as `jemail`, NULL as `jblock`, NULL as `jgroupname`, 
								w.id as `wid`, w.fname as `wfname`, w.lname as `wlname`, w.cname as `wcname`, w.email as `wemail`, w.address1 as `waddress1`,
								w.address2 as `waddress2`, w.city as `wcity`, w.state as `wstate`, w.postal as `wpostal`, w.country as `wcountry`, w.phonenumber as `wphone`  
							FROM #__jwhmcs_usersub AS w
								LEFT JOIN #__jwhmcs_xref as x ON w.id = x.xref_b
							WHERE ( x.xref_type IS NULL ) {$search[3]} ) ";
			endif;
			
			if (count($query)>1)
				$qrystr = implode(' UNION ', $query).$orderby;
			else
				$qrystr = $query[0].$orderby;
			
			break;
		endswitch;
		
		return $qrystr;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Submethod:	_getUserArray
	 * Purpose:		Because we can't send the entire post value to bind,
	 * 				we have to create a new array
	 * 
	 * Requires:	$form		- form data sent by request
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	private function _getUserArray($form)
	{
		// Because we can't send the entire post value to bind, we have to create new array
		$ubind = array(	'name'		=> $form['name'],
						'username'	=> $form['username'],
						'email'		=> $form['email'],
						'password'	=> $form['password'],
						'password2'	=> $form['password2'],
						'task'		=> $form['task'],
						'id'		=> $form['id'],
						'gid'		=> $form['gid']);
		return $ubind;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Submethod:	_sendMail
	 * Purpose:		Sends email to new user notifying them of password
	 * 				change
	 * 
	 * STILL NEEDS TESTING -- 9/21/2009  1:00pm
	 * 
	 * Requires:	$user		- User object saved in calling method
	 * 				$password	- Cleartext password sent via form
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	private function _sendMail(&$user, $password)
	{
		global $mainframe;
		
		$db			= &JFactory::getDBO();
		$name 		= $user->get('name');
		$email 		= $user->get('email');
		$username 	= $user->get('username');
		
		$usersConfig 	= &JComponentHelper::getParams( 'com_users' );
		$sitename 		= $mainframe->getCfg( 'sitename' );
		$useractivation = $usersConfig->get( 'useractivation' );
		$mailfrom 		= $mainframe->getCfg( 'mailfrom' );
		$fromname 		= $mainframe->getCfg( 'fromname' );
		$siteURL		= rtrim(JURI::base(), "/administrator/");
		
		$subject 	= sprintf ( JText::_( 'ACCOUNT_DETAILS_FOR' ), $name, $sitename);
		$subject 	= html_entity_decode($subject, ENT_QUOTES);
		
		$message	= sprintf ( JText::_( 'SEND_MSG' ), $name, $sitename, $siteURL);
		$message = html_entity_decode($message, ENT_QUOTES);
		
		//get all super administrator
		$query = 'SELECT name, email, sendEmail' .
				' FROM #__users' .
				' WHERE LOWER( usertype ) = "super administrator"';
		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		
		// Send email to user
		if ( ! $mailfrom  || ! $fromname ) {
			$fromname = $rows[0]->name;
			$mailfrom = $rows[0]->email;
		}
		
		JUtility::sendMail($mailfrom, $fromname, $email, $subject, $message);
		return;
	}
} 