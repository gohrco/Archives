<?php
/**
 * WHMCS User Synchrization View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: view.html.php 131 2010-12-22 14:21:11Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsViewSync
 * Extends:		JView
 * Purpose:		Used as the WHMCS User Synchrization view
 * 
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsViewSync extends JView
{
	/* ------------------------------------------------------------ *\
	 * Method:		display
	 * Purpose:		Assembles the page for the application to send to
	 * 				the user
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function display($tpl = null)
	{
		$model	= &$this->getModel('sync');
		$user	= &JFactory::getUser();
		$task	= JRequest::getVar( 'task' );
		$data	= $model->getData($task);
		
		switch ($task):
		default:
			JToolBarHelper::title( JText::_( 'JWHMCS_ADMIN_TITLE_SYNCRO' ), 'sync.png' );
			JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
			JToolBarHelper :: custom( 'usrmgr', 'usrmgr.png', 'usrmgr.png', JText::_( 'JWHMCS_ADMIN_BUTTON_USRMGR' ), false, false );
			JToolBarHelper :: divider();
			JToolBarHelper :: custom( 'refresh', 'refresh.png', 'refresh.png', JText::_( 'JWHMCS_ADMIN_BUTTON_REFRESH' ), false, false );
			JToolBarHelper :: divider();
			JToolBarHelper :: custom( 'requery', 'sync.png', 'sync.png', JText::_( 'JWHMCS_ADMIN_BUTTON_REQRY' ), false, false );
			JToolBarHelper :: divider();
			JToolBarHelper :: custom( 'reload', 'reload.png', 'reload.png', JText::_( 'JWHMCS_ADMIN_BUTTON_RELOAD' ), false, false );
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
		endswitch;
		
		$this->assignRef('pagination', 	$data->pagination);
		$this->assignRef('data', 		$data->items);
		parent::display($tpl);
	}
}