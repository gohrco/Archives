<?php defined('_JEXEC') or die('Restricted access');

$j48helppage = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-48-helppage.png';
$j32jwhmcs = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-jwhmcs.png';
?>
<style type="text/css">
.icon-48-helppage		{ background-image: url(<?php echo $j48helppage; ?>); }
.icon-32-jwhmcs			{ background-image: url(<?php echo $j32jwhmcs; ?>); }
#supporttable			{ margin: 0 auto; }
#supporttable td		{ padding-bottom: 25px; font-family: Trebuchet MS; }
#supporttable td p		{ font-size: 12pt; color: #333333; margin: 0px; padding: 4px 0; }
#supporttable td strong	{ font-weight: bold; font-size: 18pt; }
.supnumber				{ font-size: 32pt; color: #A30008; font-weight: bold; vertical-align: top; }
.supnumber span			{ border: 1px solid #000; padding: 0 4px; background-color: #FFE8B2; }
</style>

<table width="75%" border="0" id="supporttable">
	<tr>
		<td class="supnumber"><span>1</span></td>
		<td>
			<strong>Documentation and Knowledgebase</strong>
			<p>Start with the documentation and knowledgebase.  As the documentation is built and available, it will also be made available on our web site.</p>
			<p>Visit our documentation at <a href="http://gohigheris.com/wiki" target="blank">http://gohigheris.com/wiki</a></p>
			<p>Visit our knowledgebase at <a href="http://client.gohigheris.com/" target="blank">http://client.gohigheris.com/</a></p>
		</td>
	</tr>
	<tr>
		<td class="supnumber"><span>2</span></td>
		<td>
			<strong>Support Forums</strong>
			<p>Chances are, the issue you are encountering has been seen in the community and has been asked about previously.  Our support forums are monitored and active, so don't hesitate to jump in and ask your question!</p>
			<p>Visit our support forums at <a href="http://forum.gohigheris.com" target="blank">http://forum.gohigheris.com</a></p>
		</td>
	</tr>
	<tr>
		<td class="supnumber"><span>3</span></td>
		<td>
			<strong>Support Ticket</strong>
			<p>If you can't find the answer you need on our forum, please open a ticket with us and ask for assistance.  Please use the support ticket system for J!WHMCS Integrator product specific support only; Joomla! CMS or WHMCS product specific inquiries will be directed to the forum or their appropriate sites for further assistance.</p>
			<p>Customers with a purchased license must have a current Support and Upgrade package with their license, customers using a leased license must have their license current for support</p> 
			<p>Visit our support site at <a href="http://support.gohigheris.com" target="blank">http://support.gohigheris.com</a></p>
		</td>
	</tr>
</table>


<form action="index.php" method="post" name="adminForm">
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="controller" value="default" />
<input type="hidden" name="task" value="" />
</form>