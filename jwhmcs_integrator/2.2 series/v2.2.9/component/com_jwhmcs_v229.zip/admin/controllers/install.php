<?php
/**
 * Group Management Controller for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: install.php 131 2010-12-22 14:21:11Z steven_gohigher $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsControllerInstall
 * Extends:		JwhmcsController
 * Purpose:		Used for Installing J!WHMCS Integrator
 * As of:		version 2.0.0
\* ------------------------------------------------------------ */
class JwhmcsControllerInstall extends JwhmcsController
{
	/* ------------------------------------------------------------ *\
	 * Task:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
		
		$this->registerTask( 'apiconxnAccept',	'licenseAccept' );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		abort
	 * Purpose:		Handle abort install request
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function abort()
	{
		$msg = JText::_( 'JWHMCS_ADMIN_CONTR_MSGCNCL' );
		$this->setRedirect( 'index.php?option=com_jwhmcs', $msg );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		interview
	 * Purpose:		Pushes install to automatic install
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	function interview()
	{
		JRequest::setVar( 'hidemainmenu', 1 );
		JRequest::setVar( 'view', 'install' );
		JRequest::setVar( 'layout', 'interview' );
		parent::display();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		comlete
	 * Purpose:		Handle installation complete
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function complete()
	{
		$model = $this->getModel('install');
		$model->complete();
		
		$lnk = 'index.php?option=com_jwhmcs';
		$msg = JText::sprintf( 'JWHMCS_ADMIN_INSTALL_COMPLETE', JWHMCS_VERS );
		$this->setRedirect( $lnk, $msg);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		manual
	 * Purpose:		Display manual instructions page
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function manual()
	{
		JRequest::setVar( 'layout', 'manual' );
		parent::display();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		license
	 * Purpose:		Check the license
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function license()
	{
		$model	= $this->getModel('install');
		
		$licchk = $model->checkLicense();
		if (isset($licchk['response'])) {
			$this->setRedirect( 'index.php?option=com_jwhmcs&controller=install&task=apiconxn', JText::_( 'JWHMCS_ADMIN_INSTALL_FAILED_LICCHK' ) );
		}
		else {
			JRequest::setVar( 'hidemainmenu', 1 );
			JRequest::setVar( 'layout', 'license' );
			parent::display();
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		license
	 * Purpose:		Check the license
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function licenseReload()
	{
		$model	= $this->getModel('install');
		$model->licenseReload();
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=install&task=license', '' );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		apiconxn
	 * Purpose:		Check the API connectivity
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function apiconxn()
	{
		JRequest::setVar( 'hidemainmenu', 1 );
		JRequest::setVar( 'layout', 'apiconxn' );
		parent::display();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		licenseAccept
	 * Purpose:		Redirect to default upon license acceptance
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function licenseAccept()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs', null );
	}
}