<?php defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.mootools');
JHTML::_('behavior.tooltip');
JHTML::_('behavior.formvalidation');


$groupsel = JHTML::_('select.genericlist', $this->data->gidtypes, 'gid', '', 'value', 'text', $this->data->gid );
$isNew	= (isset($this->data->id)?($this->data->id < 1?true:false):true);
?>

<script language="javascript">
function myValidate(f) {
        if (document.formvalidator.isValid(f)) {
                return true; 
        }
        else {
                alert('Some values are not acceptable.  Please retry.');
        }
        return false;
}

function submitbutton(pressbutton) {
	var form = document.adminForm;

	if (pressbutton == 'cancel') {
		submitform( pressbutton );
		return;
	}

	if (myValidate(form) == true) {
		submitform( pressbutton );
	}
	
}
</script>

<form action="index.php" method="post" name="adminForm">
	<table class="admintable" cellspacing="1">
		<tr>
			<td width="100" align="right" class="key">
				<label for="name">
					<?php
					$title = JText::_( 'JWHMCS_ADMIN_LABEL_NAME' );
					echo JHTML::_('tooltip', 'Enter a name to give this user.  This is separate from the users site name, it is simply for internal, easy reference.', $title, null, $title); ?>
				</label>
			</td>
			<td>
				<div class="jwhmcs-fieldwrap">
					<input class="text_area required" type="text" name="name" id="name" size="40" maxlength="255" value="<?php echo $isNew?'':$this->data->name; ?>" /><br />
					<?php echo $title; ?>
				</div>
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="name">
					<?php
					$title = JText::_( 'JWHMCS_ADMIN_LABEL_USRNAME' );
					echo JHTML::_('tooltip', 'Enter a name to give this user.  This is separate from the users site name, it is simply for internal, easy reference.', $title, null, $title); ?>
				</label>
			</td>
			<td>
				<div class="jwhmcs-fieldwrap">
					<input class="text_area required" type="text" name="username" id="username" size="40" maxlength="255" value="<?php echo $isNew?'':$this->data->username; ?>" /><br />
					<?php echo $title; ?>
				</div>
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="name">
					<?php
					$title = JText::_( 'JWHMCS_ADMIN_LABEL_EMAIL' );
					echo JHTML::_('tooltip', 'Enter a name to give this user.  This is separate from the users site name, it is simply for internal, easy reference.', $title, null, $title); ?>
				</label>
			</td>
			<td>
				<div class="jwhmcs-fieldwrap">
					<input class="text_area required" type="text" name="email" id="email" size="40" maxlength="255" value="<?php echo $this->data->email; ?>" disabled /><br />
					<?php echo $title; ?>
				</div>
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="name">
					<?php
					$title = JText::_( 'JWHMCS_ADMIN_LABEL_TMPPASS' );
					echo JHTML::_('tooltip', 'Enter a name to give this user.  This is separate from the users site name, it is simply for internal, easy reference.', $title, null, $title); ?>
				</label>
			</td>
			<td>
				<div class="jwhmcs-fieldwrap">
					<input class="text_area required" type="text" name="password" id="password" size="40" maxlength="255" value="temppass" /><br />
					<?php echo $title; ?>
				</div>
				<div class="jwhmcs-fieldwrap">
					<input class="text_area required" type="text" name="password2" id="password2" size="40" maxlength="255" value="temppass" /><br />
					<?php echo JText::_( 'JWHMCS_ADMIN_LABEL_CONPASS'); ?>
				</div>
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="name">
					<?php
					$title = JText::_( 'JWHMCS_ADMIN_LABEL_GROUP' );
					echo JHTML::_('tooltip', 'Enter a name to give this user.  This is separate from the users site name, it is simply for internal, easy reference.', $title, null, $title); ?>
				</label>
			</td>
			<td>
				<div class="jwhmcs-fieldwrap">
					<?php echo $groupsel; ?><br />
					<?php echo JText::_( 'JWHMCS_ADMIN_LABEL_SELGRP'); ?>
				</div>
			</td>
		</tr>
	</table>
	<input type="hidden" name="whmcsid" value="<?php echo $this->data->wid; ?>" />
	<input type="hidden" name="joomlaid" value="<?php echo $this->data->id; ?>" />
	<input type="hidden" name="option" value="com_jwhmcs" />
	<input type="hidden" name="task" value="" />
	<?php if ($this->data->contact): ?>
	<input type="hidden" name="contact" value="1" />
	<?php endif; ?>
	<input type="hidden" name="subtask" value="<?php echo JRequest::getVar( 'task' ); ?>" />
	<input type="hidden" name="controller" value="usermgr" />
	<input type="hidden" name="email" value="<?php echo $this->data->email; ?>" />
	<?php echo JHTML::_( 'form.token' ); ?>
</form>
<div class="clr"></div>