function ajaxCheckAPI(step)
{
	var whmcsurl		= $('whmcsurl').value;
	var jwhmcsadminus	= $('jwhmcsadminus').value;
	var jwhmcsadminpw	= $('jwhmcsadminpw').value;
	var accesskey		= $('accesskey').value;
	whmcsurl			= encodeURIComponent(whmcsurl);
	jwhmcsadminus		= encodeURIComponent(jwhmcsadminus);
	jwhmcsadminpw		= encodeURIComponent(jwhmcsadminpw);
	accesskey			= encodeURIComponent(accesskey);
	
	var ajaxLog			= $('ajaxLog');
	var ajaxStat		= $('ajaxStatus');
	var ajaxMsgs		= $('ajaxMessage');
	var origStep		= $('step');
	var reqApi			= $('reqApi');
	var textWelcome		= $('textWelcome');
	var textApivalid	= $('textApivalid');
	var reqWhmcsPath	= $('reqWhmcsPath');
	var url = $('thisUrl').getProperty('value')+"?option=com_jwhmcs&controller=ajax&task=interview&jwhmcsadminus="+jwhmcsadminus+"&jwhmcsadminpw="+jwhmcsadminpw+"&whmcsurl="+whmcsurl+"&accesskey="+accesskey+"&step="+step;
	
	ajaxStat.removeClass('ajaxWaiting').addClass('ajaxLoading');
	ajaxMsgs.removeClass('ajaxMessageWaiting').addClass('ajaxMessageLoading');
	ajaxMsgs.empty().set('html','Checking API Username and Password...');
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var resp = parseXml(xhr.responseText);
				var nextStep = resp.getElementsByTagName("nextstep")[0].childNodes[0].nodeValue;
				var valid	 = resp.getElementsByTagName("valid")[0].childNodes[0].nodeValue;
				var message  = resp.getElementsByTagName("message");
				var txt = ajaxLog.innerHTML;
				
				if (valid == true) {
					var i=0;
					for (i=0; i<message.length; i++) {
						txt = "<span>"+message[i].childNodes[0].nodeValue + "</span>" + txt;
					}
					ajaxLog.set('html',txt);
					
					$('step').setProperty('value', nextStep);
					reqApi.setStyle('visibility', 'collapse');
					ajaxStat.removeClass('ajaxWaiting').addClass('ajaxLoading');
					ajaxMsgs.removeClass('ajaxMessageWaiting').addClass('ajaxMessageLoading');
					ajaxMsgs.empty().set('html','Installing');
					textWelcome.removeClass('visDisplay').addClass('visHidden');
					textApivalid.removeClass('visHidden').addClass('visDisplay');
					
					/* Display path request */
					ajaxStat.removeClass('ajaxLoading').addClass('ajaxWaiting');
					ajaxMsgs.removeClass('ajaxMessageLoading').addClass('ajaxMessageWaiting');
					reqWhmcsPath.setStyle('visibility', 'visible');
					textApivalid.removeClass('visDisplay').addClass('visHidden');
					ajaxMsgs.empty().set('html','Enter Path to WHMCS');
				} else {
					ajaxStat.removeClass('ajaxLoading').addClass('ajaxWaiting');
					ajaxMsgs.removeClass('ajaxMessageLoading').addClass('ajaxMessageWaiting');
					reqApi.setStyle('visibility', 'visible');
					textWelcome.removeClass('visDisplay').addClass('visHidden');
					ajaxMsgs.empty().set('html',message[0].childNodes[0].nodeValue);
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function ajaxCheckAPIU()
{
	var jwhmcsadminus = document.getElementById('jwhmcsadminus').value;
	var jwhmcsadminpw = document.getElementById('jwhmcsadminpw').value;
	var accesskey = document.getElementById('accesskey').value;
	var jwhmcsurl = document.getElementById('jwhmcsurl').value;
	jwhmcsurl		= encodeURIComponent( jwhmcsurl );
	jwhmcsadminus	= encodeURIComponent( jwhmcsadminus );
	jwhmcsadminpw	= encodeURIComponent( jwhmcsadminpw );
	jwhmcsadminxs	= encodeURIComponent( accesskey );
	
	var apistatusimg = document.getElementById('apistatusimg');
	var apistatusmsg = document.getElementById('apistatusmsg');
	var apistatusdef = document.getElementById('apistatusmsgdefault').value;
	
	apistatusimg.removeClass('ajaxSuccess').removeClass('ajaxError').addClass('ajaxLoading');
	apistatusmsg.innerHTML=apistatusdef;
	
	var xhr = createXHR();
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				try //Internet Explorer
				{
					xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
					xmlDoc.async="false";
					xmlDoc.loadXML(xhr.responseText);
				}
				catch(e)
				{
					try //Firefox, Mozilla, Opera, etc.
					{
						parser=new DOMParser();
						xmlDoc=parser.parseFromString(xhr.responseText,"text/xml");
					}
					catch(e) {alert(e.message)}
				}
				var result =xmlDoc.getElementsByTagName("param").item(0);
				
				var dsc = result.getElementsByTagName("result")[0].childNodes[0].nodeValue;
				var msg = result.getElementsByTagName("message")[0].childNodes[0].nodeValue;
				
				if (dsc == "success") {
					apistatusimg.removeClass('ajaxLoading').addClass('ajaxSuccess');
					document.getElementById('apiconnection').setAttribute("value", "1");
				}
				else {
					apistatusimg.removeClass('ajaxLoading').addClass('ajaxError');
				}
				apistatusmsg.innerHTML=msg;
			}
			else {
				alert('Error code ' + xhr.status);
			}
		}
	}
	xhr.open("GET","index.php?option=com_jwhmcs&controller=ajax&task=checkApiu&jwhmcsadminus="+jwhmcsadminus+"&jwhmcsadminpw="+jwhmcsadminpw+"&accesskey="+accesskey+"&jwhmcsurl="+jwhmcsurl,true);
	xhr.send(null);
}


function ajaxCheckLicense(step)

{
	var whmcspath = $('whmcspath').value;
	var license = $('licensekey').value;
	whmcspath = encodeURIComponent(whmcspath);
	license = encodeURIComponent(license);
	
	var ajaxLog  = $('ajaxLog');
	var ajaxStat = $('ajaxStatus');
	var ajaxMsgs = $('ajaxMessage');
	var origStep = $('step');
	var reqLicense = $('reqLicense');
	var textFileinstall = $('textFileinstall');
	var textLicensevalid = $('textLicensevalid');
	var url = $('thisUrl').getProperty('value')+"?option=com_jwhmcs&controller=ajax&task=interview&whmcspath="+whmcspath+"&license="+license+"&step="+step;
	
	ajaxStat.removeClass('ajaxWaiting').addClass('ajaxLoading');
	ajaxMsgs.removeClass('ajaxMessageWaiting').addClass('ajaxMessageLoading');
	ajaxMsgs.empty().set('html','Checking License...');
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var resp = parseXml(xhr.responseText);
				var nextStep = resp.getElementsByTagName("nextstep")[0].childNodes[0].nodeValue;
				var valid	 = resp.getElementsByTagName("valid")[0].childNodes[0].nodeValue;
					
				if (valid == true) {
					var message  = resp.getElementsByTagName("message");
					var txt = ajaxLog.innerHTML;
					var i=0;
					
					for (i=0; i<message.length; i++) {
						txt = "<span>" + message[i].childNodes[0].nodeValue + "</span>" + txt;
					}
					ajaxLog.set('html',txt);
					
					$('step').setProperty('value', nextStep);
					reqLicense.setStyle('visibility', 'collapse');
					ajaxStat.removeClass('ajaxWaiting').addClass('ajaxLoading');
					ajaxMsgs.removeClass('ajaxMessageWaiting').addClass('ajaxMessageLoading');
					ajaxMsgs.empty().set('html','Installing');
					textFileinstall.removeClass('visDisplay').addClass('visHidden');
					textLicensevalid.removeClass('visHidden').addClass('visDisplay');
					runInstall(nextStep);
				} else {
					ajaxStat.removeClass('ajaxLoading').addClass('ajaxWaiting');
					ajaxMsgs.removeClass('ajaxMessageLoading').addClass('ajaxMessageWaiting');
					reqLicense.setStyle('visibility', 'visible');
					textFileinstall.removeClass('visDisplay').addClass('visHidden');
					ajaxMsgs.empty().set('html','License Invalid');
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function ajaxLicenseCheck()
{
	var license = document.getElementById('licensekey').value;
	license = encodeURIComponent(license);
	
	var whmcsstatusimg = document.getElementById('whmcsstatusimg');
	var whmcsstatusmsg = document.getElementById('whmcsstatusmsg');
	var whmcsstatusdef = document.getElementById('whmcsstatusmsgdefault').value;
	
	whmcsstatusimg.removeClass('ajaxSuccess').removeClass('ajaxError').addClass('ajaxLoading');
	whmcsstatusmsg.innerHTML=whmcsstatusdef;
	
	var url = "index.php?option=com_jwhmcs&controller=ajax&task=checkValidLicense&license="+license;
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var result = parseXml(xhr.responseText);
				
				var dsc = result.getElementsByTagName("result")[0].childNodes[0].nodeValue;
				var msg = result.getElementsByTagName("message")[0].childNodes[0].nodeValue;
				
				if (dsc == "success") {
					whmcsstatusimg.removeClass('ajaxLoading').addClass('ajaxSuccess');
					document.getElementById('license').setAttribute("value", "1");
				}
				else {
					whmcsstatusimg.removeClass('ajaxLoading').addClass('ajaxError');
					document.getElementById('license').setAttribute("value", "0");
				}
				whmcsstatusmsg.innerHTML=msg;
				
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function completeInstall() {
	var textLicensevalid	= $('textLicensevalid');
	var textComplete		= $('textComplete');
	textLicensevalid.removeClass('visDisplay').addClass('visHidden');
	textComplete.removeClass('visHidden').addClass('visDisplay');
	
	var ajaxLog  = $('ajaxLog').innerHTML;
	var installLog	= $('installLog');
	installLog.setProperty('value', ajaxLog);
	
	document.forms['adminForm'].submit();
}


function createXHR() {
	var xhr = null;
		if (window.XMLHttpRequest) {
			xhr = new XMLHttpRequest();
		} else if (window.ActiveXObject) {
			try {
				xhr = new ActiveXObject('Microsoft.XMLHTTP');
			} catch (e) {}
		}
	return xhr;
}


function onKeypress(e) {
	if (e.keyCode == 13) {
		return false;
	}
}


function parseXml(data) {

	try //Internet Explorer
	{
		xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
		xmlDoc.async="false";
		xmlDoc.loadXML(data);
	}
	catch(e)
	{
		try //Firefox, Mozilla, Opera, etc.
		{
			parser=new DOMParser();
			xmlDoc=parser.parseFromString(data,"text/xml");
		}
		catch(e) {alert(e.message)}
	}
	return xmlDoc.getElementsByTagName("param").item(0);
}


function resetValid() {
	var msg = $('servermsg');
	var val = $('validusername');
	var form = document.forms['registerForm'];
	
	val.setProperty('value', '0');
	msg.removeClass('invalid').removeClass('valid');
	msg.set( 'html','' );
	form.submitit.disabled = true;
}


function runCheck(step)

{
	var ajaxStatus = document.getElementById('checkStep'+step);
	var ajaxMessage = document.getElementById('checkMessage'+step);
	var url = document.getElementById('thisUrl').getProperty('value')+"?option=com_jwhmcs&controller=ajax&task=checkinstall&step="+step;
	var laststep = document.getElementById('laststep').getProperty('value');
	
	ajaxStatus.removeClass('ajaxInitial');
	ajaxStatus.addClass('ajaxLoading');
	ajaxMessage.set('html','');
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var resp = parseXml(xhr.responseText);
				var nextStep = resp.getElementsByTagName("nextstep")[0].childNodes[0].nodeValue;
				var curStatus = resp.getElementsByTagName("status")[0].childNodes[0].nodeValue;
				var message  = resp.getElementsByTagName("message");
				var txt = ajaxMessage.innerHTML;
				var i=0;
				
				for (i=0; i<message.length; i++) {
					txt = message[i].childNodes[0].nodeValue + "\n" + txt;
				}
				ajaxMessage.set('html',txt);
				
				document.getElementById('step').setProperty('value', nextStep);
				
				ajaxStatus.removeClass('ajaxLoading');
				if (curStatus == '1') {
					ajaxStatus.addClass('ajaxSuccess');
				}
				else if (curStatus == '0' ) {
					ajaxStatus.addClass('ajaxError');
				}
				else {
					ajaxStatus.addClass('ajaxAlert');
				}
				
				if (step != laststep) {
					runCheck(nextStep);
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function runFix(step)
{
	var ajaxStatus = document.getElementById('checkStep'+step);
	var ajaxMessage = document.getElementById('checkMessage'+step);
	var url = document.getElementById('thisUrl').getProperty('value')+"?option=com_jwhmcs&controller=ajax&task=fixinstall&step="+step;
	
	ajaxStatus.removeClass('ajaxInitial');
	ajaxStatus.addClass('ajaxLoading');
	ajaxMessage.set('html','');
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var resp = parseXml(xhr.responseText);
				var curStatus = resp.getElementsByTagName("status")[0].childNodes[0].nodeValue;
				var message  = resp.getElementsByTagName("message");
				var txt = ajaxMessage.innerHTML;
				var i=0;
				
				for (i=0; i<message.length; i++) {
					txt = message[i].childNodes[0].nodeValue + "\n" + txt;
				}
				ajaxMessage.set('html',txt);
				
				ajaxStatus.removeClass('ajaxLoading');
				if (curStatus == '1') {
					ajaxStatus.addClass('ajaxSuccess');
				}
				else if (curStatus == '0' ) {
					ajaxStatus.addClass('ajaxError');
				}
				else {
					ajaxStatus.addClass('ajaxAlert');
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function runInstall(step)

{
	var ajaxLog = $('ajaxLog');
	var ajaxStat = $('ajaxStatus');
	var ajaxMsgs = $('ajaxMessage');
	var whmcspath = $('whmcspath').value;
	whmcspath = encodeURIComponent(whmcspath);
	var url = $('thisUrl').getProperty('value')+"?option=com_jwhmcs&controller=ajax&task=interview&whmcspath="+whmcspath+"&step="+step;
	
	ajaxStat.removeClass('ajaxInitial');
	ajaxStat.addClass('ajaxLoading');
	ajaxMsgs.removeClass('ajaxMessageInitial');
	ajaxMsgs.addClass('ajaxMessageLoading');
	ajaxMsgs.set('html','Installing');
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var resp = parseXml(xhr.responseText);
				var nextStep = resp.getElementsByTagName("nextstep")[0].childNodes[0].nodeValue;
				var message  = resp.getElementsByTagName("message");
				var txt = ajaxLog.innerHTML;
				
				var i=0;
				
				for (i=0; i<message.length; i++) {
					txt = "<span>"+message[i].childNodes[0].nodeValue + "</span>" + txt;
				}
				
				ajaxLog.set('html',txt);
				
				$('step').setProperty('value', nextStep);
				if (nextStep == '110' || nextStep == '210') {
					ajaxCheckAPI(nextStep);
				} else if (nextStep == '150' || nextStep == '155' || nextStep == '250' || nextStep == '255') {
					ajaxCheckLicense(nextStep);
				} else if (nextStep == '1000') {
					completeInstall();
				} else {
					runInstall(nextStep);
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function submitbutton(task) {
	var form = document.forms['registerForm'];
		
	if (task == 'validate') {
		validateUsername(document.getElementById('username').value);
	}
	else if (task == 'submit') {
		
		form.submitit.disabled = true;
		
		var valid = document.getElementById('validusername').value;

		if (valid == '1') {
			form.submit();
		}
		else {
			form.submitit.disabled = true;
		}
	}
}


function URLEncode (clearString) {
	var output = '';
	var x = 0;
	clearString = clearString.toString();
	var regex = /(^[a-zA-Z0-9_.]*)/;
	while (x < clearString.length) {
		var match = regex.exec(clearString.substr(x));
		if (match != null && match.length > 1 && match[1] != '') {
			output += match[1];
			x += match[1].length;
		} else {
			if (clearString[x] == ' ')
				output += '+';
			else {
				var charCode = clearString.charCodeAt(x);
				var hexVal = charCode.toString(16);
				output += '%' + ( hexVal.length < 2 ? '0' : '' ) + hexVal.toUpperCase();
			}
			x++;
		}
	}
	return output;
}


function validateUsername(username)
{
	var msg = document.getElementById('servermsg');
	var val = document.getElementById('validusername');
	var jid = document.getElementById('joomlaid');
	var url = document.getElementById('thisurl' ).value + "?option=com_jwhmcs&controller=changeusername&task=validateUsername&username="+URLEncode(username)+"&joomlaid="+jid.value;
	var frm = document.forms['registerForm'];
	frm.validate.disabled = true;
	frm.submitit.disabled = true;
	msg.removeClass('invalid').removeClass('valid').addClass('checking');
	msg.set('html', "Checking Username..." );
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var resp = parseXml(xhr.responseText);
				var result = resp.getElementsByTagName("result")[0].childNodes[0].nodeValue;
				var message  = resp.getElementsByTagName("message")[0].childNodes[0].nodeValue;
				
				msg.set('html', message );
				val.setProperty('value', result);
				
				if (result == 1) {
					msg.removeClass('checking').addClass('valid');
					frm.submitit.disabled = false;
					frm.validate.disabled = false;
				} else {
					msg.removeClass('checking').addClass('invalid');
					frm.validate.disabled = false;
					frm.submitit.disabled = true;
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function validInfo(type, value)
{
	var msg = $('message');
	var img = $(type+"Result");
	var chk = $(type+"Checkmsg");
	var val = $(type+"Valid");
	var thisurl = $('thisurl');
	var url = thisurl.value + "index.php?option=com_jwhmcs&controller=register&task=validInfo&type="+URLEncode(type)+"&value="+URLEncode(value);
	
	msg.removeClass('msginvalid').removeClass('msgvalid').addClass('msgnotice');
	msg.set('html',chk.value);
	img.removeClass('imginvalid').removeClass('imgrequired').removeClass('imgnotice').removeClass('imgvalid').addClass('imgcheck');
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var resp = parseXml(xhr.responseText);
				var result = resp.getElementsByTagName("result")[0].childNodes[0].nodeValue;
				var message  = resp.getElementsByTagName("message")[0].childNodes[0].nodeValue;
				
				msg.set('html',message);
				
				if (result == 1) {
					msg.removeClass('msgnotice').removeClass('msginvalid').addClass('msgvalid');
					img.removeClass('imgnotice').removeClass('imginvalid').removeClass('imgcheck').addClass('imgvalid');
					val.setProperty('value', "1");
				} else {
					msg.removeClass('msgnotice').addClass('msginvalid');
					img.removeClass('imgcheck').addClass('imginvalid');
					val.setProperty('value', "");
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function verifyFtp(step) {

	var hostname	= $('FtpHostname');
	var port		= $('FtpPort');
	var username	= $('FtpUsername');
	var password	= $('FtpPassword');
	
	hostname		= encodeURIComponent(hostname.value);
	port			= encodeURIComponent(port.value);
	username		= encodeURIComponent(username.value);
	password		= encodeURIComponent(password.value);
	
	var variables	= "&hostname="+hostname+"&port="+port+"&username="+username+"&password="+password+"&step="+step;
	var url = "index.php?option=com_jwhmcs&controller=ajax&task=verifyFtp"+variables;
	
	var ajaxLog			= $('ajaxLog');
	var ajaxStat		= $('ajaxStatus');
	var ajaxMsgs		= $('ajaxMessage');
	var reqFtp			= $('reqFtp');
	var textWelcome		= $('textWelcome');
	var textApivalid	= $('textApivalid');
	
	ajaxStat.removeClass('ajaxWaiting').addClass('ajaxLoading');
	ajaxMsgs.removeClass('ajaxMessageWaiting').addClass('ajaxMessageLoading');
	ajaxMsgs.empty().set('html','Verifying Credentials - This may take a moment');
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var resp = parseXml(xhr.responseText);
				var nextStep = resp.getElementsByTagName("nextstep")[0].childNodes[0].nodeValue;
				var valid	 = resp.getElementsByTagName("status")[0].childNodes[0].nodeValue;
				var message  = resp.getElementsByTagName("message");
				var txt = ajaxLog.innerHTML;
				
				if (valid == 1) {
					var i=0;
					for (i=0; i<message.length; i++) {
						txt = "<span>" + message[i].childNodes[0].nodeValue + "</span>" + txt;
					}
					ajaxLog.set('html',txt);
					
					reqFtp.setStyle('visibility', 'collapse');
					ajaxStat.removeClass('ajaxWaiting').addClass('ajaxLoading');
					ajaxMsgs.removeClass('ajaxMessageWaiting').addClass('ajaxMessageLoading');
					ajaxMsgs.empty().set('html','Installing');
					textWelcome.removeClass('visDisplay').addClass('visHidden');
					textApivalid.removeClass('visHidden').addClass('visDisplay');
					$('step').setProperty('value', nextStep );
					runInstall(nextStep);
				} else {
					ajaxStat.removeClass('ajaxLoading').addClass('ajaxWaiting');
					ajaxMsgs.removeClass('ajaxMessageLoading').addClass('ajaxMessageWaiting');
					ajaxMsgs.empty().set('html',message[0].childNodes[0].nodeValue);
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function verifyPath(step)

{
	var whmcspath = $('whmcspath').value;
	whmcspath = encodeURIComponent(whmcspath);
	
	var ajaxLog  = $('ajaxLog');
	var ajaxStat = $('ajaxStatus');
	var ajaxMsgs = $('ajaxMessage');
	var origStep = $('step');
	var reqWhmcsPath = $('reqWhmcsPath');
	var textApivalid = $('textApivalid');
	var textFileinstall = $('textFileinstall');
	
	var url = $('thisUrl').getProperty('value')+"?option=com_jwhmcs&controller=ajax&task=verifyPath&whmcspath="+whmcspath+"&step="+step;
	
	ajaxStat.removeClass('ajaxWaiting').addClass('ajaxLoading');
	ajaxMsgs.removeClass('ajaxMessageWaiting').addClass('ajaxMessageLoading');
	ajaxMsgs.empty().set('html','Checking Path...');
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var resp = parseXml(xhr.responseText);
				var nextStep = resp.getElementsByTagName("nextstep")[0].childNodes[0].nodeValue;
				var valid	 = resp.getElementsByTagName("valid")[0].childNodes[0].nodeValue;
				
				var message  = resp.getElementsByTagName("message");
				var txt = ajaxLog.innerHTML;
				var i=0;
				
				for (i=0; i<message.length; i++) {
					txt = "<span>" + message[i].childNodes[0].nodeValue + "</span>" + txt;
				}
				ajaxLog.set('html',txt);
				if (valid == true) {
					$('step').setProperty('value', nextStep);
					reqWhmcsPath.setStyle('visibility', 'collapse');
					ajaxStat.removeClass('ajaxWaiting').addClass('ajaxLoading');
					ajaxMsgs.removeClass('ajaxMessageWaiting').addClass('ajaxMessageLoading');
					ajaxMsgs.empty().set('html','Installing');
					textApivalid.removeClass('visDisplay').addClass('visHidden');
					textFileinstall.removeClass('visHidden').addClass('visDisplay');
					runInstall(nextStep);
				} else {
					ajaxStat.removeClass('ajaxLoading').addClass('ajaxWaiting');
					ajaxMsgs.removeClass('ajaxMessageLoading').addClass('ajaxMessageWaiting');
					reqWhmcsPath.setStyle('visibility', 'visible');
					textApivalid.removeClass('visDisplay').addClass('visHidden');
					ajaxMsgs.empty().set('html','Path Error');
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}