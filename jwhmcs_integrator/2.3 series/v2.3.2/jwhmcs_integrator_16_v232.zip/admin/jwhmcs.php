<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: jwhmcs.php 169 2011-02-04 05:39:14Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
define( 'JWHMCS_VERS', '2.32' );

// Access check.
if (!JFactory::getUser()->authorise('core.manage', 'com_jwhmcs')) 
{
        return JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
}

require_once( JPATH_COMPONENT.DS.'controller.php' );
require_once( JPATH_COMPONENT.DS.'model.php' );

if($controller = JRequest::getWord('controller')) {
	$path = JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php';
	if (file_exists($path)) {
		require_once $path;
	} else {
		$controller = '';
	}
}

// Create the controller
$classname	= 'JwhmcsController'.$controller;
$controller	= new $classname( );

// Perform the Request task
$controller->execute( JRequest::getVar( 'task' ) );

// Redirect if set by the controller
$controller->redirect();