<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_( 'behavior.mootools' );
jimport('joomla.html.pane');

$pane =& JPane::getInstance('tabs');

$data = $this->data;

$imgbase = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/';
$j32jwhmcs = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-jwhmcs.png';
$j32helppage = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-helppage.png';
$j48check = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-48-chinst.png';
$j32checkfix = $imgbase.'j-32-checkfix.png';
$j32yes = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-yes.png';
$j16yes = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-16-yes.png';
$j32no = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-no.png';
$j16no = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-16-no.png';

echo $pane->startPane( 'tabs' );
echo $pane->startPanel( JText::_( "COM_JWHMCS_CHECK_VIEW_TAB_JOOMLA" ), 'joomla_check' );
?>
<table class="checkStarttbl toolbar">
	<tr>
		<td class="checkStartimg button">
			<a class="button" href="#" onclick="beginCheck(10,30,this); return false;" id="joomla_check_href1">
			<span class="checkStarttxt icon-48-checkrun"><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_BEGINCHECK" ); ?></span></a>
		</td>
	</tr>
</table>

<table class="admintable">
	<tbody>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_COMPONENTINSTALLED" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep10"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage10">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_HIDDENMENU" ); ?>
			</td>
			<td width="50px">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep20"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage20">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_CLIENTMENU" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep30"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage30">&nbsp;</div>
			</td>
		</tr>
	</tbody>
</table>

<?php 
echo $pane->endPanel();
echo $pane->startPanel( JText::_( "COM_JWHMCS_CHECK_VIEW_TAB_PLUGIN" ), 'plugin_check' );
?>
<table class="checkStarttbl toolbar">
	<tr>
		<td class="checkStartimg button">
			<a class="button" href="#" onclick="beginCheck(100,130,this); return false;" id="plugin_check_href1">
			<span class="checkStarttxt icon-48-checkrun"><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_BEGINCHECK" ); ?></span></a>
		</td>
	</tr>
</table>

<table class="admintable">
	<tbody>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_PLUGINAUTH" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep100"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage100">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_PLUGINSYSM" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep110"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage110">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_PLUGINLANG" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep120"></div></div>
			</td>
			<td>
				<div class="ajaxMessage" id="checkMessage120">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_PLUGINUSER" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep130"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage130">&nbsp;</div>
			</td>
		</tr>
	</tbody>
</table>

<?php
echo $pane->endPanel();
echo $pane->startPanel( JText::_( "COM_JWHMCS_CHECK_VIEW_TAB_WHMCS" ), 'whmcs_check' );
?>
<table class="checkStarttbl toolbar">
	<tr>
		<td class="checkStartimg button">
			<a class="button" href="#" onclick="beginCheck(200,240,this); return false;" id="whmcs_check_href1">
			<span class="checkStarttxt icon-48-checkrun"><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_BEGINCHECK" ); ?></span></a>
		</td>
	</tr>
</table>
<table class="admintable">
	<tbody>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_WHMCSROOT" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep200"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage200">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_WHMCSHOOK" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep210"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage210">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_WHMCSAPI" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep220"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage220">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_WHMCSTMPL" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep230"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage230">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_WHMCSDB" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep240"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage240">&nbsp;</div>
			</td>
		</tr>
	</tbody>
</table>
<?php
echo $pane->endPanel();
echo $pane->startPanel( JText::_( "COM_JWHMCS_CHECK_VIEW_TAB_PRODUCT" ), 'product_check' );
?>
<table class="checkStarttbl toolbar">
	<tr>
		<td class="checkStartimg button">
			<a href="#" onclick="beginCheck(300,310,this); return false;" id="product_check_href1">
			<span class="checkStarttxt icon-48-checkrun"><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_BEGINCHECK" ); ?></span></a>
		</td>
	</tr>
</table>
<table class="admintable">
	<tbody>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_PRODLIC" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep300"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage300">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_APICNXN" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep310"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage310">&nbsp;</div>
			</td>
		</tr>
		
	</tbody>
</table>
<?php
echo $pane->endPanel();
echo $pane->endPane();
?>


<form action="index.php" method="post" name="adminForm" id="adminForm">
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="thisUrl" id="thisUrl" value="<?php echo $data->thisUrl; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="controller" value="check" />
<input type="hidden" name="step" id="step" value="10" />
<input type="hidden" name="laststep" id="laststep" value="" />
</form>

<script language="javascript">
function beginCheck(step,last,caller)
{
	document.id('laststep').setProperty('value', last);
	
	for(i=step; i<=last; i=i+10) {
		ajaxStatus = document.getElementById('checkStep'+i);
		ajaxStatus.removeClass('ajaxLoading').removeClass('ajaxSuccess').removeClass('ajaxError').removeClass('ajaxAlert');
		ajaxMessage = document.getElementById('checkMessage'+i);
		ajaxMessage.set('html','');
	}
	runCheck(step);
}

function beginFix(step)
{
	ajaxStatus = document.getElementById('checkStep'+step);
	ajaxStatus.removeClass('ajaxLoading').removeClass('ajaxSuccess').removeClass('ajaxError').removeClass('ajaxAlert');
	ajaxMessage = document.getElementById('checkMessage'+step);
	ajaxMessage.set('html','');
	runFix(step);
}
</script>