<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    Joomla! 1.6 Package
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.3.3 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      2.3.0
 * 
 * @desc       Installation Script
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( "joomla.filesystem.file" );

/**
 * com_jwhmcs installation Script
 * @version		2.3.3
 * 
 * @since		2.3.1
 * @author		Steven
 */
class com_jwhmcsInstallerScript
{
	/**
	 * Run at the time of installation only
	 * @access		public
	 * @version		2.3.3
	 * @param		JApplication object	- $parent: calls this function
	 * 
	 * @since		2.3.1
	 */
	public function install( $parent ) 
	{
		JFile::move( JPATH_ADMINISTRATOR . DS . "components" . DS . "com_jwhmcs" . DS . "integrator.php", JPATH_LIBRARIES . DS . "joomla" . DS . "updater" . DS . "adapters" . DS . "integrator.php" );
		// $parent is the class calling this method
		$parent->getParent()->setRedirectURL( 'index.php?option=com_jwhmcs&controller=install&task=interview' );
	}
	
	
	/**
	 * Run at the time of uninstallation only
	 * @access		public
	 * @version		2.3.3
	 * @param		JApplication object	- $parent: calls this function
	 * 
	 * @since		2.3.1
	 */
	public function uninstall( $parent )
	{
		JFile::delete( JPATH_LIBRARIES . DS . "joomla" . DS . "updater" . DS . "adapters" . DS . "integrator.php" );
		return;
	}
	
	
	/**
	 * Run at the time of upgrade only
	 * @access		public
	 * @version		2.3.3
	 * @param		JApplication object	- $parent: calls this function
	 * 
	 * @since		2.3.1
	 */
	public function update( $parent )
	{
		JFile::move( JPATH_ADMINISTRATOR . DS . "components" . DS . "com_jwhmcs" . DS . "integrator.php", JPATH_LIBRARIES . DS . "joomla" . DS . "updater" . DS . "adapters" . DS . "integrator.php" );
		// $parent is the class calling this method
		$parent->getParent()->setRedirectURL( 'index.php?option=com_jwhmcs&controller=install&task=interview' );
	}
	
	
	/**
	 * Runs prior to installation, upgrade or uninstallation
	 * @access		public
	 * @version		2.3.3
	 * @param		string				- $type: the task being performed (install, upgrade etc)
	 * @param		JApplication object	- $parent: calls this function
	 * 
	 * @since		2.3.1
	 */
	public function preflight( $type, $parent )
	{
		return;
	}
	
	
	/**
	 * Runs after installation, upgrade or uninstallation
	 * @access		public
	 * @version		2.3.3
	 * @param		string				- $type: the task being performed (install, upgrade etc)
	 * @param		JApplication object	- $parent: calls this function
	 * 
	 * @since		2.3.1
	 */
	public function postflight( $type, $parent )
	{
		return;
	}
}