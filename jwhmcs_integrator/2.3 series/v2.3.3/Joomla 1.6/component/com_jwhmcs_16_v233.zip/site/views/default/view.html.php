<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    Joomla! 1.6 Package
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.3.3 ( $Id: view.html.php 223 2011-05-25 19:15:48Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.5.0
 * 
 * @desc       Default View:  This file handles assembling the data and rendering the view to the user
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * Default view is used to render the wrapper around WHMCS
 * @version		2.3.0
 * 
 * @since		1.5.0
 * @author		Steven
 */
class JwhmcsViewDefault extends JView
{
	/**
	 * Builds the view from the display task for the user
	 * @access		public
	 * @version		2.3.0
	 * @param 		string		$tpl - presumably a template name never used
	 * 
	 * @since		1.5.0
	 */
	public function display($tpl = null)
	{
		// Load data for register layout
		$app		= & JFactory::getApplication();
		$tplparams	=	$app->getParams();
		$params		= &	JwhmcsParams::getInstance();
		$uri		= &	JURI::getInstance();
		$document	= &	JFactory::getDocument();
		
		$whmcsurl	= & JUri::getInstance( $params->get( 'ApiUrl' ), true );
		$whmcsurl->setPath( rtrim( $whmcsurl->getPath(), "/" ) . "/includes/jscript/" );
		
		if ($params->get( 'RenderJqueryenable' )) {
			JHTML::script('jquery.js', $whmcsurl->toString( array( 'scheme', 'host', 'path' ) ), true);
			JHTML::script('com_jwhmcs/noconflict.js', array(), true );
		}
		
		$base = & $document->getBase();
		if( empty( $base ) ) {
			$document->setBase( $uri->toString( array('scheme', 'host', 'path') ) );
		}
		
		// Include CSS reset ?
		if ( $params->get( "RenderCssreset" ) ) {
			JHtml::stylesheet( "com_jwhmcs/wrapper.css", array(), true );
		}
		
		$this->assignRef('params',	$tplparams);
		
		parent::display($tpl);
		
	}
}