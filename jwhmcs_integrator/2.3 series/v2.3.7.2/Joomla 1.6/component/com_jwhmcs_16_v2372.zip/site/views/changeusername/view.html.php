<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    Joomla! 1.6 Package
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.3.7.2 ( $Id: view.html.php 223 2011-05-25 19:15:48Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      2.1.0
 * 
 * @desc       Change Username View:  This file handles requesting the username from new registrants
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * Changeusername view handles the view assembly for the user
 * @version 2.3.0
 * 
 * @since	2.1.0
 * @author	Steven
 */
class JwhmcsViewChangeusername extends JView
{
	/**
	 * Builds the view from the display task for the user
	 * @access	public
	 * @version	2.3.0
	 * @param	string		$tpl - presumably a template name, never used
	 * 
	 * @since	2.1.0
	 */
	public function display($tpl = null)
	{
		$app		= & JFactory::getApplication();
		$uri		= & JURI::getInstance();
		$model		= & $this->getModel();
		$user		= & JFactory::getUser();
		$data		= & $model->getData();
		
		// Verify that the user isn't a guest
		if ( $user->get( 'guest' ) )
			$data = false;
		
		// Redirect if no data or user is a guest
		if (! $data ) {
			$app->redirect( $uri->base() );
		}
		
		JHTML::script("com_jwhmcs/ajax.js", array(), true );
		JHTML::stylesheet( "com_jwhmcs/signup.css", array(), true );
		JHtml::stylesheet( "com_jwhmcs/register.css", array(), true );
		
		$this->assignRef('uriString',	$uri->toString( array( 'scheme', 'host', 'path' ) ) );
		$this->assignRef('data', $data);
		
		parent::display($tpl);
	}
}