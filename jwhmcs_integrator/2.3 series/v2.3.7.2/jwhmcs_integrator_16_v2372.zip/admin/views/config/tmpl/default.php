<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');
jimport('joomla.html.pane');

$pane =& JPane::getInstance('tabs'); 

$data = $this->data;

$glob_config	= $this->data->global;
$style_config	= $this->data->style;
$user_config	= $this->data->user;
$whmcs_config	= $this->data->whmcs;
$menus_config	= $this->data->menu;
$kayako_config	= $this->data->kayako;
$recap_config	= $this->data->recaptcha;
$reg_config		= $this->data->registration;
$lang_config	= $this->data->language;
$adv_config		= $this->data->install;

?>

<div class="tabWrapper">
<form action="index.php" method="post" name="adminForm">

<?php 
echo $pane->startPane( 'tabs' );
echo $pane->startPanel( JText::_("COM_JWHMCS_CONFIG_GLOBAL_TAB"), 'global_config' );

?>

<div id="globalCell">
	<table class="admintable">
		<?php foreach ($glob_config as $item): ?>
		<?php if (!$item->display) continue; ?>
		<tr>
			<td class="paramitem">
				<div class="paramname">
					<?php echo $item->name; ?></div>
				<div class="parameter">
					<?php echo $item->field; ?></div>
				<div class="paramdesc">
					<?php echo $item->desc; ?></div>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</div>

<?php 
echo $pane->endPanel();
echo $pane->startPanel( JText::_("COM_JWHMCS_CONFIG_USER_TAB"), 'user_config' );
?>

<div id="userCell">
	<table class="admintable">
		<?php foreach ($user_config as $item): ?>
		<?php if (!$item->display) continue; ?>
		<tr>
			<td class="paramitem">
				<div class="paramname">
					<?php echo $item->name; ?></div>
				<div class="parameter">
					<?php echo $item->field; ?></div>
				<div class="paramdesc">
					<?php echo $item->desc; ?></div>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</div>

<?php
echo $pane->endPanel();
if ($this->lic['kayako']):
echo $pane->startPanel( JText::_("COM_JWHMCS_CONFIG_KAYAKO_TAB"), 'kayako_config' );
?>

<div id="kayakoCell">
	<table class="admintable">
		<?php foreach ($kayako_config as $item): ?>
		<?php if (!$item->display) continue; ?>
		<tr>
			<td class="paramitem">
				<div class="paramname">
					<?php echo $item->name; ?></div>
				<div class="parameter">
					<?php echo $item->field; ?></div>
				<div class="paramdesc">
					<?php echo $item->desc; ?></div>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</div>

<?php
echo $pane->endPanel();
endif;
echo $pane->startPanel( JText::_("COM_JWHMCS_CONFIG_STYLE_TAB"), 'style_config' );

?>

<div id="styleCell">
	<table class="admintable">
		<?php foreach ($style_config as $item): ?>
		<?php if (!$item->display) continue; ?>
		<tr>
			<td class="paramitem">
				<div class="paramname">
					<?php echo $item->name; ?></div>
				<div class="parameter">
					<?php echo $item->field; ?></div>
				<div class="paramdesc">
					<?php echo $item->desc; ?></div>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</div>

<?php
echo $pane->endPanel();
echo $pane->startPanel( JText::_("COM_JWHMCS_CONFIG_REGISTRATION_TAB"), 'reg_config' );

?>

<div id="regCell">
	<table class="admintable">
		<?php foreach ($reg_config as $item): ?>
		<?php if (!$item->display) continue; ?>
		<tr>
			<td class="paramitem">
				<div class="paramname">
					<?php echo $item->name; ?></div>
				<div class="parameter">
					<?php echo $item->field; ?></div>
				<div class="paramdesc">
					<?php echo $item->desc; ?></div>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</div>

<?php
echo $pane->endPanel();
echo $pane->startPanel( JText::_("COM_JWHMCS_CONFIG_RECAPTCHA_TAB"), 'recap_config' );

?>

<div id="recapCell">
	<table class="admintable">
		<?php foreach ($recap_config as $item): ?>
		<?php if (!$item->display) continue; ?>
		<tr>
			<td class="paramitem">
				<div class="paramname">
					<?php echo $item->name; ?></div>
				<div class="parameter">
					<?php echo $item->field; ?></div>
				<div class="paramdesc">
					<?php echo $item->desc; ?></div>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</div>

<?php
echo $pane->endPanel();
echo $pane->startPanel( JText::_("COM_JWHMCS_CONFIG_LANGUAGE_TAB"), 'menu_lang' );

?>

<div id="langCell">
	<table class="admintable">
		<?php foreach ($lang_config as $item): ?>
		<?php if (!$item->display) continue; ?>
		<tr>
			<td class="paramitem">
				<div class="paramname">
					<?php echo $item->name; ?></div>
				<div class="parameter">
					<?php echo $item->field; ?></div>
				<div class="paramdesc">
					<?php echo $item->desc; ?></div>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</div>

<?php
echo $pane->endPanel();
echo $pane->startPanel( JText::_("COM_JWHMCS_CONFIG_MENU_TAB"), 'menu_config' );

?>

<div id="menusCell">
	<table class="admintable">
		<?php foreach ($menus_config as $item): ?>
		<?php if (!$item->display) continue; ?>
		<?php if ( (! $this->lic['kayako'] ) AND ( $item->key == "MenuKayako" ) ) continue; ?>
		<tr>
			<td class="paramitem">
				<div class="paramname">
					<?php echo $item->name; ?></div>
				<div class="parameter">
					<?php echo $item->field; ?></div>
				<div class="paramdesc">
					<?php echo $item->desc; ?></div>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</div>

<?php
echo $pane->endPanel();
echo $pane->startPanel( JText::_("COM_JWHMCS_CONFIG_INSTALL_TAB"), 'adv_config' );

?>

<div id="advCell">
	<table class="admintable">
		<?php foreach ($adv_config as $item): ?>
		<?php if (!$item->display) continue; ?>
		<tr>
			<td class="paramitem">
				<div class="paramname">
					<?php echo $item->name; ?></div>
				<div class="parameter">
					<?php echo $item->field; ?></div>
				<div class="paramdesc">
					<?php echo $item->desc; ?></div>
			</td>
		</tr>
		<?php endforeach; ?>
	</table>
</div>

<?php
echo $pane->endPanel();
echo $pane->endPane();
?>

<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="config" />
</form>
</div>