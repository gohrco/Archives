<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    Joomla! 1.6 Package
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.3.7.2 ( $Id: default.php 170 2011-02-04 20:58:54Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      2.1.0
 * 
 * @desc       This file contains the default model which allows the user and system to interact with the data
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
jimport( 'joomla.application.component.model' );	// Import model


/**
 * Default model
 * @version	2.3.0
 * 
 * @since	1.5.0
 * @author Steven
 */
class JwhmcsModelDefault extends JwhmcsModel
{
	/**
	 * Constructor
	 * @access	public
	 * 
	 * @since	1.5.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
}