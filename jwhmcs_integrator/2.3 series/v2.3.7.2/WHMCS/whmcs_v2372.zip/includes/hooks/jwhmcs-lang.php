<?php

define( 'JWHMCSLANGVERS', '2.3.7.2' );

/**
 * Language hook file for J!WHMCS Integrator
 *  
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    $Id: jwhmcs-lang.php 313 2011-10-18 12:33:46Z steven_gohigher $
 * @since      2.0.3
 */

/* ------------------------------------------------------------ *\
 * Language Array
 * 		Modify the values here to match your configuration.  The
 * 		first column ('Arabic', 'Danish', etc) contains the name
 * 		of the language file in WHMCS.  The second column contains
 * 		the JoomFish short tag being used in Joomla!  If your
 * 		language file isn't in this list, the default is English.
\* ------------------------------------------------------------ */
$langarray = array(	'Arabic'		=> 'ar',
					'Bulgarian'		=> 'bg',
					'Danish'		=> 'da',
					'Dutch'			=> 'nl',
					'English'		=> 'en',
					'French'		=> 'fr',
					'German'		=> 'de',
					'Italian'		=> 'it',
					'Norwegian'		=> 'nb',
					'Portuguese-br'	=> 'pt',
					'Portuguese-pt'	=> 'pt',
					'Spanish'		=> 'es',
					'Swedish'		=> 'sv',
					'Turkish'		=> 'tr'
				);

/* ------------------------------------------------------------ *\
 * JWHMCS Language Array
 * 		This is the basic language array that will be further
 * 		expanded in future versions.  For now, you can change
 * 		the translation of the loginemail field here.
\* ------------------------------------------------------------ */				
$jwhmcs_langarray = array(
							'English' => array(
								'loginemail' => "Username"
							),
							'Spanish' => array(
								'loginemail' => "Nombre de usuario"
							),
							'French' => array(
								'loginemail' => "Nom d'utilisateur"
							)
					);
					
/* ------------------------------------------------------------ *\
 * Error Array
 * 		These are the error messages that are displayed to your
 * 		users when login failures occur.  You can add translations
 * 		for any languages you are using in WHMCS.
\* ------------------------------------------------------------ */
$errorarray	= array(	'English' => array(
						'AUTH00P000'	=> "No password was provided!",
						'AUTH00P001'	=> "Your account cannot be located at this time.",
						'AUTH01P000'	=> "Unable to bring your account settings in line!",
						'AUTH01P001'	=> "Login denied! Your account has either been blocked or you have not activated it yet. Did you not get an activation e-mail and follow the validation link?",
						'AUTH01P002'	=> "Username or password is incorrect or you don't have an account yet.",
						'AUTH01P003'	=> "Unable to bring your account settings in line!",
						'AUTH01P004'	=> "Login denied! Your account has either been blocked or you have not activated it yet. Did you not get an activation e-mail and follow the validation link?",
						'AUTH01P010'	=> "Username or password is incorrect or you don't have an account yet.",
						'AUTH01P011'	=> "Username or password is incorrect or you don't have an account yet.",
						'AUTH01P021'	=> "There was a problem binding your account settings!",
						'AUTH01P022'	=> "There was a problem saving your account settings!",
						'AUTH01P023'	=> "There was a problem binding your account settings!",
						'AUTH01P024'	=> "There was a problem saving your account settings!",
						'AUTH02P000'	=> "Unable to bring your account settings in line!",
						'AUTH02P001'	=> "Login denied!  Your account is inactive or has been blocked.",
						'AUTH02P002'	=> "Username or password is incorrect or you don't have an account yet.",
						'AUTH02P010'	=> "Username or password is incorrect or you don't have an account yet.",
						'AUTH02P011'	=> "Username or password is incorrect or you don't have an account yet."
					),
					'Spanish' => array(
						'AUTH00P000'	=> "No se proporcionó una contraseña!",
						'AUTH00P001'	=> "Su cuenta no se puede encontrar en este momento.",
						'AUTH01P000'	=> "No se puede traer a su configuración de cuenta en línea!",
						'AUTH01P001'	=> "Ingresar negado! Su cuenta ha sido bloqueada o sea que no la ha activado todavía. ¿No has recibido un correo de activación y el enlace de validación?",
						'AUTH01P002'	=> "Nombre de usuario o contraseña es incorrecta o si no tienes una cuenta.",
						'AUTH01P003'	=> "No se puede traer a su configuración de cuenta en línea!",
						'AUTH01P004'	=> "Ingresar negado! Su cuenta ha sido bloqueada o sea que no la ha activado todavía. ¿No has recibido un correo de activación y el enlace de validación?",
						'AUTH01P010'	=> "Nombre de usuario o contraseña es incorrecta o si no tienes una cuenta.",
						'AUTH01P011'	=> "Nombre de usuario o contraseña es incorrecta o si no tienes una cuenta.",
						'AUTH01P021'	=> "Hubo un problema de unificación o desactivar esta función!",
						'AUTH01P022'	=> "Hubo un problema al guardar la configuración de la cuenta!",
						'AUTH01P023'	=> "Hubo un problema de unificación o desactivar esta función!",
						'AUTH01P024'	=> "Hubo un problema al guardar la configuración de la cuenta!",
						'AUTH02P000'	=> "No se puede traer a su configuración de cuenta en línea!",
						'AUTH02P001'	=> "Ingresar negado! Su cuenta está inactiva o ha sido bloqueada.",
						'AUTH02P002'	=> "Nombre de usuario o contraseña es incorrecta o si no tienes una cuenta.",
						'AUTH02P010'	=> "Nombre de usuario o contraseña es incorrecta o si no tienes una cuenta.",
						'AUTH02P011'	=> "Nombre de usuario o contraseña es incorrecta o si no tienes una cuenta."
					),
					'French' => array(
						'AUTH00P000'	=> "Aucun mot de passe a été fourni!",	
						'AUTH00P001'	=> "Votre compte ne peut être affichée en ce moment.",
						'AUTH01P000'	=> "Impossible de mettre les paramètres de votre compte en ligne!",	
						'AUTH01P001'	=> "Connectez-vous refusé! Votre compte a été bloqué ou soit vous ne l'avez pas encore activé. N'avez-vous pas obtenir une activation e-mail et suivez le lien de validation?",
						'AUTH01P002'	=> "Nom d'utilisateur ou mot de passe est incorrect ou vous n'avez pas encore de compte.",
						'AUTH01P003'	=> "Impossible de mettre les paramètres de votre compte en ligne!",
						'AUTH01P004'	=> "Connectez-vous refusé! Votre compte a été bloqué ou soit vous ne l'avez pas encore activé. N'avez-vous pas obtenir une activation e-mail et suivez le lien de validation?",
						'AUTH01P010'	=> "Nom d'utilisateur ou mot de passe est incorrect ou vous n'avez pas encore de compte.",
						'AUTH01P011'	=> "Nom d'utilisateur ou mot de passe est incorrect ou vous n'avez pas encore de compte.",
						'AUTH01P021'	=> "Il y avait un problème de liaison paramètres de votre compte!",
						'AUTH01P022'	=> "Il y avait un problème de sauvegarde des paramètres de votre compte!",
						'AUTH01P023'	=> "Il y avait un problème de liaison paramètres de votre compte!",
						'AUTH01P024'	=> "Il y avait un problème de sauvegarde des paramètres de votre compte!",
						'AUTH02P000'	=> "Impossible de mettre les paramètres de votre compte en ligne!",
						'AUTH02P001'	=> "Connectez-vous refusé! Votre compte est inactif ou a été bloquée.",
						'AUTH02P002'	=> "Nom d'utilisateur ou mot de passe est incorrect ou vous n'avez pas encore de compte.",
						'AUTH02P010'	=> "Nom d'utilisateur ou mot de passe est incorrect ou vous n'avez pas encore de compte.",
						'AUTH02P011'	=> "Nom d'utilisateur ou mot de passe est incorrect ou vous n'avez pas encore de compte."
					)
				);

add_hook("ClientAreaPage",19,"hook_ClientAreaPageLanguageBefore","");				
add_hook("ClientAreaPage",21,"hook_ClientAreaPageLanguageAfter","");


/* ------------------------------------------------------------ *\
 * Function:	hook_ClientAreaPageLanguageBefore
 * Purpose:		Hook called prior to main clientarea hook file
 * As of:		version 2.0.3 (March 2010)
\* ------------------------------------------------------------ */
function hook_ClientAreaPageLanguageBefore()
{
	global $smarty, $langarray, $jwhmcs_langarray;
	
	$settings			= getJwhmcsSettings();
	$selected_language	= $smarty->_tpl_vars['language'];
	
	if (! isset( $jwhmcs_langarray[$selected_language] ) ) $jwhmcs_langarray = $jwhmcs_langarray['English'];
	else $jwhmcs_langarray = $jwhmcs_langarray[$selected_language];
	
	if (!$settings['Enable']) return;
	
	$smarty->assign('langarray', $langarray);
	
	if (!$settings['UserEnable']) return;
	
	if ( $smarty->_tpl_vars['filename'] != 'pwreset' ) {
		$smarty->_tpl_vars['LANG']['loginemail']	= $jwhmcs_langarray['loginemail'];
	}
}

/* ------------------------------------------------------------ *\
 * Function:	hook_ClientAreaPageLanguageAfter
 * Purpose:		Run following retrieval of site
 * As of:		version 2.0.3 (March 2010)
\* ------------------------------------------------------------ */
function hook_ClientAreaPageLanguageAfter()
{
	global $smarty, $errormessage, $errorarray;
	$settings = getJwhmcsSettings();
	
	if (!$settings['Enable']) return;
	
	// Run if User Integration is enabled
	if ($settings['UserEnable']) {
		// WHMCS v4.5.1 / Integrator v 2.2.6
		// RESOLVED - BUG 10:  https://www.gohigheris.com/issues/show_bug.cgi?id=10
		if ( isset( $GLOBALS['HTTP_SESSION_VARS']['loginurlredirect'] ) ) {
			$url = parse_url( $GLOBALS['HTTP_SESSION_VARS']['loginurlredirect'] );
			$qrystr = ( isset( $url['query'] ) ? "&" . $url['query'] : null );
		}
		
		// Modify the form action from dologin to jwhmcs
		if ($faxn = $smarty->_tpl_vars['formaction']):
			$tmp	= explode('?', $faxn);
			if (substr($tmp[0], -11) == 'dologin.php') $tmp[0] = substr_replace($tmp[0], 'jwhmcs.php', -11);
			if ( empty( $tmp[1] ) )
			{
				if ($filename = $smarty->_tpl_vars['filename'])
				{
					$tmp[1] = "goto=" . $filename;
					if ( $action = $GLOBALS['action'] )
					{
						$tmp[1] .= "&action=" . $action;
					}
				}
			}
			
			$smarty->_tpl_vars['formaction'] = $tmp[0] . '?' . $tmp[1] . $qrystr . "&task=ulogin";
		// Form action doesn't exist... create in case we are on the order form
		else:
			if ( isset( $GLOBALS['_SESSION']['loginurlredirect'] ) ) {
				$base = (! empty( $GLOBALS['CONFIG']['SystemSSLURL'] ) ? $GLOBALS['CONFIG']['SystemSSLURL'] : $GLOBALS['CONFIG']['SystemURL'] ) . '/';
				$return	= base64_encode( $base . $GLOBALS['_SESSION']['loginurlredirect'] );
				$smarty->_tpl_vars['formaction'] = 'jwhmcs.php?task=ulogin&return=' . urlencode( $return );
			}
		endif;
	}
	
	// The rest deals with the Visual Integration
	if (!$settings['RenderEnable']) return;
	
	$langarrayrev		= array_flip($smarty->_tpl_vars['langarray']);
	
	$requrl = ( $GLOBALS['requesturl'] ? $GLOBALS['requesturl'] : basename($_SERVER['REQUEST_URI'] ));
	$curUrl = trim($smarty->_tpl_vars['systemurl'], "/")."/".$requrl;
	$uri = parse_url($curUrl);
	parse_str($uri['query'], $qry);
	
	$regex[0] = '/(href=\")([^\"]*<!-- LANGUAGE=)(.{2}).*?(\")/i';
	$regex[1] = '/<!-- LANGUAGE=(.{2}) -->/i';
	$regex[2] = '/%3C%21--\+LANGUAGE_REPLACE\+--%3E/i';
	$regex[3] = '/<!-- LANGUAGE_REPLACE -->/i';
	
	$body		= array('htmlheader' => $smarty->_tpl_vars['htmlheader'], 'htmlfooter' => $smarty->_tpl_vars['htmlfooter'] );
	$repl_url	= base64_encode( $smarty->_tpl_vars['systemurl'] . ( $smarty->_tpl_vars['filename'] == "index" ? "clientarea" : $smarty->_tpl_vars['filename'] ) . '.php' );
	
	foreach($body as $key => $value) {
		
		// Perform replacement of return url for JWHCMS Login Module
		$value = preg_replace( '`<!-- JWHMCS RETURN URL -->`', $repl_url, $value );
		
		preg_match_all( $regex[0], $value, $matches, PREG_SET_ORDER);
		
		if( count( $matches ) > 0 ) {
			foreach($matches as $match) {
				$qry['language'] = $langarrayrev[$match[3]];
				$uri['query'] = buildQuery($qry);
				$value = preg_replace('`'.$match[0].'`', $match[1].queryToString($uri).$match[4], $value );
			}
		}
		
		preg_match_all( $regex[1], $value, $matches, PREG_SET_ORDER);
		
		if( count( $matches ) > 0 ) {
			foreach( $matches as $match ) {
				$qry['language'] = $langarrayrev[$match[1]];
				$uri['query'] = buildQuery($qry);
				$value = preg_replace( '`'.$match[0].'`', queryToString($uri), $value );
			}
		}
		
		$value = preg_replace( $regex[2], $smarty->_tpl_vars['language'], $value );
		$value = preg_replace( $regex[3], $smarty->_tpl_vars['language'], $value );
		
		$smarty->assign( $key, $value );
	}
	
	// Change login failure message
	$selected_language = $smarty->_tpl_vars['language'];
	if (! isset( $errorarray[$selected_language] ) ) $selected_errors = $errorarray['English'];
	else $selected_errors = $errorarray[$selected_language];
	
	if ( ( isset ( $_REQUEST['incorrect'] ) ) && ( isset ( $_REQUEST['msg'] ) ) )
	{
		$debug = ( $smarty->_tpl_vars['JWHMCS']['Debug'] ? " ({$_REQUEST['msg']})" : "" );
		$smarty->_tpl_vars['LANG']['loginincorrect'] = $selected_errors[ $_REQUEST['msg'] ] . $debug;
	}
}

?>