<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: jwhmcs_sysm.php 228 2011-05-31 17:35:46Z steven_gohigher $
 * @since      1.5.0
 * 
 * @desc		This plugin redirects links to option=com_user&task=register to
 * 				the J!WHMCS component (com_jwhmcs) user registration to request
 * 				information from end customer for WHMCS.
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.plugin.plugin');

$curlfile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jwhmcs'.DS.'classes'.DS.'class.curl.php';
if (is_readable($curlfile)) include_once($curlfile);

/**
 * System Plugin
 *
 * @package		J!WHMCS Integrator 
 * @since 		1.5.0
 */
class plgSystemJwhmcs_sysm extends JPlugin {

	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param object $subject The object to observe
	 * @param 	array  $config  An array that holds the plugin configuration
	 * @since 1.5
	 */
	function plgSystemJwhmcs_sysm(& $subject, $config)
	{
		parent::__construct($subject, $config);
	}
	
	
	function onAfterInitialise()
	{
		
	}
	
	
	/**
	 * Redirect user if trying to register, edit or reset password accordingly
	 * @access		public
	 * @version		2.3.7.2
	 * @version		2.2.6 - Added checks for NewregRedirect and PwresetRedirect to prevent looping
	 * @version		1.5.3 - Added ability to redirect to WHMCS user registration or edit pages
	 * 
	 * @since		1.5.0
	 */
	public function onAfterRender()
	{
		if (! class_exists('JwhmcsParams') ) return;
		
		$app	= & JFactory::getApplication();
		
		if( $app->isAdmin() )
			return;	// Don't run if administrator
		
		$params	= & JwhmcsParams::getInstance();
		
		if ((! $params->get( 'UserEnable' )) || (! $params->get( 'Enable' )))
			return;	// Don't run if product or user integration disabled
		
		$user 		= & JFactory::getUser();
		$option 	=   JRequest::getCmd( 'option',	'',	'default',	'string' );		
		$task   	=   JRequest::getCmd( 'task',	'', 'default',	'string' );
		$view		=   JRequest::getVar( 'view',	'', 'default',	'string' );
		$layout		=   JRequest::getVar( 'layout',	'',	'default',	'string' );
		$newlink	=   null;
		
		if ( $option=='com_user' && ($task=='register' || $view=='register') ):
			// load J!WHMCS Registration page
			if ( $user->get('guest') ):
				if ( ( $params->get( 'RegMethod' )==1 ) && ( $params->get( 'NewregRedirect' ) != 1 ) ) {
					$uri = new JURI( $params->get( 'ApiUrl' ) );
					$uri->setPath( $uri->getPath() . '/register.php' );
					$newlink = $uri->toString();
				}
				elseif ($params->get( 'RegMethod' ) == 3 ) {
					// force Itemid
					$menuitem	= "&" . ( $params->get( 'RegMenu' ) ? "Itemid={$params->get( 'RegMenu' )}" : "controller=register" );
					$newlink = JRoute::_('index.php?option=com_jwhmcs'.$menuitem, false);
				}
			endif;
		endif;
		
		if ( $option=='com_user' && ( ( $task=='edit' || $view=='edit' ) || ( $view=='user' && $layout=='form' ) ) ):
			// load J!WHMCS Edit page
			if (! $user->get('guest') ):
				if ( ( $params->get( 'RegMethod' ) == 1 ) || ( $params->get( 'RegMethod' ) == 3 ) ) {
					$uri = new JURI( $params->get( 'ApiUrl' ) );
					$uri->setPath( $uri->getPath() . '/clientarea.php' );
					$uri->setVar( 'action', 'details' );
					$newlink = $uri->toString();
				}
			endif;
		endif;
		
		if ( $option=='com_user' && ($task=='reset' || $view=='reset') ):
			// load J!WHMCS Edit page
			if ( $user->get('guest') ):
				if ( ( ( $params->get( 'RegMethod' )== 1 ) && ( $params->get( 'PwresetRedirect' ) != 1 ) ) || ( $params->get( 'PwresetRedirect' ) == 2 ) ) {
					$uri = new JURI( $params->get( 'ApiUrl' ) );
					$uri->setPath( $uri->getPath() . '/pwreset.php' );
					$newlink = $uri->toString();
				}
				elseif ( ( $params->get( 'PwresetRedirect' ) == 1 ) && ( $params->get( 'PwresetMenu' ) ) && ( $params->get( 'PwresetMenu' ) != $Itemid ) ) {
					$newlink = JRoute::_( "index.php?Itemid={$params->get( 'PwresetMenu' )}", false );
					$mainframe->redirect( $newlink );
				}
			endif;
		endif;
		
		if ( $newlink != null ) {
			$app->redirect( $newlink );
		}
		
		return;
	}
}