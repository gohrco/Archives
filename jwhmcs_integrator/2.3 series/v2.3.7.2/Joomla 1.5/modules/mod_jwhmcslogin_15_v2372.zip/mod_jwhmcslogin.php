<?php
/**
 * @package		J!WHMCS Integrator:  Login Module
 * @copyright	Copyright (C) 2010 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: mod_jwhmcslogin.php 303 2011-09-29 17:43:33Z steven_gohigher $
 * @since		2.0.0
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.helper' );

// Include the syndicate functions only once
require_once( dirname(__FILE__).DS.'helper.php' );
$curlfile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jwhmcs'.DS.'classes'.DS.'class.curl.php';
if (is_readable($curlfile)) include_once($curlfile);
else return;

/* Status Possiblities:
 * 		False = not logged in at all
 * 		True  = Logged into Joomla, no WHMCS id
 * 		(int) = WHMCS ID to retrieve data with
 */
$status		= & modJwhmcsloginHelper::isLoggedin( $params );
$contact	=   modJwhmcsloginHelper::isContact( $status );
$cparams	= & JwhmcsParams::getInstance();
$user		= & JFactory::getUser();

JHTML::stylesheet( 'mod_jwhmcslogin.css', modJwhmcsloginHelper::getStylesheet() );

if (( $status === false ) || ( $status === true ))
{
	$jwhmcs		= modJwhmcsloginHelper::getCommon( $params, $cparams, $status, false );
	require(JModuleHelper::getLayoutPath('mod_jwhmcslogin', 'form'));
}
else
{
	$jwhmcs		= modJwhmcsloginHelper::getData( $params, $cparams, $status, $contact );
	
	// If we are using the Gravatar badge
	if ( $params->get( 'enable_gravatar', false ) ) {
		require ( JModuleHelper::getLayoutPath( 'mod_jwhmcslogin', 'badge' ) );
	}
	// Or else...
	else {
		require(JModuleHelper::getLayoutPath('mod_jwhmcslogin', 'info'));
	}
}
?>
