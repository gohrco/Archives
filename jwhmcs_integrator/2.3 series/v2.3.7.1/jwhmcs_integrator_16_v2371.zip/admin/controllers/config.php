<?php
/**
 * Configuration Controller for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: config.php 311 2011-10-18 01:55:05Z steven_gohigher $
 * @author     Go Higher Information Services
 * @since      1.5.1
 * 
 * @desc       This is the config controller for the backend of J!WHMCS Integrator
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.controllerform');
/*-- File Inclusions --*/


/**
 * JWHCMS Config Controller
 * @author		Steven
 * @version		2.3.7.1
 * @version		2.3.7		- October 2011:  Added ability to apply settings
 * 
 * @since		2.3.0
 */
class JwhmcsControllerConfig extends JControllerForm
{
	/**
	 * Constructor Method
	 * @access		public
	 * @version		2.3.7.1
	 * 
	 * @since		2.3.0
	 */
	public function __construct()
	{
		if (is_null(JRequest :: getVar( 'view'))) JRequest :: setVar('view', JRequest :: getVar( 'controller' ) );
		parent::__construct();
		
		$this->registerTask( 'cpanel',	'myredirect' );
		$this->registerTask( 'helppage',	'myredirect' );
	}
	
	
	/**
	 * Redirector method
	 * @access		public
	 * @version		2.3.7.1
	 * 
	 * @since		2.3.7
	 */
	public function myredirect()
	{
		$task	= $this->getTask();
		$task	= ( $task == 'cpanel' ? 'default' : $task );
		$link	= 'index.php?option=com_jwhmcs&controller=' . $task;
		$this->setRedirect( $link );
	}
	
	
	/**
	 * Save method
	 * @access		public
	 * @version		2.3.7.1
	 * @version		2.3.7		- October 2011:  Added ability to apply settings
	 * 
	 * @since		2.3.0
	 */
	public function save()
	{
		$model	= $this->getModel( 'config' );
		$task	= $this->getTask();
		
		if ($model->storeData())
			$msg = JText::_( "COM_JWHMCS_CONFIG_CTRL_SAVED" );
		else
			$msg = JText::_( "COM_JWHMCS_CONFIG_CTRL_ERROR" );
		
		
		$link = ( $task == 'apply' ?
					'index.php?option=com_jwhmcs&controller=config' :
					'index.php?option=com_jwhmcs'
				);
		$this->setRedirect($link, $msg);
	}
}