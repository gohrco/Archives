<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');
jimport( "joomla.user.helper" );
?>


<form action="index.php" method="post" name="adminForm">
	<table class="adminlist" cellpadding="1">
		<thead>
			<tr>
				<th class="title">
					<div class="jwhmcs-hdr"><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_LABEL_JUSERS' ); ?></div>
					<select name="filter_jusers" onchange="document.adminForm.submit(); ">
						<option value="0"<?php echo $this->sort['jusers']==0?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_ALL_USERS' ); ?></option>
						<option value="1"<?php echo $this->sort['jusers']==1?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_MATCHED_USERS_ONLY' ); ?></option>
						<option value="2"<?php echo $this->sort['jusers']==2?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_UNMATCHED_USERS_ONLY' ); ?></option>
					</select>
				</th>
				<th width="200" class="title" >
					<div class="jwhmcs-hdr"><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_LABEL_MATCHES' ); ?></div>
					<select name="filter_matches" onchange="document.adminForm.submit(); ">
						<option value="-1"<?php echo $this->sort['matches']==-1?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_UNMATCHED_USERS_ONLY' ); ?></option>
						<option value="0"<?php echo $this->sort['matches']==0?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_ALL_USERS' ); ?></option>
						<option value="1"<?php echo $this->sort['matches']==1?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_USER_MATCHES' ); ?></option>
						<option value="2"<?php echo $this->sort['matches']==2?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_FOUND_MATCHES' ); ?></option>
						<option value="3"<?php echo $this->sort['matches']==3?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_CREATED_MATCHES' ); ?></option>
						<option value="4"<?php echo $this->sort['matches']==4?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_GROUP_USERS' ); ?></option>
					</select>
				</th>
				<th width="300" class="title">
					<div class="jwhmcs-hdr"><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_LABEL_WUSERS' ); ?></div>
					<select name="filter_wusers" onchange="document.adminForm.submit(); ">
						<option value="0"<?php echo $this->sort['wusers']==0?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_ALL_USERS' ); ?></option>
						<option value="1"<?php echo $this->sort['wusers']==1?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_MATCHED_USERS_ONLY' ); ?></option>
						<option value="2"<?php echo $this->sort['wusers']==2?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_UNMATCHED_USERS_ONLY' ); ?></option>
					</select>
				</th>
			</tr>
			<tr>
				<th colspan="3" class="title">
					<?php echo JText::_( 'Filter' ); ?>:
					<input type="text" name="user_search" id="user_search" value="<?php echo $this->sort['user_search'] ?>" class="text_area" onchange="document.adminForm.submit();" />
					<button onclick="this.form.submit();"><?php echo JText::_( 'Go' ); ?></button>
					<button onclick="document.getElementById('user_search').value='';this.form.submit();"><?php echo JText::_( 'Reset' ); ?></button>
				</th>
			</tr>
			<tr>
				<th width="300" class="title">
					<div class="jwhmcs-hdr"><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_LABEL_JSORTBY' ); ?></div>
					<div class="jwhmcs-hdrsort">
					<?php echo $this->sort['joomla']; ?>
					</div>
				</th>
				<th width="200" class="title" >
				</th>
				<th width="300" class="title">
					<div class="jwhmcs-hdr"><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_LABEL_WSORTBY' ); ?></div>
					<div class="jwhmcs-hdrsort">
					<?php echo $this->sort['whmcs']; ?>
					</div>
				</th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="3">
					<?php echo $this->pagination->getListFooter(); ?>
				</td>
			</tr>
		</tfoot>
		<tbody>
		<?php
			$k = 0;
			for ($i=0, $n=count( $this->data ); $i < $n; $i++)
			{
				$row 	=& $this->data[$i];

				$img 	= $row->jblock ? 'publish_x.png' : 'tick.png';
				$task 	= $row->jblock ? 'unblock' : 'block';
				$alt 	= $row->jblock ? JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_JUSER_BLOCKED" ) : JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_JUSER_ENABLED" );
				
				$disp['break']	= false;
				$disp['find']	= false;
				$disp['findsub']= false;
				$disp['add']	= false;
				$disp['addsub']	= false;
				$disp['update']	= false;
				$disp['group']	= false;
				
				switch($row->xref_type):
				case '-1':
					$disp['findsub']= true;
					$disp['addsub']	= true;
					break;
				case '0':
				case '4':
					$disp['group'] = true;
					break;
				case null:
					$disp['find'] = true;
					$disp['add']	= true;
					break;
				case '8':
				case '9':
					$disp['break'] = true;
					break;
				default:
					$disp['break'] = true;
					$disp['update'] = true;
					break;
				endswitch;
				
				if ($row->jid):
					$jblock = $row->jblock ? 0 : 1;
					$jalign	= 'top';
					$groups	= array_flip( (array) JUserHelper::getUserGroups( $row->jid ) );
					
					$jcontent = '
					<strong>'.$row->jname.'</strong>
					<div style="margin-left: 30px; ">
						'.($row->xref_type==0?'':'US:  '.$row->jusername.'<br />').'
						'.implode( " | ", $groups ).'<br />
						<a href="mailto:'.$row->jemail.'">
							'.$row->jemail.'</a><br />
							';
					$jcontent .= JHtml::_("grid.published", $jblock, $i );
//						<a href="javascript:void(0);" onclick="return listItemTask(\'cb'.$i.'\,\''.$task.'\')">
//							<img src="images/admin/'.$img.'" width="16" height="16" border="0" alt="'.$alt.'" /></a>
					$jcontent .='	&nbsp;&nbsp;'.($row->xref_type===0 ? JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_GROUPID" ) : JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_JOOMLAID" ) ) .$row->jid.'
					</div>';
				else:
					$jalign	= 'middle';
					$jcontent = '
						<div style="vertical-align: middle; text-align: center; width: 100%; ">
						'.JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_NOJUSERM" ).'</div>';
				endif;
				
				if ($row->wid):
					$walign	= 'top';
					$wcontent = '
					<strong>
						'.$row->wfname.'&nbsp;'.$row->wlname.'</strong>
					<div style="margin-left: 30px; ">
						'.(isset($row->wcname)?$row->wcname.'<br />':'').'
						'.(isset($row->waddress1)?$row->waddress1.'<br />':'').'
						'.(isset($row->waddress2)?$row->waddress2.'<br />':'').'
						'.(isset($row->wcity)?$row->wcity.', ':'').'
						'.(isset($row->wstate)?$row->wstate.'  ':'').'
						'.(isset($row->wpostcode)?$row->wpostcode.'  ':'').'
						'.$row->wcountry.'<br />
						'.(isset($row->wphonenumber)?'Phone:  '.$row->wphonenumber.'<br />':'').'
						<a href="mailto:'.$row->wemail.'">
							'.$row->wemail.'</a><br />
						' . JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_WTXT{$row->xref_type}" ) . " #:  {$row->wid}
						</div>";
				else:
					$walign	= 'middle';
					$wcontent = '
						<div style="vertical-align: middle; text-align: center; width: 100%; ">
						'.JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_NOWUSER" ).'</div>';
				endif;
				
			?>
			<tr class="<?php echo "row$k"; ?>">
				<td style="vertical-align: <?php echo $jalign; ?>; ">
					<?php echo $jcontent; ?>
				</td>
				<td align="center" style="vertical-align: middle; ">
					<table class="axns" width="100%">
						<tbody>
							<tr>
								<td class="axnicon axnicon-x<?php echo $row->xref_type; ?>" width="40">&nbsp;</td>
								<td class="axnhdr"><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_X{$row->xref_type}" ); ?></td>
							</tr>
							<tr>
								<td width="40">&nbsp;</td>
								<td class="axnbtns">
									<table class="toolbar" width="75%">
										<tbody>
											<tr>
												<?php if ($disp['break']): ?>
												<td class="button">
													<a class="toolbar" href="<?php echo JRoute::_('index.php?option=com_jwhmcs&controller=usermgr&task=syncbreak&xa='.$row->jid.'&xb='.$row->wid.'&xt='.$row->xref_type); ?>">
														<span class="icon-32-userunlock" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_BRKMATCH" ); ?>">&nbsp;</span><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_BRKMATCH" ); ?></a>
												</td>
												<?php endif; ?>
												<?php if ($disp['find']): ?>
												<td class="button">
													<a class="toolbar" href="<?php echo JRoute::_('index.php?option=com_jwhmcs&controller=usermgr&task=sync&'.($row->wid?'whmcs':'joom').'id='.($row->wid?$row->wid:$row->jid)); ?>">
														<span class="icon-32-userfind" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_FNDMATCH" ); ?>">&nbsp;</span><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_FNDMATCH" ); ?></a>
												</td>
												<?php endif; ?>
												<?php if ($disp['findsub']): ?>
												<td class="button">
													<a class="toolbar" href="<?php echo JRoute::_("index.php?option=com_jwhmcs&controller=usermgr&task=sync&whsubid={$row->wid}"); ?>">
														<span class="icon-32-userfind" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_FNDMATCH" ); ?>">&nbsp;</span><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_FNDMATCH" ); ?></a>
												</td>
												<?php endif; ?>
												<?php if ($disp['add']): ?>
												<td class="button">
													<a class="toolbar" href="<?php echo JRoute::_('index.php?option=com_jwhmcs&controller=usermgr&task='.($row->wid?'joom':'whmcs').'add&'.($row->wid?'whmcs':'joomla').'id='.($row->wid?$row->wid:$row->jid)); ?>">
														<span class="icon-32-useradd" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_FORCEADD" ); ?>">&nbsp;</span><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_FORCEADD" ); ?></a>
												</td>
												<?php endif; ?>
												<?php if ($disp['addsub']): ?>
												<td class="button">
													<a class="toolbar" href="<?php echo JRoute::_("index.php?option=com_jwhmcs&controller=usermgr&task=joomadd&wcontid={$row->wid}"); ?>">
														<span class="icon-32-useradd" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_FORCEADD" ); ?>">&nbsp;</span><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_FORCEADD" ); ?></a>
												</td>
												<?php endif; ?>
												<?php if ($disp['update']): ?>
												<td class="button">
													<a class="toolbar" href="<?php echo JRoute::_('index.php?option=com_jwhmcs&controller=usermgr&task=changeUsername&xa='.$row->jid.'&xb='.$row->wid.'&xt='.$row->xref_type); ?>">
														<span class="icon-32-userupdate" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_CHUSERNAME" ); ?>">&nbsp;</span><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_CHUSERNAME" ); ?></a>
												</td>
												<?php endif; ?>
												<?php if ($disp['group']): ?>
												<td class="button">
													<a class="toolbar" href="<?php echo JRoute::_('index.php?option=com_jwhmcs&controller=grpmgr&task=userlist&cid='.$row->wid); ?>">
														<span class="icon-32-userunlock" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_MANGROUP" ); ?>">&nbsp;</span><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_MANGROUP" ); ?></a>
												</td>
												<?php endif; ?>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
					</table>
				</td>
				<td style="vertical-align: <?php echo $walign; ?>; ">
					<?php echo $wcontent; ?>
				</td>
			</tr>
			<?php
				$k = 1 - $k;
				}
			?>
		</tbody>
	</table>

	<input type="hidden" name="option" value="com_jwhmcs" />
	<input type="hidden" name="controller" value="usermgr" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="sortby" value="<?php echo $this->sort['sortby']; ?>" />
	<input type="hidden" name="sortord" value="<?php echo $this->sort['sortord']; ?>" />
	<?php echo JHTML::_( 'form.token' ); ?>
</form>