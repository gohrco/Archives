<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    Joomla! 1.6 Package
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.3.7.5 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      2.3.0
 * 
 * @desc       This file is a utility helper for JWHMCS Integrator
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
$curlfile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jwhmcs'.DS.'classes'.DS.'class.curl.php';
if (is_readable($curlfile)) include_once($curlfile);


/**
 * JwhmcsHelper class is a utility class for common tasks
 * @version 2.3.0
 * 
 * @since	2.3.0
 * @author	Steven
 */
class JwhmcsHelper
{
	/**
	 * Builds an array of countries for use in a select option box
	 * @access	public
	 * @version	2.3.0
	 * 
	 * @return	Array of countries as XX => Name
	 * @since	1.5.0
	 */
	public function buildCountries()
	{
		return array('AF' => 'Afghanistan', 'AX' => 'Aland Islands', 'AL' => 'Albania', 'DZ' => 'Algeria', 'AS' => 'American Samoa', 'AD' => 'Andorra', 'AO' => 'Angola', 'AI' => 'Anguilla', 'AQ' => 'Antarctica', 'AG' => 'Antigua And Barbuda', 'AR' => 'Argentina', 'AM' => 'Armenia', 'AW' => 'Aruba', 'AU' => 'Australia', 'AT' => 'Austria', 'AZ' => 'Azerbaijan', 'BS' => 'Bahamas', 'BH' => 'Bahrain', 'BD' => 'Bangladesh', 'BB' => 'Barbados', 'BY' => 'Belarus', 'BE' => 'Belgium', 'BZ' => 'Belize', 'BJ' => 'Benin', 'BM' => 'Bermuda', 'BT' => 'Bhutan', 'BO' => 'Bolivia', 'BA' => 'Bosnia And Herzegovina', 'BW' => 'Botswana', 'BV' => 'Bouvet Island', 'BR' => 'Brazil', 'IO' => 'British Indian Ocean Territory', 'BN' => 'Brunei Darussalam', 'BG' => 'Bulgaria', 'BF' => 'Burkina Faso', 'BI' => 'Burundi', 'KH' => 'Cambodia', 'CM' => 'Cameroon', 'CA' => 'Canada', 'CV' => 'Cape Verde', 'KY' => 'Cayman Islands', 'CF' => 'Central African Republic', 'TD' => 'Chad', 'CL' => 'Chile', 'CN' => 'China', 'CX' => 'Christmas Island', 'CC' => 'Cocos (Keeling) Islands', 'CO' => 'Colombia', 'KM' => 'Comoros', 'CG' => 'Congo', 'CD' => 'Congo, Democratic Republic', 'CK' => 'Cook Islands', 'CR' => 'Costa Rica', 'CI' => 'Cote D\'Ivoire', 'HR' => 'Croatia', 'CU' => 'Cuba', 'CY' => 'Cyprus', 'CZ' => 'Czech Republic', 'DK' => 'Denmark', 'DJ' => 'Djibouti', 'DM' => 'Dominica', 'DO' => 'Dominican Republic', 'EC' => 'Ecuador', 'EG' => 'Egypt', 'SV' => 'El Salvador', 'GQ' => 'Equatorial Guinea', 'ER' => 'Eritrea', 'EE' => 'Estonia', 'ET' => 'Ethiopia', 'FK' => 'Falkland Islands (Malvinas)', 'FO' => 'Faroe Islands', 'FJ' => 'Fiji', 'FI' => 'Finland', 'FR' => 'France', 'GF' => 'French Guiana', 'PF' => 'French Polynesia', 'TF' => 'French Southern Territories', 'GA' => 'Gabon', 'GM' => 'Gambia', 'GE' => 'Georgia', 'DE' => 'Germany', 'GH' => 'Ghana', 'GI' => 'Gibraltar', 'GR' => 'Greece', 'GL' => 'Greenland', 'GD' => 'Grenada', 'GP' => 'Guadeloupe', 'GU' => 'Guam', 'GT' => 'Guatemala', 'GG' => 'Guernsey', 'GN' => 'Guinea', 'GW' => 'Guinea-Bissau', 'GY' => 'Guyana', 'HT' => 'Haiti', 'HM' => 'Heard Island & Mcdonald Islands', 'VA' => 'Holy See (Vatican City State)', 'HN' => 'Honduras', 'HK' => 'Hong Kong', 'HU' => 'Hungary', 'IS' => 'Iceland', 'IN' => 'India', 'ID' => 'Indonesia', 'IR' => 'Iran, Islamic Republic Of', 'IQ' => 'Iraq', 'IE' => 'Ireland', 'IM' => 'Isle Of Man', 'IL' => 'Israel', 'IT' => 'Italy', 'JM' => 'Jamaica', 'JP' => 'Japan', 'JE' => 'Jersey', 'JO' => 'Jordan', 'KZ' => 'Kazakhstan', 'KE' => 'Kenya', 'KI' => 'Kiribati', 'KR' => 'Korea', 'KW' => 'Kuwait', 'KG' => 'Kyrgyzstan', 'LA' => 'Lao People\'s Democratic Republic', 'LV' => 'Latvia', 'LB' => 'Lebanon', 'LS' => 'Lesotho', 'LR' => 'Liberia', 'LY' => 'Libyan Arab Jamahiriya', 'LI' => 'Liechtenstein', 'LT' => 'Lithuania', 'LU' => 'Luxembourg', 'MO' => 'Macao', 'MK' => 'Macedonia', 'MG' => 'Madagascar', 'MW' => 'Malawi', 'MY' => 'Malaysia', 'MV' => 'Maldives', 'ML' => 'Mali', 'MT' => 'Malta', 'MH' => 'Marshall Islands', 'MQ' => 'Martinique', 'MR' => 'Mauritania', 'MU' => 'Mauritius', 'YT' => 'Mayotte', 'MX' => 'Mexico', 'FM' => 'Micronesia, Federated States Of', 'MD' => 'Moldova', 'MC' => 'Monaco', 'MN' => 'Mongolia', 'ME' => 'Montenegro', 'MS' => 'Montserrat', 'MA' => 'Morocco', 'MZ' => 'Mozambique', 'MM' => 'Myanmar', 'NA' => 'Namibia', 'NR' => 'Nauru', 'NP' => 'Nepal', 'NL' => 'Netherlands', 'AN' => 'Netherlands Antilles', 'NC' => 'New Caledonia', 'NZ' => 'New Zealand', 'NI' => 'Nicaragua', 'NE' => 'Niger', 'NG' => 'Nigeria', 'NU' => 'Niue', 'NF' => 'Norfolk Island', 'MP' => 'Northern Mariana Islands', 'NO' => 'Norway', 'OM' => 'Oman', 'PK' => 'Pakistan', 'PW' => 'Palau', 'PS' => 'Palestinian Territory, Occupied', 'PA' => 'Panama', 'PG' => 'Papua New Guinea', 'PY' => 'Paraguay', 'PE' => 'Peru', 'PH' => 'Philippines', 'PN' => 'Pitcairn', 'PL' => 'Poland', 'PT' => 'Portugal', 'PR' => 'Puerto Rico', 'QA' => 'Qatar', 'RE' => 'Reunion', 'RO' => 'Romania', 'RU' => 'Russian Federation', 'RW' => 'Rwanda', 'BL' => 'Saint Barthelemy', 'SH' => 'Saint Helena', 'KN' => 'Saint Kitts And Nevis', 'LC' => 'Saint Lucia', 'MF' => 'Saint Martin', 'PM' => 'Saint Pierre And Miquelon', 'VC' => 'Saint Vincent And Grenadines', 'WS' => 'Samoa', 'SM' => 'San Marino', 'ST' => 'Sao Tome And Principe', 'SA' => 'Saudi Arabia', 'SN' => 'Senegal', 'RS' => 'Serbia', 'SC' => 'Seychelles', 'SL' => 'Sierra Leone', 'SG' => 'Singapore', 'SK' => 'Slovakia', 'SI' => 'Slovenia', 'SB' => 'Solomon Islands', 'SO' => 'Somalia', 'ZA' => 'South Africa', 'GS' => 'South Georgia And Sandwich Isl.', 'ES' => 'Spain', 'LK' => 'Sri Lanka', 'SD' => 'Sudan', 'SR' => 'Suriname', 'SJ' => 'Svalbard And Jan Mayen', 'SZ' => 'Swaziland', 'SE' => 'Sweden', 'CH' => 'Switzerland', 'SY' => 'Syrian Arab Republic', 'TW' => 'Taiwan', 'TJ' => 'Tajikistan', 'TZ' => 'Tanzania', 'TH' => 'Thailand', 'TL' => 'Timor-Leste', 'TG' => 'Togo', 'TK' => 'Tokelau', 'TO' => 'Tonga', 'TT' => 'Trinidad And Tobago', 'TN' => 'Tunisia', 'TR' => 'Turkey', 'TM' => 'Turkmenistan', 'TC' => 'Turks And Caicos Islands', 'TV' => 'Tuvalu', 'UG' => 'Uganda', 'UA' => 'Ukraine', 'AE' => 'United Arab Emirates', 'GB' => 'United Kingdom', 'US' => 'United States', 'UM' => 'United States Outlying Islands', 'UY' => 'Uruguay', 'UZ' => 'Uzbekistan', 'VU' => 'Vanuatu', 'VE' => 'Venezuela', 'VN' => 'Viet Nam', 'VG' => 'Virgin Islands, British', 'VI' => 'Virgin Islands, U.S.', 'WF' => 'Wallis And Futuna', 'EH' => 'Western Sahara', 'YE' => 'Yemen', 'ZM' => 'Zambia', 'ZW' => 'Zimbabwe');
	}
	
	
	/**
	 * Builds a `name` for storage in the Joomla user object based on settings in component
	 * @access	public
	 * @version	2.3.0
	 * 
	 * @return	String containing the assembled name for storage
	 * @since	2.3.0
	 */
	public function buildName()
	{
		$params = & JwhmcsParams::getInstance();
		
		// Name Compilation for Joomla based on setting in component
		$coname	= ( JRequest::getVar('companyname') ? ' ('.JRequest::getVar('companyname').')' : null );
		$name	= null;
		
		switch ($params->get( 'JuserStore' ) ):
		case 3:
			$name = $coname;
		case 1:
			$name = JRequest::getVar('firstname').' '.JRequest::getVar('lastname').$name;
			break;
		case 4:
			$name = $coname;
		case 2:
			$name = JRequest::getVar('lastname').', '.JRequest::getVar('firstname').$name;
			break;
		endswitch;
		
		return $name;
	}
	
	
	/**
	 * Encodes a password for either Joomla or WHMCS and returns the hash
	 * @access	public
	 * @version	2.3.0
	 * @param 	string		$for:  whmcs || joomla
	 * @param	string		$encoded - contains the encoded password to retrieve salt with
	 * @param	string		$clear - contains the clear text password to encode
	 * 
	 * @return	String containing encoded password for comparison
	 * @since	2.1.0
	 */
	public function encodePassword( $for = "whmcs", $encoded = null, $clear = null )
	{
		if ( $encoded == null || $clear == null ) return;
		
		$data	= false;
		$pwexp	= explode(':', $encoded);
		
		switch ( $for ):
		case 'whmcs':
			
			$data	= md5($pwexp[1].$clear).':'.$pwexp[1];
			break;
			
		case 'joomla':
			
			if ( count( $pwexp ) > 1 ) {
				$salt		= $pwexp[1];
				$password	= JUserHelper::getCryptedPassword( $clear, $salt );
				$data		= $password . ":" . $salt;
			}
			else {
				$data		= JUserHelper::getCryptedPassword( $clear );
			}
			break;
			
		endswitch;
		
		return $data;
	}
	
	
	/**
	 * Gets actions that are permitted for a user to perform
	 * @access		public
	 * @version		2.3.7.5
	 * 
	 * @return		JObject containing action sets
	 * @since		1.00
	 */
	public function getActions()
	{
		$user		= JFactory::getUser();
		$result		= new JObject;
		
		$assetName	= "com_jwhmcs";
		$actions	= array(	'core.admin',
								'core.manage',
								'core.create',
								'core.edit',
								'core.delete'
		);
		
		foreach ($actions as $action) {
			$result->set($action,        $user->authorise($action, $assetName));
		}
		
		return $result;
	}
	
	
	/**
	 * Retrieves the user array from the request based on the type
	 * @access	public
	 * @version	2.3.0
	 * @param 	string		$type: joomla || whmcs
	 * 
	 * @return	Array containing user variables to use
	 * @since	2.3.0
	 */
	public function getUserArray( $type = "joomla" )
	{
		$data	= null;
		
		if ( JRequest::getVar( 'fromjwhmcs' ) ) {
			$data	= JwhmcsHelper::getSession( JRequest::getVar( 'token' ) );
		}
		else {
			// Because we can't send the entire post value to bind, we have to create new array
			$data = array(	'name'		=> JwhmcsHelper::buildName(),
							'username'	=> JRequest::getVar('username'),
							'email'		=> JRequest::getVar('email'),
							'password'	=> JRequest::getVar('password'),
							'password2'	=> JRequest::getVar('password2'),
							'task'		=> JRequest::getVar('task'),
							'id'		=> JRequest::getVar('id'),
							'groups'	=> array( JRequest::getVar('gid') )
			);
		}
		
		return $data;
	}
	
	
	/**
	 * Retrieves a set of variables for the session based upon passed token
	 * @access	public
	 * @version	2.3.0
	 * @param 	string		$token - contains the token to search by
	 * 
	 * @return	Array containing variables retrieved or false on error
	 * @since	2.0.0
	 */
	public function getSession( $token )
	{
		$db		= & JFactory::getDBO();
		$query	= "SELECT `value` FROM #__jwhmcs_sess WHERE token={$db->quote($token)}";
		$db->setQuery($query);
		
		if (! ( $result = $db->loadResult() ) ) {
			return false;
		}
		
		$tmp	= preg_split('/\n/', $result);
		$data	= array();
		
		foreach ($tmp as $t) {
			$var = explode('=', $t);
			$k = $var[0];
			array_shift( $var );
			$data[$k] = implode("=", $var);
			unset($var, $k);
		}
		
		$query = 'DELETE FROM #__jwhmcs_sess WHERE token="'.$token.'"';
		$db->setQuery($query);
		$res = $db->query();
		
		return $data;
	}
	
	
	/**
	 * Retrieves a WHMCS client or contact
	 * @access	public
	 * @version	2.3.0
	 * @param	mixed		$method - can be an email address or an integer representing the whmcs id / contact id
	 * @param	string		$by:	email || id
	 * @param	string		$type:  client || contact
	 * 
	 * @return	Array containing the user data from WHMCS or false on error or failure
	 * @since   2.0.0
	 */
	public function getWhmcsUser($method, $by = 'email', $type = 'client' )
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		switch($type):
		case 'client':
			if ($by == 'email') {
				$jcurl->setAction('getclientsdatabyemail', array('email' => $method));
			}
			else {
				$jcurl->setAction('getclientsdata', array('clientid' => $method));
			}
		
			$whmcs	= $jcurl->loadResult();
			
			// WHMCS v421:  Now receive array of array -- need to test for it
			if ( isset($whmcs[0]['result']) ) $whmcs = $whmcs[0];
			
			if (( isset($whmcs['result'])) && ($whmcs['result'] == 'success')) {
				$whmcs['xref_type'] = 'client';
				$ret = $whmcs;
			}
			else {
				$ret = false;
			}
			
			break;
		case 'contact':
			
			$jcurl->setAction('jwhmcsgetcontact', array("get" => "$by=$method"));
			$whmcs = $jcurl->loadResult();
			
			if ($whmcs['result'] == 'success') {
				$whmcs['userid'] = $whmcs['id'];
				$whmcs['xref_type'] = 'contact';
				$ret = $whmcs;
			}
			else {
				$ret = false;
			}
			break;
		endswitch;
		
		return $ret;
	}
	
	
	/**
	 * Determines if a username is actually an email address
	 * @access	public
	 * @version	2.3.0
	 * @param 	string		$username - Contains suspect username
	 * 
	 * @return	True if email, false if not
	 * @since	2.0.0
	 */
	public function isEmail( $username )
	{
		$pattern = "/\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,5}\b/i";
		$match = preg_match( $pattern, $username );
		
		return ( $match > 0 );
	}
	
	
	/**
	 * Sends an email to a newly registered user
	 * @access	public
	 * @version	2.3.0
	 * @param	object		$user - JUser object
	 * @param	string		$password - the clear text password to send in the email
	 * 
	 * @since	2.3.0
	 */
	public function sendMail( $user, $password )
	{
		$config	=   JFactory::getConfig();
		$lang	=   JFactory::getLanguage();
		$lang->load( 'com_jwhmcs', JPATH_ADMINISTRATOR );
		
		// Compute the mail subject.
		$emailSubject = JText::sprintf(
			"COM_JWHMCS_UTILITY_SENDMAIL_EMAIL_SUBJECT",
				$user->get( 'name' ),
				$config->get('sitename')
		);
		
		// Compute the mail body.
		$emailBody = JText::sprintf(
			"COM_JWHMCS_UTILITY_SENDMAIL_EMAIL_BODY",
			$user->get( 'name' ),
			$config->get('sitename'),
			JUri::root(),
			$user->get( 'username' ),
			$password
		);
		
		// Assemble the email data...the sexy way!
		$mail = JFactory::getMailer()
			->setSender(
				array(
					$config->get('mailfrom'),
					$config->get('fromname')
				)
			)
			->addRecipient($user->get( 'email' ) )
			->setSubject($emailSubject)
			->setBody($emailBody);
		echo "<pre>".print_r($mail,1)."</pre>"; die();
		if (!$mail->Send()) {
			JError::raiseWarning(500, JText::_('ERROR_SENDING_EMAIL'));
		}
		
		
		/*$app			= & JFactory::getApplication();
		$db				= & JFactory::getDBO();
		$name 			=   $user->get('name');
		$email 			=   $user->get('email');
		$username 		=   $user->get('username');
		$usersConfig 	= & JComponentHelper::getParams( 'com_users' );
		$sitename 		=   $app->getCfg( 'sitename' );
		$useractivation =   $usersConfig->get( 'useractivation' );
		$mailfrom 		=   $app->getCfg( 'mailfrom' );
		$fromname 		=   $app->getCfg( 'fromname' );
		$siteURL		=   JURI::base();
		$subject 		=   sprintf ( JText::_( 'Account details for' ), $name, $sitename);
		$subject 		=   html_entity_decode($subject, ENT_QUOTES);
		
		if ( $useractivation == 1 ) {
			$message = sprintf ( JText::_( 'SEND_MSG_ACTIVATE' ), $name, $sitename, $siteURL."index.php?option=com_user&task=activate&activation=".$user->get('activation'), $siteURL, $username, $password);
		}
		else {
			$message = sprintf ( JText::_( 'SEND_MSG' ), $name, $sitename, $siteURL);
		}
		
		$message = html_entity_decode($message, ENT_QUOTES);
		
		//get all super administrator
		$query = 'SELECT name, email, sendEmail' .
				' FROM #__users' .
				' WHERE LOWER( usertype ) = "super administrator"';
		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		
		// Send email to user
		if ( ! $mailfrom  || ! $fromname ) {
			$fromname = $rows[0]->name;
			$mailfrom = $rows[0]->email;
		}
		
		JUtility::sendMail($mailfrom, $fromname, $email, $subject, $message);

		// Send notification to all administrators
		$subject2 = sprintf ( JText::_( 'Account details for' ), $name, $sitename);
		$subject2 = html_entity_decode($subject2, ENT_QUOTES);
		
		// get superadministrators id
		foreach ( $rows as $row )
		{
			if ($row->sendEmail) {
				$message2 = sprintf ( JText::_( 'SEND_MSG_ADMIN' ), $row->name, $sitename, $name, $email, $username);
				$message2 = html_entity_decode($message2, ENT_QUOTES);
				JUtility::sendMail($mailfrom, $fromname, $row->email, $subject2, $message2);
			}
		}*/
	}
	
	
	/**
	 * Stores the session to the database returning an identifying token
	 * @access	public
	 * @version	2.3.0
	 * @param	array		$values - an associative array containing values to store
	 * 
	 * @return	String containing token to identify with
	 * @since	2.0.0
	 */
	public function storeSession($values = null)
	{
		$db =& JFactory::getDBO();
		
		// Create a new token
		$token = JUtility::getToken(true);
		
		if (!is_null($values)) {
			foreach ($values as $k => $v) {
				$val[] = $k.'='.$v;
			}
			$value = implode("\n", $val);
		}
		else {
			$value = null;
		}
		
		// Store UID, UEM and UPW in database for retrieval
		$query = 'INSERT INTO `#__jwhmcs_sess` (`token`, `value`) '
					.'VALUES ("'.$token.'", "'.$value.'")';
		$db->setQuery($query);
		$db->query();
		
		return $token;
	}
}