<?php defined('_JEXEC') or die('Restricted access');

jimport('joomla.html.pane');
JHTML::_('behavior.mootools');
JHTML::_('behavior.tooltip');
JHTML::_('behavior.formvalidation');

$ctryopts	= array();
foreach ($this->field['country'] as $key => $value) $ctryopts[] = JHTML::_('select.option', $key, $value);
$isNew	= (isset($this->data->id)?($this->data->id < 1?true:false):true);
?>
<form id="adminForm" name="adminForm" method="post" class="form-validate">
<div class="col100">
<table width="100%" class="admintable">
	<tr>
		<td width="200" align="right" class="key">
			<label for="name">
				<?php
				$title = JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WNAME" );
				echo JHTML::_('tooltip', null, $title, null, $title); ?>
			</label>
		</td>
		<td>
			<div class="jwhmcs-fieldwrap">
				<input class="text_area required" type="text" name="firstname" id="firstname" size="50" maxlength="255" value="<?php echo $isNew?'':$this->data->firstname; ?>" /><br />
				<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WFNAME" ); ?>
			</div>
			<div class="jwhmcs-fieldwrap">
				<input class="text_area required" type="text" name="lastname" id="lastname" size="50" maxlength="255" value="<?php echo $isNew?'':$this->data->lastname;?>" /><br />
				<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WFNAME" ); ?>
			</div>
		</td>
	</tr>
	<tr>
		<td width="200" align="right" class="key">
			<label for="companyname">
				<?php
				$title = JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCNAME" );
				echo JHTML::_('tooltip', null, $title, null, $title); ?>
			</label>
		</td>
		<td>
			<div class="jwhmcs-fieldwrap">
				<input class="text_area" type="text" name="companyname" id="companyname" size="50" maxlength="255" value="<?php echo $isNew?'':$this->data->companyname;?>" /><br />
				<?php echo $title; ?>
			</div>
		</td>
	</tr>
	<tr>
		<td width="200" align="right" class="key">
			<label for="Address">
				<?php
				$title = JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WADDR" );
				echo JHTML::_('tooltip', null, $title, null, $title); ?>
			</label>
		</td>
		<td>
			<div class="jwhmcs-fieldwrap">
				<input class="text_area required" type="text" name="address1" id="address1" size="50" maxlength="255" value="<?php echo $isNew?'':$this->data->address1;?>" /><br />
				<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WADDR1" ); ?>
			</div>
			<div class="jwhmcs-fieldwrap" style="clear: both; ">
				<input class="text_area" type="text" name="address2" id="address2" size="50" maxlength="255" value="<?php echo $isNew?'':$this->data->address2;?>" /><br />
				<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WADDR2" ); ?>
			</div>
		</td>
	</tr>
	<tr>
		<td width="200" align="right" class="key">
			<label for="Address">
				<?php
				$title = JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCSTZIP" );
				echo JHTML::_('tooltip', null, $title, null, $title); ?>
			</label>
		</td>
		<td>
			<div class="jwhmcs-fieldwrap">
				<input class="text_area required" type="text" name="city" id="city" size="40" maxlength="255" value="<?php echo $isNew?'':$this->data->city;?>" /><br />
				<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCITY" ); ?>
			</div>
			<div class="jwhmcs-fieldwrap">
				<input class="text_area required" type="text" name="state" id="state" size="10" maxlength="255" value="<?php echo $isNew?'':$this->data->state;?>" /><br />
				<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WSTATE" ); ?>
			</div>
			<div class="jwhmcs-fieldwrap">
				<input class="text_area required" type="text" name="postcode" id="postcode" size="20" maxlength="255" value="<?php echo $isNew?'':$this->data->postcode;?>" /><br />
				<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WPOSTAL" ); ?>
			</div>
			<div class="jwhmcs-fieldwrap">
				<?php echo JHTML::_('select.genericlist', $ctryopts, 'country', null, 'value', 'text', ($ctry = $isNew?$this->field['defaultcountry']:$this->data->country), 'country'); ?><br />
				<?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_LABEL_WCOUNTRY' ); ?>
			</div>
		</td>
	</tr>
	<tr>
		<td width="200" align="right" class="key">
			<label for="companyname">
				<?php
				$title = JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCONTACT" );
				echo JHTML::_('tooltip', null, $title, null, $title); ?>
			</label>
		</td>
		<td>
			<div class="jwhmcs-fieldwrap">
				<input class="text_area required" type="text" name="phonenumber" id="phonenumber" size="25" maxlength="255" value="<?php echo $isNew?'':$this->data->phonenumber;?>" /><br />
				<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WPHONE" ); ?>
			</div>
			<div class="jwhmcs-fieldwrap">
				<input class="text_area" type="text" name="email" id="email" size="50" maxlength="255" value="<?php echo $this->data->email;?>" disabled /><br />
				<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_EMAIL" ); ?>
			</div>
		</td>
	</tr>
</table>
</div>

<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="whmcsid" value="<?php echo $this->data->id; ?>" />
<input type="hidden" name="joomlaid" value="<?php echo $this->data->jid; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="subtask" value="<?php echo JRequest::getVar( 'task' ); ?>" />
<input type="hidden" name="controller" value="usermgr" />
<input type="hidden" name="email" value="<?php echo $this->data->email; ?>" />
<input type="hidden" name="password2" value="temppassword" />
</form>
<script language="javascript">
function myValidate(f) {
        if (document.formvalidator.isValid(f)) {
                return true; 
        }
        else {
                alert('Some values are not acceptable.  Please retry.');
        }
        return false;
}

function submitbutton(pressbutton) {
	var form = document.adminForm;

	if (pressbutton == 'cancel') {
		submitform( pressbutton );
		return;
	}

	if (myValidate(form) == true) {
		submitform( pressbutton );
	}
	
}
</script>