<?php
/**
 * J!WHMCS Integrator - User Plugin
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: jwhmcs_user.php 311 2011-10-18 01:55:05Z steven_gohigher $
 * @since      1.5.0
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.router' );
jimport( 'joomla.environment.uri' );
jimport( 'joomla.plugin.plugin' );

$curlfile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jwhmcs'.DS.'classes'.DS.'class.curl.php';
if (is_readable($curlfile)) include_once($curlfile);
require_once( JPATH_ADMINISTRATOR.DS."components".DS."com_jwhmcs".DS."helper.php" );

/* ------------------------------------------------------------ *\
 * Class:		plgUserJwhmcs_user
 * Extends:		JPlugin
 * Purpose:		Handles user integration and redirection
 * As of:		version 1.5.0
\* ------------------------------------------------------------ */
class plgUserJwhmcs_user extends JPlugin
{
	public $changeLock	= false;	// New with WHMCS 4.3 - lockable fields
	
	/* ------------------------------------------------------------ *\
	 * Function:	plgUserJwhmcs_user
	 * Purpose:		This is the constructor task
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		$this->loadLanguage();
	}
	
	
	function onUserBeforeSave( $user, $isnew )
	{
		if (! class_exists('JwhmcsParams') ) return;
		if ( defined( 'JWHMCS_AUTH' ) ) return;	// This must be coming from our own authentication plugin - don't try to add it back to WHMCS (loop)
		if ( defined( 'COMMUNITY_COM_PATH' ) ) return;	// Jom Social work around
		
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		if ((! $params->get( 'UserEnable' )) || (! $params->get( 'Enable' )))
			return;	// Don't run if product or user integration disabled
		
		if ( $isnew )
			return;	// Nothing to do if this is new
		
		if (! $params->get( 'WchangeLockables' ) )
			return; // We aren't allowed to change the lockable fields
		
		$jcurl->setAction( 'jwhmcsgetsettings', array( "get" => "ClientsProfileUneditableFields" ) );
		$whmcs	= $jcurl->loadResult();
		
		if ( $whmcs['result'] != 'success' )
			return; // Either a problem with api or WHMCS version not applicable
		
		$this->changeLock = $whmcs['clientsprofileuneditablefields'];
		
		$jcurl->setAction( 'jwhmcsgetsettings', array( "set" => "ClientsProfileUneditableFields=" ) );
		$whmcs = $jcurl->loadResult();
		
		if ( $whmcs['result'] != 'success' )
			$this->changeLock = false;
		
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	onAfterStoreUser
	 * Purpose:		Task after Joomla user is stored by Joomla
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 * 		* Modified parameters to reflect database change
	 *  2.0.2 (Feb 2010)
	 *  	* Corrected company name not being passed to addclient
	 *  1.5.3 (Oct 2009)
	 *  	+ Check for password being reset by user added
	 * 	1.5.1 (Sep 2009)
	 * 		+ encrypt passwords for user edits (WHMCS < 4.1 bug)
	\* ------------------------------------------------------------ */
	function onUserAfterSave($user, $isnew, $succes, $msg)
	{
		if (! class_exists('JwhmcsParams') ) return;
		if ( defined( 'JWHMCS_AUTH' ) ) return;	// This must be coming from our own authentication plugin - don't try to add it back to WHMCS (loop)
		if ( defined( 'COMMUNITY_COM_PATH' ) ) return;	// Jom Social work around
		
		$app	= & JFactory::getApplication();
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		if ((! $params->get( 'UserEnable' )) || (! $params->get( 'Enable' )))
			return;	// Don't run if product or user integration disabled
		
		// Check if the user is new - if so then addclient function
		if ($isnew):
			$action	= 'addclient';
			if (JRequest::getVar( 'usedata' )):
				$company = (JRequest::getVar('company') ? JRequest::getVar('company') : JRequest::getVar('companyname'));
				$fields['firstname']	= JRequest::getVar( 'firstname' );
				$fields['lastname']		= JRequest::getVar( 'lastname' );
				$fields['companyname']	= $company;
				$fields['address1']		= JRequest::getVar( 'address1' );
				$fields['address2']		= JRequest::getVar( 'address2' );
				$fields['city']			= JRequest::getVar( 'city' );
				$fields['state']		= JRequest::getVar( 'state' );
				$fields['postcode']		= JRequest::getVar( 'postcode' );
				$fields['country']		= JRequest::getVar( 'country' );
				$fields['phonenumber']	= JRequest::getVar( 'phonenumber' );
				$fields['currency']		= '1';
			else:
				$name = explode(' ', $user['name']);
				if (count($name)< 2) $name[1] = $name[0]; 
				$fields['firstname']	= $name[0];
				$fields['lastname']		= $name[1];
				$fields['address1']		= $params->get( 'WuserDefaultaddress' );
				$fields['city']			= $params->get( 'WuserDefaultcity' );
				$fields['state']		= $params->get( 'WuserDefaultstate' );
				$fields['postcode']		= $params->get( 'WuserDefaultpostal' );
				$fields['country']		= $params->get( 'WuserDefaultcountry' );
				$fields['phonenumber']	= $params->get( 'WuserDefaultphone' );
				$fields['currency']		= '1';
			endif;
			$fields['email']		= $user['email'];
			$fields['password2']	= JRequest::getVar( 'password' );
		else:
			
			// Retrieve existing whmcsid from xref db based on user_id
			$query = 'SELECT `xref_b` as `clientid`, `xref_type` FROM #__jwhmcs_xref '
						.'WHERE xref_a='.$user['id'].' AND xref_type BETWEEN 1 AND 9';
			$db->setQuery($query);
			$result = $db->loadAssoc();
			
			if (!$result)
				return;
			
			$type	= $this->_getType( $result['xref_type'] );
			$wuser	= JwhmcsHelper::getWhmcsUser( $result['clientid'], 'id', $type );
			$passwd	= $this->_getPassword( $wuser, $type );
			
			if (! $wuser )
				return;	// No user found to update
			
			switch ( $type ):
			case 'client':
				
				// Create the fields array for retrieving existing WHMCS user
				$action					= 'updateclient';
				$fields['clientid']		= $result['clientid'];
				$fields['email']		= $user['email'];
				if ( $passwd )
					$fields['password2']= $passwd;
				
				$fields['jwhmcs']		= 1;
				
				if ($app->isAdmin())
					$fields['status']	= (JRequest::getVar( 'block' )==1?'Inactive':'Active');
				
				break;
			case 'contact':
				$action = 'jwhmcsgetcontact';
				$newPw	= $passwd ? ";password={$passwd}" : "";
				
				$status	= '';
				if ( $app->isAdmin() )
					$status	= ";subaccount=" . ( JRequest::getVar( 'block' ) == 1 ? 0 : 1 );
					
				$fields['set']			= "id={$wuser['id']};email={$user['email']}" . $newPw . $status;
				
				break;
			endswitch;
		endif;
		
		// Pass function and parameters to cURL getting back the whmcs_id
		$jcurl->setAction($action, $fields);
		$whmcs	= $jcurl->loadResult();
		
		if ($isnew):
			// Store this new id w/ the user id in the xref db
			$query = 'INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) '
						.'VALUES ('.$user['id'].', 1, '.$whmcs['clientid'].')';
			$db->setQuery($query);
			$db->query();
		else:
			
			// WHMCS 4.3 - if lockable fields set, reset them here
			if ( $this->changeLock !== false ) {
				$jcurl->setAction( 'jwhmcsgetsettings', array( "set" => "ClientsProfileUneditableFields={$this->changeLock}" ) );
				$lockresults = $jcurl->loadResult();
			}
			
			if ($app->isAdmin())
				return;		// Don't redirect to WHMCS if Administrator
			
			$store = array( "clientid"	=> $whmcs["clientid"],
							"email"		=> $fields["email"],
							"password"	=> $fields["password2"],
							'timestamp'	=> $this->_get_timestamp()
							);
			
			// Store data for next jump
			$token = JwhmcsHelper::storeSession( $store );
			
			// Create URL for redirecting to WHMCS for loggin in
			$uri = & JURI::getInstance($params->get( 'ApiUrl' ));
			$uri->setScheme( 'http' . ( $params->get( 'RedirGatewayssl' ) ? 's' : '' ) );
			$uri->setPath( $uri->getPath() . '/jwhmcs.php' );
			$uri->setVar( 'task', 'ulogin' );
			$uri->setVar( 'a', $token );
			$uri->setVar( 'jwhmcs', '1' );
			$url = $uri->toString();
			$app->redirect($url);
		endif;
	}

	
	/* ------------------------------------------------------------ *\
	 * Function:	onBeforeDeleteUser
	 * Purpose:		Task run before deleting user in Joomla
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	function onUserBeforeDelete($user)
	{
		
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	onAfterDeleteUser
	 * Purpose:		Task run after deleting a user in Joomla
	 * As of:		version 1.5.0 (August 2009)
	\* ------------------------------------------------------------ */
	function onUserAfterDelete($user, $succes, $msg)
	{
		
	}

	
	/* ------------------------------------------------------------ *\
	 * Function:	onLoginUser
	 * Purpose:		Task run after user authenticated
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 * 		* Modified parameters to reflect database change
	\* ------------------------------------------------------------ */
	function onUserLogin($user, $options)
	{
		// 0:  Initialize variables
		if (! class_exists('JwhmcsParams') ) return;
		$db		= & JFactory::getDBO();
		$params	= & JwhmcsParams::getInstance();
		$app	= & JFactory::getApplication();
		$field	=   array();
		
		if ($app->isAdmin())
			return; // Dont run in admin
		
		if ((! $params->get( 'UserEnable' )) || (! $params->get( 'Enable' )))
			return;	// Don't run if product or user integration disabled
		
		if ( $user['type'] != 'jwhmcs_auth' )
			return; // Something else authenticated, so we dont have a clear password to send to WHMCS
		
		// Check to make sure user can login to WHMCS
		if ( $this->_checkLogin($user) !== true )
			return;
		
		// 2:  Store variables to database and get token back from function
		$juri = & JURI::getInstance();
		
		$field['email']		= $user['email'];
		$field['password']	= $user['password'];
		if ($goto = JRequest::getVar( 'goto' )) $field['goto'] = $goto;
		
		$jwhmcstask = JRequest::getVar( 'jwhmcstask' );
		if ( trim ($jwhmcstask) == '' ) $jwhmcstask = 'ulogin';
		
		$field['remember']	= JRequest::getVar( 'remember' );
		$field['return']	= $this->_getReturn($options);
		$field['timestamp'] = $this->_get_timestamp();
		
		$token = JwhmcsHelper::storeSession($field);
		
		$uri = & JURI::getInstance($params->get( 'ApiUrl' ), true);
		$uri->setScheme( 'http' . ( $params->get( 'RedirGatewayssl' ) ? 's' : '' ) );
		$uri->setPath( $uri->getPath() . '/jwhmcs.php' );
		$uri->setVar( 'task', $jwhmcstask );
		$uri->setVar( 'a', $token );
		$uri->setVar( 'jwhmcs', '1' );
		
		// 3:  Create URL for redirecting to WHMCS for loggin in
		$url = $uri->toString(); // 'http'.($params->get( 'RedirGatewayssl' )?'s':'').'://'.$params->get( 'ApiUrl' ).'/jwhmcs.php?task=login&a='.$token;
		$app->redirect($url);
	}

	
	/* ------------------------------------------------------------ *\
	 * Function:	onLogoutUser
	 * Purpose:		Task run after user logs out
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 * 		* Modified parameters to reflect database change
	\* ------------------------------------------------------------ */
	function onUserLogout($user)
	{
		if (! class_exists('JwhmcsParams') ) return;
		$params	= & JwhmcsParams::getInstance();
		$app	= & JFactory::getApplication();
		
		if ($app->isAdmin())
			return; // Dont run in admin
		
		if ((! $params->get( 'UserEnable' )) || (! $params->get( 'Enable' )))
			return;	// Don't run if product or user integration disabled
		
		// Since we are the last user plugin to run before redirection kill cookie
		setcookie( JUtility::getHash('JLOGIN_REMEMBER'), false, time() - 86400, '/' );
		
		// Create URL for redirecting to WHMCS for loggin out
		$uri = & JURI::getInstance($params->get( 'ApiUrl' ));
		$uri->setScheme( 'http' . ( $params->get( 'RedirGatewayssl' ) ? 's' : '' ) );
		$uri->setPath( $uri->getPath() . '/jwhmcs.php' );
		$uri->setVar( 'task', 'ulogout' );
		$uri->setVar( 'jwhmcsout', '1' );
		$url = $uri->toString();	// 'http'.($params->get( 'RedirGatewayssl' )?'s':'').'://'.$params->get( 'ApiUrl' ).'/logout.php?goto=jwhmcs';
		$app->redirect($url);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkLogin (private)
	 * Purpose:		Checks the xref_type for the user that is logging
	 * 				in to see if additional actions need to be taken.
	 * 				1 = all is matched up ok - proceed
	 * 				2 = change password in WHMCS first, then proceed
	 * 				3 = redirect to component asking for new password
	 * 				4 = user belongs to a group, pull that grp info
	 * As of:		version 1.5.0
	 * 
	 * Revisions:
	 *  1.5.1 (Sept 2009)
	 *   	+ Added group ability
	\* ------------------------------------------------------------ */
	private function _checkLogin(&$user)
	{
		// 0:  Initialize variables
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		// 1:  Set query to pull xref table to check type
		$query = 'SELECT `xref_a` as `joomlaid`, `xref_type` as `type`, `xref_b` as `clientid` FROM #__jwhmcs_xref AS x INNER JOIN #__users AS a ON x.xref_a = a.id '
					.'WHERE a.username ="'.$user['username'].'" AND xref_type BETWEEN 1 AND 9';
		$db->setQuery($query);
		$result = $db->loadAssoc();
		
		// 2:  Test for types, failing if none found
		if (!$result)	// User isn't matched to anyone in WHMCS don't bother logging in
			return false;
		
		$type	= $this->_getType( $result['type'] );
		
		switch ($result['type']):
		case 1:			// Everything is ok - user already matched up
		case 5:			// Subaccount user is matched without issue
			return true;
			break;
		case 2:			// User was matched up by Admin, change pw in WHMCS
		case 3:			// User account added by admin in Joomla, change pw in WHMCS
		case 6:			// Subaccount was matched up by Admin, change pw in WHMCS
		case 7:			// Subaccount was added by admin in Joomla, change pw in WHMCS (used?)
			// Retrieve matching data from WHMCS
			$whmcs	= JwhmcsHelper::getWhmcsUser( $user['email'], 'email', $type );
			$whmcs['xref_type']	= ( $type == 'client' ? 2 : 6 );
			
			// Test password in WHMCS first
			$testpw	= $this->_testWhmcsPassword($whmcs['password'], $user['password']);
			
			// If correct we will update xref
			if ($testpw) {
				$return = true;
			}
			// Password is incorrect, so can we resync it?
			elseif ($params->get( 'WuserAutosync')) {
				$change = $this->_changeWhmcsPassword($whmcs['id'], $user['password'], $whmcs['xref_type']);
			
				// Negative result on change
				if (! $change)
					return false;
			}
			// Password is incorrect and we can't resync it
			else {
				return false;
			}
			
			$query	= "UPDATE `#__jwhmcs_xref` SET `xref_type` = ".( $whmcs['xref_type'] == 2 ? "1" : "5" )." WHERE xref_a = {$result['joomlaid']} AND xref_b = {$result['clientid']}";
			$db->setQuery($query);
			return $db->query();
			
			break;
		case 4:			// User belongs to a group
			$query	= 'SELECT u.`password` as `passwd`, u.`email` as `email` '
						.' FROM #__jwhmcs_group as u '
						.' WHERE u.id = '.$result['clientid'];
			$db->setQuery($query);
			
			if ($result = $db->loadAssoc()) {
				$user['email']		= $result['email'];
				$user['username']	= $result['username'];
				$user['password']	= $result['passwd'];
				$return = true;
			}
			else
				$return = false;
			
			break;
		case 8:
		case 9:
			$uri = & JURI::getInstance();
			$app = & JFactory::getApplication();
			
			// We have to store the password for the next jump
			$token = JwhmcsHelper::storeSession( array( 'password' => $user['password'] ) );
			
			$uri->setVar( 'option',	'com_jwhmcs' );
			$uri->setVar( 'controller',	'changeusername' );
			$uri->setVar( 'view',	'changeusername' );
			$uri->setVar( 'layout',	'default' );
			$uri->setVar( 'task',	'display' );
			$uri->setVar( 'token',	$token );
			if ( JRequest::getVar( 'jwhmcs' ) ) $uri->setVar( 'jwhmcs', JRequest::getVar( 'jwhmcs' ) );
			
			$query = $uri->getQuery();
			
			$url = JRoute::_( "index.php?{$query}" );
			
			$app->redirect( $url );
			
		endswitch;
		
		// 3:  Return true or false
		if ($return)
			return true;
		
		return false;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_testWhmcsPassword (private)
	 * Purpose:		Validates a WHMCS Password
	 * As of:		2.1.0 (April 2010)
	\* ------------------------------------------------------------ */
	private function _testWhmcsPassword($encoded, $clear)
	{
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		if ($params->get( 'WhmcsNomd5' )) {	// We are not using MD5
			$jcurl->setAction('decryptpassword', array('password2' => $encoded));
			$whmcs	= $jcurl->loadResult();
			
			if ($whmcs['result'] == 'success') { 
				$return = ( $whmcs['password'] == $clear ? true : false );
			}
		}
		else {	// We are using MD5 here
			$testpw = JwhmcsHelper::encodePassword( "whmcs", $encoded, $clear );
			$return = ( $testpw == $encoded ? $testpw : false );
		}
		return $return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getPassword (private)
	 * Purpose:		Wrapper for retrieving what the password should be
	 * As of:		2.1.12rc2 (August 2010)
	\* ------------------------------------------------------------ */
	private function _getPassword( $wuser, $type )
	{
		$newPassword	= ( ( $pass = JRequest::getVar( 'password1' ) ) ? $pass : ( $pass = JRequest::getVar( 'password' ) ) ? $pass : false );
		 
		if ( $newPassword === false ) {
			return false;
		}
		else 
		{
			return $this->_findWhmcsPassword( ($type == 'client' ? $wuser['clientid'] : $wuser['id'] ), $newPassword, $type );
		} 
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_findWhmcsPassword (private)
	 * Purpose:		Determine the password to use for WHMCS
	 * As of:		2.1.0 (April 2010)
	\* ------------------------------------------------------------ */
	private function _findWhmcsPassword($clientid, $password, $type = 'client' )
	{
		$jcurl			= & JwhmcsCurl::getInstance();
		$params			= & JwhmcsParams::getInstance();
		$usepassword	=   $password;
		
		// If WHMCS version 4.1 or higher, return password clear text
		if ( ( str_replace(".", "", $params->get( 'WhmcsVersion' ) ) < 410 ) || $type == 'contact' ) {
			// We must encode the password for WHMCS < 4.1
			switch ( $type ):
			case 'contact':
				$jcurl->setAction( "jwhmcsgetcontact", array( 'get' => "id={$clientid}" ) );
				break;
			case 'client':
				$jcurl->setAction ( "getclientpassword", array( 'userid' => $clientid ) );
				break;
			endswitch;
			
			$whmcs	= $jcurl->loadResult();
			
			// Explode password hash to get salt and resalt new password and return
			$pwexp	= explode(':', $whmcs['password']);
			$usepassword = md5($pwexp[1].$password).':'.$pwexp[1];
		}
		
		return $usepassword;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_changeWhmcsPassword (private)
	 * Purpose:		Pulls the current WHMCS password, grabbing the salt
	 * 				and md5's the new password, returning it to calling
	 * 				function
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 * 		* Modified parameters to reflect database change
	 * 		- Removed call to WHMCS through curl to test for version
	\* ------------------------------------------------------------ */
	private function _changeWhmcsPassword($clientid, $password, $type = 2)
	{
		$jcurl			= & JwhmcsCurl::getInstance();
		
		$usepassword	=   $this->_findWhmcsPassword($clientid, $password);
		
		// Subaccounts
		if ($type == 6 ) {
			$fields['set']			= "id={$clientid};password=$usepassword";
			$action = 'jwhmcsgetcontact';
		}
		// Regular clients
		else {
			$fields['clientid']		= $clientid;
			$fields['password2']	= $usepassword;
			$action = 'updateclient';
		}
		
		$jcurl->setAction($action, $fields);
		$whmcs	= $jcurl->loadResult();
		
		return ( $whmcs['result']=='success' ? true : false );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getReturn (private)
	 * Purpose:		Sends correct return back based on login method
	 * As of:		2.0.2 (Mar 2010)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 * 		* Modified parameters to reflect database change
	 * 	2.0.4 (Mar 2010)
	 * 		* Corrected return variable issue
	\* ------------------------------------------------------------ */
	private function _getReturn(&$options)
	{
		$juri	= & JURI::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		if (JRequest::getVar( 'whmcs' ) || JRequest::getVar( 'return' )) {
			return JRequest::getVar( 'return' );
		}
		
		return base64_encode( $params->get( 'RedirLoginurl' ) );
	}
	
	
	private function _getType( $xref_type )
	{
		$check	= array(	'client'	=> array( 1, 2, 3, 8 ),
							'contact'	=> array( 5, 6, 7, 9 ),
							'group'		=> array( 4 )
		);
		
		foreach ( $check as $type => $xrefs ) {
			if ( in_array( $xref_type, $xrefs ) ) return $type;
		}
		
		return false;
	}
	
	
	/**
	 * Single location to retrieve a timestamp
	 * @access		private
	 * @version		2.3.7.5
	 * 
	 * @return		integer containing timestamp
	 * @since		2.3.6
	 */
	private function _get_timestamp()
	{
		$ts		= null;
		$otz	= date_default_timezone_get();
		date_default_timezone_set( 'UTC' );
		$ts		= strtotime(gmdate("M d Y H:i:s", time())) + 30;
		date_default_timezone_set($otz);
		return $ts;
	}
	
}