<?php defined('_JEXEC') or die('Restricted access');

jimport('joomla.html.pane');
JHTML::_('behavior.mootools');
JHTML::_('behavior.tooltip');
JHTML::_('behavior.formvalidation');

$isNew	= (isset($this->data->id)?($this->data->id < 1?true:false):true); 
?>

<form id="adminForm" name="adminForm" method="post" class="form-validate">
<div class="col100">
<table width="100%" class="admintable">
	<tr>
		<td width="200" align="right" class="key">
			<label for="name">
				<?php
				$title = JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WNAME" );
				echo JHTML::_('tooltip', JText::_( "COM_JWHMCS_GRPMGR_VIEW_TIP_WNAME" ), $title, null, $title); ?>
			</label>
		</td>
		<td>
			<div class="jwhmcs-fieldwrap">
				<input class="text_area required" type="text" name="fname" id="fname" size="40" maxlength="255" value="<?php echo $isNew?'':$this->data->fname;?>" /><br />
				<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WFNAME" ); ?>
			</div>
			<div class="jwhmcs-fieldwrap">
				<input class="text_area required" type="text" name="lname" id="lname" size="40" maxlength="255" value="<?php echo $isNew?'':$this->data->lname;?>" /><br />
				<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WLNAME" ); ?>
			</div>
		</td>
	</tr>
	<tr>
		<td width="200" align="right" class="key">
			<label for="companyname">
				<?php
				$title = JText::_( 'COM_JWHMCS_USERMGR_VIEW_LABEL_WCNAME' );
				echo JHTML::_('tooltip', JText::_( 'COM_JWHMCS_GRPMGR_VIEW_TIP_WFNAME' ), $title, null, $title); ?>
			</label>
		</td>
		<td>
			<div class="jwhmcs-fieldwrap">
				<input class="text_area" type="text" name="cname" id="cname" size="40" maxlength="255" value="<?php echo $isNew?'':$this->data->cname;?>" /><br />
				<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCNAME" ); ?>
			</div>
		</td>
	</tr>
	<tr>
		<td width="200" align="right" class="key">
			<label for="email">
				<?php
				$title = JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_EMAIL" );
				echo JHTML::_('tooltip', JText::_( "COM_JWHMCS_GRPMGR_VIEW_TIP_EMAIL" ), $title, null, $title); ?>
			</label>
		</td>
		<td>
			<div class="jwhmcs-fieldwrap">
				<input class="text_area required" type="text" name="email" id="email" size="40" maxlength="255" value="<?php echo $isNew?'':$this->data->email;?>" /><br />
				<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_EMAIL" ); ?>
			</div>
		</td>
	</tr>
	<tr>
		<td width="200" align="right" class="key">
			<label for="password">
				<?php
				$title = JText::_( "COM_JWHMCS_GRPMGR_VIEW_LABEL_PASS" );
				echo JHTML::_('tooltip', JText::_( "COM_JWHMCS_GRPMGR_VIEW_TIP_PASS" ), $title, null, $title); ?>
			</label>
		</td>
		<td>
			<div class="jwhmcs-fieldwrap">
				<input class="text_area required" type="text" name="password" id="password" size="40" maxlength="255" value="<?php echo $isNew?'':$this->data->password;?>" /><br />
				<?php echo JText::_( "COM_JWHMCS_GRPMGR_VIEW_LABEL_PASS" ); ?>
			</div>
		</td>
	</tr>
</table>
</div>

<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="controller" value="grpmgr" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="id" value="<?php echo $this->data->id; ?>" />
</form>

<script language="javascript">
function myValidate(f) {
        if (document.formvalidator.isValid(f)) {
                return true; 
        }
        else {
                alert('<?php echo JText::_( "COM_JWHMCS_INVALID_MSG" ); ?>');
        }
        return false;
}

function submitbutton(pressbutton) {
	var form = document.adminForm;

	if (pressbutton == 'cancel') {
		submitform( pressbutton );
		return;
	}

	if (myValidate(form) == true) {
		submitform( pressbutton );
	}
	
}
</script>