<?php defined('_JEXEC') or die('Restricted access'); ?>

<script type="text/javascript">
<!--
	window.onDomReady(function(){
		document.formvalidator.setHandler('passverify', function (value) { return ($('password').value == value); }	);
	});
// -->
</script>
<script type="text/javascript" src="<?php echo $this->params->get( 'whmcsurl' ); ?>includes/jscript/pwstrength.js"></script>
<?php
	if(isset($this->message)){
		$this->display('message');
	}
?>

<form action="<?php echo JRoute::_( 'index.php?option=com_jwhmcs' ); ?>" method="post" id="josForm" name="josForm" class="form-validate">

<?php if ( $this->params->def( 'show_page_title', 1 ) ) : ?>
<div class="componentheading<?php echo $this->params->get( 'pageclass_sfx' ); ?>"><?php echo $this->escape($this->params->get('page_title')); ?></div>
<?php endif; ?>

<table cellpadding="0" cellspacing="0" border="0" width="100%" class="contentpane">
<tr>
	<td width="30%" height="40">
		<label id="firstnamemsg" for="firstname">
			<?php echo JText::_( 'FirstName' ); ?>:
		</label>
	</td>
  	<td>
  		<input type="text" name="firstname" id="firstname" size="40" value="<?php echo $this->post['firstname']; ?>" class="inputbox required" maxlength="50" /> *
  	</td>
</tr>
<tr>
	<td width="30%" height="40">
		<label id="lastnamemsg" for="lastname">
			<?php echo JText::_( 'LastName' ); ?>:
		</label>
	</td>
  	<td>
  		<input type="text" name="lastname" id="lastname" size="40" value="<?php echo $this->post['lastname']; ?>" class="inputbox required" maxlength="50" /> *
  	</td>
</tr>
<tr>
	<td width="30%" height="40">
		<label id="companynamemsg" for="companyname">
			<?php echo JText::_( 'CompanyName' ); ?>:
		</label>
	</td>
  	<td>
  		<input type="text" name="companyname" id="companyname" size="40" value="<?php echo $this->post['companyname'];  ?>" class="inputbox" maxlength="50" />
  	</td>
</tr>
<tr>
	<td width="30%" height="40">
		<label id="address1msg" for="address1">
			<?php echo JText::_( 'AddressOne' ); ?>:
		</label>
	</td>
  	<td>
  		<input type="text" name="address1" id="address1" size="40" value="<?php echo $this->post['address1']; ?>" class="inputbox required" maxlength="50" /> *
  	</td>
</tr>
<tr>
	<td width="30%" height="40">
		<label id="address2msg" for="address2">
			<?php echo JText::_( 'AddressTwo' ); ?>
		</label>
	</td>
  	<td>
  		<input type="text" name="address2" id="address2" size="40" value="<?php echo $this->post['address2'];  ?>" class="inputbox" maxlength="50" />
  	</td>
</tr>
<tr>
	<td width="30%" height="40">
		<label id="citymsg" for="city">
			<?php echo JText::_( 'City' ); ?>:
		</label>
	</td>
  	<td>
  		<input type="text" name="city" id="city" size="40" value="<?php echo $this->post['city'];  ?>" class="inputbox required" maxlength="50" /> *
  	</td>
</tr>
<tr>
	<td width="30%" height="40">
		<label id="statemsg" for="state">
			<?php echo JText::_( 'State' ); ?>:
		</label>
	</td>
  	<td>
  		<input type="text" name="state" id="state" size="40" value="<?php echo $this->post['state'];  ?>" class="inputbox required" maxlength="50" /> *
  	</td>
</tr>
<tr>
	<td width="30%" height="40">
		<label id="postcodemsg" for="postcode">
			<?php echo JText::_( 'Postcode' ); ?>:
		</label>
	</td>
  	<td>
  		<input type="text" name="postcode" id="postcode" size="40" value="<?php echo $this->post['postcode'];  ?>" class="inputbox required" maxlength="50" /> *
  	</td>
</tr>
<tr>
	<td width="30%" height="40">
		<label id="countrymsg" for="country">
			<?php echo JText::_( 'Country' ); ?>:
		</label>
	</td>
  	<td>
  		<select name="country" id="country" class="inputbox required"><?php echo $this->ctry; ?></select> *
  	</td>
</tr>
<tr>
	<td width="30%" height="40">
		<label id="phonenumbermsg" for="phonenumber">
			<?php echo JText::_( 'PhoneNumber' ); ?>:
		</label>
	</td>
  	<td>
  		<input type="text" name="phonenumber" id="phonenumber" size="40" value="<?php echo $this->post['phonenumber'];  ?>" class="inputbox required" maxlength="50" /> *
  	</td>
</tr>
<tr>
	<td colspan="2">
		<hr />
	</td>
</tr>
<tr>
	<td height="40">
		<label id="usernamemsg" for="username">
			<?php echo JText::_( 'Username' ); ?>:
		</label>
	</td>
	<td>
		<input type="text" id="username" name="username" size="40" value="<?php echo $this->post['username'];  ?>" class="inputbox required validate-username" maxlength="25" /> *
	</td>
</tr>
<tr>
	<td height="40">
		<label id="emailmsg" for="email">
			<?php echo JText::_( 'Email' ); ?>:
		</label>
	</td>
	<td>
		<input type="text" id="email" name="email" size="40" value="<?php echo $this->post['email'];  ?>" class="inputbox required validate-email" maxlength="100" /> *
	</td>
</tr>
<tr>
	<td height="40">
		<label id="pwmsg" for="password">
			<?php echo JText::_( 'Password' ); ?>:
		</label>
	</td>
  	<td>
  		<div style="width: 280px; float: left; "><input class="inputbox required validate-password" type="password" id="newpw" name="password" size="40" value="" /> *</div>
  		<script language="JavaScript" type="text/javascript">showStrengthBar();</script>
  	</td>
</tr>
<tr>
	<td height="40">
		<label id="pw2msg" for="password2">
			<?php echo JText::_( 'Verify Password' ); ?>:
		</label>
	</td>
	<td>
		<input class="inputbox required validate-passverify" type="password" id="password2" name="password2" size="40" value="" /> *
	</td>
</tr>
<?php if ($this->params->get( 'RecaptchaEnable' )):
$reurl = ($this->params->get( 'scheme' ) == 'https' ? 'https://api-secure.recaptcha.net' : 'http://api.recaptcha.net' );
?> 
<tr>
	<td>&nbsp;</td>
	<td>
<script>
var RecaptchaOptions = {
   theme : '<?php echo $this->params->get( 'RecaptchaTheme' ); ?>',
   lang: '<?php echo $this->params->get( 'RecaptchaLang' ); ?>'
};
</script>
		
		<script type="text/javascript"
		   src="<?php echo $reurl; ?>/challenge?k=<?php echo $this->params->get( 'RecaptchaPublickey' ); ?>">
		</script>		
		<noscript>
		   <iframe src="<?php echo $reurl; ?>/noscript?k=<?php echo $this->params->get( 'RecaptchaPublickey' ); ?>"
		       height="300" width="500" frameborder="0"></iframe><br>
		   <textarea name="recaptcha_challenge_field" rows="3" cols="40">
		   </textarea>
		   <input type="hidden" name="recaptcha_response_field" 
		       value="manual_challenge">
		</noscript>
	</td>
</tr>
<?php endif; ?>
<tr>
	<td colspan="2" height="40">
		<?php echo JText::_( 'REGISTER_REQUIRED' ); ?>
	</td>
</tr>
</table>
	<button class="button validate" type="submit"><?php echo JText::_('Register'); ?></button>
	<input type="hidden" name="task" value="register_save" />
	<input type="hidden" name="id" value="0" />
	<input type="hidden" name="gid" value="0" />
	<input type="hidden" name="usedata" value="1" />
	<?php echo JHTML::_( 'form.token' ); ?>
</form>
