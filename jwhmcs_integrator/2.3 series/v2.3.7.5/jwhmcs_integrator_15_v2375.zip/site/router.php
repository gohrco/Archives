<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: router.php 447 2012-03-26 18:13:10Z steven_gohigher $
 * @since      1.5.0
 */


/**
 * Router for building SEF link
 * 
 * @param	$query (array)
 * @return	$segments (array)
 */
function JwhmcsBuildRoute(&$query)
{
	$segments = array();
	
	// Catch Itemid and return
	if ( isset( $query['Itemid'] ) ) return $segments;
	
	// If no controller, but we asked for a task...
	if (! isset( $query['controller'] ) && isset( $query['task'] ) ) {
		$query['controller'] = $query['task'];
		unset( $query['task'] );
	}
	
	// If we still dont have a controller, assume default
	if (! isset( $query['controller'] ) ) {
		$query['controller'] = 'default';
	}
	
	// Build first segment
	$segments[] = $query['controller'];
	unset( $query['controller'] );
	
	// Bail if we are done
	if ( empty( $query ) ) return $segments;
	
	// Loop through these to see what else to do
	$qarray	= array(	'task'			=> 'display',
						'view'			=> null,
						'layout'		=> null,
						'token'			=> null,
						'jwhmcs'		=> null,
						'username'		=> null,
						'joomlaid'		=> null
	);
	
	foreach ( $qarray as $q => $d )
	{
		if ( isset( $query[$q] ) )
		{
			$segments[] = $query[$q];
			unset ( $query[$q] );
		}
		elseif (! is_null( $d ) )
		{
			$segments[] = $d;
		}
	}
	
	return $segments;
}


/**
 * Router for parsing SEF link
 * 
 * @param	$segments (array)
 * @return	$vars (array)
 */
function JwhmcsParseRoute($segments)
{
	$vars = array();
	
	if ( count( $segments ) == 0 )
		return $vars;	// Nothing to do
	
	// First is always the controller
	$vars['controller']	= $segments[0];
	array_shift( $segments );
	
	if ( count ( $segments ) == 0 ) return $vars;
	
	/*
	$tmp = explode( ".", $segments[0] );
	
	$vars['controller']	= $tmp[0];
	$vars['task']		= ( count( $tmp ) == 1 ? "display" : $tmp[1] );
	array_shift( $segments );
	
	if ( count( $segments ) == 0 ) {
		$vars['view'] = $vars['controller'];
		$vars['layout'] = 'default';
		return $vars;	// All we can do
	}
	
	$tmp = explode( ".", $segments[0] );
	$vars['view']	= $tmp[0];
	$vars['layout']	= ( count( $tmp ) == 1 ? "default" : $tmp[1] );
	array_shift( $segments );
	*/
	
	// Variable array:  required items up front (view / layout)
	$varray	= array(	0	=> 'task',
						1	=> 'view',
						2	=> 'layout',
						3	=> 'token',
						4	=> 'jwhmcs',
						5	=> 'username',
						6	=> 'joomlaid'
	);
	
	for ( $i=0; $i<count($segments); $i++ ) {
		if ( isset( $segments[$i] ) ) {
			$vars[$varray[$i]] = $segments[$i];
		}
	}
	
	return $vars;
}
