<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: controller.php 447 2012-03-26 18:13:10Z steven_gohigher $
 * @since      1.5.0
 */

jimport('joomla.application.component.controller');

/**
 * @package		J!WHMCS Controller
 */
class JwhmcsController extends JController
{
	function __construct()
	{
		$ctrl	= JRequest :: getVar( 'controller' );
		if (is_null(JRequest::getVar( 'view'))) JRequest::setVar('view', $ctrl );
		
		parent :: __construct();
	}
	
	
	/**
	 * task:  display
	 *     Default view display handler
	 */
	function display()
	{
		// If the view hasn't been set, set it to default
		if (is_null(JRequest::getVar( 'view'))) JRequest::setVar('view', 'default' );
		
		//$acl = & JFactory::getACL();
		
		//$acl->addACL( 'com_jwhmcs', 'view', 'users', 'super administrator' );
		
		// Call up the parent display task
		parent::display();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getSess (private)
	 * Purpose:		Retrieve and remove the passed session info
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	function _getSess($token)
	{
		$db =& JFactory::getDBO();
		$query = 'SELECT `value` FROM #__jwhmcs_sess WHERE token="'.$token.'"';
		$db->setQuery($query);
		$result = $db->loadResult();
		
		$tmp = preg_split('/\n/', $result);
		foreach ($tmp as $t)
		{
			$var = explode('=', $t);
			$k = $var[0];
			unset($var[0]);
			$ubind[$k] = implode("=", $var);
			unset($var, $k);
		}
		
		$query = 'DELETE FROM #__jwhmcs_sess WHERE token="'.$token.'"';
		$db->setQuery($query);
		$res = $db->query();
		
		return $ubind;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_stop (private)
	 * Purpose:		Halts execution of Joomla with message
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	function _stop($msg = '')
	{
		global $mainframe;
		echo $msg;
		$mainframe->close();
	}
}
?>
