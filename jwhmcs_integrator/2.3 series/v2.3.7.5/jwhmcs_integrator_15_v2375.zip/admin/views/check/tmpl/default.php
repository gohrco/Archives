<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_( 'behavior.mootools' );
jimport('joomla.html.pane');

$pane =& JPane::getInstance('tabs');

$data = $this->data;

$imgbase = JURI::root().'components/com_jwhmcs/media/icons/';

echo $pane->startPane( 'tabs' );
echo $pane->startPanel( 'Joomla Check', 'joomla_check' );
?>
<table class="checkStarttbl toolbar">
	<tr>
		<td class="checkStartimg button">
			<a class="button" href="#" onclick="beginCheck(10,30,this); return false;" id="joomla_check_href1"><img src="<?php echo $imgbase.'j-48-checkrun.png'; ?>" />
			<span class="checkStarttxt">Begin Check</span></a>
		</td>
	</tr>
</table>

<table class="admintable">
	<tbody>
		<tr>
			<td class="stepTitle">
				Component Installed
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep10"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage10">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				Hidden Menu Created
			</td>
			<td width="50px">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep20"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage20">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				Client Menu Created
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep30"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage30">&nbsp;</div>
			</td>
		</tr>
	</tbody>
</table>

<?php 
echo $pane->endPanel();
echo $pane->startPanel( 'Plugin Check', 'plugin_check' );
?>
<table class="checkStarttbl toolbar">
	<tr>
		<td class="checkStartimg button">
			<a class="button" href="#" onclick="beginCheck(100,130,this); return false;" id="plugin_check_href1"><img src="<?php echo $imgbase.'j-48-checkrun.png'; ?>" />
			<span class="checkStarttxt">Begin Check</span></a>
		</td>
	</tr>
</table>

<table class="admintable">
	<tbody>
		<tr>
			<td class="stepTitle">
				Authentication - J!WHMCS
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep100"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage100">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				System - J!WHMCS
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep110"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage110">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				System - J!WHMCS Language 
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep120"></div></div>
			</td>
			<td>
				<div class="ajaxMessage" id="checkMessage120">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				User - J!WHMCS
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep130"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage130">&nbsp;</div>
			</td>
		</tr>
	</tbody>
</table>

<?php
echo $pane->endPanel();
echo $pane->startPanel( 'WHMCS Check', 'whmcs_check' );
?>
<table class="checkStarttbl toolbar">
	<tr>
		<td class="checkStartimg button">
			<a class="button" href="#" onclick="beginCheck(200,240,this); return false;" id="whmcs_check_href1"><img src="<?php echo $imgbase.'j-48-checkrun.png'; ?>" />
			<span class="checkStarttxt">Begin Check</span></a>
		</td>
	</tr>
</table>
<table class="admintable">
	<tbody>
		<tr>
			<td class="stepTitle">
				Root Files Installed
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep200"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage200">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				Hook Files Installed
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep210"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage210">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				Custom API Files Installed
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep220"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage220">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				Template Directories Installed
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep230"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage230">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				Database Initialized (on WHMCS)
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep240"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage240">&nbsp;</div>
			</td>
		</tr>
	</tbody>
</table>
<?php
echo $pane->endPanel();
echo $pane->startPanel( 'Product Check', 'product_check' );
?>
<table class="checkStarttbl toolbar">
	<tr>
		<td class="checkStartimg button">
			<a href="#" onclick="beginCheck(300,310,this); return false;" id="product_check_href1"><img src="<?php echo $imgbase.'j-48-checkrun.png'; ?>" />
			<span class="checkStarttxt">Begin Check</span></a>
		</td>
	</tr>
</table>
<table class="admintable">
	<tbody>
		<tr>
			<td class="stepTitle">
				Product License
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep300"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage300">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				API Connection
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep310"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage310">&nbsp;</div>
			</td>
		</tr>
		
	</tbody>
</table>
<?php
echo $pane->endPanel();
echo $pane->endPane();
?>


<form action="index.php" method="post" name="adminForm" id="adminForm">
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="thisUrl" id="thisUrl" value="<?php echo $data->thisUrl; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="controller" value="check" />
<input type="hidden" name="step" id="step" value="10" />
<input type="hidden" name="laststep" id="laststep" value="" />
</form>

<script language="javascript">
function beginCheck(step,last,caller)
{
	$('laststep').setProperty('value', last);
	
	for(i=step; i<=last; i=i+10) {
		ajaxStatus = document.getElementById('checkStep'+i);
		ajaxStatus.removeClass('ajaxLoading').removeClass('ajaxSuccess').removeClass('ajaxError').removeClass('ajaxAlert');
		ajaxMessage = document.getElementById('checkMessage'+i);
		ajaxMessage.setHTML('');
	}
	runCheck(step);
}

function beginFix(step)
{
	ajaxStatus = document.getElementById('checkStep'+step);
	ajaxStatus.removeClass('ajaxLoading').removeClass('ajaxSuccess').removeClass('ajaxError').removeClass('ajaxAlert');
	ajaxMessage = document.getElementById('checkMessage'+step);
	ajaxMessage.setHTML('');
	runFix(step);
}
</script>