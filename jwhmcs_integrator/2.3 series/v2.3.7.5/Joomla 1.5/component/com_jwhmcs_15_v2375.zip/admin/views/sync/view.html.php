<?php
/**
 * WHMCS User Synchrization View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: view.html.php 182 2011-02-10 15:40:22Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsViewSync
 * Extends:		JView
 * Purpose:		Used as the WHMCS User Synchrization view
 * 
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsViewSync extends JView
{
	/* ------------------------------------------------------------ *\
	 * Method:		display
	 * Purpose:		Assembles the page for the application to send to
	 * 				the user
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function display($tpl = null)
	{
		$model	= &$this->getModel('sync');
		$user	= &JFactory::getUser();
		$task	= JRequest::getVar( 'task' );
		$data	= $model->getData($task);
		
		switch ($task):
		default:
			JToolBarHelper::title( JText::_( 'JWHMCS_ADMIN_TITLE_SYNCRO' ), 'sync.png' );
			JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
			JToolBarHelper :: custom( 'usrmgr', 'usrmgr.png', 'usrmgr.png', JText::_( 'JWHMCS_ADMIN_BUTTON_USRMGR' ), false, false );
			JToolBarHelper :: divider();
			JToolBarHelper :: custom( 'refresh', 'refresh.png', 'refresh.png', JText::_( 'JWHMCS_ADMIN_BUTTON_REFRESH' ), false, false );
			JToolBarHelper :: divider();
			JToolBarHelper :: custom( 'requery', 'sync.png', 'sync.png', JText::_( 'JWHMCS_ADMIN_BUTTON_REQRY' ), false, false );
			JToolBarHelper :: divider();
			JToolBarHelper :: custom( 'reload', 'reload.png', 'reload.png', JText::_( 'JWHMCS_ADMIN_BUTTON_RELOAD' ), false, false );
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
		endswitch;
		
		JwhmcsHelper::addMedia( "icons.css/css" );
		
		$this->assignRef('pagination', 	$data->pagination);
		$this->assignRef('data', 		$data->items);
		parent::display($tpl);
	}
}