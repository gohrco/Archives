<?php defined('_JEXEC') or die('Restricted access'); ?>

<h1>Manual Installation</h1>
<p>To complete the installation of J!WHMCS Integrator, please print out and follow these steps:</p>
<ol>
<li><strong>Plugins</strong> - Download and install the Authentication, System and User plugins.  Ensure the User Plugin appears last in execution order and activate the plugins.  You can also deactivate the Joomla Authentication plugin to allow users to login with their WHMCS email / password or their Joomla username / password.</li>
<li><strong>WHMCS Root File</strong> - Download the files for the WHMCS portion of the install.  This package will include two root files, a "jconfig.php" file and a "jwhmcs.php" file.  Open the jconfig.php file and change the default path to your Joomla configuration.php file to the location on your server that the Joomla configuration.php file can be found.  Upload the jconfig.php and jwhmcs.php file to your WHMCS directory on your server.  You can verify that the file is finding the configuration settings by visiting the url to your WHMCS at:  http://&lt;WHMCS_URL&gt;/jwhmcs.php?task=checkinstall</li>
<li><strong>WHMCS Template Files</strong> - Find the template directory you use on WHMCS and make a copy of it in the template directory calling it "jwhmcs-default" or "jwhmcs-portal".  Take the files located in the "templates" directory that were included in the whmcs archive you downloaded and copy them to the "jwhmcs-default" or "jwhmcs-portal" directory you created.</li>
<li><strong>Hidden Menu</strong> - In Joomla, go to the Menu Manager and create a new menu calling it "Hidden Menu" (or some other name you will remember).  You don't need to create a menu module for it.  Now you need to create two new menu items on this menu using the JWHMCS Integrator - Blank page.  Call the first item "Logged In", the second one "Logged Out".</li>
<li><strong>API Connection</strong> - Visit the J!WHMCS Integrator component in Joomla and click on "API Connection" on the top right of the screen.  Fill in the URL to your WHMCS, the API admin username and password and if necessary the API Access Key check.  As you fill in the fields, your settings will be checked against the API to test the connection.  When you have a check mark indicating the connection is successful, click "Save Settings".</li>
<li><strong>Manage License</strong> - Visit the J!WHMCS Integrator component in Joomla and click on "Manage License" on the top right of the screen.  Enter the license you received when you purchased J!WHMCS Integrator.  When the license has been validated, click "Save Settings".</li>
<li><strong>Parameters</strong> - Visit the J!WHMCS Integrator component in Joomla and click on "Parameters" on the top right of the screen.  Complete the missing parameters and click "Save".</li>
<li><strong>WHMCS Sync</strong> - Visit the WHMCS Sync area and click "Reload".  Your users from WHMCS should now be imported into Joomla.</li>
<li><strong>User Manager</strong> - Visit the User Manager area and click on "Find All Matches" to make all available matches between Joomla and WHMCS users.</li>
<li><strong>WHMCS Hook File</strong> - Now that the system is configured, complete the install by uploading the J!WHMCS Integrator hook file found in the archive for the WHMCS portion of the install.  Once this file goes in place, J!WHMCS Integrator will be active and your site should be wrapping around WHMCS and your users should be bridged between the two systems.</li>
</ol>
<form action="index.php" method="post" name="adminForm">
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="controller" value="default" />
<input type="hidden" name="task" value="" />
</form>