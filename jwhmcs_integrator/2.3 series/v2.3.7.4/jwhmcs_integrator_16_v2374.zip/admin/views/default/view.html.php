<?php
/**
 * Default View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: view.html.php 220 2011-05-19 21:13:00Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');
include_once( JPATH_COMPONENT_ADMINISTRATOR . DS . 'helper.php' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsViewGrpmgr
 * Extends:		JView
 * Purpose:		Used as the default view
 * As of:		version 1.5.0
\* ------------------------------------------------------------ */
class JwhmcsViewDefault extends JView
{
	/* ------------------------------------------------------------ *\
	 * Method:		display
	 * Purpose:		Assembles the page for the application to send to
	 * 				the user
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	function display($tpl = null)
	{
		$model	= & $this->getModel('default');
		$params	= & JwhmcsParams::getInstance();
		$user	= & JFactory::getUser();
		$lic	=   $model->checkLicense();		// Check J!WHMCS Integrator License
		//$wup	=   $model->whmcsParamUpdate();	// Update WHMCS Parameters (bool)
		$task	=   JRequest::getVar( 'task' );
		 
		// Retrieve ACL permitted actions
		$canDo	= JwhmcsHelper :: getActions();
		
		$this->addToolBar( $canDo );
		$icons = $model->getIconDefinitions( $canDo );
		
		$this->assignRef('lic',		$lic);		// Contains the license check data
		$this->assignRef('icondefs', $icons); // Icon definitions
		$this->assignRef('data',	$params);
		parent::display($tpl);
	}
	
	
	/**
	 * Add the toolbar buttons based on permissions
	 * @access		public
	 * @version		2.3.7.4
	 * @param		JObject		- $canDo: contains permissions user has
	 * 
	 * @since		2.32
	 */
	public function addToolBar( $canDo )
	{
		JToolBarHelper :: title( JText::_( 'COM_JWHMCS' ), 'jwhmcs.png' );
		
		// Toolbar buttons
		if ( $canDo->get( 'core.admin' ) ) {
			JToolBarHelper :: custom( 'apiconxn', 'apiconxn.png', '', JText::_( 'COM_JWHMCS_DEFAULT_VIEW_BUTTON_APICONXN'), false, false );
			JToolBarHelper :: custom( 'license', 'license.png', '', JText::_( 'COM_JWHMCS_DEFAULT_VIEW_BUTTON_LICENSE'), false, false );
			JToolBarHelper :: spacer();
			JToolBarHelper :: preferences(	'com_jwhmcs', '550', '875', 'JToolbar_Options'  );
		}
	}
}