<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    Joomla! 1.5 Package
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.3.7 ( $Id: register.php 213 2011-05-19 17:08:09Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.5.0
 * 
 * @desc		This controller handles user registration information, creating
 * 				Joomla and WHMCS accounts
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
include_once( JPATH_COMPONENT_ADMINISTRATOR . DS . 'classes' . DS . 'class.curl.php' );
include_once( JPATH_COMPONENT_ADMINISTRATOR . DS . 'helper.php' );


/**
 * JwhmcsControllerRegister class handles user registration on the front end
 * @version	2.3.0
 * 
 * @since	1.5.0
 * @author	Steven
 */
class JwhmcsControllerRegister extends JwhmcsController
{
	/**
	 * Constructor
	 * @access	public
	 * @version	2.3.0
	 * 
	 * @since	1.5.0
	 */
	function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Saves user registration information from form
	 * @access	public
	 * @version	2.3.0
	 * 
	 * @since	1.5.0
	 */
	public function save()
	{
		$app		= & JFactory::getApplication();
		$fromjwhmcs	=   JRequest::getVar( 'fromjwhmcs' );
		 
		// Check for request forgeries
		if (! $fromjwhmcs) {// if this variable exists, then we are probably coming from the jwhmcs root file
			JRequest::checkToken() or jexit( "Invalid Token" );
		}
		elseif ( $fromjwhmcs == $params->get( "Secret" ) ) {
			define('JWHMCS_AUTH', true); // Set so we don't try to add the new user to WHMCS
		}
		else {
			jexit( "Invalid Token" );
		}
		
		// Get required system objects
		$model		= $this->getModel('signup');
		$user 		= clone(JFactory::getUser());
		$pathway 	=& $app->getPathway();
		$config		=& JFactory::getConfig();
		$authorize	=& JFactory::getACL();
		$document   =& JFactory::getDocument();
		$params		=& JwhmcsParams::getInstance();
		$session	=& JFactory::getSession();
		$jcurl		= & JwhmcsCurl::getInstance();
		$db			= & JFactory::getDBO();
		
		JRequest::setVar('layout', 'default');
		
		/* reCaptcha if option set */
		if ( ( ! $fromjwhmcs) && ( $params->get( 'RecaptchaEnable' ) ) )
		{
		require_once(JPATH_COMPONENT.DS.'recaptchalib.php');
			
			$privatekey = $params->get( 'RecaptchaPrivatekey' );
			
			$resp = recaptcha_check_answer ($privatekey,
                                $_SERVER["REMOTE_ADDR"],
                                JRequest::getVar( 'recaptcha_challenge_field' ),
                                JRequest::getVar( 'recaptcha_response_field' ) );
			
			if (!$resp->is_valid) {
				JError::raiseWarning( 200, JText::_( $resp->error ) );
				JRequest::setVar( 'layout', 'default' );
				parent::display();
				return;
			}
		}
		
		// If user registration is not allowed, show 403 not authorized.
		$usersConfig = &JComponentHelper::getParams( 'com_users' );
		if ($usersConfig->get('allowUserRegistration') == '0') {
			if ($fromjwhmcs)
				$this->_stop('result=failed;error='.JText::_( 'Access Forbidden'));
			else
				JError::raiseError( 403, JText::_( 'Access Forbidden' ));
			return;
		}
		
		// Initialize new usertype setting
		$newUsertype = $usersConfig->get( 'new_usertype' );
		if (!$newUsertype) {
			$newUsertype = 'Registered';
		}
		
		// Build the user array for binding
		$ubind = JwhmcsHelper::getUserArray( "joomla" );
		
		// Check to see if the email is in use - if so, should we match it up?
		if ( ( $userid = $this->_checkEmail( $ubind['email'] ) ) && ( $fromjwhmcs ) ) {
			if ( $params->get( 'JuserEmailsync' ) ) {
				$this->_stop('result=success;existing=1;userid='.$userid);
			}
			else {
				$this->_stop('result=failed;error='.JText::_( "Email address already in use" ));
			}
		}
		
		// Bind the post array to the user object
		if (!$user->bind( $ubind, 'usertype' )) {
			if($fromjwhmcs)
				$this->_stop('result=failed;error='.JText::_( $user->getError()));
			else
				JError::raiseError( 500, $user->getError());
		}
		
		// Set some initial user values
		$user->set('id', 0);
		$user->set('usertype', '');
		$user->set('gid', $authorize->get_group_id( '', $newUsertype, 'ARO' ));
		
		$date =& JFactory::getDate();
		$user->set('registerDate', $date->toMySQL());
		
		// If user activation is turned on, we need to set the activation information
		$useractivation = ( $fromjwhmcs ? $params->get( 'JuserAuthorize' ) : $usersConfig->get( 'useractivation' ) );
		
		// Dont send welcome email by default
		$sendEmail = false;
		if ($useractivation == '1') {
			jimport('joomla.user.helper');
			$user->set('activation', JUtility::getHash( JUserHelper::genRandomPassword()) );
			$user->set('block', '1');
			$sendEmail = true;
		}
		
		// If there was an error with registration, set the message and display form
		if ( !$user->save() ) {
			if ($fromjwhmcs)
				$this->_stop('result=failed;error='.JText::_( $user->getError()));
			else
				JError::raiseWarning('', JText::_( $user->getError()));
			return false;
		}
		
		// Send registration confirmation mail
		if ($fromjwhmcs)
			$password = $ubind['password'];
		else
			$password = JRequest::getString('password', '', 'post', JREQUEST_ALLOWRAW);
		
		$password = preg_replace('/[\x00-\x1F\x7F]/', '', $password); //Disallow control chars in the email
		
		// Send email message if we have activation set
		if ($sendEmail) {
			JwhmcsHelper::sendMail($user, $password);
		}
		
		// Everything went fine, set relevant message depending upon user activation state and display message
		if ( $useractivation == 1 ) {
			$message  = JText::_( 'REG_COMPLETE_ACTIVATE' );
		} else {
			$message = JText::_( 'REG_COMPLETE' );
		}
		
		if ($fromjwhmcs)
			$this->_stop('result=success;userid='.$user->id);
		else
			$this->setRedirect( 'index.php', $message);
	}
	
	
	/**
	 * Validate info sent by the registration form prior to submittal
	 * @access	public
	 * @version	2.3.0
	 * 
	 * @since	2.1.0
	 */
	public function validInfo()
	{
		$app		= & JFactory::getApplication();
		$type		=   ( ( $type = JRequest::getVar( 'type' ) ) ? $type : JRequest::getVar( 'token' ) );
		$value		=   ( ( $value = JRequest::getVar( 'value' ) ) ? $value : JRequest::getVar( 'jwhmcs' ) );
		$model		= & $this->getModel( 'register' );
		$result		= & $model->validInfo( $type, $value );
		
		foreach ($result as $k => $v) $data[$k] = $v;
		echo $model->buildResponse($data);
		$app->close();
	}
	
	
	/**
	 * Checks to see if an email address is in use
	 * @access	private
	 * @version	2.3.0
	 * @param	string		$email - the address to look for
	 * 
	 * @return	user id if exists, false if not
	 * @since	2.1.2
	 */
	private function _checkEmail( $email )
	{
		$db = & JFactory::getDBO();
		
		$email = trim( $email );
		$query	= "SELECT u.id FROM #__users u WHERE email = '{$email}'";
		$db->setQuery( $query );
		$result = $db->loadResult();
		
		return ( $result ? $result : false );
	}
}