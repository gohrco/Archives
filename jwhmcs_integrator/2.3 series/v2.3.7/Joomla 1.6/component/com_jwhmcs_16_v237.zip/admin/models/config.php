<?php
/**
 * Configuration Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: config.php 278 2011-09-06 16:02:12Z steven_gohigher $
 * @since      2.1.0
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model
jimport( 'joomla.database.table.plugin' );
jimport( 'joomla.environment.uri' );
jimport( 'joomla.client.ftp' );

include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.filehandler.php');


/**
 * Used to handle configuration of J!WHMCS Integrator
 * @version		2.3.7
 * 
 * @author		Steven
 * @since		2.1.0
 */
class JwhmcsModelConfig extends JwhmcsModel
{
	/**
	 * An array of parameters to exclude from saving
	 * @access		public
	 * @var			array
	 */
	public $excludes	= array(	0 => 'License', 
								1 => 'InstallToken', 
								2 => 'LastSync' );
	
	/**
	 * Constructor
	 * @access		public
	 * @version		2.3.7
	 * 
	 * @since		2.1.0
	 */
	public function __construct()
	{
		parent::__construct();
		
	}
	
	
	/**
	 * Retrieves parameters for configuration selection
	 * @access		public
	 * @version		2.3.7
	 * 
	 * @return		object containing parameters
	 * @since		2.1.0
	 */
	public function getData()
	{
		// Retrieve the parameters
		$params = & $this->_getParameters();
		$names	= & $this->_getParamnames();
		
		// Retrieve the definitions
		$defs	= & $this->_getDefinitions();
		
		foreach ($params as $prime => $values) {
			$data->$prime = array();
			foreach ($values as $key => $value) {
				if ( $key == 'LangJoom' ) continue;			// No language array so don't ask for default Joomla language to WHMCS language (redundant)
				$ft = $this->_getFieldType($key, $value);
				$newkey = (object) array();
				$newkey->name = $names[$prime][$key];
				$newkey->key = $key;
				$newkey->value = $value;
				$newkey->field = $ft['field'];
				$newkey->display = $ft['display'];
				$newkey->desc = $defs[$prime][$key];
				array_push($data->$prime, $newkey);
				unset($newkey, $ft);
			}
		}
		return $data;
	}
	
	
	/**
	 * Handles the saving of parameters upon exiting configuration
	 * @access		public
	 * @version		2.3.7
	 * 
	 * @return		boolean true on success false on error
	 * @see			JwhmcsModel::storeData()
	 * @since		2.1.0
	 */
	public function storeData()
	{
		$jcurl		= & JwhmcsCurl::getInstance();
		$params		= & JwhmcsParams::getInstance();
		$urlarray	=   $this->_getParamurls();
		$warray		=   array('Enable', 'Debug', 'UserEnable', 'RenderEnable', 'Secret', 'RenderDebugconsole', 'RedirMessage', 'RedirGatewayssl', 'KayakoUsessl', 'PwresetRedirect', 'NewregRedirect', 'JoomlaUrl' );
		$wupdate	=   null;
		$setfield	=   null;
		
		foreach ($params->params as $prime => $values) {
			foreach ($values as $k => $v) {
				$formvar = JRequest::getVar($k);
				if (is_null($formvar)) continue;
				if (in_array($k, $warray)) {
					$wupdate[$k] = $formvar;
				}
				$params->set($k, $formvar, false, $prime);
				unset($formvar);
			}
		}
		
		foreach ($urlarray as $url) {
			$tmp = & JURI::getInstance($params->get($url));
			
			if (is_null($tmp->getScheme())) {
				$tmp->setScheme('http');
			}
			
			if (is_null($tmp->getHost())) {
				$tmp->setHost($tmp->getPath());
				$tmp->setPath('');
			}
			
			$params->set($url, $tmp->toString());
			
			if ( isset( $wupdate[$url] ) ) {
				$wupdate[$url] = $tmp->toString();
			}
			
			unset($tmp);
		}
		
		$params->saveAll();
		
		// Handle PW reset / Registration url settings on WHMCS side
		$PwItem		= $params->get( "PwresetMenu" );
		$wupdate['PwresetUrl']	= urlencode( JRoute::_( rtrim( $wupdate['JoomlaUrl'], "/" ) . '/index.php?option=com_user&view=reset' . ( $PwItem ? "&Itemid={$PwItem}" : null ), false ) );
		
		$RegItem	= $params->get( "RegMenu" );
		$wupdate['RegisterUrl']	= urlencode( JRoute::_( rtrim( $wupdate['JoomlaUrl'], "/" ) . '/index.php?option=com_user&view=register'  . ( $RegItem ? "&Itemid={$RegItem}" : null ), false ) );
		
		foreach ($wupdate as $key => $value) {
			if ($setfield) $setfield .= ';';
			$setfield .= $key.'='.$value;
		}
		
		$jcurl->setAction('jwhmcsconfig', array("set" => $setfield));
		$result = $jcurl->loadResult();
		
		if ($result['result'] == 'success') {
			return true;
		}
		else {
			return false;
		}
	}
	
	
	/* ----------------------------------------- *\
	 *              SUB FUNCTIONS                *
	\* ----------------------------------------- */
	
	
	/**
	 * Retrieves the array of URLs from the parameters object
	 * @access		private
	 * @version		2.3.7
	 * 
	 * @return		array of urls parameter names
	 * @since		2.1.0
	 */
	private function _getParamurls()
	{
		$params = & JwhmcsParams::getInstance();
		return $params->urlarray;
	}
	
	
	/**
	 * Creates the language descriptions for translation
	 * @access		private
	 * @version		2.3.7
	 * 
	 * @return		array of paramter language definitions
	 * @since		2.1.0
	 */
	private function _getDefinitions()
	{
		$params = & JwhmcsParams::getInstance();
		$params = $params->params;
		$langs	= $this->_getJoomlanguages();
		
		foreach ($langs as $lang) {
			if (! isset( $lang->shortcode ) ) continue;
			if (! isset($ret['language']['LangJoom'.$lang->shortcode] ) ) {
				$ret['language']['LangJoom'.$lang->shortcode] = $lang->name;
			}
		}
		
		if (! count($params) > 0) return;
		foreach ($params as $key => $set) {
			//if ($key == 'install') continue;
			if (! count($set) > 0) continue;
			foreach ($set as $k => $v) {
				if (in_array($k, $this->excludes)) continue;
				if (! $k) continue;
				if ($key == 'language') {
					$trans = JText::_( strtoupper( "COM_JWHMCS_CONFIG_" . $key . "_DESCRIPTION_" . $k ) );
					if ( $trans != strtoupper( "COM_JWHMCS_CONFIG_" . $key . "_DESCRIPTION_" . $k ) ) {
						$ret[$key][$k] = $trans;
					}
					else {
						$ret[$key][$k] = "Select the WHMCS language that should be matched up to this language in Joomla.";
					}
				}
				else {
					$ret[$key][$k] = JText::_( strtoupper("COM_JWHMCS_CONFIG_" . $key."_DESCRIPTION_" . $k ) );
				}
			}
		}
		
		return $ret;
	}
	
	
	/**
	 * Creates the language names for translation
	 * @access		private
	 * @version		2.3.7
	 * 
	 * @return		array of language names to use
	 * @since		2.1.0
	 */
	private function _getParamnames()
	{
		$params = & JwhmcsParams::getInstance();
		$params = $params->params;
		$langs	= $this->_getJoomlanguages();
		
		foreach ($langs as $lang) {
			if (! isset( $lang->shortcode ) ) continue;
			if (! isset($ret['language']['LangJoom'.$lang->shortcode] ) ) {
				$ret['language']['LangJoom'.$lang->shortcode] = $lang->name;
			}
		}
		
		if (! count($params) > 0) return;
		foreach ($params as $key => $set) {
			//if ($key == 'install' ) continue;
			if (! count($set) > 0) continue;
			foreach ($set as $k => $v) {
				if (in_array($k, $this->excludes)) continue;
				if (! $k) continue;
				if ($key == 'language') {
					$trans = JText::_( strtoupper("COM_JWHMCS_CONFIG_".$key."_TITLE_".$k) );
					if ( $trans != strtoupper("COM_JWHMCS_CONFIG_".$key."_TITLE_".$k) ) {
						$ret[$key][$k] = $trans;
					}
				}
				else {
					$ret[$key][$k] = JText::_( strtoupper("COM_JWHMCS_CONFIG_".$key."_TITLE_".$k) );
				}
			}
		}
		
		return $ret;
	}
	
	
	/**
	 * Retrieves the parameters from the component
	 * @access		private
	 * @version		2.3.7
	 * 
	 * @return		array of parameters
	 * @since		2.1.0
	 */
	private function _getParameters()
	{
		$pars = & JwhmcsParams::getInstance();
		$pars->rebuildParams();
		if ($pars->get('RenderImageurl') == '') {
			$pars->set( 'RenderImageurl', $pars->get( 'JoomlaUrl' ));
		}
		
		$params = $pars->params;
		$langs	= $this->_getJoomlanguages();
		
		foreach ($params as $prime => $pset) {
			foreach ($pset as $k => $v) {
				if (in_array($k, $this->excludes)) {
					unset ($params[$prime][$k]);
				}
			}
		}
		
		foreach ($langs as $lang) {
			if (! isset( $lang->shortcode ) ) continue;
			if (! isset($params['language']['LangJoom'.$lang->shortcode] ) ) {
				$params['language']['LangJoom'.$lang->shortcode] = $params['language']['LangDefault'];
				$pars->add( 'LangJoom'.$lang->shortcode, $params['language']['LangDefault'], 'language', '8', '30' );
			}
		}
		
		return $params;
	}
	
	
	/**
	 * Retrieves the config type for parameter
	 * @access		private
	 * @version		2.3.7
	 * @version		2.3.3 - Added field type 9 (custom)
	 * @param 		string		- $key: parameter key
	 * @param 		varies		- $value: current value
	 * 
	 * @return		array containing display option and html field
	 * @since		2.1.0
	 */
	private function _getFieldType($key, $value = null)
	{
		$db		= & JFactory::getDBO();
		$params	= & JwhmcsParams::getInstance();
		
		$query = "SELECT `field` FROM #__jwhmcs_config WHERE `key` = '$key'";
		$db->setQuery($query);
		$field = $db->loadResult();
		
		if (!$field) {
			if (! $params->init[$key][3]) {
				$field = 8;
			}
			else {
				$field = $params->init[$key][3];
			}
		}
		
		$fields = $this->_getFieldTypes();
		$ret['display'] = (in_array($field, array('-1','0')) ? 0 : 1); // Should the field be displayed to user (display = 0 or -1 then no)
		
		if ($field == 8) {
			switch(strtolower($key)):
			case 'regmethod':
				$optarray = array(	array(	'value' => '1', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_REGMETHOD_PARAM_1'),
									array(	'value' => '2', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_REGMETHOD_PARAM_2'),
									array(	'value' => '3', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_REGMETHOD_PARAM_3')
				);
				break;
			case 'regpasswordreset':
				$optarray = array(	array(	'value' => '1', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_REGPASSWORDRESET_PARAM_1' ),
									array(	'value' => '2', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_REGPASSWORDRESET_PARAM_2' ),
									array(	'value' => '3', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_REGPASSWORDRESET_PARAM_3' )
				);
				break;
			case 'juserstore':
				$optarray = array(	array(	'value' => '1', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_JUSERSTORE_PARAM_1'),
									array(	'value' => '2', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_JUSERSTORE_PARAM_2'),
									array(	'value' => '3', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_JUSERSTORE_PARAM_3'),
									array(	'value' => '4', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_JUSERSTORE_PARAM_4')
				);
				break;
			case 'jusernamestore':
				$optarray = array(	array(	'value' => '1', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_JUSERNAMESTORE_PARAM_1'),
									array(	'value' => '2', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_JUSERNAMESTORE_PARAM_2'),
									array(	'value' => '3', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_JUSERNAMESTORE_PARAM_3'),
									array(	'value' => '4', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_JUSERNAMESTORE_PARAM_4'),
									array(	'value' => '5', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_JUSERNAMESTORE_PARAM_5'),
									array(	'value' => '6', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_JUSERNAMESTORE_PARAM_6'),
									array(	'value' => '7', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_JUSERNAMESTORE_PARAM_7'),
									array(	'value' => '8', 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_JUSERNAMESTORE_PARAM_8')
				);
				break;
			case 'recaptchatheme':
				$optarray = array(	array(	'value' => 'blackglass',	'text' => 'COM_JWHMCS_CONFIG_RECAPTCHA_RECAPTCHATHEME_PARAM_BLKGL'),
									array(	'value' => 'clean',			'text' => 'COM_JWHMCS_CONFIG_RECAPTCHA_RECAPTCHATHEME_PARAM_CLEAN'),
									array(	'value' => 'red',			'text' => 'COM_JWHMCS_CONFIG_RECAPTCHA_RECAPTCHATHEME_PARAM_RED'),
									array(	'value' => 'white', 		'text' => 'COM_JWHMCS_CONFIG_RECAPTCHA_RECAPTCHATHEME_PARAM_WHITE')
				);
				break;
			case 'recaptchalang':
				$optarray = array(	array(	'value' => 'en', 'text' => 'COM_JWHMCS_CONFIG_RECAPTCHA_RECAPTCHALANG_PARAM_ENGLISH' ),
									array(	'value' => 'nl', 'text' => 'COM_JWHMCS_CONFIG_RECAPTCHA_RECAPTCHALANG_PARAM_DUTCH' ),
									array(	'value' => 'fr', 'text' => 'COM_JWHMCS_CONFIG_RECAPTCHA_RECAPTCHALANG_PARAM_FRENCH' ),
									array(	'value' => 'de', 'text' => 'COM_JWHMCS_CONFIG_RECAPTCHA_RECAPTCHALANG_PARAM_GERMAN' ),
									array(	'value' => 'pt', 'text' => 'COM_JWHMCS_CONFIG_RECAPTCHA_RECAPTCHALANG_PARAM_PORTUGUESE' ),
									array(	'value' => 'ru', 'text' => 'COM_JWHMCS_CONFIG_RECAPTCHA_RECAPTCHALANG_PARAM_RUSSIAN' ),
									array(	'value' => 'es', 'text' => 'COM_JWHMCS_CONFIG_RECAPTCHA_RECAPTCHALANG_PARAM_SPANISH' ),
									array(	'value' => 'tr', 'text' => 'COM_JWHMCS_CONFIG_RECAPTCHA_RECAPTCHALANG_PARAM_TURKISH' )
				);
				break;
			case 'menustyle':
				$optarray = array(	array(	'value' => 'joomla',	'text' => 'COM_JWHMCS_CONFIG_MENU_DESCRIPTION_MENUSTYLE_PARAM_1'),
									array(	'value' => 'yoo',		'text' => 'COM_JWHMCS_CONFIG_MENU_DESCRIPTION_MENUSTYLE_PARAM_2'),
									array(	'value' => 's5',		'text' => 'COM_JWHMCS_CONFIG_MENU_DESCRIPTION_MENUSTYLE_PARAM_3'),
									array(	'value' => 'artisteer', 'text' => 'COM_JWHMCS_CONFIG_MENU_DESCRIPTION_MENUSTYLE_PARAM_4'),
									array(	'value' => 'joomlart',	'text' => 'COM_JWHMCS_CONFIG_MENU_DESCRIPTION_MENUSTYLE_PARAM_5' ),
									array(	'value' => 'joomlr',	'text' => 'COM_JWHMCS_CONFIG_MENU_DESCRIPTION_MENUSTYLE_PARAM_6' )
				);
				break;
			case 'ftpuse':
				$optarray = array(	array(	'value' => 0, 'text' => 'COM_JWHMCS_CONFIG_INSTALL_DESCRIPTION_FTPUSE_OPTION_PATH' ),
									array(	'value' => 1, 'text' => 'COM_JWHMCS_CONFIG_INSTALL_DESCRIPTION_FTPUSE_OPTION_FTP' )
				);
				break;
			case 'newregredirect':
				$optarray = array(	array(	'value' => 0, 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_NEWREG_PARAM_0' ),
									array(	'value' => 1, 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_NEWREG_PARAM_1' )
				);
				break;
			case 'pwresetredirect':
				$optarray = array(	array(	'value' => 0, 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_PWRESET_PARAM_0' ),
									array(	'value' => 1, 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_PWRESET_PARAM_1' ),
									array(	'value' => 2, 'text' => 'COM_JWHMCS_CONFIG_REGISTRATION_PWRESET_PARAM_2' )
				);
				break;
			default: // We will assume for now it must be a language drop down
				
				$optarray = $this->_getLanguages('whmcs');
				
				break;
			endswitch;
			$ret['field'] = JHTML::_('select.genericlist', $optarray, $key, 'class="inputbox"', 'value', 'text', $value, $value, true);
		}
		elseif ($field == 7 ) {
			$ret['field'] = sprintf($this->_getMenuitems($value), $key, "config_$key", $value);
		}
		elseif (($field == 3) || ($field == 2)) {
			$sel3 = $value == 1 ? ($field == 3 ? "checked " : "selected ") : "";
			$sel4 = $value == 0 ? ($field == 3 ? "checked " : "selected ") : "";
			$ret['field'] = sprintf($fields[$field], $key, "config_$key", $sel3, $sel4);
		}
		elseif ($field == -2) {
			$ret['field'] = sprintf($fields[-2], $value);
		}
		elseif ( $field == 9 ) {
			switch( strtolower( $key ) ) {
				case 'regnofreeemaildomains':
					$domains		= file_get_contents( JPATH_SITE . DS . "media" . DS . "com_jwhmcs" . DS . "freeemaildomains.txt" );
					$ret['field']	= sprintf( $fields[5], $key, $domains, "config_$key" );
					break;
			}
		}
		else {
			$ret['field'] = sprintf($fields[$field], $key, $value, "config_$key");
		}
		
		return $ret;
	}
	
	
	/**
	 * Handles field storage for most config items
	 * @access		private
	 * @version		2.3.7
	 * @version		2.3.3 - Added textarea field (5) as option
	 * 
	 * @return		array containing html strings
	 * @since		2.1.0
	 */
	private function _getFieldTypes()
	{
		$fields[-2] = '<div style="desconly">%1$s</div>';
		$fields[-1] = '';
		$fields[0] = '<input type="hidden" name="%1$s" id="%3$s" value="%2$s" />';
		$fields[1] = '<input type="text" name="%1$s" id="%3$s" value="%2$s" size="40"  />';
		$fields[2] = '<select name="%1$s" id="%2$s"><option value="1"%3$s>'.JText::_( "Yes" ).'</option><option value="0"%4$s>'.JText::_( "No" ).'</option></select>';
		$fields[3] = '<input type="radio" name="%1$s" id="%2$s_on" value="1" %3$s /><label for="%2$s_on">'.JText::_( "Enabled" ).'</label><br /><input type="radio" name="%1$s" id="%2$s_off" value="0" %4$s /><label for="%2$s_off">'.JText::_( "Disabled" ).'</label>';
		$fields[4] = '<input type="password" name="%1$s" id="%3$s" value="%2$s" size="40"  />';
		$fields[5] = '<textarea name="%1$s" id="%3$s" cols="40" rows="3">%2$s</textarea>';
		return $fields;
	}
	
	
	/**
	 * Retrieves menu items for config selection
	 * @access		private
	 * @version		2.3.7
	 * @param		string		- $selected: contains the selected item to use in the select box
	 * 
	 * @return		string containing HTML formatted parameter
	 * @since		2.1.0
	 */
	private function &_getMenuitems($selected = null)
	{
		static $options = array();
		
		if ( empty ( $options ) ) {
			$db			= & JFactory::getDBO();
			$children	=   array();
			
			$query = 'SELECT menutype, title' .
					' FROM #__menu_types' .
					' ORDER BY title';
			$db->setQuery( $query );
			$menuTypes = $db->loadObjectList();
			
			$query = "SELECT `id`, `parent_id`, `title`, `menutype`, `type`
						FROM #__menu
						WHERE published = 1
						ORDER BY menutype, parent_id, ordering";
			$db->setQuery($query);
			$menuItems = $db->loadObjectList();
			
			if ($menuItems)
			{
				foreach ($menuItems as $v)
				{
					$pt 	= $v->parent_id;
					$list 	= @$children[$pt] ? $children[$pt] : array();
					array_push( $list, $v );
					$children[$pt] = $list;
				}
			}
			
			$list = JHTML::_('menu.treerecurse', 0, '', array(), $children, 9999, 0, 1 );
			
			$n = count( $list );
			$groupedList = array();
			foreach ($list as $k => $v) {
				$groupedList[$v->menutype][] = &$list[$k];
			}
			
			$options 	= array();
			$options[]	= JHtml::_('select.option', '', JText::_( "JOPTION_SELECT_MENU_ITEM" ) );
			
			foreach ($menuTypes as $type)
			{
				$options[]	= JHtml::_('select.option',  '0', '&#160;', 'value', 'text', true);
				$options[]	= JHtml::_('select.option',  $type->menutype, $type->title . ' - ' . JText::_( "JGLOBAL_TOP" ), 'value', 'text', true );
				
				if (isset( $groupedList[$type->menutype] ))
				{
					$n = count( $groupedList[$type->menutype] );
					for ($i = 0; $i < $n; $i++)
					{
						$item = &$groupedList[$type->menutype][$i];
						$options[] = JHTML::_('select.option',  $item->id, $item->treename, 'value', 'text', false );
	
					}
				}
			}
		}
		
		$return	= "<SELECT NAME=\"%1\$s\" id=\"%3\$s\" class=\"inputbox\">" . JHtml::_( "select.options", $options, array( "option.text.toHtml" => false, "list.select" => $selected )) . "</SELECT>";
		return $return;
	}
	
	
	/**
	 * Retrieves the language list from WHMCS
	 * @access		private
	 * @version		2.3.7
	 * @param		string		- $lang: the language parameter to match to
	 * 
	 * @return		array containing language options to select from
	 * @since		2.1.0
	 */
	private function _getLanguages($lang)
	{
		static $optarray = array();
		
		if (isset($optarray[$lang]))
		{
			return $optarray[$lang];
		}
		
		$files	= & JwhmcsFilehandler::getInstance();
		
		if (! $files->isEnabled() )
		{
			$options[] = array( 'value' => 0, 'text' => 'No method available to retrieve languages from WHMCS' );
			$optarray[$lang] = $options;
			return $optarray[$lang];
		}
		
		$files->setDst( 'lang', 'folder' );
		$langs	= $files->listAll( 'dst' );
		
		$options = array();
		
		if ( is_array( $langs ) )
		{
			foreach ($langs as $lang)
			{
				$name = explode(".", $lang);
				array_pop($name);
				$language = implode(".", $name);
				$options[] = array( 'value' => $language, 'text' => $language );
			}
		}
		$optarray[$lang] = $options;
		return $optarray[$lang];
	}
	
	
	/**
	 * Retrieve language array from Joomla
	 * @access		private
	 * @version		2.3.7
	 * @param		string		- $locate: where should the language be found
	 * 
	 * @return		array language objects from database
	 * @since		2.1.0
	 */
	private function _getJoomlanguages($locate = 'joomla')
	{
		static $joomlang = array();
		
		if (isset($joomlang[$locate]))
		{
			return $joomlang[$locate];
		}
		
		$db = & JFactory::getDBO();
		
		$query = "SHOW TABLES";
		$db->setQuery($query);
		$tables = $db->loadAssocList();
		
		$exists = false;
		foreach ($tables as $table)
		{
			foreach ($table as $v)
			{
				if ( $v == $db->getPrefix()."languages" )
				{
					$exists = true;
				}
			}
		}
		
		if (! $exists ) 
		{
			$options[] = array( (object) array() );
			$joomlang[$locate] = $options;
			return $joomlang[$locate];
		}
		
		$query = "SELECT `title` as `name`, `lang_code` as `code`, `sef` as `shortcode` FROM #__languages ORDER BY name";
		$db->setQuery($query);
		$langs = $db->loadObjectList();
		
		$joomlang[$locate] = $langs;
		return $langs;
	}
}