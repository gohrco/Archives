<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');
?>

<form action="index.php" method="post" name="adminForm">
<div id="adminCell">
	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_( "COM_JWHMCS_GRPMGR_VIEW_LABEL_ID" ); ?>
			</th>
			<th width="20">
				<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->data ); ?>);" />
			</th>
			<th>
				<?php echo JText::_( "COM_JWHMCS_GRPMGR_VIEW_LABEL_GROUP" ); ?>
			</th>
		</tr>
	</thead>
	<?php
	$k = 0;
	for ($i=0, $n=count( $this->data ); $i < $n; $i++)	{
		$row = &$this->data[$i];
		$checked 	= JHTML::_('grid.id',   $i, $row->id );
		$link 		= JRoute::_( 'index.php?option=com_jwhmcs&controller=grpmgr&task=userlist&cid='. $row->id );
		$name		= ($row->cname?$row->cname.': ':'').($row->lname?$row->lname.', ':'').($row->fname?$row->fname.' ':'');
		?>
		<tr class="<?php echo "row$k"; ?>">
			<td>
				<?php echo $row->id; ?>
			</td>
			<td>
				<?php echo $checked; ?>
			</td>
			<td>
				<a href="<?php echo $link; ?>"><?php echo $name; ?></a>
			</td>
		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	</table>
</div>

<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="grpmgr" />
</form>