<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    Joomla! 1.5 Package
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.3.7.3 ( $Id: register.php 223 2011-05-25 19:15:48Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.5.0
 * 
 * @desc		This model handles data retrieval for the user registration view and saving
 * 				the data once submitted.  It also validates info through an ajax call
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
jimport( 'joomla.application.component.model' );	// Import model
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * JwhmcsModelRegister is the class that handles the data for the registration controller and view
 * @version	2.3.0
 * 
 * @since	2.1.0
 * @author	Steven
 */
class JwhmcsModelRegister extends JwhmcsModel
{
	
	/**
	 * Constructor
	 * @access	public
	 * @version	2.3.0
	 * 
	 * @since	1.5.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Retrieves the posted variables if returning to same page
	 *  - Required to return null array for strict error reporting
	 * @access		public
	 * @version		2.3.7.3
	 * 
	 * @return		array of posted variables or null array
	 * @since		2.3.2
	 */
	public function getPost()
	{
		$post = JRequest::get( "post", null );
		if ( $post == null ) {
			$post	= array();
			$vars	= array( "firstname", "lastname", "companyname", "address1", "address2", "city", "state", "postcode", "country", "phonenumber", "username", "email" );
			foreach ($vars as $v ) $post[$v] = null;
		}
		return $post;
	}
	
	
	/**
	 * Validates info prior to sending it on for registration
	 * @access	public
	 * @version	2.3.0
	 * @param	string		$type - username || email || password
	 * @param 	string		$value - to check against
	 * 
	 * @since	2.1.0
	 */
	public function validInfo( $type, $value )
	{
		$db		= & JFactory::getDBO();
		$params	= & JwhmcsParams::getInstance();
		
		switch($type):
		case 'username':
			// If nothing sent return false
			if ( is_null( $value ) || ( trim( $value ) == '' ) ) return array('result' => false, 'message' => JText::_( "COM_JWHMCS_REGISTER_AJAX_USERNAME_VALID_ERROR00" ) );
			
			// Check to see if username is an email address
			if ( ( JwhmcsHelper::isEmail( $value ) ) AND ( $params->get( "WuserAuthenticate" ) ) ) {
				return array( 'result' => false, 'message' => JText::_( "COM_JWHMCS_REGISTER_AJAX_USERNAME_VALID_ERROR01" ) );
			}
			
			// Check to see if the username is "too short"
			if ( strlen( $value ) < 3 ) return array( 'result' => false, 'message' => sprintf( JText::_( "COM_JWHMCS_REGISTER_AJAX_USERNAME_VALID_ERROR02" ), $value ) );
			
			// See if there is a user by that name
			$query	= "SELECT `id` FROM `#__users` WHERE `username` = " . $db->quote( $value );
			$db->setQuery($query);
			$result = $db->loadResult();
			
			// If we get an id back then the name is taken
			if ( $result )
			{
				return array( 'result' => false, 'message' => sprintf( JText::_( "COM_JWHMCS_REGISTER_AJAX_USERNAME_VALID_ERROR03" ), $value ) );
			}
			else
			{
				return array( 'result' => true, 'message' => sprintf( JText::_( "COM_JWHMCS_REGISTER_AJAX_USERNAME_VALID_SUCCESS" ), $value ) );
			}
			
			break;
			
		case 'email':
			// If nothing sent return false
			if ( is_null( $value ) || ( trim( $value ) == '' ) ) return array( 'result' => false, 'message' => JText::_( "COM_JWHMCS_REGISTER_AJAX_EMAIL_VALID_ERROR00" ) );
			
			// Check to see if the value is an email address
			if (! JwhmcsHelper::isEmail( $value) ) return array( 'result' => false, 'message' => JText::_( "COM_JWHMCS_REGISTER_AJAX_EMAIL_VALID_ERROR01" ) );
			
			// See if there is a user by that name
			$query	= "SELECT `id` FROM `#__users` WHERE `email` = " . $db->quote( $value );
			$db->setQuery($query);
			$result = $db->loadResult();
			
			if ( $result )
				return array( 'result' => false, 'message' => sprintf( JText::_( "COM_JWHMCS_REGISTER_AJAX_EMAIL_VALID_ERROR02" ), $value ) );
			
			if ( JwhmcsHelper::getWhmcsUser( $value, 'email', 'client' ) !== false )
				return array( 'result' => false, 'message' => sprintf( JText::_( "COM_JWHMCS_REGISTER_AJAX_EMAIL_VALID_ERROR03" ), $value ) );
			
			if ( JwhmcsHelper::getWhmcsUser( $value, 'email', 'contact' ) !== false )
				return array( 'result' => false, 'message' => sprintf( JText::_( "COM_JWHMCS_REGISTER_AJAX_EMAIL_VALID_ERROR04" ), $value ) );
			
			if ( $this->_blockFreeEmail( $value ) === true ) {
				return array( 'result' => false, 'message' => sprintf( JText::_( 'COM_JWHMCS_REGISTER_AJAX_EMAIL_VALID_ERROR05' ), $value ) );
			}
			
			return array( 'result' => true, 'message' => sprintf( JText::_( "COM_JWHMCS_REGISTER_AJAX_EMAIL_VALID_SUCCESS" ), $value ) );
			break;
			
		case 'password':
			// If nothing sent return false
			if ( is_null( $value ) || ( trim( $value ) == '' ) ) return array( 'result' => false, 'message' => JText::_( "COM_JWHMCS_REGISTER_AJAX_PASSWORD_VALID_ERROR00" ) );
			
			// Retrieve setting in WHMCS for password strength
			$stdpws = $this->_getPWSetting();
			$thispw = $this->_getPasswordStrength( $value );
			
			if ( $thispw < $stdpws ) return array( 'result' => false, 'message' => sprintf( JText::_( "COM_JWHMCS_REGISTER_AJAX_PASSWORD_VALID_ERROR01" ), $thispw, $stdpws ) );
			
			return array( 'result' => true, 'message' => JText::_( "COM_JWHMCS_REGISTER_AJAX_PASSWORD_VALID_SUCCESS" ) );
			break;
		endswitch;
	}
	
	
	/**
	 * Retrieve the active password strength from WHMCS
	 * @access	private
	 * @version	2.3.0
	 * 
	 * @return	string containing password strength set
	 * @since	2.1.0
	 */
	private function _getPWSetting()
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		$jcurl->setAction('jwhmcsgetsettings', array("get" => "RequiredPWStrength"));
		$whmcs = $jcurl->loadResult();
		
		if ( empty($whmcs) || ( $whmcs['result'] != 'success' ) )
			return 0;
		
		return $whmcs['requiredpwstrength'];
	}
	
	
	/**
	 * Determine the password strength according to WHMCS rules
	 * @access	private
	 * @version	2.3.0
	 * @param	string		$pw - contains password to check
	 * 
	 * @return	integer indicating password strength as calculated
	 * @since	2.1.0
	 */
	private function _getPasswordStrength( $pw )
	{
		// String Length
		$pwlength = strlen($pw);
		if ( $pwlength > 5 ) $pwlength = 5;
		
		// How many numbers
		$numnumeric = preg_replace( "/[0-9]/", "", $pw );
		$numeric = strlen( $pw ) - strlen( $numnumeric );
		if ( $numeric > 3 ) $numeric = 3;
		
		// How many symbols
		$symbols = preg_replace( "/\W/", "", $pw );
		$numsymbols = strlen( $pw ) - strlen( $symbols );
		if ( $numsymbols > 3 ) $numsymbols = 3;
		
		// How many uppercase
		$numupper = preg_replace( "/[A-Z]/", "", $pw );
		$upper = strlen( $pw ) - strlen( $numupper );
		if ( $upper > 3 ) $upper = 3;
		
		// Calculate password strength
		$pwstrength = ( ( $pwlength * 10 ) - 20 ) + ( $numeric * 10 ) + ( $numsymbols * 15 ) + ( $upper * 10 );
		
		// Keep strength between 0 and 100 and return
		if ( $pwstrength < 0 ) $pwstrength = 0;
		if ( $pwstrength > 100 ) $pwstrength = 100;
		return $pwstrength;
	}
	
	
	/**
	 * Checks to see if an email is from a free email service if it should block them
	 * @access		private
	 * @version		2.3.7.3
	 * @param		string		- $email: containing the address to check
	 * 
	 * @return		boolean true if it should be blocked, false otherwise
	 * @since		2.2.6
	 */
	private function _blockFreeEmail( $email )
	{
		$params	= & JwhmcsParams::getInstance();
		if ( $params->get( "RegNofreeemail" ) == "0" ) return false;
		
		$domains	= explode( ",", $params->get( "RegNofreeemaildomains" ) );
		for($i=0;$i<count($domains);$i++) $domains[$i] = trim($domains[$i]);
		
		$eparts	= explode("@",$email);
		if ( in_array( $eparts[1], $domains ) ) return true;
		return false;
	}
}