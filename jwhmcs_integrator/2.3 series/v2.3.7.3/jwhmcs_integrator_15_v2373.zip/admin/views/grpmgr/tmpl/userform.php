<?php defined('_JEXEC') or die('Restricted access');

jimport('joomla.html.pane');
JHTML::_('behavior.mootools');
JHTML::_('behavior.tooltip');
JHTML::_('behavior.formvalidation');

?>


<form id="adminForm" name="adminForm" method="post" class="form-validate">
<div class="col100">
<table width="100%" class="admintable">
	<tr>
		<td width="100" align="right" class="key">
			<label for="name">
				<?php
				$title = JText::_( 'JWHMCS_ADMIN_LABEL_JUSER' );
				echo JHTML::_('tooltip', JText::_( 'JWHMCS_ADMIN_TIP_GMUSRADD' ), $title, null, $title); ?>
			</label>
		</td>
		<td>
			<div class="jwhmcs-fieldwrap">
				<?php echo $this->data->joomlaid; ?><br />
				<?php echo JText::_( 'JWHMCS_ADMIN_LABEL_GMUAN' ); ?>
			</div>
		</td>
	</tr>
</table>
</div>

<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="controller" value="grpmgr" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="groupid" value="<?php echo $this->data->groupid; ?>" />
<input type="hidden" name="id" value="<?php echo $this->data->id; ?>" />
</form>

<script language="javascript">
function myValidate(f) {
        if (document.formvalidator.isValid(f)) {
                return true; 
        }
        else {
                alert('<?php echo JText::_( 'JWHMCS_MSG_INVALID' ); ?>');
        }
        return false;
}

function submitbutton(pressbutton) {
	var form = document.adminForm;

	if (pressbutton == 'cancel') {
		submitform( pressbutton );
		return;
	}

	if (myValidate(form) == true) {
		submitform( pressbutton );
	}
	
}
</script>