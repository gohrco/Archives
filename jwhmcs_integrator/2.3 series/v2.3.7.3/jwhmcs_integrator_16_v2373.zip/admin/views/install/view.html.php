<?php
/**
 * WHMCS User Synchrization View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: view.html.php 169 2011-02-04 05:39:14Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsViewSync
 * Extends:		JView
 * Purpose:		Used as the WHMCS User Synchrization view
 * 
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsViewInstall extends JView
{
	/* ------------------------------------------------------------ *\
	 * Method:		display
	 * Purpose:		Assembles the page for the application to send to
	 * 				the user
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function display($tpl = null)
	{
		$model	= & $this->getModel( 'install' );
		$task	= JRequest::getVar( 'task' );
		$data	= $model->$task();
		
		switch($task):
		case 'apiconxn' :
			JToolBarHelper :: title( JText::_( 'COM_JWHMCS_INSTALL_VIEW_APICNXN_TITLE' ), 'apiconxn.png' );
			JToolBarHelper :: custom( 'apiconxnAccept', 'save.png', '', JText::_( 'COM_JWHMCS_INSTALL_VIEW_APICNXN_BUTTON_SAVESETTINGS' ), false, false );
			JToolBarHelper :: divider();
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
			break;
		case 'license' :
			JToolBarHelper :: title( JText::_( 'COM_JWHMCS_INSTALL_VIEW_LICENSE_TITLE' ), 'license.png' );
			JToolBarHelper :: custom( 'licenseReload', 'licreload.png', '', JText::_( 'COM_JWHMCS_INSTALL_VIEW_LICENSE_BUTTON_RELOAD' ), false, false );
			JToolBarHelper :: custom( 'licenseAccept', 'save.png', '', JText::_( 'COM_JWHMCS_INSTALL_VIEW_LICENSE_BUTTON_LICENSESAVE' ), false, false );
			JToolBarHelper :: divider();
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
			break;
		case 'interview':
			JToolBarHelper :: title( JText::_( 'COM_JWHMCS_INSTALL_VIEW_INTERVIEW_TITLE' ).': <small><small>[ ' . JText::_( 'COM_JWHMCS_INSTALL_VIEW_INTERVIEW_AUTO_TITLE' ).' ]</small></small>', 'settings.png' );
			JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
			break;
		case 'manual' :
		default:
			JToolBarHelper :: title( JText::_( 'JWHMCS_ADMIN_INSTALL_TITLE' ).': <small><small>[ ' . JText::_( 'JWHMCS_ADMIN_INSTALL_MANUAL' ).' ]</small></small>', 'install.png' );
			JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
			JToolBarHelper::divider();
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
		endswitch;
		
		JHTML::script("com_jwhmcs/ajax.js", array(), true);
		JHtml::stylesheet( "com_jwhmcs/icons.css", array(), true );
		JHTML::stylesheet( "com_jwhmcs/install.css", array(), true );
		
		$this->assignRef('data', $data);
		parent::display($tpl);
	}
}