<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: jwhmcs_pricing.php 169 2011-02-04 05:39:14Z steven_gohigher $
 * @since      2.10
 * 
 * @desc		This plugin locates tags embedded in modules and content of a
 * 				site and replaces them with the appropriate pricing from WHMCS.
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.plugin.plugin');

$curlfile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jwhmcs'.DS.'classes'.DS.'class.curl.php';
if (is_readable($curlfile)) include_once($curlfile);

/**
 * System Plugin
 *
 * @package		J!WHMCS Integrator:  Pricing Plugin 
 * @since 		2.21
 */
class plgSystemJwhmcs_pricing extends JPlugin {

	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param object $subject The object to observe
	 * @param 	array  $config  An array that holds the plugin configuration
	 * @since 1.5
	 */
	function plgSystemJwhmcs_pricing(& $subject, $config)
	{
		$this->params = new JParameter( $config['params'] );
		parent::__construct($subject, $config);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	onAfterRender
	 * Purpose:		Runs to apply pricing to modules
	 * As of:		version 2.2 (December 2010)
	\* ------------------------------------------------------------ */
	function onAfterRender()
	{
		$app = JFactory::getApplication();
		if ($app->isAdmin()) return;
		
		$dispatcher = JDispatcher::getInstance();
		
		$body		= JResponse::getBody();
		$params		= array();
		
		$regex = '/{whmcs\s*\|(?<type>[^\|}]*)\|(?<id>[^\|}]*)\|(?:(?<currency>[^\|}]*)\|)?(?<freq>[^\|}]*)[^}]*}/i';
		
		if (! $this->params->get( 'enabled', 1 ) )
		{
			$body = preg_replace( $regex, '', $body );
			JResponse::setBody( $body );
			return true;
		}
		
		preg_match_all( $regex, $body, $matches, PREG_SET_ORDER );
		
		$count = count( $matches[0] );
		
		if ( $count )
		{
			foreach ( $matches as $match )
			{
				$price	= '';
				$by = ( is_numeric( $match['id'] ) ? 'id' : 'name' );
				$price	= $this->_getPrice( array( 'type' => $match['type'], 'id' => $match['id'], 'freq' => $match['freq'], 'curr' => ((! $match['currency'] ) ? false : $match['currency'] ) ), $by );
				$body = str_replace( $match[0], $price, $body );
			}
		}
		
		JResponse::setBody( $body );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getPrice
	 * Purpose:		Actually performs the price retrieval
	 * As of:		version 2.1.1 (June 2010)
	\* ------------------------------------------------------------ */
	protected function _getPrice( $options = array(), $by = 'id' )
	{
		static $prices = array();
		
		$serialized = serialize( $options );
		
		if (! isset( $prices[$serialized] ) )
		{
			$jcurl	= JwhmcsCurl::getInstance();
			$params	= $this->params;
			
			$type	= $this->_getType( strtolower( $options['type'] ) );
			$id		= $options['id'];
			$freq	= $this->_getFreq( strtolower( $options['freq'] ) );
			$curr	= strtoupper( $this->_getCurr( $options['curr'] ) );
			
			$jcurl->setAction('jwhmcsgetpricing', array("price" => "$type,$id,$freq,$curr", "by" => "$by" ));
			$whmcs	= $jcurl->loadResult();
			
			$price = null;
			if( $whmcs['result'] == 'success' )
			{
				$price = ( $params->get( "showprefix", false ) ? $whmcs['prefix'] : "" ) . $whmcs['price'] . ( $params->get( "showsuffix", false ) ? " " . $whmcs['suffix'] : "" );
			}
			
			$prices[$serialized] = $price;
		}
		
		return $prices[$serialized];
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getType
	 * Purpose:		Wrapper to ensure we retrieve a correct type
	 * As of:		version 2.1.1 (June 2010)
	\* ------------------------------------------------------------ */
	protected function _getType( $type )
	{
		switch( $type ):
		case 'product':
			return 'product';
		case 'addon':
			return 'addon';
		case 'config':
			return 'configoptions';
		case 'domainaddon':
			return 'domainaddon';
		case 'domainreg':
			return 'domainregister';
		case 'domaintrans':
			return 'domaintransfer';
		case 'domainrenew':
			return 'domainrenew';
		endswitch;
		
		// Just in case I miss one
		return $type;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getFreq
	 * Purpose:		Wrapper to ensure we retrieve the wrapper
	 * As of:		version 2.1.1 (June 2010)
	\* ------------------------------------------------------------ */
	protected function _getFreq( $freq )
	{
		switch( $freq ):
		case 'monsetup':
			return 'msetupfee';
		case 'qtrsetup':
			return 'qsetupfee';
		case 'semsetup':
			return 'ssetupfee';
		case 'annsetup':
			return 'asetupfee';
		case 'biasetup':
			return 'bsetupfee';
		case 'trisetup':
			return 'tsetupfee';
		case 'monprice':
			return 'monthly';
		case 'qtrprice':
			return 'quarterly';
		case 'semprice':
			return 'semiannually';
		case 'annprice':
			return 'annually';
		case 'biaprice':
			return 'biennially';
		case 'triprice':
			return 'triennially';
		endswitch;
		
		// Just in case they add one
		return $freq;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getCurr
	 * Purpose:		Wrapper to determine currency to retrieve
	 * As of:		version 2.2 (December 2010)
	\* ------------------------------------------------------------ */
	protected function _getCurr( $curr )
	{
		$params		= $this->params;
		$default	= $params->get( "defcurrency", "USD" );
		return ( $curr === false ? $default : $curr );
	}
}