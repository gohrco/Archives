<?php
//error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
//error_reporting(E_ALL);
/**
 * J!WHMCS Integrator - Authentication Plugin
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id$
 * @since		1.5.1
 * 
 * @desc		This plugin handles authentication of the user in case they use
 * 				their email address instead of their Joomla username.
 */


// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.application.component.helper' );
include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jwhmcs'.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		plgAuthenticationPlg_auth_jwhmcs
 * Purpose:		This plugin allows the user to login with either the
 * 				email address or their username from Joomla
\* ------------------------------------------------------------ */
class plgAuthenticationJwhmcs_auth extends JPlugin
{
	/* ------------------------------------------------------------ *\
	 * Method:		plgAuthenticationPlg_auth_jwhmcs
	 * Purpose:		Constructor function
	\* ------------------------------------------------------------ */
	function plgAuthenticationJwhmcs_auth(& $subject, $config)
	{
		parent::__construct($subject, $config);
		
		// Retrieve the component and plugin parameters and set them
		$component	  = JComponentHelper::getComponent( 'com_jwhmcs' );
  		$params = new JParameter( $component->params );
  		$this->params->merge($params);
  		$this->_setComid();
	}

	
	/* ------------------------------------------------------------ *\
	 * Method:		onAuthenticate
	 * Purpose:		Handles user authentication procedure for customer
	\* ------------------------------------------------------------ */
	function onAuthenticate( $credentials, &$options, &$response )
	{
		// 0a:  Set Initial Variables
		global $mainframe;
		// $options['return'] has the unencoded url for returning
		
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		
		jimport('joomla.user.helper');
		jimport ('joomla.error.log');
		$conditions = '';
		
		// 0b: Test for blank password
		if (empty($credentials['password']))
		{
			$response->status = JAUTHENTICATE_STATUS_FAILURE;
			$response->error_message = 'Empty password not allowed';
			return false;
		}
		
		/* ----------------------------------- */
		/* Test to see if username is an email */
		/* ----------------------------------- */
		if ($this->_checkEmail($credentials['username']))  
		{	/* ------------------------------------- */
			/* Username is actually an email address */
			/* ------------------------------------- */
			
			// 1:  Retrieve WHMCS data by email address
			$jcurl->setAction('getclientsdatabyemail', array('email' => $credentials['username']));
			$whmcs	= $jcurl->loadResults();
			
			if ($whmcs['result']!='success'):
				$response->status = JAUTHENTICATE_STATUS_FAILURE;
				$response->error_message = 'Please contact the administrator';
				return false;
			endif;
			
			// 2:  Test password sent with password from WHMCS DB
			if (! $this->_testWhmcsPassword($whmcs['password'], $credentials['password'])) :
				$response->status = JAUTHENTICATE_STATUS_FAILURE;
				$response->error_message = 'Invalid Password';
				return false;
			endif;
			
			// 3:  Get Joomla ID from xref table for logging in
			$query	= 'SELECT `xref_a` as joomlaid, `xref_type` as type, `xref_b` as clientid FROM #__jwhmcs_xref WHERE xref_b='.$whmcs['userid'].' AND (xref_type=1 OR xref_type=2 OR xref_type=3 OR xref_type=4)';
			$db->setQuery($query);
			$joom	= $db->loadObjectList();
			
			$joom	= $this->_checkOrphaned($joom, 'joomla');
			
			// 4:  Test to ensure something was returned
			if (!$joom)
			{
				/* ---------------------------------------- */
				/* There is no xref in the DB by that email */
				/* ---------------------------------------- */
				// 4x:  Test to see if an email already exists in Joomla DB
				$query	= 'SELECT `id` FROM #__users WHERE `email`='.$db->Quote($credentials['username']);
				$db->setQuery($query);
				$existing = $db->loadResult();
				
				if ($existing) $this->params->set( 'autoaddjoomla', 0);
				// 4a1: If nothing returned, check parameter to auto add to Joomla
				if ($this->params->get( 'autoaddjoomla' )):
					// 4a1a: Add Joomla user to DB
					$acl	= &JFactory::getACL();
					$user	= JFactory::getUser(0);	
					$usersConfig	=& JComponentHelper::getParams( 'com_users' );
					
					$newUsertype = $usersConfig->get( 'new_usertype' );
					if (!$newUsertype)
						$newUsertype = 'Registered';
					
					// Build the user array for binding
					$ubind['name']		= $whmcs['firstname'].' '.$whmcs['lastname'];
					$ubind['username']	= strtolower($whmcs['firstname'].'.'.$whmcs['lastname']);
					$ubind['email']		= $whmcs['email'];
					$ubind['gid']		= $acl->get_group_id( '', $newUsertype, 'ARO' );
					$ubind['password']	= $credentials['password'];
					$ubind['password2']	= $credentials['password'];
					$ubind['sendEmail']	= 0;
					$ubind['block']		= 0;
					
					// Bind the post array to the user object
					if (!$user->bind( $ubind )):
						$response->status = JAUTHENTICATE_STATUS_FAILURE;
						$response->error_message = 'Invalid Username or Password';
						return false;
					endif;
					
					$date =& JFactory::getDate();
					$user->set('registerDate', $date->toMySQL());
					
					// If there was an error with registration, set the message and display form
					if ( !$user->save() )
					{
						$response->status = JAUTHENTICATE_STATUS_FAILURE;
						$response->error_message = 'Invalid Password';
						return false;
					}
					
					// 4a1b: Add new user to xref DB
					$query = 'INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) '
								.'VALUES ("'.$user->id.'", "1", '.$whmcs['userid'].')';
					$db->setQuery($query);
					$db->query();
				else:
					// 4a2a: Throw error
					$response->status = JAUTHENTICATE_STATUS_FAILURE;
					$response->error_message = 'Invalid Username or Password';
					return false;
				endif;
			}
			else
			{
				/* ---------------------------------------- */
				/* There is an xref in the DB by that email */
				/* ---------------------------------------- */
				// 4b1: Something returned, so authenticate by pulling user by id
				$query	= 'SELECT a.* FROM `#__users` AS a WHERE email='.$db->Quote($credentials['username']);
				$db->setQuery($query);
				$user	= $db->loadObject();
				
				// 4b2: Ensure the user exists
				if (!$user):
					$response->status = JAUTHENTICATE_STATUS_FAILURE;
					$response->error_message = 'Username does not exist';
					return false;
				endif;
				
				// 4b3: Check password retrieved
				$testcrypt = $this->_parseJPassword($user->password, $credentials['password']);
				
				if ($testcrypt['salted'] != $user->password):
					// 4b4: Password doesn't match, auto update password?
					if ($this->params->get( 'autoupdatejoomlapw' )):
						// 4b5: Update password
						$query	= 'UPDATE `#__users` SET `password`='.$db->Quote($testcrypt['salted']).' WHERE `id`='.$joom->joomlaid;
						$db->setQuery($query);
						$db->query();
					else:
						// 4b6: Throw error logging in
						$response->status	= JAUTHENTICATE_STATUS_FAILURE;
						$response->error_message = 'Invalid Password';
						return false;
					endif;
				endif;
			}
		} else {
			/* ------------------------------------- */
			/* Username sent is not an email address */
			/* ------------------------------------- */
			// 1a:  Retrieve Joomla login information
			$query	= 'SELECT a.* FROM `#__users` AS a WHERE username='.$db->Quote($credentials['username']);
			$db->setQuery($query);
			$user	= $db->loadObject();
			
			// 1b: Test to ensure data was passed
			if (!$user):
				$response->status = JAUTHENTICATE_STATUS_FAILURE;
				$response->error_message = 'Username does not exist';
				return false;
			endif;
			
			// 2:  Create encrypted version of sent password for comparison
			$testcrypt = $this->_parseJPassword($user->password, $credentials['password']);
			
			
			// 2b:  Test password sent against encrypted password
			if ($mainframe->isAdmin()):
				if ($testcrypt['salted'] == $user->password):
					$response->email = $user->email;
					$response->fullname = $user->name;
					$response->status = JAUTHENTICATE_STATUS_SUCCESS;
					$response->error_message = '';
					return true;
				else:
					$response->status = JAUTHENTICATE_STATUS_FAILURE;
					$response->error_message = 'Invalid password';
					return false;
				endif;
			else:
				if ($testcrypt['salted'] != $user->password):
					$response->status = JAUTHENTICATE_STATUS_FAILURE;
					$response->error_message = 'Invalid Password';
					return false;
				endif;
			endif;
			
			// 3a: Pull clientid from xref table
			$query	= 'SELECT `xref_a` as joomlaid, `xref_type` as type, `xref_b` as clientid FROM #__jwhmcs_xref WHERE xref_a='.$user->id.' AND xref_type IN ("1", "2", "3", "4")';
			$db->setQuery($query);
			$whm	= $db->loadObjectList();
			
			// 3b: Check for orphaned xrefs and return only the legit one (if any)
			$whm	= $this->_checkOrphaned($whm, 'whmcs');
			$whm	= $this->_checkGroup($whm);
			
			if ($whm->password)
				$credentials['password'] = $whm->password;
			
			// 4:  Test to ensure something was returned
			if (!$whm)
			{
				/* ------------------------------------------- */
				/* There is no xref in the DB by that username */
				/* ------------------------------------------- */
				// 4x:  Test to see if an email already exists in WHMCS DB
				$jcurl->setAction('getclientsdatabyemail', array('email' => $user->email));
				$whmcs	= $jcurl->loadResult();
				
				if ($whmcs['result']=='success') $this->params->set( 'autoaddwhmcs', 0 );
				
				// 4a1: If nothing returned, check parameter to auto add to Joomla
				if ($this->params->get( 'autoaddwhmcs' )):
					// 4a1a: Add New WHMCS user to DB
					$fields['firstname']	= $credentials['username'];
					$fields['lastname']		= '(web site user)';
					$fields['address1']		= $this->params->get( 'whmcsaddress' );
					$fields['city']			= $this->params->get( 'whmcscity' );
					$fields['state']		= $this->params->get( 'whmcsstate' );
					$fields['postcode']		= $this->params->get( 'whmcspostal' );
					$fields['country']		= $this->params->get( 'whmcscntry' );
					$fields['phonenumber']	= $this->params->get( 'whmcsphone' );
					$fields['currency']		= '1';
					$fields['email']		= $user->email;
					$fields['password2']	= $credentials['password'];
					
					// 4a1b: Send to curl for adding user and get id back
					$jcurl->setAction('addclient', $fields);
					$whmcs	= $jcurl->loadResult();
					
					// 4a1c: Add new user to xref DB
					$query = 'INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) '
								.'VALUES ("'.$user->id.'", "1", '.$whmcs['clientid'].')';
					$db->setQuery($query);
					$db->query();
				else:
					// 4a2a: Allow Joomla login, but throw warning
					JError::raiseNotice(100, JText::_('No client details could be found matched to your username.'));
				endif;
			} else {
				/* ------------------------------------------- */
				/* There is an xref in the DB by that username */
				/* ------------------------------------------- */
				
				// 4b1: Something was returned, now retrieve info by ID
				if ($whm->type==4) {
					$action				= 'getclientsdatabyemail';
					$fields['email']	= $whm->email;
				}
				else {
					$action				= 'getclientsdata';
					$fields['clientid']	= $whm->clientid;
				}
				
				$jcurl->setAction($action, $fields);
				$whmcs	= $jcurl->loadResult();
				
				// 4b2:  Test password sent with password from WHMCS DB
				if (! ($encpw = $this->_testWhmcsPassword($whmcs['password'], $credentials['password'] ) ) ) :
					
					// 4b4: Password doesn't match, auto update password?
					if ($this->params->get( 'autoupdatewhmcspw' )):
						// Begin by checking what version of WHMCS is used
						$whmcsvers = str_replace('.','',$this->params->get( 'whmcsvers' ));
						$fields['password2']	= ( $whmcsvers >= '410' ? $credentials['password'] : $encpw );
						$fields['clientid']		= $whmcs['userid'];
						$jcurl->setAction('updateclient', $fields);
						$whmcs	= $jcurl->loadResult();
						
					else:
						// 4b6: Throw error logging in
						JError::raiseNotice(100, JText::_('Your web site password does not match your client login.  Please contact the site administrator.'));
					endif;
				endif;
			}
		}
		
		/* ----------------------------------------- */
		/* All checks have cleared, now set response */
		/* ----------------------------------------- */
		// 5:  Everything checked out, return OK
		$response->email		= $user->email;
		$response->username		= $user->username;
		$response->fullname		= $user->name;
		$response->status = JAUTHENTICATE_STATUS_SUCCESS;
		$response->error_message = '';
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_parseJPassword (private)
	 * Purpose:		This function parses and returns encrypted Joomla
	 * 				password for comparison purposes.
	 * ------------------------------------------------------------ */
	private function _parseJPassword($curpass, $newpass)
	{
		$parts	= explode( ':', $curpass );
		$crypt	= $parts[0];
		$salt	= @$parts[1];
		$ret['password']	= JUserHelper::getCryptedPassword($newpass, $salt);
		$ret['salted']		= $ret['password'].':'.$salt;
		return $ret;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_parseWPassword (private)
	 * Purpose:		This function parses and returns encrypted WHMCS
	 * 				password for comparison purposes.
	 * ------------------------------------------------------------ */
	private function _parseWPassword($encoded, $clear)
	{
		$pwexp	= explode(':', $encoded);
		return md5($pwexp[1].$clear).':'.$pwexp[1];
	}
	
	
	private function _testWhmcsPassword($encoded, $clear)
	{
		$jcurl = & JwhmcsCurl::getInstance();
		
		if ($this->params->get( 'nomd5' )) {	// We are not using MD5
			$jcurl->setAction('decryptpassword', array('password2' => $encoded));
			$whmcs	= $jcurl->loadResult();
			
			if ($whmcs['result'] == 'success') { 
				$return = ( $whmcs['password'] == $clear ? true : false );
			}
		}
		else {	// We are using MD5 here
			$testpw = $this->_parseWPassword($encoded, $clear);
			$return = ( $testpw == $encoded ? $testpw : false );
		}
		return $return;
	}
	
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkOrphaned (private)
	 * Purpose:		This function checks the xref table at the time of
	 * 				login and will verify there is an account matched
	 * 				up.  An array of objects are sent to it, and only
	 * 				the single legit xref should be sent back, if none
	 * 				then null so automatic account creation can
	 * 				proceed if desired.
	 * 				
	 * 				(big thanks to Komang for this catch!)
	 * ------------------------------------------------------------ */
	private function _checkOrphaned($xref, $system)
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		
		for ($i=0; $i<count($xref); $i++):
			$x = $xref[$i];
			switch($system):
			case 'joomla':	// We are testing for a set of Joomla IDs
				// Add error testing for xref'd Joomla ID
				$query = 'SELECT a.id FROM #__users as a WHERE id='.$x->joomlaid;
				$db->setQuery($query);
				$joom	= $db->loadResult();
				
				if (!$joom):
					$query = 'DELETE FROM #__jwhmcs_xref WHERE xref_a='.$x->joomlaid.' AND xref_type='.$x->type.' AND xref_b='.$x->clientid;
					$db->setQuery($query);
					$db->query();
					unset($xref[$i]);
				else:
					$ret = $xref[$i];
				endif;
				break;
			case 'whmcs':	// We are testing for a set of WHMCS IDs
				if ($x->type==4):
					// Pull the email and password from jwhmcs_user table
					$query	= 'SELECT grp.email as email FROM #__jwhmcs_group AS grp WHERE id='.$x->clientid;
					$db->setQuery($query);
					
					if ($joom = $db->loadObject()):
						$action				= 'getclientsdatabyemail';
						$fields['email']	= $joom->email;
					else:
						// WHMCS account must not exist, so break switch and reloop
						break;
					endif;
				else:
					$action				= 'getclientsdata';
					$fields['clientid']	= $x->clientid;
				endif;
				
				$jcurl->setAction($action, $fields);
				$whmcs	= $jcurl->loadResult();
				
				if ($whmcs['result']!='success'):
					$query = 'DELETE FROM #__jwhmcs_xref WHERE xref_a='.$x->joomlaid.' AND xref_type='.$x->type.' AND xref_b='.$x->clientid;
					$db->setQuery($query);
					$db->query();
					unset($xref[$i]);
				else:
					$ret = $xref[$i];
				endif;
				break;
			endswitch;
		endfor;
		
		if (count($xref)==0)
			$ret = null;
		
		return $ret;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkGroup (private)
	 * Purpose:		This function checks the xref_type field prior to
	 * 				pulling data for authentication against WHMCS just
	 * 				in case they belong to a group.  If so, (type 4)
	 * 				then their credentials are changed to match correct
	 * 				credentials for group.
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	private function _checkGroup(&$xref)
	{
		// 0:  Check type to see if we need to continue
		if ($xref->type<>4)
			return $xref;
		
		// 1:  We need this, so lets initialize variables 
		$db	= &JFactory::getDBO();
		
		// 2:  Use clientid to pull user from jwhmcs_group table to retrieve pw
		$query	= 'SELECT grp.email, grp.password FROM #__jwhmcs_group AS grp WHERE grp.id='.$xref->clientid;
		$db->setQuery($query);
		if ($res = $db->loadObject()):
			$xref->password	= $res->password;
			$xref->email		= $res->email;
		endif;
		
		// 3:  Return correct xref
		return $xref;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_setComid (private)
	 * Purpose:		This function pulls the component id from the table
	 * 				jos_components and passes it along to the file in
	 * 				WHMCS/jwhmcs.php for pulling parameters purposes
	\* ------------------------------------------------------------ */
	private function _setComid()
	{
		$db =& JFactory::getDBO();
		
		// Find the installed instance of com_jwhmcs and pull the id for storage
		$query	= 'SELECT `id` FROM #__components WHERE `option`="com_jwhmcs"';
		$db->setQuery($query);
		$cjw	= $db->loadAssoc();
		
		$this->params->set( 'comid', $cjw['id'] );
		return;
	}

	
	private function _checkEmail($username)
	{
		// This is the pattern we are using to test for
		$pattern = "/\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,5}\b/i";
		$match = preg_match($pattern, $username);
		
		if (!$match)
			return false;
		elseif ($match > 0)
			return true;
		else
			return false;
	}
}
