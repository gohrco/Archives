<?php
/**
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id$
 * @since		1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsInstall
 * Purpose:		Primary class called to handle file installation
 * As of:		version 2.0.2
\* ------------------------------------------------------------ */
class JwhmcsInstall
{
	private static $instance = null;
	private static $fileset	 = false;
	
	var $whmcsvers	= null;
	var $jwhmcsvers	= null;
	var $pathjoomla	= null;
	var $pathwhmcs	= null;
	var $task		= null;
	var $DS			= null;
	var $files		= array();
	var $taskarray	= array('install' => 1, 'upgrade' => 2, 'uninstall' => 4);
	
	var $errorarray = array(	1		=> 'Task is not set to be performed.',
								2		=> 'Source file is missing.',
								4		=> 'Destination directory permissions incorrect.',
								8		=> 'Destination file exists and can not be overwritten.',
								16		=> 'Destination file exists and can not be overwritten due to incorrect permissions.',
								32		=> 'File cannot be installed for current version of WHMCS.',
								64		=> 'File cannot be installed for current version of WHMCS.',
								1024	=> 'Error copying file',
								2048	=> 'Error deleting destination file',
								4096	=> 'Error renaming source to destination file',
								8192	=> 'Unable to create destination directory',
								16384	=> 'Error copying file in nested directory',
								32768	=> 'Error deleting destination file in nested directory',
								65536	=> 'Error renaming source to destination file in nested directory',
								131072	=> 'Error opening source directory for copying');
	
    /* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Called upon initialization of class object
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	private function __construct($options)
	{
		$this->pathjoomla	= $options['pathjoomla'];
		$this->pathwhmcs	= $options['pathwhmcs'];
		$this->DS			= DIRECTORY_SEPARATOR;
		$this->jwhmcsvers	= $this->_setVersion($options['jwhmcs']);
		$this->wdb			= $this->_loadWdb();
		$this->wsettings	= $this->_getWhmcsSettings();
		$this->whmcsvers	= $this->_setVersion($this->wsettings['version']);
		$this->task			= $this->_setTask($options['task']);
		
		if (! $this->task) return false;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	getInstance
	 * Purpose:		Called to create an instance of the class
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	public static function getInstance($options = false)
	{
		if (!$options) return false;
		
		if (self::$instance == null)
		{
			self::$instance = new self($options);
		}
		return self::$instance;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	loadManifest
	 * Purpose:		Pulls the manifest file and sets file objects
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	function loadManifest($fn = false)
	{
		if (!$fn) return false;
		if ($this->fileset) return false;	// Manifest file already set
		$file = file($fn);
		$file = preg_replace('/\//i', $this->DS, $file);
		$file = preg_replace('/<%J%>/i', $this->pathjoomla, $file);
		$file = preg_replace('/<%W%>/i', $this->pathwhmcs, $file);
		$file = preg_replace('/[\t\r\n]/i', '',$file);
		
		foreach($file as $line) {
			$option = explode(",", $line);
			$option[0] = $this->_setVersion($option[0]);
			$option[1] = $this->_setVersion($option[1]);
			$ifile	= new JwhmcsInstallFile($option);
			$ifile->checkFile($this->task, $this->whmcsvers, $this->jwhmcsvers);
			$this->files[] = $ifile;
			unset ($option, $ifile);
		}
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	runInstall
	 * Purpose:		Called to perform the actual installation
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	function runInstall()
	{
		// Part 1:  File Handling
		for ($i=0; $i < count($this->files); $i++)
		{
			$f =& $this->files[$i];
			
			$f->time = date("Y M d :: g:i:s T");
			
			// Check first to see if we both doing anything with the file
			if (! $f->performaxn) {
				$f->complete = true;
				$f->errormsg = $this->errorarray[$f->error];
				continue;
			}
			
			// Run Installation
			if ($this->task & 1)
			{
				$cp = (($f->action & 2) ? true : false );
				$ow = (($f->action & 4) ? true : false );
				try {
					$this->_recursive_copy($f->filesrc, $f->filedst, $ow, $cp);
				} catch(Exception $e) {
					$f->error = $e->getMessage();
				}
				
				$f->complete = true;
			}
			// Run Upgrade
			elseif ($this->task & 2)
			{
				$cp = (($f->action & 2) ? true : false );
				$ow = (($f->action & 4) ? true : false );
				try {
					$this->_recursive_copy($f->filesrc, $f->filedst, $ow, $cp);
				} catch(Exception $e) {
					$f->error = $e->getMessage();
				}
				$f->complete = true;
			}
			// Run Uninstallation
			elseif ($this->task & 4)
			{
				try {
					if ($f->action & 8) {
						$this->_recursive_delete($f->filedst);
					}
					else {
						$this->_recursive_copy($f->filedst, $f->filesrc, $true, false);
					}
				} catch(Exception $e) {
					$f->error = $e->getMessage();
				}
			}
			
			if ($f->error) {
				$f->errormsg = $this->errorarray[$f->error];
			}
			else {
				$f->errormsg = 'Task completed';
			}
		} // files for
		
		// Part 2:  Database Handling
		if ($this->task & 1) {
			
		}
		elseif ($this->task & 2) {
			
		}
		elseif ($this->task & 4) {
			
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * 			PRIVATE FUNCTIONS									*
	\* ------------------------------------------------------------ */
	
	/* ------------------------------------------------------------ *\
	 * Function:	_loadWdb (private)
	 * Purpose:		Loads and creates the instance of the WHMCS DB
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	private function _loadWdb()
	{
		include($this->pathwhmcs.$this->DS.'configuration.php');
		$config['host']		= $db_host;
		$config['user']		= $db_username;
		$config['password']	= $db_password;
		$config['database']	= $db_name;
		$config['prefix']	= 'tbl';
		return JwhmcsDBO::getInstance($config);	// WHMCS DB
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getWhmcsSettings (private)
	 * Purpose:		Pulls the current settings from WHMCS
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	private function _getWhmcsSettings()
	{
		$wb		= & $this->wdb;
		$data	= array();
		
		$query	= 'SELECT `setting`, `value` FROM #__configuration ORDER BY setting';
		$wb->setQuery($query);
		$result	= $wb->loadAssocList();
		
		foreach ($result as $r) {
			$data[strtolower($r['setting'])] = $r['value'];
		}
		
		$query	= 'SELECT `id` FROM #__currencies WHERE `default` = 1';
		$wb->setQuery($query);
		$data['defaultcurrency'] = $wb->loadResult();
		
		return $data; 
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_setTask (private)
	 * Purpose:		Returns the correct task integer for given task
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	private function _setTask($task = false)
	{
		if (!$task) return false;
		if (in_array($task, $this->taskarray)) {
			$this->taskarray = array_flip($this->taskarray);
			$task = $this->taskarray[$task];
			$this->taskarray = array_flip($this->taskarray);
		}
		return $this->taskarray[$task];
	}
	
	/* ------------------------------------------------------------ *\
	 * Function:	_setVersion (private)
	 * Purpose:		Returns numeric representation of version
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	private function _setVersion($vers)
	{
		return str_replace('.', '', trim($vers));
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_recursive_copy (private)
	 * Purpose:		handle copying files from directories 
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	private function _recursive_copy($src, $dst, $ow = false, $copy = true)
	{
		// Note:  $ow = overwrite T/F
		// Test to see if src is a directory
		if ( is_dir($src) ) {
			$dir = opendir($src);
			if (!$dir) throw new Exception(131072);
			if (!@mkdir($dst)) throw new Exception(8192);
			while(false !== ( $file = readdir($dir)) ) {
				if (( $file != '.' ) && ( $file != '..' )) {
					if ( is_dir($src . DS . $file) ) {
						try {
							$this->_recursive_copy($src .DS. $file,$dst .DS. $file, $ow, $copy);
						} catch(Exception $e) {
							throw new Exception($e->getMessage());
						}
					}
					else {
						if ((file_exists($dst.DS.$file)) && ($ow == false)) {
							continue;
						}
						if ($copy) {
							if (!@copy($src.DS.$file,$dst.DS.$file)) {
								throw new Exception(16384);
							}
						}
						else {
							if (file_exists($dst.DS.$file)) {
								if (!@unlink($dst.DS.$file)) {
									throw new Exception(32768);
								}
							}
							if (!@rename($src.DS.$file,$dst.DS.$file)) {
								throw new Exception(65536);
							}
						}
					}
				}
			}
			closedir($dir);
		}
		else {
			if ((file_exists($dst)) && ($ow == false)) {
				return;
			}
			if ($copy) {
				if (!@copy($src, $dst)) {
					throw new Exception(1024);
				}
			}
			else {
				if (file_exists($dst)) {
					if (!@unlink($dst)) {
						throw new Exception(2048);
					}
				}
				if (!@rename($src,$dst)) {
					throw new Exception(4096);
				}
			}
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_recursive_delete (private)
	 * Purpose:		recursively delete files and folders 
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	private function _recursive_delete($str){
        if(is_file($str)){
            return @unlink($str);
        }
        elseif(is_dir($str)){
            $scan = glob(rtrim($str,'/').'/*');
            foreach($scan as $index=>$path){
                $this->_recursive_delete($path);
            }
            return @rmdir($str);
        }
    }
}


/* ------------------------------------------------------------ *\
 * Class:		JwhmcsInstallFile
 * Purpose:		Store data for each file to perform actions on
 * As of:		version 2.0.2
\* ------------------------------------------------------------ */
class JwhmcsInstallFile
{
	var $jwhmcsvers	= null;
	var $whmcsvers	= null;
	var $task		= null;
	var $action		= null;
	var $filesrc	= null;
	var $filedst	= null;
	
	/* Perform Action on this file?  T/F */
	var $performaxn	= false;
	
	/* Has Action been completed? T/F */
	var $complete	= false;
	
	/* Action Caused Error with file? T/F */
	var	$error		= false;
	
	/* ------------------------------------------------------------ *\
	 * Function:	__construct
	 * Purpose:		Called upon initialization of object class
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	function __construct($options = false)
	{
		if (! $options) return false;
		$this->jwhmcsvers	= $options[0];
		$this->whmcsvers	= $options[1];
		$this->task			= $options[2];
		$this->action		= $options[3];
		$this->filesrc		= $options[4];
		$this->filedst		= $options[5];
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	checkFile
	 * Purpose:		Perform logic against file parameters and set flag
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	function checkFile($task, $curwhmcs, $curjwhmcs)
	{
		// Check first if the file task is to be done
		if (!($this->task & $task)) {
			$this->error = 1;
			$this->performaxn = false;
			return;
		}
		
		// Installation Checks
		if ($this->task & 1)
		{
			// Does the src file exist?
			if (!($this->_fileExists($this->filesrc))) {
				$this->error = 2;
			}
			
			// Is there no destination file?
			if (!($this->_fileExists($this->filedst)))
			{
				// If there is no dest file, can we save it (permissions)?
				if (!($this->_canSave($this->filedst))) {
					$this->error = 4;
				}
			}
			else
			{
				// If there is a dest file, should we overwrite it?
				if (!($this->action & 4)) {
					$this->error = 8;
				}
				
				// If there is a dest file, can we overwrite it (permissions)?
				elseif (!($this->_checkPerms($this->filedst))) {
					$this->error = 16;
				}
			}
			
			// Is the action 16 bit set (install only for WHMCS vers or earler)?
			if ($this->action & 16)
			{
				// Is the current version of WHMCS newer than specified version?
				if ($curwhmcs > $this->whmcsvers) {
					$this->error = 32;
				}
			}
			
			// Is the action 32 bit set (install only for specific WHMCS vers)?
			if ($this->action & 32)
			{
				// Is the current version not the one specified for this file?
				if ($curwhmcs != $this->whmcsvers) {
					$this->error = 64;
				}
			}
			
		}
		// Upgrade Checks
		elseif ($this->task & 2) {
			// Does the src file exist?
			if (!($this->_fileExists($this->filesrc)))
			{
				$this->error = 2;
			}
			
			// Is there no destination file?
			if (!($this->_fileExists($this->filedst)))
			{
				// If there is no dest file, can we save it (permissions)?
				if (!($this->_canSave($this->filedst))) {
					$this->error = 4;
				}
			}
			else
			{
				// If there is a dest file, should we overwrite it?
				if (!($this->action & 4)) {
					$this->error = 8;
				}
				
				// If there is a dest file, can we overwrite it (permissions)?
				elseif (!($this->_checkPerms($this->filedst))) {
					$this->error = 16;
				}
			}
		}
		// Uninstallation Checks
		elseif ($this->task & 4) {
			// Does the dest file exist?
			if (!($this->_fileExists($this->filedst)))
			{
				$this->error = 2;
			}
			
			// Should it be renamed? (delete flag set to false)
			if (!($this->action & 8))
			{
				// Does the src file exist?
				if (!($this->_fileExists($this->filesrc)))
				{
					// If there is no src file, can we save it (permissions)?
					if (!($this->_canSave($this->filesrc))) {
						$this->error = 4;
					}
				}
				else
				{
					// If there is a src file, should it be replaced?
					if (!($this->action & 128)) {
						$this->error = 8;
					}
					// If there is a src file, can we replace it (permissions)?
					elseif (!($this->_checkPerms($this->filesrc))) {
						$this->error = 16;
					}
				}
			}
		}
		
		// All checks complete - set performaxn
		if (!$this->error) {
			$this->performaxn = true;
		}
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_fileExists (private)
	 * Purpose:		Container for checking if a file exists
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	private function _fileExists($file)
	{
		return file_exists($file);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_canSave (private)
	 * Purpose:		Checks to see if specified file can be saved
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	private function _canSave($file)
	{
		$rem = false;
		
		if (is_writeable(dirname($file)))
		{
			// Check to see if the file doesn't exist
			if (!$this->_fileExists($file)) {
				$rem = true;
				file_put_contents($file,'');
			}
			
			// Now check permissions via owner
			$return = $this->_checkPerms($file);
			
			// If we created the file earlier, remove it
			if ($rem) {
				@unlink($file);
			}
			return $return; 
		}
		return false;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkPerms (private)
	 * Purpose:		Check permissions of file given
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	private function _checkPerms($file)
	{
		$path	= dirname($file);
		$newf	= $path.DS.md5('jwhmcs'.date("mm/dd/yyyys")).'.txt';
		
		file_put_contents($newf, date("mm/dd/yyyys"));
		
		clearstatcache();
		$ret	= (fileowner($file) == fileowner($newf));
		$ret	= (!$ret ? filegroup($file) == filegroup($newf) : $ret );
		
		@unlink($newf);
		
		return $ret;
	}
	
	
	function getPermissions($path)
	{
		$path = $this->clean($path);
		$mode = @ decoct(@ fileperms($path) & 0777);

		if (strlen($mode) < 3) {
			return '---------';	
		}
		$parsed_mode = '';
		for ($i = 0; $i < 3; $i ++)
		{
			// read
			$parsed_mode .= ($mode { $i } & 04) ? "r" : "-";
			// write
			$parsed_mode .= ($mode { $i } & 02) ? "w" : "-";
			// execute
			$parsed_mode .= ($mode { $i } & 01) ? "x" : "-";
		}
		return $parsed_mode;
	}
	
	
	function clean($path, $ds=DS)
	{
		$path = trim($path);

		if (empty($path)) {
			$path = JPATH_ROOT;
		} else {
			// Remove double slashes and backslahses and convert all slashes and backslashes to DS
			$path = preg_replace('#[/\\\\]+#', $ds, $path);
		}

		return $path;
	}
}
