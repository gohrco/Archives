<?php
/**
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2010 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id$
 * @since		2.0.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');	

function com_uninstall() {
	return true;
}

?>