<?php


/*-- Security Protocols --*/
if (!defined("WHMCS")) die("This file cannot be accessed directly");
/*-- Security Protocols --*/

// Path to WHMCS ROOT
if (! defined( "WHMCS_ROOT" ) ) {
	define( "WHMCS_ROOT", dirname(dirname(dirname(dirname(__FILE__) ) ) ) . DIRECTORY_SEPARATOR );
}
