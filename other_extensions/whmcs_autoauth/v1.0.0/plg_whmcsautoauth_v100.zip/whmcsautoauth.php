<?php
/**
 * WHMCS AutoAuth for Joomla!
 * 
 * @package    WHMCS AutoAuth for Joomla!
 * @copyright  2010 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @version    1.0.0 ( $Id: whmcsautoauth.php 3 2010-12-17 19:51:48Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.00
 * 
 * @desc		Once a user is authenticate, this user redirects to an install
 * 				of WHMCS using the AutoAuth feature found in v4.41 and above of
 * 				WHMCS.
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

/* ------------------------------------------------------------ *\
 * Class:		plgUserWhmcsautoauth
 * Extends:		JPlugin
 * Purpose:		Handles user event for WHMCS AutoAuth
 * As of:		version 1.00
\* ------------------------------------------------------------ */
class plgUserWhmcsautoauth extends JPlugin
{
	/* ------------------------------------------------------------ *\
	 * Function:	plgUserWhmcsautoauth
	 * Purpose:		This is the constructor task
	 * As of:		version 1.00 (December 2010)
	\* ------------------------------------------------------------ */
	function plgUserWhmcsautoauth(& $subject, $config)
	{
		$params = new JParameter( $config['params'] );
		
		$this->version	= $params->get( "version" );
		$this->authkey	= trim( $params->get( "authkey" ) );
		$this->gotourl	= $params->get( "gotourl" );
		$this->whmcsurl	= $params->get( "whmcsurl" );
		$this->canlogout = $params->get( "logoutenable" );
		
		parent::__construct($subject, $config);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	onLoginUser
	 * Purpose:		Task run after user authenticated in Joomla!
	 * As of:		version 1.00 (December 2010)
	\* ------------------------------------------------------------ */
	function onLoginUser($user, $options)
	{
		// 0:  Initialize variables
		global $mainframe;
		
		if ( $mainframe->isAdmin() )
			return; // Dont run in admin
		
		$email	= trim( $user['email'] );
		$time	= time();
		$hash	= sha1( $email . $time . $this->authkey );
		
		$gotourl	= trim( $this->gotourl );
		
		if (! empty( $gotourl ) )
			$goto = $gotourl;
		else
			$goto = false;
			
		$uri = & JURI::getInstance( $this->whmcsurl );
		$uri->setPath( rtrim( $uri->getPath(), "/" ) . '/dologin.php' );
		$uri->setVar( 'email',	$email );
		$uri->setVar( 'timestamp', $time );
		$uri->setVar( 'hash',	$hash );
		
		if ( $goto !== false ) $uri->setVar( 'goto', $goto );
		
		$url = $uri->toString();
		$mainframe->redirect( $url );
	}

	
	/* ------------------------------------------------------------ *\
	 * Function:	onLogoutUser
	 * Purpose:		Task run after user logs out
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 * 		* Modified parameters to reflect database change
	\* ------------------------------------------------------------ */
	function onLogoutUser($user)
	{
		global $mainframe;
		
		if ($mainframe->isAdmin())
			return; // Dont run in admin
		
		if (! $this->canlogout )
			return; // Don't wanna run logout routine
		
		$uri = & JURI::getInstance( $this->whmcsurl );
		$uri->setPath( rtrim( $uri->getPath(), "/" ) . "/logout.php");
		
		$url = $uri->toString();
		$mainframe->redirect( $url );
	}
}