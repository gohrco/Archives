<?php
/**
 * Kayako root file for J!WHMCS Integrator
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: jwint.php 131 2010-12-22 14:21:11Z steven_gohigher $
 * @since      2.10
 */

if ( is_readable( getcwd() . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'config.php' ) )
	require_once( getcwd() . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'config.php' );

/* ------------------------------------------------------------ *\
 * Class:		JWInt
 * As of:		version 2.10 (August 2010)
\* ------------------------------------------------------------ */
class JWInt
{
	private $url;
	private $user;
	
	/* ------------------------------------------------------------ *\
	 * Function:	__construct
	 * Purpose:		Create the object
	 * As of:		version 2.10 (August 2010)
	 * 
	 *	$fetch	=> declared when called by the template
	 *				template currently gets body, css and redirect
	\* ------------------------------------------------------------ */
	function __construct( $fetch = 'body' )
	{
		global $template, $settings;
		
		if (! isset( $settings->data['loginshare']['whmcsurl'] ) ) return;
		
		$this->url	= parse_url( $template->_vars['_swiftpath'] );
		$this->user	= $template->_vars['_USER'];
		
		$this->groupname	= $template->_vars['tgroupname'];
		$this->whmcsurl	= $settings->data['loginshare']['whmcsurl'];
		$this->langarray	= $this->buildLangarray( $settings->data['loginshare']['whmcslang'] );
		$this->visualang	= $this->buildLangarray( $settings->data['loginshare']['whmcslang'], true );
		$this->themepath		= $template->_vars['_SWIFT']['themepath'];
		$this->swiftpath		= $template->_vars['_SWIFT']['swiftpath'];
		$this->sessionid		= $template->_vars['session']['sessionid'];
		
		switch ($fetch):
		/**
		 * Called by the header template for wrapping purposes
		 */
		case 'body':
			
			$this->send['joomadmin'] = $settings->data['loginshare']['jwhmcssecret'];
			$this->send['jwhmcs']	= true;
			$this->send['loggedin'] = $this->isLoggedin();
			$this->send['usessl']	= $this->isSecure();
			$this->send['filename']	= 'kayako';
			$this->send['email']	= $this->getEmail();
			$this->send['kayako']	= true;
			$this->send['systemurl']	= $template->_vars['_swiftpath'];
			$this->send['lang']		= $this->getLanguage();
			
			$this->vals = $this->goCurl();
			
			/* Script Header */
			$htmlscript	= $this->getInclude();
			$template->assign( 'htmlscript', $htmlscript );
			
			/* Header */
			$htmlheader	= base64_decode( $this->vals['htmlheader'] );
			$htmlheader	= str_replace( '</head>', $htmlscript . "</head>", $htmlheader );
			$htmlheader	= preg_replace( '`<base[^>]*>`', '', $htmlheader );
			$htmlheader	= $this->fixLanguage( $htmlheader );
			$template->assign( 'htmlheader', $htmlheader );
			
			/* Footer */
			$htmlfooter	= base64_decode( $this->vals['htmlfooter'] );
			$htmlfooter	= $this->fixLanguage( $htmlfooter );
			$template->assign( 'htmlfooter', $htmlfooter );
			
			/* Widgets */
			$this->cleanWidgets();
			break;
		
		/**
		 * Called by the CSS template
		 */
		case 'css':
			
			$ssl	= $this->isSecure() ? 's' : '';
		
			$turl	= parse_url( $this->themepath );
			$turl['scheme'] = $this->url['scheme'];
			$themeurl	= $this->toString( $turl );
			$swifturl	= $this->toString( $this->url );
			
			$template->assign( 'themepath', $themeurl );
			break;
			
		/**
		 * Called by the redirect template for logging in purposes
		 */
		case 'redirect':
			
			$template->assign( 'whmcsurl', rtrim( $this->whmcsurl, '/' ) );
			break;
		endswitch;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	cleanWidgets
	 * Purpose:		Cycle through the widgets and set the img urls
	 * As of:		version 2.10 (August 2010)
	\* ------------------------------------------------------------ */
	function cleanWidgets()
	{
		global $template;
		
		if (! is_array( $template->_vars['widgets'] ) ) return;
		
		for ($i=0; $i<count($template->_vars['widgets']); $i++)
		{
			$tmpurl = parse_url( $template->_vars['widgets'][$i]['icon'] );
			$tmpurl['scheme'] = $this->url['scheme'];
			$template->_vars['widgets'][$i]['icon'] = $this->toString( $tmpurl );
		}
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	getEmail
	 * Purpose:		If the user is logged in, get their email address
	 * As of:		version 2.10 (August 2010)
	\* ------------------------------------------------------------ */
	function getEmail()
	{
		return ( $this->isLoggedin() ? $this->user['primaryemail'] : false );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	getLanguage
	 * Purpose:		Return the current language the user is utilizing
	 * As of:		version 2.10 (August 2010)
	\* ------------------------------------------------------------ */
	function getLanguage()
	{
		global $template;
		return $this->visualang[$template->_vars['languagecode']];
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	fixLanguage
	 * Purpose:		After the site is retrieved, run replacements
	 * As of:		version 2.10 (August 2010)
	\* ------------------------------------------------------------ */
	function fixLanguage( $data )
	{
		$regex[0] = '/(href=\")([^\"]*<!-- LANGUAGE=)(.{2}).*?(\")/i';
		$regex[1] = '/<!-- LANGUAGE=(.{2}) -->/i';
		$regex[2] = '/<!-- JWHMCS RETURN URL -->/i';
		
		preg_match_all( $regex[0], $data, $matches, PREG_SET_ORDER);
		
		if( count( $matches ) > 0 ) {
			foreach($matches as $match)
			{
				$data = preg_replace( '`'.$match[0].'`', $match[1]."index.php?languageid={$this->langarray[$match[3]]}".$match[4], $data );
			}
		}
		
		preg_match_all( $regex[1], $data, $matches, PREG_SET_ORDER);
		
		if( count( $matches ) > 0 ) {
			foreach( $matches as $match )
			{
				$data = preg_replace( '`'.$match[0].'`', "index.php?languageid={$this->langarray[$match[1]]}", $data );
			}
		}
		
		$data = preg_replace( $regex[2], base64_encode( $this->currenturl ), $data );
		
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	isLoggedin
	 * Purpose:		Test to see if the user is logged in
	 * As of:		version 2.10 (August 2010)
	\* ------------------------------------------------------------ */
	function isLoggedin()
	{
		return ( $this->user['loggedin'] ? true : false );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	isSecure
	 * Purpose:		Test if the current page is using SSL
	 * As of:		version 2.10 (August 2010)
	\* ------------------------------------------------------------ */
	function isSecure()
	{
		if (! isset( $this->url['scheme'] ) )
			return false;
		
		return ( $this->url['scheme'] == 'https' ? true : false );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	goCurl
	 * Purpose:		Make the call to the JWHMCS root file
	 * As of:		version 2.10 (August 2010)
	\* ------------------------------------------------------------ */
	function goCurl()
	{
		$send		= $this->send;
		$url		= $this->buildCurl();
		$curlfollow	= ((ini_get('open_basedir') == '' && ini_get('safe_mode' == 'Off')) ? true : false );
		
		$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_TIMEOUT, 100);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_NOPROGRESS, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, $curlfollow );
			curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false );
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false );
			ob_start();
				$data = curl_exec($ch);
				$info = curl_getinfo($ch);
			ob_end_clean();
		curl_close($ch);
		
		$xml = xml_parser_create();
		xml_parse_into_struct($xml, $data, $vals, $index);
		xml_parser_free($xml);
		 
		foreach ($vals as $p):
			if ($p['type']=='complete')
			{
				// Error trapping for error_reporting(-1)
				if(isset($p['value']))
					$items[strtolower($p['tag'])] = $p['value'];
			}
		endforeach;
		$items['info'] = $info;
		return $items;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	buildCurl
	 * Purpose:		Standardize the url for WHMCS (variable is set by user)
	 * As of:		version 2.10 (August 2010)
	\* ------------------------------------------------------------ */
	function buildCurl()
	{
		return trim($this->whmcsurl,'/').'/jwhmcs.php?task=parse';
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	queryToString
	 * Purpose:		Build a url string from an array of uri variables
	 * As of:		version 2.10 (August 2010)
	\* ------------------------------------------------------------ */
	function toString($uri)
	{
		$tmp = '';
		$tmp .= isset($uri['scheme'])  ? (!empty($uri['scheme']) ? $uri['scheme'].'://' : '') : '';
		$tmp .= isset($uri['user'])	? $uri['user'] : '';
		$tmp .= isset($uri['pass'])	? (!empty ($uri['pass']) ? ':' : '') .$uri['pass']. (!empty ($uri['user']) ? '@' : '') : '';
		$tmp .= isset($uri['host'])	? $uri['host'] : '';
		$tmp .= isset($uri['port'])	? (!empty ($uri['port']) ? ':' : '').$uri['port'] : '';
		$tmp .= isset($uri['path'])	? $uri['path'] : '';
		$tmp .= isset($uri['query'])	? (!empty ($uri['query']) ? '?'.$uri['query'] : '') : '';
		$tmp .= isset($uri['fragment'])? (!empty ($uri['fragment']) ? '#'.$uri['fragment'] : '') : '';
		return $tmp;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	buildQuery
	 * Purpose:		Build a query string from an array of parameters
	 * As of:		version 2.10 (August 2010)
	\* ------------------------------------------------------------ */
	function buildQuery ($params = null)
	{
		if (is_null($params)) return false;
		$out = array();
		foreach ( $params as $k => $v ) $out[] = $k."=".urlencode($v);
		return implode("&",$out);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	buildLangarray
	 * Purpose:		This creates language arrays.  Visual arrays
	 * 				are arrays of Kayako iso-codes matched to Joomla
	 * 				Joomfish shortcodes.  Non-visual arrays are arrays that
	 * 				contain Joomfish short codes to the Kayako ID # for
	 * 				the appropriate language. 
	 * As of:		version 2.10 (August 2010)
	 * 
	 * 	$lang	=> (string) variable from loginshare (en-us:en|fr:fr...)
	 *	$visual	=> (bool)	are we creating a visual or non-visual array
	\* ------------------------------------------------------------ */
	function buildLangarray( $lang = null, $visual = false )
	{
		global $template;
		
		static $code;									// Static variable
		$list = $template->_vars['languagelist'];		// Grab internal language list from template
		
		if (! is_array( $list ) ) return array();		// Error trapping in case no template array
		if ( is_null( $lang ) ) return array();			// If we didn't send anything then send back
		
		if (! is_array( $code ) )						// If we haven't created the code array yet then do so now
		{
			$code	= array();
			foreach ( $list as $l )
			{
				$code[$l['languagecode']] = $l['languageid'];
			}
		}
		
		$tmp = explode("|", $lang );					// Take the language set in login share and start working it over
		foreach ( $tmp as $t )							// Explode guarantees at least one time through
		{
			$pair = explode( ":", $t );					// Explode corresponding pairs
			if ( isset( $code[$pair[0]] ) )				// If we have the matching language code
			{
				if ( $visual )							// If we are creating a visual array then it will look like this:
				{										//		'en-us' => 'en'
					$data[$pair[0]] = $pair[1];			//		'fr'	=> 'fr'
				}
				else									// If we are creating a non-visual array:
				{										//		'en'	=> 1
					$data[$pair[1]] = $code[$pair[0]];	//		'fr'	=> 2
				}
			}
			unset( $pair );
		}
		
		return $data;									// Send back
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	getInclude
	 * Purpose:		Create Kayako's css and js declarations for the <head>
	 * As of:		version 2.10 (August 2010)
	\* ------------------------------------------------------------ */
	function getInclude()
	{
		global $template;
		
		$ssl	= $this->isSecure() ? 's' : '';
		
		$turl	= parse_url( $this->themepath );
		$turl['scheme'] = $this->url['scheme'];
		$themeurl	= $this->toString( $turl );
		$swifturl	= $this->toString( $this->url );
		
		$burl	= parse_url( $template->_vars['basepath'] );
		if ( isset( $burl['scheme'] ) ) $burl['scheme'] = $this->url['scheme'];
		
		$template->assign( 'themepath', $themeurl );
		$template->assign( 'basepath', $this->toString( $burl ) );
		$this->currenturl = $template->_vars['basepath'];
		
		$swifturl = rtrim( $swifturl, '/' );
		$return = <<< JSINCLUDE
<link rel="stylesheet" type="text/css" media="all" href="{$swifturl}/index.php?_ca=css&group={$this->groupname}" />
<script language="Javascript">
var themepath = "{$themeurl}";
var swiftpath = "{$swifturl}";
var BLANK_IMAGE="{$themeurl}space.gif";
var swiftsessionid = "{$this->sessionid}";
</script>
<script language="Javascript" src="{$themeurl}basejs.js" type="text/javascript"></script>
JSINCLUDE;
	return $return;
	}
}