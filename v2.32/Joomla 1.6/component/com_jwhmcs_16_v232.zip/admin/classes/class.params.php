<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: class.params.php 174 2011-02-05 03:26:47Z steven_gohigher $
 * @since      1.5.3
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once ('class.database.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsParams
 * Purpose:		Object to handle parameters for JWHMCS
 * As of:		version 1.5.3
 * 
 * Significant Revisions:
 *  2.1.0 (Apr 2010)
 *  	- Dropped methods _cleanUrls, _loadDefaults
\* ------------------------------------------------------------ */
class JwhmcsParams
{
	private static $instance = null;
	private $types = array(	0  => 'global',
							1  => 'user',
							2  => 'style',
							3  => 'menu',
							4  => 'whmcs',
							5  => 'install',
							6  => 'advanced',
							7  => 'recaptcha',
							8  => 'registration',
							9  => 'kayako',
							10 => 'language'
	);
	
	private $map = array();
	
    /* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Called upon initialization of object class
	 * As of:		version 1.5.3
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 *  	- No longer needed to get then build params (dropped buildParams)
	 *  	- Dropped call to clean urls each time
	\* ------------------------------------------------------------ */
	private function __construct()
	{
		// Check to see which environment we are in (JFactory = Joomla)
		$this->jdb	= class_exists('JFactory');
		$this->_buildMap();
		$this->_buildUrlarray();
		
		// Initialize Parameter array
		$params = $this->_initParameters();
		
		foreach ($params as $param) {
			$this->params[$this->types[$param[0]]][$param[1]] = $param[2];
			$this->init[$param[1]] = $param;
		}
		
		// Retrieve the parameters
		$this->_getParams();
		
		if (count($this->params) == 0) {
			$this->initParams();
		}
	}
	
	 
	/* ------------------------------------------------------------ *\
	 * Method:		getInstance
	 * Purpose:		Called to create an instance of the class
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public static function getInstance()
	{
		if (self::$instance == null)
		{
			self::$instance = new self;
		}
		return self::$instance;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		get
	 * Purpose:		Called to retrieve a specific parameter
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	public function get($key)
	{
		if (!$this->_multiArrayKeyExists($key, $this->params))
		{
			// Error trapping for non-existant parameter
			return false;
		}
		
		$prime = $this->_arrayFindPrimeKey($key, $this->params);
		
		if ($prime) {
			return $this->params[$prime][$key];
		} else {
			return false;
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getPrime
	 * Purpose:		Called to retrieve an entire set of parameters
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	public function getPrime($prime)
	{
		if (! $this->params[$prime] ) {
			return false;
		} else {
			return $this->params[$prime];
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getMap
	 * Purpose:		Called to retrieve the map of parameters
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	public function getMap()
	{
		return $this->map;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		initParams
	 * Purpose:		Called to build initial parameters for database
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	public function initParams()
	{
		// Call appropriate database object
		if ($this->jdb) {
			$db = & JFactory::getDBO();
		} else {
			$db	= & JwhmcsDBO::getInstance();
		}
		
		$params = $this->_initParameters();
		
		foreach ($params as $param) {
			$this->params[$this->types[$param[0]]][$param[1]] = $param[2];
			$q[] = sprintf( "INSERT INTO `#__jwhmcs_config` (`type`, `key`, `value`, `field`, `order`) VALUES (%d, \"%s\", \"%s\", %d, %d) ON DUPLICATE KEY UPDATE `value`=\"%s\"", $param[0], $param[1], $param[2], $param[3], $param[4], $param[2]);
		}
		
		foreach ( $q as $query ) {
			$db->setQuery($query);
			$db->query();
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		set
	 * Purpose:		Called to set a specific parameter
	 * As of:		version 1.5.3
	 * 
	 * Significant Revisions:
	 * 	2.1.0 (Apr 2010)
	 * 		* Changed prime default from 'component' to 'local'
	\* ------------------------------------------------------------ */
	public function set($key, $value, $save = false, $prime = 'local')
	{
		if ($this->_multiArrayKeyExists($key, $this->params))
			$prime = $this->_arrayFindPrimeKey($key, $this->params);
		
		$this->params[$prime][$key] = $value;
		
		if ($save)
		{
			$this->_saveParams($prime);
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		add
	 * Purpose:		Called to add a new parameter to the database
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	public function add($key, $value, $prime = 'local', $type = '-1', $order = '10' )
	{
		// Call appropriate database object
		if ($this->jdb) {
			$db = & JFactory::getDBO();
		} else {
			$db	= & JwhmcsDBO::getInstance();
		}
		
		// We don't save any parameters set locally (temporary storage)
		if ( $prime == 'local' ) return;
		
		$types = array_flip($this->types);
		$p = $types[$prime];
		
		$query = sprintf( "INSERT INTO `#__jwhmcs_config` (`type`, `key`, `value`, `field`, `order`) VALUES (%d, \"%s\", \"%s\", %d, %d) ON DUPLICATE KEY UPDATE `value`=\"%s\"", $p, $key, $value, $type, $order, $value);
		$db->setQuery($query);
		$db->query();
		
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		saveAll
	 * Purpose:		Save all set parameters
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	public function saveAll()
	{
		$this->_saveParams();
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		rebuildParams
	 * Purpose:		Pulls parameters and sets correct settings
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	public function rebuildParams()
	{
		$q = array();
		
		// Call appropriate database object
		if ( $this->jdb )
		{
			$db = & JFactory::getDBO();
		}
		else
		{
			$db = & JwhmcsDBO::getInstance();
		}
		
		// Retrieve current parameters from database
		$query	= "
					SELECT c.type, c.key, c.value, c.field, c.order
					FROM #__jwhmcs_config c";
		$db->setQuery( $query );
		$dps	= $db->loadObjectList();
		
		$updq	= "UPDATE `#__jwhmcs_config` SET `type` = %d, `field` = %d, `order` = %d WHERE `key` = \"%s\"";
		foreach ( $dps as $dp )
		{
			// Check to see if the current key is set in the init array
			if ( ! isset( $this->init[$dp->key] ) ) continue;
			
			$def = $this->init[$dp->key];
			
			// Create query for resetting values in database
			$q[]	= sprintf( $updq, $def[0], $def[3], $def[4], $dp->key);
		}
		
		// Cycle through each query and set
		foreach ( $q as $query )
		{
			$db->setQuery( $query );
			$db->query();
		}
		
		// Retrieve current parameters
		$this->_getParams();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getParams (private)
	 * Purpose:		Retrieve the parameters from the database
	 * As of:		version 1.5.3 (November 2010)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 *  	* Modified parameter storage to its own database table
	\* ------------------------------------------------------------ */
	private function _getParams()
	{
		// Call appropriate database object
		if ($this->jdb) {
			$db = & JFactory::getDBO();
		} else {
			$db	= & JwhmcsDBO::getInstance();
		}
		
		$query = "SELECT `type`, `key`, `value`, `field` FROM #__jwhmcs_config ORDER BY `order`";
		$db->setQuery($query);
		$result = $db->loadAssocList();
		
		$params = array();
		
		// Test to ensure there are parameters to go through
		if (! is_array($result)) return;
		
		foreach($result as $param)
		{
			$param['value'] = str_replace("\\\\", "\\", $param['value']);
			$this->params[$this->types[$param['type']]][$param['key']] = $param['value'];
		}
		
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_saveParams (private)
	 * Purpose:		Save parameters back to database
	 * As of:		version 1.5.3 (November 2010)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 *  	* Modified parameter storage to its own database table
	\* ------------------------------------------------------------ */
	private function _saveParams($prime = null)
	{
		// Call appropriate database object
		if ($this->jdb) {
			$db = & JFactory::getDBO();
		} else {
			$db	= & JwhmcsDBO::getInstance();
		}
		
		// Check if no prime set (save all params) and cycle through each parameter set
		if (! $prime ) {
			foreach ($this->params as $prime => $value) {
				$this->_saveParams($prime);
			}
			return;
		}
		
		// We don't save any parameters set locally (temporary storage)
		if ( $prime == 'local' ) return;
		
		// Error trapping for missing parameters
		if ( count ($this->params[$prime]) == 0 ) return;
		
		// Shortcut param reference
		$p = & $this->params[$prime];
		
		foreach ( $p as $key => $value ) {
			$i		= & $this->init[$key];
			$value	= str_replace("\\", "\\\\", $value);
			$q[]	= sprintf( "INSERT INTO `#__jwhmcs_config` (`type`, `key`, `value`, `field`, `order`) VALUES (%d, \"%s\", \"%s\", %d, %d) ON DUPLICATE KEY UPDATE `value`=\"%s\"", $i[0], $key, $value, $i[3], $i[4], $value);
		}
		
		foreach ( $q as $query ) {
			$db->setQuery($query);
			$db->query();
		}
		
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_multiArrayKeyExists
	 * Purpose:		Recursively check for existance of a value in an array
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	private function _multiArrayKeyExists( $needle, $haystack )
	{
		if (!$haystack) return false; 
		foreach ( $haystack as $key => $value )
		{
			if ( $needle == $key )
				return true;
			
			if ( is_array( $value ) ) {
				if ( $this->_multiArrayKeyExists( $needle, $value ) == true )
				{
					return true;
				}
				else
				{
					continue;
				}
			}
		}
		
		return false;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_arrayFindPrimeKey
	 * Purpose:		Recursively get the prime location of a key
	 * As of:		version 1.5.3
	\* ------------------------------------------------------------ */
	private function _arrayFindPrimeKey($key, $form)
	{
		if (array_key_exists($key, $form))
		{
			return true;
		}
		
		$ret = false;
		foreach ($form as $k => $v)
		{
			if (is_array($form[$k])) {
				$ret = & $this->_arrayFindPrimeKey($key, $form[$k]);
			}
			if ($ret===true)	// Test if the key was found in the previous check
			{
				return $k;		// Return the primary key
			}
			if ($ret)
			{
				$ret[$k] = $ret;
				return $ret;
			}
		}
		return false;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_initParameters (private)
	 * Purpose:		Returns the default parameters for installation
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	private function _initParameters()
	{
		//							Group	Name					Default Value	Type	Order
		//  -------------------------------------------------------------------------------------------
		$init	= array(	array(	'0',	'Version',				'2.32',	'-1',	'10' ),
							array(	'0',	'InstallToken',			'',				'-1',	'10' ),
							array(	'0',	'Enable',				'1',			'3',	'10' ),
							array(	'0',	'LicenseKey',			'',				'1',	'20' ),
							array(	'0',	'Debug',				'1',			'3',	'30' ),
							array(	'0',	'JoomlaUrl',			'',				'1',	'40' ),
							array(	'0',	'ApiUrl',				'',				'1',	'50' ),
							array(	'0',	'ApiUsername',			'',				'1',	'60' ),
							array(	'0',	'ApiPassword',			'',				'4',	'70' ),
							array(	'0',	'ApiAccesskey',			'',				'4',	'80' ),
							array(	'0',	'Secret',				'JwhmcsInt',	'1',	'90' ),
							//array(	'0',	'ApiToken',			md5(time()),	'1',	'95' ),
							array(	'0',	'License',				'',				'-1',	'10' ),
					//  --------------------------------------------------------------------------------
							array(	'1',	'LastSync',				'',				'1',	'10' ),
							array(	'1',	'UserEnable',			'1',			'3',	'10' ),
							array(	'1',	'RedirLoginurl',		'',				'1',	'20' ),
							//array(	'1',	'RedirLoginssl',		'0',			'3',	'25'),
							array(	'1',	'RedirLogouturl',		'',				'1',	'30'),
							//array(	'1',	'RedirLogoutssl',		'0',			'3',	'35' ),
							array(	'1',	'RedirGatewayssl',		'0',			'3',	'45' ),
							array(	'1',	'RedirMessage',			'Logging In',	'1',	'47' ),
							array(	'1',	'JuserAutoadd',			'1',			'3',	'50' ),
							array(	'1',	'JuserAutosync',		'1',			'2',	'60' ),
							array(	'1',	'JuserEmailsync',		'0',			'2',	'62' ),
							array(	'1',	'JuserAuthorize',		'0',			'3',	'65' ),
							array(	'1',	'WuserAutoadd',			'1',			'3',	'70' ),
							array(	'1',	'WuserAutosync',		'1',			'2',	'80' ),
							array(	'1',	'JuserPendingallow',	'1',			'3',	'67' ),
							array(	'1',	'WuserAuthenticate',	'1',			'3',	'85' ),
							array(	'1',	'WchangeLockables',		'1',			'2',	'46' ),
					//  --------------------------------------------------------------------------------
							array(	'2',	'RenderEnable',			'1',			'3',	'10' ),
							array(	'2',	'RenderDebugconsole',	'0',			'2',	'15' ),
							array(	'2',	'RenderSslenable',		'1',			'3',	'20' ),
							array(	'2',	'RenderImageurl',		'',				'1',	'30' ),
							array(	'2',	'RenderJqueryenable',	'1',			'3',	'40' ),
							array(	'2',	'RenderCssreset',		'0',			'3',	'45' ),
							array(	'2',	'RenderLoggedin',		'',				'7',	'50' ),
							array(	'2',	'RenderLoggedout',		'',				'7',	'60' ),
							array(	'2',	'RenderOverridecache',	'0',			'2',	'70' ),
							array(	'2',	'RenderClearcache',		'0',			'2',	'80' ),
							array(	'2',	'RenderConvertcharset',	'1',			'2',	'90' ),
					//  --------------------------------------------------------------------------------
							array(	'3',	'MenuDefault',			'',				'7',	'7' ),
							array(	'3',	'MenuStyle',			'joomla',		'8',	'8' ),
							array(	'3',	'MenuKayako',			'',				'7',	'9' ),
							array(	'3',	'MenuAffiliate',		'',				'7',	'10' ),
							array(	'3',	'MenuAnnouncements',	'',				'7',	'10' ),
							array(	'3',	'MenuBanned',			'',				'7',	'10' ),
							array(	'3',	'MenuCart',				'',				'7',	'10' ),
							array(	'3',	'MenuClientarea',		'',				'7',	'10' ),
							array(	'3',	'MenuConfiguressl',		'',				'7',	'10' ),
							array(	'3',	'MenuContact',			'',				'7',	'10' ),
							array(	'3',	'MenuCreditcard',		'',				'7',	'10' ),
							array(	'3',	'MenuDomainchecker',	'',				'7',	'10' ),
							array(	'3',	'MenuDownloads',		'',				'7',	'10' ),
							array(	'3',	'MenuIndex',			'',				'7',	'10' ),
							array(	'3',	'MenuKnowledgebase',	'',				'7',	'10' ),
							array(	'3',	'MenuLogout',			'',				'7',	'10' ),
							array(	'3',	'MenuNetworkissues',	'',				'7',	'10' ),
							array(	'3',	'MenuOrder',			'',				'7',	'10' ),
							array(	'3',	'MenuPasswordreminder',	'',				'7',	'10' ),
							array(	'3',	'MenuPwreset',			'',				'7',	'10' ),
							array(	'3',	'MenuPwresetvalidtion',	'',				'7',	'10' ),
							array(	'3',	'MenuRegister',			'',				'7',	'10' ),
							array(	'3',	'MenuServerstatus',		'',				'7',	'10' ),
							array(	'3',	'MenuSubmitticket',		'',				'7',	'10' ),
							array(	'3',	'MenuSupporttickets',	'',				'7',	'10' ),
							array(	'3',	'MenuTutorials',		'',				'7',	'10' ),
							array(	'3',	'MenuUpgrade',			'',				'7',	'10' ),
							array(	'3',	'MenuViewinvoice',		'',				'7',	'10' ),
							array(	'3',	'MenuViewticket',		'',				'7',	'10' ),
							array(	'3',	'MenuAjaxorder',		'',				'7',	'10' ),
					//  --------------------------------------------------------------------------------
							array(	'4',	'WhmcsVersion',			'4.0.0',		'-2',	'10' ),
							array(	'4',	'WhmcsSystemurl',		'',				'-2',	'20' ),
							array(	'4',	'WhmcsSystemsslurl',	'',				'-2',	'30' ),
							array(	'4',	'WhmcsTemplate',		'',				'-2',	'40' ),
							array(	'4',	'WhmcsCharacterset',	'',				'-2',	'50' ),
							array(	'4',	'WhmcsDefaultcountry',	'',				'-2',	'60' ),
							array(	'4',	'WhmcsNomd5',			'',				'-2',	'70' ),
							array(	'4',	'WhmcsRequiredpwstrength',	'',			'-2',	'80' ),
					//  --------------------------------------------------------------------------------
							array(	'5',	'AdvUnicode',			'1',			'3',	'5' ),
							array(	'5',	'AdvConvertcharset',	'1',			'3',	'7' ),
							array(	'5',	'FtpUse',				'0',			'8',	'10' ),
							array(	'5',	'FtpHostname',			'',				'1',	'30' ),
							array(	'5',	'FtpPort',				'',				'1',	'40' ),
							array(	'5',	'FtpUsername',			'',				'1',	'50' ),
							array(	'5',	'FtpPassword',			'',				'4',	'60' ),
							array(	'5',	'FtpPath',				'',				'1',	'70' ),
							array(	'5',	'FilePath',				'',				'1',	'20' ),
							array(	'5',	'PreviousTemplate',		'',				'-1',	'60' ),
							array(	'5',	'PreviousRequiredpwstrength',	'',		'-1',	'70' ),
							array(	'5',	'PreviousVersion',		'',				'-1',	'80' ),
					//  --------------------------------------------------------------------------------
							array(	'7',	'RecaptchaEnable',		'0',			'3',	'10' ),
							array(	'7',	'RecaptchaPublickey',	'',				'1',	'20' ),
							array(	'7',	'RecaptchaPrivatekey',	'',				'1',	'30' ),
							array(	'7',	'RecaptchaTheme',		'red',			'8',	'40' ),
							array(	'7',	'RecaptchaThemecustom',	'',				'-1',	'50' ),
							array(	'7',	'RecaptchaLang',		'en',			'8',	'60' ),
					//  --------------------------------------------------------------------------------
							array(	'8',	'RegMethod',			'1',			'8',	'10' ),
							array(	'8',	'RegPasswordreset',		'1',			'8',	'13' ),
							array(	'8',	'RegMenu',				'',				'7',	'15' ),
							array(	'8',	'RegAjax',				'0',			'3',	'20' ),
							array(	'8',	'JuserStore',			'1',			'8',	'67' ),
							array(	'8',	'JusernameStore',		'1',			'8',	'68' ),
							array(	'8',	'WuserDefaultaddress',	'New Address',	'1',	'85' ),
							array(	'8',	'WuserDefaultcity',		'New City',		'1',	'90' ),
							array(	'8',	'WuserDefaultcountry',	'GB',			'1',	'95' ),
							array(	'8',	'WuserDefaultphone',	'000-0123-4544',	'1',	'100' ),
							array(	'8',	'WuserDefaultpostal',	'124565',		'1',	'105' ),
							array(	'8',	'WuserDefaultstate',	'FL',			'1',	'110' ),
					//  --------------------------------------------------------------------------------
							array(	'9',	'KayakoEnable',			'0',			'3',	'10' ),
							array(	'9',	'KayakoUrl',			'',				'1',	'20' ),
							array(	'9',	'KayakoUsessl',			'0',			'2',	'30' ),
							array(	'9',	'KayakomenuLoggedin',	'',				'7',	'40' ),
							array(	'9',	'KayakomenuLoggedout',	'',				'7',	'50' ),
					//  --------------------------------------------------------------------------------
							array(	'10',	'LangEnable',			'1',			'3',	'10' ),
							array(	'10',	'LangDefault',			'English',		'8',	'20' )
		);
		return $init;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_buildMap (private)
	 * Purpose:		Builds a map of old parameters and new parameters
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	private function _buildMap()
	{
		$this->map = array(	'licensekey'			=> array( 'LicenseKey',				'global',		'' ), 
							'whmcsvers'				=> array( 'WhmcsVersion',			'whmcs',		'' ), 
							'jwhmcsvers'			=> array( 'Version',				'global',		'2.1.0' ),  
							'whmcs_charset'			=> array( 'WhmcsCharacterset', 		'whmcs',		'' ), 
							'jwhmcsdebug'			=> array( 'Debug',					'global',		'1' ), 
							'jwhmcsjurl'			=> array( 'JoomlaUrl',				'global',		'' ), 
							'jwhmcsjrootimgurl'		=> array( 'RenderImageurl',			'style',		'' ), 
							'jwhmcsjssl'			=> array( 'RenderSslenable',		'style',		'1' ), 
							'jwhmcsjin'				=> array( 'RedirLoginurl',			'user',			'' ), 
							'jwhmcsjout'			=> array( 'RedirLogouturl',			'user',			'' ), 
							'jwhmcsjstoreus'		=> array( 'JuserStore',				'user',			'1' ), 
							'jwhmcsjauth'			=> array( 'JuserAuthorize',			'user',			'0' ), 
							'jwhmcssecret'			=> array( 'Secret',					'global',		'JwhmcsInt' ), 
							'jwhmcsurl'				=> array( 'ApiUrl',					'global',		'' ), 
							'jwhmcsssl'				=> array( 'RedirGatewayssl',		'user',			'0' ), 
							'jwhmcsadminus'			=> array( 'ApiUsername',			'global',		'' ), 
							'jwhmcsadminpw'			=> array( 'ApiPassword',			'global',		'' ), 
							'jwhmcsjquery'			=> array( 'RenderJqueryenable',		'style',		'1' ), 
							'accesskey'				=> array( 'ApiAccesskey',			'global',		'' ), 
							'jwloggedinurl'			=> array( 'RenderLoggedin',			'style',		'' ), 
							'jwloggedouturl'		=> array( 'RenderLoggedout',		'style',		'' ), 
							'overridecache'			=> array( 'RenderOverridecache',	'style',		'0' ), 
							'clearcache'			=> array( 'RenderClearcache',		'style',		'0' ), 
							'jwlnkdefault'			=> array( 'MenuDefault',			'menu',			'1' ), 
							'jwhmcsmenustyle'		=> array( 'MenuStyle',				'menu',			'joomla' ), 
							'jwlnkaffiliates'		=> array( 'MenuAffiliate',			'menu',			'-1' ), 
							'jwlnkannouncements'	=> array( 'MenuAnnouncements',		'menu',			'-1' ), 
							'jwlnkbanned'			=> array( 'MenuBanned',				'menu',			'-1' ), 
							'jwlnkcart'				=> array( 'MenuCart',				'menu',			'-1' ), 
							'jwlnkclientarea'		=> array( 'MenuClientarea',			'menu',			'-1' ), 
							'jwlnkconfiguressl'		=> array( 'MenuConfiguressl',		'menu',			'-1' ), 
							'jwlnkcontact'			=> array( 'MenuContact',			'menu',			'-1' ), 
							'jwlnkcreditcard'		=> array( 'MenuCreditcard',			'menu',			'-1' ), 
							'jwlnkdomainchecker'	=> array( 'MenuDomainchecker',		'menu',			'-1' ), 
							'jwlnkdownloads'		=> array( 'MenuDownloads',			'menu',			'-1' ), 
							'jwlnkindex'			=> array( 'MenuIndex',				'menu',			'-1' ), 
							'jwlnkknowledgebase'	=> array( 'MenuKnowledgebase',		'menu',			'-1' ), 
							'jwlnklogout'			=> array( 'MenuLogout',				'menu',			'-1' ), 
							'jwlnknetworkissues'	=> array( 'MenuNetworkissues',		'menu',			'-1' ), 
							'jwlnkorder'			=> array( 'MenuOrder',				'menu',			'-1' ), 
							'jwlnkpasswordreminder'	=> array( 'MenuPasswordreminder',	'menu',			'-1' ), 
							'jwlnkpwreset'			=> array( 'MenuPwreset',			'menu',			'-1' ), 
							'jwlnkpwresetvalidation'=> array( 'MenuPwresetvalidtion',	'menu',			'-1' ), 
							'jwlnkregister'			=> array( 'MenuRegister',			'menu',			'-1' ), 
							'jwlnkserverstatus'		=> array( 'MenuServerstatus',		'menu',			'-1' ), 
							'jwlnksubmitticket'		=> array( 'MenuSubmitticket',		'menu',			'-1' ), 
							'jwlnksupporttickets'	=> array( 'MenuSupporttickets',		'menu',			'-1' ), 
							'jwlnktutorials'		=> array( 'MenuTutorials',			'menu',			'-1' ), 
							'jwlnkupgrade'			=> array( 'MenuUpgrade',			'menu',			'-1' ), 
							'jwlnkviewinvoice'		=> array( 'MenuViewinvoice',		'menu',			'-1' ), 
							'jwlnkviewticket'		=> array( 'MenuViewticket',			'menu',			'-1'),
							'autoaddjoomla'			=> array( 'JuserAutoadd',			'user',			''),
							'autoupdatejoomlapw'	=> array( 'JuserAutosync',			'user',			''),
							'autoaddwhmcs'			=> array( 'WuserAutoadd',			'user',			''),
							'autoupdatewhmcspw'		=> array( 'WuserAutosync',			'user',			''),
							'whmcsaddress'			=> array( 'WuserDefaultaddress',	'registration',	''),
							'whmcscity'				=> array( 'WuserDefaultcity',		'registration',	''),
							'whmcscntry'			=> array( 'WuserDefaultcountry',	'registration',	''),
							'whmcsphone'			=> array( 'WuserDefaultphone',		'registration',	''),
							'whmcspostal'			=> array( 'WuserDefaultpostal',		'registration',	''),
							'whmcsstate'			=> array( 'WuserDefaultstate',		'registration',	''),
							'jwhmcsredirwhmcs'		=> array( 'RegMethod',				'registration',	''),
							'menuid'				=> array( 'RegMenu',				'registration',	''),
							'jwhmcs_authenable'		=> array ( 'UserEnable',			'user',			'1'),
							'jwhmcs_sysmlangenable'	=> array( 'LangEnable',				'language',		'1' ),
							'jwhmcsrecaptcha'		=> array( 'RecaptchaEnable',		'recaptcha',	'0'),
							'jwhmcsrcpubkey'		=> array( 'RecaptchaPublickey',		'recaptcha',	''),
							'jwhmcsrcprikey'		=> array( 'RecaptchaPrivatekey',	'recaptcha',	''),
							'jwhmcsrctheme'			=> array( 'RecaptchaTheme',			'recaptcha',	'red'),
							'jwhmcsrclang'			=> array( 'RecaptchaLang',			'recaptcha',	'en')
		);
		
		$this->mapssl	= array(	'jwhmcsjinssl' => 'RedirLoginurl', 'jwhmcsjoutssl' => 'RedirLogouturl' );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_buildUrlarray (private)
	 * Purpose:		Builds a map of url parameters to filter against
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	private function _buildUrlarray()
	{
		$this->urlarray	= array (	'JoomlaUrl',
									'RenderImageurl',
									'RedirLoginurl',
									'RedirLogouturl',
									'ApiUrl',
									'KayakoUrl'
		);
	}
}