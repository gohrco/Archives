<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: default.php 180 2011-02-09 15:13:46Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsControllerDefault
 * Extends:		JController
 * Purpose:		Used to set tasks for default controller
 * As of:		version 1.5.0
\* ------------------------------------------------------------ */
class JwhmcsControllerDefault extends JwhmcsController
{
	/* ------------------------------------------------------------ *\
	 * Task:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	function __construct()
	{
		// If the view hasn't been set, set it to default
		if (is_null(JRequest::getVar( 'view'))) JRequest::setVar('view', 'default' );
		
		parent::__construct();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		cron
	 * Purpose:		Task for calling automated updates to database
	 * As of:		version 1.5.0
	 * 
	 * Significant Revisions
	 *  2.1.0 (Apr 2010)
	 *  	* Modified parameters to reflect database change
	\* ------------------------------------------------------------ */
	function cron()
	{
		// 0:  Initialize variables
		$params	= & JwhmcsParams::getInstance();
		$this->addModelPath( JPATH_COMPONENT_ADMINISTRATOR.DS.'models' );
		
		$db		= & JFactory::getDBO();
		$uri	= & JURI::getInstance();
		$model	= & $this->getModel( 'sync' );
		
		// 1:  Check for secret value from querystring
		if (!($secret = JRequest::getVar( 'secret' )))
			return false;
		
		// 2:  Compare against parameter secret value (false == fail)
		if ($secret != $params->get( 'Secret'))
			return false;
		
		// 3:  Pull action from querystring to run
		if (!($action = JRequest::getVar( 'action' )))
			return false;
		
		// 4:  Run action
		if (! method_exists($model, $action))
			exit('No method');
		
		if (! ($cid = JRequest::getVar( 'cid', array(0), 'post', 'array' )))
			$cid = array();
		
		$model->$action($cid);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		whmcs_login
	 * Purpose:		Login a user from WHMCS
	 * As of:		1.5.3
	\* ------------------------------------------------------------ */
	function whmcs_login()
	{
		$app	= & JFactory::getApplication();
		$db		= & JFactory::getDBO();
		$uri	= & JURI::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		// 1: Retrieve variables based on token
		$vars	= $this->_getSess(JRequest::getVar( 'token' ));
		
		foreach ($vars as $k => $v) {
			$var[$k] = $v;
			if (in_array($k, array('username', 'passwd', 'password'))) continue;
			JRequest::setVar( $k, $v );
		}
		
		// Test to see if we are using User Integration, if not bypass login and return
		if ($params->get( 'UserEnable' ) ) {
			
			// 2: Set the return redirect (jwhmcs.php)
			$fromWhmcs			= ( JRequest::getVar('whmcs')=="1" ? true : false );
			$options			= array('remember' => true, 'return' => $var['return'], 'silent' => true, 'whmcs' => $fromWhmcs);
			$credentials		= array('username' => $var['username'], 'password' => $var['passwd']);
			
			//preform the login action
			$error = $app->login($credentials, $options);
		}
		
		$error = JError::getError( false );
		// If we are here then login failed, so determine where to return to
		if ($origin = JRequest::getVar( 'origin' ) ) {
			$org	= & JURI::getInstance(base64_decode($origin));
			$org->setVar('incorrect', 'true');
			$org->setVar( 'msg', $error->message );
			$return = $org->toString();
		}
		elseif ( ! $return = JRequest::getVar( 'return' ) ) {
			$return = 'index.php?option=com_user';
		}
		else {
			// Return exists and is base64 encoded
			$return = trim(base64_decode($return), '?');
			
			$ret = & JURI::getInstance($return);
			if ( $fromWhmcs )
			{
				$req		= explode( "/", $ret->getPath() );
				$use		= (int) ( count($req) - 1 );
				$req[$use]	= "clientarea.php";
				
				$ret->setPath( implode( "/", $req) );
				$ret->setVar('incorrect', 'true');
				$ret->setVar( 'msg', $error->message );
			}
			$return = $ret->toString();
		}
		
		// If we are returning to WHMCS, empty the message queue so we don't get some ugly messages upon returning to Joomla
		if ( $fromWhmcs ) {
			$app->_messageQueue = array ();
		}
		
		$app->redirect( $return );
	}
}