<?php
/**
 * Register View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: view.html.php 180 2011-02-09 15:13:46Z steven_gohigher $
 * @since      2.1.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
jimport( "joomla.html.parameter" );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsViewRegister
 * Extends:		JView
 * Purpose:		Handles the Register view
 * As of:		version 2.1.0
\* ------------------------------------------------------------ */
class JwhmcsViewRegister extends JView
{
	/* ------------------------------------------------------------ *\
	 * Handler:		display
	 * Purpose:		Needed for building the class
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function display($tpl = null)
	{
		// Load data for register layout
		$app		= & JFactory::getApplication();
		$tmplparams	=   $app->getParams();
		$pathway	= & $app->getPathway();
		$params		= & JwhmcsParams::getInstance();
		$uri		= & JURI::getInstance();
		$document	= & JFactory::getDocument();
		$model		= & $this->getModel();
		$user		= & JFactory::getUser();
		$thisurl	=   rtrim( $uri->base(), "/") . "/";
		
		// Page Title
		$menus	= & JSite::getMenu();
		$menu	=   $menus->getActive();
		$menups	=   new JParameter( $menu->params );
		
		if ( $menups->get( 'page_title' ) ) $document->setTitle( $menups->get( 'page_title' ) );
		$pathway->addItem( JText::_( 'New' ));
		
		// Load the form validation behavior
		JHtml::_( 'behavior.formvalidation' );
		JHtml::_( 'behavior.mootools' );
		
		$user 	= & JFactory::getUser();
		$post	=   JRequest::get('post');
		
		// Build Country Select
		$country	= JHtml::_('select.genericlist', JwhmcsHelper::buildCountries(), 'country', null, 'value', 'text', ( $post['country'] ? $post['country'] : $params->get( 'WhmcsDefaultcountry' ) ) );
		
		JHtml::script( "jquery.js", rtrim( $params->get( 'ApiUrl' ), "/" ).'/includes/jscript/' );
		JHtml::script( "com_jwhmcs/noconflict.js", array(), true );
		JHtml::script( "com_jwhmcs/ajax.js", array(), true );
		
		JHtml::stylesheet( "com_jwhmcs/signup.css", array(), true );
		
		$tmplparams->set( 'RecaptchaEnable',	$params->get( 'RecaptchaEnable' ));
		$tmplparams->set( 'RecaptchaTheme',		$params->get( 'RecaptchaTheme' ));
		$tmplparams->set( 'RecaptchaLang',		$params->get( 'RecaptchaLang' ));
		$tmplparams->set( 'RecaptchaPublickey',	$params->get( 'RecaptchaPublickey' ));
		
		$params->set( 'scheme', $uri->getScheme() );
		
		$this->assignRef( 'tmplparams',	$tmplparams );
		$this->assignRef( 'params',		$params );
		$this->assignRef( 'user',		$user );
		$this->assignRef( 'country',	$country );
		$this->assignRef( 'post',		$post );
		$this->assignRef( 'tmp', 		$params );
		$this->assignRef( 'thisurl',	$thisurl );
		
		parent::display($tpl);
	}
}