<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: router.php 169 2011-02-04 05:39:14Z steven_gohigher $
 * @since      1.5.0
 */


/**
 * Router for building SEF link
 * 
 * @param	$query (array)
 * @return	$segments (array)
 */
function JwhmcsBuildRoute(&$query)
{
	$segments = array();
	
	if ( isset( $query['controller'] ) ) {
		$segments[0] = $query['controller'] . ( isset( $query['task'] ) ? "." .$query['task'] : "" );
	}
	
	if ( isset( $query['view'] ) ) {
		$segments[1] = $query['view'] . ( isset( $query['layout'] ) ? "." . $query['layout'] : "" );
	}
	elseif ( isset( $query['controller'] ) ) {
		$segments[1] = $query['controller']; 
	}
	
	$removeMe = array( "controller", "task", "view", "layout" );
	foreach ( $removeMe as $remove ) unset( $query[$remove] );
	
	// Query array:  required items up front (view / layout)
	$qarray	= array(	'token'			=> null,
						'jwhmcs'		=> null,
						'username'		=> null,
						'joomlaid'		=> null
	);
	
	foreach ( $qarray as $q => $d )
	{
		if ( isset( $query[$q] ) )
		{
			$segments[] = $query[$q];
			unset ( $query[$q] );
		}
		elseif (! is_null( $d ) )
		{
			$segments[] = $d;
		}
	}
	return $segments;
}


/**
 * Router for parsing SEF link
 * 
 * @param	$segments (array)
 * @return	$vars (array)
 */
function JwhmcsParseRoute($segments)
{
	$vars = array();
	
	if ( count( $segments ) == 0 )
		return $vars;	// Nothing to do
	
	$tmp = explode( ".", $segments[0] );
	
	$vars['controller']	= $tmp[0];
	$vars['task']		= ( count( $tmp ) == 1 ? "display" : $tmp[1] );
	array_shift( $segments );
	
	if ( count( $segments ) == 0 ) {
		$vars['view'] = $vars['controller'];
		return $vars;	// All we can do
	}
	
	$tmp = explode( ".", $segments[0] );
	$vars['view']	= $tmp[0];
	$vars['layout']	= ( count( $tmp ) == 1 ? "default" : $tmp[1] );
	array_shift( $segments );
	
	// Variable array:  required items up front (view / layout)
	$varray	= array(	0	=> 'token',
						1	=> 'jwhmcs',
						2	=> 'username',
						3	=> 'joomlaid'
	);
	
	for ( $i=0; $i<count($segments); $i++ ) {
		if ( isset( $segments[$i] ) ) {
			$vars[$varray[$i]] = $segments[$i];
		}
	}
	
	return $vars;
}
