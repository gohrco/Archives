<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: controller.php 169 2011-02-04 05:39:14Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

class JwhmcsController extends JController
{
	
	function display()
	{
		// If the view hasn't been set, set it to default
		if (is_null(JRequest::getVar( 'controller' ))) JRequest::setVar( 'controller', 'default' );
		if (is_null(JRequest::getVar( 'view'))) JRequest::setVar('view', JRequest::getVar( 'controller' ) );
		
		// Call up the parent display task
		parent::display();
	}
	
	
	function cpanel()
	{
		JRequest::setVar( 'controller', 'default' );
		JRequest::setVar( 'view', 'default' );
		
		parent::display();
	}
	
	
	function helppage()
	{
		JRequest::setVar( 'controller', 'helppage' );
		JRequest::setVar( 'view', 'helppage' );
		
		parent::display();
	}
	
	
	function grpmgr()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=grpmgr', null );
	}
	
	
	function usrmgr()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', null );
	}
}