<?php
/**
 * Default Controller for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsControllerDefault
 * Extends:		JwhmcsController
 * Purpose:		Used as the default controller for user management
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsControllerDefault extends JwhmcsController
{
	/* ------------------------------------------------------------ *\
	 * Task:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		license
	 * Purpose:		Calls appropriate license function
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function license()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=install&task=license', null );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		apiconxn
	 * Purpose:		Calls appropriate api connection check
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function apiconxn()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=install&task=apiconxn', null );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		config
	 * Purpose:		Calls appropriate license function
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function config()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=config', null );
	}
}