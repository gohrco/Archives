J!WHMCS Integrator
------------------------------------------------------------------------

 Release Version: 2.2.7
    Release Date: 2011 July 5

 PLEASE READ ALL THE ENCLOSED INSTRUCTIONS

        Forums: https://forum.gohigheris.com
       Support: https://support.gohigheris.com
 Documentation: https://www.gohigheris.com/wiki
   Client Area: https://client.gohigheris.com


[ CONTENTS ] 
------------------------------------------------------------------------

1. Server Requirements
2. Version 2.2.7 Release Notes
3. New Installation Instructions
4. Upgrade Instructions


[ SERVER REQUIREMENTS ]
------------------------------------------------------------------------

1. Joomla 1.5 (version 1.5.20 or above recommended)
2. WHMComplete Solution (WHMCS) version 4.0 or above (4.3.1 recommended)
3. PHP Version 5.x or later
4. MySQL Version 5.x or later
5. Curl Support (with SSL)
6. Ioncube Loaders Support (required for WHMCS portion of installation)


[ RELEASE NOTES ]
------------------------------------------------------------------------

To review the details and notes for the Version 2.2.7 release, please see:

https://www.gohigheris.com/wiki/Version_2.2.7_Release_Notes


[ NEW INSTALLATION INSTRUCTIONS ]
------------------------------------------------------------------------

For instructions on performing a new installation of J!WHMCSIntegrator, please see:

https://www.gohigheris.com/wiki/Version_2.2.7_Release_Notes#Install_Steps


[ UPGRADE INSTRUCTIONS ]
------------------------------------------------------------------------

The recommended steps for upgrading from an earlier version of J!WHMCS
Integrator to this latest release can be found at:

https://www.gohigheris.com/wiki/Version_2.2.7_Release_Notes#Upgrade_Steps
