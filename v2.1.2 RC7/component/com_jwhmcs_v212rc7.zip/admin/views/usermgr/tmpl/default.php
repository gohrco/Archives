<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');

$basepath	= JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/';
#$j32jwhmcs = $basepath.'j-32-jwhmcs.png';
#$j32grpmgr = $basepath.'j-32-grpmgr.png';
#$j32matchall = $basepath.'j-32-matchall.png';
#$j48usrmgr = $basepath.'j-48-usrmgr.png';
#$j32helppage = $basepath.'j-32-helppage.png';

// Icons for the middle of the fields
/*$icon['x']	= 'j-32-xno.png'; // blank icon
$icon['x0']	= 'j-32-x4.png'; // xref_type 0 (not a db setting)
$icon['x-1']	= 'j-32-subaccount.png'; // xref_type -1 (not a db setting)
$icon['x1']	= 'j-32-x1.png'; // xref_type 1
$icon['x2']	= 'j-32-x2.png'; // xref_type 2
$icon['x3']	= 'j-32-x3.png'; // xref_type 3
$icon['x4']	= 'j-32-x4.png'; // xref_type 4
$icon['x5']	= 'j-32-x5.png'; // xref_type 5
$icon['x6']	= 'j-32-x6.png'; // xref_type 6
$icon['x7']	= 'j-32-x7.png'; // xref_type 7
$icon['x8']	= 'j-32-x3.png'; // xref_type 8
$icon['x9']	= 'j-32-x7.png'; // xref_type 9
*
// Message for the middle of the fields
$msg['x']	= JText::_( 'JWHMCS_MSG_NOMATCH' ); // blank icon
$msg['x0']	= JText::_( 'JWHMCS_MSG_GROUPMB' ); // xref_type 0 (not a db setting)
$msg['x-1'] = JText::_( 'JWHMCS_MSG_SUBACCT' ); // xref_type -1 (not a db setting)
$msg['x1']	= JText::_( 'JWHMCS_MSG_MATCHED' ); // xref_type 1
$msg['x2']	= JText::_( 'JWHMCS_MSG_FOUNDUS' ); // xref_type 2
$msg['x3']	= JText::_( 'JWHMCS_MSG_ADDEDUS' ); // xref_type 3
$msg['x4']	= JText::_( 'JWHMCS_MSG_GROUPUS' ); // xref_type 4
$msg['x5']	= JText::_( 'JWHMCS_MSG_MATSUBA' ); // xref_type 5
$msg['x6']	= JText::_( 'JWHMCS_MSG_FNDSUBA' ); // xref_type 6
$msg['x7']	= JText::_( 'JWHMCS_MSG_ADDSUBA' ); // xref_type 7
$msg['x8']	= JText::_( 'JWHMCS_MSG_RESETUS' ); // xref_type 8
$msg['x9']	= JText::_( 'JWHMCS_MSG_RESETUS' ); // xref_type 9
*/
?>


<form action="index.php" method="post" name="adminForm">
	<table class="adminlist" cellpadding="1">
		<thead>
			<tr>
				<th class="title">
					<div class="jwhmcs-hdr"><?php echo JText::_( 'JWHMCS_LABEL_SHOW_JUSERS' ); ?></div>
					<select name="filter_jusers" onchange="document.adminForm.submit(); ">
						<option value="0"<?php echo $this->sort['jusers']==0?' selected':''; ?>><?php echo JText::_( 'JWHMCS_ALL_USERS' ); ?></option>
						<option value="1"<?php echo $this->sort['jusers']==1?' selected':''; ?>><?php echo JText::_( 'JWHMCS_MATCHED_USERS_ONLY' ); ?></option>
						<option value="2"<?php echo $this->sort['jusers']==2?' selected':''; ?>><?php echo JText::_( 'JWHMCS_UNMATCHED_USERS_ONLY' ); ?></option>
					</select>
				</th>
				<th width="200" class="title" >
					<div class="jwhmcs-hdr"><?php echo JText::_( 'JWHMCS_LABEL_SHOW_MATCHES' ); ?></div>
					<select name="filter_matches" onchange="document.adminForm.submit(); ">
						<option value="-1"<?php echo $this->sort['matches']==-1?' selected':''; ?>><?php echo JText::_( 'JWHMCS_UNMATCHED_USERS_ONLY' ); ?></option>
						<option value="0"<?php echo $this->sort['matches']==0?' selected':''; ?>><?php echo JText::_( 'JWHMCS_ALL_USERS' ); ?></option>
						<option value="1"<?php echo $this->sort['matches']==1?' selected':''; ?>><?php echo JText::_( 'JWHMCS_LOCKED_USER_MATCHES' ); ?></option>
						<option value="2"<?php echo $this->sort['matches']==2?' selected':''; ?>><?php echo JText::_( 'JWHMCS_FOUND_USER_MATCHES' ); ?></option>
						<option value="3"<?php echo $this->sort['matches']==3?' selected':''; ?>><?php echo JText::_( 'JWHMCS_CREATED_USER_MATCHES' ); ?></option>
						<option value="4"<?php echo $this->sort['matches']==4?' selected':''; ?>><?php echo JText::_( 'JWHMCS_GROUP_USERS' ); ?></option>
					</select>
				</th>
				<th width="300" class="title">
					<div class="jwhmcs-hdr"><?php echo JText::_( 'JWHMCS_LABEL_SHOW_WUSERS' ); ?></div>
					<select name="filter_wusers" onchange="document.adminForm.submit(); ">
						<option value="0"<?php echo $this->sort['wusers']==0?' selected':''; ?>><?php echo JText::_( 'JWHMCS_ALL_USERS' ); ?></option>
						<option value="1"<?php echo $this->sort['wusers']==1?' selected':''; ?>><?php echo JText::_( 'JWHMCS_MATCHED_USERS_ONLY' ); ?></option>
						<option value="2"<?php echo $this->sort['wusers']==2?' selected':''; ?>><?php echo JText::_( 'JWHMCS_UNMATCHED_USERS_ONLY' ); ?></option>
					</select>
				</th>
			</tr>
			<tr>
				<th colspan="3" class="title">
					<?php echo JText::_( 'Filter' ); ?>:
					<input type="text" name="user_search" id="user_search" value="<?php echo $this->sort['user_search'] ?>" class="text_area" onchange="document.adminForm.submit();" />
					<button onclick="this.form.submit();"><?php echo JText::_( 'Go' ); ?></button>
					<button onclick="document.getElementById('user_search').value='';this.form.submit();"><?php echo JText::_( 'Reset' ); ?></button>
				</th>
			</tr>
			<tr>
				<th width="300" class="title">
					<div class="jwhmcs-hdr"><?php echo JText::_( 'JWHMCS_ADMIN_LABEL_JSORTBY' ); ?></div>
					<div class="jwhmcs-hdrsort">
					<?php echo $this->sort['joomla']; ?>
					</div>
				</th>
				<th width="200" class="title" >
				</th>
				<th width="300" class="title">
					<div class="jwhmcs-hdr"><?php echo JText::_( 'JWHMCS_ADMIN_LABEL_WSORTBY' ); ?></div>
					<div class="jwhmcs-hdrsort">
					<?php echo $this->sort['whmcs']; ?>
					</div>
				</th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="3">
					<?php echo $this->pagination->getListFooter(); ?>
				</td>
			</tr>
		</tfoot>
		<tbody>
		<?php
			$k = 0;
			for ($i=0, $n=count( $this->data ); $i < $n; $i++)
			{
				$row 	=& $this->data[$i];

				$img 	= $row->jblock ? 'publish_x.png' : 'tick.png';
				$task 	= $row->jblock ? 'unblock' : 'block';
				$alt 	= $row->jblock ? JText::_( 'JUSER_ENABLED' ) : JText::_( 'JUSER_BLOCKED' );
				
				$disp['break']	= false;
				$disp['find']	= false;
				$disp['findsub']= false;
				$disp['add']	= false;
				$disp['addsub']	= false;
				$disp['update']	= false;
				
				switch($row->xref_type):
				case '-1':
					$disp['findsub']= true;
					$disp['addsub']	= true;
					break;
				case '0':
				case '4':
					$disp['group'] = true;
					break;
				case null:
					$disp['find'] = true;
					$disp['add']	= true;
					break;
				case '8':
				case '9':
					$disp['break'] = true;
					break;
				default:
					$disp['break'] = true;
					$disp['update'] = true;
					break;
				endswitch;
				
				// Actions for the middle of the fields
				$action['x']	= '';
				
				$action['x0']	= '';
				$action['x1']	= $brklnk; // xref_type 1
				$action['x2']	= $brklnk; // xref_type 2
				$action['x3']	= $brklnk; // xref_type 3
				$action['x4']	= $action['x0'];
				$action['x5']	= $brklnk; // xref_type 5 - matched subaccounts
				$action['x6']	= $brklnk; // xref_type 6
				$action['x7']	= $brklnk; // xref_type 7
				$action['x8']	= $brklnk; // xref_type 8
				$action['x9']	= $brklnk; // xref_type 9
								
				if ($row->jid):
					$jimg 	= $row->jblock ? 'publish_x.png' : 'tick.png';
					$jalt 	= $row->jblock ? 'Unblock' : 'Block' ;
					$jalign	= 'top';
					
					$jcontent = '
					<strong>'.$row->jname.'</strong>
					<div style="margin-left: 30px; ">
						'.($row->xref_type==0?'':'US:  '.$row->jusername.'<br />').'
						'.$row->jgroupname.'<br />
						<a href="mailto:'.$row->jemail.'">
							'.$row->jemail.'</a><br />
						<a href="javascript:void(0);" onclick="return listItemTask(\'cb'.$i.'\,\''.$task.'\')">
							<img src="images/'.$img.'" width="16" height="16" border="0" alt="'.$alt.'" /></a>
						&nbsp;&nbsp;'.($row->xref_type===0?'Group ID':'Joomla ID').' #:  '.$row->jid.'
					</div>';
				else:
					$jalign	= 'middle';
					$jcontent = '
						<div style="vertical-align: middle; text-align: center; width: 100%; ">
						'.JText::_( 'JWHMCS_MSG_NOJUSERM' ).'</div>';
				endif;
				
				if ($row->wid):
					$walign	= 'top';
					$wcontent = '
					<strong>
						'.$row->wfname.'&nbsp;'.$row->wlname.'</strong>
					<div style="margin-left: 30px; ">
						'.(isset($row->wcname)?$row->wcname.'<br />':'').'
						'.(isset($row->waddress1)?$row->waddress1.'<br />':'').'
						'.(isset($row->waddress2)?$row->waddress2.'<br />':'').'
						'.(isset($row->wcity)?$row->wcity.', ':'').'
						'.(isset($row->wstate)?$row->wstate.'  ':'').'
						'.(isset($row->wpostcode)?$row->wpostcode.'  ':'').'
						'.$row->wcountry.'<br />
						'.(isset($row->wphonenumber)?'Phone:  '.$row->wphonenumber.'<br />':'').'
						<a href="mailto:'.$row->wemail.'">
							'.$row->wemail.'</a><br />
						' . JText::_( "JWHMCS_USRMGR_WTXT{$row->xref_type}" ) . " #:  {$row->wid}
						</div>";
				else:
					$walign	= 'middle';
					$wcontent = '
						<div style="vertical-align: middle; text-align: center; width: 100%; ">
						'.JText::_( 'JWHMCS_MSG_NOWUSERM' ).'</div>';
				endif;
				
			?>
			<tr class="<?php echo "row$k"; ?>">
				<td style="vertical-align: <?php echo $jalign; ?>; ">
					<?php echo $jcontent; ?>
				</td>
				<td align="center" style="vertical-align: middle; ">
					<table class="axns" width="80%">
						<tbody>
							<tr>
								<td class="axnicon axnicon-x<?php echo $row->xref_type; ?>" width="40">&nbsp;</td>
								<td class="axnhdr"><?php echo JText::_( 'JWHMCS_USRMGR_X'.$row->xref_type ); ?></td>
							</tr>
							<tr>
								<td width="40">&nbsp;</td>
								<td class="axnbtns">
									<table class="toolbar" width="75%">
										<tbody>
											<tr>
												<?php if ($disp['break']): ?>
												<td class="button">
													<a class="toolbar" href="<?php echo JRoute::_('index.php?option=com_jwhmcs&controller=usermgr&task=syncbreak&xa='.$row->jid.'&xb='.$row->wid.'&xt='.$row->xref_type); ?>">
														<span class="icon-32-userunlock" title="<?php echo JText::_( 'JWHMCS_MSG_BRKMATCH' ); ?>">&nbsp;</span><?php echo JText::_( 'JWHMCS_MSG_BRKMATCH' ); ?></a>
												</td>
												<?php endif; ?>
												<?php if ($disp['find']): ?>
												<td class="button">
													<a class="toolbar" href="<?php echo JRoute::_('index.php?option=com_jwhmcs&controller=usermgr&task=sync&'.($row->wid?'whmcs':'joom').'id='.($row->wid?$row->wid:$row->jid)); ?>">
														<span class="icon-32-userfind" title="<?php echo JText::_( 'JWHMCS_MSG_FNDMATCH' ); ?>">&nbsp;</span><?php echo JText::_( 'JWHMCS_MSG_FNDMATCH' ); ?></a>
												</td>
												<?php endif; ?>
												<?php if ($disp['findsub']): ?>
												<td class="button">
													<a class="toolbar" href="<?php echo JRoute::_("index.php?option=com_jwhmcs&controller=usermgr&task=sync&whsubid={$row->wid}"); ?>">
														<span class="icon-32-userfind" title="<?php echo JText::_( 'JWHMCS_MSG_FNDMATCH' ); ?>">&nbsp;</span><?php echo JText::_( 'JWHMCS_MSG_FNDMATCH' ); ?></a>
												</td>
												<?php endif; ?>
												<?php if ($disp['add']): ?>
												<td class="button">
													<a class="toolbar" href="<?php echo JRoute::_('index.php?option=com_jwhmcs&controller=usermgr&task='.($row->wid?'joom':'whmcs').'add&'.($row->wid?'whmcs':'joomla').'id='.($row->wid?$row->wid:$row->jid)); ?>">
														<span class="icon-32-useradd" title="<?php echo JText::_( 'JWHMCS_MSG_FORCEADD' ); ?>">&nbsp;</span><?php echo JText::_( 'JWHMCS_MSG_FORCEADD' ); ?></a>
												</td>
												<?php endif; ?>
												<?php if ($disp['addsub']): ?>
												<td class="button">
													<a class="toolbar" href="<?php echo JRoute::_("index.php?option=com_jwhmcs&controller=usermgr&task=joomadd&wcontid={$row->wid}"); ?>">
														<span class="icon-32-useradd" title="<?php echo JText::_( 'JWHMCS_MSG_FORCEADD' ); ?>">&nbsp;</span><?php echo JText::_( 'JWHMCS_MSG_FORCEADD' ); ?></a>
												</td>
												<?php endif; ?>
												<?php if ($disp['update']): ?>
												<td class="button">
													<a class="toolbar" href="<?php echo JRoute::_('index.php?option=com_jwhmcs&controller=usermgr&task=changeUsername&xa='.$row->jid.'&xb='.$row->wid.'&xt='.$row->xref_type); ?>">
														<span class="icon-32-userupdate" title="<?php echo JText::_( 'JWHMCS_MSG_CHUSERNAME' ); ?>">&nbsp;</span><?php echo JText::_( 'JWHMCS_MSG_CHUSERNAME' ); ?></a>
												</td>
												<?php endif; ?>
												<?php if ($disp['group']): ?>
												<td class="button">
													<a class="toolbar" href="<?php echo JRoute::_('index.php?option=com_jwhmcs&controller=grpmgr&task=userlist&cid='.$row->wid); ?>">
														<span class="icon-32-userunlock" title="<?php echo JText::_( 'JWHMCS_MSG_MANGROUP' ); ?>">&nbsp;</span><?php echo JText::_( 'JWHMCS_MSG_MANGROUP' ); ?></a>
												</td>
												<?php endif; ?>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
					</table>
				</td>
				<td style="vertical-align: <?php echo $walign; ?>; ">
					<?php echo $wcontent; ?>
				</td>
			</tr>
			<?php
				$k = 1 - $k;
				}
			?>
		</tbody>
	</table>

	<input type="hidden" name="option" value="com_jwhmcs" />
	<input type="hidden" name="controller" value="usermgr" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="sortby" value="<?php echo $this->sort['sortby']; ?>" />
	<input type="hidden" name="sortord" value="<?php echo $this->sort['sortord']; ?>" />
	<?php echo JHTML::_( 'form.token' ); ?>
</form>