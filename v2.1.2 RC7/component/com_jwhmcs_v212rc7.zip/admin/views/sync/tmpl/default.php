<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');

//$j32refres = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-refresh.png';
$j32refres = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-refresh.png';
$j32jwhmcs = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-jwhmcs.png';
$j32syncer = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-sync.png';
$j32reload = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-reload.png';
$j48syncer = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-48-sync.png';
$j32usrmgr = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-usrmgr.png';
$j32helppage = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-helppage.png';
?>
<style type="text/css">
.icon-32-usrmgr		{ background-image: url(<?php echo $j32usrmgr; ?>); }
.icon-32-jwhmcs		{ background-image: url('<?php echo $j32jwhmcs; ?>'); }
.icon-32-helppage	{ background-image: url('<?php echo $j32helppage; ?>'); }
.icon-32-refresh {
	background-image: url('<?php echo $j32refres; ?>');	
}
.icon-32-sync {
	background-image: url('<?php echo $j32syncer; ?>');	
}
.icon-32-reload {
	background-image: url('<?php echo $j32reload; ?>');	
}
.icon-48-sync {
	background-image: url('<?php echo $j48syncer; ?>');	
}
</style>

<form action="index.php" method="post" name="adminForm">
<div id="adminCell">
	<table class="adminlist">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_( 'JWHMCS_ADMIN_LABEL_ID' ); ?>
			</th>
			<th width="20">
				<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->data ); ?>);" />
			</th>
			<th>
				<?php echo JText::_( 'JWHMCS_ADMIN_LABEL_TYPE' ); ?>
			</th>
			<th>
				<?php echo JText::_( 'JWHMCS_ADMIN_LABEL_NAME' ); ?>
			</th>
			<th>
				<?php echo JText::_( 'JWHMCS_ADMIN_LABEL_WCNAME2' ); ?>
			</th>
			<th>
				<?php echo JText::_( 'JWHMCS_ADMIN_LABEL_EMAIL' ); ?>
			</th>
			<th>
				<?php echo JText::_( 'JWHMCS_ADMIN_LABEL_WADDR' ); ?>
			</th>
			<th>
				<?php echo JText::_( 'JWHMCS_ADMIN_LABEL_WPHONE' ); ?>
			</th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td colspan="7">
				<?php echo $this->pagination->getListFooter(); ?>
			</td>
		</tr>
	</tfoot>
	<?php
	$k = 0;
	for ($i=0, $n=count( $this->data ); $i < $n; $i++)	{
		$row = &$this->data[$i];
		$checked 	= JHTML::_('grid.id',   $i, "{$row->id},{$row->type}" );
		$link 		= JRoute::_( 'index.php?option=com_jwhmcs&controller=grpmgr&task=userlist&cid='. $row->id );
		$name		= ($row->lname?$row->lname.', ':'').($row->fname?$row->fname.' ':'');
		$type		= ( $row->type == 1 ? "Client" : "Subaccount");
		$typeimg	= JURI::base()."components/".JRequest::getCmd('option','com_jwhmcs')."/assets/icons/j-16-" . ( $row->type == 1 ? "usrmgr" : "subaccount" ) . ".png";
		?>
		<tr class="<?php echo "row$k"; ?>">
			<td>
				<?php echo $row->id; ?>
			</td>
			<td>
				<?php echo $checked; ?>
			</td>
			<td align="center">
				<img src="<?php echo $typeimg; ?>" alt="<?php echo $type; ?>" />
			</td>
			<td>
				<?php echo $name; ?>
			</td>
			<td>
				<?php echo isset($row->cname)?$row->cname:''; ?>
			</td>
			<td>
				<?php echo isset($row->email)?$row->email:''; ?>
			</td>
			<td>
				<?php echo isset($row->address1)?$row->address1:''; ?> <?php echo isset($row->address2)?$row->address2:''; ?>, <?php echo isset($row->city)?$row->city:''; ?>,  <?php echo isset($row->state)?$row->state:''; ?>  <?php echo isset($row->postal)?$row->postal:''; ?> (<?php echo isset($row->country)?$row->country:''; ?>)
			</td>
			<td>
				<?php echo isset($row->phone)?$row->phone:''; ?>
			</td>
		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	</table>
</div>

<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="sync" />
</form>