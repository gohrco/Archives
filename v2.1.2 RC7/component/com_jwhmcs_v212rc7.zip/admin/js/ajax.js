function ajaxCheckAPIU()
{
	var jwhmcsadminus = document.getElementById('jwhmcsadminus').value;
	var jwhmcsadminpw = document.getElementById('jwhmcsadminpw').value;
	var accesskey = document.getElementById('accesskey').value;
	var jwhmcsurl = document.getElementById('jwhmcsurl').value;
	jwhmcsurl = encodeURIComponent(jwhmcsurl);
	document.getElementById('apistatus').innerHTML='<div style="width: 32px; margin: 0px auto; padding: 10px; "><img src="components/com_jwhmcs/assets/ajax-img.gif" /></div><div style="width: 200px; margin: 0px auto; font-size: small; font-weight: bold; clear: both; padding: 10px; text-align: center; ">One moment...</div>';
	var xhr = createXHR();
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var apistatus=document.getElementById("apistatus");
				try //Internet Explorer
				{
					xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
					xmlDoc.async="false";
					xmlDoc.loadXML(xhr.responseText);
				}
				catch(e)
				{
					try //Firefox, Mozilla, Opera, etc.
					{
						parser=new DOMParser();
						xmlDoc=parser.parseFromString(xhr.responseText,"text/xml");
					}
					catch(e) {alert(e.message)}
				}
				var result =xmlDoc.getElementsByTagName("param").item(0);
				apistatus.innerHTML='';
				
				var dsc = result.getElementsByTagName("result")[0].childNodes[0].nodeValue;
				var msg = result.getElementsByTagName("message")[0].childNodes[0].nodeValue;
				
				if (dsc == "success") {
					img = "j-32-yes.png";
					document.getElementById('apiconnection').setAttribute("value", "1");
				} else {
					img = "j-32-no.png";
				}
				txt = "<div style=\"width: 32px; margin: 0px auto; padding: 10px; \"><img src=\"components/com_jwhmcs/assets/icons/"+img+"\" /></div>";
				txt = txt + "<div style=\"width: 200px; margin: 0px auto; font-size: small; font-weight: bold; clear: both; padding: 10px; text-align: center; \">"+msg+"</div>";
				apistatus.innerHTML = txt;
				
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
	xhr.open("GET","index2.php?option=com_jwhmcs&controller=ajax&task=checkApiu&jwhmcsadminus="+jwhmcsadminus+"&jwhmcsadminpw="+jwhmcsadminpw+"&accesskey="+accesskey+"&jwhmcsurl="+jwhmcsurl,true);
	xhr.send(null);
}


function createXHR() {
	var xhr = null;
		if (window.XMLHttpRequest) {
			xhr = new XMLHttpRequest();
		} else if (window.ActiveXObject) {
			try {
				xhr = new ActiveXObject('Microsoft.XMLHTTP');
			} catch (e) {}
		}
	return xhr;
}

function URLEncode (clearString) {
	var output = '';
	var x = 0;
	clearString = clearString.toString();
	var regex = /(^[a-zA-Z0-9_.]*)/;
	while (x < clearString.length) {
		var match = regex.exec(clearString.substr(x));
		if (match != null && match.length > 1 && match[1] != '') {
			output += match[1];
			x += match[1].length;
		} else {
			if (clearString[x] == ' ')
				output += '+';
			else {
				var charCode = clearString.charCodeAt(x);
				var hexVal = charCode.toString(16);
				output += '%' + ( hexVal.length < 2 ? '0' : '' ) + hexVal.toUpperCase();
			}
			x++;
		}
	}
	return output;
}

/* Start of 2.0.2 Modifications */
function runInstall(step)
{
	var ajaxLog = $('ajaxLog');
	var ajaxStat = $('ajaxStatus');
	var ajaxMsgs = $('ajaxMessage');
	var whmcspath = $('whmcspath').value;
	whmcspath = encodeURIComponent(whmcspath);
	var url = $('thisUrl').getProperty('value')+"?option=com_jwhmcs&controller=ajax&task=interview&whmcspath="+whmcspath+"&step="+step;
	
	ajaxStat.removeClass('ajaxInitial');
	ajaxStat.addClass('ajaxLoading');
	ajaxMsgs.removeClass('ajaxMessageInitial');
	ajaxMsgs.addClass('ajaxMessageLoading');
	ajaxMsgs.setHTML('Installing');
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var resp = parseXml(xhr.responseText);
				var nextStep = resp.getElementsByTagName("nextstep")[0].childNodes[0].nodeValue;
				var message  = resp.getElementsByTagName("message");
				var txt = ajaxLog.innerHTML;
				var i=0;
				
				for (i=0; i<message.length; i++) {
					txt = message[i].childNodes[0].nodeValue + "\n" + txt;
				}
				ajaxLog.setHTML(txt);
				
				$('step').setProperty('value', nextStep);
				if (nextStep == '110' || nextStep == '210') {
					ajaxCheckAPI(nextStep);
				} else if (nextStep == '150' || nextStep == '155' || nextStep == '250' || nextStep == '255') {
					ajaxCheckLicense(nextStep);
				} else if (nextStep == '1000') {
					completeInstall();
				} else {
					runInstall(nextStep);
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function ajaxCheckLicense(step)
{
	var whmcspath = $('whmcspath').value;
	var license = $('licensekey').value;
	whmcspath = encodeURIComponent(whmcspath);
	license = encodeURIComponent(license);
	
	var ajaxLog  = $('ajaxLog');
	var ajaxStat = $('ajaxStatus');
	var ajaxMsgs = $('ajaxMessage');
	var origStep = $('step');
	var reqLicense = $('reqLicense');
	var textFileinstall = $('textFileinstall');
	var textLicensevalid = $('textLicensevalid');
	var url = $('thisUrl').getProperty('value')+"?option=com_jwhmcs&controller=ajax&task=interview&whmcspath="+whmcspath+"&license="+license+"&step="+step;
	
	ajaxStat.removeClass('ajaxWaiting').addClass('ajaxLoading');
	ajaxMsgs.removeClass('ajaxMessageWaiting').addClass('ajaxMessageLoading');
	ajaxMsgs.empty().setHTML('Checking License...');
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var resp = parseXml(xhr.responseText);
				var nextStep = resp.getElementsByTagName("nextstep")[0].childNodes[0].nodeValue;
				var valid	 = resp.getElementsByTagName("valid")[0].childNodes[0].nodeValue;
					
				if (valid == true) {
					var message  = resp.getElementsByTagName("message");
					var txt = ajaxLog.innerHTML;
					var i=0;
					
					for (i=0; i<message.length; i++) {
						txt = message[i].childNodes[0].nodeValue + '<br />' + txt;
					}
					ajaxLog.setHTML(txt);
					
					$('step').setProperty('value', nextStep);
					reqLicense.setStyle('visibility', 'collapse');
					ajaxStat.removeClass('ajaxWaiting').addClass('ajaxLoading');
					ajaxMsgs.removeClass('ajaxMessageWaiting').addClass('ajaxMessageLoading');
					ajaxMsgs.empty().setHTML('Installing');
					textFileinstall.removeClass('visDisplay').addClass('visHidden');
					textLicensevalid.removeClass('visHidden').addClass('visDisplay');
					runInstall(nextStep);
				} else {
					ajaxStat.removeClass('ajaxLoading').addClass('ajaxWaiting');
					ajaxMsgs.removeClass('ajaxMessageLoading').addClass('ajaxMessageWaiting');
					reqLicense.setStyle('visibility', 'visible');
					textFileinstall.removeClass('visDisplay').addClass('visHidden');
					ajaxMsgs.empty().setHTML('License Invalid');
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function ajaxCheckAPI(step)
{
	var whmcsurl		= $('whmcsurl').value;
	var jwhmcsadminus	= $('jwhmcsadminus').value;
	var jwhmcsadminpw	= $('jwhmcsadminpw').value;
	var accesskey		= $('accesskey').value;
	whmcsurl			= encodeURIComponent(whmcsurl);
	jwhmcsadminus		= encodeURIComponent(jwhmcsadminus);
	jwhmcsadminpw		= encodeURIComponent(jwhmcsadminpw);
	accesskey			= encodeURIComponent(accesskey);
	
	var ajaxLog			= $('ajaxLog');
	var ajaxStat		= $('ajaxStatus');
	var ajaxMsgs		= $('ajaxMessage');
	var origStep		= $('step');
	var reqApi			= $('reqApi');
	var textWelcome		= $('textWelcome');
	var textApivalid	= $('textApivalid');
	var reqWhmcsPath	= $('reqWhmcsPath');
	var url = $('thisUrl').getProperty('value')+"?option=com_jwhmcs&controller=ajax&task=interview&jwhmcsadminus="+jwhmcsadminus+"&jwhmcsadminpw="+jwhmcsadminpw+"&whmcsurl="+whmcsurl+"&accesskey="+accesskey+"&step="+step;
	
	ajaxStat.removeClass('ajaxWaiting').addClass('ajaxLoading');
	ajaxMsgs.removeClass('ajaxMessageWaiting').addClass('ajaxMessageLoading');
	ajaxMsgs.empty().setHTML('Checking API Username and Password...');
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var resp = parseXml(xhr.responseText);
				var nextStep = resp.getElementsByTagName("nextstep")[0].childNodes[0].nodeValue;
				var valid	 = resp.getElementsByTagName("valid")[0].childNodes[0].nodeValue;
				var message  = resp.getElementsByTagName("message");
				var txt = ajaxLog.innerHTML;
				
				if (valid == true) {
					var i=0;
					for (i=0; i<message.length; i++) {
						txt = message[i].childNodes[0].nodeValue + '<br />' + txt;
					}
					ajaxLog.setHTML(txt);
					
					$('step').setProperty('value', nextStep);
					reqApi.setStyle('visibility', 'collapse');
					ajaxStat.removeClass('ajaxWaiting').addClass('ajaxLoading');
					ajaxMsgs.removeClass('ajaxMessageWaiting').addClass('ajaxMessageLoading');
					ajaxMsgs.empty().setHTML('Installing');
					textWelcome.removeClass('visDisplay').addClass('visHidden');
					textApivalid.removeClass('visHidden').addClass('visDisplay');
					
					/* Display path request */
					ajaxStat.removeClass('ajaxLoading').addClass('ajaxWaiting');
					ajaxMsgs.removeClass('ajaxMessageLoading').addClass('ajaxMessageWaiting');
					reqWhmcsPath.setStyle('visibility', 'visible');
					textApivalid.removeClass('visDisplay').addClass('visHidden');
					ajaxMsgs.empty().setHTML('Enter Path to WHMCS');
				} else {
					ajaxStat.removeClass('ajaxLoading').addClass('ajaxWaiting');
					ajaxMsgs.removeClass('ajaxMessageLoading').addClass('ajaxMessageWaiting');
					reqApi.setStyle('visibility', 'visible');
					textWelcome.removeClass('visDisplay').addClass('visHidden');
					ajaxMsgs.empty().setHTML(message[0].childNodes[0].nodeValue);
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function completeInstall() {
	var textLicensevalid	= $('textLicensevalid');
	var textComplete		= $('textComplete');
	textLicensevalid.removeClass('visDisplay').addClass('visHidden');
	textComplete.removeClass('visHidden').addClass('visDisplay');
	
	var ajaxLog  = $('ajaxLog').innerHTML;
	var installLog	= $('installLog');
	installLog.setProperty('value', ajaxLog);
	
	document.forms['adminForm'].submit();
}


function ajaxLicenseCheck()
{
	var license = document.getElementById('licensekey').value;
	license = encodeURIComponent(license);
	document.getElementById('whmcsstatus').innerHTML='<div style="width: 32px; margin: 0px auto; padding: 10px; "><img src="components/com_jwhmcs/assets/ajax-img.gif" /></div><div style="width: 200px; margin: 0px auto; font-size: small; font-weight: bold; clear: both; padding: 10px; text-align: center; ">One moment...</div>';
	
	var url = "index2.php?option=com_jwhmcs&controller=ajax&task=checkValidLicense&license="+license;
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var result = parseXml(xhr.responseText);
				var whmcsstatus=document.getElementById("whmcsstatus");
				
				whmcsstatus.innerHTML='';
				
				var dsc = result.getElementsByTagName("result")[0].childNodes[0].nodeValue;
				var msg = result.getElementsByTagName("message")[0].childNodes[0].nodeValue;
				
				if (dsc == "success") {
					img = "j-32-yes.png";
					document.getElementById('license').setAttribute("value", "1");
					
				} else {
					img = "j-32-no.png";
					document.getElementById('license').setAttribute("value", "0");
				}
				txt = "<div style=\"width: 32px; margin: 0px auto; padding: 10px; \"><img src=\"components/com_jwhmcs/assets/icons/"+img+"\" /></div>";
				txt = txt + "<div style=\"width: 200px; margin: 0px auto; font-size: small; font-weight: bold; clear: both; padding: 10px; text-align: center; \">"+msg+"</div>";
				whmcsstatus.innerHTML = txt;
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function verifyFtp(step) {
	var hostname	= $('FtpHostname');
	var port		= $('FtpPort');
	var username	= $('FtpUsername');
	var password	= $('FtpPassword');
	
	hostname		= encodeURIComponent(hostname.value);
	port			= encodeURIComponent(port.value);
	username		= encodeURIComponent(username.value);
	password		= encodeURIComponent(password.value);
	
	var variables	= "&hostname="+hostname+"&port="+port+"&username="+username+"&password="+password+"&step="+step;
	var url = "index2.php?option=com_jwhmcs&controller=ajax&task=verifyFtp"+variables;
	
	var ajaxLog			= $('ajaxLog');
	var ajaxStat		= $('ajaxStatus');
	var ajaxMsgs		= $('ajaxMessage');
	var reqFtp			= $('reqFtp');
	var textWelcome		= $('textWelcome');
	var textApivalid	= $('textApivalid');
	
	ajaxStat.removeClass('ajaxWaiting').addClass('ajaxLoading');
	ajaxMsgs.removeClass('ajaxMessageWaiting').addClass('ajaxMessageLoading');
	ajaxMsgs.empty().setHTML('Verifying Credentials - This may take a moment');
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var resp = parseXml(xhr.responseText);
				var nextStep = resp.getElementsByTagName("nextstep")[0].childNodes[0].nodeValue;
				var valid	 = resp.getElementsByTagName("status")[0].childNodes[0].nodeValue;
				var message  = resp.getElementsByTagName("message");
				var txt = ajaxLog.innerHTML;
				
				if (valid == 1) {
					var i=0;
					for (i=0; i<message.length; i++) {
						txt = message[i].childNodes[0].nodeValue + '<br />' + txt;
					}
					ajaxLog.setHTML(txt);
					
					reqFtp.setStyle('visibility', 'collapse');
					ajaxStat.removeClass('ajaxWaiting').addClass('ajaxLoading');
					ajaxMsgs.removeClass('ajaxMessageWaiting').addClass('ajaxMessageLoading');
					ajaxMsgs.empty().setHTML('Installing');
					textWelcome.removeClass('visDisplay').addClass('visHidden');
					textApivalid.removeClass('visHidden').addClass('visDisplay');
					$('step').setProperty('value', nextStep );
					runInstall(nextStep);
				} else {
					ajaxStat.removeClass('ajaxLoading').addClass('ajaxWaiting');
					ajaxMsgs.removeClass('ajaxMessageLoading').addClass('ajaxMessageWaiting');
					ajaxMsgs.empty().setHTML(message[0].childNodes[0].nodeValue);
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function verifyPath(step)
{
	var whmcspath = $('whmcspath').value;
	whmcspath = encodeURIComponent(whmcspath);
	
	var ajaxLog  = $('ajaxLog');
	var ajaxStat = $('ajaxStatus');
	var ajaxMsgs = $('ajaxMessage');
	var origStep = $('step');
	var reqWhmcsPath = $('reqWhmcsPath');
	var textApivalid = $('textApivalid');
	var textFileinstall = $('textFileinstall');
	
	var url = $('thisUrl').getProperty('value')+"?option=com_jwhmcs&controller=ajax&task=verifyPath&whmcspath="+whmcspath+"&step="+step;
	
	ajaxStat.removeClass('ajaxWaiting').addClass('ajaxLoading');
	ajaxMsgs.removeClass('ajaxMessageWaiting').addClass('ajaxMessageLoading');
	ajaxMsgs.empty().setHTML('Checking Path...');
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var resp = parseXml(xhr.responseText);
				var nextStep = resp.getElementsByTagName("nextstep")[0].childNodes[0].nodeValue;
				var valid	 = resp.getElementsByTagName("valid")[0].childNodes[0].nodeValue;
				
				var message  = resp.getElementsByTagName("message");
				var txt = ajaxLog.innerHTML;
				var i=0;
				
				for (i=0; i<message.length; i++) {
					txt = message[i].childNodes[0].nodeValue + "\n" + txt;
				}
				ajaxLog.setHTML(txt);
				if (valid == true) {
					$('step').setProperty('value', nextStep);
					reqWhmcsPath.setStyle('visibility', 'collapse');
					ajaxStat.removeClass('ajaxWaiting').addClass('ajaxLoading');
					ajaxMsgs.removeClass('ajaxMessageWaiting').addClass('ajaxMessageLoading');
					ajaxMsgs.empty().setHTML('Installing');
					textApivalid.removeClass('visDisplay').addClass('visHidden');
					textFileinstall.removeClass('visHidden').addClass('visDisplay');
					runInstall(nextStep);
				} else {
					ajaxStat.removeClass('ajaxLoading').addClass('ajaxWaiting');
					ajaxMsgs.removeClass('ajaxMessageLoading').addClass('ajaxMessageWaiting');
					reqWhmcsPath.setStyle('visibility', 'visible');
					textApivalid.removeClass('visDisplay').addClass('visHidden');
					ajaxMsgs.empty().setHTML('Path Error');
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function parseXml(data) {
	try //Internet Explorer
	{
		xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
		xmlDoc.async="false";
		xmlDoc.loadXML(data);
	}
	catch(e)
	{
		try //Firefox, Mozilla, Opera, etc.
		{
			parser=new DOMParser();
			xmlDoc=parser.parseFromString(data,"text/xml");
		}
		catch(e) {alert(e.message)}
	}
	return xmlDoc.getElementsByTagName("param").item(0);
}


function createXHR() {
	var xhr = null;
		if (window.XMLHttpRequest) {
			xhr = new XMLHttpRequest();
		} else if (window.ActiveXObject) {
			try {
				xhr = new ActiveXObject('Microsoft.XMLHTTP');
			} catch (e) {}
		}
	return xhr;
}