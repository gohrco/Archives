<?php
/**
 * Dunamis
 * Joomla! - Legacy Handler
 *
 * @package    Dunamis
 * @copyright  @copyWrite@
 * @license    GNU General Public License version 2, or later
 * @version    2.0.1 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This file permits Dunamis to operate across Joomla! versions
 *
 */


if ( version_compare( JVERSION, '3.0', 'ge' ) )
{
	if (! class_exists( 'DunamisControllerExt' ) ) {
		class DunamisControllerExt extends JControllerLegacy {}
	}
	if (! class_exists( 'DunamisControllerForm' ) ) {
		class DunamisControllerForm extends JControllerForm {}
	}
	if (! class_exists( 'DunamisModelExt' ) ) {
		class DunamisModelExt extends JModelLegacy {}
	}
	if (! class_exists( 'DunamisViewExt' ) ) {
		class DunamisViewExt extends JViewLegacy {}
	}
}
else if ( version_compare( JVERSION, '1.6', 'ge' ) )
{
	jimport('joomla.application.component.controller');
	jimport('joomla.application.component.controllerform');
	jimport('joomla.application.component.model');
	jimport( 'joomla.application.component.view' );
	
	if (! class_exists( 'DunamisViewExt' ) ) {
		class DunamisViewExt extends JView {}
	}
	if (! class_exists( 'DunamisControllerExt' ) ) {
		class DunamisControllerExt extends JController {}
	}
	if (! class_exists( 'DunamisControllerForm' ) ) {
		class DunamisControllerForm extends JControllerForm {}
	}
	if (! class_exists( 'DunamisModelExt' ) ) {
		class DunamisModelExt extends JModel {}
	}
}
else
{
	jimport('joomla.application.component.controller');
	jimport('joomla.application.component.model');
	jimport( 'joomla.application.component.view' );

	if (! class_exists( 'DunamisControllerExt' ) ) {
		class DunamisControllerExt extends JController {}
	}
	if (! class_exists( 'DunamisControllerForm' ) ) {
		class DunamisControllerForm extends JController {}
	}
	if (! class_exists( 'DunamisModelExt' ) ) {
		class DunamisModelExt extends JModel {}
	}
	if (! class_exists( 'DunamisViewExt' ) ) {
		class DunamisViewExt extends JView {}
	}
}