<?php
/**
 * Dunamis
 * 
 * @package    Dunamis
 * @copyright  @copyWrite@
 * @license    GNU General Public License version 2, or later
 * @version    1.4.3 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      1.4.0
 * 
 * @desc       This file renders the default view to the admin user
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.view' );
/*-- File Inclusions --*/

/**
 * IntegratorViewDefault class object
 * @version		1.4.3
 * 
 * @since		3.0.0
 * @author		Steven
 */
class DunamisViewDefault extends DunamisViewExt
{
	
	/**
	 * Displays the backend to the user
	 * @access		public
	 * @version		1.4.3
	 * @param		string		- $tpl: template name (unused)
	 * 
	 * @since		3.0.0
	 */
	public function display($tpl = null)
	{
		$toolbar			=	dunloader( 'toolbar',	'com_dunamis' );
		
		$toolbar->title( 'default' );
		$toolbar->add( 'default' );
		
		parent::display($tpl);
	}
}