<?php defined('DUNAMIS') OR exit('No direct script access allowed');
/**
 * Dunamis Module File
 * This is the module file that each product module is based on
 *
 * @package         Dunamis
 * @version         1.2.1
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2009 - 2013 Go Higher Information Services.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */

/**
 * Dunamis Module class
 * @version		1.2.1
 *
 * @author		Steven
 * @since		1.0.0
 */
class DunModule extends DunObject
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.2.1 ( $id$ )
	 * @param		array		- $options: anything we want to set
	 *
	 * @since		1.0.0
	 */
	public function __construct()
	{
		
	}
	
}