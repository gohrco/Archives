<?php defined('DUNAMIS') OR exit('No direct script access allowed');
/**
 * Joomla Dunamis Document File
 * This is the environment handler of the Dunamis Framework
 *
 * @package         Dunamis
 * @version         1.2.1
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2009 - 2013 Go Higher Information Services.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */


/**
 * Joomla Dunamis Document class handler
 * @version		1.2.1
 *
 * @author		Steven
 * @since		1.1.0
 */
class JoomlaDunDocument extends DunDocument
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.2.1
	 * @param		array		- $options: contains an array of arguments
	 *
	 * @since		1.1.0
	 */
	public function __construct( $options = array() )
	{
		parent :: __construct( $options );
	}
	
	
	/**
	 * Adds a script to the head (<script src=...>)
	 * @access		public
	 * @version		1.2.1
	 * @param		string		- $url: the source url
	 * @param		string		- $type: the type declaration
	 * @param		boolean		- $defer: adds the defer attribute
	 * @param		boolean		- $async: adds the async attribute
	 *
	 * @return		self to permit chaining
	 * @since		1.0.0
	 */
	public function addScript( $url, $type = 'text/javascript', $defer = false, $async = false )
	{
		$doc	=	$document = JFactory::getDocument();
		$doc->addScript( $url, $type, $defer, $async );
		
		return $this;
	}
	
	
	/**
	 * Adds a script to the page
	 * @access		public
	 * @version		1.2.1
	 * @param		string		- $content: the script
	 * @param		string		- $type: the type of script
	 *
	 * @return		self to permit chaining
	 * @since		1.0.0
	 */
	public function addScriptDeclaration($content, $type = 'text/javascript')
	{
		$doc	=	$document = JFactory::getDocument();
		$doc->addScriptDeclaration( $content, $type );
		
		return $this;
	}
	
	
	/**
	 * Adds a linked stylesheet to the page
	 * @access		public
	 * @version		1.2.1
	 * @param		string		- $url: the source of the stylesheet
	 * @param		string		- $type: the encoding type
	 * @param		string		- $media: the media type applied to
	 * @param		array		- $attribs: any attributes to set
	 *
	 * @return		self to permit chaining
	 * @since		1.0.0
	 */
	public function addStyleSheet( $url, $type = 'text/css', $media = null, $attribs = array() )
	{
		$doc	=	$document = JFactory::getDocument();
		$doc->addStyleSheet( $url, $type, $media, $attribs );
		
		return $this;
	}
	
	/**
	 * Adds a stylesheet declaration to the page
	 * @access		public
	 * @version		1.2.1
	 * @param		string		- $content: the style to write
	 * @param		string		- $type: the type of style we are writing
	 *
	 * @return		self to permit chaining
	 * @since		1.0.0
	 */
	public function addStyleDeclaration( $content, $type = 'text/css' )
	{
		$doc	=	$document = JFactory::getDocument();
		$doc->addStyleDeclaration( $content, $type );
		
		return $this;
	}
}