<?php defined('DUNAMIS') OR exit('No direct script access allowed');

class DunModule extends DunObject
{
	
	public function __construct()
	{
		
	}
	
}