<?php
/**
 * Dunamis Hooks File
 * This initializes the Dunamis Framework on WHMCS regardless
 *
 * @package         Dunamis
 * @version         1.1.5
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2009 - 2013 Go Higher Information Services.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */


if (! function_exists( 'get_dunamis' ) ) {
	$path	= dirname( dirname( dirname( dirname(__FILE__) ) ) ) . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'dunamis.php';
	if ( file_exists( $path ) ) require_once( $path );
}

if ( function_exists( 'get_dunamis' ) ) {
	get_dunamis( 'dunamis' );
}
