<?php


class DunObject
{
	public function __construct() {}
}