<?php
/**
 * This file outputs document data to the admin head
 */

