<?php
/**
 * This file outputs document data to the admin head
 */

echo dunmodule( 'themer' )->renderClientHeaderOutput();