<?php
/**
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: router.php 9 2009-09-30 23:01:32Z Steven $
 * @since		1.5.0
 */


/**
 * Router for building SEF link
 * 
 * @param	$query (array)
 * @return	$segments (array)
 */
function JwhmcsBuildRoute(&$query)
{
	$segments = array();
	
	if(isset($query['layout'])) {
		$segments[] = $query['layout'];
		unset($query['layout']);
	}

	return $segments;
}


/**
 * Router for parsing SEF link
 * 
 * @param	$segments (array)
 * @return	$vars (array)
 */
function JwhmcsParseRoute($segments)
{
	$vars = array();
	
	switch($segments[0]):
		case 'register':
			$vars['layout']	= 'register';
			break;
		case 'edit':
			$vars['layout'] = 'edit';
			break;
	endswitch;
	
	return $vars;
}
