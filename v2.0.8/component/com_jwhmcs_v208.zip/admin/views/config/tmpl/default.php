<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');
jimport('joomla.html.pane');

$pane =& JPane::getInstance('tabs'); 

$data = $this->data;
$j32jwhmcs = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-jwhmcs.png';
$j48settings = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-48-settings.png';
$j32yes = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-yes.png';
$j16yes = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-16-yes.png';
$j32no = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-no.png';
$j16no = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-16-no.png';
?>
<style type="text/css">
.icon-48-settings{
	background-image: url('<?php echo $j48settings; ?>');	
}
.icon-32-jwhmcs {
	background-image: url('<?php echo $j32jwhmcs; ?>');	
}
table.adminlist thead tr {
	border-spacing: 0px;
}
table.adminlist thead tr th.hdr {
	border-bottom: 0px;
	font-size: 12pt;
	line-height: 1.1em;
	margin: 0px;
	padding: 4px 0px;
}
table.adminlist tr td.status {
	vertical-align: top;
	text-align: center;
}
table.adminlist tr td.title, table.adminlist tr td.title2 {
	font-weight: bold;
	text-align: center;
	vertical-align: top;
}
table.adminlist tr td.value {
	font-weight: bold;
	text-align: center;
	vertical-align: top;
}
table.adminlist tr td.detail {
	vertical-align: top;
	font-style: italic;
}
table.adminlist tr td.title2 {
	border-left: 1px solid #999999;
}
</style>

<form action="index.php" method="post" name="adminForm">

<?php 
echo $pane->startPane( 'pane' );
echo $pane->startPanel( 'Component Configuration', 'comconfig' );
?>
<form action="index.php" method="post" name="adminForm">
<div id="componentCell">
	<table class="admintable">
<?php 
	$k = 0;
	for ($i=0; $i<count($this->data->comp); $i++):
		$row = &$this->data->comp[$i];
?>
		<tr>
			<td class="paramlist_key" width="40%" align="right">
				<span class="editlinktip"><?php echo $row[0]; ?></span>
			</td>
			<td class="paramlist_value">
				<?php echo $row[1]; ?>
			</td>
		</tr>
<?php	
		$k = 1 - $k;
	endfor;
?>
	</table>
</div>

<?php 
echo $pane->endPanel();
echo $pane->startPanel( 'User Integration', 'user' );
?>

<div id="userCell">
	<table class="admintable">
<?php 
	$k = 0;
	for ($i=0; $i<count($this->data->user); $i++):
		$row = &$this->data->user[$i];
?>
		<tr>
			<td class="paramlist_key" width="40%" align="right">
				<span class="editlinktip"><?php echo $row[0]; ?></span>
			</td>
			<td class="paramlist_value">
				<?php echo $row[1]; ?>
			</td>
		</tr>
<?php	
		$k = 1 - $k;
	endfor;
?>
	</table>
</div>

<?php
echo $pane->endPanel();
echo $pane->startPanel( 'Style Integration', 'style' );
?>

<div id="styleCell">
	<table class="admintable">
<?php 
	$k = 0;
	for ($i=0; $i<count($this->data->style); $i++):
		$row = &$this->data->style[$i];
?>
		<tr>
			<td class="paramlist_key" width="40%" align="right">
				<span class="editlinktip"><?php echo $row[0]; ?></span>
			</td>
			<td class="paramlist_value">
				<?php echo $row[1]; ?>
			</td>
		</tr>
<?php	
		$k = 1 - $k;
	endfor;
?>
	</table>
</div>

<?php
echo $pane->endPanel();
echo $pane->startPanel( 'Plugins', 'style' );
?>

<div id="pluginCell">
	<table class="admintable">
<?php 
	$k = 0;
	for ($i=0; $i<count($this->data->plug); $i++):
		$row = &$this->data->plug[$i];
?>
		<tr>
			<td class="paramlist_key" width="40%" align="right">
				<span class="editlinktip"><?php echo $row[0]; ?></span>
			</td>
			<td class="paramlist_value">
				<?php echo $row[1]; ?>
			</td>
		</tr>
<?php	
		$k = 1 - $k;
	endfor;
?>
	</table>
</div>

<?php
echo $pane->endPanel();
echo $pane->startPanel( 'WHMCS Settings', 'style' );
?>

<div id="whmcsCell">
	<table class="admintable">
<?php 
	$k = 0;
	for ($i=0; $i<count($this->data->whmcs); $i++):
		$row = &$this->data->whmcs[$i];
?>
		<tr>
			<td class="paramlist_key" width="40%" align="right">
				<span class="editlinktip"><?php echo $row[0]; ?></span>
			</td>
			<td class="paramlist_value">
				<?php echo $row[1]; ?>
			</td>
		</tr>
<?php	
		$k = 1 - $k;
	endfor;
?>
	</table>
</div>

<?php
echo $pane->endPanel();
echo $pane->endPane();
?>

<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="config" />
</form>