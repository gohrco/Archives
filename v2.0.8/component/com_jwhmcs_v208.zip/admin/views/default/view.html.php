<?php
/**
 * Default View for J!WHMCS Integrator
 * 
 * @package		J!WHMCS Integrator
 * @copyright	Copyright (C) 2009 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: view.html.php 97 2010-01-11 18:56:24Z Steven $
 * @since		1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

/**
 * Default View
 *
 * @package    J!WHMCS Integrator
 */
class JwhmcsViewDefault extends JView
{
	/**
	 * display method of Hello view
	 * @return void
	 **/
	function display($tpl = null)
	{
		$model	= & $this->getModel('default');
		$params	= &JComponentHelper::getParams( 'com_jwhmcs' );
		$lic	= $model->checkLicense(&$params);		// Check J!WHMCS Integrator License
		$wup	= $model->whmcsParamUpdate();	// Update WHMCS Parameters (bool)
		$user	= &JFactory::getUser();
		$task	= JRequest::getVar( 'task' );
		$icons	= $model->getIconDefinitions();
		
		JToolBarHelper :: title( JText::_( 'JWHMCS_ADMIN_TITLE_DEFAULT' ), 'jwhmcs.png' );
		JToolBarHelper :: custom( 'apiconxn', 'apiconxn.png', '', JText::_( 'JWHMCS_ADMIN_BUTTON_APICONXN'), false, false );
		JToolBarHelper :: custom( 'license', 'license.png', '', JText::_( 'JWHMCS_ADMIN_BUTTON_LICENSE'), false, false );
		JToolBarHelper :: preferences( 'com_jwhmcs', '450' );
		JToolBarHelper :: help('jwhmcs.default', true);
		
		$this->assignRef('lic',		$lic);		// Contains the license check data
		$this->assignRef('icondefs', $icons); // Icon definitions
		$this->assignRef('data',	$params);
		parent::display($tpl);
	}
}