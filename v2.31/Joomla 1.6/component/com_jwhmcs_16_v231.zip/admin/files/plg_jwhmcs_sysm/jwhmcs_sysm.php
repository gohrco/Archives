<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: jwhmcs_sysm.php 174 2011-02-05 03:26:47Z steven_gohigher $
 * @since      1.5.0
 * 
 * @desc		This plugin redirects links to option=com_user&task=register to
 * 				the J!WHMCS component (com_jwhmcs) user registration to request
 * 				information from end customer for WHMCS.
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.plugin.plugin');

$curlfile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jwhmcs'.DS.'classes'.DS.'class.curl.php';
if (is_readable($curlfile)) include_once($curlfile);

/**
 * System Plugin
 *
 * @package		J!WHMCS Integrator 
 * @since 		1.5.0
 */
class plgSystemJwhmcs_sysm extends JPlugin {

	/**
	 * Constructor
	 *
	 * @param object $subject The object to observe
	 * @param 	array  $config  An array that holds the plugin configuration
	 * @since 1.5
	 */
	function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	onAfterRender (private)
	 * Purpose:		After rendering site, redirect user if trying to
	 * 				visit com_user based on plugin parameters. 
	 * 
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 * 	1)  ver 1.5.3 - Oct 2009
	 * 			Added ability to redirect to WHMCS user reg or edit page
	\* ------------------------------------------------------------ */
	function onAfterRender()
	{
		$app	= & JFactory::getApplication();
		
		// Don't run if we are in backend
		if( $app->isAdmin() ) return;
		
		// Don't run if we can't find the product parameters
		if (! class_exists('JwhmcsParams') ) return;
		else $params = & JwhmcsParams::getInstance();
		
		// Don't run if product or user integration disabled
		if ((! $params->get( 'UserEnable' )) || (! $params->get( 'Enable' ))) return;
		
		$user 		= & JFactory::getUser();
		$option 	=   JRequest::getCmd( 'option',	'',	'default',	'string' );		
		$task   	=   JRequest::getCmd( 'task',	'', 'default',	'string' );
		$view		=   JRequest::getVar( 'view',	'', 'default',	'string' );
		$layout		=   JRequest::getVar( 'layout',	'',	'default',	'string' );
		$newlink	=   null;
		
		if ( $option=='com_users' && ($task=='registration' || $view=='registration') ):
			// load J!WHMCS Registration page
			if ( $user->get( 'guest' ) ):
				if ( $params->get( 'RegMethod' )== 1 ) {
					$uri = new JURI( $params->get( 'ApiUrl' ) );
					$uri->setPath( $uri->getPath() . '/register.php' );
					$newlink = $uri->toString();
				}
				elseif ($params->get( 'RegMethod' ) == 3 ) {
					// Use Itemid or view
					$menuitem	= "&" . ( $params->get( 'RegMenu' ) ? "Itemid={$params->get( 'RegMenu' )}" : "controller=register" );
					$newlink = JRoute::_('index.php?option=com_jwhmcs'.$menuitem, false);
				}
			endif;
		endif;
		
		if ( $option=='com_users' && ( ( $task=='profile.edit' || $view=='edit' ) || ( $view=='user' && $layout=='form' ) ) ):
			// load J!WHMCS Edit page
			if (! $user->get('guest') ):
				if ( ( $params->get( 'RegMethod' ) == 1 ) || ( $params->get( 'RegMethod' ) == 3 ) ) {
					$uri = new JURI( $params->get( 'ApiUrl' ) );
					$uri->setPath( $uri->getPath() . '/clientarea.php' );
					$uri->setVar( 'action', 'details' );
					$newlink = $uri->toString();
				}
			endif;
		endif;
		
		if ( $option == 'com_users' && ($task == 'reset' || $view == 'reset') ):
			// load J!WHMCS Edit page
			if ( $user->get('guest') ):
				if ($params->get( 'RegPasswordreset' ) == 3 ) {
					$uri = new JURI( $params->get( 'ApiUrl' ) );
					$uri->setPath( $uri->getPath() . '/pwreset.php' );
					$newlink = $uri->toString();
				}
			endif;
		endif;
		
		if ( $newlink != null ) {
			$app->redirect( $newlink );
		}
		return;
	}
}