<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.07 ( $Id: Int_install.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This is the install library for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Install Library 
 * @version		3.1.07
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Int_install
{
	/**
	 * Stores any errors that have occurred
	 * @access		public
	 * @since		3.0.0
	 * @var			array
	 */
	public	$error_stack			= array();
	
	/**
	 * Stores the version of ioncube found on server
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public	$ioncube_version		= null;
	
	/**
	 * Stores the MySQL client version found
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public	$mysql_client_version	= null;
	
	/**
	 * Stores the MySQL server version found
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public	$mysql_server_version	= null;
	
	/**
	 * Stores the PHP version found
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public	$php_version			= null;
	
	/**
	 * Stores reference to CI object
	 * @access		private
	 * @since		3.0.0
	 * @var			CI object
	 */
	private	$ci						= null;
	
	/**
	 * Stores a reference to the CI DB object
	 * @access		private
	 * @since		3.0.0
	 * @var			object
	 */
	private $db						= null;
	
	/**
	 * Stores the data object for installation
	 * @access		private
	 * @since		3.0.0
	 * @var			object
	 */
	private $data					= null;
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.1.07
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		$this->ci = & get_instance();
		$this->ci->load->helper( 'date' );
	}
	
	
	/**
	 * Checks the version of ionCube found
	 * @access		public
	 * @version		3.1.07
	 * 
	 * @return		boolean if ionCube is 4.0 or above
	 * @since		3.0.0
	 */
	public function check_ioncube()
	{
		if (! extension_loaded('ionCube Loader') ) {
			return false;
		}
		
		$vers = $this->ioncube_loader_version_array();
		$this->ioncube_version = $vers['version'];
		
		return ( $vers['major'] >= 4 );
	}
	
	
	/**
	 * Tests the configuration file and template
	 * @access		public
	 * @version		3.1.07
	 * 
	 * @return		boolean true if writable, false if not, string on error
	 * @since		3.0.0
	 */
	public function config_test()
	{
		// Check for new config file and no old config file (ideal)
		if ( ( file_exists( BASEPATH . 'configuration.php.new' ) ) && ( ! file_exists( BASEPATH . 'configuration.php' ) ) ) {
			return is_really_writable( BASEPATH );
		}
		
		// Catch no new config file and no old config file (missing new template file)
		if ( ( ! file_exists( BASEPATH . 'configuration.php.new' ) ) && ( ! file_exists( BASEPATH . 'configuration.php' ) ) ) {
			return 'err1';
		}
		
		// Check for both new and old existing (rename old if possible)
		if ( ( file_exists( BASEPATH . 'configuration.php.new' ) ) && ( file_exists( BASEPATH . 'configuration.php' ) ) ) {
			// Try to rename existing file
			if ( rename( BASEPATH . 'configuration.php', BASEPATH . 'configuration.' . time() . '.bak.php' ) ) {
				return is_really_writable( BASEPATH . '../' );
			}
			// Couldn't rename the old file, so what to do?
			if ( @unlink( BASEPATH .'configuration.php' ) ) {
				return is_really_writable( BASEPATH . '../' );
			}
		}
		
		// Couldn't delete the old config file or no new config file found with an existing old config file
		return 'err2';
	}
	
	
	/**
	 * Tests the directories for permissions
	 * @access		public
	 * @version		3.1.07
	 * 
	 * @return		array of objects
	 * @since		3.0.0
	 */
	public function directory_tests()
	{
		$data	= array();
		$dirs	= array( 'cache' => 'includes/cache', 'logs' => 'logs', 'tmp' => 'tmp' );
		
		foreach ( $dirs as $n => $dir ) {
			$valid	= is_really_writable( BASEPATH . $dir );
			$data[]	= (object) array( 'use' => $valid, 'msg' => sprintf( lang( ( $valid ? 'msg' : 'error' ) . '.dir' ), BASEPATH . $dir ) );
		}
		
		return $data;
	}
	
	
	/**
	 * Retrieves the last error from the installer
	 * @access		public
	 * @version		3.1.07
	 * 
	 * @return		string containing error message or null if none
	 * @since		3.0.0
	 */
	public function get_error()
	{
		return array_pop( $this->error_stack );
	}
	
	
	/**
	 * Retrieves the previous version from the database
	 * @access		public
	 * @version		3.1.07
	 * 
	 * @return		string containing version or false on error
	 * @since		3.0.0
	 */
	public function get_previous_version()
	{
		if ( $this->db == null ) {
			if (! file_exists( BASEPATH . 'configuration.php' ) ) return false;
			
			include_once( BASEPATH . 'configuration.php' );
			
			$this->ci->session->set_userdata( 'hostname', $db_hostname );
			$this->ci->session->set_userdata( 'username', base64_encode( $db_username ) );
			$this->ci->session->set_userdata( 'password', base64_encode( $db_password ) );
			$this->ci->session->set_userdata( 'port', ( isset( $db_port ) ? $db_port : '3306' ) );
			$this->ci->session->set_userdata( 'dbprefix', $db_dbprefix );
			
			if ( ( $this->db = $this->test_db_connection() ) === false ) return false;
			if (! mysql_select_db( $db_database ) ) return false;
		}
		
		$query		= "SELECT `value` FROM `{$this->ci->session->userdata( 'dbprefix' )}settings` WHERE `key` = 'Version'";
		$result		= @mysql_query( $query, $this->db );
		$version	= @mysql_result( $result, 0 );
		
		return $version;
	}
	
	
	/**
	 * Tests the version of MySQL server and client found for server requirements
	 * @access		public
	 * @version		3.1.07
	 * 
	 * @return		boolean true MySQL is okay to use
	 * @since		3.0.0
	 */
	public function mysql_works()
	{
		$this->mysql_client_version = preg_replace( '/[^0-9\.]/', '', mysql_get_client_info() );
		
		if ( $db = $this->test_db_connection() ) {
			$this->mysql_server_version = @mysql_get_server_info($db);
			@mysql_close($db);
		}
		else {
			@mysql_close($db);
			return false;
		}
		
		return ( ( $this->mysql_server_version >= 5 ) && ($this->mysql_client_version >= 5) ) ? true : false;
	}
	
	
	/**
	 * Tests the version of PHP for server requirements
	 * @access		public
	 * @version		3.1.07
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function php_works()
	{
		$this->php_version = phpversion();
		return ( version_compare(PHP_VERSION, '5.3', '>=') ) ? true : false;
	}
	
	
	/**
	 * Performs the actual installation of the database and configuration file
	 * @access		public
	 * @version		3.1.07
	 * 
	 * @return		boolean false on error
	 * @since		3.0.0
	 */
	public function run()
	{
		// Grab the data
		$data		= $this->assemble_data();
		
		// Grab the SQL file and apply the data to it
		$file		= file_get_contents( dirname( dirname( __FILE__ ) ) . DIRECTORY_SEPARATOR . 'sql' . DIRECTORY_SEPARATOR . 'install.sql' );
		$file		= $this->parse_sql( $file );
		
		// Connect to the data server
		if (! $this->db = @mysql_connect( $data->database['server'], $data->database['username'], $data->database['password'] ) ) {
			$this->error_stack[]	= lang( 'error.run-dbcon' );
			return false;
		}
		
		// Create the database if asked to
		if (! empty( $data->database['createdb'] ) ) {
			mysql_query( 'CREATE DATABASE IF NOT EXISTS `' . $data->database['database'] . '`', $this->db );
		}
		
		// Select the database regardless
		if (! mysql_select_db( $data->database['database'], $this->db ) ) {
			$this->error_stack[]	= sprintf( lang( 'error.run-dbsel' ), $data->database['database'] );
			return false;
		}
		
		// Process the SQL file
		if (! $this->process_sql( $file, false ) ) {
			$this->error_stack[]	= lang( 'error.run-dbsql' );
			return false;
		}
		
		// Kill the connection
		mysql_close( $this->db );
		
		// Create the configuration file
		if (! $this->create_config_file( $data ) ) {
			$this->error_stack[]	= lang( 'error.run-config' );
			return false;
		}
		
		return true;
	}
	
	
	/**
	 * Tests the various server requirements
	 * @access		public
	 * @version		3.1.07
	 * 
	 * @return		object containing results
	 * @since		3.0.0
	 */
	public function server_tests()
	{
		$data	= array();
			$data['php']		=	$this->php_works();
			$data['mysql']		=	$this->mysql_works();
			$data['curl']		=	(bool) function_exists( 'curl_init' );
			$data['ioncube']	=	$this->check_ioncube();
			$data['xmlwriter']	=	(bool) class_exists( 'XMLWriter' );
		return (object) $data;
	}
	
	
	/**
	 * Tests the provided database information
	 * @access		public
	 * @version		3.1.07
	 * 
	 * @return		resource upon success, false on error
	 * @since		3.0.0
	 */
	public function test_db_connection()
	{
		$hostname = $this->ci->session->userdata('hostname');
		$username = base64_decode( $this->ci->session->userdata('username') );
		$password = base64_decode( $this->ci->session->userdata('password') );
		$port	  = $this->ci->session->userdata('port');
		return @mysql_connect("$hostname:$port", $username, $password);
	}
	
	
	/**
	 * Tests the requested database prefix to ensure no conflicts occur
	 * @access		public
	 * @version		3.1.07
	 * 
	 * @return		boolean true if prefix is okay false if not
	 * @since		3.0.0
	 */
	public function test_db_prefix()
	{
		$db		= $this->test_db_connection();
		$pref	= $this->ci->input->post( 'dbpref' );
		@mysql_select_db( $this->ci->input->post( 'dbname' ) );
		
		$cycle	= array( 'groups', 'users', 'cnxnmap', 'cnxns', 'meta', 'sess', 'session', 'settings', 'userlog' );
		foreach( $cycle as $i => $c ) $cycle[$i] = $pref . $c;
		
		$result	= mysql_query( "SHOW TABLES" );
		
		while( $row = mysql_fetch_row( $result ) ) {
			if ( in_array( $row[0], $cycle ) ) return false;
		}
		
		return true;
	}
	
	
	/**
	 * Performs the upgrade procedure for pre-existing installs
	 * @access		public
	 * @version		3.1.07
	 * @version		3.0.16	- August 2013: modified database upgrade procedure to ensure always updates
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function upgrade()
	{
		// Make sure the configuration file is still there
		if (! file_exists( BASEPATH . 'configuration.php' ) ) {
			$this->error_stack[]	= lang( 'error.configmissing' );
			return false;
		}
		
		// Include it
		@include_once( BASEPATH . 'configuration.php' );
		
		// Connect to the database server
		if (! $this->db = @mysql_connect( $db_hostname . ":" . ( $db_port ? $db_port : '3306' ), $db_username, $db_password ) ) {
			$this->error_stack[]	= lang( 'error.nodbcnxn' );
			return false;
		}
		
		// Select the database
		if (! mysql_select_db( $db_database, $this->db ) ) {
			$this->error_stack[]	= sprintf( lang( 'error.run-dbsel' ), $data->database['database'] );
			return false;
		}
		
		// Let's do the upgrade...
		$files			=	$this->get_upgrade_files();
		$origvers		=	$this->get_previous_version();
		
		foreach ( $files as $v => $file ) {
			if ( version_compare( $v, $origvers, 'l' ) ) continue;
			$this->process_sql( $file );
		}
		
		$sql	=	$this->parse_sql( "UPDATE IGNORE `__DBPREFIX__settings` SET `value`='" . INTEGRATOR_INSTALL . "' WHERE `key` = 'Version'", false );
		$this->process_sql( $sql, false );
		
		// Kill the connection
		mysql_close( $this->db );
		
		// Kill the configuration template
		@unlink( BASEPATH . 'configuration.php.new' );
		
		return true;
	}
	
	
	/**
	 * Assembles the data for installation
	 * @access		private
	 * @version		3.1.07
	 * 
	 * @return		object of data
	 * @since		3.0.0
	 */
	private function assemble_data()
	{
		$ci		= & $this->ci;
		
		$salt	=   substr( md5( uniqid( rand(), true ) ), 0, 10 );
		$data	=   array(
						'database' => array(
							'server'	=> $ci->session->userdata( 'hostname' ) . ':' . $ci->session->userdata( 'port' ),
							'hostname'	=> $ci->session->userdata( 'hostname' ),
							'username'	=> base64_decode( $ci->session->userdata( 'username' ) ),
							'password'	=> base64_decode( $ci->session->userdata( 'password' ) ),
							'database'	=> $ci->input->post( 'db_database' ),
							'createdb'	=> $ci->input->post( 'db_create' ),
							'prefix'	=> $ci->input->post( 'db_dbprefix' )
						),
						'user' => array(
							'username'	=> $ci->input->post( 'username' ),
							'email'		=> $ci->input->post( 'email' ),
							'salt'		=> $salt,
							'password'	=> $salt . substr( sha1( $salt . $ci->input->post( 'password' ) ), 0, -10),
							'group_name' => 'admin',
							'ip_address' => $ci->input->ip_address(),
							'created_on' => now(),
							'last_login' => now(),
							'active'	=> 1
						),
						'license' => $ci->input->post( 'license' )
					);
		
		$this->data = (object) $data;
		return $this->data;
	}
	
	
	/**
	 * Creates the configuration file by making replacements in the template
	 * @access		private
	 * @version		3.1.07
	 * @param		object		- $data: the data object to use for replacements
	 * 
	 * @return		boolean result
	 * @since		3.0.0
	 */
	private function create_config_file( $data )
	{
		$file	= file_get_contents( BASEPATH . 'configuration.php.new' );
		
		$check	= array(
					'__DBSERVER__'	=> $data->database['hostname'],
					'__USERNAME__'	=> $data->database['username'],
					'__PASSWORD__'	=> $data->database['password'],
					'__DATABASE__'	=> $data->database['database'],
					'__DBPREFIX__'	=> $data->database['prefix']
		);
		
		$file	= str_replace( array_keys( $check ), $check, $file );
		
		$config	= @fopen( BASEPATH . 'configuration.php', 'w+' );
		
		if ( $config !== false ) {
			unlink( BASEPATH . 'configuration.php.new' );
			return @fwrite( $config, $file );
		}
		
		return false;
	}
	
	
	/**
	 * Retrieves the contents of an .sql file
	 * @access		private
	 * @version		3.1.07
	 * 
	 * @return		string containing contents or false on error
	 * @since		3.0.0
	 */
	private function get_sql_contents( $filename )
	{
		$filename	= dirname( dirname( __FILE__ ) ) . DIRECTORY_SEPARATOR . 'sql' . DIRECTORY_SEPARATOR . $filename;
		return ( file_exists( $filename ) ? file_get_contents( $filename ) : false );
	}
	
	
	/**
	 * Method to get the upgrade files and ensure they are in order
	 * @access		private
	 * @version		3.1.07 ( $id$ )
	 *
	 * @return		array
	 * @since		3.0.16
	 */
	private function get_upgrade_files()
	{
		$dh		=	opendir( dirname( dirname(__FILE__) ) . DIRECTORY_SEPARATOR . 'sql' );
		$files	=	array();
	
		while( ( $file = readdir( $dh ) ) !== false ) {
			if ( in_array( $file, array( '.', '..' ) ) ) continue;
			if (! preg_match( "#upgrade-(.*)\.sql#", $file, $matches ) ) continue;
			$files[$matches[1]] = $file;
		}
		
		ksort( $files );
		return $files;
	}
	
	
	/**
	 * Create the ionCube loader version array
	 * @access		private
	 * @version		3.1.07
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	private function ioncube_loader_version_array ()
	{
		if ( function_exists('ioncube_loader_iversion') ) {
			// Mmmrr
			$ioncube_loader_iversion = ioncube_loader_iversion();
			$ioncube_loader_version_major = (int)substr($ioncube_loader_iversion,0,1);
			$ioncube_loader_version_minor = (int)substr($ioncube_loader_iversion,1,2);
			$ioncube_loader_version_revision = (int)substr($ioncube_loader_iversion,3,2);
			$ioncube_loader_version = "$ioncube_loader_version_major.$ioncube_loader_version_minor.$ioncube_loader_version_revision";
		} else {
			$ioncube_loader_version = ioncube_loader_version();
			$ioncube_loader_version_major = (int)substr($ioncube_loader_version,0,1);
			$ioncube_loader_version_minor = (int)substr($ioncube_loader_version,2,1);
		}
		return array('version'=>$ioncube_loader_version, 'major'=>$ioncube_loader_version_major, 'minor'=>$ioncube_loader_version_minor);
	}
	
	
	/**
	 * Assembles the data for installation
	 * @access		private
	 * @version		3.1.07
	 * @param		string		- $sql:  the contents of an sql file
	 * @param		boolean		- $install: if this is for installation true
	 * 
	 * @return		string containing parsed sql statements
	 * @since		3.0.0
	 */
	private function parse_sql( $sql, $install = true )
	{
		$system_url = isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off' ? 'https' : 'http';
		$system_url .= '://'. $_SERVER['HTTP_HOST'];
		$system_url .= dirname( dirname( $_SERVER['SCRIPT_NAME'] ) );
		
		if ( $install ) {
			
			$check	= array (
						'__DBPREFIX__'	=> $this->data->database['prefix'],
						'__EMAIL__'		=> $this->data->user['email'],
						'__USERNAME__'	=> $this->data->user['username'],
						'__PASSWORD__'	=> $this->data->user['password'],
						'__SALT__'		=> $this->data->user['salt'],
						'__IPADDRESS__'	=> $this->data->user['ip_address'],
						'__NOW__'		=> now(),
						'__LICENSE__'	=> $this->data->license,
						'__SYSTEMURL__'	=> $system_url,
						'__TMPDIR__'	=> BASEPATH . 'tmp',
						'__LOGDIR__'	=> BASEPATH . 'logs'
			);
		}
		else {
			$check	= array (
						'__DBPREFIX__'	=> $this->ci->session->userdata( 'dbprefix' ),
						'__NOW__'		=> now(),
						'__SYSTEMURL__'	=> $system_url,
						'__TMPDIR__'	=> BASEPATH . 'tmp',
						'__LOGDIR__'	=> BASEPATH . 'logs'
			);
		}
		foreach ($check as $key => $value ) {
			$sql = str_replace( "$key", $value, $sql );
		}
		
		return $sql;
	}
	
	
	/**
	 * Performs actual SQL commands
	 * @access		private
	 * @version		3.1.07
	 * @param		string		- $raw: contains sql filename or parsed sql statements
	 * @param		boolean		- $is_file: indicates nature of $raw
	 * 
	 * @return		boolean true on success, false on error
	 * @since		3.0.0
	 */
	private function process_sql( $raw, $is_file = true )
	{
		if ( $is_file ) {
			$sql = $this->get_sql_contents( $raw );
			$sql = $this->parse_sql( $sql, false );
		}
		else {
			$sql = $raw;
		}
		
		$queries	= explode( '-- command split --', $sql );
		
		foreach($queries as $query) {
			$query = rtrim( trim($query), "\n;");
			@mysql_query($query, $this->db);
			//if (mysql_errno($this->db) > 0) {
				//return false;
			//}
		}
		return true;
	}
}