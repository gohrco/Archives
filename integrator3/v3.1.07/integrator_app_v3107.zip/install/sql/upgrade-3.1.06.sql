
ALTER TABLE `int_cnxnmap` CHANGE `item` `item` VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL;
