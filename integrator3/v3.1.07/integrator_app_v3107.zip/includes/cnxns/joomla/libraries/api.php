<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Joomla
 * Enter description here ...
 * @author Steven
 *
 */
class Joomla_API extends API2_Request
{
	/**
	 * Indicates which version of the Joomla API we want to call up
	 * @access		private
	 * @var			string
	 * @since		3.1.00
	 */
	protected $apiversion	=	'3.1';
	
	
	/**
	 * Method to load up our object
	 * @access		public
	 * @version		3.1.07
	 * @param		array
	 * 
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function load( $options = array() )
	{
		parent::load( $options );
		
		// Load URL and Token
		$apiurl 	=   $this->get( 'apiurl', $this->getParam( 'api.apiurl', null ) );
		$apitoken	=	Params :: getInstance()->get( 'Secret' );
		
		if (! $apiurl || ! $apitoken ) {
			// @TODO Throw an error
			return false;
		}
		
		// Test for index.php
		if ( strpos( $apiurl, 'index.php' ) === false ) {
			$apiurl	= rtrim( $apiurl, '/' ) . '/index.php';
		}
		
		$this->setApiuri( Uri :: getInstance( $apiurl ) );
		$gmt					=	new DateTime( null, new DateTimeZone('GMT') );
		$this->setApitimestamp( $gmt->format( "U" ) );
		$this->setApitoken( $apitoken );
		
		$this->setApipost( array( 'apitimestamp'	=> $this->getApitimestamp() ) );
		
		$this->setApioptions( array(	'HEADER'			=> false,
										'RETURNTRANSFER'	=> true,
										'SSL_VERIFYPEER'	=> false,
										'SSL_VERIFYHOST'	=> false,
										'CONNECTTIMEOUT'	=> 2,
										'FORBID_REUSE'		=> true,
										'FRESH_CONNECT'		=> true,
										'HTTP_VERSION'		=> CURL_HTTP_VERSION_1_1,
										'HTTPHEADER'		=> array(),
										'COOKIEFILE'		=> "",
										'COOKIEJAR'			=> "",
										'COOKIESESSION'		=> true,
										
		) );
		
		$this->setEnabled( true );
		
		return true;
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE API FUNCTIONS AND ARE CALLED DIRECTLY
	 * **********************************************************************
	 */
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Called to authenticate a set of user credentials
	 * @access		public
	 * @version		3.1.07
	 * @param		array		- $post: an array of variables to post (should be empty if no child library)
	 * @param		array		- $credentials:  allows for specifying creds to api call; will pull from session otherwise
	 * 
	 * @return		boolean true if authenticated, false if failed
	 * @since		3.0.0
	 */
	public function authenticate( $post = array(), $credentials = null )
	{
		if ( $credentials == null ) {
			$credentials = get_var( "credentials" );
		}
		
		$post['username']	= ( isset( $post['username'] ) ? $post['username'] : $credentials['username'] );
		$post['password']	= ( isset( $post['password'] ) ? $post['password'] : $credentials['password'] );
		
		// Clean up empty variables
		foreach ( $post as $k => $v ){ if (! $v ) unset( $post[$k] ); }
		
		$call	= $this->_call_api( 'post', 'Authenticate', $post );
		
		return ( $call->data->result == 'success' ? $call->data : false );
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Retrieves information about the Integrator 3 cnxn
	 * @access		public
	 * @version		3.1.07
	 * @version		3.1.00		- Major refit for new API
	 *
	 * @return		array or false on error
	 * @since		3.0.1 (0.1)
	 */
	public function get_info()
	{
		$call	= $this->_call_api( 'get', 'Getinfo' );
		return $call->result == 'success' ? (array) $call->data : array();
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Retrieves the languages on this connection
	 * @access		public
	 * @version		3.1.07
	 * @version		3.1.00		- Major refit for new API
	 * 
	 * @return		array containing either the languages or empty array
	 * @since		3.0.0
	 */
	public function get_languages()
	{
		$call	= $this->_call_api( 'get', 'Getlanguages' );
		return $call->result == 'success' ? (array) $call->data : array();
	}
	
	
	/**
	 * Retrieves missing credentials from the connection
	 * @access		public
	 * @version		3.1.00
	 * @param		string		- $credential: the item being sought
	 * 
	 * @return		string containing the found item or false on error or nothing found
	 * @since		3.0.0
	 */
	public function get_missing_credential( $credential = 'password' )
	{
		$missing_item = false;
		switch( $credential ):
		case 'username':
			$creds		=	get_var( "credentials" );
			$post		=	array(
					'data'	=>	array( 'email' => $creds['email'] )
			);
			
			$call		=	$this->_call_api( 'post', 'Userfind', $post  );
			
			$missing_item	= ( $call->result == 'success' ? $call->data->username : false );
			break;
			
		case 'email':
			
			$creds		= get_var( "credentials" );
			$username	= $creds['username'];
				
			$post	= array(
					'username'	=> $username
			);
				
			$call			=	$this->_call_api( 'post', 'Missingemail', $post );
			$missing_item	=	( $call->result == 'success'
					? ( $call->data
							? $call->data 
							: false )
					: false );
			
			break;
			
		case 'password':
		default:
			// We can't get a password from Joomla
			$missing_item = false;
			break;
		endswitch;
		return $missing_item;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Retrieves the pages in this connection
	 * @access		public
	 * @version		3.1.07
	 * @version		3.1.00		- Major refit for new API
	 * 
	 * @return		array containing the pages on this connection
	 * @since		3.0.0
	 */
	public function get_pages()
	{
		static $page;
		
		if (! is_array( $page ) ) $page = array();
		
		if (! isset( $page[$this->id] ) ) {
			$page[$this->id]	= array();
			$return				= array();
			
			$post	= array(	'task'		=> "get_menutree"
			); 
			
			$call	= $this->_call_api( 'get', 'Getpages', $post );
			
			// Nothing sent back
			if (! isset( $call->result ) ) {
				debug( 'Joomla: API - nothing was returned by the connection' );
				return array();
			}
			
			// Error sent back
			if ( $call->result != 'success' ) {
				debug( 'Joomla: API - there was an error sent back by the connection', 'info', false );
				return array();
			}
			
			$data = $call->data->data;
			$vers = $call->data->version;
			
			foreach( $data as $menutype => $menuitems ) {
				if (! isset( $return[$menutype] ) ) {
					$return[$menutype] = array();
				}
				
				foreach( $menuitems as $menuitem ) {
					$menuitem = (object) $menuitem;
					if (! isset( $return[$menutype][$menuitem->parent_id] ) ) {
						$return[$menutype][$menuitem->parent_id] = array();
					}
					$return[$menutype][$menuitem->parent_id][] = array( 'value' => $menuitem->id, 'name' => $menuitem->name );
				}
			}
			
			foreach( $return as $menutype => $items ) {
				$items	= build_menu_tree( $items, ( version_compare( $vers, '1.6.0', 'ge' ) ? 1 : 0 ) );
				foreach( $items as $item ) {
					$page[$this->id][$menutype][$item['value']] = $item['name'];
				}
			}
		}
		
		return $page[$this->id];
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Method for testing the connection
	 * @access		public
	 * @version		3.1.07
	 * @version		3.1.00		- Major refit for new API
	 * @param		boolean		- $auth: if we are testing for the authentication then true 
	 *
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function ping( $auth = true )
	{
		static	$instance = array();
		$find	=	$auth ? 1 : 0;
		
		if (! isset( $instance[$find] ) ) {
			if ( $auth ) {
				$ping	=	$this->_call_api( 'get', 'Verify' );
				$instance[1]	=	( (! $ping || ! is_object( $ping ) || $ping->result != 'success' ) ? false : true );
			}
			else {
				$ping	=	$this->_call_api( 'get', 'Verify', array(), array(), false );
				$instance[0]	=	$ping ? true : $this->curl->has_errors();
			}
		}
		
		return $instance[$find];
	}
	
	
	/**
	 * Called to test a connection to ensure it responds
	 * @deprecated
	 * @access		public
	 * @version		3.1.00
	 * @param		mixed		- $check: if a string, assume its an URL, if array test credentials
	 * 
	 * @return		mixed depending on need boolean true if responsive
	 * @since		3.0.0
	 */
	public function pingOLD( $check = null )
	{
		if ( is_string( $check ) ) {
			$post	= array( 'task' => 'ping' );
			$purl	= $check;
			$optns	= array( 'RETURNTRANSFER' => false, 'FAILONERROR' => false );
		}
		else if ( is_array( $check ) ) {
			$post	= array( 'task' => 'apilogin' );
			$purl	= null;
			$optns	= array_merge( $check, array( 'RETURNTRANSFER' => true ) );
		}
		else {
			$post	= array( 'task' => 'ping' );
			$purl	= null;
			$optns	= array( 'RETURNTRANSFER' => true );
		}
		
		$call	= $this->_call_api( $post, 'ping', $purl, $optns );
		
		return ( is_string( $check ) ? $call : ( is_array( $check ) ? $call['data'] : $call['result'] == 'success' ) );
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Method for rendering the site
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 * @param		boolean		- $auth: if we are testing for the authentication then true
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function render( $post = array(), $options = array() )
	{
		$result		=	$this->_call_api( 'get', 'Render', $post, $options );
		
		if (! $result || ! is_object( $result ) || $result->result != 'success' ) {
			return false;
		}
		
		return $result;
	}
	
	
	/**
	 * Updates the cnxn remotely
	 * @access		public
	 * @version		3.1.07
	 *
	 * @return		boolean
	 * @since		3.1.05
	 */
	public function update_cnxn()
	{
		$params	=	Params :: getInstance();
		$data	=	array(
				'dlid'	=>	$params->get( 'downloadid' ),
		);
	
		$call	=	$this->_call_api( 'post', 'Updatecnxn', array( 'settings' => $data ), array ( 'TIMEOUT' => 300 ) );
	
		// Return result
		return ( $call->result == 'success' ? true : $call->error );
	}
	
	
	/**
	 * Updates a setting on the cnxn
	 * @access		public
	 * @version		3.1.00
	 * @param		array		- $post: contains the settings array to update
	 *
	 * @return		true on success; false on error
	 * @since		3.0.0 (0.3)
	 */
	public function update_settings( $post = array() )
	{
		// Catch empties
		if ( ( $data = $this->filter_setting_array( $post ) ) === false ) return true;
		
		$call	=	$this->_call_api( 'post', 'Updatesettings', array( 'settings' => $data ) );
		
		// Return result
		return $call->result == 'success';
	}
	
	
	/**
	 * Create a user on this connection
	 * @access		public
	 * @version		3.1.07
	 * @param		array		- $post: array of variables to create user with
	 * 
	 * @return		boolean true if successful, error message otherwise
	 * @since		3.0.0
	 */
	public function user_create()
	{
		// We must ensure we have all our user settings here
		$cuser	=	Cuser :: getInstance();
		$cuser->complete( $this->getId() );
		
		$data	=   array( 'data' => $this->get_userdata() );
		$call	=	$this->_call_api( 'post', 'Usercreate', $data );
		
		return ( $call->result == 'success' ? true : $call->error );
	}
	
	
	/**
	 * Finds a user by username or email
	 * @access		public
	 * @version		3.1.00
	 * @param		boolean		- $data: if we want the data back set true, else return boolean
	 * 
	 * @return		varies can be boolean or the data result
	 * @since		3.0.0
	 */
	public function user_find( $data = false )
	{
		$post	= array( 'data' => $this->get_userdata() );
		$call = $this->_call_api( 'post', 'Userfind', $post );
		
		if ( $call->result == 'success' ) {
			$this->place_data( $call->data );
		}
		
		return ( $call->result == 'success' ? ( $data ? $call->data : true ) : $call->error );
	}
	
	
	/**
	 * Searches for a user based on entry
	 * @access		public
	 * @version		3.1.00
	 * @param		array		- $post: contains search=>value
	 * 
	 * @return		array
	 * @since		3.0.1 (0.2)
	 */
	public function user_search( $post = array() )
	{
		if ( empty( $post ) ) return array();
		$call			= $this->_call_api( 'post', 'Usersearch', $post );
		
		if ( $call->result != 'success' ) return array();
		return $call->data;
	}
	
	
	/**
	 * Updates user information on this connection
	 * @access		public
	 * @version		3.1.07
	 * @param		array		- $post: an array of variables to update
	 * 
	 * @return		boolean true if successful, error message otherwise
	 * @since		3.0.0
	 */
	public function user_update()
	{
		$data	=   array( 'data' => $this->get_userdata() );
		$call	=	$this->_call_api( 'post', 'Userupdate', $data );
		
		return ( $call->result == 'success' ? true : $call->error );
	}
	
	
	/**
	 * User removal call to the Joomla 1.6 api
	 * @access		public
	 * @version		3.1.07
	 * @param		string		- $email: contains just an email address
	 * 
	 * @return		boolean true if successful, false otherwise
	 * @since		3.0.0
	 */
	public function user_remove() 
	{
		$data	=   array( 'data' => $this->get_userdata() );
		$call	=	$this->_call_api( 'post', 'Userremove', $data );
		
		return ( $call->result == 'success' ? true : $call->error );
	}
	
	
	/**
	 * Validates a set of new user credentials
	 * @access		public
	 * @version		3.1.00
	 * @param		array		- $data: standard formed user data from Integrator
	 * 
	 * @return		boolean true if valid, false otherwise
	 * @since		3.0.0
	 */
	public function user_validation_on_create()
	{
		$data	=   array( 'data' => $this->get_userdata() );
		$call	=	$this->_call_api( 'post', 'Validateoncreate', $data );
		
		return ( $call->result == 'success' ? true : $call->error );
		
	}
	
	
	/**
	 * Validates an updated set of user information
	 * @access		public
	 * @version		3.1.00
	 * @param		array		- $data: standard formed user data from Integrator
	 * 
	 * @return		boolean true if valid, false otherwise
	 * @since		3.0.0
	 */
	public function user_validation_on_update()
	{
		$data	=   array( 'data' => $this->get_userdata() );
		$call	=	$this->_call_api( 'post', 'Validateonupdate', $data );
		
		return ( $call->result == 'success' ? true : $call->error );
	}
	
	
	/**
	 * Method for calling up the API
	 * @access		private
	 * @version		3.1.07
	 * @version		3.1.00		- Total rewrite of API methods
	 * @param		string		- $method: get|put|post...
	 * @param		string		- $call: the actual API method on the remote system
	 * @param		array		- $post: any additional post variables
	 * @param		array		- $optns: we can specify curl options in this
	 * @param		bool		- $wantresult: true if we want the result back false if we just want to know it worked
	 *
	 * @return		mixed array or boolean
	 * @since		3.0.0
	 */
	private function _call_api( $method = 'post', $call = '/Ping', $post = array(), $optns = array(), $wantresult = true )
	{
		// Last chance to test before epic fails
		$uri		=	$this->getApiuri();
		$apitoken	=	$this->getApitoken();
		
		if ( empty( $uri ) || empty( $apitoken ) ) {
			return false;
		}
		
		// Now we should test to ensure it's live
		$apioptns	=	$this->getApioptions();
		$optns		=	array_merge( $apioptns, $optns );
		$apipost	=	$this->getApipost();
		$post		=	array_merge( $apipost, $post );
		$curl		= & get_instance()->curl;
		$call		=	"/{$this->getApiversion()}/" . trim( $call, "/" );
		
		// Lets allow forcing everything to get if we need to
		//$config	=	dunloader( 'config', 'jwhmcs' );
		
		//if ( $config->get( 'forceapitoget', false ) ) {
		//	$method	=	'get';
		//}
		
		// Put methods require the e in the URL
		if ( in_array( $method, array( 'put', 'get' ) ) ) {
			$uri->setVar( 'integrator', $call );
			$uri->setVar( 'apitimestamp', $post['apitimestamp'] );
			unset( $post['apitimestamp'] );
			foreach ( $post as $k => $v ) $uri->setVar( $k, $v );
		}
		else {
			$post['integrator']		= $call;
		}
		
		// Generate the signature
		$sign	=	$this->_generateSignature( $method, $uri, $post );
		
		// include the signature in the method variable and the header
		if ( in_array( $method, array( 'put', 'get' ) ) ) {
			$uri->setVar( 'apisignature', rawurlencode( $sign ) );
		}
		else {
			$post['apisignature']	= rawurlencode( $sign );
		}
		
		// Assemble the API Request
		$curl->create( $uri->toString() );
		$curl->http_header( 'IntegratorRequestSignature', rawurlencode( $sign ) );
		
		if ( $method == 'get' ) {
			$curl->http_method( 'get' );
			$curl->options( $optns );
		}
		else {
			$curl->$method( $post, $optns );
		}
		
		// Execute the Curl Call
		$result	=	$curl->execute();
		
		// Debug handling
		\Tracy\Debugger :: getBar()->getPanel( 'Tracy\ApiBarPanel' )->addData( array(
				'call'		=>	$call,
				'method'	=>	$method,
				'post'		=>	$post,
				'optns'		=>	$optns,
				'result'	=>	$result,
				'curlinfo'	=>	$curl->info
		) );
		
		// Return result
		if (! $wantresult ) {
			return $curl->has_errors() ? false : true;
		}
		
		//		Cleanup string just in case
		$cleaned	=	$this->_cleanupJson( $result );
		
		// Process for returned errors
		$data	= json_decode( $cleaned, false );
		
		// Throw an exception if we are in a development mode
		if (! $data && ENVIRONMENT_LOG === '4' ) {
			$parts	=	explode( "\r\n\r\n", $result );
			if ( count( $parts ) == 2 ) $result = $parts[1];
			\Tracy\Debugger :: getBar()->renderforRedirect();
		}
		
		return $data;
	}
	
	
	/**
	 * Method to cleanup the Json string for PHP just in case Joomla left us a surprise
	 * @access		public
	 * @version		3.1.07 ( $id$ )
	 * @param		string		- $string: what we are starting with
	 *
	 * @return		string cleaned up
	 * @since		3.1.00
	 */
	private function _cleanupJson( $string )
	{
		// Strip off anything before the first curly bracket
		$string	=	preg_replace( "#^[^{]*#im", "", $string );
		
		return $string;
	}
	
	
	/**
	 * Method for generating the signature request
	 * @access		private
	 * @version		3.1.07
	 * @param		string		- $method: method used (get|post|put...)
	 *
	 * @return		string containing hash
	 * @since		3.1.00
	 */
	private function _generateSignature( $method, $uri, $post = array() )
	{
		// Remove the API Signature if this isnt the first time through
		$uri->delVar( 'apisignature' );
		
		$token	=	$this->getApitoken();
		$string	=	$uri->toString();
		$append	=	null;
		
		if ( $method != 'get' ) {
			ksort( $post );
			$usepost	=	array();
			
			foreach ( $post as $k => $v ) {
				if (! in_array( $k, array( 'apisignature', '_c' ) ) ) {
					$usepost[$k] = $v;
				}
			}
			
			\Tracy\Debugger :: barDump( $usepost, 'Variables Posted To API' );
			
			$append	=	$this->_generateString( $usepost );
		}
		
		$hash	=	base64_encode( hash_hmac( 'sha256', rawurldecode( $string ) . $append, $token, true ) );
		return $hash;
	}
	
	
	/**
	 * Method to generate string
	 * @access		public
	 * @version		3.1.07
	 * @param		array
	 * @param		array
	 *
	 * @return		string
	 * @since		3.1.00
	 */
	private function _generateString( $data = array() )
	{
		$string	=	null;
		foreach ( $data as $k => $v ) {
			if ( is_array( $v ) ) {
				$string		.=	$this->_generateString( $v );
			}
			else {
				$v		=	( is_bool( $v ) ? $v == true ? '1' : '0' : $v );
				$string	.=	$k . $v;
			}
		}
		return $string;
	}
	
	
	/**
	 * Overwrite default find api cookies to be sure we find actual user cookies
	 * @access		protected
	 * @version		3.1.07
	 * @param		string		- $header: the data sent back in the header from the API
	 * 
	 * @since		3.0.0
	 * @see			API_Library::_find_api_cookies()
	 */
	protected function _find_api_cookies( $header )
	{
		$data	= null;
		preg_match_all('/^Set-Cookie: (.*?)=(.*?);/m', $header, $cookies, PREG_SET_ORDER );
		
		foreach ( $cookies as $cookie ) {
			// Joomla session variables are 32 long, be sure we are grabbing the correct cookie!
			if ( strlen( $cookie[1] ) == 32 ) {
				$data = $cookie[1] . '=' . $cookie[2];
				break;
			}
		}
		
		if ( empty( $data ) ) { 
			log_message( 'debug', 'Joomla Cnxn API_library (line ' . __LINE__ . '): Unable to find a cookie in header' );
			debug( 'api.findapicookie.nocookie', 'debug' );
			return false;
		}
		
		return $data;
	}
}