<?php
/**
 * Integrator 3
*
* @package    Integrator 3
* @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
* @license    GNU General Public License version 2, or later
* @version    3.1.07 ( $Id: admin_lang.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
* @author     Go Higher Information Services, LLC
* @since      3.0.0
*
* @desc       This is the English language file for the Joomla admin controller pages for the Integrator
*
*/

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

