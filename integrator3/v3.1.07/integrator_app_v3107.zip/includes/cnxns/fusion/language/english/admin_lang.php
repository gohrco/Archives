<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.07 ( $Id: admin_lang.php 163 2012-12-18 14:56:38Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the Joomla admin controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


// ===================================================================
// 	Pagemapping (pagemap/index)
// ===================================================================
//		v 3.0.2
// -------------------------------------------------------------------
$lang['fusion.page.header']	= 'The settings below indicate which pages on this Kayako Fusion connection are mapped from the application selected on the left and the associated page beneath `Page`.  A default page must be set (at the top) and you can choose to have certain pages retrieved when the user is on the associated Kayako Fusion page.';



// ===================================================================
// 	Language Mapping (langmap/index)
// ===================================================================
//		v 3.0.2
// -------------------------------------------------------------------
$lang['fusion.lang.header']	= 'The settings below indicate which languages on this Kayako Fusion connection are mapped from the application selected on the left and the associated language beneath `Language`.  A default language must be set (at the top) and you can choose to have certain languages retrieved when the user is on the associated Kayako Fusion language.';



// ===================================================================
// 	Edit Connection (cnxns/edit)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['fusion_label.api.apisecret']		= "API Secret Value";
$lang['fusion_label.api.apikey']		= "API Key";

$lang['fusion_desc.api.apiurl']			= "Enter the URL to reach your Kayako site.  DO NOT enter the `/api/index.php?` found at the end of your `API URL` value which is found by visiting your Kayako Admin control panel > Dashboard > REST API > API Information.  The `/api/index.php?` is appended automatically for you.";
$lang['fusion_desc.api.apisecret']		= "Enter the value for the `Secret Key` that is in the backend of your Kayako application.  This value can be found by visiting your Kayako Admin control panel > Dashboard > REST API > API Information and is labeled `Secret Key`.";
$lang['fusion_desc.api.apikey']			= "Enter the value for the `API Key` that is in the backend of your Kayako application.  This value can be found by visiting your Kayako Admin control panel > Dashboard > REST API > API Information and is labeled `API Key`.";

// ----- Clientarea Tab
$lang['fusion_clientarea.ticketsdisplay']	= 'Display Tickets';
$lang['fusion_clientarea.ticketsnewwin']	= 'Tickets in New Window';
$lang['fusion_desc.clientarea.ticketsdisplay']	= 'Do you want the ticket summary to be included on the Client Area page for your logged in clients?';
$lang['fusion_desc.clientarea.ticketsnewwin']	= 'Do you want the tickets to be opened in a new window or tab?';



// ===================================================================
// 	System Update (help/systemstatus/updates)
// ===================================================================
//		v 3.0.8
// -------------------------------------------------------------------
$lang['dialog.fusion.update.content']	= '<p>The updates for this connection are handled through FTP and finalized in the backend of Kayako Fusion.  There are also customizations that must be applied to your Kayako Core if you have recently updated it as well.  To update, download the latest package for Kayako Fusion from our site, FTP the files to your Kayako Fusion site and then navigate to your admin area by clicking the button below.  The button will take you to your admin area where you will need to log in, navigate to the Apps section under Settings and perform the upgrade.</p>';
$lang['dialog.fusion.update.header']	= 'Redirect to Kayako Fusion Administrator';
$lang['dialog.fusion.button.redirect']	= 'Redirect';
