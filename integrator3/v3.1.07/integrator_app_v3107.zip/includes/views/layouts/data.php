<?php if ( isset( $actions ) && is_array( $actions ) ) : ?>
<?php echo form_open( null, array( 'method' => 'post', 'id' => 'filter' ) ); ?>
<div class="form-actions filters">
	<?php $use = intval( ( 12 / count( $actions ) ) ); ?>
	<?php foreach ( $actions as $item ) : ?>
	<div class="span<?php echo $use ?>" style="text-align: center; ">
	<?php echo heading( $item->heading, '4' ); ?>
	<?php echo $item->form; ?>
	</div>
	<?php endforeach; ?>
</div>
<?php echo form_close(); ?>
<?php endif; ?>

<table class="table table-striped table-bordered table-condensed">
	<thead>
		<tr>
			<?php foreach ( $cols as $col ) : ?>
			<th>
				<?php echo lang( 'tblhdr.' . $col ); ?>
			</th>
			<?php endforeach; ?>
		</tr>
	</thead>
	<tbody>
		<?php foreach ( $rows as $row ) : ?>
		<tr>
			<?php foreach ( $row as $item ) : ?>
			<td>
				<?php echo $item; ?>
			</td>
			<?php endforeach; ?>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>

<div class="form-actions">
	<div class="offset1">
		<?php echo $pagination; ?>
	</div>
</div>