<?php
/**
 * Integrator 3
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.07 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This file is the Dunamis file for Integrator 3
 *
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Define the Integrator 3 version here
 */
if (! defined( 'DUN_MOD_INTEGRATOR' ) )		define( 'DUN_MOD_INTEGRATOR', "3.1.07" );
if (! defined( 'DUN_MOD_COM_INTEGRATOR' ) )	define( 'DUN_MOD_COM_INTEGRATOR', "3.1.07" );


class Com_integratorDunModule extends DunModule
{
	public function initialise()
	{
		
	}
}