<?php

$pagedefaults	=	<<< PAGES
Affiliates::affiliates.php
Announcements::announcements.php
Banned::banned.php
Cart: Configure Product::cart.php?a=confproduct
Cart: Shopping Cart::cart.php
Cart: View Cart::cart.php?a=view
Client Area::clientarea.php
Client Portal::index.php
Configure SSL::configuressl.php
Contact::contact.php
Credit Card::creditcard.php
Domain Checker::domainchecker.php
Downloads::downloads.php
Knowledgebase::knowledgebase.php
My Details::clientarea.php?action=details
My Domains::clientarea.php?action=domains
My Emails::clientarea.php?action=emails
My Products::clientarea.php?action=products
My Quotes::clientarea.php?action=quotes
Network Issues::networkissues.php
Password Reset::pwreset.php
Password Reset Validation::pwresetvalidation.php
Register::register.php
Server Status::serverstatus.php
Submit Ticket::submitticket.php
Support Tickets::supporttickets.php
Tutorials::tutorials.php
View Invoices::clientarea.php?action=invoices
PAGES;

$form	= array(
		'pages'		=> array(
				'order'			=> 10,
				'type'			=> 'textarea',
				'value'			=> true,
				'validation'	=> '',
				'cols'			=> '100',
				'rows'			=> '15',
				'label'			=> 'integrator.pages.label',
				'description'	=> 'integrator.pages.desc',
				'default'		=>	$pagedefaults,
				'style'			=>	'width: 500px;'
		),
		'customcss'		=> array(
				'order'			=>	20,
				'type'			=>	'textarea',
				'value'			=>	true,
				'validation'	=>	'',
				'cols'			=>	'100',
				'rows'			=>	'15',
				'label'			=>	'integrator.customcss.label',
				'description'	=>	'integrator.customcss.desc',
				'style'			=>	'width: 500px;'
		),
	);