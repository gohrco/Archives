<?php
/**
 * Integrator 3
 * Integrator 3 - User Module File
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.07 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This file is the user controller
 *
 */

/**
 * User Module Class for Integrator 3
 * @version		3.1.07
 *
 * @author		Steven
 * @since		3.1.00
 */
class IntegratorUserDunModule extends WhmcsDunModule
{
	/**
	 * Provide means to check for file integrity
	 * @access		protected
	 * @var			string
	 * @since		3.1.00
	 */
	protected $checkstring	=	"@checkString@";
	
	
	/**
	 * Method to handle adding clients
	 * @access		public
	 * @version		3.1.07
	 * @param		array
	 *
	 * @since		3.1.00
	 */
	public function clientAdd( $vars )
	{
		// If we are disabled don't run ;-)
		if (! ensure_active( 'user' ) ) {
			return;
		}
		
		// If we are adding the user through JWHMCS... don't recursively do it again
		if ( defined( 'INTEGRATORUSERADDATLOGIN' ) ) {
			return;
		}
		
		$api	=	dunloader( 'api', 'integrator' );
		$wapi	=	dunloader( 'whmcsapi', 'integrator' );
		$config	=	dunloader( 'config', true );
		$task	=	'ClientAdd';
		
		$user		=	convert_user( $vars, array(), true, 'to', 'client' );
		$response	=	$api->post_user( $user );
		
		if (! $response ) {
			$error	=	$wapi->log( $task, 'Add User on Integrator3', $api->hasErrors() );
			global $errormessage;
			$errormessage .= '<strong>' . $error . '</strong>';
		}
		
		// If we are on the shopping cart be sure to disable the login routine 
		// from happening automatically and return
		if ( get_filename() == 'cart' ) {
			dunloader( 'config', 'integrator' )->set( 'loginenable', 0 );
			return;
		}
		
		// Admins outta here
		if ( is_admin() ) {
			return;
		}
		
		// Set our return url in the gotourl variable
		global $gotourl;
		
		$use		=	( is_ssl() ? ( $config->get( 'SystemSSLURL' ) ? true : false ) : false );
		$sysurl		=	( $use ? $config->get( 'SystemSSLURL' ) : $config->get( 'SystemURL' ) );
		$gotouri	=	DunUri :: getInstance( $sysurl, true );
		
		if ( isset( $_SERVER['HTTP_REFERER'] ) && $_SERVER['HTTP_REFERER'] ) {
			$gotourl	=	$_SERVER['HTTP_REFERER'];
		}
		else {
			$gotourl	=	rtrim( $gotouri->toString( array( 'path' ) ), '/' ) . '/clientarea.php';
		}
		
		$login		=	dunmodule( 'integrator.login' );
		$login->setCreds( array( 'email' => $user['email'], 'username' => $user['username'] ) );
		
		$login->complete();
		
		return;
// 		// REDIRECTION ROUTINE GOES HERE
		
		
// 		if ( $this->is_admin() ) return;
		
// 		$config	= & JwhmcsFactory :: getConfig();
// 		$uri	=   $this->_find_uri();
		
// 		$uri->setPath( rtrim( $uri->getPath(), '/' ) . '/jwhmcs.php' );
// 		$uri->setScheme( 'http' . ( $config->get( 'RedirGatewayssl', false ) ? 's' : '' ) );
// 		$uri->setVar( 'task', 'ulogin' );
// 		$uri->setVar( 'whmcs', true );
		
// 		$form	= $this->_form_redirect( $uri->toString(), array( 'msg' => $config->get( 'RedirMessage' ), 'username' => $user['email'], 'password' => $user['password'] ), false );
		
// 		$this->_init_languages();
// 		$this->_load_usersettings();
// 		$this->_load_visualsettings();
// 		$this->_set_languagetranslation();
// 		$this->_set_configs();
		
// 		$url		= $this->visual['uri']->toString();
// 		$response	= $this->_call_visual( $url );
// 		$this->_process_response( $response );
		
// 		$log->write();
// 		echo $this->get( 'htmlheader' );
// 		echo $form;
// 		echo $this->get( 'htmlfooter' );
// 		exit;
	}
	
	
	/**
	 * Method to handle changing the password (front end only)
	 * @access		public
	 * @version		3.1.07
	 * @param		array
	 *
	 * @since		3.1.00
	 */
	public function clientChangePassword( $vars )
	{
		// If we are disabled don't run ;-)
		if (! ensure_active( 'user' ) ) {
			return;
		}
		
		$api	=	dunloader( 'api', 'integrator' );
		$wapi	=	dunloader( 'whmcsapi', 'integrator' );
		$input	=	dunloader( 'input', true );
		$task	=	'ClientChangePassword';
		
		if ( is_admin() ) {
			$wapi->log( $task, null, 'Password change bypassed in task as its done elsewhere', 'info', 'Password change bypassed in task as its done elsewhere' );
			return;
		}
		
		$password	=	$input->getVar( 'newpw', ( $vars['password'] ? $vars['password'] : false ) );
		
		if (! $password ) {
			$wapi->log( $task, null, 'No password received by Integrator 3 to update with.', 'info', 'No password received by Integrator 3 to update with.' );
			return;
		}
		
		$user		=	get_user_information( 'fetch', $vars );
		$changes	=	convert_user( $vars, $user, false, 'to', 'client' );
		
		$post	=	array(
				'email'		=>	$user['email'],
				'update'	=>	array(
					'password'	=>	$password,
					'password2'	=>	$password
				),
				);
		
		$result		=	$api->put_user( $post );
		
		if ( $api->hasErrors() ) {
			$error	=	$wapi->log( $task, $post, $api->hasErrors() );
			global $errormessage;
			$errormessage .= '<strong>' . $error . '</strong>';
		}
		
		// REDIRECTION ROUTINE GOES HERE
		return;
	}
	
	
	/**
	 * Method to handle client closure
	 * @access		public
	 * @version		3.1.07
	 * @param		array
	 *
	 * @since		3.1.00
	 */
	public function clientClose( $vars )
	{
		$config	=	dunloader( 'config', 'integrator' );
		$action	=	$config->get( 'clientclose', '1' );
		
		if ( $action == '1' ) {
			$this->clientDelete( $vars );
		}
		else {
			$vars	=	get_user_information( 'validation', 'client' );
			unset( $vars['password'] );
			$this->clientEdit( $vars );
		}
	}
	
	
	/**
	 * Performs client editing
	 * @access		public
	 * @version		3.1.07 ( $id$ )
	 * @param		array		- $vars: the variables passed to us
	 *
	 * @return		void
	 * @since		3.1.00
	 */
	public function clientEdit( $vars )
	{
		// If we are disabled don't run ;-)
		if (! ensure_active( 'user' ) ) {
			return;
		}
		
		$api		=	dunloader( 'api', 'integrator' );
		$wapi		=	dunloader( 'whmcsapi', 'integrator' );
		$olduser	=	false;
		
		if ( isset( $vars['olddata'] ) ) {
			$olduser	=	$vars['olddata'];
		}
		
		if (! $olduser ) {
			$olduser	=	get_user_information( 'validation', 'client' );
		}
		
		$isnew		=	false;
		$changes	=	convert_user( $vars, $olduser, $isnew, 'to', 'client' );
		
		$data		=	array(
			'email'		=>	$olduser['email'],
			'oldemail'	=>	$olduser['email'],
			'isnew'		=>	$isnew,
			'update'	=>	$changes
		);
		
		$response	=	$api->put_user( $data );
		
		if (! $response ) {
			$error	=	$wapi->log( $task, 'Edit User on Integrator3', $api->hasErrors() );
			global $errormessage;
			$errormessage .= '<strong>' . $error . '</strong>';
		}
		
		return;
	}
	
	
	/**
	 * Method to delete a client user on Joomla
	 * @access		public
	 * @version		3.1.07 ( $id$ )
	 * @param		array		- $vars: the variables passed by WHMCS
	 *
	 * @return		void
	 * @since		3.1.00
	 */
	public function clientDelete( $vars, $task = 'ClientDelete' )
	{
		// If we are disabled don't run ;-)
		if (! ensure_active( 'user' ) ) {
			return;
		}
		
		$api	=	dunloader( 'api', 'integrator' );
		$wapi	=	dunloader( 'whmcsapi', 'integrator' );
		
		$data	=	get_user_information( 'fetch', $vars );
		$response	=	$api->delete_user( $data );
		
		if (! $response ) {
			$error	=	$wapi->log( $task, 'Edit User on Integrator3', $api->hasErrors() );
			global $errormessage;
			$errormessage .= '<strong>' . $error . '</strong>';
		}
		
		// Nothing else to do here...
		return;
	}
	
	
	/**
	 * Performs client validation
	 * @desc		As of v5.1 validation is only done for clients
	 *				Validation is only done for the backend when editing an existing user
	 * 				but both creation and editing on frontend
	 * @access		public
	 * @version		3.1.07 ( $id$ )
	 * @param		array		- $vars: the variables passed to us
	 *
	 * @return		void
	 * @since		3.1.00
	 */
	public function clientDetailsValidation( $vars )
	{
		// If we are disabled don't run ;-)
		if (! ensure_active( 'user' ) ) {
			return;
		}
		
		// For frontend:  Validation occurs at registration and editing
		// For backend:   Validation only occurs at editing
		// We know only client information get validated for some reason
		$type		=	'client';
		$olduser	=	get_user_information( 'validation', $type );
		$isnew		=	( $olduser === false ? true : false );
		$changes	=	convert_user( $vars, $olduser, $isnew, 'to', 'client' );
		
		$data		=	array(
			'email'		=>	$olduser['email'],
			'oldemail'	=>	$olduser['email'],
			'isnew'		=>	$isnew,
			'update'	=>	$changes
		);
		
		if ( $isnew ) {
			unset( $data['email'] );
			unset( $data['oldemail'] );
		}
		
		$api	=	dunloader( 'api', 'integrator' );
		$result	=	$api->post_validateonupdate( $data );
		
		if (! $result ) {
			global $errormessage;
			$msg			=	$api->getError();
			$errormessage	.= '<strong>' . $msg . '</strong>';
			return $msg;
		}
		
		if ( get_filename() == 'register' ) {
			$task		=	'ClientAdd';
			$user		=	convert_user( $vars, array(), true, 'to', 'client' );
			$response	=	$api->post_user( $user );
		}
		
		return;
	}
	
	
	
	/**
	 * Method for creating a contact in Joomla
	 * @access		public
	 * @version		3.1.07 ( $id$ )
	 * @param		array		- $vars: whatever variables we are passed by WHMCS
	 *
	 * @return		void
	 * @since		3.1.00
	 */
	public function contactAdd( $vars )
	{
		// If we are disabled don't run ;-)
		if (! ensure_active( 'user' ) ) {
			return;
		}
	
		$api	=	dunloader( 'api',		'integrator' );
		$wapi	=	dunloader( 'whmcsapi',	'integrator' );
		$task	=	'ContactAdd';
	
		$user		=	convert_user( $vars, array(), true, 'to', 'contact' );
		$response	=	$api->post_user( $user );
		
		if ( $api->hasErrors() ) {
			$error	=	$wapi->log( $task, 'Create Contact on Integrator 3', $api->hasErrors() );
			global $errormessage;
			$errormessage .= '<strong>' . $error . '</strong>';
		}
		
		// Nothing else to do here...
		return;
	}
	
	
	
	/**
	 * Method to edit a contact on Joomla
	 * @access		public
	 * @version		3.1.07 ( $id$ )
	 * @param		array		- $vars: whatever variables we are sent by WHMCS
	 *
	 * @return		void
	 * @since		3.1.00
	 */
	public function contactEdit( $vars )
	{
		// If we are disabled don't run ;-)
		if (! ensure_active( 'user' ) ) {
			return;
		}
		
		$task		=	'ContactEdit';
		$api		=	dunloader( 'api',		'integrator' );
		$wapi		=	dunloader( 'whmcsapi',	'integrator' );
		$input		=	dunloader( 'input', true );
		
		if (! is_admin() ) {
			$oldcontact	=	$vars['olddata'];
			unset( $vars['olddata'] );
		}
		else {
			global $oldcontact;
		}
		
		$newcontact		=	$vars;
		$was_subaccount	=	( in_array( $oldcontact['subaccount'], array( 'on', '1' ) ) ? true : false );
		$is_subaccount	=	( in_array( $newcontact['subaccount'], array( 'on', '1' ) ) ? true : false );
		
		// Change of account status.. lets see if we must create them
		if ( $is_subaccount !== $was_subaccount && ! $api->finduser( $oldcontact['email'] ) ) {
			$user	=	convert_user( $newcontact, array(), true, 'to', 'contact' );
			$result	=	$api->post_user( $user );
			return;
		}
		
		// From here on we assume we are editing an existing user
		$user		=	convert_user( $newcontact, $oldcontact, false, 'to', 'contact' );
		
		if (! isset( $user['subaccount'] ) ) {
			$user['subaccount'] = false;
		}
		
		$user['active']	=
		$user['status']	=	( $user['subaccount'] ? '1' : '0' );
		
		// Catch email changes
		if ( $newcontact['email'] != $oldcontact['email'] ) {
			$user['newemail']	=	$newcontact['email'];
			$user['email']		=	$oldcontact['email'];
		}
		
		$data		=	array(
			'email'		=>	$user['email'],
			'isnew'		=>	false,
			'update'	=>	$user
		);
		
		$result		=	$api->put_user( $data );
		
		if ( $api->hasErrors() ) {
			$error	=	$wapi->log( $task, 'Edit User on Integrator 3', $api->hasErrors() );
		}
		
		return;
	}
	
	
	/**
	 * Method for deleting a contact on Joomla
	 * @access		public
	 * @version		3.1.07 ( $id$ )
	 * @param		array		- $vars: whatever variables we are sent by WHMCS
	 *
	 * @return		void
	 * @since		3.1.00
	 */
	public function contactDelete( $vars )
	{
		// If we are disabled don't run ;-)
		if (! ensure_active( 'user' ) ) {
			return;
		}
		
		global $oldcontact;
		
		$api	=	dunloader( 'api',		'integrator' );
		$wapi	=	dunloader( 'whmcsapi',	'integrator' );
		$task	=	'ContactDelete';
		
		$user	=	convert_user( $oldcontact, array(), true, 'to', 'contact' );
		$api->delete_user( $user );
		
		if ( $api->hasErrors() ) {
			$error	=	$wapi->log( $task, 'Delete Contact on Integrator 3', $api->hasErrors() );
		}
		
		// Nothing else to do here...
		return;
	}
	
	
	/**
	 * Initializes the module
	 * @access		public
	 * @version		3.1.07
	 *
	 * @since		3.1.00
	 */
	public function initialise() { }
	
	
	
}