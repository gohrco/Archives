<?php

$form['sslactive']	= array(
		
);

$form['tasks']	= array(
		'login' => array(
				'value'			=> true,
				'order'			=> 10,
				'nodesc'		=> true,
				'type'			=> 'toggleyn',
				'validation'	=> 'required|xss_clean'
		),
		'logout' => array(
				'value'			=> true,
				'order'			=> 20,
				'nodesc'		=> true,
				'type'			=> 'toggleyn',
				'validation'	=> 'required|xss_clean'
		),
		'register' => array(
				'value'			=> true,
				'order'			=> 30,
				'nodesc'		=> true,
				'type'			=> 'toggleyn',
				'validation'	=> 'required|xss_clean'
		),
		
		'user' => array(
				'value'			=> true,
				'order'			=> 40,
				'nodesc'		=> true,
				'type'			=> 'toggleyn',
				'validation'	=> 'required|xss_clean'
		),
		
		'render' => array(
				'value'			=> true,
				'order'			=> 50,
				'nodesc'		=> true,
				'type'			=> 'toggleyn',
				'validation'	=> 'required|xss_clean'
		),
		
		'api' => array(
				'value'			=> true,
				'order'			=> 60,
				'nodesc'		=> true,
				'type'			=> 'toggleyn',
				'validation'	=> 'required|xss_clean'
		),
);