<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class to generate a sort field
 * @version		3.0.21
 * 
 * @since		3.0.2
 * @author		Steven
 */
class SortfieldsField extends form_definition
{

	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.21
	 * @param		array		- $options: contruction options
	 * 
	 * @since		3.0.2
	 */
	public function __construct( $options = array() )
	{
		parent::__construct( $options );
	}
	
	
	/**
	 * Method to generate a form field
	 * @access		protected
	 * @version		3.0.21
	 * 
	 * @return		string
	 * @since		3.0.2
	 * @see			form_definition::field()
	 */
	protected function field()
	{
		$this->append_javascript();
		
		$name		= $this->name . ( $this->array ? '[]' : '' );
		$arguments	= $this->arguments();
		
		$items	= null;
		$list	= array( 'fullname', 'firstname', 'lastname', 'username', 'email', 'password', 'address1', 'address2', 'city', 'state', 'postal', 'country', 'phone', 'companyname' );
			
		if (! empty( $this->value ) ) {
			$list = is_string( $this->value ) ? json_decode( $this->value ) : $this->value;
		}
			
		foreach ( $list as $item ) {
			$items	.= '<li><input type="hidden" name="' . $name . '" value="' . $item .'" /><i class="icon-move"></i>' . lang( 'settings.' . $item ) . '</li>';
		}
		
		$friendly	= 'wrap' . array_pop( explode( ".", $this->lang ) );
		
		$field		=	'<ul class="unstyled" id="' . $friendly . '" style="min-height: 520px; ">'
					.	$items
					.	'</ul>';
		
		return $field;
	}
	
	
	/**
	 * Adds necessary javascript calls to the template
	 * @access		protected
	 * @version		3.0.21
	 *
	 * @since		3.0.2
	 */
	protected function append_javascript()
	{
		static $data = false;
		
		$ci		= & get_instance();
		
		if (! $data ) {
			$data	= true;
			$ci->template->append_javascript( bootstrap( 'jquery.sortable.min.js', 'js' ) );
		}
		
		$ci->template->append_javascript( $this->_build_javascript() );
	}
	
	
	/**
	 * Method to retrieve the javascript
	 * @access		private
	 * @version		3.0.21
	 * 
	 * @return		string
	 * @since		3.0.2
	 */
	private function _build_javascript()
	{
		$friendly	=	'wrap' . array_pop( explode( ".", $this->lang ) );
		$javascript	=	'<script type="text/javascript">'
					.	"jQuery(document).ready(function(){"
					.	"jQuery('#{$friendly}').sortable();"
					.	"});"
					.	'</script>';
		
		return $javascript;
		
	}
}