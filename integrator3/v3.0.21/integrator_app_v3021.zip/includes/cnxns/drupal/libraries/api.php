<?php


class Drupal_API extends API_Library
{
	protected		$apioptions	= array();
	protected		$apipost	= array();
	protected		$apiurl		= null;
	protected		$apiport	= 80;
	protected		$apisignature	= null;
	protected		$apisalt		= null;
	
	public function load( $options )
	{
		parent::load( $options );
		
		// =====================================
		// ---BEGIN: Determine SSL settings properly
// 		$usessl	=    secure_task( 'api', (bool) $this->get( "sslenabled", false, 'params' ) );
// 		if ( $usessl ) {
// 			$apioptions	= $this->get( 'apioptions' );
// 			//$apioptions['SSL_VERIFYHOST'] = true;
// 			$apioptions['SSL_VERIFYPEER'] = false;
// 			$apioptions['CAINFO']			= BASEPATH . APPPATH . 'assets' . DIRECTORY_SEPARATOR . 'cacert.pem';
// 			$this->set( 'apioptions', $apioptions );
// 		}
		// ---END: Determine SSL settings properly
		// =====================================
		// ---BEGIN: Setting API url
		$url	=	$this->get( 'apiurl', $this->get( 'baseurl', null, 'params' ), 'params' );
		$uri	= & Uri::getInstance( $url, true );
// 		$uri->setScheme( "http" . ( $usessl ? "s" : "" ) );
// 		$uri->setScheme( "http" . ( ( $this->get( "sslverify", 0, 'api' ) == 1 ) ? "s" : "" ) );
		$uri->setPath( rtrim( $uri->getPath(), "/" ) . "/xmlrpc.php" );
		$this->set( "apiurl", $uri->toString() );
		// ---END:   Setting API url
		// =====================================
		// ---BEGIN: Setting API variables
		$apipost	= $this->get( "apipost" );
			
			// Build secret code
			$params		= & Params :: getInstance();
			$salt		=   mt_rand();
			$secret		=   $params->get( 'Secret' );
			$signature	=   base64_encode( hash_hmac( 'sha256', $salt, $secret, true ) );
			
			$apipost['apiusername']		= $this->get( "username", null, 'api' );
			$apipost['apipassword']		= $this->get( "password", null, 'api' );
			$apipost['apisignature']	= $signature;
			$apipost['apisalt']			= $salt;
			
			$this->apisignature = $signature;
			$this->apisalt = $salt;
			
		$this->set( "apipost", $apipost );
		// ---END:   Setting API variables
		// =====================================
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE API FUNCTIONS AND ARE CALLED DIRECTLY
	 * **********************************************************************
	 */
	
	
	/**
	 * Called to authenticate a set of user credentials
	 * @access		public
	 * @version		3.0.21
	 * @param		array		- $post: an array of variables to post (should be empty if no child library)
	 * 
	 * @return		boolean true if authenticated, false if failed
	 * @since		3.0.6
	 */
	public function authenticate( $data = array(), $credentials = null )
	{
		$post	= array();
		
		if ( $credentials == null ) {
			$credentials = get_var( "credentials" );
		}
		
		$post['username']	= ( isset( $post['username'] ) ? $post['username'] : $credentials['username'] );
		$post['password']	= ( isset( $post['password'] ) ? $post['password'] : $credentials['password'] );
		
		$call	= $this->_call_xmlrpc( 'integrator.authenticate', 'authenticate', $post );
		
		if ( $call['result'] == 'success' ) {
			return ( $call['data'] == 1 );
		}
		return false;
	}
	
	
	/**
	 * Retrieves information about the Integrator 3 cnxn
	 * @access		public
	 * @version		3.0.21
	 *
	 * @return		array or false on error
	 * @since		3.0.6
	 */
	public function get_info()
	{
		$call	= $this->_call_xmlrpc( 'integrator.getinfo', 'get_info', array() );
		
		if ( $call['result'] == 'success' ) {
			return $call['data'];
		}
		return false;
	}
	
	
	/**
	 * Retrieves the languages on this connection
	 * @access		public
	 * @version		3.0.21
	 * 
	 * @return		array containing either the languages or empty array
	 * @since		3.0.6
	 */
	public function get_languages()
	{
		$call = $this->_call_xmlrpc( 'integrator.getlanguages', 'get_languages' );
		
		$ci				= & get_instance();
		$current_page	=   $ci->uri->segment(1, '') . '/' . $ci->uri->segment(2, 'index');
		
		if ( $current_page == 'langmap/index' ) {
			set_info_messages( sprintf( lang( 'msg.info.langmap' ), get_cnxn_name( $this->id ) ) );
		}
		
		return ( $call['result'] == 'success' ? $call['data'] : array() );
	}
	
	
	/**
	 * Retrieves missing credentials from the connection
	 * @access		public
	 * @version		3.0.21
	 * @param		string		- $credential: the item being sought
	 * 
	 * @return		string containing the found item or false on error or nothing found
	 * @since		3.0.6
	 */
	public function get_missing_credential( $credential = 'password' )
	{
		$credentials = get_var( 'credentials' );
		
		switch( $credential ) :
		
		case 'username' :
			
			$post['uservalue']	= $credentials['email'];
			
			break;
			
		case 'email' :
			
			$post['uservalue']	= $credentials['username'];
			
			break;
			
		case 'password' :
		default:
			
			// We can't get a password!
			return false;
			
			break;
			
		endswitch;
		
		$call	= $this->_call_xmlrpc( 'integrator.getmissingcredentials', 'get_missing_credential: ' .$credential, $post );
		
		if ( $call['result'] == 'success' ) {
			return $call['data'];
		}
		return false;
		
	}
	
	
	/**
	 * Retrieves the pages in this connection
	 * @access		public
	 * @version		3.0.21
	 * 
	 * @return		array containing the pages on this connection
	 * @since		3.0.6
	 */
	public function get_pages()
	{
		static $page;
		
		if (! is_array( $page ) ) {
			$page	= array();
			$return	= array();
			
			$post	= array();
			$call	= $this->_call_xmlrpc( 'integrator.getmenutree', 'get_pages' );
			
			if ( $call['result'] == 'error' ) {
				return false;
			}
			
			$data	= $call['data'];
			
			if (! is_array( $data ) ) return $page;
			
			foreach( $data as $menutype => $menuitems ) {
				
				if (! is_array( $menuitems ) ) continue;
				
				// Cycle through menu items 
				foreach( $menuitems as $menuitem ) {
					$menuitem = (object) $menuitem;
					
					if (! isset( $return['default'][$menuitem->mlid] ) ) {
						$return['default'][$menuitem->mlid] = array();
					}
					
					$return['default'][$menuitem->mlid] = array( 'value' => $menuitem->link_path, 'name' => "&nbsp;&nbsp;-&nbsp;{$menuitem->link_title}" );
					
					/*if (! isset( $return[$menutype][$menuitem->menu_item_parent] ) ) {
						$return[$menutype][$menuitem->menu_item_parent] = array();
					}
					$return[$menutype][$menuitem->menu_item_parent][] = array( 'value' => $menuitem->object_id, 'name' => $menuitem->title );
					*/
				}
				
			}
			
			foreach( $return as $items ) {
				foreach( $items as $item ) {
					$page['Integrator Links'][$item['value']] = $item['name'];
				}
			}
		}
		
		$ci				= & get_instance();
		$current_page	=   $ci->uri->segment(1, '') . '/' . $ci->uri->segment(2, 'index');
		
		if ( $current_page == 'pagemap/index' ) {
			set_info_messages( sprintf( lang( 'msg.info.pagemap' ), get_cnxn_name( $this->id ) ) );
		}
		return $page;
	}
	
	
	/**
	 * Called to test a connection to ensure it responds
	 * @access		public
	 * @version		3.0.21
	 * @param		mixed		- $check: if a string, assume its an URL, if bool true then test creds
	 * 
	 * @return		mixed depending on need boolean true if responsive
	 * @since		3.0.6
	 */
	public function ping( $check = null )
	{
		$post = array();
		if ( $check === true ) {
			$check			= $this->get( 'apiurl', null );
			$post['login']	= true;
		}
		
		$call	= $this->_call_xmlrpc( 'integrator.ping', 'ping', $post, $check );
		
		return ( $call['result'] == 'success' ? ( $call['data'] == 'Pong' ? true : $call['data'] ) : $call['data'] );
	}
	
	
	/**
	 * Create a user on this connection
	 * @access		public
	 * @version		3.0.21
	 * 
	 * @return		boolean true if successful, error message otherwise
	 * @since		3.0.6
	 */
	public function user_create()
	{
		$data			= $this->get_data();
		
		$call	= $this->_call_xmlrpc( 'integrator.usercreate', 'user_create', $data );
		
		if ( $call['result'] == 'success' ) {
			return ( $call['data'] != 0 );
		}
		return false;
	}
	
	
	/**
	 * Finds a user by username or email
	 * @access		public
	 * @version		3.0.21
	 * @param		mixed		- $post: array or string to be set
	 * @param		boolean		- $data: if we want the data back set true, else return boolean
	 * 
	 * @return		varies can be boolean or the data result
	 * @since		3.0.6
	 */
	public function user_find( $data = false )
	{
		$post	= $this->get_data();
		
		$call	= $this->_call_xmlrpc( 'integrator.userfind', 'user_find', $post );
		
		if ( ( $call['result'] == 'success' ) && ( $call['data'] != 0 ) ) {
			$this->place_data( $call['data'] );
		}
		else {
			$this->set_error( $call['data'] != '0' ? $call['data'] : 'User not found' );
		}
		
		if ( ( $call['result'] == 'success' ) && ( $call['data'] != '0' ) ) {
			return $data ? $call['data'] : true;
		}
		else {
			return $data ? $call['data'] : false;
		}
	}
	
	
	/**
	 * Searches for a user based on entry
	 * @access		public
	 * @version		3.0.21
	 * @param		array		- $post: contains search=>value
	 *
	 * @return		array
	 * @since		3.0.6
	 */
	public function user_search( $post = array() )
	{
		$call	= $this->_call_xmlrpc( 'integrator.usersearch', 'user_search', $post );
		
		if ( ( $call['result'] == 'success' ) && ( $call['data'] != 0 ) ) {
			return $call['data'];
		}
		else return array();
	}
	
	
	/**
	 * Updates user information on this connection
	 * @access		public
	 * @version		3.0.21
	 * @param		array		- $post: an array of variables to update
	 * 
	 * @return		boolean true if successful, error message otherwise
	 * @since		3.0.6
	 */
	public function user_update( $post = array() )
	{
		$data	=   $this->get_data();
		
		$call	=   $this->_call_xmlrpc( 'integrator.userupdate', 'user_update', $data );
		
		if ( $call['result'] == 'success' ) {
			return ( $call['data'] == 1 ? true : $call['data'] );
		}
		return false;
	}
	
	
	/**
	 * User removal call to the Joomla 1.6 api
	 * @access		public
	 * @version		3.0.21
	 * @param		string		- $email: contains just an email address
	 * 
	 * @return		boolean true if successful, false otherwise
	 * @since		3.0.6
	 */
	public function user_remove() 
	{
		$data	= $this->get_data();
		$call	= $this->_call_xmlrpc( 'integrator.userremove', 'user_remove', $data );
		
		return ( ( $call['result'] == 'success' && $call['data'] == '1' ) ? true : $call['data'] );
	}
	
	
	/**
	 * Validates a set of new user credentials
	 * @access		public
	 * @version		3.0.21
	 * @param		array		- $data: standard formed user data from Integrator
	 * 
	 * @return		boolean true if valid, false otherwise
	 * @since		3.0.6
	 */
	public function user_validation_on_create()
	{
		$data	= $this->get_data();
		
		$call	= $this->_call_xmlrpc( 'integrator.validateoncreate', 'user_validation_on_create', $data );
		
		if ( $call['result'] == 'success' ) {
			return ( $call['data'] == 1 ? true : $call['data'] );
		}
		return false;
		
	}
	
	
	/**
	 * Validates an updated set of user information
	 * @access		public
	 * @version		3.0.21
	 * 
	 * @return		boolean true if valid, false otherwise
	 * @since		3.0.6
	 */
	public function user_validation_on_update()
	{
		$data	=   $this->get_data();
		$call	=   $this->_call_xmlrpc( 'integrator.validateonupdate', 'user_validation_on_update', $data );
		
		if ( $call['result'] == 'success' ) {
			return ( $call['data'] == 1 ? true : $call['data'] );
		}
		return false;
	}
	
	
	/**
	 * Prepares data that is to be sent to XML-RPC handler
	 * Note:  Must remain unencoded - xml-rpc calls fail when encoded
	 * @access		public
	 * @version		3.0.21
	 * @param		mixed		- $check: the item to be prepped
	 * 
	 * @return		array containing item and found type
	 * @since		3.0.6
	 */
	public function prepare_xmlrpc_data( $check )
	{
		switch( gettype( $check ) ) :
		
		case 'float':
		case 'double':
			
			$data	= array( $check, 'double' );
			break;
			
		case 'integer':
			
			$data	= array( $check, 'int' );
			break;
			
		case 'boolean':
			
			$data	= array( $check, 'boolean' );
			break;
			
		case 'string':
			
			$data = array( $check, 'string' );
			break;
			
		case 'array':
			
			$type	= 'array';
			
			foreach( $check as $key => $value ) {
				
				if ( is_string( $key ) ) {
					$type = 'struct';
				}
				
				$check[$key] = $this->prepare_xmlrpc_data( $value );
			}
			
			$data	= array( $check, $type );
			
			break;
			
		endswitch;
		
		return $data;
	}
	
	
	/**
	 * Calls the API connection through curl
	 * @access		public
	 * @version		3.0.21
	 * @param		array		- $method: the method being called up via xml-rpc
	 * @param		string		- $action: the requested action (for logging purposes)
	 * @param		string		- $data: data array
	 * @param		array		- $url: a specific url to call (for testing)
	 * 
	 * @return		response from API or false on error
	 * @since		3.0.6
	 * @see 		Cnxns_library::_call_api()
	 */
	protected function _call_xmlrpc( $method, $action = 'unknown', $data = array(), $url = null )
	{
		$url	= ( $url != null ? rtrim( $url, '/' ) . '/xmlrpc.php' : $this->get( 'apiurl', null ) );
		
		$creds	= array( 'apiusername' => $this->get( 'username', null, 'api' ), 'apipassword' => $this->get( 'password', null, 'api' ), 'apisignature' => $this->get( 'apisignature', null ), 'apisalt' => $this->get( 'apisalt', null ) );
		$data	= array( 'credentials' => $creds, 'data' => $data );
		
		$post	= array( $this->prepare_xmlrpc_data( $data ) );
		$port	= $this->get( 'apiport', 80 );
		
		$result	= parent::_call_xmlrpc( $url, $method, $post, $port, $action );
		
		return $result;
	}
}