<?php


class Whmcs_API extends API_Library
{
	protected		$apioptions	= array();
	protected		$apipost	= array();
	protected		$apiurl		= null;
	
	protected		$clientarea	= array();
	
	public function load( $options )
	{
		parent::load( $options );
		
		// =====================================
		// ---BEGIN: Set default api options
		$apioptions	= $this->get( 'apioptions' );
			$apioptions['HEADER'] =  true;
			$apioptions['RETURNTRANSFER'] = true;
		$this->set( 'apioptions', $apioptions );
		// ---END:   Set default api options
		// =====================================
		// ---BEGIN: Determine SSL settings properly
// 		$usessl	=    secure_task( 'api', (bool) $this->get( "sslenabled", false, 'params' ) );
// 		if ( $usessl ) {
// 			$apioptions	= $this->get( 'apioptions' );
// 			//$apioptions['SSL_VERIFYHOST'] = true;
// 			$apioptions['SSL_VERIFYPEER'] = false;
// 			$apioptions['CAINFO']			= BASEPATH . APPPATH . 'assets' . DIRECTORY_SEPARATOR . 'cacert.pem';
// 			$this->set( 'apioptions', $apioptions );
// 		}
		// ---END: Determine SSL settings properly
		// =====================================
		// ---BEGIN: Setting GLOBAL API curl options
// 		$apioptions	= $this->get( 'apioptions' );
// 			if ( $this->get( 'sslverify', 0, 'api' ) == 1 ) {
// 				$apioptions['SSL_VERIFYHOST'] = true;
// 				$apioptions['SSL_VERIFYPEER'] = true;
// 			}
// 		$this->set( 'apioptions', $apioptions );
		// ---END:   Setting GLOBAL API curl options
		// =====================================
		// ---BEGIN: Setting API url
		$url 	=   $this->get( "apiurl", $this->get( 'baseurl', null, 'params' ), 'api' );
		$uri	= & Uri::getInstance( $url );
// 		$uri->setScheme( "http" . ( $usessl ? "s" : "" ) );
// 		$uri->setScheme( "http" . ( ( $this->get( "sslverify", 0, 'api' ) == 1 ) ? "s" : "" ) );
		$uri->setPath( rtrim( $uri->getPath(), "/" ) . "/includes/api.php" );
		$this->set( "apiurl", $uri->toString() );
		// ---END:   Setting API url
		// =====================================
		// ---BEGIN: Setting API curl options
		$apioptions	= $this->get( 'apioptions' );
			// Do something if needed
		$this->set( 'apioptions', $apioptions );
		// ---END:   Setting API curl options
		// =====================================
		// ---BEGIN: Setting API variables
		$apipost	= $this->get( "apipost" );
		$apipost['username']	= $this->get( "username", null, 'api' );
		$apipost['password']	= md5( $this->get( "password", null, 'api' ) );
		if ( $this->get( "accesskey", null, 'api' ) ) {
			$apipost['accesskey']	= $this->get( "accesskey", null, 'api' );
		}
		$apipost['responsetype']	= 'json';
		$apipost['IntAPI']			= true;
		$this->set( "apipost", $apipost );
		// ---END:   Setting API variables
		// =====================================
		
		$ca	= array(	'invoicesdisplay'	=> isset( $options['params']['clientarea']['invoicesdisplay']['value'] ) ? $options['params']['clientarea']['invoicesdisplay']['value'] : false,
						'invoicesnewwin'	=> isset( $options['params']['clientarea']['invoicesnewwin']['value'] ) ? $options['params']['clientarea']['invoicesnewwin']['value'] : false,
						'ticketsdisplay'	=> isset( $options['params']['clientarea']['ticketsdisplay']['value'] ) ? $options['params']['clientarea']['ticketsdisplay']['value'] : false,
						'ticketsnewwin'		=> isset( $options['params']['clientarea']['ticketsnewwin']['value'] ) ? $options['params']['clientarea']['ticketsnewwin']['value'] : false,
		);
		
		$this->set( 'clientarea', $ca );
		
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE API FUNCTIONS AND ARE CALLED DIRECTLY
	 * **********************************************************************
	 */

	

	/**
	 * Called to authenticate a set of user credentials
	 * @access		public
	 * @version		3.0.21
	 * @param		array		- $post: an array of variables to post (should be empty if no child library)
	 * 
	 * @return		boolean true if authenticated, false if failed
	 * @since		3.0.0
	 */
	public function authenticate( $post = array() )
	{
		$credentials	= get_var( "credentials" );
		
		$post['action']		= "validatelogin";
		$post['email']		= ( isset( $post['email'] ) ? $post['email'] : $credentials['email'] );
		$post['password2']	= ( isset( $post['password2'] ) ? $post['password2'] : ( isset( $post['password'] ) ? $post['password'] : $credentials['password'] ) );
		
		// Kill the username / password in case we are setting it
		unset(
				$post['username'],
				$post['password']
		);
		
		$call	= $this->_call_api( $post, 'authenticate' );
		
		if ( $call['result'] == 'success' ) {
			return true;
		}
		else {
			// Log error message ?
			return false;
		}
	}
	
	
	/**
	 * Retrieves information about the Integrator 3 cnxn
	 * @access		public
	 * @version		3.0.21
	 * 
	 * @return		array or false on error
	 * @since		3.0.1 (0.1)
	 */
	public function get_info()
	{
		$post	= array(	'action'	=> 'integrator',
							'task'		=> 'get_version'
		);
		
		$call	= $this->_call_api( $post, 'get_info' );
		
		if ( $call['result'] == 'success' ) {
			unset ( $call['result'] );
			return $call;
		}
		else {
			// Log error message ?
			return false;
		}
	}
	
	
	/**
	 * Retrieves the languages on this connection
	 * @access		public
	 * @version		3.0.21
	 * 
	 * @return		array containing either the languages or empty array
	 * @since		3.0.0
	 */
	public function get_languages()
	{
		$post	= array(	'action'	=> "integrator",
							'task'		=> "get_languages"
		);
		
		$call	= $this->_call_api( $post, 'get_languages' );
		
		if ( $call['result'] == 'success' ) {
			unset ( $call['result'] );
			return $call;
		}
		else {
			// Log error message ?
			return false;
		}
	}
	
	
	/**
	 * Retrieves missing credentials from the connection
	 * @access		public
	 * @version		3.0.21
	 * @param		string		- $credential: the item being sought
	 * 
	 * @return		string containing the found item or false on error or nothing found
	 * @since		3.0.0
	 */
	public function get_missing_credential( $credential = 'password' )
	{
		$missing_item = false;
		switch( $credential ):
		case 'password':
		default:
			// We can't get a password from WHMCS
			$missing_item = false;
			break;
		endswitch;
		return $missing_item;
	}
	
	
	/**
	 * Retrieves the pages in this connection
	 * @access		public
	 * @version		3.0.21
	 * 
	 * @return		array containing the pages on this connection
	 * @since		3.0.0
	 */
	public function get_pages()
	{
		$post	= array(	'action'	=> "integrator",
							'task'		=> "get_pages"
		);
		
		$call	= $this->_call_api( $post, 'get_pages' );
		
		if ( $call['result'] == 'success' ) {
			unset ( $call['result'] );
			return $call;
		}
		else {
			// Log error message ?
			return false;
		}
	}
	
	
	/**
	 * Gathers the information for the client area page
	 * @access		public
	 * @version		3.0.21
	 * 
	 * @return		array
	 * @since		3.0.2
	 */
	public function get_secondary_info()
	{
		// Email needs to already be set - if user isn't there then return now
		if ( $this->user_find() !== true ) return false;
		
		$data		=   array();
		$items		=   array();
		$user		=   $this->get_data();
		$clientid	=   $user['id'];
		$siteurl	=   Uri :: getInstance( $this->get( 'baseurl', null, 'params' ), true );
		$sitepath	=   $siteurl->getPath();
		$settings	=   $this->get( 'clientarea' );
		
		if ( $settings['invoicesdisplay'] ) {
			
			$post	= array(	'action'	=> "getinvoices",
								'userid'	=> "{$clientid}"
			);
			
			// Retrieve from WHMCS
			$call	= $this->_call_api( $post, 'get_secondary_info: getinvoices' );
			
			if ( $call['result'] != 'success' ) return false;
			
			// If we received no invoices, set to an array
			$invoices	=   ( empty( $call['invoices'] ) ? array() : $call['invoices']['invoice'] );
			$cnt		=   0; // Count for badge
			$class		=   array( 'class' => 'btn btn-info btn-mini', 'target' => null, 'style' => 'min-width: 70px; ' );
			
			if ( $settings['invoicesnewwin'] ) $class['target'] = 'blank';
			
			$siteurl->setPath( rtrim( $sitepath, '/' ) . '/viewinvoice.php' );
			
			foreach ( $invoices as $inv ) {
				if ( $inv['status'] == 'Paid' ) continue;
				$cnt++;
				$siteurl->setVar( 'id', $inv['id'] );
				$items[]	= array( $inv['id'], $inv['date'], $inv['duedate'], $inv['currencyprefix'] . $inv['total'] . ' ' . $inv['currencysuffix'], $inv['status'], anchor( $siteurl->toString(), lang( 'whmcs_api.invoices.column.viewinv' ), $class ) );
			}
			
			$siteurl->delVar( 'id' );
			$siteurl->setPath( rtrim( $sitepath, '/' ) . '/clientarea.php' );
			$siteurl->setVar( 'action', 'invoices' );
			
			$data[]		=   array(
								'header'		=> lang( 'whmcs_api.invoices.header') . ' <span class="badge badge-' . ( $cnt != 0 ? 'important' : 'info' ) . '">'.$cnt.'</span>',
								'headerlink'	=> anchor( $siteurl->toString(), lang( 'whmcs_api.invoices.headerlink' ), array( 'class' => 'btn btn-inverse' ) ),
								'columns'		=> array(
													lang( 'whmcs_api.invoices.column.invnum' ),
													lang( 'whmcs_api.invoices.column.invdate' ),
													lang( 'whmcs_api.invoices.column.duedate' ),
													lang( 'whmcs_api.invoices.column.total' ),
													lang( 'whmcs_api.invoices.column.status' ),
													''
													),
								'data'			=> $items
					
			);
		}
		
		if (! $settings['ticketsdisplay'] ) return $data;
		
		// Support Departments Retrieval
		$post	= array(	'action'	=> 'getsupportdepartments',
							'ignore_dept_assignments'	=> true );
		
		$call	= $this->_call_api( $post, 'get_secondary_info: getsupportdepartments' );
		$depts	= array();
		$items	= array();
		
		if ( $call['result'] != 'success' ) return $data;
		if ( $call['totalresults'] == '0' ) return $data;
		
		foreach ( $call['departments']['department'] as $dept ) {
			$depts[$dept['id']] = $dept['name'];
		}
		
		// Support Ticket Retrieval
		$post	= array(	'action'	=> "gettickets",
							'clientid'	=> "{$clientid}"
				);
		
		// Retrieve from WHMCS
		$call	= $this->_call_api( $post, 'get_secondary_info: gettickets' );
		
		// If we received no tickets, set to an array
		$tickets	=   ( empty( $call['tickets'] ) ? array() : $call['tickets']['ticket'] );
		$cnt		=   0; // Count of tickets to badge
		$class		=   array( 'class' => 'btn btn-info btn-mini', 'target' => null, 'style' => 'min-width: 70px; ' );
			
		if ( $settings['ticketsnewwin'] ) $class['target'] = 'blank';
		
		$siteurl->delVar( 'action' );
		$siteurl->setPath( rtrim( $sitepath, '/' ) . '/viewticket.php' );
		
		foreach ( $tickets as $tkt ) {
			if ( $tkt['status'] == 'Closed' ) continue;
			$cnt++;
			$siteurl->setVar( 'tid', $tkt['tid'] );
			$siteurl->setVar( 'c', $tkt['c'] );
			$items[]	= array( $tkt['date'], $depts[$tkt['deptid']], $tkt['subject'], $tkt['status'], $tkt['lastreply'], anchor( $siteurl->toString(), lang( 'whmcs_api.tickets.column.viewtkt' ), $class ) );
		}
		
		$siteurl->delVar( 'tid' );
		$siteurl->delVar( 'c' );
		
		$siteurl->setPath( rtrim( $sitepath, '/' ) . '/supporttickets.php' );
		
		$data[]		=   array(
				'header'		=> lang( 'whmcs_api.tickets.header') . ' <span class="badge badge-' . ( $cnt != 0 ? 'important' : 'info' ) . '">'.$cnt.'</span>',
				'headerlink'	=> anchor( $siteurl->toString(), lang( 'whmcs_api.tickets.headerlink' ), array( 'class' => 'btn btn-inverse' ) ),
				'columns'		=> array(
						lang( 'whmcs_api.tickets.column.tktdate' ),
						lang( 'whmcs_api.tickets.column.dept' ),
						lang( 'whmcs_api.tickets.column.subject' ),
						lang( 'whmcs_api.tickets.column.status' ),
						lang( 'whmcs_api.tickets.column.updated' ),
						''
				),
				'data'			=> $items
		
		);
		return $data;
	}
	
	
	/**
	 * Called to test a connection to ensure it responds
	 * @access		public
	 * @version		3.0.21
	 * @param		mixed		- $check: if a string, assume its an URL, if array test credentials
	 * 
	 * @return		mixed depending on need boolean true if responsive
	 * @since		3.0.0
	 */
	public function ping( $check = null )
	{
		if ( is_string( $check ) ) {
			$post	= array( 'task' => 'ping', 'action' => 'integrator' );
			$purl	= $check;
			$optns	= array( 'RETURNTRANSFER' => false, 'FAILONERROR' => false );
		}
		else {
			$post	= array( 'task' => 'ping', 'action' => 'integrator' );
			$purl	= null;
			$optns	= array( 'RETURNTRANSFER' => true );
		}
		
		$call = $this->_call_api( $post, 'ping', $purl, $optns );
		
		if ( is_string( $check ) ) {
			return (bool) $call;
		}
		
		return $this->_call_api( $post, 'ping', $purl, $optns );
	}
	
	
	/**
	 * Updates a setting on the cnxn
	 * @access		public
	 * @version		3.0.21
	 * @param		array		- $post: contains the settings array to update
	 *
	 * @return		true on success; false on error
	 * @since		3.0.0 (0.3)
	 */
	public function update_settings( $post = array() )
	{
		// Catch empties
		if ( ( $data = $this->_filter_setting_array( $post ) ) === false ) return true;
		
		// Assign task
		$send	= array(
					'settings'	=> $data,
					'action'	=> 'integrator',
					'task'		=> 'update_settings'
		);
		
		// Make the call
		$call	= $this->_call_api( $send, 'update_settings' );
		
		// Return result
		return $call['result'] == 'success';
	}
	
	
	/**
	 * Creates a new user in WHMCS
	 * @access		public
	 * @version		3.0.21
	 * @param		array		- $post: variables to post to the API
	 * 
	 * @return		true on success, false otherwise
	 * @since		3.0.0
	 */
	public function user_create()
	{
		$data	= $this->get_data();
		
		foreach( array( 'address1', 'city', 'country', 'phonenumber', 'postcode', 'state' ) as $item ) {
			$default = 'default' . $item;
			if (! isset( $data[$item] ) ) $data[$item] = null;
			if (! empty( $data[$item] ) ) continue;
			$data[$item] = $this->get_param( $default );
		}
		
		unset( $data['update'], $data['active'] );
		
		$noemail				= $this->get_param( 'sendemail', 'users' ) == '0';
		$data['noemail']		= $noemail;
		
		// We are hard coding this for now
		$data['skipvalidation']	= true;
		
		$data['action'] = 'addclient';
		$call = $this->_call_api( $data, 'user_create' );
		
		return ( $call['result'] == 'success' ? true : $call['message'] );
	}
	
	
	/**
	 * Finds a user by email
	 * @access		public
	 * @version		3.0.21
	 * @param		boolean		- $data: if we want the data back set true, else return boolean
	 * 
	 * @return		varies can be boolean or the data result
	 * @since		3.0.0
	 */
	public function user_find( $data = false )
	{
		$post	= $this->get_data();
		
		// Intercept no email address
		if (! isset( $post['email'] ) ) {
			$this->set_error( 'This connection does not support usernames' );
			return false;
		}
		
		unset( $post['status'] );
		$post['action']	= 'getclientsdetails';
		$call = $this->_call_api( $post, 'user_find' );
		
		if ( $call['result'] == 'success' ) {
			unset( $call['password'] );
			$this->place_data( $call );
		}
		else {
			
			$origmsg = $call['message'];
			
			// Try to grab a contact...
			$post['action'] = 'getcontacts';
			$cd		= $call;
			$call = $this->_call_api( $post, 'user_find: getcontacts' );
			
			if ( ( $call['result'] == 'success' ) && ( isset( $call['contacts'] ) )  ) {
				$calldata	= $call['contacts']['contact'];
				if ( count( $calldata ) > 1 ) {
					$this->set_error( $origmsg );
				}
				else {
					unset( $calldata[0]['password'] );
					$this->place_data( $calldata[0] );
				}
			}
			else {
				$call = $cd;
				$this->set_error( $origmsg );
			}
			
		}
		
		return ( $call['result'] == 'success' ? ( $data ? $call : true ) : $call['message'] );
	}
	
	
	/**
	 * Checkes a password against the connection for validation purposes
	 * @access		public
	 * @version		3.0.21
	 * @param		boolean		- $data: indicates we want the dataset back
	 *
	 * @return		boolean
	 * @since		3.0.2
	 */
	public function user_password_check( $data = false )
	{
		// If we ignore the pw strength when coming from the API then return
		if (! $this->get_param( 'testpwstrength', 'users' ) ) return true;
		
		$post				= $this->get_data();
		$post['action']		= "integrator";
		$post['task']		= "validate_password";
		
		$call	= $this->_call_api( $post, 'user_password_check' );
		
		return ( $call['result'] == 'success' ? ( $data ? $call : true ) : $call['message'] );
	}
	
	
	/**
	 * Searches for a user based on entry
	 * @access		public
	 * @version		3.0.21
	 * @param		array		- $post: contains search=>value
	 *
	 * @return		array
	 * @since		3.0.1 (0.2)
	 */
	public function user_search( $post = array() )
	{
		$post['action']			=	'getclients';
		$post['limitnumber']	=	'100';	// I don't know if this is right for v5.1 or below
		$post['limitnum']		=	'100';	// This is correct as of v5.2
		$post['action']			=	'integrator';
		$post['task']			=	'user_search';
		
		$call = $this->_call_api( $post, 'user_search' );
		
		if ( $call['result'] != 'success' ) return array();
		
		if (! isset( $call['clients']['client'] ) ) return array();
		
		// We are going to cycle through and grab each of the clients found
		foreach ( $call['clients']['client'] as $id => $client ) {
			$this->place_data( $client );
			$this->user_find();
			$call['clients']['client'][$id] = $this->get_data();
		}
		
		return $call['clients']['client'];
		
	}
	
	
	/**
	 * Updates user information on this connection
	 * @access		public
	 * @version		3.0.21
	 * @param		array		- $post: an array of variables to update
	 * 
	 * @return		boolean true if successful, error message otherwise
	 * @since		3.0.0
	 */
	public function user_update()
	{
		$data	=   $this->get_data();
		
		if (! isset( $data['update'] ) ) return false;
		$update	=   $data['update'];
		
		// If we don't have the client ID in the update array, we must get it
		if ( empty( $update['clientid'] ) ) {
			$post = array( 'action' => 'getclientsdetails', 'email' => $data['email'] );
			$call = $this->_call_api( $post, 'user_update' );
			
			if ( ( $call['result'] == 'success' ) && isset( $call['userid'] ) ) {
				$update['clientid']	= $call['userid'];
				$update['action']	= 'updateclient';
				unset( $update['id'] );
			}
			else {
				
				$origmsg = $call['message'];
				
				// Try to grab a contact...
				$post['action'] = 'getcontacts';
				$call = $this->_call_api( $post, 'user_update: getcontacts' );
				
				if ( ( $call['result'] == 'success' ) && ( isset( $call['contacts'] ) ) ) {
					
					$calldata	= $call['contacts']['contact'];
					if ( count( $calldata ) > 1 ) {
						$this->set_error( $origmsg );
					}
					else {
						$update['action'] = 'updatecontact';
						$update['contactid']	= $calldata[0]['id'];
						if ( isset( $update['active'] ) ) {
							$update['subaccount'] = $update['active'];
							unset( $update['active'] );
						}
						unset( $calldata[0]['password'] );
						$this->place_data( $calldata[0] );
					}
				}
				else {
					$this->set_error( $origmsg );
				}
			}
		}
		
		$call = $this->_call_api( $update, 'user_update: updatecontact' );
		
		return ( $call['result'] == 'success' ? true : $call['message'] );
	}
	
	
	/**
	 * User removal call to this connection
	 * @access		public
	 * @version		3.0.21
	 * @param		string		- $email: contains just an email address
	 * 
	 * @return		boolean true if successful, false otherwise
	 * @since		3.0.0
	 */
	public function user_remove()
	{
		$data = $this->get_data();
		
		$post = array( 'action' => 'getclientsdetails', 'email' => $data['email'] );
		$call = $this->_call_api( $post, 'user_remove: getclientsdetails' );
		
		// Try close client
		if ( $call['result'] == 'success' ) {
			$post = array( 'action' => 'closeclient', 'clientid' => $call['userid'] );
			$call = $this->_call_api( $post, 'user_remove: closeclient' );
			
			return ( $call['result'] == 'success' ) ? true : $call['message'];
		}
		
		$origmsg = $call['message'];
		
		// Try to grab a contact...
		$post['action'] = 'getcontacts';
		$call = $this->_call_api( $post, 'user_remove: getcontacts' );
		
		if ( ( $call['result'] == 'success' ) && ( isset( $call['contacts'] ) ) ) {
			
			$calldata	= $call['contacts']['contact'];
			if ( count( $calldata ) > 1 ) {
				$this->set_error( $origmsg );
				return $origmsg;
			}
			else {
				$update['action']		= 'updatecontact';
				$update['contactid']	= $calldata[0]['id'];
				$update['subaccount']	= '0';
				
				$call = $this->_call_api( $update, 'user_remove: updatecontact' );
			}
		}
		
		return ( $call['result'] == 'success' ? true : $origmsg );
	}
	

	/**
	 * Validates a set of new user credentials
	 * @access		public
	 * @version		3.0.21
	 * @param		array		- $nopasswordcheck: over ride the password check
	 * 
	 * @return		boolean true if valid, false otherwise
	 * @since		3.0.0
	 */
	public function user_validation_on_create( $nopasswordcheck = false )
	{
		$data			= $this->get_data();
		
		if (! empty( $data['email'] ) ) {
			$post = array( 'action' => 'getclientsdetails', 'email' => $data['email'] );
			$call = $this->_call_api( $post, 'user_validation_on_create' );
			
			if ( $call['result'] == 'success' ) return sprintf( 'Client already exists with email address `%s`', $data['email'] );
		}
		
		// If we ignore the pw strength when coming from the API then return
		if ( (! $this->get_param( 'testpwstrength', 'users' ) ) || $nopasswordcheck ) return true;
		
		$data['action']		= "integrator";
		$data['task']		= "validate_password";
		
		$call	= $this->_call_api( $data, 'user_validation_on_create: validate_password' );
		
		return ( $call['result'] == 'success' ) ? true: $call['data'] ;
	}
	
	
	/**
	 * Validates an updated set of user information
	 * @access		public
	 * @version		3.0.21
	 * @param		array		- $data: standard formed user data from Integrator
	 * 
	 * @return		boolean true if valid, false otherwise
	 * @since		3.0.0
	 */
	public function user_validation_on_update()
	{
		$data	=   $this->get_data();
		
		if (! isset( $data['update'] ) ) return true;
		
		$update	=   $data['update'];
		
		// Check for old / new email match
		if (! empty( $data['email'] ) && ! empty( $update['email'] ) ) {
			if ( $data['email'] != $update['email'] ) {
				$post = array( 'action' => 'getclientsdetails', 'email' => $update['email'] );
				$call = $this->_call_api( $post, 'user_validation_on_update' );
				
				if ( $call['result'] == 'success' ) return sprintf( 'Client exists with email address `%s`', $update['email'] );
			}
		}
		
		// If we ignore the pw strength when coming from the API then return
		if (! $this->get_param( 'testpwstrength', 'users' ) ) return true;
		
		// Password check
		if (! empty( $update['password2'] ) ) {
			$post = array( 'action' => 'integrator', 'task' => 'validate_password', 'password2' => $update['password2'] );
			$call = $this->_call_api( $post, 'user_validation_on_update: validate_password' );
			
			if ( $call['result'] != 'success' ) return $call['data'];
		}
		
		return true;
	}
	
	
	/**
	 * Calls the API connection through curl
	 * @access		public
	 * @version		3.0.21
	 * @param		array		- $api_post: an array of items to post to the API
	 * @param		string		- $action: the requested action (for logging purposes)
	 * @param		string		- $api_url: the API url
	 * @param		array		- $api_options: any additional API CURLSETOPT to set
	 * 
	 * @return		response from API or false on error
	 * @since		3.0.0
	 * @see 		Cnxns_library::_call_api()
	 */
	protected function _call_api( $api_post = array(), $action = 'unknown', $api_url = null, $api_options = array() )
	{
		if ( empty( $api_post ) ) return false;
		
		// Handle URL
		$api_url		= ( $api_url == null ? $this->get( 'apiurl' ) : $api_url );
		
		// Handle Options
		$api_options	= array_merge( $this->get( 'apioptions' ), $api_options );
		
		// Handle Post
		$api_post		= array_merge( $this->get( "apipost" ), $api_post );
// 		_e( $api_post,1);
		$result			= parent::_call_api( $api_post, $api_url, $api_options, $action );
		
		// ---BEGIN INT-2
		// WHMCS passes multibyte data back to us encoded funny
		$result			= preg_replace('/\\\u([0-9a-z]{4})/', '&#x$1;', $result);
		// ---END INT-2
		
		if ( ( $response = json_decode( $result, TRUE ) ) == NULL ) {
			$CI = & get_instance();
			if ( $CI->debug_on() ) {
				echo $CI->curl->debug( "API Call from Joomla16 Library" );
			}
			return false;
		}
		else return $response;
	}
}