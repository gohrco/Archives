<?php defined('BASEPATH') OR exit('No direct script access allowed');

include_once( 'render.php' );
include_once( 'api.php' );

/**
 * Joomla Connections Library extended class
 * @version		3.0.21
 * 
 * @since		3.0.0
 * @author Steven
 */
class Joomla extends Cnxns_library
{
	protected	$apiparams		= array();		// The parameters to post / put for API connections
	protected	$isvisual		= true;
	protected	$renderparams	= array();		// The parameters to post / put for Rendering the site back to user
	protected 	$type			= "joomla";	// The type reference for this object
	//protected	$uri			= null;			// The global URI object for use
	protected 	$version		= "3.0.21";	// The version of this object in use
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.21
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		$this->_ci = & get_instance();
	}
	
	
	/**
	 * Bind the parameters to connection
	 * @access		public
	 * @version		3.0.21
	 * @param		varies		- $params: if empty, does nothing, if integer, loads from DB, else a json_encoded string
	 * 
	 * @since		3.0.0
	 * @see 		Cnxns::bind()
	 */
	public function bind( $params = null )
	{
		parent::bind( $params );
	}
	
	
	/**
	 * Verifies settings for the connection
	 * @access		public
	 * @version		3.0.21
	 * 
	 * @return		boolean true on success
	 * @since		3.0.0
	 * @see Cnxns_library::update_settings()
	 */
	public function verify_settings()
	{
		$api	= & get_api( $this->cnxn_id );
		$CI		= & get_instance();
		$prev	=   ( ( $prev = $CI->session->flashdata( 'info_message' ) ) ? $prev : null );
		
		// =================================================
		// ---BEGIN: Verify settings updated in parent first
		// -------------------------------------------------
		if (! ( $model = parent::verify_settings() ) ) {
			error_message( 'msg.error.noconnection' );
			return false;
		}
		// ---END:   Verify settings updated in parent first
		// =================================================
		// ---BEGIN: Test the Base Connection URL
		// -------------------------------------------------
		$baseuri	= new Uri( $model->get( 'url', null, 'globals' ) );
		$baseuri->setPath( rtrim( $baseuri->getPath(), '/' ). '/' );
		
		if (! ( $result = $api->ping( $baseuri->toString() ) ) ) {
			$model->set( 'active', false );
			$model->save();
			error_message( 'msg.error.cnxnping' );
			return true;
		}
		else {
			$model->set( 'url', $baseuri->toString(), 'globals' );
			$model->save();
		}
		// ---END:   Test the Base Connection URL
		// =================================================
		// ---BEGIN: Test the Image URL
		// -------------------------------------------------
		if (! $model->get( 'imgurl', false, 'visuals' ) ) {
			$model->set( 'imgurl', $model->get( 'url', null, 'globals' ), 'visuals' );
			$model->save();
			info_message( 'msg.info.imgurlunset' );
			return false;
		}
		// ---END:   Test the Image URL
		// =================================================
		// ---BEGIN: Test API URL for active connection
		// -------------------------------------------------
		if (! ( $active = $api->ping() ) ) {
			if ( ( $sslset = $model->get( 'sslverify', false, 'api' ) ) AND ( $CI->curl->error_code == 60 ) ) {
				$model->set( 'sslverify', 0, 'api' );
				$model->save();
				info_message( 'msg.info.nosslverify' );
				return false;
			}
			elseif ( $CI->curl->error_code == 200 ) {
				// Test the final URL for the API against what we entered to ensure no redirects are taking place
				$muri = new Uri( $api->get( 'apiurl' ) );
				$murl = rtrim( $muri->toString( array( 'scheme', 'host', 'path' ) ), '/' );
				$curi = new Uri( $CI->curl->info['url'] );
				$curl = rtrim( $curi->toString( array( 'scheme', 'host', 'path' ) ), '/' );
				
				if ( $murl != $curl ) {
					$model->set( 'apiurl', $curl, 'api' );
					$model->save();
					info_message( 'msg.info.apiurlcorrected' );
					return false;
				}
			}
			else {
				if ( $prev != null ) $CI->session->set_flashdata( 'info_message', $prev );
				error_message( 'msg.error.cnxndeactivated', $model->get( "name" ) );
				error_message( 'msg.error.msgreturned', 'API URL Test', $model->get( 'name' ), $CI->curl->has_errors() );
				$model->set( 'active', 0 );
				$model->save();
				return true;
			}
		}
		// ---END:   Test API URL for active connection
		// =================================================
		// ---BEGIN: Test API Credentials
		// -------------------------------------------------
		$result	= $api->ping( array() );
		
		if ( $result != 'Pong' ) {
			error_message( 'msg.error.cnxndeactivated', $model->get( "name" ) );
			error_message( 'msg.error.msgreturned', 'API Credential Test', $model->get( 'name' ), $result );
			$model->set( 'active', 0 );
			$model->save();
			return true;
		}
		// ---END:   Test API Credentials
		// =================================================
		
		return true;
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE RELATED TO TRANSLATING BETWEEN CUSER AND THIS CNXN
	 * **********************************************************************
	 */
	
	
	
	
	
	/**
	 * Creates an array of fields to filter cuser object for this object
	 * @access		public
	 * @version		3.0.21
	 * @param		array		- $full_form: the full form from the cuser object
	 * @param		boolean		- $is_new: if this is a new user form
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function cuser_fields( $full_form, $is_new = false )
	{
		$data		= array();
		$use_fields	= array( 'fullname' => array( 'req' => true ), 'username' => array( 'req' => true ), 'email' => array( 'req' => true ), 'password' => array( 'req' => $is_new ) );
		
		foreach( $use_fields as $name => $optns ) {
			$data[$name] = $full_form[$name];
			
			if ( $optns['req'] ) {
				$data[$name]['validation'] = 'required|' . $full_form[$name]['validation'];
			}
		}
		
		return $data;
	}
	
	/**
	 * Processes an array of data and inserts into the common user object
	 * @access		public
	 * @version		3.0.21
	 * @param		array		- $juser: array of data from this connection type
	 * 
	 * @since		3.0.0
	 */
	public function cuser_place( $juser )
	{
		$cuser	= & Cuser::getInstance( true );
		$data	=   array();
		$trans	=   $this->cuser_table( true );
		
		foreach ( $juser as $k => $v ) {
			
			if ( $k == 'block' ) {
				$v = ( $v == '0' ? true : false );
			}
			
			if ( $k == 'name' ) {
				$name = explode( " ", $v );
				$data['firstname']	= array_shift( $name );
				$data['lastname']	= implode( ' ', $name );
			}
			
			if ( isset( $trans[$k] ) ) {
				$data[$trans[$k]] = $v;
				continue;
			}
			
			if ( $k == 'update' ) {
				
				foreach( $v as $k2 => $v2 ) {
					if ( $k2 == 'block' ) {
						$v2 = ( $v2 == '0' ? true : false );
					}
					
					if ( $k2 == 'name' ) {
						$name = explode( " ", $v2 );
						$data['update']['firstname']	= array_shift( $name );
						$data['update']['lastname']		= implode( ' ', $name );
					}
					
					if ( isset( $trans[$k2] ) ) {
						$data['update'][$trans[$k2]] = $v2;
					}
				}
			}
		}
		
		// Set the data
		$cuser->set_properties( $data );
		
		// If we are coming from the API interface, we must establish username and fullname for cnxns requiring such
		if ( defined( 'INTEGRATOR_API' ) && ( get_var( '_c' ) == $this->get( 'cnxn_id' ) ) ) {
			$cuser->complete( $this->get( 'cnxn_id' ) );
		}
		
		return;
	}
	
	
	/**
	 * Extracts user data from the common user object for use on this connection type
	 * @access		public
	 * @version		3.0.21
	 * 
	 * @return		array of user data
	 * @since		3.0.0
	 */
	public function cuser_retrieve()
	{
		$cuser	= & Cuser::getInstance();
		$data	=   array();
		$cdata	=   $cuser->get_properties();
		$trans	=   $this->cuser_table();
		
		foreach ( $cdata as $k => $c ) {
			if ( $k == 'active' ) $c = ( $c == '0' ? '1' : '0' );
			if ( is_null( $c ) ) continue;
			
			if ( isset( $trans[$k] ) ) {
				$data[$trans[$k]] = $c;
			}
			
			if ( ( $k == 'password' ) && isset( $trans[$k] ) ) {
				$data['password2'] = $c;
			}
			
			if ( $k == 'update' ) {
				
				foreach( $c as $k2 => $c2 ) {
					if ( $k2 == 'active' ) $c2 = ( $c2 == '0' ? '1' : '0' );
					if ( is_null( $c2 ) ) continue;
					
					if ( isset( $trans[$k2] ) ) {
						$data['update'][$trans[$k2]] = $c2;
					}
					
					if ( ( $k2 == 'password' ) && isset( $trans[$k2] ) ) {
						$data['update']['password2'] = $c2;
					}
				}
			}
		}
		
		return $data;
	}
	
	
	/**
	 * Translation table from WP to cuser object
	 * @access		public
	 * @version		3.0.21
	 * @param		boolean		- $from: if coming from cuser then true
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function cuser_table( $from = false )
	{
		$data	= array();
		
		$data['name']			= 'fullname';
		$data['username']		= 'username';
		$data['email']			= 'email';
		$data['password']		= 'password';
		$data['block']			= 'active';
		
		return ( $from ? $data : array_flip( $data ) );
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE RELATED TO THE USER INTEGRATION OF THE CONNECTION
	 * **********************************************************************
	 */
	
	
	public function build_user_array( $data )
	{
		if ( isset( $data['firstname'] ) && isset( $data['lastname'] ) ) {
			$data['name'] = $data['firstname'] . " " . $data['lastname'];
			unset( $data['firstname'], $data['lastname'] );
		}
		
		return $data;
	}
	
	
	/**
	 * Decodes the return url
	 * @access		public
	 * @version		3.0.21
	 * @param		base64 string	- $return: base64 encoded string
	 * 
	 * @return		string containing URL
	 * @since		3.0.0
	 */
	public function decode_return_url( $return )
	{
		return base64_decode( $return );
	}
	
	
	/**
	 * Returns the correct URL for the forgot password link
	 * @access		public
	 * @version		3.0.21
	 *
	 * @return		string
	 * @since		3.0.2
	 * @see			Cnxns_library::get_forgot_password_url()
	 */
	public function get_forgot_password_url()
	{
		$cnxn_model	=   cnxn( $this->get( 'cnxn_id' ) );
		$base_url	=   $cnxn_model->get( 'baseurl' );
		$redirect	=   rtrim( $base_url, '/' ) . '/index.php?option=com_integrator&view=pwreset';
		return $redirect;
	}
	
	
	/**
	 * Builds the login error page with error message
	 * @access		public
	 * @version		3.0.21
	 * @param		string		- $error: contains the error message to send along
	 * 
	 * @return		string containing URL of login error landing page
	 * @since		3.0.0
	 */
	public function get_login_error_url( $error = null )
	{
		$cnxn	= cnxn( $this->get( 'cnxn_id' ) );
		$erruri	= new Uri( $cnxn->get( 'loginlandingerrorurl' ) );
		if ( $error ) $erruri->setVar( 'errmsg', $error );
		return $erruri->toString();
	}
	
	
	/**
	 * Gets an item for the update process
	 * @access		public
	 * @version		3.0.21
	 * @param		string		- $item: href|modal|action|url...
	 *
	 * @return		varies
	 * @since		3.0.8
	 * @see			Cnxn_Library :: get_update()
	 */
	public function get_update( $item = null )
	{
		switch ( $item ) {
			// For the link in help/systemstatus/updates we want to popup a modal
			case 'href' :
				return $this->get_update( 'modal' );
				break;
			case 'modalbuttons' :
				return array(
					(object) array( 'uri' => $this->get_update( 'uri' ), 'title' => lang( 'dialog.joomla.button.redirect' ), 'id' => 'confirmModal', 'class' => 'btn btn-primary', 'btntype' => 'anchor', 'target' => '_blank' ),
					(object) array( 'content' => lang( 'cancel' ), 'name' => 'cancel', 'id' => 'cancelModal', 'value' => true, 'class' => 'btn', 'data-dismiss' => 'modal', 'btntype' => 'button' )
				);
				break;
			case 'uri' :
				$model = cnxn ( $this->cnxn_id );
				$url	= $model->get( 'url', null, 'globals' );
				$uri	= new Uri( $url );
				$uri->setPath( rtrim( $uri->getPath(), '/' ) . '/administrator' );
				return $uri->toString();
				break;
			default:
				return parent :: get_update( $item );
		}
	}
	
	
	/**
	 * Takes care of storing session cookies
	 * @access		public
	 * @version		3.0.21
	 * @param		string	- $sid: contains the session id base 64 encoded
	 * @param		string	- $sname: contains the session name base 64 encoded
	 * 
	 * @since		3.0.0
	 */
	public function handle_session_cookies( $sid, $sname )
	{
		if ( ( $sid == NULL ) OR ( $sname == NULL ) ) return false;
		
		$cookie		= $sname . "=" . $sid;
		
		save_session_id( $sid, $this->cnxn_id );
		parent::handle_session_cookies( $cookie );
	}
	
	
	/**
	 * Takes the user array from Joomla 1.5 and converts it to a standard user array
	 * @access		public
	 * @version		3.0.21
	 * @param		array		- $user: contains the data passed by the API to the Integrator
	 * 
	 * @return		array containing standardized user data
	 * @since		3.0.0
	 */
	public function handle_user_array( $data )
	{
		if ( isset( $data['name'] ) ) {
			$tmp = explode( " ", $data['name'] );
			$data['firstname'] = $tmp[0];
			unset( $tmp[0] );
			$data['lastname']	= implode( " ", $tmp );
			unset( $data['name'] );
		}
		
		return $data;
	}
	
	
	/**
	 * Removes session cookies and session from database
	 * @access		public
	 * @version		3.0.21
	 * 
	 * @since		3.0.0
	 * @see			Cnxns_library::remove_session_cookies()
	 */
	public function remove_session_cookies()
	{
		remove_session_id( $this->cnxn_id, true );
		parent::remove_session_cookies();
	}
	
	
	protected function _find_credential( $item = null )
	{
		// ==========================================================
		// Run through the parent first
		// ==========================================================
		$found		=   parent :: _find_credential( $item );
		$cnxn_id	=   $this->get( 'cnxn_id' );
		$cnxn		=   cnxn( $cnxn_id );
		
		if ( $item != 'username' || $found ) return $found;
		if ( ( (bool) $cnxn->get( 'forceadd', false, 'users' ) ) === false ) return $found;
		
		// =========================================================
		// We are looking for the username but cant find it
		// We are asking to force add the user
		// ==========================================================
		// Set the credentials into a new cuser
		// ==========================================================
		$creds		=   $this->_ci->get( 'credentials', array() );
		$cuser		= & Cuser :: getInstance( true );
		
		foreach ( array( 'username', 'email', 'password' ) as $item ) {
			$cuser->set( $item, $creds[$item] );
		}
		
		// ==========================================================
		// Grab the logins that were completed and build a full user
		// ==========================================================
		$logins		=   $this->_ci->get( 'login', array() );
		
		foreach ( $logins['done'] as $cid )
		{
			// Find the user on this cnxn
			if( ( get_api( $cid )->user_find() ) !== true ) continue;
		
			// We found the user, so set the password and create it
			$fuser	= & Cuser :: getInstance();
			$fuser->set( 'password', $creds['password'] );
			$fuser->complete( $cid );
			
			$search	= get_api( $cnxn_id )->user_search( array( 'search' => $fuser->get( 'username' ) ) );
			break;
		}
		
		// ==========================================================
		// We have the search array test it and start counting
		// ==========================================================
		$exact	= false;
		$count	= 0;
		
		foreach ( $search as $item ) {
			if ( $item['username'] == $fuser->get( 'username' ) ) $exact = true;
			if ( strpos( $item['username'], $fuser->get( 'username' ), 0 ) !== false ) $count++;
		}
		
		// ==========================================================
		// Test exact and counts to determine what to do
		// ==========================================================
		// Exact username not found so lets use it 
		// ==========================================================
		if ( $exact === false ) {
			$creds['username'] = $fuser->get( 'username' );
			$this->_ci->set( 'credentials', $creds );
			return true;
		}
		
		// ==========================================================
		// If we have an exact username found, append +1 to the new
		// username 
		// ==========================================================
		$count++;
		$creds['username'] = $fuser->get( 'username' ) . '.' . $count;
		$this->_ci->set( 'credentials', $creds );
		
		return true;
	}
}