<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.16 ( $Id: default.php 190 2013-01-31 18:57:54Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file contains the default controller class allowing the system to intereact with the data based upon actions
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once( JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_integrator' . DIRECTORY_SEPARATOR . 'helper.php' );
/*-- Security Protocols --*/

/**
 * Default controller is used to handle tasks to perform for the user by the system
 * @version		3.0.16
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntegratorControllerDefault extends IntegratorControllerExt
{
	/**
	 * Constructor
	 * @access		public
	 * @version		3.0.16
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		// If the view hasn't been set, set it to default
		if ( is_null( IntegratorHelper :: get( 'view', null ) ) ) IntegratorHelper :: set( 'view', 'default' );
		
		parent::__construct();
	}
	
	
	/**
	 * Login controller for allowing a user to log into Joomla from the Integrator
	 * @access		public
	 * @version		3.0.16
	 * 
	 * @since		3.0.0
	 */
	public function login()
	{
		$app	= & JFactory::getApplication();
		$params	= & JComponentHelper::getParams( "com_integrator" );
		$model	= & $this->getModel( 'default' );
		
		IntegratorHelper :: set( 'view', 'default' );
		IntegratorHelper :: set( 'layout', 'default' );
		
		$remember	= IntegratorHelper :: get( 'rememberme', false, 'bool' );
		$return		= IntegratorHelper :: get( 'return', null );
		$username	= IntegratorHelper :: get( 'username', '', 'username', 'method' );
		$password	= IntegratorHelper :: get( 'passwd', IntegratorHelper :: get( 'password', '', 'string', 'post', JREQUEST_ALLOWRAW ), 'string', 'post', JREQUEST_ALLOWRAW );
		
		if ( is_email( $username ) ) {
			$username	= $model->get_username( $username );
		}
		
		$options			= array('remember' => $remember, 'return' => $return, 'silent' => true, 'integrator' => true );
		$credentials		= array('username' => $username, 'password' => $password);
		
		//preform the login action
		$success = $app->login($credentials, $options);
		
		jimport( "joomla.session.session" );
		$session	=   JSession::getInstance( null, array() );
		$session	=   IntegratorHelper::sessionEncode( $session->getName(), $session->getId() );
		
		// Set Form Action
		$uri	= & JURI::getInstance( $params->get( "IntegratorUrl" ) );
		$usessl	=   $params->get( 'UseSSL', 'ignore' );
		$isSsl	=   ( $usessl == 'force' ? true : ( $usessl == 'none' ? false : Juri::getInstance()->isSsl() ) );
		$uri->setScheme( "http" . ( $isSsl ? "s" : "" ) );
		$uri->setPath( $uri->getPath() . "/index.php/login/" . ( $success ? "succeed" : "failed" ) . '/' );
		$action	= $uri->toString();
		
		// Create Form Fields
		$fields	= array( '_c' => $params->get( 'cnxnid' ), 'session' => $session );
		
		// Redirect
		IntegratorHelper :: form_redirect( $action, $fields );
		
	}
	
	
	/**
	 * Login Error controller when there is a problem
	 * @access		public
	 * @version		3.0.16
	 * 
	 * @since		3.0.0
	 */
	public function loginerror()
	{
		IntegratorHelper :: set( 'layout', 'loginerror' );
		return parent::display();
	}
	
	
	/**
	 * Logs a user out from the Integrator
	 * @access		public
	 * @version		3.0.16
	 * 
	 * @since		3.0.0
	 */
	public function logout()
	{
		$app		= & JFactory::getApplication();
		
		if (! IntegratorHelper :: get( 'integrator', false ) ) {
			jexit(JText::_( 'JInvalid_Token' ) );
		}
		
		$app->logout();
	}
}