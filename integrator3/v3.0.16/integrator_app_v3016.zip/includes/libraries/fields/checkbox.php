<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class to generate a checkbox field
 * @version		3.0.16
 * 
 * @since		3.0.2
 * @author		Steven
 */
class CheckboxField extends form_definition
{
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.16
	 * @param		array		- $options: contruction options
	 * 
	 * @since		3.0.2
	 */
	public function __construct( $options = array() )
	{
		parent::__construct( $options );
	}
	
	
	
	/**
	 * Method to generate a form field
	 * @access		protected
	 * @version		3.0.16
	 * 
	 * @return		string
	 * @since		3.0.2
	 * @see			form_definition::field()
	 */
	public function field()
	{
		$name		= $this->name . ( $this->array ? '[]' : '' );
		$arguments	= $this->arguments();
		
		$extras		= "id=\"{$this->lang}\"";
		foreach ( $arguments as $key => $value ) $extras .= " {$key}=\"{$value}\"";
		
		return form_hidden( $name, set_value( $this->name, '0' ) ) . form_checkbox( $name, '1', set_value( $this->name, $this->value ), $extras );
	}
	
	
	/**
	 * Method to generate a label
	 * @access		public
	 * @version		@fileVers2
	 *
	 * @return		null
	 * @since		3.0.2
	 * @see			form_definition::label()
	 */
	public function label()
	{
		// Presumably on the front end?
		if ( $this->bootstrap ) {
			return $this->translate( $this->lang );
		}
		
		
		$args	= $this->labelargs;
		$args['class']	.= ' control-label';
		
		if ( $this->error ) {
			$args['class'] .= ' error';
		}
		
		return form_label( $this->translate( $this->lang ), $this->lang, $args );
	}
}