<?php
/**
 * Integrator
 *
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.16 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      3.0.4
 *
 * @desc       This is the generic box builder for Integrator 3 backend
 *
 */

/**
 * This file requires:
 *  - $type:     what type of box we are creating (used for language purposes)
 * 	- $headings: an array of headings
 *  - $source:   the actual source
 *  
 *  headings should be in same order as source items
 */
?>

<table class="table table-striped table-bordered">
	<thead>
		<tr>
			<?php foreach ( $headings as $heading ) : ?>
			
			<th><?php echo lang( 'tblhdr.' . $type . '.' . $heading ); ?></th>
			
			<?php endforeach; ?>
		</tr>
	</thead>
	<tbody>
		<?php foreach ( $source as $items ) : ?>
		
		<tr>
			<?php foreach ( $items as $item ) : ?>
			
			<td><?php echo $item; ?></td>
			
			<?php endforeach; ?>
		</tr>
		
		<?php endforeach; ?>
	</tbody>
</table>