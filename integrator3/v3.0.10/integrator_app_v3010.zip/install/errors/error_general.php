<?php

require_once( BASEPATH . 'includes/helpers/uri_helper.php' );

$uri = & Uri::getInstance();
$uri->cleanForInstaller();

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		
		<!-- Always force latest IE rendering engine & Chrome Frame -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		
		<title>Error</title>
		<base href="<?php echo $uri->toString(); ?>" />
		
		<link rel="stylesheet" href="includes/assets/bootstrap/css/bootstrap.min.css" type="text/css" media="screen, projection" />
		<link rel="stylesheet" href="includes/assets/bootstrap/css/bootstrap-responsive.min.css" type="text/css" media="screen, projection" />
		<link rel="stylesheet" href="includes/assets/bootstrap/css/fam-icons.css" type="text/css" media="screen, projection" />
		<link href="includes/assets/css/fonts/colaborate/colaborate.css" type="text/css" rel="stylesheet" />
		<link rel="stylesheet" href="includes/assets/bootstrap/css/admin.css" type="text/css" media="screen, projection" />
		<link href="includes/assets/css/login.css" type="text/css" rel="stylesheet" />
		<link rel="stylesheet" href="includes/assets/bootstrap/css/system.css" type="text/css" media="screen, projection" />
		<link href="includes/assets/css/pagination.css" type="text/css" rel="stylesheet" />
		<link href="includes/assets/css/pagination-blue.css" type="text/css" rel="stylesheet" />
		<link href="includes/assets/css/icon.css" type="text/css" rel="stylesheet" />
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
		<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
		
	</head>
<body>

<div style="height: 100px; display: block;" class="hidden-phone"></div>

<div class="container">
	<div class="row">
		<div class="span7 offset3">
			<div class="row-fluid">
				<div class="span12">
					<div class="well-white" id="header">
						<div id="logo" style="display: block; ">Integrator <small>v</small>3.0</div>
					</div>
					<div class="row-fluid">
						<div class="well">
							<h1><?php echo $heading; ?></h1>
							<?php echo $message; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="span2 visible-desktop">&nbsp;</div>
	</div>
</div>

</body>
</html>