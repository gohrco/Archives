
INSERT INTO `__DBPREFIX__settings` (`key`, `value`) VALUES
( 'GoHigherUsername', '' ),
( 'GoHigherPassword', '' );

-- command split --

UPDATE IGNORE `__DBPREFIX__settings` SET `value`='3.0.8' WHERE `key` = 'Version';
