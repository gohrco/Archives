
ALTER TABLE `__DBPREFIX__meta`  ADD `language` VARCHAR(50) NOT NULL COMMENT 'As of 3.0.4'

-- command split --

UPDATE IGNORE `__DBPREFIX__settings` SET `value`='3.0.4' WHERE `key` = 'Version';


-- command split --

INSERT INTO `__DBPREFIX__settings` (`key`, `value`) VALUES
('DefaultLanguage', 'english');
