<?php //00925
/**
 * ---------------------------------------------------------------------
 * Integrator v3.0
 * ---------------------------------------------------------------------
 * 2009 - 2012 Go Higher Information Services.  All rights reserved.
 * 2013 February 6
 * version 3.0.10
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPo9RaUoe76h3eO84pq6dnxNN/8AfyEdXyhQijLCK8tkSmzSx0XZCa4G38FewwOW5ZaVdmOSX
9sZ7bKaQwgthPdsvhCdcYRsYVxqGwyFPOABHJQzmOqrqnyFN309j6KblTPAsjvIysnt+ma0g3ocU
XDM5XgixzbUe/7dc0R0nkHEba38l16kJFXv3SPGHn9rot3+HD6NiUlh+9gQ9V98hxfWLs0+06cNW
2LMPbP0f3Hjgnu7iHm2OldCrg5dZsi2FHmCWSwQwYwPaCOon3pdmMzl7G4hzDl4VPtrV8RzdcTJr
8cb17Ze45zyklCY/qQYzpfTyM1cDnTNYPWDpCGIBWceIrCh5HbhwTOfLPx7G8Hsl8lLku7IJvF2C
zDiYMNV4D5s1LdrMK3/Wx2yPV/GwAAz4dHzrbAsmZ3SgmkXavbcV6HOpqp2ej+e1w9RkmyCxE1Jr
j2UoC5TvC500cw7TIraKOGHCH99K+1OGpDqwJkrMVYuZpa2hbXz+CMwpNMyjkE1E8amjaHWw3w/s
FV362bZMo5bO+Lj8uZ1HNq92Q5Qo3gca0dDc6+dP9nsUhd4nqRDRYgh3VB7r8hxEY9c1uo48/im0
Q/t/MA7x8zzNhG+cJWck4SHn9H+aOa2cDVRgSqh/LZ4eUbi/zc/pKca92DVGbnE34qE/UNTjdGAl
g/BAVRGSFsBIDXdXBHLvzD0MVqVELwc6rH0Pjg52kRYv4raDQAMUUc1swwDtvwIQZq1JZ0bZE8WU
//QtZ86VpcC5661YKpha7bVKrEOXuUB0g1W+fr8V/WoBXmdoyI/ylPfSJdGqIemqExI1p07scyqM
4VqsPOknK0tiGJ81pwrbKB/AwaJegqzNvpbNWSi1HR5PuRS2xwcwg9cece3B6c/uZI0biU/HAREa
fhc5TnGLDyDxKRNfvsqUt5D4BuikUeDF7Vy4JyiIdnXiTMjP8JHRrfLvfCjw9U1D45o1l/UNnX7v
MF/PrL8g8171YWTdl8CgzG04/fAJMGLe2eJC9yplmI2ofvh3q61iCHoiX46g0R6GdsuAEaVI702U
6Wqo7NN+H0M5V3ZS7BTFTa4U5c9hTeyd8fUBvPdC+Ae/lo5p1fQnXvF6UXZ8h4FbGMtDK0XRe/4l
+yICVEsI0LaJ2J1VeuAFX6LnQTs+tm45wd8Q+Lb0iNTh2b5U2VzPpibRRiSIE19HMoG1H16c015K
etC6MgAzvAVfKhFV5NCi9aONeZzufcg96VW2mKqIc7NxJaZ2fyXJPQUE5f4/DadwAunIZ00ROVsB
LCs28caKy2QOgQxFRZ1A6aLFjb3dfc/ojdsLjDzfboHaU+vs2gFhnKdGAqZJLrslJS8LyjsBXYxZ
xM/KbBwPkENbZeSROMqGRgiz9gyO+1QsMJZcM1r9mRlRdw8XFWD6t+4tDO6iO8W+qr54rvrZczz8
kBD0owWClIDgbvK0ptnH/iaDhmiBhY9ckKO0NfK1zBUYvIEpMHifbz5TbHs2rLV0PfODP1bwJerz
c9h2/vORoAycoeo9cdndBPF3E63czJXpHs4fdh4oGeUWe5NRvxfG7g987Vu5lYM5eAQluZXg/q8W
s21PYnwWOs+lrW/jMmFmbKDxW9w7fGErDVU0pts2mJ25xgtSQ6pcfK8maaIgaNfhbfuVJNjQKNRn
f4Vbi1B/lUkgOPB028fdJmEl3/HICTMJJ+giYbej6NcYetWZUVHBrxD8RbrryypwMxG1+1Gggueh
iERmKlEiKO0MjXbKlb3iH8u8yv1sfPYYjxgLh3GTEvyJ2xuU1CTy32+CrUxu8/1n9OFJcfUM4XNl
nDGaD20K9YM+ZyJQ7RsqMBNBidZkK8JxwJXFEhDIYQISJag+vXp/tl3rI/eZZX2tIt/kqEZmTrK3
9yW0DKsJY11gvZP12KwEgdn8+942knhZ6F8cOQkRnDdU0FpF40Wo8mjHf4YZEGZuQLpPVSY0bxWW
cUxrnx77SRtWyt+OSzLkGtPWddQ2Rd/DqLrd3jj52iUlLa1Rg5+WvY6eqLQvly+A8PIAUzsn99ai
1GE8tf+ypxww53UjUlfyI+wsEWLqdHqb3ydF051uGT4csiO/8jcATI2FbXeulePABF08yyqRsU3o
ydtVsk1vMDM4+VI/A4wudGooYFKsXshOxf7TkS7d4+qhUHODyaKTFVL30ro1DEo275lJU8Hzkh9E
jnafHkXaBVohLT4A5pVu2HeQZJ2YQ8AyoI+jwo1xllDDMW42tgzNxc/sRGq4tXRt9lihodl6bUOa
UYIX0SLNASCpYj/mEkQPMsDUo6A7wH7ZGnqxVfSsJcKY+XhkyCYdwYsD160lj7c3wgFU9cmuqIpf
It62Zk4D46bg/qSNOB00gN0YRwK4zE2LA3eTlaOxRmU7LLjPhKYiELkLZbczC5xWLze6CY10Q+6z
3c6KMz16RDU7wYZ0QVtHVPTpMpR+qOOHsGb3dq+EE0/QINHlrvmiqRmpVd7TlHc9ri4qjBJQ8Z/F
hfHSPiAazcX3QRxrgJYsoa2F5rUbSulTy3V9QAalvjjq+CwEd/xYAvDJw9eYYEhJTnqtLMijjOkj
aGSAQJXSWxq9M+OTlEf6fzQdXmHTMb7CtMc0w5iPpsfNXrwI1ruXiN43RBB9gZ4QtGqwlhxgHGUa
IQdFANrZXKhgomRWqanrL4bwxcL2Emmk+o3pGg/JfEIQf8hrH1bHGXc8hHvFw+iHp8pcdep86DF1
LJRKQuuSAucJhBZ9xRh+kxx0+jfnhNdWx4j2lzHKBavUMrhXjULdOORH2caJ39HPb/RtCtIEJSlP
4QbieipFcV0AhH8psZQnaIJO/4XRAhdWVXExnPIBgHKxJX5SNdqY6Ngeql2yyKlr2t7QcYVqGJNw
pfiEiJREJXpzqdNAlMkGVYOgT8CFkgNQ4aZIBArKkf+ov9hzjMBlKPMf42pi/8G2+3jyLh0/cGe/
ifGwnawn+1Y6fu0x1YoqOFMNrqHO9TnRnwNitxCtHm8G6jveOCIAZyI3DrK/LDRGO8tJEEK82vfg
f8gBCB8YnX+j7rkS36atprhg05jaIyo/dJI6I+YspITOn/gLTCM2KMT3eXL7gOnRD0oVj8AgmFnW
QgUbPT9+Q0ojsHMZ+QvO1HFmnI2bmWwe7c2refzr+kWjukSaZWVUbEweGLJcWSLdhi84JIRi0xQn
oyKNUuQC3NQLWfsLzUKNzQlKMg7sN0ByPKYetxN/3tVCi5P1B10VjVyqRdV+qSpNNLkX7MGTzD0n
waZvYvP3GJjo/q3lo2lsUt8fJsoV9jzoma3UuTFRuc+OXZiimvKV3Yx6FdCr/lgrGk8OMWgj8BM5
8vkH1iZASkFSyo48PGuRxupPQ+/hRO9nGeY3TggqVKWzBc9wQyB+y6Ufbm1GAorNXdXpx3AToo17
f6xDJlyQHRKBKU9jh8Qh9yYkJrQZ1yGqIgaJG8enjhsGi6aOGXZlVtbpk9fvrYjXT8NrYmYKyhuj
EHJ1YOKO9EuXxj/8RZDsytMYDVoJDFVDNsqFz4LxDZBcug/20Z3dqC56XvXK6W4mckSlatP0jlZM
ShbnMemtctWeJQIC3tQmw9dCMp2Qa0931FrT4Xa+ZL5gDmo2gqRsfoYIlLqvY/2Z/SAbOAPA75bU
911tsXEuRM3NAaqVOY2fnlhoRgb2/D2H5tOsYpAjs0sm2MOOt9c7Xmxy6OZ2eFGQfcdZ8y5Bzd+z
b7lTgk/lT8dxROkhyiFSB4i7bxaMLVvywBfmBYN/LxeFNq4LmRlkJAlZrx9BfR8hobjgnPchdpvl
48y2URSk+PfJgrVQMFqW0/OYXTtsyDr+nS7s9k3IAZcJpg5H5pVCNmoF0IqD0yeddWONb7mmOLLT
+Vrw+bRQNYDJKmvYJY1poZEuKN7hg2KeBARf6b/j81cOIyPeo5zrLZCQP1LebKAqvxb8Fg3pBqlQ
k97jW5xdG5Q8B/1qBINpAOBvYA9OasRbTndtjnUw56oNPFGVFiiKxupkp2BzEMWPIl6CRj1x5G5x
/uByz+228ADP3o1Kb3PfWeCxYbaEMy3oa4IG/SSsCilSxf4EjaSBZVd2MuL22SN7pR2w68whVJX1
455j7PcRDenyIjRu25RjQdgEPEnavoNv1G2DsW8YTrNqLI6RGeCbULEZZLRsyNzXXW08P/eDdhu8
SL2bPQm99f8lvmbhEW6b2Nis6zswJOLopqkGqKYTG7/Wgo9oGx3pbmyNpyCQ7PIq6pWtwKILNdiN
y4J2YUzxXNypOB+lsv61MXafHRIhYo1pJa1Yo7WCyFZM/xaTYEHNcFBQsXA+TlNNf1/AKrciSha6
X1ah8Qo5l4+XbW17JO7EDoNkQghrccSms0HSeJIsoT9/xUITBsgcRY0fIVToRzOGWlTAzzb5lErG
T+4vL+qhUNZDS+e9P2dqSuXMIW/UTP5iHV472IAkSfIqksvM/pcvIuHR0ms6Gxi/zy7tvRwAIQSa
wVi7/3WX3nZ+UUhxfKGjtjPe1UfCtQiSgMyHIEaHBXql3GZf3Ve1flyTZUZJIo2ac8Rp0YXOmnQe
isgICzjNaWWdTiOd7nCSeZsxXTkbLunEV7IKp2rHr1Of8kicF/JnS208lJ3Ns+2UsaC9e9UUQxIt
PSyXOJKKYlsCPS8u5/k+lOkWVhz7f+dW4N55vcqQUT8pvcJX2jjlH9bdXO3PelRHUMeOWKJxEwm/
Urf0vmqThnSl8uwIBeRO/fo2u4CpZyeGbpht53DMjSpTIueIW1/cP1cl91cIuCZoZuTs7FXvVk9E
jhGXMuSl16CduVxEaMarVh4frDPrcsZr1YySzivoVm08oAyRcC9qmWjsy2abDF5HWnvgrqkfvYFv
1Y+e167svz+JaZggKrRsFQcsfFgPZoy8zMf+YtLD8OTXEzXg6d3QXEi7xiC8e8BtNo5WbPorRAS6
IQytn9sUSw19uYnJwQSZW+M9OkBCfrAWJQbb1rHadwqRRFBX1VU2I5KgH5PeYpHchae6ur8DXqY9
8HjArXnCNadRUVczd8qSNcSXxdlcPl/j26smp37cT2U+rjE/01zsoPypsuh5tuAJJg2y46pRI2zu
KFzCwHJlL3gs38I6Jq+iY843sIEv9NjyT8m9HOJUxp6KOw1KXUXmKKPbOWoPc4lsiAbGgzY++ooq
xDPMpgSL09aL1ktf6DNTFSlYOcLH0XvVOBJrs5IdoA++HtaNAvvhZncp1BpKhK/312ENrGtzaUqV
kC8HD3sGQlZBkT7KttfVMRjmLjgKPi2zU3KOEdV0ig+Hlvt+dGc5QXpe4/Sx5kXUb0yw/IYnhXmQ
IxE1nFb5pdg3T/cfSKnXeLLxflMrD8EIOHcCLRrDlOIXb9mdB8djfZZX7AnhIvt/431oTL5zg7Jk
O/dB9eInfia1gesYsxWrH91Sdaq7ZR9qycEocxLuLs4FCNIMDH9f4HmqEqnSYNH8HKnmq9+dPaZR
h0FiYHBIuH5J86PVBo41f6GYO5APrENdPVBevHKoJ3eGb1Z03sR9ZG5+PgFtXDL4Dzfa7AoC2+qS
9IRa3jTQvNqafTestHEyjLFpI3YlbyIV9UQFSQYeBXKw3m30IyrPP4ydi80+zviEaw/jxa/n/Ycb
yfNkTUl57tdv9XkTvw6YSZlbLRdlg6Sm5AIqhSMJlWoFnAOtM6O2yAF7W1h3Jo7SyeUENbbgxFxe
pfqa8xUJ5xTeWUuZMkAaA/YKB8/G+J5EQDWWCj1HAsOqDvwTP7AIybj4XvWhj6ZA14kBG0CLTDZk
wkh8Stqzt8A4bk2yxG1zh4GtSFzUDKBSKZr4fHdDun9QCw656V4M6KkWFvbcN4vCHKvvLLRhhA2W
1/OMiofW46HGKEt8yFZkvuD0ZSSItxHAIYygVpItEhEHtuzlBaqx4YEZNDIqFn5CiFkCBy6HSOj6
9puM2GQZh1fLuuwh6R9x4wWnvFSM3QYAkcotmNj6ZOaKOVOxkINejsjYqXx6oBCla4zSr2bBkoja
qndvJTVJk6xO4ukGhi4fp83vsoM7E5NhxHetJEHyicZg4BIuLgjFV//Kyf6vXV0G9NtPQjGlh9Zc
zi6XtUllWbkv5x73sEr6hobclUUh7Vl+cAMHzRtBVHpFXUOF0RTaE0/tXGTV2ObtdwjOXPAeXXoT
q4Q3q3k3uzvu8XNExxWnBM4DOSd+5VzlzHZHK4g7UuseC0t9W+h3eldnmJqbjTvDFagUvMr6ttKo
AucvYBK1NTekjc4034/qcowq6tnji/BBQz3ctojjn2DDX/gYe7SPY2FPueFRbQJ2OeInuVcCkUSE
kdyCdzlyuXlFSfkMdaq8ESgdujQ97YdcQx2+IKX38XaMtHyQa4m9SZf2bD0enF+WOvuTK9Zvq92E
/l1KQ18UI7E/2rBIIIqmY9Ix/2alUM2btyqG/mW7jjN9FQSMY/duL7ykkKk4GDCr22+ecsflLhKx
J18i5VoFU2aIJq7jDlxBpgzBUn/ah/daFOTxk3Q+W72+Do31wRvogOTyMrs0PjHxwgelqPkO4gbx
VQ3KsPuB2c40O4pbZ4h+dHjh0bzIfVnQC9D1eoX7xQkJGg57a0cRLl5TN/z5BDv05jH2dVH/iaup
0JhugNxk143zzsG7H8fmNmE8QQO2IRb5iwjnDyGkRAYOB1ovWacY80QyVY55XpHHLzlbajc7ag1Y
Rz9C2PYY9gmXEJbGf2JSCo5Xw+hDDVATRSqYRvwdMIzJ3RsPwgGwv+AYkU2CB/U/yRdYlioRVkYv
xOK/RO36niGREmc2iMbmvWXfL/ieNCBTTIWpQkAgpZrQZmLsBIJwb9S1t1AZFfCE3OwVWvkLB2Ku
/nfz/8vldSvV8APH6BYkSquS41JCAg45WnJ/xgk4+CljZwH1pS849xVJ7QWFORei+OhcJalIOM//
Qx9j+mCGdK/5FaPSzNCONOUcrVFSs0h0p69uKfTovAyjR+eAbzYo9mZObPhCQHbyhcblxWWWSfWP
7jIMya7o2hk0ddUzXWH15arIPPEqmAxeQHrvvTXnTJQD8UT+vltIyEuV6Kn/3/Q0H1YUsdIHNn5L
zTbRjuQWqBHen3YQvjUx3N+Gy0xJrPIbNXOlsJJidp8z3oQZerGO/PABiYeTt6b4i2z+lkA5KwUS
lyY4Z5p6fXKV/CVCXiHwsvwunIzvvF0cOKKm4DYySzXazdtWIhuNE4cH2REq/1D4Zj+BPYZWOHzy
1gephUclJtjTAPs5AUmnBtL2OJbsP2EGSlLAC/0eWOObtrkiXl/BD0Ltk8zwriLnHwJdK05Z7PPh
jdqmUyz0Z0jJTbM0Dbm9NhspGVRa4LpgHAjvUy92eC+ly/4Ozh0bny8q49K3OlW7VbtVucxpWsxy
VQqtwWX27Tr1jtypATOLmyu7GLvW6Q76AF/zLfM6DQc6KpzOXXhPO4+NQiqCss0UQgNHhbywT270
hBH0308N9QOIpVdo2zihLy1xIJbii/Vc1YLcS0xcuOzg15Z7fuxqTnvgS+02nWIaHOkvn14aU0xn
/K8cm1JEg3bNlw/Ph39/05aaZAdIFNVmgnp18+OQ/ps+6ux1GO8xsi0bzbBv0rdy15yTh/Z3A83v
cGtzoZSpnIqLIhSnhb+XO49n4rQOs48VAYCuQIFiv9FJ+bRQv67yGYBNTgv2BL+Xfb+jXa7KKeYO
284KXyNItgnOCVanPiUbDZBXl2h+1K5UTG8GxMFVP9qWynV1OjglIidGcBA9ZWozh/Jf8BtA1z3o
/81ATGrAY9VMdoyDMI1Uk20dQWb8/xaT/DYDr6NV9uZFoIx9Sbobnx9GpUAEmdUY2sCuMwj5uxj/
o68UZ3j/6mSbSiIIM3kOoRc1zM7ZhZtQtWY9bJsCqfFz++fojxIEQKY7z2/Ys6ecjkBb44pukQcY
PJZ/uJln9rNyhGTEGk3YTRJWIyMLVCnqdC2oWGD+PcyWGZsC/URT24X6cqdnh6k7E0N8x2YvhVC7
qrYSICsHRgrMMNCdQEujfzSWkA36y2J6mgq2udcjOy9PwUjn48dMOCIRXaasZa/CRkfJcb/CAoc/
hkbShZ4egSuEMLnuhVS3Y8/S8pdWuFsVkSCGuopymkBqcOw7ZBiL5y1ThslrdmqTHLR8Olcfq+Fh
Nc6TzUBnvTVx54TlkwNPUbCrqxMhGFV3C0Zh4U939yDv6jXWEKVY0byMKbf/3BKsHBpLD7YnU4BI
UVC7jvZmIVUBpiRLdyT3GSmQKmp+Yx48wfLiainVQ/jTlxLRf34LCeaC5xcaxkrYd/Da8qJBkqvj
ojL7AgSdH8q3wlYGDQhZbEFZjBBQov6zpbkHHhZwCATdqEtNCMKPjdC+E+wmbs2BPi1eOy2hzYkn
VM15pNhLv97JMcQ8wMUH3ErQWDqNPJvNoB515cZAW2gru1Pz3XEr6K/LmI/6FO23bvus8r0MD9Jo
iAiRW0ltnRxv1mZCMMxAqR9WSuV63nb2UC2vP4f4PD9RmNbrr3qtPGAC7U2/oKw+8xCGDPzTX/q6
WdLNPQvyx0M0QbSLEvUMEFbsGdfRINSClzY+3eNJKEazHWiQCe2OiW6X0GePcQ3iZHTZiVxJnOju
3GCXX9GSNj3L2w0q4jwzb8Ee95N/XGb85LK8BSdrzNN2uYs2XFN9pVG4RNtRxYlKN1t3BoBJ9Fpj
h60wjYZsIjhf8u1q5Yi05C0Q35umSnrBgW1np1WIPjeYPPlX/lch0W15PG2Sj3f1fG4O2Iqd2ugN
fn4+YCixvP+o8ChoxQF1WY9nz4dxFPTRgaASO6hTgIKNTdYSnvGnN3uLgQ/6V7T3ys8UrZuRSOAQ
eGHUzMslJdbALgshp+FIwNnBOUE6zUDCgwVEdHFGM/M4y2OortenRGXz1GkOYy6iHJ+jakeflwmt
QXnQjHL7G2qQ2oGH2QokV/6lX83BmWTZ+iVVpvAmhFRRv/R5/aYB/bTOxeQIAKd67TQgwa0AJShG
pzHY4nBMHRt4NXVZgSZqJJzACcInXQzyGgL/6hQ3UKRsneYcPHeaSTq3G4gGUbLnmVV5p3sJ9Rv5
N/TaLYW1PZHXg2dSD0cmJfUrQAQIX5kP24/hcZk6CKgmJyL688sBhHbo6CjQBrBq+cHGzJj7LKEy
BS8zjwgVZxT0LVWSCOhGdRGUoEVnTfi0hwrq1FYFI3EI1adKWWjI0SDAUrzLsDGuX15Asrn1doQF
ODZClgqc7nCuvldtdrVCryLnFiBKmZgZzerouyfWOzhHPmz89tFlqTzdg9uwAKE/nM7SRaCXDd5i
J/YnfRUd3oLqUMI3rlMA9KMTkIC6O6XVxlxhVPMnUIpk2rt6dEQDKvPyoUOoYLM7xNd7/ugtxkOA
aTrkI1/jLjS7wNXQz0SESsd+kQRZCwdocDCSVQs5MmIATVu4/i6jfz4ktmZxD0d3YoRIpMLaoQLc
U2/d4BIhcBNcI+mUNWu/cWgzvjAWYjZGye0G9P4rhAAN8Y1iY+iuop2qTEtsvrpmT8lrz+V5V4tm
K/ZnDjY4CSn2OYDsUPv4hhKJLAZi1IU6e2+QU02loqZ1W5QwvcZEQqepmSm2R39jDrtKis/u72HS
hU2JXVm=