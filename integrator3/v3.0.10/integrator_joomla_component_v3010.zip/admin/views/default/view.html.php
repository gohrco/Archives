<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.10 ( $Id: view.html.php 190 2013-01-31 18:57:54Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file renders the default view to the admin user
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.view' );
require_once( JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'helper.php' );
/*-- File Inclusions --*/

/**
 * IntegratorViewDefault class object
 * @version		3.0.10
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntegratorViewDefault extends IntegratorViewExt
{
	
	/**
	 * Displays the backend to the user
	 * @access		public
	 * @version		3.0.10
	 * @param		string		- $tpl: template name (unused)
	 * 
	 * @since		3.0.0
	 */
	public function display($tpl = null)
	{
		$model				= & $this->getModel();
		$this->status		=   $this->get( 'Status' );
		
		if ( $this->status === true ) {
			$model->updateSettings();
		}
		
		IntegratorHelper :: addToolbar();
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			IntegratorHelper :: set( 'layout', 'default35' );
			
		}
		else {
			IntegratorHelper :: addMedia( 'admin_default/css');
		}
		
		$this->debug		=   $this->get( 'Debug' );
		parent::display($tpl);
	}
}