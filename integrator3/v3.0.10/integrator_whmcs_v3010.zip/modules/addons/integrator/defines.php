<?php
/**
 * Integrator
 * WHMCS - Defines File
 * 
 * @package    Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.10 ( $Id: defines.php 165 2012-12-18 15:52:55Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file establishes any needed constants
 * 
 */

/*-- Security Protocols --*/
if (!defined("WHMCS")) die("This file cannot be accessed directly");
/*-- Security Protocols --*/

// Path to WHMCS ROOT
if (! defined( "WHMCS_ROOT" ) ) {
	define( "WHMCS_ROOT", dirname(dirname(dirname(dirname(__FILE__) ) ) ) . DIRECTORY_SEPARATOR );
}

// Path to Templates Directory
if (! defined( "TEMPLATE_PATH" ) ) {
	// Determine the version and template name to use
	$version			= substr( $GLOBALS['CONFIG']['Version'], 0, 3);
	$int_template		= $GLOBALS['CONFIG']['Template'];
	$order_template		= $GLOBALS['CONFIG']['OrderFormTemplate'];
	
	if (! in_array( $int_template, array( 'classic', 'default', 'portal' ) ) ) $int_template = 'portal';
	
	// Define constants
	define( "TEMPLATE_PATH", dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'templates' . DIRECTORY_SEPARATOR . $version . DIRECTORY_SEPARATOR . $int_template . DIRECTORY_SEPARATOR );
	define( "TEMPLATE_OPATH", dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'templates' . DIRECTORY_SEPARATOR . $version . DIRECTORY_SEPARATOR . 'orderforms' . DIRECTORY_SEPARATOR . $order_template . DIRECTORY_SEPARATOR );
	
	define( "WHMCS_VERSION", substr( $GLOBALS['CONFIG']['Version'], 0, 3) );
	define( "TEMPLATE_URL", 'modules/addons/integrator/templates/' . $version . '/' . $int_template . '/' );
	define( "TEMPLATE_OURL", 'modules/addons/integrator/templates/' . $version . '/orderforms/' );
	define( "TEMPLATE_OSTYLE", $order_template );
}