<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.12 ( $Id: admin_lang.php 163 2012-12-18 14:56:38Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the WordPress admin controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


// ===================================================================
// 	Edit Connection (cnxns/edit)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------



// ===================================================================
// 	User Management (usermgr/modify)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------


// ===================================================================
// 	System Update (help/systemstatus/updates)
// ===================================================================
//		v 3.0.8
// -------------------------------------------------------------------
$lang['dialog.wp.update.content']	= 'The updates for this connection are handled in the backend of Wordpress.  The button below will take you to the log in form for your Wordpress administrator wher eyou can log in.  Once logged in, navigate to the plugins area to perform the necessary updates.';
$lang['dialog.wp.update.header']	= 'Redirect to Wordpress Administrator';
$lang['dialog.wp.button.redirect']	= 'Redirect';