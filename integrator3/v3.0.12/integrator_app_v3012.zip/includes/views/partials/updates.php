<?php foreach ( $updates as $update ) : ?>

<table id="dataTable" class="table table-striped table-bordered" style="margin-bottom: 35px; ">
	<thead>
		<tr>
			<th colspan="3">
				<h4>
				<?php echo sprintf( lang( 'tblhdr.help.updates.cnxn' ), $update['name'], $update['type'] ); ?>
				<?php if ( $update['hasupdate'] ) : ?>
					<a class="btn btn-warning btn-mini pull-right" href="<?php echo $update['href']; ?>" style="color: #333; margin-right: 25px; ">
						<i class="icon-wrench"></i>
						<?php echo lang( 'tblhdr.help.updates.hasupdate' ); ?>
					</a>
				<?php endif; ?>
				</h4>
			</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ( $update['rows'] as $row ) : ?>
		<tr>
			<td style="padding-left: 35px; ">
				<?php 
				if ( $row['status'] == 0 ) :
					echo '<span class="muted">' . $row['name'] . '</span>';
				else :
					echo $row['name'];
				endif;
				?>
			</td>
			<td width="50px" class="center">
				<?php
				if ( $row['status'] == 0 ) :
					echo '<span class="label">' . lang( 'tbl.help.updates.version.notfound' ) . '</span>';
				elseif ( $row['status'] == 1 ) :
					echo '<span class="label label-success">' . $row['version'] . '</span>';
				else :
					echo '<span class="label label-important">' . $row['version'] . '</span>';
				endif;
				?>
			</td>
			<td width="150px" class="center">
				<?php 
				if ( $row['status'] == 0 ) :
					echo '<span class="muted">' . lang( 'tbl.help.updates.status.notinstalled' ) . '</span>';
				elseif ( $row['status'] == 1 ) :
					echo '<strong style="color: #006600; "><i class="fam-accept"></i> ' . lang( 'tbl.help.updates.status.current' ) . '</strong>';
				else:
					echo '<strong style="color: #660000; "><i class="fam-cross"></i> ' . lang( 'tbl.help.updates.status.update' ) . '</strong>';
				endif;
				?>
			</td>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>

<?php endforeach; ?>