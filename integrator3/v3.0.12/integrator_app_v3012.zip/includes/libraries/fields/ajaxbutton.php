<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class to generate a toggle yes / no field
 * @version		3.0.12
 * 
 * @since		3.0.2
 * @author		Steven
 */
class AjaxbuttonField extends form_definition
{
	private	$_events	= array();
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.12
	 * @param		array		- $options: contruction options
	 * 
	 * @since		3.0.2
	 */
	public function __construct( $options = array() )
	{
		foreach ( $options as $key => $value ) {
			if (strpos( substr( $key, 0, 2 ), 'on', 0 ) !== false ) {
				$this->_events[$key] = $value;
				unset( $options[$key] );
			}
		}
		
		parent::__construct( $options );
	}
	
	
	/**
	 * Method to generate a form field
	 * @access		protected
	 * @version		3.0.12
	 *
	 * @return		string
	 * @since		3.0.2
	 * @see			form_definition::field()
	 */
	protected function field( $name = null, $type = null )
	{
		// Add the javascript declaration
		$this->add_javascript();
		
		$btn		=	lang( 'btn.' . $this->lang . '.init' );
		$args		=	$this->get_arguments();
		$field		=	'<a href="javascript:;"' . $args . '>'.$btn.'</a>';
		
		return $field;
	}
	
	
	/**
	 * Adds necessary info to the template header
	 * @access		protected
	 * @version		3.0.12
	 * 
	 * @since		3.0.2
	 */
	protected function add_javascript()
	{
		static $data = false;
		
		$ci			= & get_instance();
			
		if (! $data ) {
			$data	= true;
			$ci->template->append_javascript( bootstrap( 'ajaxbutton.js', 'js' ) );
		}
		
	}
	
	
	/**
	 * Retrieves the argument string for the field
	 * @access		protected
	 * @version		3.0.12
	 * 
	 * @return		string
	 * @since		3.0.2
	 */
	protected function get_arguments()
	{
		$data		=	array();
		$arguments	=	array(
				'class'					=>	'btn btn-inverse',
				'id'					=>	$this->get_id(),
				'data-loading-text'		=>	lang( 'btn.' . $this->lang . '.loading'),
				'data-complete-text'	=>	lang( 'btn.' . $this->lang . '.complete' ),
				'data-error-text'		=>	lang( 'btn.' . $this->lang . '.error' )
				)
					+	parent :: get_arguments()
					+	$this->get_events();
		
		foreach( $arguments as $key => $value ) {
			$data[]	= "{$key}=\"{$value}\"";
		}
		
		return implode( ' ', $data );
	}
	
	
	/**
	 * Method to retrieve and manipulate events set in form definition
	 * @access		protected
	 * @version		3.0.12
	 * 
	 * @return		array
	 * @since		3.0.2
	 */
	protected function get_events()
	{
		return $this->_events;
	}
	
	
	/**
	 * Method to generate the ID for the field
	 * @access		protected
	 * @version		3.0.12
	 * 
	 * @return		string
	 * @since		3.0.2
	 */
	protected function get_id()
	{
		$id = $this->name;
		$id = str_replace( '[', '_', str_replace( ']', '', $id ) );
		return $id;
	}
	
	
	/**
	 * Method to retrieve the javascript
	 * @access		private
	 * @version		3.0.12
	 *
	 * @return		string
	 * @since		3.0.2
	 */
	private function _build_javascript()
	{
		$id	=	$this->get_id();
		
		$javascript	=	'<script type="text/javascript">'
		.	"function testthis( id ) {"
			.	"var self = jQuery( id );"
			.	"self.button('loading');"
    		.	"alert( self.attr( 'id' ) );"
			.	"alert( jQuery( '#subscribe' ).attr( 'class' ) );"
			.	"return false;"
		.	"}"
		.	'</script>';
		//"<script>jQuery(document).on( 'click', '#subscribe', '#unsubscribe' function () { jQuery('#subscribe').button();jQuery('#unsubscribe').button();});</script>", 'js');
		return $javascript;
	
	}
}