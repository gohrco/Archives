<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class to generate a dropdown field
 * @version		3.0.12
 * 
 * @since		3.0.2
 * @author		Steven
 */
class LangselectField extends form_definition
{
	
	public $sessionselect = false;
	
	
	/**
	 * Indicates we want to use the default as a selection if true
	 * @access		public
	 * @var			bool
	 * @since		3.0.4
	 */
	public $usedefault	= true;
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.12
	 * @param		array		- $options: contruction options
	 * 
	 * @since		3.0.2
	 */
	public function __construct( $options = array() )
	{
		parent::__construct( $options );
	}
	
	
	/**
	 * Method to generate a form field
	 * @access		protected
	 * @version		3.0.12
	 * 
	 * @return		string
	 * @since		3.0.2
	 * @see			form_definition::field()
	 */
	protected function field()
	{
		$name		= $this->name . ( $this->array ? '[]' : '' );
		$arguments	= $this->arguments();
		
		if (! isset( $arguments['class'] ) ) $arguments['class'] = null;
		
		$extras		= "id=\"{$this->lang}\"";
		foreach ( $arguments as $key => $value ) $extras .= " {$key}=\"{$value}\"";
		
		$options	= $this->get_options();
		$selected	= $this->get_selected();
		
		$field		= form_dropdown( $name, $options, set_value( $this->name, $selected ), $extras  );
		
		return $field;
	}
	
	
	/**
	 * Method to retrieve the available language options
	 * @access		protected
	 * @version		3.0.12
	 * 
	 * @return		array
	 * @since		3.0.4
	 */
	protected function get_options()
	{
		$options	= array();
		$path		= APPPATH . 'language' . DIRECTORY_SEPARATOR;
		$languages	= get_dir_file_info( $path );
		
		if ( $this->usedefault ) {
			$options['default']	= lang( 'default' );
		}
		
		foreach ( $languages as $data ) {
			if (! is_dir( $path . DIRECTORY_SEPARATOR . $data['name'] ) ) continue;
			$name	= lang( $data['name'] );
			if ( empty( $name ) ) $name = ucfirst( $data['name'] );
			$options[$data['name']] = $name;
		}
		
		return $options;
	}
	
	
	/**
	 * Method to get the appropriate language selection as the selected item
	 * @access		protected
	 * @version		3.0.12
	 * 
	 * @return		string
	 * @since		3.0.4
	 */
	protected function get_selected()
	{
		// If we are logging in we need to select by session
		if ( $this->sessionselect )
		{
			$ci			= & get_instance();
			$language	=   $ci->session->userdata( 'user_language' );
			
			if ( $language === false ) $language = 'default';
		}
		// If we want to edit a setting let the database set the selection
		else {
			$language = $this->value;
		}
		
		return $language;
	}
}