<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class to generate a text field
 * @version		3.0.12
 * 
 * @since		3.0.2
 * @author		Steven
 */
class TextField extends form_definition
{

	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.12
	 * @param		array		- $options: contruction options
	 * 
	 * @since		3.0.2
	 */
	public function __construct( $options = array() )
	{
		parent::__construct( $options );
	}
	
	
	/**
	 * Method to generate a form field
	 * @access		protected
	 * @version		3.0.12
	 * 
	 * @return		string
	 * @since		3.0.2
	 * @see			form_definition::field()
	 */
	protected function field()
	{
		$name		= $this->name . ( $this->array ? '[]' : '' );
		$arguments	= $this->arguments();
		
		// We are setting this to span5 as a default if not declared in the form def
		if (! isset( $arguments['class'] ) ) $arguments['class'] = '';
		
		$id = $this->lang;
		if ( isset( $arguments['id'] ) ) {
			$id = $arguments['id'];
			unset( $arguments['id'] );
		}
		 
		$use		= array( 'name' => $name, 'value' => set_value( $this->name, $this->value ), 'id' => $id ) + $arguments;
		
		return form_input( $use );
	}
	
	
	/**
	 * Method to set arguments specific to this field type
	 * @access		public
	 * @version		3.0.12
	 * @param		array		- $data: contains the data passed along at field initialization
	 * 
	 * @return		array containing remaining arguments
	 * @since		3.0.2
	 * @see			form_definition :: set_arguments()
	 */
	public function set_arguments( $data = array() )
	{
		$data	= parent :: set_arguments( $data );
		$args	= array( 'readonly', 'disabled', 'style' );
		
		foreach ( $data as $key => $value ) {
			if (! in_array( $key, $args ) ) continue;
			$this->arguments[$key] = $value;
			unset( $data[$key] );
		}
		
		return $data;
	}
}