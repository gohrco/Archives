<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class to generate a toggle yes / no field
 * @version		3.0.12
 * 
 * @since		3.0.2
 * @author		Steven
 */
class ToggleynField extends form_definition
{
	protected	$text_enabled	= 'Enabled';
	protected	$text_disabled	= 'Disabled';
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.12
	 * @param		array		- $options: contruction options
	 * 
	 * @since		3.0.2
	 */
	public function __construct( $options = array() )
	{
		parent::__construct( $options );
	}
	
	
	/**
	 * Method to generate a form field
	 * @access		protected
	 * @version		3.0.12
	 *
	 * @return		string
	 * @since		3.0.2
	 * @see			form_definition::field()
	 */
	protected function field( $name = null, $type = null )
	{
		$class	=	str_replace('[', '', str_replace(']', '', $this->name ) );
		
		// Add the js / css to the header
		$this->add_javascript( $class );
		
		$name	=	$this->name . ( $this->array ? '[]' : '' );
		$args	=	$this->get_arguments();
		
		$field	=	'<div class="toggle tog-'.$class.'" data-enabled="ENABLED" data-disabled="DISABLED" data-toggle="toggle">'
				.	form_hidden( $name, set_value( $this->name, '0' ) )
				.	form_checkbox( $name, '1', set_value( $this->name, $this->value ), $args )
				.	'<label class="check" for="'.$this->name.'"></label>'
				.	'</div>';
		
		return $field;
	}
	
	
	/**
	 * Method to get the arguments from the object
	 * @access		protected
	 * @version		3.0.12
	 *
	 * @return		string
	 * @since		3.0.2
	 * @see			form_definition::get_arguments()
	 */
	protected function get_arguments()
	{
		$args	= parent :: get_arguments();
		$check	= array( 'id' => $this->name, 'class' => 'checkbox' );
		$data	= array();
		
		// Ensure only the check args get sent
		foreach ( $args as $k => $v ) {
			if (! isset( $check[$k] ) ) continue;
			$data[$k] = $v;
		}
		
		// Cycle through and set defaults
		foreach ( $check as $k => $d ) {
			if (! isset( $data[$k] ) && ( $d !== false ) ) $data[$k] = $d;
		}
		
		// Flatten array
		$arg = null;
		foreach ( $data as $k => $v ) $arg .= "{$k}=\"{$v}\" ";
		return $arg;
	}
	
	
	/**
	 * Method to generate a label
	 * @access		protected
	 * @version		@fileVers2
	 *
	 * @return		null
	 * @since		3.0.2
	 * @see			form_definition::label()
	 */
	protected function label()
	{
		$args	= $this->labelargs;
		$args['class']	.= ' control-label';
		
		if ( $this->error ) {
			$args['class'] .= ' error';
		}
		
		return form_label( $this->translate( $this->lang ), $this->lang, $args );
	}
	
	
	/**
	 * Adds necessary info to the template header
	 * @access		protected
	 * @version		3.0.12
	 * 
	 * @since		3.0.2
	 */
	protected function add_javascript( $class )
	{
		static $data = false;
		
		$ci			= & get_instance();
			
		if (! $data ) {
			$data	= true;
			$ci->template->append_metadata( bootstrap( 'bootstrap-toggle.css' ) );
			$ci->template->append_javascript( bootstrap( 'bootstrap-toggle.js', 'js' ) );
		}
		
		$js = (! empty( $this->arguments['onclick'] ) ? $this->arguments['onclick'] : null );
		
		$javascript	=	'<script>'
					.	"jQuery('.tog-".$class."').toggle({"
					.	"onClick: function (event, status) { " . $js . " },"
					.	"    text: {"
					.	"      enabled: '{$this->text_enabled}',"
					.	"      disabled: '{$this->text_disabled}'"
					.	"    },"
					.	"    style: {"
					.	"      enabled: 'success',"
					.	"      disabled: 'danger'"
					.	"    }"
					.	"  });"
					.	'</script>';
					
		$ci->template->append_javascript( $javascript );
	}
	
	
	/**
	 * Method to set arguments to object
	 * @access		public
	 * @version		3.0.12
	 * @param		array		- $options: array from form settings
	 * 
	 * @return		array containing unset option arguments
	 * @since		3.0.2
	 * @see			form_definition::set_arguments()
	 */
	public function set_arguments( $options = array() )
	{
		$args	= array( 'text_enabled', 'text_disabled' );
		
		foreach ( $options as $key => $value ) {
			if (! in_array( $key, $args ) ) continue;
			$this->$key = $value;
			unset( $options[$key] );
		}
		
		return parent :: set_arguments( $options );
	}
}