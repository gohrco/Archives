
UPDATE IGNORE `__DBPREFIX__settings` SET `value`='3.0.5' WHERE `key` = 'Version';
