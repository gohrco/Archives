<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.12 ( $Id: mod_intlogin.php 190 2013-01-31 18:57:54Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the main file for the Integrator Login module
 *  
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.helper' );
jimport( 'joomla.application.component.helper' );

// Include the syndicate functions only once
require_once( JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_integrator' . DIRECTORY_SEPARATOR . 'integrator.class.php' );

if (! class_exists( 'intLogin' ) ) {
	
class intLogin
{
	private	$_active		= true;
	private $_error			= array();
	private	$_loggedin		= false;
	private $_ssl			= false;
	
	private	$api			= null;
	private $form			= array();
	private $gravatar		= array();
	private	$info			= array();
	private	$moduleparams	= null;
	private	$params			= null;
	private	$userobj		= null;
	
	public function __construct( $options )
	{
		// Set local values
		$this->api			= IntApi :: getInstance();
		$this->moduleparams	= ( isset( $options['params'] ) ? $options['params'] : null );
		$this->params		= JComponentHelper :: getParams( 'com_integrator' );
		$this->userobj		= JFactory :: getUser();
		$this->_loggedin	= ( $this->userobj->get( 'guest', true ) ? false : true );
		
		if (! $this->build() ) {
			$this->_active = false;
		}
		
		// Clean object
		$this->api = null;
	}
	
	
	public function getInstance( $options = array() )
	{
		static $instance = array();
		
		$reset	= ( isset( $options['force'] ) ? $options['force'] : false );
		
		$serial	= serialize( $options );
		
		if ( empty( $instance[$serial] ) || $reset ) {
			$instance[$serial] = new self( $options );
		}
		
		return $instance[$serial];
	}
	
	
	public function isLoggedin()
	{
		return (bool) $this->_loggedin;
	}
	
	
	public function isSsl( $setting = null )
	{
		if ( $setting != null ) {
			$this->_ssl = $setting;
			return $this->_ssl;
		}
		else return $this->_ssl;
	}
	
	
	public function render()
	{
		$content	= null;
		$params		= $this->moduleparams;
		$form		= (object) $this->form;
		$gravatar	= (object) $this->gravatar;
		$links		= $this->getLinks();
		
		if ( $this->isLoggedin() ) {
			$rows	= $this->getRows();
			$info	= (object) $this->info;
			$path	= JModuleHelper :: getLayoutPath( 'mod_intlogin', 'info' );
			
			if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
				JHtml :: stylesheet( 'modules/mod_intlogin/tmpl/css/info.css' );
			}
			else {
				JHtml :: stylesheet( 'info.css', $this->getCsspath() );
			}
		}
		else {
			$info = null;
			$path = JModuleHelper :: getLayoutPath( 'mod_intlogin', 'form' );
			
			if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
				JHtml :: stylesheet( 'modules/mod_intlogin/tmpl/css/form.css' );
			}
			else {
				JHtml :: stylesheet( 'form.css', $this->getCsspath() );
			}
		}
		
		ob_start();
			require $path;
			$content = ob_get_contents();
		ob_end_clean();
		
		// Now lets set the debug data
		$this->clearErrors();
		
		return $content;
	}
	
	
	/**
	 * Add error message to the local array
	 * @access		private
	 * @version		3.0.12
	 * @param		string		- $msg: the message to set
	 * @param		string		- $type:  the type of error message to use
	 * 
	 * @since		3.0.7
	 */
	private function addError( $msg, $type = 'info' )
	{
		$bt	= debug_backtrace( false );
		$bt	= $bt[0];
		
		$this->_error[]	= array( 'filename' => $bt['file'], 'message' => $msg, 'line' => $bt['line'], 'type' => $type );
		
	}
	
	
	/**
	 * Build the variables for the module to render
	 * @access		private
	 * @version		3.0.12
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	private function build()
	{
		/** 
		 * Reset URI first (J!1.7+)
		 */
		if ( version_compare( JVERSION, '1.7.0', 'ge' ) ) {
			JUri :: reset();
		}
		
		/**
		 * Now lets start by building the action
		 */
		if (! ( $inturl = $this->params->get( 'IntegratorUrl', false ) ) ) {
			$this->addError( JText::_( 'MOD_INTLOGIN_ERROR_NOINTURL' ), 'error' );
			return false;
		}
		
		if ( ( $ssl = $this->moduleparams->get( 'forcessl', false ) ) === false ) {
			$this->addError( JText::_( 'MOD_INTLOGIN_INFO_SSLNO' ), 'info' );
		}
		else {
			$suri	= JUri :: getInstance();
			$this->isSsl( $suri->isSSL() );
			$ssl	= (bool) ( $ssl == '2' ? $this->isSsl() : $ssl );
		}
		
		$uri = new JUri( $inturl );
		$uri->setPath( rtrim( $uri->getPath(), '/' ) . '/index.php/login/index' );
		$uri->setScheme( 'http' . ( $ssl ? 's' : '' ) );
		
		$this->form['action']	= $uri->toString();
		
		/**
		 * Action complete
		 * * * * * * * *
		 * Now build the return URL
		 */
		
		$mod_return_url	= $this->moduleparams->get( 'mod_return_url', null );
		
		if ( $mod_return_url ) {
			$returnuri = new JUri( $mod_return_url );
		}
		else {
			$returnuri = JUri :: getInstance();
				
			// Clear the override in case we are coming from the Integrator
			if ( $returnuri->getVar( 'override', false ) ) {
				$returnuri->delVar( 'override' );
			}
		}
		
		$this->form['return'] = base64_encode( $returnuri->toString() );
		
		/**
		 * Return URL complete
		 * * * * * * * *
		 * Now set the origin
		 */
		
		if (! ( $cnxnid = $this->params->get( 'cnxnid', false ) ) ) {
			$this->addError( JText::_( 'MOD_INTLOGIN_ERROR_NOCNXNID' ), 'error' );
			return false;
		}
		
		$this->form['origin'] = $cnxnid;
		
		/**
		 * Origin is set
		 * * * * * * * *
		 * Now retrieve the user info
		 */
		
		if ( $this->isLoggedin() && $this->moduleparams->get( 'retrieve_info', false ) ) {
			$email		= $this->userobj->get( 'email' );
			$this->info	= $this->api->get_user_info( array( 'email' => $email ) );
		}
		else if ( $this->isLoggedin() ) {
			$user = $this->userobj->getProperties();
			$this->info = array( 'fullname' => $user['name'], 'username' => $user['username'], 'email' => $user['email'] );
		}
		
		/**
		 * User info is set
		 * * * * * * * *
		 * Now set logout URL
		 */
		
		$uri = new JUri( $inturl );
		$uri->setPath( rtrim( $uri->getPath(), '/' ) . '/index.php/logout/index' );
		$uri->setScheme( 'http' . ( $ssl ? 's' : '' ) );
		
		$this->form['logout']	= $uri->toString();
		
		/**
		 * Logout URL is set
		 * * * * * * * *
		 * Build the Gravatar
		 */
		
		if ( $this->isLoggedin() ) {
			$this->gravatar	= $this->getGravatar( $this->info['email'], $this->moduleparams->get( 'grav_size', '80' ), $this->moduleparams->get( 'grav_default', 'mm' ), 'g', true );
		}
		
		return true;
	}
	
	
	/**
	 * Clears the errors from the object, stashing them in the debug object
	 * @access		private
	 * @version		3.0.12
	 * 
	 * @since		3.0.7
	 */
	private function clearErrors()
	{
		$errors	=   $this->_error;
		$debug	= & IntDebug :: getInstance();
		
		if ( empty( $errors ) || ! is_array( $errors ) ) return;
		
		$debug->add_array( $errors );
		
		$this->_error = array();
	}
	
	
	private function getCsspath()
	{
		$app	= & JFactory::getApplication();
		
		// Build the template and base path for the layout
		$tPath	= JPATH_BASE . DIRECTORY_SEPARATOR
				. 'templates' . DIRECTORY_SEPARATOR 
				. $app->getTemplate() . DIRECTORY_SEPARATOR 
				. 'html' . DIRECTORY_SEPARATOR 
				. 'mod_intlogin' . DIRECTORY_SEPARATOR;
		
		$tUrl	= 'templates/' . $app->getTemplate() . '/html/mod_intlogin/';
		$bUrl	= 'modules/mod_intlogin/tmpl/css/';
		
		// If the template has a layout override use it
		if (file_exists($tPath)) {
			return $tUrl;
		} else {
			return $bUrl;
		}
	}
	
	
	/**
	 * Get either a Gravatar URL or complete image tag for a specified email address.
	 *
	 * @param string $email The email address
	 * @param string $s Size in pixels, defaults to 80px [ 1 - 512 ]
	 * @param string $d Default imageset to use [ 404 | mm | identicon | monsterid | wavatar ]
	 * @param string $r Maximum rating (inclusive) [ g | pg | r | x ]
	 * @param boole $img True to return a complete IMG tag False for just the URL
	 * @param array $atts Optional, additional key/value attributes to include in the IMG tag
	 * @return String containing either just a URL or a complete image tag
	 * @source http://gravatar.com/site/implement/images/php/
	 */
	private function getGravatar( $email, $s = 80, $d = 'mm', $r = 'g', $img = false, $atts = array() )
	{
		$user	= & $this->userobj;
		
		if (! is_null( $enable = IntegratorHelper :: get( 'dg' ) ) ) {
			$user->setParam( 'display_gravatar', $enable );
			$user->save();
		}
		
		if ( $user->defParam( 'display_gravatar', '2' ) == '2' ) {
			defined( 'INTEGRATOR_API' ) or define( 'INTEGRATOR_API', true );
			$user->setParam( 'display_gravatar', false );
			$user->save();
		}
		
		$uri	= JUri::getInstance();
		if ( JRequest :: getVar( 'option' ) == 'com_integrator' && JRequest :: getVar( 'override' ) == '1' ) {
			$uri->setVar( 'override', '0' );
		}
		$uri->setVar( 'dg', ( $user->getParam( 'display_gravatar', false ) ? '0' : '1' ) );
		$option	= $uri->toString();
		
		if ( $user->getParam( 'display_gravatar', true ) == false ) {
			$email = 'donotdisplay@localhost.com';
		}
		
		$mode	 = $this->isSsl();
		$url	 = 'http' . ( $mode == true ? 's://secure' : '://www' ) . '.gravatar.com/avatar/';
		$url	.= md5( strtolower( trim( $email ) ) );
		$url	.= "?s=$s&d=$d&r=$r";
		
		if ( $img ) {
			$url = '<img src="' . $url . '"';
			foreach ( $atts as $key => $val )
				$url .= ' ' . $key . '="' . $val . '"';
			$url .= ' />';
		}
		
		return array( 'url' => $url, 'option' => $option, 'enabled' => $user->getParam( 'display_gravatar', false ) );
	}
	
	
	private function getLinks()
	{
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$usersConfig = JComponentHelper::getParams('com_users');
			$links	= array(	'reset'		=> 'index.php?option=com_users&view=reset',
								'username'	=> 'index.php?option=com_users&view=remind',
								'register'	=> 'index.php?option=com_users&view=registration',
								'allowed'	=> $usersConfig->get( 'allowUserRegistration' )
			);
		}
		else {
			$userConfig = JComponentHelper::getParams('com_users');
			$links	= array(	'reset'		=> 'index.php?option=com_user&view=reset',
								'username'	=> 'index.php?option=com_user&view=remind',
								'register'	=> 'index.php?option=com_user&task=register',
								'allowed'	=> $userConfig->get( 'allowUserRegistration' )
			);
		}
		
		return (object) $links;
	}
	
	
	private function getRows()
	{
		$info	= $this->info;
		$data	= array();
		
		// Be sure we use the local userobj
		$info['username'] = empty( $info['username'] ) ? $this->userobj->get( 'username' ) : $info['username'];
		
		if ( $this->moduleparams->get( 'name', 1 ) == '0' ) {
			$data['name']	= array( 'username' );
		}
		else {
			$data['name']	= (! empty( $info['fullname'] ) ) ? array( 'fullname' ) : array( 'firstname', 'lastname' );
		}
		
		if (! empty( $info['companyname'] ) ) $data['company'] = array( 'companyname' );
		
		if ( $this->moduleparams->get( 'name', 1 ) == '0' ) {
			$data['user'] = array( 'email' );
		}
		else {
			$data['user'] = array( 'email' );
			$data['usr1'] = array( 'username' );
		}
		
		$data['add1']	= array( 'address1' );
		$data['add2']	= array( 'address2' );
		$data['add3'] = array( 'city', 'state', 'postal' );
		$data['add4'] = array( 'country' );
		
		$this->info = $info;
		return $data;
	}
}

}

$intlogin	= intLogin :: getInstance( array( 'params' => $params ) );

echo $intlogin->render();