<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.12 ( $Id: integrator.php 190 2013-01-31 18:57:54Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the main file for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die('Restricted access');

// Require the base controller
require_once (JPATH_COMPONENT . DIRECTORY_SEPARATOR . 'controller.php');
require_once( JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'class.api.php' );
require_once( JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'helper.php' );
include_once( JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_integrator' . DS . 'integrator.class.php' );

// Require specific controller if requested
$controller = JRequest::getWord('controller', 'default');
require_once (JPATH_COMPONENT . DIRECTORY_SEPARATOR . 'controllers' . DIRECTORY_SEPARATOR . $controller.'.php');

// Create the controller
$classname	= 'IntegratorController'.$controller;
$controller = new $classname();

// Perform the Request task
$controller->execute( JRequest::getWord('task'));

// Redirect if set by the controller
$controller->redirect();