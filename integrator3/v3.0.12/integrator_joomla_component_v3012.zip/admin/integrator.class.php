<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.12 ( $Id: integrator.class.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       Helper class file establishing global functions for use through out by plugins and component
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or exit('No direct script access allowed');
/*-- Security Protocols --*/

/*-- File Inclusions --*/
require_once( 'class.api.php' );
require_once( 'class.debug.php' );
require_once( 'helper.php' );
/*-- File Inclusions --*/

/**
 * Builds a user array
 * @version		3.0.12
 * @param		array		- $newuser: the updated user array to use
 * @param		array		- $olduser: the previous user array if applicable
 * @param		boolean		- $is_new: true if new
 * @param		string		- $direction: indicates if the user array is coming from Integrator or going to the Integrator (default = to)
 * 
 * @return		array containing user array
 * @since		3.0.0
 */
if (! function_exists( 'build_user_array' ) ) {
	function build_user_array( $newuser, $olduser, $is_new, $direction = 'to' )
	{
		$data	= array();
		$check	= array( 'email', 'username', 'name', 'block' );
		
		if ( $is_new ) {
			foreach ( $check as $c ) {
				if ( empty( $newuser[$c] ) || (! isset( $newuser[$c] ) ) ) continue;
				$data[$c] = $newuser[$c];
			}
			
			if ( $newuser['password'] == $newuser['password2'] ) {
				$data['password'] = $newuser['password'];
			}
			elseif ( (! empty( $newuser['password_clear'] ) ) ) {
				$data['password'] = $newuser['password_clear'];
			}
		}
		else {
			foreach ( $check as $c ) {
				if (! isset( $newuser[$c] ) ) continue;
				if ( empty( $newuser[$c] ) && $newuser[$c] != '0' ) continue;
				$data['update'][$c] = $newuser[$c];
			}
			
			if ( (! empty( $newuser['password_clear'] ) ) ) {
				$data['update']['password'] = $newuser['password_clear'];
			}
			else if ( (! empty( $newuser['password'] ) ) && (! empty( $newuser['password2'] ) ) && ( $newuser['password'] == $newuser['password2'] ) ) {
				$data['update']['password'] = $newuser['password'];
			}
			
			
			$data['email']		= $olduser['email'];
			$data['username']	= $olduser['username'];
			$data['block']		= $olduser['block'];
		}
		
		return $data;
	}
}


if (! function_exists( 'debug' ) ) {
	function debug( $message = null, $type = 'info', $translate = true, $use = 0 )
	{
		$bt = debug_backtrace();
		$bt = $bt[$use];
		
		$filename	= ( isset( $bt['file'] ) ? $bt['file'] : 'file not known' );
		$line		= ( isset( $bt['line'] ) ? $bt['line'] : 'unknown' );
		
		// Depending on environmental setting, show full path or not
		if (! JDEBUG ) {
			$filename = str_replace( '\\', '/', $filename );
			if (FALSE !== strpos( $filename, '/' ) ) {
				$x = explode('/', $filename );
				$filename = $x[count($x)-2].'/'.end($x);
			}
		}
		
		$debug	= & IntDebug::getInstance();
		$debug->add( $message, $filename, $line, $type, $translate );
	}
}


/**
 * Checks to see if a username is actually an email address
 * @version		3.0.12
 * @param		string		- @username: contains either a username or email address to check
 * 
 * @return		boolean true if email found
 * @since		3.0.0
 */
if (! function_exists ( 'is_email' ) ) {
	function is_email( $username) {
		$pattern = "/\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,5}\b/i";
		$match = preg_match( $pattern, $username );
		
		return ( $match > 0 );
	}
}

?>