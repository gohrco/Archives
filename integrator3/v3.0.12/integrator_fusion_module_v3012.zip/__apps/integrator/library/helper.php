<?php


/**
 * Creates an encoded session hash for transmittal
 * @version		3.0.12
 * @param		string		- $name: the session name
 * @param		string		- $id: the session id
 * 
 * @return		string containing hashed array
 * @since		3.0.0
 */
if (! function_exists( 'MY_session_encode' ) ) {
function MY_session_encode( $name, $id )
{
	$SWIFT = SWIFT :: GetInstance();
	
	// Initialize items
	$salt			=   mt_rand();
	$secret			=   $SWIFT->Settings->Get( 'integrator_apisecret' );
	$string			=   null;
	$data			=   null;
	$encode			=   null;
	
	// Create base array
	$serial	= serialize( array( 'id' => $id, 'name' => $name ) );
	$key	= md5( $secret . $salt );
	
	for ( $i = 0; $i < strlen( $serial ); $i++ ) {
		$string .= substr( $key, ( $i % strlen( $key ) ), 1 ) . ( substr( $key, ( $i % strlen( $key ) ), 1 ) ^ substr( $serial, $i, 1 ) );
	}
	
	for ( $i = 0; $i < strlen( $string ); $i++ ) {
		$data .= substr( $string, $i, 1 ) ^ substr( $key, ( $i % strlen( $key ) ), 1 );
	}
	
	// Create array and encode
	$encode	= array( 'data' => base64_encode( $data ), 'salt' => $salt );
	$encode = serialize( $encode );
	$encode = base64_encode( $encode );
	$encode = md5( $salt . $secret ) . $encode;
	$encode = strrev( $encode );
	
	return $encode;
}
}


/**
 * Creates a quick form redirection to send back to the Integrator securely
 * @access		private
 * @version		3.0.12
 * @param		string		- $url: the form action to send to
 * @param		array		- $fields: hidden fields to send
 * 
 * @since		3.0.0
 */
if (! function_exists( 'MY_form_redirect' ) ) {
function MY_form_redirect( $url = null, $fields = array() )
{
	$field = null;
	foreach ( $fields as $name => $value ) {
		$field .= "<input type='hidden' name='{$name}' value='{$value}' />";
	}
	
	$output = <<< OUTPUT
<form action="{$url}" method="post" name="frmlogin" id="frmlogin">
		{$field}
</form>
<script language="javascript"><!--
setTimeout ( "autoForward()", 0 );
function autoForward() {
	document.forms['frmlogin'].submit()
}
//--></script>
OUTPUT;
		exit ( $output );
}
}