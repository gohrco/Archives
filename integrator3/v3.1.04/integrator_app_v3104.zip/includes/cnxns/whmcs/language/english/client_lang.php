<?php
/**
 * Integrator 3
*
* @package    Integrator 3
* @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
* @license    GNU General Public License version 2, or later
* @version    3.1.04 ( $Id: admin_lang.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
* @author     Go Higher Information Services, LLC
* @since      3.0.0
*
* @desc       This is the English language file for the Joomla admin controller pages for the Integrator
*
*/

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


// ===================================================================
// 	Clientarea Page (user/info)
// ===================================================================
//		v 3.0.2
// -------------------------------------------------------------------
$lang['whmcs_api.invoices.header']			= 'Invoices';
$lang['whmcs_api.invoices.headerlink']		= 'View All Invoices';
$lang['whmcs_api.invoices.column.invnum']	= 'Inv #';
$lang['whmcs_api.invoices.column.invdate']	= 'Invoice Date';
$lang['whmcs_api.invoices.column.duedate']	= 'Due Date';
$lang['whmcs_api.invoices.column.total']	= 'Total';
$lang['whmcs_api.invoices.column.status']	= 'Status';
$lang['whmcs_api.invoices.column.viewinv']	= 'View Invoice';

$lang['whmcs_api.tickets.header']			= 'Support Tickets';
$lang['whmcs_api.tickets.headerlink']		= 'View All Tickets';
$lang['whmcs_api.tickets.column.tktdate']	= 'Date';
$lang['whmcs_api.tickets.column.dept']		= 'Department';
$lang['whmcs_api.tickets.column.subject']	= 'Subject';
$lang['whmcs_api.tickets.column.status']	= 'Status';
$lang['whmcs_api.tickets.column.updated']	= 'Last Updated';
$lang['whmcs_api.tickets.column.viewtkt']	= 'View Ticket';

