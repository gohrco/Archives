<?php defined('DUNAMIS') OR exit('No direct script access allowed');
/**
 * Integrator 3
 * Integrator 3 - Default Module Base File
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.04 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This file is the default controller
 *
 */


/**
 * Define the Integrator3 version here
 */
if (! defined( 'DUN_MOD_INTEGRATOR' ) ) define( 'DUN_MOD_INTEGRATOR', "3.1.04" );

/**
 * Default Module Class for Integrator 3
 * @version		3.1.04
 *
 * @author		Steven
 * @since		3.1.00
 */
class IntegratorApiDunModule extends WhmcsDunModule
{
	/**
	 * Provide means to check for file integrity
	 * @access		protected
	 * @var			string
	 * @since		3.1.00
	 */
	protected $checkstring	=	"@checkString@";
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.1.04 ( $id$ )
	 *
	 * @since		3.1.00
	 */
	public function __construct()
	{
		$this->area	=	'api';
		parent :: __construct();
	}
	
	/**
	 * Initialise the object
	 * @access		public
	 * @version		3.1.04
	 *
	 * @since		3.1.00
	 */
	public function initialise()
	{
		static $instance = false;
	
		if (! $instance ) {
			dunloader( 'language', true )->loadLanguage( 'integrator' );
			dunloader( 'helpers', 'integrator' );
			
			$instance	=	true;
		}
		
		global $task;
		
		if ( $task ) {
			$this->task = $task;
		}
	}
	
	/**
	 * Method to execute tasks
	 * @access		public
	 * @version		3.1.04
	 * @param		string		- $task: if we are passing a specific task to do
	 * 
	 * @since		3.1.00
	 */
	public function execute()
	{
		// Be sure we can do what we are being asked of us
		if (! method_exists( $this, $this->task ) ) {
			return false;
		}
		
		$task	=	$this->task;
		return $this->$task();
	}
	
	
	
	/**
	 * Method to get information about this module
	 * @access		public
	 * @version		3.1.04
	 * 
	 * @return		array 
	 * @since		3.1.00
	 */
	public function get_info()
	{
		return array( 'cnxns|whmcs' => DUN_MOD_INTEGRATOR );
	}
	
	
	/**
	 * Method for getting languages from WHMCS
	 * @access		public
	 * @version		3.1.04 ( $id$ )
	 *
	 * @return		array
	 * @since		3.1.00
	 */
	public function get_languages()
	{
		if (! defined ( "ROOTDIR" ) ) {
			define( "ROOTDIR", dirname( dirname( dirname( dirname( __FILE__ ) ) ) ) );
		}
		
		$rows	= array();
		$d = dir ( ROOTDIR . DIRECTORY_SEPARATOR . "lang" );
		
		while ( false !== ( $file = $d->read() ) ) {
			if ( in_array( $file, array( ".", ".." ) ) ) continue;
			if (is_dir( ROOTDIR . DIRECTORY_SEPARATOR . "lang" . DIRECTORY_SEPARATOR . $file ) ) continue;
			if ( strpos( $file, ".php" ) === false ) continue;
			$file = substr( $file, 0, -4 );
			$rows[$file] = $file;
		}
		
		$d->close();
		return $rows;
	}
	
	
	/**
	 * Method to retrieve the page listing from WHMCS
	 * @access		public
	 * @version		3.1.04
	 *
	 * @return		array
	 * @since		3.1.00
	 */
	public function get_pages()
	{
		$config	=	dunloader( 'config', 'integrator' );
		$data	=	array();
		$pages	=	$config->get( 'pages' );
		
		foreach ( explode( "\r\n", $pages ) as $row ) {
			$row	=	trim( $row );
			if (! $row ) continue;
			
			$parts	=	explode( "::", $row );
			if (! $parts[0] || ! $parts[1] ) continue;
			
			$parts[1]			=	str_replace( ".php", '-', str_replace( ".php?", '-', str_replace( "=", '-', str_replace( "&", '-', $parts[1] ) ) ) );
			$data[$parts[1]]	=	$parts[0];
		}
		
		asort( $data );
		
		return $data;
	}
	
	
	/**
	 * Method for getting a price from WHMCS
	 * @access		public
	 * @version		3.1.04
	 *
	 * @return		array
	 * @since		2.5.12
	 */
	public function getprice()
	{
		$db		=	dunloader( 'database', true );
		$input	=	dunloader( 'input', true );
		$price	=	explode( ",", $input->getVar( 'price' ) );
		
		switch( $input->getVar( 'by' ) ):
		case 'id':
			$query	=	"SELECT p.`{$price[2]}` as  `value`, c.`prefix`, c.`suffix` "
					.	"FROM tblpricing p INNER JOIN tblcurrencies c ON p.currency=c.id "
					.	"WHERE p.`type` = '{$price[0]}' AND p.`relid` = {$price[1]} AND UPPER( c.`code` )='{$price[3]}'";
			break;
		case 'name':
		
			$ret = 'name';
		
			switch($price[0]):
			case 'product':
				$tbl = 'tblproducts';
				break;
			case 'addon':
				$tbl = 'tbladdons';
				break;
			case 'configoptions':
				$tbl = 'tblproductconfigoptions';
				break;
			default:
				$tbl = 'tbldomainpricing';
				$ret = 'extension';
				break;
			endswitch;
			
			$query	=	"SELECT p.`{$price[2]}` as `value`, c.`prefix`, c.`suffix` "
					.	"FROM tblpricing p INNER JOIN {$tbl} as n ON n.id = p.relid INNER JOIN tblcurrencies c ON p.currency=c.id "
					.	"WHERE p.type = '{$price[0]}' AND n.{$ret} = '{$price[1]}' AND UPPER( c.`code` )='{$price[3]}'";
		
			break;
		endswitch;
		
		$db->setQuery( $query );
		$result	=	$db->loadAssoc();
		
		return $result;
	}
	
	
	/**
	 * Method for getting a username from WHMCS
	 * @access		public
	 * @version		3.1.04 ( $id$ )
	 *
	 * @return		string
	 * @since		3.1.00
	 */
	public function getusername()
	{
		$input		=	dunloader( 'input', true );
		$config		=	dunloader( 'config', 'integrator' );
		$db			=	dunloader( 'database', true );
		$wapi		=	dunloader( 'whmcsapi', 'integrator' );
		$email		=	$input->getVar( 'email', null );
		$client		=	$wapi->finduserdetails( $email, 'email' );
		
		switch ( $config->get( 'userstyle' ) ) :
		// Username is built
		case '1' :
			
			$username	=	build_username( $client );
			
			break;
		// Username is stored
		case '2' :
			
			$username	=	find_username( $client->userid );
			
			if (! $username ) {
				$username	=	build_username( $client );
			}
			
			break;
		endswitch;
		
		return $username;
	}
	
	
	/**
	 * Method to verify connection
	 * @access		public
	 * @version		3.1.04
	 * 
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function ping()
	{
		return true;
	}
	
	
	/**
	 * Method for searching the WHMCS knowledgebase
	 * @access		public
	 * @version		3.1.04 ( $id$ )
	 *
	 * @return		array
	 * @since		3.1.00
	 */
	public function searchknowledgebase()
	{
		$db		=	dunloader( 'database', true );
		$input	=	dunloader( 'input', true );
		$config	=	dunloader( 'config', true );
		$isseo	=	( $config->get( 'SEOFriendlyUrls' ) ? true : false );
		
		$text	=	$input->getVar( 'text' );
		$type	=	$input->getVar( 'type' );
		$order	=	$input->getVar( 'order' );
		
		// Process our text
		if ( $type == 'exact' ) {
			$search	=	"( title LIKE '%{$text}%' OR article LIKE '%{$text}%' )";
		}
		else {
			$parts	=	explode( ' ', $text );
			$search	=	array();
			
			foreach ( $parts as $part ) {
				$search[]	=	"( title LIKE '%{$part}%' OR article LIKE '%{$part}%' )";
			}
			
			if ( $type == 'any' ) {
				$search	=	implode( ' OR ', $search );
			}
			else {
				$search	=	implode( ' AND ', $search );
			}
		}
		
		// Process our order
		switch ( $order ) :
		case 'alpha' :
			$ordering	=	"ORDER BY `title` ASC";
			break;
		case 'category' :
			$ordering	=	"ORDER BY `c`.`name` ASC, `order` ASC,`title` ASC";
			break;
		case 'popular' :
			$ordering	=	"ORDER BY `votes` ASC";
			break;
		default:
			$ordering	=	"ORDER BY `order` ASC,`title` ASC";
			break;
		endswitch;
		
		$data	=	array();
		$query	=	"SELECT * FROM tblknowledgebase k INNER JOIN tblknowledgebaselinks l ON l.articleid = k.id INNER JOIN tblknowledgebasecats c ON c.id = l.categoryid WHERE {$search} {$ordering}";
		$db->setQuery( $query );
		
		foreach( $db->loadObjectList() as $row ) {
			
			if ( $row->hidden == 'on' ) continue;
			
			$article	=	array(
				'id'		=>	$row->id,
				'title'		=>	htmlentities( $row->title ),
				'article'	=>	strip_tags( $row->article ),
				'category'	=>	$row->name,
				'catid'		=>	$row->categoryid,
				'views'		=>	$row->views,
				'votes'		=>	$row->votes,
				'useful'	=>	$row->useful,
				'seotitle'	=>	getModRewriteFriendlyString( $row->title ),
				'isseo'		=>	$isseo,
				'query'		=>	$query,
				
			);
			
			$data[]	=	$article;
			
		}
		
		return $data;
	}
	
	
	/**
	 * Method for updating settings on WHMCS
	 * @access		public
	 * @version		3.1.04 ( $id$ )
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function update_settings()
	{
		$input		=	dunloader( 'input', true );
		$config		=	dunloader( 'config', 'integrator' );
		
		$data		=	$input->getVar( 'data', array(), 'post', 'array' );
		
		$map		=	array(
				'enable'				=>	'enable',
				'debug'					=>	'debug',
				'token'					=>	'apitoken',
				'enableuserbridging'	=>	'userenable',
				'languageenable'		=>	'languageenable',
				'regmethod'				=>	'regmethod',
				);
		
		if ( empty( $data ) ) return false;
		
		foreach ( $data as $key => $value ) {
			$use	=	$map[$key];
			$config->set( $use, $value );
			
			if ( $use == 'debug' ) {
				$dcon	=	dunloader( 'config', 'dunamis' );
				$dcon->set( $use, $value );
				$dcon->save();
			}
		}
		
		if (! $config->save() ) {
			return false;
		}
		
		return true;
	}
	
	
	/**
	 * User search functionality - b/c WHMCS doesn't search properly
	 * @access		public
	 * @version		3.1.04
	 *
	 * @since		3.0.20
	 */
	public function user_search()
	{
		$db			=	dunloader( 'database', true );
		$input		=	dunloader( 'input', true );
		
		$search		=	$input->getVar( 'search', null );
		$limitstart	=	$input->getVar( 'limitstart', '0' );
		$limitnum	=	$input->getVar( 'limitstart', '25' );
		
		if (! $limitnum ) $limitnum = '25';
		if (! $limitstart && $limitstart != '0' ) $limitstart = '0';
		
		$query	=	"SELECT SQL_CALC_FOUND_ROWS id, firstname, lastname, companyname, email, groupid, datecreated, status FROM tblclients WHERE email LIKE '%" . $search . "%' OR firstname LIKE '%" . $search . "%' OR lastname LIKE '%" . $search . "%' OR companyname LIKE '%" . $search . "%' ORDER BY firstname, lastname, companyname LIMIT " . (int)$limitstart . ", " . (int)$limitnum;
		$db->setQuery( $query );
		$result	=	$db->loadObjectList();
		
		$db->setQuery( "SELECT FOUND_ROWS()" );
		$total	=	$db->loadResult();
		
		$apiresults	=	array(
				"totalresults"	=>	$total,
				"startnumber"	=>	$limitstart,
				"numreturned"	=>	count( $result )
		);
	
		foreach ( $result as $item ) {
			$apiresults["clients"]["client"][] = array(
					"id"			=>	$item->id,
					"firstname"		=>	$item->firstname,
					"lastname"		=>	$item->lastname,
					"companyname"	=>	$item->companyname,
					"email"			=>	$item->email,
					"datecreated"	=>	$item->datecreated,
					"groupid"		=>	$item->groupid,
					"status"		=>	$item->status
			);
		}
	
		return $apiresults;
	}
	
	
	/**
	 * Method for updating a username in WHMCS
	 * @access		public
	 * @version		3.1.04 ( $id$ )
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function updateusername()
	{
		$input		=	dunloader( 'input', true );
		$config		=	dunloader( 'config', 'integrator' );
		$db			=	dunloader( 'database', true );
		
		// Bail if we don't need to worry about it
		if ( $config->get( 'userstyle' ) != '2' ) return true;
		
		// Pull the customfield id first
		if (! ( $fieldid = get_custom_field_id( $config->get( 'usernamefield' ) ) ) ) {
			return false;
		}
		
		//$db->setQuery( "SELECT `id` FROM `tblcustomfields` WHERE `type` = 'client' AND `fieldname` = " . $db->Quote( $config->get( 'usernamefield' ) ) );
		//if (! ( $fieldid = $db->loadResult() ) )  return false;
		
		// Next search to see if we have the field set already
		$where	=	" WHERE `fieldid` = " . $db->Quote( $fieldid ) . " AND `relid` = " . $db->Quote( $input->getVar( 'clientid' ) );
		$db->setQuery( "SELECT 1 FROM `tblcustomfieldsvalues` " . $where );
		
		if ( $db->loadResult() ) {
			$query	=	"UPDATE `tblcustomfieldsvalues` SET `value` = " . $db->Quote( $input->getVar( 'username2' ) ) . $where;
		}
		else {
			$query	=	"INSERT INTO `tblcustomfieldsvalues` ( `relid`, `fieldid`, `value` ) VALUES ( " . $db->Quote( $input->getVar( 'clientid' ) ) . ", " . $db->Quote( $fieldid ) . ", " . $db->Quote( $input->getVar( 'username2' ) ) . " )";
		}
		
		$db->setQuery( $query );
		
		if (! $db->query() ) {
			return false;
		}
		
		return true;
	}
	
	
	/**
	 * Validate a password 
	 * @access		public
	 * @version		3.1.04
	 *
	 * @return		void
	 * @since		3.1.00
	 */
	public function validate_password()
	{
		$input	=	dunloader( 'input', true );
		$data		=	$input->getVar( 'data', array(), 'post', 'array' );
		
		if (! isset( $data['password2'] ) || $data['password2'] == null || $data['password2'] == '' ) {
			return array( 'result' => 'error', 'data' => 'No password sent or found' );
		}
		
		$wconf		=	dunloader( 'config', true );
		$pwstrength	=	$wconf->get( 'RequiredPWStrength' );
		$sentpw		= $this->_calculate_password_strength( $data['password2'] );
		
		if ( $sentpw < $pwstrength ) {
			return array( 'result' => 'error', 'data' => sprintf( 'Password not strong enough ( %s < %s )', $sentpw, $pwstrength ) );
		}
	
		return array( 'result' => 'success', 'data' => sprintf( 'Password strong enough! ( %s >= %s )', $sentpw, $pwstrength ) );
	}
	
	
	/**
	 * Calculates the password strength of a given password
	 * @access		private
	 * @version		3.1.04
	 * @param		string		- $pw: contains the new password
	 *
	 * @return		integer containing the calculated strength
	 * @since		3.1.00
	 */
	private function _calculate_password_strength( $pw )
	{
		// String Length
		$pwlength = strlen($pw);
		if ( $pwlength > 5 ) $pwlength = 5;
	
		// How many numbers
		$numnumeric = preg_replace( "/[0-9]/", "", $pw );
		$numeric = strlen( $pw ) - strlen( $numnumeric );
		if ( $numeric > 3 ) $numeric = 3;
	
		// How many symbols
		$symbols = preg_replace( "/\W/", "", $pw );
		$numsymbols = strlen( $pw ) - strlen( $symbols );
		if ( $numsymbols > 3 ) $numsymbols = 3;
	
		// How many uppercase
		$numupper = preg_replace( "/[A-Z]/", "", $pw );
		$upper = strlen( $pw ) - strlen( $numupper );
		if ( $upper > 3 ) $upper = 3;
	
		// Calculate password strength
		$pwstrength = ( ( $pwlength * 10 ) - 20 ) + ( $numeric * 10 ) + ( $numsymbols * 15 ) + ( $upper * 10 );
	
		// Keep strength between 0 and 100 and return
		if ( $pwstrength < 0 ) $pwstrength = 0;
		if ( $pwstrength > 100 ) $pwstrength = 100;
		return $pwstrength;
	}
}