function updatepages( selectedpagegroup, fieldname, selectedpage )
{
	var pagelist	=	jQuery( '#' + fieldname );
	var isgroup		=	false;
	
	pagelist.children().remove('optgroup').remove('option');
	
	for ( i=0; i < pages[selectedpagegroup].length; i++ ) {
		var text	= pages[selectedpagegroup][i].split("|")[0];
		var value	= pages[selectedpagegroup][i].split("|")[1];
		
		if ( value ) {
			if ( value == selectedpage ) {
				pagelist.append('<option value="' + value + '" selected="selected">' + text + '</option>' );
			}
			else { 
				pagelist.append('<option value="' + value + '">' + text + '</option>' );
			}
		}
		else {
			if ( isgroup )
			pagelist.append('</optgroup>');
			pagelist.append('<optgroup label="' + text + '">');
			isgroup = true;
		}
	}
	
	if ( isgroup ) {
		pagelist.append('</optgroup>');
	}
}