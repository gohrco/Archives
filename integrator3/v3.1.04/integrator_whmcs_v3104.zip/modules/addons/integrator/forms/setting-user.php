<?php


$form	= array(
		'userenable'		=> array(
				'order'			=> 10,
				'type'			=> 'toggleyn',
				'value'			=> true,
				'validation'	=> '',
				'labelon'		=> 'integrator.form.toggleyn.enabled',
				'labeloff'		=> 'integrator.form.toggleyn.disabled',
				'label'			=> 'integrator.admin.form.settings.label.userenable',
				'description'	=> 'integrator.admin.form.settings.description.userenable',
		),
		'regmethod'		=> array(
				'order'			=> 30,
				'type'			=> 'togglebtn',
				'value'			=> '',
				'validation'	=> '',
				'options'		=> array(
						array( 'id' => 0, 'name' => 'integrator.regmethod.0.integrator' ),
						array( 'id' => 1, 'name' => 'integrator.regmethod.1.whmcs' ),
						array( 'id' => 2, 'name' => 'integrator.regmethod.2.customurl' ),
				),
				'label'			=> 'integrator.admin.form.settings.label.regmethod',
				'description'	=> 'integrator.admin.form.settings.description.regmethod'
		),
		'regmethodoptn0'	=> array(	'order'	=> 31, 'class'	=> 'well well-small', 'type'	=> 'wrapo' ),
		'register_cnxn_id'	=> array(	'order'	=> 32, 'type'	=> 'cnxnlist',
				'value'			=> '',
				'label'			=> 'integrator.register_cnxn_id.label',
				'description'	=> 'integrator.register_cnxn_id.desc',
				'target'		=> 'register_page',
		),
		'register_page'		=> array(	'order'	=> 33, 'type'	=> 'dropdown',
				'value'			=> '',
				'label'			=> 'integrator.register_page.label',
				'description'	=> 'integrator.register_page.desc'
		),
		'regmethodoptn0c'	=> array(	'order'	=> 34,	'type'	=> 'wrapc' ),
		'regmethodoptn2'	=> array(	'order'	=> 37, 'class'	=> 'well well-small', 'type'	=> 'wrapo' ),
		'register_customurl'=> array(	'order'	=> 38,	'type'	=> 'text',
				'value'			=> null,
				'label'			=> 'integrator.register_customurl.label',
				'description'	=> 'integrator.register_customurl.desc',
		),
		'regmethodoptn2c'	=> array(	'order'	=> 39, 'type'	=> 'wrapc' ),
		/*'userfield'	=>	array(
				'order'			=>	40,
				'type'			=>	'customclientfield',
				'value'			=>	null,
				'validation'	=>	'',
				'label'			=>	'integrator.userfield.label',
				'description'	=>	'integrator.userfield.desc',
		),*/
		'clientclose'		=> array(
				'order'			=> 50,
				'type'			=> 'togglebtn',
				'value'			=> '',
				'validation'	=> '',
				'options'		=> array(
						array( 'id' => 0, 'name' => 'integrator.clientclose.disable' ),
						array( 'id' => 1, 'name' => 'integrator.clientclose.delete' ),
				),
				'label'			=> 'integrator.clientclose.label',
				'description'	=> 'integrator.clientclose.desc'
		),
	);
