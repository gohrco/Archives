<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.04 ( $Id: view.html.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This file renders the default view to the admin user
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.view' );
/*-- File Inclusions --*/

/**
 * IntegratorViewDefault class object
 * @version		3.1.04
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntegratorViewDefault extends IntegratorViewExt
{
	
	/**
	 * Displays the backend to the user
	 * @access		public
	 * @version		3.1.04
	 * @param		string		- $tpl: template name (unused)
	 * 
	 * @since		3.0.0
	 */
	public function display($tpl = null)
	{
		$toolbar			=	dunloader( 'toolbar',	'com_integrator' );
		$document			=	dunloader( 'document',	'com_integrator' );
		
		$model				=	$this->getModel();
		$this->status		=   $this->get( 'Status' );
		
		if ( $this->status === true ) {
			$model->updateSettings();
		}
		
		$toolbar->title( 'default' );
		$toolbar->add( 'default' );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			$document->addMedia( 'com_integrator/admin-3x/css' );
		}
		else {
			$document->addMedia( 'com_integrator/admin/css' );
		}
		
		$this->debug		=   $this->get( 'Debug' );
		
		parent::display($tpl);
	}
}