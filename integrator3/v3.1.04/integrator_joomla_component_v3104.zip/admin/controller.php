<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.04 ( $Id: controller.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This is the main controller file for the backend of the Integrator
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.controller');
/*-- File Inclusions --*/


/**
 * Integrator Controller class object
 * @version		3.1.04
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntegratorController extends IntegratorControllerExt
{
	
	/**
	 * Displays the backend to the user
	 * @access		public
	 * @version		3.1.04
	 * 
	 * @since		3.0.0
	 */
	public function display( $cachable = false, $urlparams = array() )
	{
		// If the view hasn't been set, set it to default
		if ( is_null( IntegratorHelper :: get ( 'controller', null ) ) ) {
			IntegratorHelper :: set ( 'controller', 'default' );
		}
		
		if ( is_null( IntegratorHelper :: get ( 'view', null ) ) ) {
			IntegratorHelper :: set ( 'view', IntegratorHelper :: get ( 'controller', 'default' ) );
		}
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			IntegratorHelper :: set( 'layout', 'default35' );
		}
		else {
			IntegratorHelper :: set( 'layout', 'default' );
		}
		
		// Call up the parent display task
		parent::display( $cachable, $urlparams );
	}
}