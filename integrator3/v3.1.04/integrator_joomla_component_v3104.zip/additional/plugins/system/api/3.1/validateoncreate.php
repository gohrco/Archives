<?php
/**
 * Integrator 3 - System Plugin
 * 		Validateoncreate File
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.04 ( $Id$ )
 * @since      3.1.02
 *
 * @desc       This is the Validate on Create Task which validates information upon creation for I3
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

jimport( 'joomla.filesystem.folder' );
jimport( 'joomla.filesystem.file' );
jimport( 'joomla.filesystem.path' );

/**
 * Validateonupdate API Class
 * @version		3.1.04
 *
 * @since		3.1.02
 * @author		Steven
 */
class ValidateoncreateIntegratorAPI extends IntegratorAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		3.1.04
	 * 
	 * @since		3.1.02
	 * @see			IntegratorAPI :: execute()
	 */
	public function execute()
	{
		$db		=	dunloader( 'database', true );
		$input	=	dunloader( 'input', true );
		$data	=	$input->getVar( 'data', array(), 'array' );
		$query	=   array();
		
		extract( $data );
		
		// Lets check email updates first
		if ( isset( $data['email'] ) ) {
			$query['email']		=	"SELECT u.id FROM `#__users` u WHERE `email` = {$db->Quote( $data['email'] )}";
			$type				=	'email';
		}
		
		// Lets check username updates next
		if ( isset( $data['username'] ) ) {
			$query['username']	=	"SELECT u.id FROM `#__users u WHERE `username` = {$db->Quote( $data['username'] )}";
			$type				=	'username';
		}
		
		foreach ( $query as $type => $q ) {
			$db->setQuery( $q );
			if ( $db->loadResult() ) {
				return $this->error( JText :: sprintf( 'COM_INTEGRATOR_API_USERVALIDATION_ERROR' . strtoupper( $type ), $data[$$type] ) );
			}
		}
		
		return $this->success( true );
	}
}