<?php
/**
 * Integrator
 * Integrator - Component Script
 *
 * @package    Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.14 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      3.0.9
 *
 * @desc       This is the installation script executed by Joomla! 2.5+
 *
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');

/**
 * Called at installation
 * @author 		Steven
 * @version		3.0.14
 *
 * @since		2.4.9
 */
class com_integratorInstallerScript
{
	/**
	 * Called after the component has been installed or updated
	 * @access		public
	 * @version		3.0.14
	 * @param		string		- $type: contains the type of installation performed
	 * @param 		object		- $parent: the parent object calling the script
	 *
	 * @since		2.4.9
	 */
	function postflight( $type, $parent )
	{
		$path			=	JPATH_ADMINISTRATOR	. DIRECTORY_SEPARATOR
		.	'components'			. DIRECTORY_SEPARATOR
		.	'com_integrator'		. DIRECTORY_SEPARATOR;
			
		JFile :: move( 'com_integrator_30.xml', 'com_integrator.xml', $path );
		
		return;
	}
}
