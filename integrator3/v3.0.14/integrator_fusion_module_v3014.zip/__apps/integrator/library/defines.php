<?php
/**
 * Integrator
 * 
 * @package    Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.14 ( $Id: defines.php 78 2012-10-03 00:40:16Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file includes and defines constants for use in the hook files
 * 
 */

if (! defined( 'INTEGRATOR' ) ) {
	@define( 'INTEGRATOR', true );
	@define( 'MODULE_INTEGRATOR', 'integrator' );
	
	if ( version_compare( SWIFT_VERSION, '4.50', 'ge' ) ) {
		@define( 'MODULE_INTEGRATOR_LIBPATH', SWIFT_BASEPATH . DIRECTORY_SEPARATOR . SWIFT_APPSDIRECTORY . DIRECTORY_SEPARATOR . 'integrator' . DIRECTORY_SEPARATOR . 'library'. DIRECTORY_SEPARATOR );
	}
	else {
		@define( 'MODULE_INTEGRATOR_LIBPATH', SWIFT_BASEPATH . DIRECTORY_SEPARATOR . SWIFT_MODULESDIRECTORY . DIRECTORY_SEPARATOR . 'integrator' . DIRECTORY_SEPARATOR . 'library'. DIRECTORY_SEPARATOR );
	}
}

// Array of library files to require
$files	= array( 'object', 'uri', 'curl', 'api', 'render', 'user', 'helper' );

foreach( $files as $file ) {
	require_once( MODULE_INTEGRATOR_LIBPATH . $file . '.php' );
}