<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<body>

<script>
<!--//--><![CDATA[//><!--

img1 = new Image();
img2 = new Image();
	
img1.src = "<?php echo $bgimg; ?>";
img2.src = "<?php echo $barimg; ?>";

//--><!]]>
</script>
		<div class="redirect-wrapper" id="jwhmcsredirect">
		<div class="redirect-texthdr"><span><?php echo $message; ?></span><br />
		<div class="redirect-imagebar">&nbsp;</div>
		</div></div>
<form action="<?php echo $action; ?>" method="post" name="frmlogin" id="frmlogin">
		<?php echo $fields; ?>
</form>
<script language="javascript"><!--
setTimeout ( "autoForward()", 0 );
function autoForward() {
	document.forms['frmlogin'].submit()
}
//--></script>

</body>
</html>