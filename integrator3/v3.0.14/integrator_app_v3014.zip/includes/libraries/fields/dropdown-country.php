<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class to generate a dropdown of countries for selection
 * @version		3.0.14
 * 
 * @since		3.0.2
 * @author		Steven
 */
class DropdownCountryField extends form_definition
{

	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.14
	 * @param		array		- $options: contruction options
	 * 
	 * @since		3.0.2
	 */
	public function __construct( $options = array() )
	{
		parent::__construct( $options );
	}
	
	
	/**
	 * Method to generate a form field
	 * @access		protected
	 * @version		3.0.14
	 * 
	 * @return		string
	 * @since		3.0.2
	 * @see			form_definition::field()
	 */
	protected function field()
	{
		$name		= $this->name . ( $this->array ? '[]' : '' );
		$arguments	= $this->arguments();
		
		if (! isset( $arguments['class'] ) ) $arguments['class'] = '';
		
		$extras		= "id=\"{$this->lang}\"";
		foreach ( $arguments as $key => $value ) $extras .= " {$key}=\"{$value}\"";
		
		$options	= $this->get_options();
		$selected	= $this->get_selected();
		
		$field		= form_dropdown( $name, $options, set_value( $this->name, $selected ), $extras  );
		
		return $field;
	}
	
	
	/**
	 * Method to get the options for the drop down box
	 * @access		protected
	 * @version		3.0.14
	 * 
	 * @return		array
	 * @since		3.0.2
	 * @see			form_definition::get_options()
	 */
	protected function get_options()
	{
		$ci			= & get_instance();
		$cnxn		=   type( $this->cnxn_type );
		
		if (! is_a( $cnxn, 'Cnxns_library' ) )
			$cnxn = & $ci->cnxns_library;
			
		$options	= $cnxn->build_country_array();

		return $options;
	}
	
	
	/**
	 * Method to get the selected item for the drop down box
	 * @access		protected
	 * @version		3.0.14
	 * 
	 * @return		mixed
	 * @since		3.0.2
	 * @see			form_definition::get_selected()
	 */
	protected function get_selected()
	{
		$params		= & Params :: getInstance();
		$selected	=   ( $this->value ? $this->value : $params->get( 'DefaultCountry' ) );
		return $selected;
	}
}