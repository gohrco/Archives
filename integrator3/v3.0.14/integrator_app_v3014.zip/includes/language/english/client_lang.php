<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.14 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      3.0.1 (2.0)
 * 
 * @desc       This is the English language file for the client side of the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/



// ===================================================================
// 	Client Registration (register/index)
// ===================================================================
//		v 3.0.1
// -------------------------------------------------------------------
$lang['desc.firstname']		= 'Enter your first name';
$lang['desc.lastname']		= 'Enter your last name';
$lang['desc.username']		= 'Enter a username to register on our site with';
$lang['desc.email']			= 'Enter your email address';
$lang['desc.password']		= 'Enter the password you want to use on our site';
$lang['desc.password2']		= 'Please re-enter the password to be sure you typed it correctly.';
$lang['desc.address1']		= 'Enter your street address';
$lang['desc.address2']		= '(optional)';
$lang['desc.city']			= 'Enter your city';
$lang['desc.state']			= 'Enter your state';
$lang['desc.postal']		= 'Enter your postal code';
$lang['desc.country']		= 'Enter your country name or country code';
$lang['desc.phone']			= 'Enter your phone number';
$lang['desc.companyname']	= 'Enter your company name if you have one';

$lang['desc.pwstrength']	= 'Strength';
$lang['pwtxtstrong']		= "Strong";
$lang['pwtxtmod']			= "Moderate";
$lang['pwtxtweak']			= "Weak";



// ===================================================================
// 	Logging Out (logout/*)
// ===================================================================
//		v 3.0.1
// -------------------------------------------------------------------
$lang['title.logout']				= "Logging Out";

//		v 3.0.7
// -------------------------------------------------------------------
$lang['msg.redirectingoutnow']		= "Logging Out...";



// ===================================================================
// 	Logging In (login/*)
// ===================================================================
//		v 3.0.1
// -------------------------------------------------------------------
$lang['title.login']				= "Logging In";
$lang['msg.redirectingnow']			= "Logging In...";





/**
 * **********************************************************************
 * GENERAL API MSGS
 * **********************************************************************
 */
//     v3.0.0
// ---------------
$lang['ping']							= "pong";

$lang['msg.success.valid']				= "true";
$lang['msg.error.invalid']				= "false";

$lang['msg.error.disabled']				= "The Integrator is disabled - unable to make a connection";
$lang['msg.error.userdisabled']			= "User integration has been disabled globally in the Integrator!";
$lang['msg.error.cnxndisabled']			= "User integration on this connection is disabled in the Integrator!";
$lang['msg.error.credsincorrect']		= "The API username or password you supplied are incorrect";
$lang['msg.error.credsmissing']			= "The API username, password or secret key are missing";
$lang['msg.error.invaliddata']			= "No originating connection id passed along";
$lang['msg.error.formvalidation']		= 'The data passed did not validate - check your configuration.';
$lang['msg.error.secrethashinvalid']	= "There is a problem with the secret / hash generated code.";
$lang['msg.error.invalidcredentials']	= 'No username or email was found to authenticate.';

$lang['msg.error.getroute.cnxnlib']		= "Unable to retrieve the requested route.";

$lang['api.findapicookie.nocookie']		= 'Unable to find the cookie for the api in the header stack.';
$lang['api.grabcookies.noread']			= 'Unable to read the API cookie file.';
$lang['api.grabcookies.noopen']			= 'API cookie file exists but cant be opened.';
$lang['api.grabcookies.empty']			= 'The API cookie file is empty for this connection.';
$lang['api.writecookies.error']			= 'There was a problem writing to the temporary directory.';




/**
 * **********************************************************************
 * LABELS - Input field labels
 * **********************************************************************
 */

$lang['label.email']			= "Email Address";
$lang['label.oldpassword']		= 'Old Password';
$lang['label.remember']			= "Remember Me";
$lang['label.remember']			= "Remember Me";
$lang['label.newpassword']		= 'New Password';
$lang['label.newpassword2']		= ' ';

$lang['label.firstname']		= 'First Name';
$lang['label.lastname']			= 'Last Name';
$lang['label.username']			= 'Username';
$lang['label.email']			= 'Email Address';
$lang['label.password']			= 'Password';
$lang['label.password2']		= 'Confirm Password';
$lang['label.address1']			= 'Address';
$lang['label.address2']			= 'Address 2';
$lang['label.city']				= 'City';
$lang['label.state']			= 'State';
$lang['label.postal']			= 'Postal Code';
$lang['label.country']			= 'Country';
$lang['label.phone']			= 'Phone Number';
$lang['label.companyname']		= 'Company Name';

/**
 * **********************************************************************
 * BUTTONS - Individual button languages
 * **********************************************************************
 */
$lang['btn.edit']				= 'Make Changes';
$lang['btn.edituser']			= 'Edit User';
$lang['btn.changepw']			= 'Change Password';
$lang['btn.login']				= "Login";
$lang['btn.logout']				= 'Log Out';
$lang['btn.changepassword']		= 'Change Password';
$lang['btn.forgotpassword']		= 'Forgot Password?';
$lang['btn.register']			= 'Register';


/**
 * **********************************************************************
 * TITLES - Appear at the top of the pages
 * **********************************************************************
 */
$lang['title.user.edit']				= 'Edit Your Information';
$lang['title.user.login']				= "Client Login";
$lang['title.user.changepassword']		= 'Change Password';
$lang['title.user.info']				= 'Client Information';
$lang['title.user.contactinfo']			= 'Contact Information';
$lang['title.register.index']			= 'Client Registration';
$lang['title.login.index']				= "Logging In";
$lang['title.logout.index']				= "Logging Out";


/**
 * **********************************************************************
 * PAGE DATA - Used on the site to display paragraph descriptions
 * **********************************************************************
 */
$lang['page.changepassword']	= '<p>To change your password, please be sure to enter your current password below.  Then enter a new password and confirm it to continue.</p>';
$lang['page.clientarea']		= '<p>Below you will find your account information as well as other relavent data pertaining to your account.</p>';
$lang['page.login']				= '<p>Please enter your email address and password on file with us below to log into our site.</p>';
$lang['page.register']			= '<p>Thank you for registering with us!  Please complete the form below and click "Register" at the bottom to continue.  Note that fields marked with a <i class="icon-star"></i> are required to complete registration.</p>';
$lang['page.useredit']			= '<p>Please update your information below.  Note that fields marked with a <i class="icon-star"></i> are required data fields.</p>';


/**
 * **********************************************************************
 * PLACEHOLDERS - Used for blank input text fields
 * **********************************************************************
 */
$lang['place.email']			= 'Your email address';
$lang['place.password']			= 'Your password';
$lang['place.oldpassword']		= 'Your current password';
$lang['place.newpassword']		= 'New password';
$lang['place.newpassword2']		= 'Retype password';


/**
 * **********************************************************************
 * TIPS - Tooltip mouseover tips
 * **********************************************************************
 */
$lang['tip.identifyusername']	= 'This is your username';
