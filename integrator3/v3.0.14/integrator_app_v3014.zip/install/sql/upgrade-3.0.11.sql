
UPDATE IGNORE `__DBPREFIX__settings` SET `value`='3.0.12' WHERE `key` = 'Version';
