
UPDATE IGNORE `__DBPREFIX__settings` SET `value`='3.0.7' WHERE `key` = 'Version';
