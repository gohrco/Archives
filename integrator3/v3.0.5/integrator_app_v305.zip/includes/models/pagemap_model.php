<?php //00924
/**
 * ---------------------------------------------------------------------
 * Integrator v3.0
 * ---------------------------------------------------------------------
 * 2009 - 2012 Go Higher Information Services.  All rights reserved.
 * 2012 November 7
 * version 3.0.5
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPwHuccT6/Nv82w4FHBh1BeniqcOZviT67vMi41HwVomEtX9WdXnHu2p75eCcPWLkavMAhcAu
c/LcE2McCzFZUufT0H6NHOuW93Nv8frgGXFDnTY6v55Vbi9qHwqRdQeQvBxbwc24lpcV/Raqyglw
S65KUm0a/JlnSLPenQ9+ooDEs17ZpIDwUvY1Dm0AvzpVx4U1SvhDWH3n6h1tMOjAeTx2k0+fc1SQ
w+3xuASfMyu/rmvDxeDIbu5dpQ7ws3TMQ1IJ7TUl5yHXEfYCDGUij/hO25ZGj75hzn4uqjvN2syu
rmydQ5hkhJcq+X3WnF523DjIHmhZeU5Chp9wOlvARQB09LYAiLCo0EjqPZD2ShwR9/GmeJkhKwiK
yJzArQ9w6twOxGHzs2+Jb57/KB/T0wzMg/7XK4bIo0YDlNzaLx7AqFqDuHyv8AIG18Wx8FIQ0Kqf
nVYe6SFBu4Glg0Y4nsE0x4/8IdHkZhhmyWZ1DlW4Ci/NVB4gU97p5XADOpVc76fLksqgb9+ewlzP
eATuYzSa06wBnzPdizzNXXTNOFX1L2SIb91hvXU6obHpgUyrxPO4W7aLhnTo8oBIURd7nJbBnJVA
kLCL0oVsIPczjoMBxby7mSZDwQR2l63/NrUeoA8O3+eXUAxSa2xevYZikpbpSqmCTEUSjiIN15+z
/I2QVcLStVmR+84RXJIlrzyCxfEX2ATRKj0zZ/Zyy4CaCmU4WM2glo0viZNmU+dUXOsg2UW8eMEg
fbyUJs2hXDej2s14+DndJUKS7yr9XX24P5RwASHDigTzSm+g6ah+KpqpeXGztd701p1sU1wN5J8F
lO8ROrpDOXcLfruRZO60qA0EN9qi9zvE14c7lmrDiCdYioET+k3Ts0gCNsqve6x3oW+oJMSajkrM
px+XZu5Pkod6B7S4UdpjacqVVT0ccNE342griwQ4ZYF/CW2GTPZgvfWVE3+fQ/dGwr+COlzEj0IY
PgZUq2vDmkUyrcLwrnwbWi1fEbebZof2LRnQlZihL/om4oRY5cUK58pXXJbGTr39x3G+j7U0uhzJ
QHFiP9pwyKNtgcW/p6LLWecDr1HDFlf0G6IF+MyW6XVRi5HD+Xbmmrj9SAnlmiZcTk/I3ztN8bZD
PdrSvU9SU1ajd2NA7PXbRbjk7I7gCFsmACoeGvIwbmedLmy3iQR+2izvPz6QJrxf5OwV4526C3ep
syZYl4dO0+H+U0UkUZPia/Ce5B1FfAybG/9QKW414Uy3fZAXZTpwRNMA+k+SVXFQKNqpvrBahMBt
Rv3CIQPe/LOPP4tskGYH5xPQLeYMiIPa8UjUG+Fecch9SPsixSS2hR3fILdrWiCTBvIRAzv0gYLK
u8GTBO70h0f0Hav1ybqfknRZfcon+8xS86O4JrqartE0CQ7VmgSfB7Eu2Co/2O/57GygQ6x1lBHH
SebEXkNMMnEhP0ETfej5VK2thb4MHpFwi7D0mtd69Vou2Oh+cWoBikxsTuDxOMp9+UfQgMuB1SBx
6dIo0ZNWrHhx0h8qgap11AYwwiAD1oKdLKw+OHdDS0BGn/S9fPg3rxlcglUiEjFcBG21UQxaWtSw
XhQmAb0eXRu2CsnowfXVbaBHaZqqz0t8GvmrO4Y6w0tTiy0kecwzOYAhB8ceuKjYS0cxL3dfUfbz
97s1sIMa31oti/mb0NxYWzHp9nOqwirdL9Rr6KnCNZFaoEHo0O0ThYmvuIdoW5lOf+T2pnRMoX8g
29T1HC01Zk6gxPf+dKW9PLJEnVsuSNmMmb7rcTdGZHNzp1/uIh/TngnD1MOVKIuTw5O5Rxn9Llf4
gmlMmRbQY9d3AVGA7L/FusqgUo4DchhTQUzh+nwkUHvULFWd5zR1w6NnKHOcst8BNslQH+ppqT+5
l1ea+3/OZ9clCX35bzYZSngOmqhcrU16oQyrXQEe3Zs9tB+kr7EDcZ4sDUiee091WRHlPs3R19pW
DDyN5SAwCBuAWuCbsy5u/D/unY1W3EY/VEBU6AC+KKcOqxTTz6OfU5NnomHMqxmw29ipN8PAaKL1
vu1oxj25wnpFfIXPuju82Ag0VfxV0OV5U6BES2hhqFUe/s+GrXtfc4iaafu88Z4j3fZkeot2eKxH
xJ4+S7qYDx5HQHy0s7j9gIAZj3qiEE1FaddXmwek0o/M5nr0oVpVdl590/VpGK0X8vBv5GwIRAkA
q2aAdZ95AG4cq5OtRvnZu8iEswhf6KmWcnmKWfS+akhPytxZFPyahuXdxPTZ2vkWT76/2f9TxayZ
/uTDQ8Fe2dOm2hihWmxX/J8UNon1v+/AdBvkaBhqUlXpgUIFwSGH/AzYT+zNCpkTesuVknyc0tA2
lrwg9iOBGP7wO6Noi5KW/o+mCL3cIeDXKU0Ux7GavCSXYaOl1hA3p7I4fn9NYTR6lw6F/DUUSefU
Rex+L0JFJQ11ls5twx+t4w1RiLbeS+kJD9H7XM5zSotmyFw2nbyi9lngQG2zEjAqLdYRr/SOW2wA
pNxMRiDBCq/AO6H6MZ7rkIUSfRuKVdftyina43QeIVZU60SY9fAEIvRpmScXe2yIkJ7pR+V4jCub
B9tNM/ex6iiP+E1a9R/zkI/aT1YKJTakUOzY09F7cssukUqBAKK7HNF9LD2eqLCZxi25yH6z8rHo
UnWv19S+FygbQCZAteJ2DfOid85vZtX/nEGCxdYX9elbzrwi8Z9tuUghWnM1C8kBtcldfShwNX4r
2+czaVVcA7FftiOdzRfdHJKbd4wgXz6qBh1RhKjD8wr8BBoqddQ0NKY5CNBePPA3pYUGwzKvfhYt
Rz4J7+lMCvMrsLN/X6Sv5QEIgp7Ka4gKEmICTzVNKz28N3dd1cnhYKyK4j+WX2YIZfGSuEqgGOam
ky0ibMfoVNZhRPHlzP7RAcWa5dj/L8fa0zXyo30Ucnx328rUAtcDSadB2O5z3+ZiEtu40QYbykN7
vvCBuLwDy9nAfUcL94FzpOZcZgxjDc2I02tEgJ2cJxsxQHj33W2y+6EN8D07UxH1bx1hL4ZUYDW4
uxoXdFapJVutSap4m0JStaU6P7jHTaR0uRNGnS5FEfyq3a0jWc7w7Psy5+vVNZ+hHtHpRvkaArhQ
WFWUpzpcFTXD+nlFgJGOOTv/q9wixqbpXY9ystra9nDYhYRFFdae9wHjIQ/Qvm6lQO4B0fLv8jGz
9gmjaW5JouUN3JWWp3W1RPq1l+r7GRtipcEGfQ64I2g3sdNwQ0NdlzFvQd8tXHKqV6/jR+PZjL4s
0NmoTetLx1CoMJWx/gIBXn1yXt2BXecrpulWlkAdrsVaAyywowzJsmMK0CBwv+54ETDZ42zeio12
IGGKehzyGp9ArE+3jjjd6Q2rkkVskV4M/gEbipjW5CUyD+/qTnxXssvWiFD7H5kkAZXC/tK0obi9
vKruNvapn2lxeOZ0Qui/cEnjCPL60gUJsh3DNXfqB7zKw9JWLEMadutlyAQzoqEHWywS4JM8k5VB
/a55jjNsgDhztt0083CK3DJcWvnwWINVgP/oMTZMt7EthWsbG91w6PjHJf0614dxvaRnmvCpIRBF
XV8EdEbWPYlq75XYi5mFxQTKJQMtVCYEuPVUKprG9zwG9jITf0Mjz9WcyaGURaUE9YdAKF6bP7bU
LOqvVfyLV7sB5okh4m6/Is0+2iyNVl0i0WEbUuQENQRZNbL9KL0T72YK2DGEQC3e6HJqSyZdhap2
lE/zyzCtqueX7OP8lVECpfA0UvOpXWZ/OQgTi4izb2gamwG0C7MBrg8ogR6E7Kc8XAXdJHF+Omjy
yor5aW7Cdhf6paBdemFdzCfR7CZQlBYqVHP+74ln2oYVD9ZsOypdf4O6mtdjj4DoD63Pt41+/QS4
V+BRcKyes6/X9cvPQXqT3w4UlnkyZEa9X6X49r5Ce9hMudrh7TDy3BH4XvLYvkonwD5OVnZSeXV9
dulyZd/f2KfTwm4qaYs0zIPr/LpeGruj4CYrfEBE6XvUB8nZfzq7ma+qgoCYtHZ8RYOPfeSfo0YX
qT67f0R856nn2SuOI0Eq/10dBI0d4yGB0cGg/I0RWpvx9RUZsCL32q76XAcRQLVQNFRyNlzvl28n
AzmZwq47Pw67TmDeZquipRrYkKXddm/p4l1u5Kptu2GsT0gy8e3NyDLlpTbF7qYQuJLyyDID4tXj
kGk8Xm3H9PKFsTkx/WdtHNzdn5T4b+9FP9TTRh+sWCve4ZCAa+o2ZhMu89ecehgL2CrH4/vOpNkq
soAVYNupK+A9pCvB6t1wKuXvt/IT91UFqJFQe1TjkY6TJfesXxH4ppgUBnigmXCJIpRr7jgfbiHa
K3MsjPKtlpKOUL15WFJxE1g3SAgYvDx1A9OvyHoTG+XY8sw8S9nOzhSqNfKE5ji9qteloG8qKtAy
Ka63svy/23j4km9E4XKCfJLKzKbuBmXY/mzph5YAco5EBEBvT7VfA6K3G74nA1JC5DrWasHIbHMQ
9ZbvNjY1yZaiMXxn3A0SCc5SBeO+x4T6o7mThzN5ylmDoXIly3CUtZHpsu5T4CpldGlywaTdgiaQ
PjvDbw+1u8bK5a+aba3VN/PUThkj5GhZ5t/BQD3TZtybfITbVwQ0u7xvSNmrb5w63sRfc3Gd96rt
EUtlnHgLU6Dq51WPi0s+vcsQQw9HUD3dB0WQ1NZ4kPfzH3ei8H/Ds6dDglGSA2Ebcj5BquXnXgQH
+x7tcBS5HnjDGhvkkCLZS3bOuoPxzhfHJrPZFWoegysGM1Pdv+ta8b56X+KJCtfoVmPjvpPGZNjg
J2XHMt7CMXaMvO0AVUMaeX4vLj0zjEKF805TLL9s5khpdgFGzgCDX6RsgdP9S1wIETLq5h/HoSsV
iQ17pGaS74jI7CBqDa5JyFHSwcEM3XWP3JAPWg9jZBaB9Fqns7IECJKElvPAhXrfEvXAU9JFse2b
Mp2mtnRIMIFEVP9Uay6aP6pxa5S4I5HHM2XIN34dafuSEHklH2NfsWqKv9y8ZEwf8/dExUqCPxQS
SRJO04of7YFSdcxXQNkpzXPyucC6dp0I9HuEdp9vcIOTeHjmeGgV9ZhQXhYcRZ5fgGJyA1MUn2J7
HV1eIgv/1WeZY+QanqweEhxI7A54CGhZ8DpfWxHS3lyPD5x0+BY6QrhOIvndy9gOaRkcdvlxp2ql
BW/UFPmgGKQmDAA+GxuuvmeaYCsF3CRV0R7DmvtdycTsEsbffhqX1aKRXRPFrOKK8Dg6j2ViMweW
iEm0CK76QIRJWiEieGw9/C5KsJ55xMfdi/gtbftvV3SkXV5PO/k/wz6yPfHTrBPclmw3Ez7gyg7N
X9B3+dwXImx6UWMIMUcl72a1gkNFFHFFxE1P6fVG953wtEFoUQrWPPAjgTTNH0QoqylUHxH5lCPH
+rD/PwejPcDnUEpyf8l5I6P9rW2oHvX00F7neCaIDfP9qPYOhy5tBZXfPbzyvPMJQsWWzl4Mrtpv
0h1TRSRsHCez8+98TeRyWW59a81iXZB5Uai7eDMTcSKXGRiW3LfYjFs0ku0gaX1JNJLgv4sQ9qP2
Nx4XXqp7n38x30cp1QDL68JgZHJAzMY6cSZ24b6lHks9fQHsyW9F7oE6wo6deFPyPxKmh7WwvGQT
lYEHcPtxXaifqDGobjFA9WPaKIhT0hIIhpilJhPzkm90Wompo4ow+IWqPXC/ShN/C6be0eZweZBF
4mEtC+YOquUybw6959rYlRBkI29XK/Zc8+WkZuqUE/KlhxejiN6gXOGLvNnfqYfmPnzaEjfqUFAM
+lMGrf72K6CxLCyTNQ2jLBEFqbu3QWTtMnId0AlcyasnI1Li6CFw2+DTeR+EzwMqwxfWbtBT6eUb
jpdsScpZlUFgxP5O8OvD5RfXzMZ28UJVkDw2xQdILllXLFF/51Jp6LFfwL9lTh7kjDVP3NFQ6EAX
1B69ROL1G1BibwbEwItWBWWbhg2p67DOx/6ZZivmbJCC4ljIoaLk93NATdObfWPvLn1DxupJNtzJ
bk9zix2fJNKTQh8+OXnGvXudUNM/BMiLGO3gYBkHOqs2C2VS/0XRTgaDEVPVV+msDJucvPdSttkb
QlDtLuXlG5DfIOJ7fkHFMd/rAgarmqkQIpCdMlB9GtT6y0vCSeKHFywLeA+4CLBCMVhxXIHZbk9F
Gt3+pyK5DHBKywhZJx8qU2uIu/MWfWRbgkcIsUdLqWm+9vnkCzzhDr98wKg2hx8LLbXBvlsEBhM2
eKH9AXXSmchEWgj4Z9P36Gv0QDKOnSjtJdJSiklCCrXMAfexATL5oDRPL0nQITMmuowaZiu+RQl8
buCOHRF5r4Z5v+Lm8a+ZXLWSW9TdcfeCwejBEgQZhUp8yuOxDWyblsRrIj8IKcJ1rNpT4BsvoQto
PCybB3KYUW2kxajQxJ83m5J6r1ltZsSCJ0Lrx8NwVW44NKSEGsg6qfgTBS+BNBU0jOFulX5N4rbS
KCYywWSM57m2fSr14t2bUlovv5w0PY9d1WkfyIsusbLFWHnItl0GoTePSofKFIYpeNxGl8iDh1aK
GE144PzG7O627ZtP+g2xAYiqApsVHn/1FiYmfSNHRrZjz56efccaJEnIPvRF+5CaeekK5GWAvwnM
iMx74OiU3uXZ42xkYUy7cwlcgoECLYnXzdIdtdg1h/IzLIaJn2u/UOxvC2Ox1uTpe2bJT58iccKG
a0zxN7Zotv4EMemnQkLFMhiKcvp7VKTg7npXfNL92EfzYR57IP278ZTZ6aU6/mhBMvo3RR2KVJIR
KhDq2a4r5TqEGA9TEmP+t2H8ElVWoUzHgH8C998Xg7u6ozS78c59cmCmAW0p0DO26gRyGM4KoQz5
WHN6O7vPYMMoMGuVkdADjjhOjrCj6v90nI+Bs5iiaPiVloJR3wpoZ1QxmCz6+XdK/tMod6OeT3bH
gKduT4MkaX4sL+Qx6bxZneUR0MZIN/Hvz+8odWn07y2iRJ42akKg2TUvx6XjUJelhTnzf/RVuIvx
GGq7vSy0h+07XDdz1l7bCh40NgZn4XNUPqllB8md6hpnzcCUFc4dvIkzVqbo0028U85JD6QzzNFY
7y6XM+ZwvceWldoNNL7jLAgGH+VVDPk/+Ytsk9B/Gq3Wgch4drVsHqMgeu3+E0NqRBLdiEQDeWdH
mCsxx4gYdOTaItD7ofr5yYL9TDdciuJ7UUSiZVS9qgxaY3gZEmJllkIp1iSl+q5q862t1qGI11lA
7E6xLry3QG+oxOA1a1SU5MyDNeouxASkaFBJ0JBXQprcxL2JqURUnG0bCNwSc/GQ92mEsj69x4pa
5XkwS+wjZ1gpAj2tYxzIINqlT1qXnz35bfxs+2qFfyNKEUcKa15ScA0ZVfSOSvyi9PDRm/RHsg+B
wsAd6IfnBuT9SknfTZel1fXRv9fOLAysNEC+QGUoFGpagYhDC2V4/Rx5oIXRpnoZVc5bKZGh8RbX
E0q4n6T1EUIHOcyQkVTP6iVzhfm3JfMUZD0QHL9/XnkrSgvUcdZS5Sh1znoDZGsOWFvuZXCshQ/t
+gqZ6MSwrlI+SvBnkbaKkhU4pbApt5rv7NJWlCO7mHt4n3jy3waaZ0qGTHIOI1lUz5gpAPm6Vd/x
mPGv3VNKMWVVOWWkzwFpx8aUx4y0o7kuJ9g/MNBWoDkUrGzN8f3UwV2fHWAEeAgOTBfyhkuUSfGI
amCxbTv3X5jBUxu6ZzUZtRda0ammP4Ge2M0LaT4c07NEXriFkf+GRmxW2nABf4js+I1Jdwd2306k
d1WNul0EUI7FiFpddifLRuxGO75VoN/Sr4MSWgBa60DfeCwy5+I4pzXzpyMk7fozELTur9e0VjC9
c9h0TDRmmqPnasfJXgCs+q1mvqVm6SLlP1krO9m9IONBFWz6WLE6TGOfjSHHyeSxsC9nU8/tfKrq
mZV0SQiBNdGN7CYZ9mV6GbR22JeoMnWgGVGvrxxHzkCH+OarciqoJcUddfxL28d1NfuheWM0yp0K
SupnRDxC7dKX7x4wC90gFrUHUU35UakNydWjfq4ZjbXRK8ngcpfD6a962KIOzvTqdg0H0PyB2cY8
XHFY7yOgHzLMeKFgTp7ctu1Ea0u3RCGx9VIyVqJXKt7nUKAu/SPUlgO04B80U7e4d8fg4KKVq4aj
J79aTqa5kB4Sf9sqONriC+B6k8q4eUWQK0Ul16SREdfi4spgU46aO/voXrDr3iWOncmR0UkeFODr
zjrQbTnbAGvPTyPpCgaBwGMOS3gnEv7VCWJU86C6msqUC+2/fr6EpyNApax5z4U3DTGrsGZGpcrO
3dbsl6WGqHTDfBfNa95O1fxEaXp7HJqO9ZjSp9xxvwfnlYDWRq/f9JiM3ogwsnoUoGvS1vLzrAIc
D8AzYE8/nSgT/K28TU+narfJXJbp0rwBrviAM12y4QwVYyju6AxHuRSXjunO5qy1Sb5kHHUPqYs9
QU7V0vNkq3c/rVrbj9GYa2UyeyuV4FkRQEQvCk7JRxr+UO/RQODQuFoaQJ28IIzlPkaz+HGe3A+1
n/eh2zlvLWBMZJU7GP0gs35DPfPGvUAh31+0m36wBdcddvMUUYgkWNfU9YnCpInkE0omU3/M7MJ0
gN1/tOGioQMKWPYgR3K0OVBHcvDRN5HBsEN/X+yDvX6VfUROC4ISM8qpgFxLs2l4N260Kyt7e0NJ
DgRxcLyNhnMabCsHrX/l7VkXijFTNQYifk3sHvBoGQeB0uLGLrBIDFBTeFBT5IGR2BnrgxxmUzj5
22L27hmcWyln+pLbm+/rpt5xkoQfDljUl369ycW+CtDpxWGpx0eKOo9za4fgUcFIeWDLCrHX/40F
aE4jOuEjmZL1/8DjJsKMmcX5N3T47XtvFMkjm5QzWZ1u5QnWOUOf3Z0YmjEWBbVp2kqRf0opYHY3
twh5WpRx8MIGm2MNLel6V089m9mH5IFJooflQKkosiHR4J6PMnjQRep/UZ4dBzsHcmioTzT4blFK
D0J/ehhFQxqGQpwTnHLtarLEvwqH2c/lWEPopKK8+Y5ehKQcGSP2ZPFPDO4ZtCxq5fS/acFp6lhb
70w46LW9jJAhc8gvc59wNo7Z/Az6sDjJyt6Yl4+zkIQrxNd+CiSd88bOPygbnPoMgR73oHC7OIk2
XDMTNRlIax8efvKE9me1WoUE/39N2K+WhN/meMD8ZjPF8jbJ07PSSBQyjkTcEKYVUS8x1HK86Rxw
qbnZrhsKtHcJazIx82JPyfqxE7r+a/b5qe3YMdomrVM514xJU10UuOztd9F+IqmdazZKrQQLzyi8
eqoROEcvKx0xzYKm1CeXM0T5OePiVvTtid2BX/7cMmFjC3QRvtZI7A4vdsH8hhSUwOOVZGiJDC9B
fhPR/dpmfWlbIHb5UbIwbD3fntBV9KH/+9K4G2FQCnkIqjO4KiWYvl7MKtNTAKf47lwblffeh0TC
jjYf4Ru6vXVqHLxaox45uuKPKbycxmbpMouo8Qda1WKKqRV3fluu/xCB6T2bFuzkAn4jhR/vRQCb
y88498tJrqNCpbpprkrC46ggWGZ/OdajnlCzRzoO0JRGMJyEMWN35gRZMjg7v1X2TNisl9xLSa+l
qDL8EqKObwgiuYtyDv29vJR5Vgj+f49jmPe=