<?php 

$active	= true;
?>

<?php echo form_open( $action, array( 'id' => 'adminForm' ) ); ?>

<div class="tabbable tabs-left">
	<ul class="nav nav-tabs">
		
		<?php foreach ( $data as $dataset ) : ?>
		
		<li<?php echo ( $active ? ' class="active"' : '' ); ?>>
			
			<a href="<?php echo "#".$dataset['id'] ?>" data-toggle="tab"><?php echo $dataset['name']; ?></a>
			
		</li>
		
		<?php $active = false; ?>
		<?php endforeach; ?>
		<?php $active = true; ?>
		
	</ul>
	
	<div class="tab-content">
		
		<?php foreach( $data as $dataset ) : ?>
		
		<div class="tab-pane<?php echo ( $active ? ' active' : '' ); ?>" id="<?php echo $dataset['id']; ?>">
			
			<?php echo heading( $dataset['name'], '3' ); ?>
			
			<?php if ( lang( $dataset['type'].'.header' ) ) echo '<div class="header-text">' . lang( $dataset['type'] . '.header' ) . '</div>' ?>
			
			<?php $active = false; ?>
			
			<table class="table table-striped">
				<thead>
					<?php foreach( $dataset['data']['header'] as $header ) : ?>
					<th<?php echo isset( $header['class'] ) ? ' class="' . $header['class'] . '"' : ''  ?>><?php echo $header['text']; ?></th>
					<?php endforeach; ?>
				</thead>
				<tbody>
					<?php foreach( $dataset['data']['body'] as $item ) : ?>
						<tr>
							<?php foreach ( $item as $cell ) : ?>
							<td<?php echo isset( $cell['class'] ) ? ' class="' . $cell['class'] . '"' : ''  ?>><?php echo $cell['text']; ?></td>
							<?php endforeach; ?>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			
			<?php if ( isset( $dataset['buttons'] ) && is_array( $dataset['buttons'] ) ) : ?>
			
			<div class="row-fluid form-horizontal">
				<div class="form-actions">
					
					<?php foreach ( $dataset['buttons'] as $button ) :
						$type = $button->btntype; 
						unset( $button->btntype );
						
						if ( $type == 'anchor' )
						{
							$uri	= $button->uri;
							$title	= $button->title;
							unset ( $button->uri, $button->title );
							echo anchor( $uri, $title, (array) $button );
						}
						else
						{
							echo form_button( (array) $button );
						}
					endforeach; ?>
					
				</div>
			</div>
			
			<?php endif; ?>
		</div>
		
		<?php endforeach; ?>
		
	</div>
	
</div>

<?php 
if ( isset ( $hidden ) ) {
	foreach( $hidden as $hider ) echo $hider->field;
}
?>

<div class="row-fluid form-horizontal">
	<div class="form-actions">
		
		<?php 
		foreach ( $buttons as $button )
		{
			$type = $button->btntype; 
			unset( $button->btntype );
			
			if ( $type == 'anchor' )
			{
				$uri	= $button->uri;
				$title	= $button->title;
				unset ( $button->uri, $button->title );
				echo anchor( $uri, $title, (array) $button );
			}
			else
			{
				echo form_button( (array) $button );
			}
		}	
		?>
	</div>
</div>

<?php echo form_close(); ?>
