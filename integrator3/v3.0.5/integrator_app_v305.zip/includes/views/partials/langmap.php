<script>
$(function() {
	$( "#tabs" ).tabs();
});
</script>
<?php echo form_open("langmap" );?>
<div id="tabs">
	<ul>
		<?php foreach ( $languages['app'] as $app_id => $app ) : ?>
		<li><a href="#app<?php echo $app_id; ?>"><?php echo $app['name']; ?></a></li>
		<?php endforeach; ?>
	</ul>
	<?php foreach( $languages['app'] as $app_id => $app ) :?>
	<div id="app<?php echo $app_id; ?>">
		<table width="100%" border="0" cellpadding="5" cellspacing="0">
			<thead>
				<tr>
					<th style="text-align: center; ">
						<?php echo lang( 'langmap.hdr.page' ); ?>
					</th>
					<?php foreach ( $languages['site'] as $site_id => $site ) :?>
					<th style="text-align: center;"><?php echo $site['name']; ?></th>
					<?php endforeach; ?>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td style="border-right: 1px solid #223344; border-bottom: 1px solid #223344; text-align: right; "><?php echo lang( 'langmap.hdr.defaultlang' ); ?></td>
					<?php foreach ( $languages['site'] as $site_id => $site ) : ?>
					<td style="border-bottom: 1px solid #223344; text-align: center; "><?php echo form_dropdown( 'language['.$app_id.'][default]['.$site_id.']', $site['languages'], set_value( "language[{$app_id}][default][{$site_id}]", $language[$app_id]['default'][$site_id] ) ); ?></td>
					<?php endforeach; ?>
				</tr>
				<?php foreach( $app['languages'] as $lang_id => $lang_name ) : ?>
				<tr>
					<td style="border-right: 1px solid #223344; border-bottom: 1px dotted gray; text-align: right; "><?php echo $lang_name; ?></td>
					<?php foreach ( $languages['site'] as $site_id => $site ) : ?>
					<td style="border-bottom: 1px dotted gray; text-align: center; "><?php echo form_dropdown( 'language['.$app_id.']['.$lang_id.']['.$site_id.']', array( "default" => "-- " . lang( 'option.pagemap.default' ) . " --" ) + $site['languages'], set_value( "language[{$app_id}][{$lang_id}][{$site_id}]", $language[$app_id][$lang_id][$site_id] ) ); ?></td>
					<?php endforeach; ?>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<?php endforeach; ?>
</div>

<div class="push-4 append-bottom clear"><?php echo form_button( array( 'name' => 'submit', 'id' => 'submit', 'value' => true, 'type' => 'submit', 'content' => lang( 'updatesettings' ) ) );?></div>

<?php echo form_close();?>