<?php if (! empty( $admin_user ) ) : ?>
<!-- <?php echo sprintf( lang( 'side.greeting' ), $admin_user->first_name, $admin_user->last_name ); ?>&nbsp;(<?php echo anchor( 'admin/logout', 'Logout' ); ?>) -->
<?php endif; ?>