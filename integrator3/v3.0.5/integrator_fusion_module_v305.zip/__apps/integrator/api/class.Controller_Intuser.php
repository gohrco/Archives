<?php
/**
 * Integrator
 * 
 * @package    Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.5 ( $Id: class.Controller_Intuser.php 78 2012-10-03 00:40:16Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file handles api calls to the User interface of the Integrator within Fusion
 * 
 */

if ( version_compare( SWIFT_VERSION, '4.50', 'ge' ) ) {
	require_once( SWIFT_BASEPATH . DIRECTORY_SEPARATOR . SWIFT_APPSDIRECTORY . DIRECTORY_SEPARATOR . 'integrator' . DIRECTORY_SEPARATOR . 'library' . DIRECTORY_SEPARATOR . 'defines.php' );
}
else {
	require_once( SWIFT_BASEPATH . DIRECTORY_SEPARATOR . SWIFT_MODULESDIRECTORY . DIRECTORY_SEPARATOR . 'integrator' . DIRECTORY_SEPARATOR . 'library' . DIRECTORY_SEPARATOR . 'defines.php' );
}

/**
 * Intuser Controller extends the API Controller implementing the REST interface
 * @version		3.0.5
 * 
 * @since		3.0.0
 * @author		Steven
 */
class Controller_Intuser extends Controller_api implements SWIFT_REST_Interface
{
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.5
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
		$this->Load->Library( 'XML:XML' );
		$this->Load->Library( 'User:User', false, false );
		$this->Load->Library( 'User:UserEmail', false, false );
		$this->Load->Library( 'User:UserGroup', false, false );
		//$this->Load->Library( 'User:UserGroup_Exception', false, false );
		
		define( 'INTEGRATOR_API', true );
		return true;
	}
	
	
	/**
	 * Destructor method
	 * @access		public
	 * @version		3.0.5
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function __destruct()
	{
		parent::__destruct();
		return true;
	}
	
	
	/**
	 * API call to authenticate a user
	 * @access		public
	 * @version		3.0.5
	 * 
	 * @return		true
	 * @since		3.0.0
	 * @throws		SWIFT_Exception on error
	 */
	public function Authenticate()
	{
		// First see if the class is loaded...
		if (! $this->GetIsClassLoaded() ) {
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
			return false;
		}
		
		// Grab the credentials array to authenticate with
		$credentials	= $_POST['credentials'];
		$result			= SWIFT_User :: Authenticate( $credentials['email'], $credentials['password'] );
		
		if ( $result === false ) {
			$this->BuildResponse( array( 'user' => array( 'result' => 'error', 'message' => SWIFT::Get( 'errorstring' ) ) ) );
		}
		else {
			$this->BuildResponse( array( 'user' => array( 'result' => 'success' ) ) );
		}
		$this->XML->EchoXML();
		return true;
	}
	
	
	/**
	 * API call to create a user
	 * @access		public
	 * @version		3.0.5
	 * 
	 * @return		bool
	 * @since		3.0.0
	 * @throws		SWIFT_Exception on error
	 */
	public function Create()
	{
		// First see if the class is loaded...
		if (! $this->GetIsClassLoaded() ) {
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
			return false;
		}
		
		// Grab the update array to create the new user
		$post	= $_POST['update'];
		
		// Verify we have all we need
		foreach ( array( 'fullname', 'email', 'password' ) as $item ) {
			if ( empty( $post[$item] ) ) {
				$this->BuildResponse( array( 'user' => array( 'result' => 'error', 'message' => "Missing {$item} to create user" ) ) );
				$this->XML->EchoXML();
				return true;
			}
		}
		
		// Grab the default user group id
		$_usergroupID	= SWIFT_UserGroup :: RetrieveDefaultUserGroupID( SWIFT_UserGroup :: TYPE_REGISTERED );
		
		$_SWIFT_UserObject	= SWIFT_User :: GetOrCreateUserID( $post['fullname'], $post['email'], $_usergroupID );
		$_SWIFT_UserObject->UpdatePool( 'isenabled', $post['isenabled'] );
		$_SWIFT_UserObject->ChangePassword( $post['password'] );
		
		// Respond and close
		$this->BuildResponse( array( 'user' => array( 'result' => 'success', 'userid' => $_SWIFT_UserObject->GetUserID() ) ) );
		$this->XML->EchoXML();
		return true;
	}
	
	
	/**
	 * API call to delete a user
	 * @access		public
	 * @version		3.0.5
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 * @throws		SWIFT_Exception on error
	 */
	public function Delete()
	{
		// First see if the class is loaded...
		if (! $this->GetIsClassLoaded() ) {
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
			return false;
		}
		
		// Find the user first and any email addresses
		$_user		= $this->Find( false );
		$_emails	= SWIFT_UserEmail :: RetrieveListOnUserIDList( array( $_user['userid'] ) );
		
		// If we found only one email address, we delete the user
		if ( count( $_emails ) == 1 ) {
			$user	= new SWIFT_User( $_user['userid'] );
			$user->Delete();
			$user->SetIsClassLoaded( true );
		}
		// If the user has multiple email addresses, we just remove the email address from the user list
		else {
			$uem	= new SWIFT_UserEmail( $_user['emailid'] );
			$uem->Delete();
			$uem->SetIsClassLoaded( true );
		}
		
		// Respond and close
		$this->BuildResponse( array( 'user' => array( 'result' => 'success' ) ) );
		$this->XML->EchoXML();
		return false;
	}
	
	
	/**
	 * API call to find a user
	 * @access		public
	 * @version		3.0.5
	 * @param		bool		- $xml: true to respond with xml, false to return data (internal)
	 * 
	 * @return		mixed array or bool
	 * @since		3.0.0
	 * @throws		SWIFT_Exception on error
	 */
	public function Find( $xml = true )
	{
		// First see if the class is loaded...
		if (! $this->GetIsClassLoaded() ) {
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
			return false;
		}
		
		// Pull user info from database
		$this->Database->Query("SELECT u.userid, ue.email, ue.useremailid as emailid, u.fullname, u.isenabled FROM " . TABLE_PREFIX . "useremails ue INNER JOIN " . TABLE_PREFIX . "users u ON ( u.userid = ue.linktypeid ) WHERE linktype = '" . SWIFT_UserEmail::LINKTYPE_USER . "' AND `email` = '" . $_GET['email'] . "'" );
		
		$_user = null;
		while ($this->Database->NextRecord()) {
			$_user	= $this->Database->Record;
		}
		
		// Check to see if there was no user info found
		if ( empty( $_user ) ) {
			if ( $xml ) {
				$this->RESTServer->DispatchStatus( SWIFT_RESTServer::HTTP_BADREQUEST, 'Unknown User' );
			}
			return false;
		}
		
		// Respond and close
		if ( $xml ) {
			$this->BuildResponse( array( 'user' => $_user ) );
			$this->XML->EchoXML();
			return true;
		}
		else {
			return $_user;
		}
	}
	
	
	/**
	 * API call to get a list of functions (reqd by Kayako)
	 * @access		public
	 * @version		3.0.5
	 * 
	 * @return		false (not doing it)
	 * @since		3.0.0
	 * @throws		SWIFT_Exception on error
	 */
	public function GetList()
	{
		// First see if the class is loaded...
		if (!$this->GetIsClassLoaded()) {
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
			return false;
		}
		$this->RESTServer->DispatchStatus(SWIFT_RESTServer::HTTP_BADREQUEST, 'Not Implemented.');
		return false;
	}
	
	
	/**
	 * API call to update user
	 * @access		public
	 * @version		3.0.5
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 * @throws		SWIFT_Exception on error
	 */
	public function Update()
	{
		// First see if the class is loaded...
		if (! $this->GetIsClassLoaded() ) {
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
			return false;
		}
		
		// Grab the update array and build user
		$post	= $_POST['user'];
		$userid	= ( isset( $post['update']['userid'] ) ? $post['update']['userid'] : ( isset( $post['userid'] ) ? $post['userid'] : false ) );
		$update	= $post['update'];
		
		// If we don't have a userid try to find the correct one based on email
		if ( $userid === false ) {
			$user	= $this->Find( false );
			if ( isset( $user['userid'] ) ) $userid = $user['userid'];
		}
		
		// Test to see if we received a userid and fail otherwise
		if ( $userid === false ) {
			$this->RESTServer->DispatchStatus( SWIFT_RESTServer::HTTP_BADREQUEST, 'No Userid Passed Along' );
			return false;
		}
		
		$user	= new SWIFT_User( $userid );
		
		// Update Fullname if set
		if ( isset( $update['fullname'] ) ) {
			if(! empty( $update['fullname'] ) ) {
				$user->UpdatePool( 'fullname', $update['fullname'] );
			}
		}
		
		// Update Enabled field if sent
		if ( isset( $update['isenabled'] ) ) {
			$user->UpdatePool( 'isenabled', $update['isenabled'] );
		}
		
		// Update user object
		$user->UpdatePool('lastupdate', DATENOW);
		$user->ProcessUpdatePool();
		
		// If we sent a password, update it now
		if ( isset( $update['password'] ) ) {
			if (! empty( $update['password'] ) ) {
				$user->ChangePassword( $update['password'] );
			}
		}
		
		if ( isset( $post['password'] ) && ! empty( $post['password'] ) ) {
			$user->ChangePassword( $post['password'] );
		}
		
		// Find the user info that also contains the user email id
		$_user	= $this->Find( false );
		
		// If the email address isn't already in use update it
		if ( isset( $update['email'] ) ) {
			if (! ( $exists = SWIFT_UserEmail :: CheckEmailRecordExists( array( $update['email'] ), $userid ) ) ) {
				$useremail	= new SWIFT_UserEmail( $_user['emailid'] );
				$useremail->Update( $update['email'], $useremail->GetProperty( 'isprimary' ) );
			}
		}
		
		// Respond and close
		$this->BuildResponse( array( 'user' => array( 'result' => 'success', 'userid' => $userid ) ) );
		$this->XML->EchoXML();
		return true;
	}
	
	
	/**
	 * API call to validate credentials prior to creation
	 * @access		public
	 * @version		3.0.5
	 * 
	 * @return		bool
	 * @since		3.0.0
	 * @throws		SWIFT_Exception on error
	 */
	public function ValidateOnCreate()
	{
		// First see if the class is loaded...
		if (! $this->GetIsClassLoaded() ) {
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
			return false;
		}
		
		// Grab the update array to create the new user
		$post	= $_POST['update'];
		
		// Verify we have all we need
		foreach ( array( 'fullname', 'email' ) as $item ) {
			if ( empty( $post[$item] ) ) {
				$this->BuildResponse( array( 'user' => array( 'result' => 'error', 'message' => "Missing {$item} to create user" ) ) );
				$this->XML->EchoXML();
				return true;
			}
		}
		
		if ( $_userIDFromEmail = SWIFT_UserEmail :: RetrieveUserIDOnUserEmail( $post['email'] ) ) {
			$this->BuildResponse( array( 'user' => array( 'result' => 'error', 'message' => "The email address {$post['email']} is already in use" ) ) );
			$this->XML->EchoXML();
			return true;
		}
		else {
			$this->BuildResponse( array( 'user' => array( 'result' => 'success' ) ) );
			$this->XML->EchoXML();
			return true;
		}
	}
	
	
	/**
	 * API call to validate credentials prior to update
	 * @access		public
	 * @version		3.0.5
	 * 
	 * @return		bool
	 * @since		3.0.0
	 * @throws		SWIFT_Exception on error
	 */
	public function ValidateOnUpdate()
	{
		// First see if the class is loaded...
		if (! $this->GetIsClassLoaded() ) {
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
			return false;
		}
		
		// Grab the update array to create the new user
		$post	= $_POST['update'];
		
		// Verify we have all we need
		foreach ( array( 'fullname', 'email' ) as $item ) {
			if ( empty( $post[$item] ) ) {
				$this->BuildResponse( array( 'user' => array( 'result' => 'error', 'message' => "Missing {$item} to update user" ) ) );
				$this->XML->EchoXML();
				return true;
			}
		}
		
		if ( $_userIDFromEmail = SWIFT_UserEmail :: RetrieveUserIDOnUserEmail( $post['email'] ) ) {
			$this->BuildResponse( array( 'user' => array( 'result' => 'error', 'message' => "The email address {$post['email']} is already in use" ) ) );
			$this->XML->EchoXML();
			return true;
		}
		else {
			$this->BuildResponse( array( 'user' => array( 'result' => 'success' ) ) );
			$this->XML->EchoXML();
			return true;
		}
	}
	
	
	/**
	 * Build a response
	 * @access		private
	 * @version		3.0.5
	 * @param		array		- $data: response data
	 * 
	 * @since		3.0.0
	 */
	private function BuildResponse( $data )
	{
		foreach ( $data as $key => $value ) {
			if ( is_array( $value ) ) {
				$this->XML->AddParentTag( $key );
					$this->BuildResponse( $value );
				$this->XML->EndParentTag( $key );
			}
			else {
				$this->XML->AddTag( $key, $value );
			}
		}
	}
}
?>