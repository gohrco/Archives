<?php
/**
 * Integrator
 * WHMCS - Logging File
 * 
 * @package    Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.2 ( $Id: log.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file instantiates objects as needed
 * 
 */

/*-- Security Protocols --*/
if (!defined("WHMCS")) die("This file cannot be accessed directly");
/*-- Security Protocols --*/

/**
 * Log Class
 * @version		3.0.2
 * 
 * @since		1.0.4
 * @author		Steven
 */
class IntLog extends IntObject
{
	/**
	 * Stores the database object for reference
	 * @access		public
	 * @since		1.0.4
	 * @var			BDatabase object
	 */
	public	$db	= null;
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.2
	 * 
	 * @since		1.0.4
	 */
	public function __construct()
	{
		$this->db = & IntFactory :: getDbo();
	}
	
	
	/**
	 * Load the Belong logs from the database table
	 * @access		public
	 * @version		3.0.2
	 * 
	 * @return		array of records
	 * @since		1.0.4
	 */
	public function load()
	{
		$query = "SELECT * FROM `tblactivitylog` WHERE `user` = 'Integrator' ORDER BY `date` DESC";
		$this->db->setQuery( $query, 25, 0 );
		$rows	= $this->db->loadObjectList();
		
		$data	= array();
		
		foreach ( $rows as $row ) {
			$date	= date( $this->_dateFormat(), strtotime( $row->date ) );
			$msg	= preg_replace( '# - User ID: ' . $row->userid . '#', ( $row->userid != 0 ? ' - <a href="clientssummary.php?userid=' . $row->userid . '">User ' . $row->userid . '</a>' : '' ), $row->description );
			$data[]	= (object) array( 'msg' => $msg, 'date' => $date, 'ip' => $row->ipaddr );
		}
		
		return $data;
	}
	
	
	/**
	 * Writes a log record to the database table
	 * @access		public
	 * @version		3.0.2
	 * 
	 * @since		1.0.4
	 */
	public function write()
	{
		$msg	= $this->get( 'message' ) . ' (' . $this->get( 'action' ) . ') - User ID: ' . $this->get( 'clientid' );
		$ip		= $_SERVER['SERVER_ADDR'];
		$query	= 'INSERT INTO `tblactivitylog` SET `date` = NOW(), `description` = "' . $msg . '", `user` = "Integrator", `userid` = ' . $this->get( 'clientid' ) . ', `ipaddr` = "' . $ip . '"';
		$this->db->setQuery( $query );
		$this->db->query();
	}
	
	
	private function _dateFormat()
	{
		$format = $GLOBALS['CONFIG']['DateFormat'];
		switch ( $format ):
		case 'DD.MM.YYYY':
			return 'd.m.Y H:i';
		case 'DD-MM-YYYY':
			return 'd-m-Y H:i';
		case 'MM/DD/YYYY':
			return 'm/d/Y H:i';
		case 'YYYY/MM/DD':
			return 'Y/m/d H:i';
		case 'YYYY-MM-DD':
			return 'Y-m-d H:i';
		case 'DD/MM/YYYY':
		default:
			return 'd/m/Y H:i';
		endswitch;
	}
}