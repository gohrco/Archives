<?php
/**
 * Integrator
 * WHMCS - Admin Module Base File
 * 
 * @package    Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.2 ( $Id: integrator.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file is the root file loaded by WHMCS upon selection of the "Integrator" addon
 * 
 */

/*-- Security Protocols --*/
if (!defined("WHMCS")) die("This file cannot be accessed directly");
/*-- Security Protocols --*/


/**
 * Configuration function called by WHMCS
 * 
 * @return An array of configuration variables
 * @since  3.0.0
 */
function integrator_config()
{
	require_once( 'factory.php' );
	$lang	= & IntFactory::getLang();
	
	$desc = "<div style='padding: 2px 20px 10px 10px; font-style: italic; '>%s</div>";
	$configarray = array(
		"name"			=> $lang['cfg_name'],
		"version"		=> ( in_array( "3.0.2", array( '3.0.03', '3.0.01', '3.0.02' ) ) ? "3.0.0" : "3.0.2" ),
		"author"		=> "<div style='text-align: center; width: 100%; '>Go Higher<br/>Information Services</div>",
		"description"	=> $lang['cfg_desc'],
		"language"		=> "english",
		"fields"		=> array(
			"Enabled"				=> array (
				"FriendlyName"	=> $lang['cfg_enablelabel'],
				"Description"	=> sprintf( $desc, $lang['cfg_enabledesc'] ),
				"Type"			=> "dropdown",
				"Options"		=> "Yes,No"
			),
			"Debug"					=> array (
				"FriendlyName"	=> $lang['cfg_debuglabel'],
				"Type"			=> "dropdown",
				"Options"		=> "Yes,No",
				"Description"	=> sprintf( $desc, $lang['cfg_debugdesc'] )
			),
			"UserEnabled"			=> array (
				"FriendlyName"	=> $lang['cfg_userenlabel'],
				"Type"			=> "dropdown",
				"Options"		=> "Yes,No",
				"Description"	=> sprintf( $desc, $lang['cfg_userendesc'] )
			),
			"VisualEnabled"			=> array (
				"FriendlyName"	=> $lang['cfg_visenlabel'],
				"Type"			=> "dropdown",
				"Options"		=> "Yes,No",
				"Description"	=> sprintf( $desc, $lang['cfg_visendesc'] )
			),
			"IntegratorUrl"			=> array (
				"FriendlyName"	=> $lang['cfg_inturllabel'],
				"Type"			=> "text",
				"Size"			=> "40",
				"Description"	=> sprintf( $desc, $lang['cfg_inturldesc'] )
			),
			"IntegratorUsername"	=> array(
				"FriendlyName"	=> $lang['cfg_apiuserlabel'],
				"Type"			=> "text",
				"Size"			=> "40",
				"Description"	=> sprintf( $desc, $lang['cfg_apiuserdesc'] )
			),
			"IntegratorPassword"	=> array(
				"FriendlyName"	=> $lang['cfg_apipasslabel'],
				"Type"			=> "text",
				"Size"			=> "40",
				"Description"	=> sprintf( $desc, $lang['cfg_apipassdesc'] )
			),
			"IntegratorApisecret"	=> array(
				"FriendlyName"	=> $lang['cfg_apisecretlabel'],
				"Type"			=> "text",
				"Size"			=> "40",
				"Description"	=> sprintf( $desc, $lang['cfg_apisecretdesc'] )
			),
			"RegistrationMethod"	=> array(
				"FriendlyName"	=> $lang['cfg_regmethodlabel'],
				"Type"			=> "dropdown",
				"Options"		=> "Integrated,WHMCS",
				"Description"	=> sprintf( $desc, $lang['cfg_regmethoddesc'] )
			),
			"cnxnid"				=> array(
				"FriendlyName"	=> $lang['cfg_cnxnlabel'],
				"Type"			=> "text",
				"Description"	=> sprintf( $desc, $lang['cfg_cnxndesc'] ),
				"Size" => "5"
			),
			"UseSSL"			=> array (
				"FriendlyName"	=> $lang['cfg_usessllabel'],
				"Type"			=> "dropdown",
				"Options"		=> "Never,Always,Ignore",
				"Description"	=> sprintf( $desc, $lang['cfg_usessldesc'] )
			),
		)
    );
    return $configarray;
}


/**
 * Activation function called by WHMCS
 * 
 * @since  3.0.0
 */
function integrator_activate()
{
	
}


/**
 * Deactivation function called by WHMCS
 * 
 * @since  3.0.0
 */
function integrator_deactivate()
{
	
}


/**
 * Upgrade function called by WHMCS
 * @param  array		Contains the variables set in the configuration function
 * 
 * @since  3.0.0
 */
function integrator_upgrade($vars)
{
	// Ensure backwards compatible to v4.41
	// Bug in WHMCS dox state to use vars['version']
	if ( isset( $vars['version'] ) ) {
		$version = $vars['version'];
	}
	else
	// But this is what is found in 441
	if ( isset( $vars['integrator']['version'] ) ) {
		$version = $vars['integrator']['version'];
	}
	
}


/**
 * Output function called by WHMCS
 * @param  array		Contains the variables set in the configuration function
 * 
 * @since 3.0.0
 */
function integrator_output($vars)
{	
	require_once( "factory.php" );
	$INT_hook	= & IntFactory::getHook();
	$intlang	= & IntFactory::getLang();
	$INT_log	= & IntFactory :: getLog();
	$logs		=   $INT_log->load();
	
	// Test to be sure we are connected and then update settings
	$connected	= $INT_hook->ping();
	$updated	= ( $connected === true ? $INT_hook->update_settings() : false );
	
	$msg			= array();
	$msg['cnxn']	= ( $connected === true ? $intlang['admin_msg01'] : "{$connected}{$intlang['admin_err01']}" );
	$msg['upd']		= ( $updated === true ? $intlang['admin_msg02'] : ( $updated === false ? $intlang['admin_err02'] : sprintf( $intlang['admin_err03'], $updated ) ) );
	
	$output		= <<< OUTPUT
<h3>{$intlang['admin_outputhdr']}</h3>
<table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
	<tr>
		<td width="20%" class="fieldlabel">{$intlang['admin_labelcnxn']}</td>
		<td class="fieldarea">{$msg['cnxn']}</td>
	</tr>
	<tr>
		<td class="fieldlabel">{$intlang['admin_labelsets']}</td>
		<td class="fieldarea">{$msg['upd']}</td>
	</tr>
</table>
OUTPUT;
	
	$logrows	= null;
	$row		= 0;
	foreach( $logs as $log ) {
		$logrows .= '<div class="row' . ( $row++ & 1 ? 1 : 0 ) . '">';
		$logrows .= '<div class="date">' . $log->date . '</div>' . $log->msg;
		$logrows .= '</div>';
	}
	
	$output .= <<< OUTPUT
</table>
</form>

<style type="text/css">
.widget-content .date { width: 180px; float: left; color: #888888; }
.widget-content .row0, .widget-content .row0 { margin: 0 -5px; padding: 5px; }
.widget-content .row1 { background-color: #fafafa; }
</style>

<div id="activity_log" class="homewidget">
		<div class="widget-header">{$intlang['log_messages']}</div>
		<div class="widget-content">
{$logrows}
        </div>
	</div>
OUTPUT;
	
	echo $output;
}


/**
 * Function to generate sidebar menu called by WHMCS
 * @param  array		Contains the variables set in the configuration function
 * 
 * @since  3.0.0
 */
function integrator_sidebar($vars)
{
	
}
?>