<?php

$form['api']	= array(
	'Secret' => array(
			'apiname'		=> null,
			'value'			=> null,
			'order'			=> 10,
			'type'			=> 'text',
			'validation'	=> 'required|xss_clean'
		),
	'APILogging' => array(
			'value'			=> false,
			'order'			=> 20,
			'type'			=> 'toggleyn',
			'validation'	=> 'required|xss_clean'
		),
	'ClearAPILog'	=> array (
			'value'			=> false,
			'order'			=> 30,
			'type'			=> 'ajaxbutton',
			'call'			=> '',
			'validation'	=> '',
			'onclick'		=> "ajaxbutton( 'clearapilog', this );",
			'autocomplete'	=> 'off'
			)
);