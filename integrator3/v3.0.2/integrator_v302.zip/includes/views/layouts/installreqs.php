<div id="ajaxResponse"></div>

<?php echo form_open( $action, array( 'id' => 'adminForm', 'class' => 'form-horizontal' ) ); ?>

<div class="row-fluid">
	
	<div class="span2"> </div>
	
	<div class="span8">
		
		<?php foreach( $items as $key => $item ) : ?>
		
		<?php echo heading( lang( 'title.' . $key ), '3', 'class="header"' ); ?>
	
		<?php if ( is_array( $item ) ) : ?>
		<?php foreach ( $item as $sub ) : ?>
		
		<div class="row-fluid">
		
			<div class="span1">
				<?php echo img( 'assets/img/icon32-' . ( $sub->use ? 'success' : 'error' ) . '.png' ); ?>
			</div>
			
			<div class="span11">
				<?php echo $sub->msg; ?>
			</div>
			
			<div style="clear: both; ">&nbsp;</div>
		
		</div>
		
		<?php endforeach; ?>
		<?php else : ?>
		
		<div class="row-fluid">
		
			<div class="span1">
				<?php echo img( 'assets/img/icon32-' . ( $item->use ? 'success' : 'error' ) . '.png' ); ?>
			</div>
			
			<div class="span11">
				<?php echo $item->msg; ?>
			</div>
			
			<div style="clear: both; ">&nbsp;</div>
			
		</div>
		
		<?php endif; ?>
			
		<?php endforeach; ?>
		
	</div>
	
	<?php foreach( $hidden as $hide ) : ?>
		<?php echo $hide->field; ?>
	<?php endforeach; ?>
	
</div>

<div class="row-fluid">
	<div class="form-actions">
		<?php 
		foreach ( $buttons as $button )
		{
			$type = $button->btntype; 
			unset( $button->btntype );
			
			if ( $type == 'anchor' )
			{
				$uri	= $button->uri;
				$title	= $button->title;
				unset ( $button->uri, $button->title );
				echo anchor( $uri, $title, (array) $button );
			}
			else
			{
				echo form_button( (array) $button );
			}
		}	
		?>
	</div>
</div>

<?php echo form_close(); ?>