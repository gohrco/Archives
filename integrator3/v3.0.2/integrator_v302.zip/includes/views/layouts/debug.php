<?php

if (! isset ( $debug ) || ! is_array( $debug ) ) return;
?>
<div id="debug" class="row-fluid">
<?php 
foreach ( $debug as $item ) :
?>
	<div class="span2"></div>
	<div class="span8 debugitem code<?php echo $item['code']; ?>">
		<h4>A PHP Error was Encountered<span><?php echo $item['severity']?></span></h4>
		<span class="line"><strong>Message:</strong> <?php echo $item['message']; ?></span><br/>
		<span class="line"><strong>Filename:</strong> <?php echo $item['filepath']; ?></span><br/>
		<span class="line"><strong>@ Line:</strong> <?php echo $item['line']; ?></span>
	</div>
</div>
<div id="debug" class="row-fluid">
<?php
endforeach;
?>
</div>