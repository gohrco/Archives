<?php

$form['globals']	= array(
	'name'	=> array(
		'value'			=> "",
		'order'			=> 5,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'url' => array(
		'value'			=> "http://",
		'order'			=> 10,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'sslenabled' => array(
		'value'			=> false,
		'order'			=> 11,
		'type'			=> 'hidden',
		'validation'	=> '',
	),
	'active' => array(
		'value'			=> null,
		'order'			=> 20,
		'type'			=> 'toggleyn',
		'validation'	=> ''
	),
	'type' => array(
		'value'			=> null,
		'order'			=> 100,
		'type'			=> 'hidden',
		'validation'	=> ''
	),
	'id' => array(
		'value'			=> null,
		'order'			=> 110,
		'type'			=> 'text',
		'validation'	=> '',
		'readonly'		=> true
	)
);


$form['api']	= array(
	'apiurl' => array(
		'value'			=> "http://",
		'order'			=> 10,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'username' => array(
		'value'			=> null,
		'order'			=> 30,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'password' => array(
		'value'			=> null,
		'order'			=> 40,
		'type'			=> 'password',
		'validation'	=> 'required'
	)
);

$form['users'] = array (
	'userenable' => array(
		'value'			=> 0,
		'order'			=> 10,
		'type'			=> 'toggleyn',
		'validation'	=> 'required'
	),
	'processlogin' => array(
		'value'			=> 0,
		'order'			=> 20,
		'type'			=> 'dropdown',
		'validation'	=> 'required',
		'list'			=> array( 'always', 'whenconnected', 'never' )
	),
	'loginurl'	=> array(
		'value'			=> 'http://',
		'order'			=> 25,
		'type'			=> 'text',
		'validation'	=> ''
	),
	'logouturl' => array(
		'value'			=> 'http://',
		'order'			=> 30,
		'type'			=> 'text',
		'validation'	=> ''
	),
	'storeusername' => array(
		'value'			=> 'random',
		'order'			=> 40,
		'type'			=> 'dropdown',
		'validation'	=> 'required',
		'list'			=> array( 'first.last', 'last.first', 'random', 'flastname','firstnamel', 'firstname', 'lastname' )
	),
	'storename' => array(
		'value'			=> 'firstlast',
		'order'			=> 50,
		'type'			=> 'dropdown',
		'validation'	=> 'required',
		'list'			=> array( 'firstlast', 'firstlastco', 'lastfirst', 'lastfirstco' )
	),
	'usernametype' => array(
		'value'			=> 'email',
		'order'			=> 51,
		'type'			=> 'hidden',
		'validation'	=> 'required'
	),
	'testpwstrength' => array(
		'value'	=> '0',
		'order'	=> 60,
		'type'	=> 'toggleyn',
		'validation'	=> 'required|xss_clean|is_natural'
	),
	'forceadd' => array(
		'value'			=> 1,
		'order'			=> 70,
		'type'			=> 'toggleyn',
		'validation'	=> 'required'
	),
	'forcepwupdate' => array(
		'value'			=> 1,
		'order'			=> 75,
		'type'			=> 'toggleyn',
		'validation'	=> 'required'
	),
	'sendemail' => array(
		'value'			=> 1,
		'order'			=> 77,
		'type'			=> 'toggleyn',
		'validation'	=> 'required'
	),
	'defaultaddress1' => array(
		'value'			=> 'My Address',
		'order'			=> 81,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'defaultcity' => array(
		'value'			=> 'My City',
		'order'			=> 82,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'defaultcountry' => array(
		'value'			=> 'My Country',
		'order'			=> 84,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'defaultphonenumber' => array(
		'value'			=> '000-000-0000',
		'order'			=> 86,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'defaultpostcode' => array(
		'value'			=> 'xxxxx',
		'order'			=> 87,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'defaultstate' => array(
		'value'			=> 'MY',
		'order'			=> 88,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'defaultlastname' => array(
		'value'			=> '(unknown)',
		'order'			=> 100,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
);

$form['visuals'] = array(
	'visualenable' => array(
		'value'			=> 0,
		'order'			=> 10,
		'type'			=> 'toggleyn',
		'validation'	=> 'required'
	),
	'imgurl' => array(
		'value'			=> null,
		'order'			=> 30,
		'type'			=> 'text',
		'validation'	=> ''
	),
	'convertcharacterset' => array(
		'value'			=> '1',
		'order'			=> 40,
		'type'			=> 'toggleyn',
		'validation'	=> 'required'	
	)
);

$form['clientarea']	= array(
		'invoicesdisplay'	=> array(
				'value'			=> 1,
				'order'			=> 10,
				'type'			=> 'toggleyn',
				'validation'	=> 'required'
		),
		'invoicesnewwin'	=> array(
				'value'			=> 1,
				'order'			=> 20,
				'type'			=> 'toggleyn',
				'validation'	=> 'required'
		),
		'ticketsdisplay'	=> array(
				'value'			=> 1,
				'order'			=> 30,
				'type'			=> 'toggleyn',
				'validation'	=> 'required'
		),
		'ticketsnewwin'	=> array(
				'value'			=> 1,
				'order'			=> 40,
				'type'			=> 'toggleyn',
				'validation'	=> 'required'
		),
);