<?php

$__LANG = array (
	'integrator_logintitle'		=> 'Please Log In Below',
);
?>