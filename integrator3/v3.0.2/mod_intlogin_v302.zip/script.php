<?php
/**
 * @package		J!WHMCS Integrator:  Login Module
 * @copyright	Copyright (C) 2010 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: script.php 3 2012-04-19 14:16:13Z steven_gohigher $
 * @since		2.0.0
 */

defined('_JEXEC') or die('Restricted access');

/**
 * Called at installation
 * @author 		Steven
 * @version		3.0.2
 * 
 * @since		3.0.0
 */
class mod_intloginInstallerScript
{
	/**
	 * Called after the module has been installed or updated
	 * @access		public
	 * @version		3.0.2
	 * @param		string		- $type: contains the type of installation performed
	 * @param 		object		- $parent: the parent object calling the script
	 * 
	 * @since		3.0.0
	 */
	function postflight( $type, $parent )
	{
		if ( $type != "Install" ) return;
		
		$db = & JFactory::getDbo();
		
		$query	= "UPDATE `#__modules` SET `title` = 'Client Login' WHERE `module`='mod_intlogin' AND `client_id`=0";
		$db->setQuery($query);
		$db->query();
		
		return;
	}
}