<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.2 ( $Id: controller.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the main controller file for the backend of the Integrator
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.controller');
/*-- File Inclusions --*/


/**
 * Integrator Controller class object
 * @version		3.0.2
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntegratorController extends JController
{
	
	/**
	 * Displays the backend to the user
	 * @access		public
	 * @version		3.0.2
	 * 
	 * @since		3.0.0
	 */
	public function display()
	{
		// If the view hasn't been set, set it to default
		if ( is_null( IntegratorHelper :: get ( 'controller', null ) ) ) {
			IntegratorHelper :: set ( 'controller', 'default' );
		}
		
		if ( is_null( IntegratorHelper :: get ( 'view', null ) ) ) {
			IntegratorHelper :: set ( 'view', IntegratorHelper :: get ( 'controller', 'default' ) );
		}
		
		// Call up the parent display task
		parent::display();
	}
}