<?php
/**
 * Integrator
 * Fusion - Object File
 * 
 * @package    Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.13 ( $Id: render.php 78 2012-10-03 00:40:16Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the render class for pulling the site from Integrator
 * 
 */

/*-- Security Protocols --*/
if (!defined("INTEGRATOR")) die("This file cannot be accessed directly");
/*-- Security Protocols --*/

/**
 * Integrator Rendering Controller
 * @author		Steven
 * @version		3.0.13
 * 
 * @since		3.0.0
 */
class IntRender extends IntObject
{
	/**
	 * Stores the CURL Options Array
	 * @access		public
	 * @version		3.0.13
	 * @var			array
	 */
	public	$apioptions	= array();
	
	/**
	 * Stores the default POST variables to pass along
	 * @access		public
	 * @version		3.0.13
	 * @var			array
	 */
	public	$apipost	= array();
	
	/**
	 * Stores the IntUri Object of the Integrator URL
	 * @access		public
	 * @version		3.0.13
	 * @var			IntUri object
	 */
	public	$apiuri		= array();
	
	/**
	 * Stores reference to the IntCurl object
	 * @access		public
	 * @version		3.0.13
	 * @var			IntCurl object
	 */
	public	$curl		= null;
	
	/**
	 * Indicates the Integrator is enabled or not
	 * @access		public
	 * @version		3.0.13
	 * @var			boolean
	 */
	public	$enabled	= true;
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.13
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		if ( ( $post = $this->_build_post_array() ) === false ) {
			$this->enabled = false;
			return false;
		}
		
		if ( ( $uri = $this->_build_uri_array() ) === false ) {
			$this->enabled = false;
			return false;
		}
		
		$this->apioptions	= $this->_build_options_array();
		$this->apipost		= $post;
		$this->apiuri		= $uri;
		$this->curl			= new IntCurl();
	}
	
	
	/**
	 * Called up to retrieve the visual variables for the templates (by client_init hook)
	 * @access		public
	 * @version		3.0.13
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function client_render()
	{
		// Be sure we don't try if we can't
		if (! $this->enabled ) return;
		
		$response	= $this->_call_visual( $this->apiuri->toString() );
		
		// Bad response or can't connect so return so we dont generate weird errors
		if ( $response === false ) return;
		elseif ( $response['result'] != 'success' ) return $response['message'];
		
		if (! isset( $response['header']) || ! isset( $response['footer'] ) ) return;
		
		$this->_process_response( $response );
		
		return true;
	}
	
	
	/**
	 * Builds the default CURL options array
	 * @access		private
	 * @version		3.0.13
	 * 
	 * @return		array of CURL Options
	 * @since		3.0.0
	 */
	private function _build_options_array()
	{
		$options	= array(	'POST'				=> true,
								'TIMEOUT'			=> 30,
								'RETURNTRANSFER'	=> true,
								'POSTFIELDS'		=> array(),
								'FOLLOWLOCATION'	=> false,
								'HEADER'			=> true,
								'HTTPHEADER'		=> array( 'Expect:' ),
								'MAXREDIRS'			=> 5,
								'SSL_VERIFYHOST'	=> false,
								'SSL_VERIFYPEER'	=> false
		);
		
		return $options;
	}
	
	
	/**
	 * Builds the default post variables for the visual rendering
	 * @access		private
	 * @version		3.0.13
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	private function _build_post_array()
	{
		$SWIFT 		=   SWIFT :: GetInstance();
		$template	= & $SWIFT->TemplateGroup;
		$lang		= & $SWIFT->Language;
		$session	= & $SWIFT->Session;
		$cache		= & $SWIFT->Cache;
		$router		= & $SWIFT->Router;
		
		if ( version_compare( SWIFT_VERSION, '4.50', 'ge' ) ) {
			$module	= & $SWIFT->App;
		}
		else {
			$module	= & $SWIFT->Module;
		}
		
		// Catch bad pages...
		if ( in_array( $router->getAction(), array( 'Compressor' ) ) ) return false;
		
		// Filename build
		$filename	= strtolower( $module->GetName() . '.' . $router->GetController() . '.' . $router->GetAction() );
		
		// Language Retrieval
		$language	= $lang->GetLanguageCode();
		
		// Character Set
		$characterset	= "UTF-8";
		$langs		= $cache->Get( 'languagecache' );
		if ( is_array( $langs ) ) :
		foreach( $langs as $l ) {
			if ( $l['languagecode'] == $language ) {
				$characterset	= $l['charset'];
			}
		}
		endif;
		
		// Session ID
		$session_id	= base64_encode( $session->GetSessionID() );
		
		// SSL Chcek
		$isssl = ( isset( $GLOBALS['_SERVER']['HTTPS'] ) ? 1 : 0 );
		
		// Grab the cnxnid
		$_a	= $SWIFT->Settings->Get( 'integrator_cnxnid' );
		
		// Build the salt signature to pass along
		$salt		= mt_rand();
		$secret		= $SWIFT->Settings->Get( 'integrator_apisecret' );
		$signature	= base64_encode( hash_hmac( 'sha256', $salt, $secret, true ) );
		
		// Compact for return
		$data	= compact( 'filename', 'language', 'characterset', 'session_id', 'isssl', '_a', 'salt', 'signature' );
		
		// Check for a _v argument
		$_args	= $router->GetArguments();
		if (isset ( $_args['_v'] ) ) {
			$data['_v']	= $_args['_v'];
		}
		
		return $data;
	}
	
	
	/**
	 * Creates the Integrator URL
	 * @access		private
	 * @version		3.0.13
	 * 
	 * @return		IntUri Object
	 * @since		3.0.0
	 */
	private function _build_uri_array()
	{
		$SWIFT		= SWIFT :: GetInstance();
		$apiurl		= $SWIFT->Settings->Get( 'integrator_url' );
		if ( empty( $apiurl ) ) return false;
		
		$uri		= new IntUri( $apiurl );
		$uri->setPath( rtrim( $uri->getPath(), "/" ) . "/index.php/render/" );
		
		return $uri;
	}
	
	
	/**
	 * Calls up the visual retrieval with CURL
	 * @access		private
	 * @version		3.0.13
	 * @param		string		- $url: the completed URL to call up
	 * @param		array		- $post: any post variables to pass along
	 * @param		array		- $options: any updated options to include
	 * 
	 * @return		array containing result
	 * @since		3.0.0
	 */
	private function _call_visual( $url, $post = array(), $options = array() )
	{
		$post		= array_merge( $this->apipost, $post );
		$options	= array_merge( $this->apioptions, $options );
		
		$result		= $this->curl->simple_post( $url, $post, $options );
		
		if ( $result === false ) {
			/*
			echo var_dump( $url ) . '<pre>';
			var_dump( $post );
			echo base64_decode( $post['session_id'] );
			print_r( $this->curl );
			$this->curl->has_errors(); die();
			*/
			// error trapping for debug purposes
			return array( 'result' => 'error', 'message' => $this->curl->has_errors() );
		}
		
		if ( $options['HEADER'] == TRUE ) {
			list( $header, $response ) = explode( "\r\n\r\n", $result, 2 );
		}
		else {
			$response = $result;
		}
		
		// Convert response to XML object
		try {
			$xml = new SimpleXMLElement( $response );
			$xml = $this->_processSimpleXMLToArray( $xml );
			$xml['result']	= 'success';
		}
		catch ( Exception $e ) {
			if ( ( $this->debug ) || ( $GLOBALS['debug'] == true ) ) {
				echo "<h2>Problem Parsing XML Response from the Integrator</h2>";
				echo "=============================================<br/>\n";
				echo $url . "<br/>\n<pre>";
				echo $e->getLine();
				echo print_r( $e->getTrace(), 1);
				echo "=============================================<br/>\n";
				echo "<h3>Info</h3><pre>";
				echo print_r( $this->curl->info, 1 );
				echo "</pre>=============================================<br/>\n";
				echo "<h3>Posted Variables and Options</h3><pre>";
				echo print_r( $post, 1 );
				echo print_r( $options, 1 );
				echo "</pre>=============================================<br/>\n";
				echo "<h3>Header</h3><pre>";
				echo $header;
				echo "</pre>=============================================<br/>\n";
				echo "<h3>Response</h3><pre>";
				echo print_r( $response, 1 );
				echo "</pre>";
			}
			$xml = false;
		}
		
		return $xml;
	}
	
	
	/**
	 * Processes the response and sets variables into place
	 * @access		private
	 * @version		3.0.13
	 * @param		array		- $site: contains the base64 encoded parts of the site retrieved 
	 * 
	 * @since		3.0.0
	 */
	private function _process_response( $site )
	{
		// Grab an instances
		$swift = SWIFT::GetInstance();
		
		$header	= base64_decode( $site['header'] );
		$footer = base64_decode( $site['footer'] );
		
		// Remove Base HREF
		$regex	= '`(?P<front>)(?P<link><base[^>]*>)(?P<back>)`';
		$base	= null;
		$header	= preg_replace( $regex, "\${1}$base\${3}", $header );
		
		// Handle title
		$hdrparts		= preg_split( '`<title>.*</title>`', $header );
		$headerPreTitle	= $hdrparts[0];
		
		// Separate header now
		$hdrsubparts	= preg_split( '`</head>`', $hdrparts[1] );
		$hdrsubparts[1] = '</head>' . $hdrsubparts[1];
		
		// Assign variables for template use
		$swift->Template->Assign( '_htmlHeaderPreTitle', $headerPreTitle );
		$swift->Template->Assign( '_htmlHeaderPostTitle', $hdrsubparts[0] );
		$swift->Template->Assign( '_htmlHeaderPostBody', $hdrsubparts[1] );
		$swift->Template->Assign( '_htmlFooter', $footer );
	}
	
	
	/**
	 * Converts the SimpleXML object into an array
	 * @access		private
	 * @version		3.0.13
	 * @param		SimpleXMLElement	- $xml: the returned XML Element
	 * @param		string				- $attributesKey: if set will find a custom attribute key
	 * @param		string				- $childrenKey: if set will find a certain child key
	 * @param		string				- $valueKey: if set will find a special value key
	 * 
	 * @return		array 
	 * @since		3.0.0
	 */
	private function _processSimpleXMLToArray( SimpleXMLElement $xml, $attributesKey = null, $childrenKey = null, $valueKey = null )
	{
		if ( $childrenKey && ! is_string( $childrenKey ) ) {
			$childrenKey = '@children';
		}
		
		if ( $attributesKey && ! is_string( $attributesKey ) ) {
			$attributesKey = '@attributes';
		}
		
		if ( $valueKey && ! is_string( $valueKey ) ) {
			$valueKey = '@values';
		}
		
		$return	= array();
		$name	= $xml->getName();
		$_value	= trim((string)$xml);
		
		if (! strlen( $_value ) ) {
			$_value = null;
		}
		
		if ( $_value !== null ) {
			if ( $valueKey ) {
				$return[$valueKey] = $_value;
			}
			else {
				$return = $_value;
			}
		}
		
		$children	= array();
		$first		= true;
		
		foreach ( $xml->children() as $elementName => $child )
		{
			$value	= $this->_processSimpleXMLToArray( $child, $attributesKey, $childrenKey, $valueKey );
			
			if ( isset( $children[$elementName] ) ) {
				if ( is_array( $children[$elementName] ) ) {
					if ( $first ) {
						$temp	= $children[$elementName];
						unset( $children[$elementName] );
						$children[$elementName][]	= $temp;
						$first	= false;
					}
					$children[$elementName][]	= $value;
				}
				else {
					$children[$elementName]	= array( $children[$elementName], $value );
				}
			}
			else {
				$children[$elementName]	= $value;
			}
		}
		
		if ( $children ) {
			if ( $childrenKey ) {
				$return[$childrenKey] = $children;
			}
			else {
				$return	= array_merge( $return, $children );
			}
		}
		
		$attributes	= array();
		foreach ( $xml->attributes() as $name => $value )
		{
			$attributes[$name]	= trim($value);
		}
		
		if ( $attributes ) {
			if ( $attributesKey ) {
				$return[$attributesKey] = $attributes;
			}
			else {
				$return	= array_merge( $return, $attributes );
			}
		}
		
		return $return;
	} 
}