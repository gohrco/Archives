<?php
/**
 * Integrator
 * System - Integrator Plugin Script
 *
 * @package    Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.13 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      3.0.9
 *
 * @desc       This is the installation script executed by Joomla! 2.5+
 *
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( "joomla.filesystem.file" );


/**
 * plgauthenticationintegrator_system installation Script
 * @version		3.0.13
 *
 * @since		3.0.9
 * @author		Steven
 */
if (! class_exists( 'plgsystemintegrator_systemInstallerScript' ) ) {	// Workaround for Installation purposes
	class plgsystemintegrator_systemInstallerScript
	{
		/**
		 * Run at the time of upgrade only
		 * @access		public
		 * @version		3.0.13
		 * @param		JApplication object	- $parent: calls this function
		 *
		 * @since		3.0.9
		 */
		public function install( $parent )
		{
			return;
		}


		/**
		 * Run at the time of uninstallation only
		 * @access		public
		 * @version		3.0.13
		 * @param		JApplication object	- $parent: calls this function
		 *
		 * @since		3.0.9
		 */
		public function uninstall( $parent )
		{
			return;
		}


		/**
		 * Run at the time of upgrade only
		 * @access		public
		 * @version		3.0.13
		 * @param		JApplication object	- $parent: calls this function
		 *
		 * @since		3.0.9
		 */
		public function update( $parent )
		{
			return;
		}


		/**
		 * Runs prior to installation, upgrade or uninstallation
		 * @access		public
		 * @version		3.0.13
		 * @param		string				- $type: the task being performed (install, upgrade etc)
		 * @param		JApplication object	- $parent: calls this function
		 *
		 * @since		3.0.9
		 */
		public function preflight( $type, $parent )
		{
			return;
		}


		/**
		 * Runs after installation, upgrade
		 * @access		public
		 * @version		3.0.13
		 * @param		string				- $type: the task being performed (install, upgrade etc)
		 * @param		JApplication object	- $parent: calls this function
		 *
		 * @since		3.0.9
		 */
		public function postflight( $type, $parent )
		{
			$path			=	JPATH_PLUGINS		. DIRECTORY_SEPARATOR
			.	'system'		. DIRECTORY_SEPARATOR
			.	'integrator_system'		. DIRECTORY_SEPARATOR;

			JFile :: move( 'integrator_system_30.xml', 'integrator_system.xml', $path );
			return;
		}
	}
}