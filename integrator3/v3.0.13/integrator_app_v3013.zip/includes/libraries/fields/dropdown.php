<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class to generate a dropdown field
 * @version		3.0.13
 * 
 * @since		3.0.2
 * @author		Steven
 */
class DropdownField extends form_definition
{

	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.13
	 * @param		array		- $options: contruction options
	 * 
	 * @since		3.0.2
	 */
	public function __construct( $options = array() )
	{
		parent::__construct( $options );
	}
	
	
	/**
	 * Method to generate a form field
	 * @access		protected
	 * @version		3.0.13
	 * 
	 * @return		string
	 * @since		3.0.2
	 * @see			form_definition::field()
	 */
	protected function field()
	{
		$name		= $this->name . ( $this->array ? '[]' : '' );
		$arguments	= $this->arguments();
		
		if (! isset( $arguments['class'] ) ) $arguments['class'] = null;
		
		$extras		= "id=\"{$this->lang}\"";
		foreach ( $arguments as $key => $value ) $extras .= " {$key}=\"{$value}\"";
		
		$options	= $this->translate( $this->lang, true );
		$field		= form_dropdown( $name, $options, set_value( $this->name, $this->value ), $extras );
		
		return $field;
	}
}