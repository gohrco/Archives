/**
 * Updatecheck performs check of versions via ajax
 */
function updatecheck() {
	var updtxt		= jQuery( '#version_results' );
	var updateurl	= ajaxurl + '/updatecheck';
	
	jQuery.ajax({
		type: 'POST',
		url: updateurl,
	}).success( function( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		updtxt.html( obj.msg );
		if ( obj.result == 'success' ) {
			if ( obj.data == true ) {
				updtxt.addClass( 'label-important' );
			}
			else {
				updtxt.addClass( 'label-success' );
			}
		}
	});
}


jQuery(document).ready(function() {
	updatecheck();
});

/**
 * End Updatecheck
 */

/**
 * Retrieves the system status via ajax (help/systemstatus)
 */
function systemCheck() {
	var systemurl	= ajaxurl + '/systemstatus';
	
	jQuery.ajax({
		type: 'POST',
		url:	systemurl,
		}).success( function( msg ) {
			var obj		= jQuery.parseJSON( msg );
			var html	= null;
			
			jQuery.each( obj.html, function( index, value ) {
				html = html + '<tr>';
				html = html + '<td>' + value.name + ' (' + value.type + ')</td>';
				html = html + '<td class="center">' + value.active + '</td>';
				html = html + '<td class="center">' + value.user + '</td>';
				html = html + '<td class="center">' + value.visual + '</td>';
				html = html + '<td class="center">' + value.ping + '</td>';
				html = html + '<td>' + value.result + '</td>';
				html = html + '</td>';
				html = html + '</tr>';
			});
			
			jQuery("table#dataTable tbody").html( html );
	})
}

/**
 * End Systemcheck
 */