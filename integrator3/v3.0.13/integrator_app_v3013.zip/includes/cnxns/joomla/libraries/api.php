<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Joomla
 * Enter description here ...
 * @author Steven
 *
 */
class Joomla_API extends API_Library
{
	protected		$apioptions	= array();
	protected		$apipost	= array();
	protected		$apiurl		= null;
	
	public function load( $options )
	{
		parent::load( $options );
		
		// =====================================
		// ---BEGIN: Set default api options
		$apioptions	= $this->get( 'apioptions' );
			$apioptions['HEADER'] =  true;
			$apioptions['RETURNTRANSFER'] = true;
			$apioptions['FOLLOWLOCATION'] = false;
		$this->set( 'apioptions', $apioptions );
		// ---END:   Set default api options
		// =====================================
		// ---BEGIN: Determine SSL settings properly
// 		$usessl	=    secure_task( 'api', (bool) $this->get( "sslenabled", false, 'params' ) );
// 		if ( $usessl ) {
// 			$apioptions	= $this->get( 'apioptions' );
// 			//$apioptions['SSL_VERIFYHOST'] = true;
// 			$apioptions['SSL_VERIFYPEER'] = false;
// 			$apioptions['CAINFO']			= BASEPATH . APPPATH . 'assets' . DIRECTORY_SEPARATOR . 'cacert.pem';
// 			$this->set( 'apioptions', $apioptions );
// 		}
		// ---END: Determine SSL settings properly
		// =====================================
		// ---BEGIN: Setting GLOBAL API curl options
// 		$apioptions	= $this->get( 'apioptions' );
// 			if ( $this->get( 'sslverify', 0, 'api' ) == 1 ) {
// 				$apioptions['SSL_VERIFYHOST'] = true;
// 				$apioptions['SSL_VERIFYPEER'] = true;
// 			}
// 		$this->set( 'apioptions', $apioptions );
		// ---END:   Setting GLOBAL API curl options
		// =====================================
		// ---BEGIN: Setting API url
		$url 	=   $this->get( "apiurl", $this->get( 'baseurl', null, 'params' ), 'api' );
		$uri	= & Uri::getInstance( $url );
// 		$uri->setScheme( "http" . ( ( $this->get( "sslverify", 0, 'api' ) == 1 ) ? "s" : "" ) );
// 		$uri->setScheme( "http" . ( $usessl ? "s" : "" ) );	
		$uri->setPath( rtrim( $uri->getPath(), "/" ) );
		$uri->setVar( "option", "com_integrator" );
		$uri->setVar( "controller", "api" );
		$this->set( "apiurl", $uri->toString() );
		// ---END:   Setting API url
		// =====================================
		// ---BEGIN: Setting API curl options
		$apioptions	= $this->get( 'apioptions' );
			// Do something if needed
		$this->set( 'apioptions', $apioptions );
		// ---END:   Setting API curl options
		// =====================================
		// ---BEGIN: Setting API variables
		$apipost	= $this->get( "apipost" );
			
			// Build secret code
			$params		= & Params :: getInstance();
			$salt		=   mt_rand();
			$secret		=   $params->get( 'Secret' );
			$signature	=   base64_encode( hash_hmac( 'sha256', $salt, $secret, true ) );
			
			$apipost['username']	= $this->get( "username", null, 'api' );
			$apipost['password']	= $this->get( "password", null, 'api' );
			$apipost['signature']	= $signature;
			$apipost['salt']		= $salt;
		$this->set( "apipost", $apipost );
		// ---END:   Setting API variables
		// =====================================
		
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE API FUNCTIONS AND ARE CALLED DIRECTLY
	 * **********************************************************************
	 */
	
	
	/**
	 * Called to authenticate a set of user credentials
	 * @access		public
	 * @version		3.0.13
	 * @param		array		- $post: an array of variables to post (should be empty if no child library)
	 * @param		array		- $credentials:  allows for specifying creds to api call; will pull from session otherwise
	 * 
	 * @return		boolean true if authenticated, false if failed
	 * @since		3.0.0
	 */
	public function authenticate( $post = array(), $credentials = null )
	{
		if ( $credentials == null ) {
			$credentials = get_var( "credentials" );
		}
		
		$post['task']		= "authenticate";
		$post['username']	= ( isset( $post['username'] ) ? $post['username'] : $credentials['username'] );
		$post['password']	= ( isset( $post['password'] ) ? $post['password'] : $credentials['password'] );
		
		$call	= $this->_call_api( $post, 'authenticate' );
		
		return ( $call['result'] == 'success' );
	}
	
	
	/**
	 * Retrieves information about the Integrator 3 cnxn
	 * @access		public
	 * @version		3.0.13
	 *
	 * @return		array or false on error
	 * @since		3.0.1 (0.1)
	 */
	public function get_info()
	{
		$post	= array( 'task' => 'get_info' );
		
		$call	= $this->_call_api( $post, 'get_info' );
		
		return ( $call['result'] == 'success' ? $call['data'] : array() );
	}
	
	
	/**
	 * Retrieves the languages on this connection
	 * @access		public
	 * @version		3.0.13
	 * 
	 * @return		array containing either the languages or empty array
	 * @since		3.0.0
	 */
	public function get_languages()
	{
		$post	= array(	'task'		=> "get_languages"
		);
		
		$call	= $this->_call_api( $post, 'get_languages' );
		
		return ( $call['result'] == 'success' ? $call['data'] : array() );
	}
	
	
	/**
	 * Retrieves missing credentials from the connection
	 * @access		public
	 * @version		3.0.13
	 * @param		string		- $credential: the item being sought
	 * 
	 * @return		string containing the found item or false on error or nothing found
	 * @since		3.0.0
	 */
	public function get_missing_credential( $credential = 'password' )
	{
		$missing_item = false;
		switch( $credential ):
		case 'username':
			$creds		= get_var( "credentials" );
			$email		= $creds['email'];
			
			$post	= array(	'task'		=> "get_missing_credential",
								'retrieve'	=> "username",
								'email'		=> $email
			);
			
			$call	= $this->_call_api( $post, 'get_missing_credential: username' );
			
			$missing_item	= ( $call['result'] == 'success' ? $call['data'] : false );
			break;
			
		case 'email':
			$creds		= get_var( "credentials" );
			$username	= $creds['username'];
			
			$post	= array(	'task'		=> "get_missing_credential",
								'retrieve'	=> 'email',
								'username'	=> $username
			);
			
			$call	= $this->_call_api( $post, 'get_missing_credential: email' );
			
			$missing_item	= ( $call['result'] == 'success' ? $call['data'] : false );
			break;
			
		case 'password':
		default:
			// We can't get a password from WHMCS
			$missing_item = false;
			break;
		endswitch;
		return $missing_item;
	}
	
	
	/**
	 * Retrieves the pages in this connection
	 * @access		public
	 * @version		3.0.13
	 * 
	 * @return		array containing the pages on this connection
	 * @since		3.0.0
	 */
	public function get_pages()
	{
		static $page;
		
		if (! is_array( $page ) ) $page = array();
		
		if (! isset( $page[$this->id] ) ) {
			$page[$this->id]	= array();
			$return				= array();
			
			$post	= array(	'task'		=> "get_menutree"
			); 
			
			$call	= $this->_call_api( $post, 'get_pages' );
			
			// Nothing sent back
			if (! isset( $call['result'] ) ) {
				debug( 'Joomla: API - nothing was returned by the connection' );
				return array();
			}
			
			// Error sent back
			if ( $call['result'] != 'success' ) {
				debug( 'Joomla: API - there was an error sent back by the connection', 'info', false );
				return array();
			}
			
			$data = $call['data']['data'];
			$vers = $call['data']['version'];
			
			foreach( $data as $menutype => $menuitems ) {
				if (! isset( $return[$menutype] ) ) {
					$return[$menutype] = array();
				}
				
				foreach( $menuitems as $menuitem ) {
					$menuitem = (object) $menuitem;
					if (! isset( $return[$menutype][$menuitem->parent_id] ) ) {
						$return[$menutype][$menuitem->parent_id] = array();
					}
					$return[$menutype][$menuitem->parent_id][] = array( 'value' => $menuitem->id, 'name' => $menuitem->name );
				}
			}
			
			foreach( $return as $menutype => $items ) {
				$items	= build_menu_tree( $items, ( version_compare( $vers, '1.6.0', 'ge' ) ? 1 : 0 ) );
				foreach( $items as $item ) {
					$page[$this->id][$menutype][$item['value']] = $item['name'];
				}
			}
		}
		
		return $page[$this->id];
	}
	
	
	/**
	 * Called to test a connection to ensure it responds
	 * @access		public
	 * @version		3.0.13
	 * @param		mixed		- $check: if a string, assume its an URL, if array test credentials
	 * 
	 * @return		mixed depending on need boolean true if responsive
	 * @since		3.0.0
	 */
	public function ping( $check = null )
	{
		if ( is_string( $check ) ) {
			$post	= array( 'task' => 'ping' );
			$purl	= $check;
			$optns	= array( 'RETURNTRANSFER' => false );
		}
		else if ( is_array( $check ) ) {
			$post	= array( 'task' => 'apilogin' );
			$purl	= null;
			$optns	= array_merge( $check, array( 'RETURNTRANSFER' => true ) );
		}
		else {
			$post	= array( 'task' => 'ping' );
			$purl	= null;
			$optns	= array( 'RETURNTRANSFER' => true );
		}
		
		$call	= $this->_call_api( $post, 'ping', $purl, $optns );
		
		return ( is_string( $check ) ? $call : ( is_array( $check ) ? $call['data'] : $call['result'] == 'success' ) );
	}
	
	
	/**
	 * Updates a setting on the cnxn
	 * @access		public
	 * @version		3.0.13
	 * @param		array		- $post: contains the settings array to update
	 *
	 * @return		true on success; false on error
	 * @since		3.0.0 (0.3)
	 */
	public function update_settings( $post = array() )
	{
		// Catch empties
		if ( ( $data = $this->_filter_setting_array( $post ) ) === false ) return true;
		
		// Assign task
		$send	= array(
					'settings'	=> $data,
					'task'		=> 'update_settings'
		);
		
		// Make the call
		$call	= $this->_call_api( $send, 'update_settings' );
		
		// Return result
		return $call['result'] == 'success';
	}
	
	
	/**
	 * Create a user on this connection
	 * @access		public
	 * @version		3.0.13
	 * @param		array		- $post: array of variables to create user with
	 * 
	 * @return		boolean true if successful, error message otherwise
	 * @since		3.0.0
	 */
	public function user_create()
	{
		$post			= $this->get_data();
		$post['task']	= "user_create";
		
		$call = $this->_call_api( $post, 'user_create' );
		
		return ( $call['result'] == 'success' ? true : $call['data'] );
	}
	
	
	/**
	 * Finds a user by username or email
	 * @access		public
	 * @version		3.0.13
	 * @param		boolean		- $data: if we want the data back set true, else return boolean
	 * 
	 * @return		varies can be boolean or the data result
	 * @since		3.0.0
	 */
	public function user_find( $data = false )
	{
		$post	= $this->get_data();
		$post['task']	= 'user_find';
		$call = $this->_call_api( $post, 'user_find' );
		
		if ( $call['result'] == 'success' ) {
			$this->place_data( $call['data'] );
		}
		else {
			$this->set_error( $call['data'] );
		}
		
		return ( $call['result'] == 'success' ? ( $data ? $call['data'] : true ) : $call['data'] );
	}
	
	
	/**
	 * Searches for a user based on entry
	 * @access		public
	 * @version		3.0.13
	 * @param		array		- $post: contains search=>value
	 * 
	 * @return		array
	 * @since		3.0.1 (0.2)
	 */
	public function user_search( $post = array() )
	{
		if ( empty( $post ) ) return array();
		$post['task']	= 'user_search';
		$call			= $this->_call_api( $post, 'user_search' );
		
		if ( $call['result'] != 'success' ) return array();
		return $call['data'];
	}
	
	
	/**
	 * Updates user information on this connection
	 * @access		public
	 * @version		3.0.13
	 * @param		array		- $post: an array of variables to update
	 * 
	 * @return		boolean true if successful, error message otherwise
	 * @since		3.0.0
	 */
	public function user_update()
	{
		$post			=   $this->get_data();
		$post['task']	=   "user_update";
		
		$call = $this->_call_api( $post, 'user_update' );
		return ( $call['result'] == 'success' ? true : $call['data'] );
	}
	
	
	/**
	 * User removal call to the Joomla 1.6 api
	 * @access		public
	 * @version		3.0.13
	 * @param		string		- $email: contains just an email address
	 * 
	 * @return		boolean true if successful, false otherwise
	 * @since		3.0.0
	 */
	public function user_remove() 
	{
		$post	= $this->get_data();
		$post['task']	= 'user_remove';
		
		$call	= $this->_call_api( $post, 'user_remove' );
		return ( $call['result'] == 'success' ? true : $call['data'] );
	}
	
	
	/**
	 * Validates a set of new user credentials
	 * @access		public
	 * @version		3.0.13
	 * @param		array		- $data: standard formed user data from Integrator
	 * 
	 * @return		boolean true if valid, false otherwise
	 * @since		3.0.0
	 */
	public function user_validation_on_create()
	{
		$data			= $this->get_data();
		$data['task']	= "user_validation_on_create";
		
		$call	= $this->_call_api( $data, 'user_validation_on_create' );
		
		return ( $call['result'] == 'success' ? true : $call['data'] );
		
	}
	
	
	/**
	 * Validates an updated set of user information
	 * @access		public
	 * @version		3.0.13
	 * @param		array		- $data: standard formed user data from Integrator
	 * 
	 * @return		boolean true if valid, false otherwise
	 * @since		3.0.0
	 */
	public function user_validation_on_update()
	{
		$data			=   $this->get_data();
		$data['task']	= "user_validation_on_update";
		
		$call			= $this->_call_api( $data, 'user_validation_on_update' );
		
		return ( $call['result'] == 'success' ? true : $call['data'] );
	}
	
	
	/**
	 * Calls the API connection through curl
	 * @access		public
	 * @version		3.0.13
	 * @param		array		- $post: an array of items to post to the API
	 * @param		string		- $action: the requested action (for logging purposes)
	 * @param		string		- $api_url: the API url
	 * @param		array		- $api_options: any additional API CURLSETOPT to set
	 * 
	 * @return		response from API or false on error
	 * @since		3.0.0
	 * @see 		Cnxns_library::_call_api()
	 */
	protected function _call_api( $post = array(), $action = 'unknown', $api_url = null, $api_options = array() )
	{
		if ( empty( $post ) ) return false;
		
		// Handle URL
		$api_url		= ( $api_url == null ? $this->get( 'apiurl' ) : $api_url );
		
		// Handle Options
		$api_options	= array_merge( $this->get( 'apioptions' ), $api_options );
		
		// Pull the task
		$task			= $post['task'];
		unset( $post['task'] );
		
		// Build the post array
		$api_post		= array( 'task' => $task, 'data' => $post, 'credentials' => $this->get( 'apipost' ) );
		
		$result			= parent::_call_api( $api_post, $api_url, $api_options, $action );
		
		if ( ( $response = json_decode( $result, TRUE ) ) == NULL ) {
			debug_error( $result, false, 1 );
			$CI = & get_instance();
			if ( $CI->debug_on( "API Call from Joomla API" ) ) {
				echo $CI->curl->debug( "API Call from Joomla API" );
			}
			return $result;
		}
		else {
			if ( isset( $response['debug'] ) ) debug_array( $response['debug'] );
			return $response;
		}
	}
	
	
	/**
	 * Overwrite default find api cookies to be sure we find actual user cookies
	 * @access		protected
	 * @version		3.0.13
	 * @param		string		- $header: the data sent back in the header from the API
	 * 
	 * @since		3.0.0
	 * @see			API_Library::_find_api_cookies()
	 */
	protected function _find_api_cookies( $header )
	{
		$data	= null;
		preg_match_all('/^Set-Cookie: (.*?)=(.*?);/m', $header, $cookies, PREG_SET_ORDER );
		
		foreach ( $cookies as $cookie ) {
			// Joomla session variables are 32 long, be sure we are grabbing the correct cookie!
			if ( strlen( $cookie[1] ) == 32 ) {
				$data = $cookie[1] . '=' . $cookie[2];
				break;
			}
		}
		
		if ( empty( $data ) ) { 
			log_message( 'debug', 'Joomla Cnxn API_library (line ' . __LINE__ . '): Unable to find a cookie in header' );
			debug( 'api.findapicookie.nocookie', 'debug' );
			return false;
		}
		
		return $data;
	}
}