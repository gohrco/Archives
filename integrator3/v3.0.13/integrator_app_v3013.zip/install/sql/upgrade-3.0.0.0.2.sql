INSERT IGNORE INTO `__DBPREFIX__settings` (`key`, `value`) VALUES
('BanFreebies', '0' );

-- command split --

UPDATE IGNORE `__DBPREFIX__settings` SET `value`='3.0.0.0.3' WHERE `key` = 'Version';