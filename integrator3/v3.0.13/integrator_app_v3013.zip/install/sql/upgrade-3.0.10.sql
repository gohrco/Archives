
UPDATE IGNORE `__DBPREFIX__settings` SET `value`='3.0.11' WHERE `key` = 'Version';
