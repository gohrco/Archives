<?php
/**
 * Integrator 3 - System Plugin
 * 		Updateuser File
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.06 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This is the Updateuser Task which will update a given user in our Joomla site from I3
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * User Update API Class
 * @version		3.1.06
 *
 * @since		3.1.00
 * @author		Steven
 */
class UserupdateIntegratorAPI extends IntegratorAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		3.1.06
	 * 
	 * @since		3.1.00
	 * @see			IntegratorAPI :: execute()
	 */
	public function execute()
	{
		$helper	=	dunloader( 'helpers', 'com_integrator' );
		$input	=	dunloader( 'input', true );
		$config	=	dunloader( 'config', 'com_integrator' );
		$data	=	$input->getVar( 'data', array(), 'array' );
		$by		=   ( isset( $data['email'] ) ? 'email' : 'username' );
		
		if (! ( $user = get_joomlauser( $data[$by], $by ) ) ) {
			if (! $config->get( 'addmissingusersonupdate', false ) ) {
				$this->error( JText::sprintf( 'COM_INTEGRATOR_API_USERUPDATE_ERRORNOFIND', $data[$by] ) );
			}
			else {
				
				$user	=	JFactory :: getUser();
				$update	=	$data['update'];
				
				if (! isset( $update['password'] ) ) {
					$update['password']	=	JApplication :: getHash( mt_rand() );
				}
				
				if (! isset( $update['username'] ) ) {
					$update['username']	=	substr( JApplication :: getHash( mt_rand() ), 0, 8 );
				}
				
				if (! isset( $update['groups'] ) ) {
					$update['groups']	=	array( 2 );
				}
			}
		}
		else {
			$user	=	JFactory::getUser( $user['id'] );
			$update	=	$data['update'];
		}
		
		if (! $user->bind( $update ) ) {
			$this->error( 'USERUPDATE_ERRORBIND' );
		}
		
		if (! $user->save() ) {
			$this->error( 'USERUPDATE_ERRORSAVE' );
		}
		
		$this->success( true );
	}
}