<?php defined('_JEXEC') or die('Restricted access'); ?>
<!-- Integrator_Marker -->
<integrator />

<?php if ( $this->params->get( 'show_page_title' ) ): ?>
<div class="componentheading">
	Integrator Blank Page - <?php echo $this->params->get( 'page_title' ); ?>
</div>
<?php endif; ?>

<table class="contentpaneopen">
	<tr>
		<td valign="top">
			<p>It should not be possible to see this message.  If you do, there is a problem, please check the Support forums at Go Higher.</p>
		</td>
	</tr>
</table>

<integrator />

<!-- Integrator_Tag -->
<!-- Integrator_Marker -->