/**
 * noconflict.js
 * Compatible with WHMCS v5.2 and above
 * 
 * Integrator 3 - Custom Javascript File
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.06 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 */

jQuery.noConflict();