<?php
/**
 * Integrator 3
 * WHMCS - Hook File
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.06 ( $Id: hooks.php 403 2015-07-16 13:40:12Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      2.4.0
 * 
 * @desc       This file included in the hooks execution and calls appropriate functions for actions
 * 
 */

/*-- Security Protocols --*/
if (!defined("WHMCS")) die("This file cannot be accessed directly");
/*-- Security Protocols --*/

// ACCOMODATION FOR LIVEHELP MODULE
if ( isset( $_SERVER['REQUEST_URI'] ) && ( strpos( $_SERVER['REQUEST_URI'], 'livehelp/xml/WebService.php' ) !== false || strpos( $_SERVER['REQUEST_URI'], 'modules/livehelp/' ) !== false ) ) {
	return;
}

if (! function_exists( 'get_dunamis' ) ) {
	$path	= dirname( dirname( dirname( dirname(__FILE__) ) ) ) . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'dunamis.php';
	if ( file_exists( $path ) ) require_once( $path );
}

if ( function_exists( 'get_dunamis' ) ) {
	get_dunamis( 'integrator' );
}

// Intercept login requests to verify we have a valid email / password (be sure to not redirect from admin area)
if (! is_admin() && ! from_adminarea() && get_filename() == 'dologin' ) {
	
	$login	=	dunmodule( 'integrator.login' );
	
	if (! $login->authenticate() ) {
		$login->redirectOnError();
	}
}

// Intercept Contact Deletions to grab the previously set data before losing them
// ------------------------------------------------------------------------------
// --------
// Backend
// --------
if ( is_admin() && get_filename() == 'clientscontacts' && in_array( dunloader( 'input', true )->getVar( 'action', false ), array( 'save', 'delete' ) ) ) {
	global $oldcontact;
	$oldcontact	= get_user_from_db( dunloader( 'input', true )->getVar( 'contactid' ), 'contact' );
}
// --------
// Frontend
// --------
else if (! is_admin() && get_filename() == 'clientarea' && in_array( dunloader( 'input', true )->getVar( 'action', false ), array( 'contacts' ) ) && dunloader( 'input', true )->getVar( 'delete', false ) == 'true' ) {
	global $oldcontact;
	$oldcontact	= get_user_from_db( dunloader( 'input', true )->getVar( 'id' ), 'contact' );
} 

// Intercept at time of registration and see what we should be doing
// ------------------------------------------------------------------------------
if (! is_admin() && get_filename() == 'register' ) {
	$client	=	dunmodule( 'integrator.client' );
	$client->checkRegistration();
}

// Intercept logout attempts when users are already logged out
// ------------------------------------------------------------------------------
if (! is_admin() && get_filename() == 'logout' && ! isset( $_SESSION["uid"] ) && dunloader( 'input', true )->getVar( 'returntoadmin', false ) != '1' ) {
	dunmodule( 'integrator.login' )->logout();
}

// WHMCS doesn't natively wrap invoice / quotes
// ------------------------------------------------------------------------------
if (! is_admin() && ( get_filename() == 'viewinvoice' || get_filename() == 'viewquote' ) && dunloader( 'config', 'integrator' )->get( 'wrapinvoice', true ) ) {
	// We must retrieve the user info ourselves
	$vars	=	array();
	if ( isset( $_SESSION['uid'] ) ) {
		$id		=	$_SESSION['uid'];
		
		$vars	=	array(
				'loggedin'		=>	true,
				'loggedinuser'	=>	get_user_from_db( $id )
		);
		$vars['language']	=	$vars['loggedinuser']['language'];
	}
	
	dunmodule( 'integrator.render' )->execute( $vars );
}