<?php


/**
 * Function for building a username based on JWHMCS settings
 * @version		3.1.06 ( $id )
 * @param		array		- $user: the user array to use
 * 
 * @return		string
 * @since		3.1.00
 */
if (! function_exists( 'build_username' ) ) {
function build_username( $user )
{
	$user	=	(object) $user;
	$config	=	dunloader( 'config', 'integrator' );
	$input	=	dunloader( 'input', true );
	$method	=	$config->get( 'userstyle', 1 );
	
	// Build the username
	if ( $method == 1 )
	{
		$manner	=	$config->get( 'usernamestyle', '3' );
		$name	=	null;
		
		switch ( $manner ) :
			// Create the username as `firstname.lastname`
			case '1' :
				$name	=	"{$user->firstname}.{$user->lastname}";
			break;
			// Create the username as `lastname.firstname`
			case '2' :
				$name	=	"{$user->lastname}.{$user->firstname}";
				break;
			// Create the username as `random`
			default :
			case '3' :
				for ($i=0; $i<12; $i++) {
					$d = rand(1,30)%2;
					$name	.=	( $d ? chr(rand(65,90)) : chr(rand(48,57)));
				}
				$name	=	ucfirst(strtolower( $name ) );
				break;
			// Create the username as `f.lastname`
			case '4' :
				$name	=	substr($user->firstname, 0, 1).".{$user->lastname}";
				break;
			// Create the username as `firstname.l`
			case '5' :
				$name	=	"{$user->firstname}.".substr($user->lastname, 0, 1);
				break;
			// Create the username as `firstname`
			case '6' :
				$name	=	"{$user->firstname}";
				break;
			// Create the username as `lastname`
			case '7' :
				$name	=	"{$user->lastname}";
				break;
			// Create the username as their email address
			case '8' :
				$name	=	"{$user->email}";
				break;
		endswitch;
	}
	// We want to use a custom client field so find it in the input array
	else if ( $method == '2' )
	{
		$fieldid		=	get_custom_field_id( $config->get( 'usernamefield' ), 'client' );
		$customfields	=	$input->getVar( 'customfield', array(), 'request', 'array' );
		
		if ( isset( $customfields[$fieldid] ) ) {
			$name	=	$customfields[$fieldid];
		}
		
		if ( empty( $name ) ) {
			$config->set( 'userstyle', '1' );
			$name	=	build_username( $user );
			$config->set( 'userstyle', '2' );
			
			$wapi	=	dunloader( 'whmcsapi', 'integrator' );
			$wapi->log( 'Helper', 'Build Username', 'No username provided at user creation, creating our own' );
		}
	}
	
	return $name;
}
}

/**
 * Function for checking compatibility with applications
 * @version		3.1.06 ( $id )
 * @param		string		- $app: the application we are testing - for future expansion
 * 
 * @return		boolean
 * @since		2.5.6
 */
if (! function_exists( 'check_compatible' ) ) {
function check_compatible( $app = 'dunamis' )
{
	switch ( $app ) :
	
	case 'dunamis'		:	return version_compare( DUNAMIS, '1.2.0', 'ge' );
	
	endswitch;
}
}
/**
 * Common method for creating a consistant user array to send to the Integrator
 * @access		private
 * @version		3.1.06
 * @param		array		- $newuser: new user data to send to Integrator
 * @param		array		- $olduser: if an edit, the original data
 * @param		boolean		- $is_new: is new or not
 * @param		string		- $direction: to => going to Integrator, from => coming from (not used yet)
 * @param		string		- $type: which type of user to convert (client|contact)
 *
 * @return		array
 * @since		3.1.00
 */
if (! function_exists( 'convert_user' ) ) {
function convert_user( $newuser, $olduser, $is_new, $direction = 'to', $type = 'client' )
{
	$input		=	dunloader( 'input', true );
	$newuser	=	(array) $newuser;
	$olduser	=	(array) $olduser;
	$data		=	array();
	
	if ( version_compare( DUN_ENV, '5.2', 'ge' ) ) {
		$check	=	array( 'userid', 'contactid', 'email', 'firstname', 'lastname', 'companyname', 'address1', 'address2', 'city', 'state', 'postcode', 'country', 'phonenumber', 'active', 'subaccount', 'status' );
	}
	else {
		$check	=	array( 'userid', 'contactid', 'email', 'firstname', 'lastname', 'company', 'address1', 'address2', 'city', 'state', 'postcode', 'country', 'phonenumber', 'active', 'subaccount', 'status' );
	}
	
	// If we are a new user...
	if ( $is_new ) {
		
		$check[] = 'password';
			
		foreach ( $check as $c ) {
			if ( empty( $newuser[$c] ) || (! isset( $newuser[$c] ) ) ) continue;
			if ( $c == 'userid' ) $data['clientid'] = $newuser[$c];
			elseif ( $c == 'status' ) $data[$c] = ( $newuser[$c] == 'Closed' ? 0 : 1 );
			else $data[$c] = $newuser[$c];
		}
		
		// If we are creating a contact we must pull the raw pw
		if ( $type == 'contact' ) {
			$data['password'] = $input->getVar( 'password', null );
		}
		
		if (! empty( $data['password'] ) ) {
			$data['password2'] = $data['password'];
		}
		
		$data['name']		=	$data['firstname'] . ' ' . $data['lastname'];
		
		// Workaround in case no first / last name is present (thanks Marcel)
		if (! $data['firstname'] && ! $data['lastname'] && $newuser['companyname'] ) {
			$data['name']	=	$newuser['companyname'];
		}
		
		$data['username']	=	build_username( $data );
	}
	// Existing User
	else {
	
		// If on the front end we can pull the original contact info from the database
		if ( $type == 'contact'  && /*! is_admin() && */empty( $olduser ) ) {
			$olduser = get_user_from_db( $newuser['contactid'], 'contact' );
		}
		// No way to update contacts without risking damage to other connections so return false
		else if ( $type == 'contact' && is_admin() ) {
			//return false;
		}
		
		foreach ( $check as $c ) {
			if ( empty( $newuser[$c] ) || (! isset( $newuser[$c] ) ) ) continue;
			if ( $c == 'userid' ) $data['clientid'] = $newuser[$c];
			elseif ( $c == 'status' ) $data[$c] = ( $newuser[$c] == 'Closed' ? 0 : 1 );
			else $data[$c] = $newuser[$c];
		}
			
		// If we are updating a contact, we must grab it from the password from the post array
		if ( $type == 'contact' && $input->getVar( 'password', false ) ) {
			$data['password'] = $input->getVar( 'password', null );
		}
		// Catch password updates for clients on the back end
		else if ( is_admin() ) {
			$newpass	= ( isset( $newuser['password'] ) ? $newuser['password'] : $input->getVar( 'password', null ) );
	
			if ( ( $newpass != 'Enter to Change' ) && (! empty( $newpass ) ) ) {
				$data['password']	=	$newpass;
				$data['password2']	=	$newpass;
			}
		}
		// Password updates for front end are handled separately
		$data['name']	= $data['firstname'] . ' ' . $data['lastname'];
		$data['email']	= $newuser['email'];
		
		if (! $data['firstname'] && ! $data['lastname'] && $newuser['companyname'] ) {
			$data['name']	=	$newuser['companyname'];
		}
		
		$config	=	dunloader( 'config', 'integrator' );
		
		if ( $config->get( 'userstyle', '1' ) == '2' ) {
			
			$fieldid		=	get_custom_field_id( $config->get( 'usernamefield' ), 'client' );
			$customfields	=	$input->getVar( 'customfield', array(), 'request', 'array' );
			
			if ( isset( $customfields[$fieldid] ) ) {
				$data['username']	=	$customfields[$fieldid];
			}
		}
	}
	
	// We must convert the data from the native characterset to utf-8 so Integrator can handle it.
	$wconfig	=	dunloader( 'config', true );
	if ( strtoupper( $wconfig->get( 'Charset' ) ) && function_exists( 'iconv' ) ) {
		foreach ( $data as $k => $v ) {
			$data[$k] = iconv( strtoupper( $wconfig->get( 'Charset' ) ), 'UTF-8', $v );
		}
	}
	
	return $data;
}
}


/**
 * Function for encoding the session variables for I3 to handle
 * @access		public
 * @version		3.1.06
 *
 * @return		string
 * @since		3.0.0
 */
if (! function_exists( 'encode_session' ) ) {
function encode_session( $name, $id )
	{
		// Initialize items
		$config			=	dunloader( 'config', 'integrator' );
		$salt			=   mt_rand();
		$secret			=   $config->get( 'apitoken' );
		$string			=   null;
		$data			=   null;
		$encode			=   null;

		// Create base array
		$serial	= serialize( array( 'id' => $id, 'name' => $name ) );
		$key	= md5( $secret . $salt );

		for ( $i = 0; $i < strlen( $serial ); $i++ ) {
			$string .= substr( $key, ( $i % strlen( $key ) ), 1 ) . ( substr( $key, ( $i % strlen( $key ) ), 1 ) ^ substr( $serial, $i, 1 ) );
		}

		for ( $i = 0; $i < strlen( $string ); $i++ ) {
			$data .= substr( $string, $i, 1 ) ^ substr( $key, ( $i % strlen( $key ) ), 1 );
		}

		// Create array and encode
		$encode	= array( 'data' => base64_encode( $data ), 'salt' => $salt );
		$encode = serialize( $encode );
		$encode = base64_encode( $encode );
		$encode = md5( $salt . $secret ) . $encode;
		$encode = strrev( $encode );

		return $encode;
	}
}


/**
 * Common method for determining if we should perform a given task
 * @version		3.1.06 ( $id$ )
 * @param		string		- $type: [user|visual]
 *
 * @return		boolean
 * @since		3.1.00
 */
if (! function_exists( 'ensure_active' ) ) {
function ensure_active( $type = 'user' )
{
	$config		=	dunloader( 'config', 'integrator' );
	
	if ( $type == 'user' ) {
		// If we are disabled don't run ;-)
		if (! $config->get( 'enable', false ) || ! $config->get( 'userenable', false ) ) {
			return false;
		}
		return true;
	}
	else if ( $type == 'visual' ) {
		// If we are disabled don't run ;-)
		if (! $config->get( 'enable', false ) || ! $config->get( 'visualenable', false ) ) {
			return false;
		}
		return true;
	}
	else if ( $type == 'login' ) {
		// If we are disabled don't run ;-)
		if (! $config->get( 'enable', false ) || ! $config->get( 'loginenable', false ) ) {
			return false;
		}
		return true;
	}
	else if ( $type == 'license' ) {
		// If we passed our valid test earlier, we must be true
		return true;
	}
	
	return false;
}
}


/**
 * Function to extract the client data from parameters
 * @version		3.1.06 ( $Id$ )
 * @param		array		- $params passed to us
 * 
 * @return		object | false
 * @since		3.1.00
 */
if (! function_exists( 'extract_clientdata' ) ) {
function extract_clientdata( $params = array() )
{
	$client	=	(object) ( isset( $params['clientsdetails'] ) ? $params['clientsdetails'] : $params );
	
	if (! isset( $client->email ) ) return false;
	else return $client;
}
}


/**
 * Function to find a username from the database
 * @version		3.1.06 ( $Id$ )
 * @param		integer		- $id: the client id
 * 
 * @return		string
 * @since		3.1.00
 */
if (! function_exists( 'find_username' ) ) {
function find_username( $id )
{
	$config		=	dunloader( 'config', 'integrator' );
	$db			=	dunloader( 'database', true );
	
	if (! ( $fieldid = get_custom_field_id( $config->get( 'usernamefield' ) ) ) ) {
		return false;
	}
	
	$query	=	"SELECT `value` FROM `tblcustomfieldsvalues` WHERE `fieldid` = " . $db->Quote( $fieldid ) . " AND `relid` = " . $db->Quote( $id );
	$db->setQuery( $query );
	
	return $db->loadResult();
}
}


/**
 * Function to redirect using a hidden form
 * @access		public
 * @version		3.1.06 ( $Id$ )
 * 
 * @since		3.1.00
 */
if (! function_exists( 'form_redirect' ) ) {
function form_redirect( $url, $fields = array() )
{
	$fields = (array) $fields;
	$input	= null;
	
	foreach ( $fields as $name => $field ) {
		$input .= '<input type="hidden" name="' . $name . '" value="' . $field . '" />';
	}
	
	$output = <<< OUTPUT
<form action="{$url}" method="post" name="frmlogin" id="frmlogin">
		{$input}
</form>
<script language="javascript"><!--
setTimeout ( "autoForward()", 0 );
function autoForward() {
	document.forms['frmlogin'].submit()
}
//--></script>
OUTPUT;
			exit ( $output );
}
}


/**
 * Function to test to see if we are coming from the admin area
 * @version		3.1.06 ($Id$)
 * 
 * @return		boolean
 * @since		2.5.5
 */
if (! function_exists( 'from_adminarea' ) ) {
function from_adminarea()
{
	global $customadminpath;

	if (! $customadminpath ) {
		$customadminpath = 'admin';
	}
	
	$customadminpath	=	'/' . $customadminpath;
	
	if (! isset( $_SERVER['HTTP_REFERER'] ) || empty( $_SERVER['HTTP_REFERER'] ) ) {
		return false;
	}
	
	$uri		=	DunUri :: getInstance( $_SERVER['HTTP_REFERER'], true );
	
	if ( strpos( $uri->toString(), $customadminpath ) !== false ) {
		return true;
	}

	return false;
}
}


/**
 * Function to get the custom field id for a given field from the database
 * @version		3.1.06 ( $id$ )
 * @param		string		- $field: the field we want
 * @param		string		- $type: what type of custom field we are after [CLIENT]
 *
 * @return		string
 * @since		3.1.00
 */
if (! function_exists( 'get_custom_field_id' ) ) {
function get_custom_field_id( $field = null, $type = 'client' )
{
	$db	=	dunloader( 'database', true );
	
	switch ( $type ) {
		case 'client' :
			$db->setQuery( "SELECT `id` FROM `tblcustomfields` cf WHERE cf.type= 'client' AND cf.fieldname = " . $db->Quote( $field ) );
			break;
	}
	
	$result	=	$db->loadResult();
	return $result;
}
}


/**
 * Function to get the system URL to use based on ssl and setting existance
 * @version		3.1.06
 * 
 * @return		string
 * @since		3.1.00
 */
if (! function_exists( 'get_systemurl' ) ) {
function get_systemurl()
{
	$config	=	dunloader( 'config', true );
	
	if ( is_ssl() && $config->get( 'SystemSSLURL' ) ) {
		return $config->get( 'SystemSSLURL' );
	}
	
	return $config->get( 'SystemURL' );
}
}


/**
 * Function to get a variable from our template handler (smarty)
 * @version		3.1.06
 * 
 * @return		mixed
 * @since		3.1.04
 */
if (! function_exists( 'get_template_var' ) ) {
function get_template_var( $name, $default = false )
{
	global $smarty;
	
	// See if smarty is an object
	if (! is_object( $smarty ) || ! is_a( $smarty, 'Smarty' ) ) {
		$tpl_vars	=	array();
	}
	else {
			
		if ( version_compare( DUN_ENV_VERSION, '6.0.0', 'ge' ) ) {
			$tpl_vars	=	$smarty->get_template_vars();
		}
		else {
			$tpl_vars	=	$smarty->_tpl_vars;
		}
			
	}
	
	return ( isset( $tpl_vars[$name] ) ? $tpl_vars[$name] : $default );
}
}


/**
 * Function to get the short version number
 * @version		3.1.06
 * 
 * @return		string
 * @since		3.1.00
 */
if (! function_exists( 'get_version' ) ) {
function get_version()
{
	static $version = null;
	
	if ( $version == null ) {
		$curversion	=	substr( DUN_ENV_VERSION, 0, 3 );
		
		$path	=	dirname( dirname( __FILE__ ) ) . DIRECTORY_SEPARATOR
				.	'templates' . DIRECTORY_SEPARATOR;
		
		if ( is_dir( $path . $curversion ) ) {
			$version	=	$curversion;
		}
		else {
			$dh		=	opendir( $path );
			$dirs	=	array();
			while ( false !== ( $file = readdir( $dh ) ) ) {
				if ( in_array( $file, array( '.', '..' ) ) ) continue;
				if (! is_dir( $path . DIRECTORY_SEPARATOR . $file ) ) continue;
				$dirs[]	=	$file;
			}
			rsort( $dirs );
			$version	=	array_shift( $dirs );
		}
	}
	
	return $version;
}
}


/**
 * Function to get a user from the database
 * @version		3.1.06
 * @param		integer		- $userid: contains the id of the user to get
 * @param		string		- $type: indicates which type of user to get
 * @param		string		- $by: allows us to specify a field to get the user by
 * 
 * @return		array or false on unfound
 * @since		2.4.0
 */
if (! function_exists( 'get_user_from_db' ) ) {
function get_user_from_db( $userid, $type = 'client', $by = 'id' )
{
	$db		=	dunloader( 'database', true );
	$db->setQuery( "SELECT * FROM `tbl" . $type . "s` WHERE `" . $by . "` = " . $db->Quote( $userid ) );
	$user	=	$db->loadAssoc();
	return ( empty( $user ) ? false : $user );
}
}


/**
 * Function to get user information
 * @version		3.1.06
 * @param		string		- $request: indicates what action we are performing so we can find it correctly
 * @param		string		- $type: indicates we want a client or contact
 * 
 * @return		array or false on unfound
 * @since		2.4.0
 */
if (! function_exists( 'get_user_information' ) ) {
function get_user_information( $request, $type = null )
{
	switch ( $request ) :
	case 'fetch' :
	case 'passwordchange':
		$user = get_user_from_db( $type['userid'] );
		
	break;	// Passwordchange
	// ----------------------------------------------
	case 'validation':
		// Switch on contact / client
		switch ( $type ) :
		
		// Contacts dont run through validation
		case 'contact':
			
		break;
			
		// Client data validation
		case 'client':
		default:
			if ( is_admin() ) {
				// We must load the user info from the database
				global $userid;
				$user	= get_user_from_db( $userid );
			}
			else {
				
				$user	=	false;
				
				if ( version_compare( DUN_ENV_VERSION, '5.2', 'ge' ) ) {
					
					// New with WHMCS 5.2 - WHMCS_Client object permits accessing details of existing user prior to validation (on front end)
					global $client;
					if ( is_a( $client, 'WHMCS_Client' ) ) {
						$user	=	$client->getDetails();
					}
					
				}
				else {
					$user	= $GLOBALS['existingclientsdetails'];
				}
				
			}
			
		break;
		endswitch;	// Type
		
	break;		// Validation
	endswitch;	// Request

	return $user;
}
}


/**
 * Function to see if we are logged into WHMCS or not
 * @version		3.1.06
 * 
 * @return		boolean
 * @since		2.5.12
 */
if (! function_exists( 'is_loggedin' ) ) {
function is_loggedin()
{
	if ( isset( $_SESSION['uid'] ) ) {
		if ( $_SESSION['uid'] ) {
			return true;
		}
	}
	
	return false;
}	
}


/**
 * Function to test to see if a string is UTF8 or not
 * @version		3.1.06
 * @param		string		- $Str: The string we are testing
 *
 * @return		boolean
 * @since		2.5.4
 */
if (! function_exists( 'is_utf8' ) ) {
function is_utf8( $Str )
{
	for ($i=0; $i<strlen($Str); $i++) {
		if ( ord($Str[$i]) < 0x80 ) continue;			# 0bbbbbbb
		elseif ( (ord($Str[$i]) & 0xE0) == 0xC0 ) $n=1; # 110bbbbb
		elseif ( (ord($Str[$i]) & 0xF0) == 0xE0 ) $n=2; # 1110bbbb
		elseif ( (ord($Str[$i]) & 0xF8) == 0xF0 ) $n=3; # 11110bbb
		elseif ( (ord($Str[$i]) & 0xFC) == 0xF8 ) $n=4; # 111110bb
		elseif ( (ord($Str[$i]) & 0xFE) == 0xFC ) $n=5; # 1111110b
		else return false; # Does not match any model
		
		for ( $j=0; $j<$n; $j++ ) {
			# n bytes matching 10bbbbbb follow ?
			if ( (++$i == strlen($Str)) || ((ord($Str[$i]) & 0xC0) != 0x80) ) {
				return false;
			}
		}
	}
	return true;
}
}


/**
 * Simple function to determine if we are supporting the installed WHMCS version
 * @version		3.1.06
 * 
 * @return		boolean
 * @since		3.1.00
 */
if (! function_exists( 'is_supported' ) ) {
function is_supported()
{
	$curversion	=	substr( DUN_ENV_VERSION, 0, 3 );
	
	return $curversion == get_version();
}
}


/**
 * Function to convert XML to an array
 * @version		3.1.06
 * @param		SimpleXMLElement
 * 
 * @return		array
 * @since		3.1.00
 */
if (! function_exists( 'simpleXMLToArray' ) ) {
function simpleXMLToArray( SimpleXMLElement $xml, $attributesKey = null, $childrenKey = null, $valueKey = null )
{
	if ( $childrenKey && ! is_string( $childrenKey ) ) {
		$childrenKey = '@children';
	}
	
	if ( $attributesKey && ! is_string( $attributesKey ) ) {
		$attributesKey = '@attributes';
	}
	
	if ( $valueKey && ! is_string( $valueKey ) ) {
		$valueKey = '@values';
	}
	
	$return	= array();
	$name	= $xml->getName();
	$_value	= trim((string)$xml);
	
	if ( $_value == '>' ) $_value = ''; // CHANGE 3.0.1 (0.1)
	
	if (! strlen( $_value ) ) {
		$_value = null;
	}
	
	if ( $_value !== null ) {
		if ( $valueKey ) {
			$return[$valueKey] = $_value;
		}
		else {
			$return = $_value;
		}
	}
	
	$children	= array();
	$first		= true;
	
	foreach ( $xml->children() as $elementName => $child )
	{
		$value	= simpleXMLToArray( $child, $attributesKey, $childrenKey, $valueKey );
		
		if ( isset( $children[$elementName] ) ) {
			if ( is_array( $children[$elementName] ) ) {
				if ( $first ) {
					$temp	= $children[$elementName];
					unset( $children[$elementName] );
					$children[$elementName][]	= $temp;
					$first	= false;
				}
				$children[$elementName][]	= $value;
			}
			else {
				$children[$elementName]	= array( $children[$elementName], $value );
			}
		}
		else {
			$children[$elementName]	= $value;
		}
	}
	
	if ( $children ) {
		if ( $childrenKey ) {
			$return[$childrenKey] = $children;
		}
		else {
			if (! empty( $return ) )  // CHANGE 3.0.1 (0.1)
				$return	= @array_merge( (array) $return, $children );
			else
				$return	= $children;
		}
	}
	
	$attributes	= array();
	foreach ( $xml->attributes() as $name => $value )
	{
		$attributes[$name]	= trim($value);
	}
	
	if ( $attributes ) {
		if ( $attributesKey ) {
			$return[$attributesKey] = $attributes;
		}
		else {
			if (! is_array( $return ) ) $return = array( 'value' => $return ); // CHANGE 3.0.1 (0.1)
			$return	= @array_merge( $return, $attributes );
		}
	}
	
	return $return;
} 

}


/**
 * Function to store a username to the database
 * @version		3.1.06 ( $Id$ )
 * @param		integer		- $id: the client id
 *
 * @return		string
 * @since		3.1.00
 */
if (! function_exists( 'store_username' ) ) {
function store_username( $id, $username )
{
	$config		=	dunloader( 'config', 'integrator' );
	$db			=	dunloader( 'database', true );

	if (! ( $fieldid = get_custom_field_id( $config->get( 'usernamefield' ) ) ) ) {
		return false;
	}
	
	// Determine if we add or update
	if ( find_username( $id ) ) {
		$query	=	"UPDATE `tblcustomfieldsvalues` SET `value` = " . $db->Quote( $username ) . " WHERE `fieldid` = " . $db->Quote( $fieldid ) . " AND `relid` = " . $db->Quote( $id );
	}
	else {
		$query	=	"INSERT INTO `tblcustomfieldsvalues` ( `fieldid`, `relid`, `value` ) VALUES ( " . $db->Quote( $fieldid ) . ", " . $db->Quote( $id ) . ", " . $db->Quote( $username ) . " )";
	}
	
	$db->setQuery( $query );
	return $db->query();
}
}
?>