<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.06 ( $Id: routes.php 74 2012-10-01 15:55:25Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This is the primary configuration file for the Integrator
 *  
 */


/*-- Security Protocols --*/
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*-- Security Protocols --*/

$route['default_controller'] = "process";
$route['404_override'] = '';