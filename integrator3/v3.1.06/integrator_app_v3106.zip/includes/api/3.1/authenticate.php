<?php
/**
 * Integrator 3
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.06 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * API interface for application
 * @version		3.1.06
 *
 * @since		3.1.00
 * @author		Steven
*/
class AuthenticateApi extends BaseApi
{
	protected $_controller	=	'authenticate';
	
	function post()
	{
		// See if User Integration is Enabled
		if ( is_enabled( 'user' ) === false ) {
			return $this->error( lang( 'msg.error.userdisabled' ), 'USERDISABLED-AUTHAPI' );
		}
		
		$_c		= get_var( '_c', 'post' );
		$cnxn	= get_cnxn_library( $_c );
		$cnxn->cuser_place( get_instance()->input->post() );
		$cuser  = Cuser::getInstance();
		
		// Standardize the credentials
		$creds	= standardize_credentials( array( 'cnxnid' => $_c ) );
		
		// Figure out which type we have if nothing then invalid creds sent
		if ( ( $type = ( empty( $creds['username'] ) ? ( empty( $creds['email'] ) ? false : 'email' ) : 'username' ) ) === false ) {
			return $this->error( "msg.error.invalidcredentials", 'INVALIDCREDS-AUTHAPI' );
		}
		
		// Build the authentication stack
		$stack	= build_authentication_stack( array( 'excludes' => array( $_c ), 'type' => $type ) );
		$auth	= false;
		
		// Loop through stack
		foreach ( $stack as $s ) {
			$api		= get_api( $s->id );
				
			// Try to authenticate
			if ( $user = $api->authenticate( $creds ) ) {
				$auth	= $s->id;
				break;
			}
		}
		
		$data	=	array(
				'type'	=>	( $auth ? 'array' : 'binary' ),
				'data'	=>	( $auth ? ( isset( $user->user ) ? $user : true ) : false )
		);
		
		return $this->success( $data );
	}
}