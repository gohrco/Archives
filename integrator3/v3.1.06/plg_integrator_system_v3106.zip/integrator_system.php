<?php
/**
 * Integrator 3
 * System - Integrator Plugin
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.06 ( $Id: integrator_system.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This is the file executed by the System - Integrator plugin for handling system level calls including debug output and redirection
 * 
 */


/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
defined( 'INTEGRATORSYSM_FILEPATH' ) or define( 'INTEGRATORSYSM_FILEPATH', dirname( __FILE__) . DIRECTORY_SEPARATOR );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.application.component.helper' );

// Ensure Dunamis is loaded
jimport( 'dunamis.dunamis' );
/*-- File Inclusions --*/


/**
 * System - Integrator Plugin
 * @version		3.1.06
 * 
 * @since		3.0.0
 * @author		Steven
 */
class plgSystemIntegrator_system extends JPlugin
{
	/**
	 * Local enable
	 * @access		private
	 * @since		3.0.0
	 * @var			bool
	 */
	public $_enabled	= false;
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.1.06
	 * @param		object
	 * @param		array
	 *
	 * @since		1.5.0
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct( $subject, $config );
		
		$this->loadLanguage();
		
		$app		=	JFactory :: getApplication();
		$user		=	JFactory :: getUser();
		
		// Run through tests
		// -----------------
		// Ensure we have Dunamis installed
		if (! function_exists( 'get_dunamis' ) ) {
			// Not admin don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
			
			// Show error message
			$this->_displayError( 'INTEGRATOR_SYSM_CONFIG_NODUNAMIS', 'library' );
			return;
		}
		
		get_dunamis( 'com_integrator' );
		$config	=	dunloader( 'config', 'com_integrator' );
		
		if (! is_a( $config, 'Com_integratorDunConfig' ) ) {
			// Not admin or not logged in don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
				
			// Show error message
			$this->_displayError( 'INTEGRATOR_SYSM_CONFIG_NOJWHMCSCONFIG', 'integratorconfig' );
			return;
		}
		
		// Ensure we are active...
		if (! $config->get( 'Enabled' ) ) {
			// Not admin or not logged in don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
			
			// Show error message
			$this->_displayError( 'INTEGRATOR_SYSM_CONFIG_NOTENABLED', 'enable' );
			return;
		}
		
		// Ensure we have a token set
		if (! $config->get( 'IntegratorSecret' ) ) {
			// Not admin or not logged in don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
				
			// Show error message
			$this->_displayError( 'INTEGRATOR_SYSM_CONFIG_NOTOKEN', 'token' );
			return;
		}
		
		// All good, lets go
		$this->_enabled	=	true;
		
		// But before we go...
		if ( $config->get( 'IntegratorDebug' ) != 'No' ) {
			// Visitors shouldn't be bothered
			if ( $user->guest ) return;
			
			// WARN EVERYONE ELSE THO
			$this->_displayError( 'INTEGRATOR_SYSM_CONFIG_DEBUGON', 'debug', false );
		}
		
		return;
	}
	
	
	/**
	 * Joomla onAfterInitialise system level event
	 * @access		public
	 * @version		3.1.06
	 * @version		3.0.8		- Jan 2013: Changes to the email address are reverted due to session - added session updating
	 * 
	 * @since		3.0.2
	 */
	public function onAfterInitialise()
	{
		$app = JFactory::getApplication();
		
		// Handle the API requests (true indicates we handled an API call so we shouldn't do anything else - if we are even still here)
		if ( $this->_handleApi() ) {
			return;
		}
		
		
		return;
		// Initialize variables
		$app		=	JFactory::getApplication();
		$vars		=   array(	'option'	=> IntegratorHelper :: get ( 'option', null, 'cmd' ),
								'view'		=> IntegratorHelper :: get ( 'view', null, 'cmd' )
		);
		$newlink	=   null;
		
		// Test for password reset
		if ( $vars['option'] == 'com_integrator' && $vars['view'] == 'pwreset' )							// I3 Password Reset Link
		{
			if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
				$newlink = JRoute :: _( 'index.php?option=com_users&view=reset' );
			}
			else {
				$newlink = JRoute :: _( 'index.php?option=com_user&view=reset' );
			}
		} // End test for password reset
		
		if ( $newlink != null ) {
			$app->redirect( $newlink );
		}
		
		if ( defined( 'INTEGRATOR_API' ) ) return;
		
		$session	=	JFactory::getSession();
		$instance	=	$session->get('user');
		
		if ( is_a( $instance, 'JUser' ) && ! $instance->guest ) {
			$dbuser		= new Juser( $instance->get( 'id' ) );
			$changes	= false;
			
			foreach( array( 'email', 'username', 'name' ) as $item ) {
				if ( $dbuser->get( $item ) == $instance->get( $item ) ) continue;
				$instance->set( $item, $dbuser->get( $item ) );
				$changes	= true;
			}
			
			if ( $changes ) {
				$instance->set( 'email', $dbuser->get( 'email' ) );
				$session->set( 'user', $instance );
			}
		}
		
		
		
	}
	
	
	/**
	 * Joomla onAfterRender system level event
	 * @access		public
	 * @version		3.1.06
	 * 
	 * @since		3.0.0
	 */
	public function onAfterRender()
	{
		return;
		// Ensure we don't throw errors if Integrator missing
		if (! $this->_enabled ) return;
		
		// Process redirects first
		$this->redirectRequests();
		
		// Render the debug output if called for
		$this->debugOutput();
		
		return;
	}
	
	
	/**
	 * Method to grab the debug output and append it to the body
	 * @access		private
	 * @version		3.1.06
	 * 
	 * @since		3.0.0
	 */
	private function debugOutput()
	{
		// Grab local copy
		$params	= $this->params;
		
		// Grab the debug data (clearing it if no debug active)
		$debug	=	IntDebug :: getInstance();
		$data	=   $debug->get_output();
		
		// Bail if no debugging is on
		if ( $params->get( 'IntegratorDebug' ) != 'Yes' && ! JDEBUG ) return;
		
		// Bail if we are in the API!
		if ( defined( 'INTEGRATOR_API' ) ) return;
		
		// Bail if nothing to do
		if ( empty( $data ) ) return;
		
		$response	= '<div style="width: 100%; clear: both; position: relative; color: #000; ">'
					. '<fieldset style="padding: 5px 17px 17px; background-color: #fff; border: 1px solid #CCCCCC; ">'
					. '<legend style="color: #146295; font-size: 1.15em; font-weight: bold; margin: 0; padding: 0; ">'
					. 'Integrator Debug Information'
					. '</legend>'
					. '<ul class="list-style: none outside none; margin: 0; padding: 0; ">';
		$closing	= '</ul></fieldset></div>';
		
		foreach ( $data as $line ) {
			$response  .= '<li style="list-style: none outside none; border-bottom: 1px solid #666666; padding: 5px; ">'
						. '<div style="float: left; font-weight: bold; ' . ( $line['type'] == 'error' ? 'color: DarkRed; ' : '' ) . '">[' . $line['type'] . '] ' . $line['message'] . '</div>'
						. '<div style="float: right; font-size: smaller; ' . ( $line['type'] == 'error' ? 'color: DarkRed; ' : '' ) . '">' . $line['filename'] . '  @ line ' . $line['line'] . '</div>'
						. '<div style="clear: both; line-height: 1px; ">&nbsp;</div>'
						. '</li>';
		}
		
		JResponse :: appendBody( $response .= $closing );
	}
	
	
	/**
	 * Method to generate a signature for validation
	 * @static
	 * @access		public
	 * @version		3.1.06
	 *
	 * @return		string
	 * @since		3.1.00
	 */
	public static function generateSignature()
	{
		get_dunamis( 'integrator_system' );
		$config	=	dunloader( 'config', 'com_integrator' );
		$method	=	self :: getMethod();
		$token	=	$config->get( 'IntegratorSecret' );
		$uri	=	clone DunUri :: getInstance( 'SERVER', true );
		$append	=	null;
		
		// Cleanup language uri redirections :(
		if ( ( $l = $uri->getVar( 'lang', false ) ) ) {
			$path	=	$uri->getPath();
			$path	=	str_replace( '/' . $l . '/', '', $path );
			$uri->setPath( $path );
		}
	
		$isSef		=	self :: _usingSefrewrite();
		
		if ( $isSef && strpos( $uri->getPath(), 'index.php' ) === false ) {
			$path	=	rtrim( $uri->getPath(), '/' ) . '/index.php';
			$uri->setPath( $path );
		}
		
		if ( $method == 'get' ) {
			$uri->delVar( 'apisignature' );
			$uri->delVar( '_c' );
		}
		else {
			$post	=	$_POST;
			ksort( $post );
			$usepost	=	array();
			
			foreach ( $post as $k => $v ) {
				if (! in_array( $k, array( 'apisignature', '_c' ) ) ) {
					$usepost[$k] = $v;
				}
			}
			
			\Tracy\Debugger :: barDump( $usepost, 'Posted Variables Received' );
			
			$append .= self :: generateString( $usepost );
			
		}
	
		return base64_encode( hash_hmac( 'sha256', rawurldecode( $uri->toString() ) . $append, $token, true ) );
	}
	
	
	/**
	 * Method to generate string
	 * @access		public
	 * @static
	 * @version		3.1.06
	 * @param		array
	 * @param		array
	 *
	 * @return		string
	 * @since		3.1.00
	 */
	public static function generateString( $data = array(), $subarray = null )
	{
		$input	=	dunloader( 'input', true );
		$string	=	null;
		
		foreach ( $data as $k => $v ) {
			if ( is_array( $v ) ) {
				$subdata	=	( $subarray ? $subarray[$k] : $input->getVar( $k, null, 'array', 'post' ) );
				$string		.=	self :: generateString( $v, $subdata );
			}
			else {
				if ( $subarray ) {
					$myv	=	isset( $subarray[$k] ) ? $subarray[$k] : null;
				}
				else {
					$myv	=	$input->getVar( $k, null, 'string', 'post' );
				}
				
				$string	.=	$k . $myv;
			}
		}
		return $string;
	}
	
	
	/**
	 * Method to determine which method we are using to access the API
	 * @static
	 * @access		public
	 * @version		3.1.06
	 *
	 * @return		string
	 * @since		2.5.0
	 */
	public static function getMethod()
	{
		if ( version_compare( JVERSION, '1.7.0', 'ge' ) ) {
			$app	= & JFactory :: getApplication();
			return strtolower( $app->input->getMethod() );
		}
		else {
			return strtolower( JRequest :: getMethod() );
		}
	}
	
	
	/**
	 * Method to redirect requests
	 * @access		private
	 * @version		3.1.06
	 * 
	 * @since		3.0.0
	 */
	private function redirectRequests()
	{
		return;
		$app	=	JFactory::getApplication();
		$user 	=	JFactory::getUser();
		$api 	=	IntApi::getInstance();
		$params	=   $this->params;
		
		// Don't redirect any admin requests
		if ( $app->isAdmin() ) return;
		
		// Don't run if product or user integration disabled
		if ( $params->get( 'UserEnabled' ) != 'Yes' || $params->get( 'Enabled' ) != 'Yes' ) return;
		
		// Initialize variables
		$vars		=   array(	'option'	=> IntegratorHelper :: get ( 'option', null, 'cmd' ),
								'view'		=> IntegratorHelper :: get ( 'view', null, 'cmd' ),
								'task'		=> IntegratorHelper :: get ( 'task', null, 'cmd' ),
								'layout'	=> IntegratorHelper :: get ( 'layout', null, 'cmd' )
						);
		$newlink	=   null;
		
		// Test for registration page
		if ( ( $vars['option'] == 'com_users' && $vars['view'] == 'registration' )	// Joomla 1.6+
		  || ( $vars['option'] == 'com_users' && $vars['task'] == 'registration' )	//   - also J1.6+
		  || ( $vars['option'] == 'com_user' && $vars['task'] == 'register' ) 		// Joomla 1.5
		  || ( $vars['option'] == 'com_user' && $vars['view'] == 'register' ) )		//   - also Joomla 1.5
		{
			
			// Be sure we are a guest
			if ( $user->get( 'guest' ) )
			{
				// Integrated Page
				if ( $params->get( 'register_override' ) == '1' ) {
					$a		= $params->get( 'register_cnxn_id', false );
					$page	= $params->get( 'register_page', false );
					
					// In case we haven't selected an a or page
					if ( $a !== false && $page !== false ) {
						$newlink = $api->get_route( array( 'cnxn_id' => $a, 'page' => $page ) );
					}
					
				}
				// Custom URL
				else if ( $params->get( 'register_override' ) == '2' ) {
					$newlink = $params->get( 'register_customurl' );
				}
			} // End test for guest
		} // End test for registration page
		
		// Test for editing a profile
		if ( ( $vars['option'] == 'com_users' && $vars['view'] == 'profile' && $vars['layout'] == 'edit' )		// Joomla 1.6+
		  || ( $vars['option'] == 'com_user' && $vars['view'] == 'user' && $vars['layout'] == 'edit' ) )		// Joomla 1.5
		{
			if (! $user->get('guest') ):
				if ( ( $params->get( 'RegMethod' ) == 1 ) || ( $params->get( 'RegMethod' ) == 3 ) ) {
					$uri = new JURI( $params->get( 'ApiUrl' ) );
					$uri->setPath( $uri->getPath() . '/clientarea.php' );
					$uri->setVar( 'action', 'details' );
					$newlink = $uri->toString();
				}
			endif;
			
		} // End test for editing a profile
		
		// Test for password reset
		if ( ( $vars['option'] == 'com_integrator' && $vars['view'] == 'pwreset' )							// I3 Password Reset Link
		  || ( $vars['option'] == 'com_users' && $vars['view'] == 'reset' && $vars['layout'] == 'edit' )	// Joomla 1.6+
		  || ( $vars['option'] == 'com_user' && $vars['view'] == 'reset' ) )								// Joomla 1.5
		{
			// load J!WHMCS Edit page
			if ( $user->get('guest') ):
				if ( ( ( $params->get( 'RegMethod' )== 1 ) && ( $params->get( 'PwresetRedirect' ) != 1 ) ) || ( $params->get( 'PwresetRedirect' ) == 2 ) ) {
					$uri = new JURI( $params->get( 'ApiUrl' ) );
					$uri->setPath( $uri->getPath() . '/pwreset.php' );
					$newlink = $uri->toString();
				}
				elseif ( ( $params->get( 'PwresetRedirect' ) == 1 ) && ( $params->get( 'PwresetMenu' ) ) && ( $params->get( 'PwresetMenu' ) != $Itemid ) ) {
					$newlink = JRoute::_( "index.php?Itemid={$params->get( 'PwresetMenu' )}", false );
					$mainframe->redirect( $newlink );
				}
			endif;
		} // End test for password reset
		
		// Test for username request
		if ( ( $vars['option'] == 'com_users' && $vars['view'] == 'remind' && $vars['layout'] == 'edit' )	// Joomla 1.6+
		  || ( $vars['option'] == 'com_user' && $vars['view'] == 'remind' ) ) 								// Joomla 1.5
		{
			
			
			
		} // End test for username request
		
		if ( $newlink != null ) {
			$app->redirect( $newlink );
		}
	}
	
	
	/**
	 * Method to compare signatures
	 * @desc		Used to prevent timing attacks
	 * @access		private
	 * @version		3.1.06
	 * @param		string		- $a: signature 1
	 * @param		string		- $b: signature 2
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	private function _compareSignatures( $a, $b )
	{
		$diff = strlen($a) ^ strlen($b);
	
		for ( $i = 0; $i < strlen($a) && $i < strlen($b); $i++ ) {
			$diff |= ord( $a[$i] ) ^ ord( $b[$i] );
		}
	
		return $diff === 0;
	}
	
	
	/**
	 * Common method for displaying an error message
	 * @access		private
	 * @version		3.1.06
	 * @param		string		- $msg: the message to display
	 *
	 * @since		3.1.00
	 */
	private function _displayError( $msg = null, $task = 'token', $usesess = true )
	{
		// Translate string first
		$msg		=	JText :: _( $msg );
		$session	=	JFactory :: getSession();
	
		$hasrun		=	$session->get( 'integrator_system.' . $task, false );
	
		if ( $hasrun && $usesess ) {
			return;
		}
		elseif ( $usesess ) {
			$session->set( 'integrator_system.' . $task, true );
		}
	
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JFactory::getApplication()->enqueueMessage( "{$msg}" );
		}
		else {
			JError::raiseNotice( 100, "{$msg}" );
		}
	}
	
	
	/**
	 * Method for calling up a failed response
	 * @access		private
	 * @version		3.1.06
	 * @param		mixed		- $message: the message to fail on
	 *
	 * @since		3.1.00
	 */
	private function _fail( $message )
	{
		$data	=	array(
			'result'	=>	'error',
			'error'		=>	$message,
			'debug'		=>	dunloader( 'debug', true )->renderforApi()
		);
		$string	= json_encode( $data );
		exit( $string );
	}
	
	
	/**
	 * Method for determining the requested API version
	 * @access		private
	 * @version		3.1.06
	 * @param		md5 string		- $sent: we should be sent an md5 hashed string of the intended version
	 *
	 * @return		string containing found matching hashed version or 2.0 as the default
	 * @since		3.1.00
	 */
	private function _findApiversion( $sent = null )
	{
		$apipath	=	INTEGRATORSYSM_FILEPATH . 'api' . DIRECTORY_SEPARATOR;
	
		$dh		= opendir( $apipath );
		$data	=	array();
		while( ( $filename = readdir( $dh ) ) !== false ) {
			if ( in_array( $filename, array( '.', '..', 'index.html' ) ) ) continue;
			$data[md5( $filename )]	= $filename;
		}
	
		if ( isset( $data[$sent] ) ) return $data[$sent];
		else return '3.1';
	}
	
	
	/**
	 * Handles the calls for the API interface
	 * @access		public
	 * @version		3.1.06
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	private function _handleApi()
	{
		// Ensure we can run this
		if (! $this->_enabled ) return false;
	
		/* Yeay Dunamis! */
		get_dunamis();
	
		// Initialize some fun Dunamis things
		$input	=	dunloader( 'input', true );
		$config	=	dunloader( 'config', 'com_integrator' );
		
		// Grab the method first
		$method	=	$input->getMethod();
		
		// See if we should do anything
		if (! ( $integrator =	$input->getVar( 'integrator', false, $method ) ) ) {
			// If we aren't getting the integrator variable than we should assume this is a normal request
			// and send the user on their way
			return false;
		}
		
		// We use this variable to indicate we are coming from I3 also.. :-(
		if ( $integrator == '1' || $integrator == 'true' ) {
			return false;
		}
		
		// ==============================================================
		//	We have an Integrator 3 request so lets test the signature
		// ==============================================================
	
		// See if we have matching signatures
		$postsig	=	(string) rawurldecode( $input->getVar( 'apisignature', false, 'STRING', $method ) );
		$headsig	=	(string) rawurldecode( $input->getVar( 'HTTP_INTEGRATORREQUESTSIGNATURE', false, 'STRING', 'server' ) );
		
		// WARNING - BE SURE DEBUG IS DISABLED IN PRODUCTION!
		if ( $config->get( 'debug', false ) ) {
			$headsig = $postsig;
		}
		
		if ( $this->_compareSignatures( $postsig, $headsig ) !== true ) {
			$this->_fail( JText :: _( 'INTEGRATOR_SYSM_API_BADSIGNATURE' ) );
		}
		
		// Test the signature - randomize head / post sig use
		$_received_signature	=	(string) ( rand( 0, 1 ) == '1' ? $headsig : $postsig );
		$_generatedsignature	=	(string) plgSystemIntegrator_system :: generateSignature();
		
		// Bail if the signatures dont match
		if ( $this->_compareSignatures( $_received_signature, $_generatedsignature ) !== true ) {
			$this->_fail( JText :: _( 'INTEGRATOR_SYSM_API_BADSIGNATURE' ) );
		}
		
		// Test the timestamp to ensure recent request
		$gmt		=	new DateTime( null, new DateTimeZone('GMT') );
		$current	=	$gmt->format("U");
		$timestamp	=	$input->getVar( 'apitimestamp', 0, $method );
		$timediff	=	( $config->get( 'debug' ) ? 300 : 45 );
		
		// Test the timestamp
		if ( ( $current - $timestamp ) > $timediff ) {
			// The request is older than 2 minutes... something isn't right
			$this->_fail( JText :: _( 'INTEGRATOR_SYSM_API_OLDREQUEST' ) );
		}
	
	
		// ================================================================
		//	Lets find the base for the API
		// ================================================================
	
		// Take the J!WHMCS Request to get the base loaded
		$parts		=	explode( "/", trim( $integrator, '/' ) );
		$apiversion	=	array_shift( $parts );
		$apirequest	=	array_shift( $parts );
	
		// Find the api path
		$apipath	=	INTEGRATORSYSM_FILEPATH . 'api' . DIRECTORY_SEPARATOR;
	
		// Permit possibilities of versioned API
		$apiversion	=	$this->_findApiversion( $apiversion );
		$apipath	.=	$apiversion . DIRECTORY_SEPARATOR;
		
		// Be sure we dont fail ugly - we must have the base
		if (! file_exists(  $apipath . 'base.php' ) ) {
			// If for some reason we don't have the base file for the API for Belong there may
			// have been a problem during installation.
			$this->_fail( sprintf( JText :: _( 'INTEGRATOR_SYSM_API_BASE_NOPATH' ), $apipath . 'base.php' ) );
		}
	
		// Load the base api file
		@require_once( $apipath . 'base.php' );
	
		$classname	= 'IntegratorAPI';
		
		// Be sure we dont fail ugly - we must have the base
		if (! class_exists( $classname ) ) {
			// If for some reason we don't have the base class but was able to find the file something
			// is fishy so bail
			$this->_fail( sprintf( JText :: _( 'INTEGRATOR_SYSM_API_BASE_NOCLASS' ), $classname ) );
		}
	
	
	
		// =============================================================
		//	Now lets find the actual request
		// =============================================================
	
		// API classname
		$apiclassname	= ucfirst( $apirequest ) . $classname;
		
		// Find the api filename
		// @TODO:  Check for safe mode as file exists may fail otherwise
		if ( file_exists( $apipath . strtolower( $apirequest ) . '.php' ) ) {
			@require_once( $apipath . strtolower( $apirequest ) . '.php' );
		}
	
		// Be sure we dont fail ugly
		if (! class_exists( $apiclassname ) ) {
			$this->_fail( sprintf( 'API Method `%s` is unknown.', $apirequest ) );
		}
	
		// Prevent recursion
		define( 'INTEGRATORAPI', true );
	
		// Initialize the class and execute
		$api	=	new $apiclassname();
		$result	=	$api->execute();
	
		return $result;
	}
	
	
	/**
	 * Method to determine if we are using sef rewrite anywhere
	 * @static
	 * @access		public
	 * @version		3.1.06
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	private static function _usingSefrewrite()
	{
		$jconfig	=	dunloader( 'config', true );
	
		// Lets test for Joomla core sef first
		if ( $jconfig->get( 'sef_rewrite' ) ) {
			return true;
		}
	
		// Now lets see if sh404sef is installed and set with sef
		$paths	=	array(
				rtrim( JPATH_ADMINISTRATOR, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_sh404sef',
				rtrim( JPATH_SITE, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_sh404sef',
		);
	
		$found = false;
		foreach ( $paths as $path ) {
			if ( is_dir( $path ) ) {
				$found = true;
				break;
			}
		}
	
		if (! $found ) return false;
	
		$sh404	=	JComponentHelper :: getComponent( 'com_sh404sef', true );
	
		if ( $sh404->enabled ) {
				
			$comp = JComponentHelper :: getComponent( 'com_sh404sef' );
				
			if ( is_object( $comp ) ) {
				if ( JComponentHelper :: getComponent( 'com_sh404sef' )->params->get( 'shRewriteMode' ) == '0' ) {
					return true;
				}
				else {
					return false;
				}
			}
				
			// Old school sh404sef
			$files	=	array( 'sh404seffactory.php', 'shSEFConfig.class.php', 'classes' . DIRECTORY_SEPARATOR . 'config.php' );
			$path	=	JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_sh404sef' . DIRECTORY_SEPARATOR;
				
			foreach ( $files as $file ) {
				if ( file_exists( $path . $file ) ) {
					include_once $path . $file;
				}
			}
				
			if ( class_exists( 'Sh404sefFactory' ) ) {
				$shconf	=	Sh404sefFactory :: getConfig();
	
				if ( $shconf->shRewriteMode == '0' ) {
					return true;
				}
			}
		}
	
		return false;
	}
}