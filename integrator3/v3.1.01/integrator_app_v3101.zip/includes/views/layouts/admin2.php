<!DOCTYPE HTML>
<html lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		
		<!-- Always force latest IE rendering engine & Chrome Frame -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		
		<title><?php echo $template['title']; ?></title>
		
		<base href="<?php echo base_url(); ?>" />
		
		<?php //echo $template['metadata']; ?>
		<?php echo $header_includes; ?>
		
		<!-- Mobile Viewport Fix -->
<!-- 		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"> -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
		
		<script type="text/javascript">
			var ajaxurl		= '<?php echo base_url( 'index.php/ajax' ); ?>';
		</script>
		
	</head>
<body>

<div style="height: 100px; display: block;" class="hidden-phone"></div>

<div class="container">
	
	<div class="row">
		
		<div class="span7 offset3">
			
			<?php if (! empty( $error ) ) : ?>
				<div class="row-fluid">
					<div class="alert alert-error">
						<h4 class="alert-heading"><?php echo lang( 'error.heading' ); ?></h4>
						<ul><?php echo $error; ?></ul>
					</div>
				</div>
			<?php endif; ?>
			
			<?php if (! empty( $success ) ) : ?>
				<div class="row-fluid">
					<div class="alert alert-success">
						<h4 class="alert-heading"><?php echo lang( 'success.heading' ); ?></h4>
						<ul><?php echo $success; ?></ul>
					</div>
				</div>
			<?php endif; ?>
			
				<div class="row-fluid">
					
					<div class="span12">
						
						<div class="well-white" id="header">
							<div id="logo" style="display: block; ">Integrator <small>v</small>3.0</div>
						</div>
						
						<?php echo $template['partials']['body']; ?>
						
					</div>
					
				</div>
		
		</div>
		
		<div class="span2 visible-desktop">&nbsp;</div>
		
	</div>
</div>

<?php echo $template['partials']['modals']; ?>

<?php echo $footer_javascript; ?>

<?php echo $template['partials']['debug']; ?>

</body>
</html>