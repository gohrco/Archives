<?php
/**
 * Integrator 3
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.00 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * API interface for application
 * @version		3.1.00
 *
 * @since		3.1.00
 * @author		Steven
*/
class RouteApi extends BaseApi
{
	protected $_controller	=	'route';
	
	function get()
	{
		$cnxn_id	=	get_var( 'cnxn_id' );
		$cnxn_lib	=	get_cnxn_library( $cnxn_id );
		
		$response	=	array(
				'type'		=>	'string',
				'data'		=>	null,
		);
		
		$debug		=	array( 'cnxn_id' => $cnxn_id, 'cnxn_lib' => ( $cnxn_lib === false ? false : get_class( $cnxn_lib ) ) );
		
		// Catch misconfigurations (they happen)
		if ( $cnxn_lib === false ) {
			return $this->error( lang( 'msg.error.getroute.cnxnlib' ), 'CNXN01|' . $cnxn_id, $debug );
		}
		
		// Grab the route
		$route				=	$cnxn_lib->get_route();
		$response['data']	=	$route;
		
		logAPIResponse( get_var( '_c' ), '0', 'get_route', array( 'page' => get_var( 'page' ), 'cnxn_id' => get_var( 'cnxn_id' ) ), null, $route );
		
		$this->success( $response, $debug );
	}
}