<?php
/**
 * Integrator 3
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.01 ( $Id: cnxnlist.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 *
 * @desc       This file is the connection list type of input field for Integrator 3
 *
 */

defined('JPATH_BASE') or die;

jimport('joomla.html.html');
jimport('joomla.form.formfield');
jimport('joomla.form.helper');

// Ensure Dunamis is loaded
jimport( 'dunamis.dunamis' );

// -------------------------------------------------------
// Ensure we have Dunamis and it's loaded
if (! function_exists( 'get_dunamis' ) ) {
	$path	= dirname( dirname( dirname(__FILE__) ) ) . DIRECTORY_SEPARATOR . 'libraries' . DIRECTORY_SEPARATOR . 'dunamis' . DIRECTORY_SEPARATOR . 'dunamis.php';
	if ( file_exists( $path ) ) require_once( $path );
}

if (! function_exists( 'get_dunamis' ) ) {
	// EPIC FAILURE HERE
	return;
}

get_dunamis( 'com_integrator' );

dunloader( 'helpers', 'com_integrator', true );

//----------------------------------------------------------[ DUNAMIS LOADED ]

if(! class_exists( 'IntElementBase' ) )
{
	// Create a Joomla 1.6 compatible base first
	if( version_compare( JVERSION,'1.6.0', 'ge' ) )
	{
		class IntElementBase extends JFormFieldList {
			public function getInput() {
				return parent::getInput();
			}
		}
	}
	// If not 1.6 then create a Joomla 1.5 base first
	else {
		class IntElementBase extends JElement {}
	}
}


class IntElement extends IntElementBase
{
	/**
	 * Provides mechanism to exclude an empty connection (upon failure)
	 * @access		public
	 * @since		3.0.2
	 * @var			array
	 */
	var $_excludes	= array();
	
	/**
	 * Used for storing a created ID when on J! 1.5
	 * @access		public
	 * @since		3.0.2
	 * @var			string
	 */
	var $_id		= null;
	
	var $_name		= 'CnxnList';
	
	public function fetchElement( $name, $value, &$node, $control_name )
	{
		if ( version_compare( JVERSION, '1.6.0', 'l' ) ) {
			$this->_id = $control_name.$name;
		}
		
		$pagetxt	= $this->getCnxnpages();
		$options	= $this->getOptions();
		$selpage	= $this->_parent->get(  $this->_buildName( false ) . '_page' );
		
		$class		= ( $node->attributes('class') ? 'class="'.$node->attributes('class').'"' : 'class="inputbox"' );
		$class		.= ' onChange="updatepages(this.options[this.selectedIndex].value, \'' . $this->_buildName() . '\')"';
		
		$this->_buildJavascript( $pagetxt, $selpage, $this->_buildName() );
		return JHtml::_('select.genericlist',  $options, ''.$control_name.'['.$name.']', $class, 'value', 'text', $value, $control_name.$name);
	}
	
	
	public function getInput()
	{
		$selpage	= $this->form->getValue( $this->_buildName( false ) . '_page', ( strpos( $this->_buildName(), 'params' ) !== false ? 'params' : null ), 0 );
		$pagetxt	= $this->getCnxnpages();
		
		$this->_buildJavascript( $pagetxt, $selpage, $this->_buildName() );
		
		return parent::getInput();
	}
	
	
	/**
	 * Method to get the options for the field
	 * @access		public
	 * @version		3.1.01
	 * @version		3.1.00		- Major rewrite for API change
	 * 
	 * @return		array
	 * @since		3.1.00
	 */
	protected function getOptions()
	{
		static $options	= null;
		
		if ( $options == null ) {
			
			$options	=
			$tmp		=
			$data		=	array();
			
			$api		=	dunloader( 'api', 'com_integrator' );
			$cnxns		=   $api->get_cnxnlist( array( 'type' => 'applications' ) );
			
			// Lets order our cnxns properly
			foreach ( $cnxns as $aid => $cnxn )	$tmp[$cnxn->name]	=	$aid;
			ksort( $tmp );
			foreach ( $tmp as $t )				$data[]				=	$cnxns[$t];
			
			// Start our options array
			$options[]	=   (object) array( 'value' => '', 'text' => '- Select a Connection -');
			
			if ( $data === false ) return $options;
			
			foreach ( $data as $cnxn )
			{
				if ( in_array( $cnxn->id, $this->_excludes ) ) continue;
				$options[]	= (object) array( 'value' => $cnxn->id, 'text' => $cnxn->name );
			}
		}
		
		return $options;
	}
	
	
	protected function getCnxnpages()
	{
		static $pages	= null;
		
		if ( $pages == null ) {
			$api	=	dunloader( 'api', 'com_integrator' );
			$items	=	$api->get_cnxnpages();
			
			if ( $items === false ) return null;
			
			foreach ( $items as $item ) {
				
				if ( empty( $item->pages ) ) {
					$this->_excludes[]	= $item->cnxn_id;
					continue;
				}
				
				$txt	= array();
				asort( $item->pages );
				foreach( $item->pages as $val => $page ) {
					$txt[]	= $page . '|' . $val;
				}
				$pages .= 'pages[' . $item->cnxn_id . '] = ["' . implode( '", "', $txt ) . '"]
';
			}
		}
		return $pages;
	}
	
	
	private function _buildName( $full = true )
	{
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$id	= $this->id;
			$pstrip	= 'params_';
		}
		else {
			$id		= $this->_id;
			$pstrip	= 'params';
		}
		
		$data	= str_replace( '_cnxn_id', '', str_replace( 'jform_', '', $id ) );
		
		if ( $full ) {
			return $data;
		} else {
			return str_replace( $pstrip, '', $data );
		}
	}
	
	
	private function _buildJavascript( $pagetxt, $selpage = null, $fieldname = 'register' )
	{
		static $onetime		= true;
		static $includes	= array();
		
		$javascript	=   null;
		$document	=	JFactory :: getDocument();
		$v			=   version_compare( JVERSION, '3.0', 'ge' ) ? '35' :
						( version_compare( JVERSION, '1.6.0', 'ge' ) ? '25' : '15' );
		
		if ( $onetime ) {
			$onetime	=   false;
			$javascript	=   <<< JSCRIPT
var pages = new Array();
pages[''] = ["- Select A Page -|"]
{$pagetxt}
JSCRIPT;
			
			IntegratorHelper :: addMedia( "functions{$v}/js" );
			$document->addScriptDeclaration( $javascript );
			IntegratorHelper :: addMedia( 'cnxnlist/css' );
		}
		
		if (! isset( $includes[$fieldname] ) ) {
			$includes[$fieldname] = true;
			
			if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
				$document->addScriptDeclaration( "jQuery('document').ready( function() { var tmp = document.getElementById( 'jform_{$fieldname}_cnxn_id' ); updatepages( tmp.options[tmp.selectedIndex].value, '{$fieldname}', '{$selpage}' ); } ); " );
			}
			else if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
				$document->addScriptDeclaration( "window.addEvent('domready', function() { var tmp = document.getElementById( 'jform_{$fieldname}_cnxn_id' ); updatepages( tmp.options[tmp.selectedIndex].value, '{$fieldname}', '{$selpage}' ); }) " );
			}
			else {
				$document->addScriptDeclaration( "window.addEvent('domready', function() { var tmp = document.getElementById( '{$fieldname}_cnxn_id' ); updatepages( tmp.options[tmp.selectedIndex].value, '{$fieldname}', '{$selpage}' ); }) " );
			}
		}
	}
}

if ( version_compare( JVERSION,'1.6.0','ge' ) ) {
	class JFormFieldCnxnList extends IntElement {}
}
else {
	class JElementCnxnList extends IntElement {}                
}