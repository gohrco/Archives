<?php
/**
 * Integrator 3
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.01 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 *
 * @desc       Default controller for Integrator 3
 *
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );


/**
 * IntegratorControllerDefault class is the default task handler for the admin area
 * @version		3.1.01
 *
 * @since		3.0.0
 * @author		Steven
 */
class IntegratorControllerDefault extends IntegratorControllerExt
{

	/**
	 * Constructor task
	 * @access		public
	 * @version		3.1.01
	 *
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
	}



	/**
	 * Display task
	 * @access		public
	 * @version		3.1.01
	 *
	 * @since		3.0.0
	 * @see			IntegratorController :: display()
	 */
	public function display()
	{
		$input	=	dunloader( 'input', true );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			$input->setVar( 'view', 'default' );
			$input->setVar( 'layout', 'default35' );
		}
		else {
			$input->setVar( 'view', 'default' );
		}
		
		parent::display();
	}
	
}