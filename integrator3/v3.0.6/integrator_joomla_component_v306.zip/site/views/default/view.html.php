<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.6 ( $Id: view.html.php 119 2012-11-07 17:13:30Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.5.0
 * 
 * @desc       This is the default view file to assemble the view for the user
 *  
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );


/**
 * Default view is used to render the wrapper
 * @version	3.0.0
 * 
 * @since	1.5.0
 * @author Steven
 */
class IntegratorViewDefault extends JView
{
	/**
	 * Builds the view from the display task for the user
	 * @access	public
	 * @version	3.0.0
	 * @param 	string		$tpl - presumably a template name never used
	 * 
	 * @since	1.5.0
	 */
	public function display($tpl = null)
	{
		$app		= & JFactory::getApplication();
		$params		= & $app->getParams();
		$uri		= &	JURI::getInstance();
		$document	= &	JFactory::getDocument();
		$layout		= &	IntegratorHelper :: get( 'layout', 'default' );
		$route		=   false;
		
		// If we aren't passing the override variable, redirect to desired location
		if (! IntegratorHelper :: get( "override", false ) && $layout == 'default' ) {
			
			$api		= & IntApi :: getInstance();
			$lang		=   IntegratorHelper :: getLanguage();
			$route		=   $api->get_route( array( 'cnxn_id' => $params->get( 'menu_cnxn_id' ), 'page' => $params->get( 'menu_page' ), 'vars' => $params->get( 'qrystring' ), 'lang' => $lang  ) );
			$layout		=   'debug';
			
			if ( $route === false ) {
				$debug	= $params->get( 'IntegratorDebug' );
				if ( $debug == 'No' ) $route = '';
			}
		}
		
		// If we have a route to redirect to then do so
		if ( $route !== false ) {
			
			if (! is_null( $enable = JRequest :: getVar( 'dg' ) ) ) {
				// Must occur after pulling any info from API
				defined( 'INTEGRATOR_API' ) or define( 'INTEGRATOR_API', true );
				$user	= & JFactory :: getUser();
				$user->setParam( 'display_gravatar', $enable );
				$user->save();
			}
			
			$app->redirect( $route );
			$app->close();
		}
		
		switch( $layout ):
		case 'loginerror':
			$errormsg	= 'COM_INTEGRATOR_LOGINERROR_' . strtoupper( IntegratorHelper :: get( 'errmsg' ) );
			$errorcode	= ( $params->get( 'IntegratorDebug' ) == 'Yes' ? ' (' . IntegratorHelper :: get( 'errmsg' ) . ')' : '' );
			
			JError::raiseWarning( IntegratorHelper :: get( 'errmsg' ), JText::_( $errormsg ) . $errorcode );
			
			if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
				$app->redirect(JRoute::_('index.php?option=com_users&view=login', false));
			}
			else {
				$app->redirect( JRoute::_('index.php?option=com_user&view=login', false ) );
			}
			
			$app->close();
			
			break;
		case 'debug':
			$debug	= & IntDebug :: getInstance();
			$data	=   $debug->get_output();
			
			$this->setLayout( 'debug' );
			$this->assignRef( 'debug', $data );
			
			break;
		case 'default':
		default:
			
			$base = & $document->getBase();
			if ( empty( $base ) ) {
				$document->setBase( $uri->toString( array('scheme', 'host', 'path') ) );
			}
			
			IntegratorHelper :: addMedia( "reset/css", array(), true );
			break;
		endswitch;
		
		$this->assignRef('params',	$params);
		
		parent::display($tpl);
		
	}
}