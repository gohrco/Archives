<?php
 
$__LANG = array (
	'settings_integrator'		=> 'Integrator',
	'integrator_apititle'		=> 'Integrator API Settings',

// Integrator URL
    "integrator_url"			=> "Integrator URL",
    "d_integrator_url"			=> "Enter the URL to your Integrator application",

// API Username
	'integrator_apiusername'	=> 'Integrator API Username',
	'd_integrator_apiusername'	=> 'Enter the API Username you setup for the Integrator application',

// API Password
	'integrator_apipassword'	=> 'Integrator API Password',
	'd_integrator_apipassword'	=> 'Enter the password associated with the API account for the Integrator',

// API Secret Key
	'integrator_apisecret'		=> 'API Secret Key',
	'd_integrator_apisecret'	=> 'Enter the API Secret Key you have in your Integrator application.  This is used for security purposes between these two connections, and it is highly advisable to be unique.  <strong>Never give out the API Secret Key!</strong>.',

// Integrator Cnxn_id (_c)
	'integrator_cnxnid'			=> 'Integrator Connection ID',
	'd_integrator_cnxnid'		=> 'Enter the connection id associated with this connection from your Integrator control panel.',

// Use SSL for Login / Logout
	'integrator_usessl'			=> 'Use SSL for Log In / Out',
	'd_integrator_usessl'		=> 'If you have an SSL certificate on the domain your Integrator is located, you can use SSL here.  To not use SSL, specify `Never`, to force SSL always, select `Force Always` and to defer to the current scheme, select `Ignore`.',
	
// Fusion Custom Pages
	'integrator_pagestitle'		=> 'Custom Fusion Pages to Map',
	'integrator_custompages'	=> 'Enter Custom Pages',
	'd_integrator_custompages'	=> 'You can enter additional pages to include for routing users to your Fusion application.  Each additional page should appear on its own line and the route should be separated by the title with a "|".'  
);
?>