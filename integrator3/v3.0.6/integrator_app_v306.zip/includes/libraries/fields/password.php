<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class to generate a password field
 * @version		3.0.6
 * 
 * @since		3.0.2
 * @author		Steven
 */
class PasswordField extends form_definition
{

	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.6
	 * @param		array		- $options: contruction options
	 * 
	 * @since		3.0.2
	 */
	public function __construct( $options = array() )
	{
		parent::__construct( $options );
	}
	
	
	/**
	 * Method to generate a form field
	 * @access		protected
	 * @version		3.0.6
	 * 
	 * @return		string
	 * @since		3.0.2
	 * @see			form_definition::field()
	 */
	protected function field()
	{
		$name		= $this->name . ( $this->array ? '[]' : '' );
		$arguments	= $this->arguments();
		
		if (! isset( $arguments['class'] ) ) $arguments['class'] = 'span5';
		
		$use	= array( 'name' => $name, 'value' => set_value( $this->name, $this->value ), 'id' => $this->lang ) + $arguments;
		$field	= form_password( $use );
		
		return $field;
	}
}