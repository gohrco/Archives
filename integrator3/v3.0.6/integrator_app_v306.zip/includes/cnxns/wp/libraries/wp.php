<?php defined('BASEPATH') OR exit('No direct script access allowed');

include_once( "render.php" );
include_once( "api.php" );

/**
 * Wordpress Connections Library extended class
 * @version		3.0.6
 * 
 * @since		3.0.0
 * @author Steven
 */
class Wp extends Cnxns_library
{
	protected	$apiparams		= array();		// The parameters to post / put for API connections
	protected	$isvisual		= true;
	protected	$renderparams	= array();		// The parameters to post / put for Rendering the site back to user
	protected 	$type			= "wp";	// The type reference for this object
	//protected	$uri			= null;			// The global URI object for use
	protected 	$version		= "3.0.6";	// The version of this object in use
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.6
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		$this->_ci = & get_instance();
	}
	
	
	/**
	 * Bind the parameters to connection
	 * @access		public
	 * @version		3.0.6
	 * @param		varies		- $params: if empty, does nothing, if integer, loads from DB, else a json_encoded string
	 * 
	 * @since		3.0.0
	 * @see 		Cnxns::bind()
	 */
	public function bind( $params = null )
	{
		parent::bind( $params );
	}
	
	
	/**
	 * Verifies settings for the connection
	 * @access		public
	 * @version		3.0.6
	 * 
	 * @return		boolean true on success
	 * @since		3.0.0
	 * @see Cnxns_library::update_settings()
	 */
	public function verify_settings()
	{
		$api	= & get_api( $this->cnxn_id );
		$CI		= & get_instance();
		
		// =================================================
		// ---BEGIN: Verify settings updated in parent first
		// -------------------------------------------------
		if (! ( $model = parent::verify_settings() ) ) {
			return error_message( 'msg.error.noconnection' );
		}
		// ---END:   Verify settings updated in parent first
		// =================================================
		// ---BEGIN: Test the Base Connection URL
		// -------------------------------------------------
		$baseuri	= new Uri( $model->get( 'url', null, 'globals' ) );
		$baseuri->setPath( rtrim( $baseuri->getPath(), '/' ). '/' );
		
		if (! ( $result = $api->ping( $baseuri->toString() ) ) ) {
			$model->set( 'active', false );
			$model->save();
			return error_message( 'msg.error.cnxnping' );
		}
		else {
			$model->set( 'url', $baseuri->toString(), 'globals' );
			$model->save();
		}
		
		// ---END:   Test the Base Connection URL
		// =================================================
		// ---BEGIN: Test the Image URL
		// -------------------------------------------------
		if (! $model->get( 'imgurl', false, 'visuals' ) ) {
			$model->set( 'imgurl', $model->get( 'url', null, 'globals' ), 'visuals' );
			$model->save( $model->get_properties() );
			return info_message( 'msg.info.imgurlunset' );
		}
		// ---END:   Test the Image URL
		// =================================================
		// ---BEGIN: Test API URL for active connection
		// -------------------------------------------------
		if ( ( $active = $api->ping() ) !== true ) {
			if ( $prev != null ) $CI->session->set_flashdata( 'info_message', $prev );
			error_message( 'msg.error.cnxndeactivated', $model->get( "name" ) );
			$model->set( 'active', 0 );
			$model->save();
			return true;
		}
		// ---END:   Test API URL for active connection
		// =================================================
		// ---BEGIN: Test API Credentials
		// -------------------------------------------------
		$result	= $api->ping( true );
		if ( $result != 'Pong' ) {
			error_message( 'msg.error.msgreturned', 'API Credential Test', $model->get( 'name' ), $result );
			error_message( 'msg.error.cnxndeactivated', $model->get( "name" ) );
			$model->set( 'active', 0 );
			$model->save();
			return true;
		}
		// ---END:   Test API Credentials
		// =================================================
		
		return true;
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE RELATED TO TRANSLATING BETWEEN CUSER AND THIS CNXN
	 * **********************************************************************
	 */
	
	
	/**
	 * Creates an array of fields to filter cuser object for this object
	 * @access		public
	 * @version		3.0.6
	 * @param		array		- $full_form: the full form from the cuser object
	 * @param		boolean		- $is_new: if this is a new user form
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function cuser_fields( $full_form, $is_new = false )
	{
		$data		= array();
		$use_fields	= array( 'firstname' => array( 'req' => true ), 'lastname' => array( 'req' => true ), 'email' => array( 'req' => true ), 'password' => array( 'req' => $is_new ) );
		
		//if ( $is_new ) {
			$use_fields['username'] = array( 'req' => true );
		//}
		
		foreach( $use_fields as $name => $optns ) {
			$data[$name] = $full_form[$name];
			
			if ( $optns['req'] ) {
				$data[$name]['validation'] = 'required|' . $full_form[$name]['validation'];
			}
		}
		
		return $data;
	}
	
	
	/**
	 * Processes an array of data and inserts into the common user object
	 * @access		public
	 * @version		3.0.6
	 * @param		array		- $wpuser: array of data from this connection type
	 * 
	 * @since		3.0.0
	 */
	public function cuser_place( $wpuser )
	{
		// Error prevention
		if (! is_array( $wpuser ) ) return;
		
		$cuser	= & Cuser::getInstance( true );
		$data	=   array();
		$trans	=   $this->cuser_table( true );
		
		foreach ( $wpuser as $k => $v ) {
			
			if ( isset( $trans[$k] ) ) {
				$data[$trans[$k]] = $v;
				continue;
			}
			
			if ( $k == 'update' ) {
				
				if (! is_array( $v ) ) continue;
				
				foreach( $v as $k2 => $v2 ) {
					
					if ( isset( $trans[$k2] ) ) {
						$data['update'][$trans[$k2]] = $v2;
					}
					
				}
				
				$data['update']['fullname']
					= ( isset( $data['update']['firstname'] ) ? $data['update']['firstname'] : $data['firstname'] ) 
					. ' '
					. ( isset( $data['update']['lastname'] ) ? $data['update']['lastname'] : $data['lastname'] );
					
				continue;
			}
		}
		
		$data['fullname']	= $data['firstname'] . ' ' . $data['lastname'];
		
		// Set the data
		$cuser->set_properties( $data );
		
		// If we are coming from the API interface, we must establish username and fullname for cnxns requiring such
		if ( defined( 'INTEGRATOR_API' ) && ( get_var( '_c' ) == $this->get( 'cnxn_id' ) ) ) {
			$cuser->complete( $this->get( 'cnxn_id' ) );
		}
		
		return;
	}
	
	
	/**
	 * Extracts user data from the common user object for use on this connection type
	 * @access		public
	 * @version		3.0.6
	 * 
	 * @return		array of user data
	 * @since		3.0.0
	 */
	public function cuser_retrieve()
	{
		$cuser	= & Cuser::getInstance();
		$data	=   array();
		$cdata	=   $cuser->get_properties();
		$trans	=   $this->cuser_table();
		
		foreach ( $cdata as $k => $c ) {
			if ( empty( $c ) ) continue;
			
			if ( isset( $trans[$k] ) ) {
				$data[$trans[$k]] = $c;
				continue;
			}
			
			if ( $k == 'update' ) {
				
				foreach( $c as $k2 => $c2 ) {
					if ( empty( $c2 ) ) continue;
					
					if ( isset( $trans[$k2] ) ) {
						$data['update'][$trans[$k2]] = $c2;
					}
				}
			}
		}
		
		return $data;
	}
	
	
	/**
	 * Translation table from WP to cuser object
	 * @access		public
	 * @version		3.0.6
	 * @param		boolean		- $from: if coming from cuser then true
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function cuser_table( $from = false )
	{
		$data	= array();
		
		$data['user_login']		= 'username';
		$data['user_pass']		= 'password';
		$data['user_email']		= 'email';
		$data['first_name']		= 'firstname';
		$data['last_name']		= 'lastname';
		
		return ( $from ? $data : array_flip( $data ) );
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE RELATED TO THE USER INTEGRATION OF THE CONNECTION
	 * **********************************************************************
	 */
	
	
	/**
	 * Decodes the return url
	 * @access		public
	 * @version		3.0.6
	 * @param		base64 string	- $return: base64 encoded string
	 * 
	 * @return		string containing URL
	 * @since		3.0.0
	 */
	public function decode_return_url( $return )
	{
		return base64_decode( $return );
	}
	
	
	/**
	 * Returns the correct URL for the forgot password link
	 * @access		public
	 * @version		3.0.6
	 *
	 * @return		string
	 * @since		3.0.2
	 * @see			Cnxns_library::get_forgot_password_url()
	 */
	public function get_forgot_password_url()
	{
		$cnxn_model	=   cnxn( $this->get( 'cnxn_id' ) );
		$base_url	=   $cnxn_model->get( 'baseurl' );
		$redirect	=   rtrim( $base_url, '/' ) . '/wp-login.php?action=lostpassword';
		return $redirect;
	}
	
	
	/**
	 * Takes care of storing session cookies
	 * @access		public
	 * @version		3.0.6
	 * @param		base64 string	- $sid: contains the session id base 64 encoded
	 * @param		base64 string	- $sname: contains the session name base 64 encoded
	 * 
	 * @since		3.0.0
	 */
	public function handle_session_cookies( $sid, $sname )
	{
		if ( ( $sid == NULL ) OR ( $sname == NULL ) ) return false;
		
// 		$sid	= base64_decode( $sid );
// 		$sname	= base64_decode( $sname );
		
		$cookie		= $sname . "=" . $sid;
		
		save_session_id( $sid, $this->cnxn_id );
		parent::handle_session_cookies( $cookie );
	}
	
	
	/**
	 * Takes the user array from Joomla 1.5 and converts it to a standard user array
	 * @access		public
	 * @version		3.0.6
	 * @param		array		- $user: contains the data passed by the API to the Integrator
	 * 
	 * @return		array containing standardized user data
	 * @since		3.0.0
	 */
	public function handle_user_array( $data )
	{
		if ( isset( $data['name'] ) ) {
			$tmp = explode( " ", $data['name'] );
			$data['firstname'] = $tmp[0];
			unset( $tmp[0] );
			$data['lastname']	= implode( " ", $tmp );
			unset( $data['name'] );
		}
		return $data;
	}
	
	
	/**
	 * Removes session cookies and session from database
	 * @access		public
	 * @version		3.0.6
	 * 
	 * @since		3.0.0
	 * @see			Cnxns_library::remove_session_cookies()
	 */
	public function remove_session_cookies()
	{
		remove_session_id( $this->cnxn_id, true );
		parent::remove_session_cookies();
	}
}