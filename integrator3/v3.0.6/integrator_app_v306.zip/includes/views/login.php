<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<!-- Always force latest IE rendering engine & Chrome Frame -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	
	<title><?php echo $template['title']; ?></title>
	<base href="<?php echo base_url(); ?>" />
	<?php echo $template['metadata']; ?>
	
	<!-- Mobile Viewport Fix -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
	
	<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
	
</head>
<body>

<div id="login-wrap">
	<div style="padding: 10px 0px; text-align: center;">
		<?php echo image( 'new-logo.png', null, array( 'id' => 'logo' ) ); ?>
	</div>
	
	<center><?php echo $template['partials']['sidehdr']; ?></center>
	<div id="loginBox">
		<?php echo $template['partials']['content_messages']; ?>
		<?php echo $template['partials']['body']; ?>
	</div>
</div>
</body>
</html>