<script>
$(function() {
	$( "#tabs" ).tabs();
});
</script>
<?php echo form_open("pagemap" );?>
<div id="tabs">
	<ul>
		<?php foreach ( $pages['app'] as $app_id => $app ) : ?>
		<li><a href="#app<?php echo $app_id; ?>"><?php echo $app['name']; ?></a></li>
		<?php endforeach; ?>
	</ul>
	<?php foreach( $pages['app'] as $app_id => $app ) :?>
	<div id="app<?php echo $app_id; ?>">
		<table width="100%" border="0" cellpadding="5" cellspacing="0">
			<thead>
				<tr>
					<th style="text-align: center; ">
						<?php echo lang( 'pagemap.hdr.page' ); ?>
					</th>
					<?php foreach ( $pages['site'] as $site_id => $site ) :?>
					<th style="text-align: center;"><?php echo $site['name']; ?></th>
					<?php endforeach; ?>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td style="border-right: 1px solid #223344; border-bottom: 1px solid #223344; text-align: right; "><?php echo lang( 'pagemap.hdr.defaultpage' ); ?></td>
					<?php foreach ( $pages['site'] as $site_id => $site ) : ?>
					<td style="border-bottom: 1px solid #223344; text-align: center; "><?php echo form_dropdown( 'page['.$app_id.'][default]['.$site_id.']', $site['pages'], set_value( "page[{$app_id}][default][{$site_id}]", $page[$app_id]['default'][$site_id] ) ); ?></td>
					<?php endforeach; ?>
				</tr>
				<?php foreach( $app['pages'] as $page_id => $page_name ) : ?>
				<tr>
					<td style="border-right: 1px solid #223344; border-bottom: 1px dotted gray; text-align: right; "><?php echo $page_name; ?></td>
					<?php foreach ( $pages['site'] as $site_id => $site ) : ?>
					<td style="border-bottom: 1px dotted gray; text-align: center; ">
					<?php echo 
					form_dropdown( 
							'page['.$app_id.']['.$page_id.']['.$site_id.']', 
							array( "default" => "-- " . lang( 'option.pagemap.default' ) . " --" ) + $site['pages'], 
							set_value( "page[{$app_id}][{$page_id}][{$site_id}]", 
							$page[$app_id][$page_id][$site_id] )
					); ?></td>
					<?php endforeach; ?>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<?php endforeach; ?>
</div>

<div class="push-4 append-bottom clear"><?php echo form_button( array( 'name' => 'submit', 'id' => 'submit', 'value' => true, 'type' => 'submit', 'content' => lang( 'updatesettings' ) ) );?></div>

<?php echo form_close();?>