<?php
/**
 * Integrator
 * WHMCS - Factory File
 * 
 * @package    Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.17 ( $Id: factory.php 273 2013-08-20 15:20:34Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file instantiates objects as needed
 * 
 */

/*-- Security Protocols --*/
if (!defined("WHMCS")) die("This file cannot be accessed directly");
/*-- Security Protocols --*/

/*-- File Inclusions --*/
//
// v3.0.9 - DEFINITIONS MOVED HERE DUE TO ISSUE WITH SOME INCLUSIONS

// ---- BEGIN INT-9
//		Configurable Groups Fail to Duplicate Properly
if ( defined( "CLIENTAREA" ) == true ) {
	if (! defined( "WHMCS_ROOT" ) ) {
		define( "WHMCS_ROOT", dirname(dirname(dirname(dirname(__FILE__) ) ) ) . DIRECTORY_SEPARATOR );
	}
}
// ---- END INT-9

// Path to Templates Directory
if (! defined( "TEMPLATE_PATH" ) ) {
	// Determine the version and template name to use
	$version			= substr( $GLOBALS['CONFIG']['Version'], 0, 3);
	$int_template		= $GLOBALS['CONFIG']['Template'];
	$order_template		= $GLOBALS['CONFIG']['OrderFormTemplate'];

	if (! in_array( $int_template, array( 'classic', 'default', 'portal' ) ) ) $int_template = 'portal';

	// Define constants
	define( "TEMPLATE_PATH", dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'templates' . DIRECTORY_SEPARATOR . $version . DIRECTORY_SEPARATOR . $int_template . DIRECTORY_SEPARATOR );
	define( "TEMPLATE_OPATH", dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'templates' . DIRECTORY_SEPARATOR . $version . DIRECTORY_SEPARATOR . 'orderforms' . DIRECTORY_SEPARATOR . $order_template . DIRECTORY_SEPARATOR );

	define( "WHMCS_VERSION", substr( $GLOBALS['CONFIG']['Version'], 0, 3) );
	define( "TEMPLATE_URL", 'modules/addons/integrator/templates/' . $version . '/' . $int_template . '/' );
	define( "TEMPLATE_OURL", 'modules/addons/integrator/templates/' . $version . '/orderforms/' );
	define( "TEMPLATE_OSTYLE", $order_template );
}
//
// END DEFINITIONS
//
require_once( "core/object.php" );
require_once( "core/uri.php" );
require_once( "helpers/language.php" );
/*-- File Inclusions --*/

/**
 * Factory Class
 * @version		3.0.17
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntFactory
{
	/**
	 * Retrieves an instance of the configuration class
	 * @access		public
	 * @static
	 * @version		3.0.17
	 * 
	 * @return		instance of IntConfig object
	 * @since		3.0.0
	 */
	public static function &getConfig()
	{
		static $instance;
		
		if (! is_object( $instance ) ) {
			require_once( "classes/config.php" );
			$instance	= new IntConfig();
		}
		
		return $instance;
	}
	
	
	/**
	 * Retrieves a singular instance of the curl class
	 * @access		public
	 * @static
	 * @version		3.0.17
	 * 
	 * @return		instance of IntCurl object
	 * @since		3.0.0
	 */
	public static function &getCurl()
	{
		static $instance;
		
		if (! is_object( $instance ) ) {
			require_once( "core/curl.php" );
			$instance = new IntCurl();
		}
		
		return $instance;
	}
	
	
	/**
	 * Retrieves a singular instance of the database object
	 * @access		public
	 * @static
	 * @version		3.0.17
	 * 
	 * @return		instance of IntDatabase object
	 * @since		3.0.0
	 */
	public static function &getDbo()
	{
		static $instance;
		
		if (! is_object( $instance ) ) {
			require_once( "core/database.php" );
			$instance = new IntDatabase();
		}
		
		return $instance;
	}
	
	
	/**
	 * Retrieves a singular instance of the debug object, passing parameters if sent
	 * @access		public
	 * @static
	 * @version		3.0.17
	 * @param		mixed		- $options: can be an array, boolean or string
	 * 
	 * @return		instance of IntDebug object
	 * @since		3.0.0
	 */
	public static function &getDebug( $options = array() )
	{
		static $instance;
		
		if ( is_bool( $options ) )		$options = array( 'enable' => $options );
		if ( is_string( $options ) )	$options = array( 'script' => $options );
		
		if (! is_object( $instance ) ) {
			if (! isset( $options['enable'] ) ) {
				$config = IntFactory::getConfig();
				$options['enable'] = $config->Debug;
			}
			require_once( "classes/debug.php" );
			$instance = new IntDebug( $options );
		}
		else {
			if (! empty( $options ) ) {
				$instance->set_options( $options );
			}
		}
		
		return $instance;
	}
	
	
	/**
	 * Retrieves a singular instance of the hook class object
	 * @access		public
	 * @static
	 * @version		3.0.17
	 * 
	 * @return		instance of IntHook object
	 * @since		3.0.0
	 */
	public static function &getHook()
	{
		static $instance;
		
		if (! is_object( $instance ) ) {
			require_once( "classes/hook.php" );
			$instance	= new IntHook();
		}
		
		return $instance;
	}
	
	
	/**
	 * Retrieves the language file when in WHMCS backend
	 * @access		public
	 * @static
	 * @version		3.0.17
	 * @param		string		- $language: in the event $aInt hasn't been instantiated yet
	 * 
	 * @return		array containing language translations
	 * @since		3.0.0
	 */
	public static function &getLang( $language = 'english' )
	{
		static $intlang;
		
		if (! is_array( $intlang ) ) {
			global $aInt;
			$language = (! is_object( $aInt ) ) ? $language : $aInt->language;
			$lang_file	= dirname(__FILE__) . DIRECTORY_SEPARATOR . 'lang' . DIRECTORY_SEPARATOR . ucfirst( $language ) . '.php';
			$lang_file	= file_exists( $lang_file ) ? $lang_file : dirname(__FILE__) . DIRECTORY_SEPARATOR . 'lang' . DIRECTORY_SEPARATOR . 'English.php';
			require_once( $lang_file );
		}
		
		return $intlang;
	}
	
	
	/**
	* Retrieves a singular instance of the log class object
	* @access		public
	* @static
	* @version		3.0.17
	*
	* @return		instance of BLog object
	* @since		1.0.4
	*/
	public static function &getLog()
	{
		static $instance;
	
		if (! is_object( $instance ) ) {
			require_once( "classes/log.php" );
			$instance	= new IntLog();
		}
	
		return $instance;
	}
}