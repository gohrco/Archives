
ALTER TABLE `__DBPREFIX__users` MODIFY `username` varchar(32)
