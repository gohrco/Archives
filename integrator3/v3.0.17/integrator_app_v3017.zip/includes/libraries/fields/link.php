<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class to generate a link
 * @version		3.0.17
 * 
 * @since		3.0.8
 * @author		Steven
 */
class LinkField extends form_definition
{
	private	$_events	= array();
	private $href		= null;
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.17
	 * @param		array		- $options: contruction options
	 * 
	 * @since		3.0.8
	 */
	public function __construct( $options = array() )
	{
		foreach ( $options as $key => $value ) {
			if (strpos( substr( $key, 0, 2 ), 'on', 0 ) !== false ) {
				$this->_events[$key] = $value;
				unset( $options[$key] );
			}
		}
		
		if ( array_key_exists( 'href', $options ) ) {
			$this->href = $options['href'];
			unset( $options['href'] );
		}
		
		parent::__construct( $options );
	}
	
	
	/**
	 * Method to generate a link
	 * @access		protected
	 * @version		3.0.17
	 *
	 * @return		string
	 * @since		3.0.8
	 * @see			form_definition::field()
	 */
	protected function field( $name = null, $type = null )
	{
		$title		=	lang( $this->lang . '.link' );
		$uri		=	$this->getUrl();
		$args		=	$this->get_arguments();
		$field		=	anchor( $uri, $title, (array) $args );
		
		return $field;
	}
	
	
	/**
	 * Retrieves the argument string for the field
	 * @access		protected
	 * @version		3.0.17
	 * 
	 * @return		string
	 * @since		3.0.8
	 */
	protected function get_arguments()
	{
		$data		=	array();
		$string		=	null;
		$arguments	=	array(
				'id'					=>	$this->get_id(),
				)
					+	parent :: get_arguments()
					+	$this->get_events();
		
		foreach( $arguments as $key => $value ) {
			$data[]	= "{$key}=\"{$value}\"";
		}
		
		$string	= implode(" ", $data );
		return $string;
		return $data;
	}
	
	
	/**
	 * Method to retrieve and manipulate events set in form definition
	 * @access		protected
	 * @version		3.0.17
	 * 
	 * @return		array
	 * @since		3.0.8
	 */
	protected function get_events()
	{
		return $this->_events;
	}
	
	
	/**
	 * Method to generate the ID for the field
	 * @access		protected
	 * @version		3.0.17
	 * 
	 * @return		string
	 * @since		3.0.8
	 */
	protected function get_id()
	{
		$id = $this->name;
		$id = str_replace( '[', '_', str_replace( ']', '', $id ) );
		return $id;
	}
	
	
	/**
	 * Generates the URL for the link
	 * @access		protected
	 * @version		3.0.17
	 * 
	 * @return		string
	 * @since		3.0.8
	 */
	protected function getUrl()
	{
		$href = $this->href;
		return site_url( $href );
	} 
}