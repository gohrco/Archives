<?php //00926
/**
 * ---------------------------------------------------------------------
 * Integrator v3.0
 * ---------------------------------------------------------------------
 * 2009 - 2012 Go Higher Information Services.  All rights reserved.
 * 2013 September 3
 * version 3.0.17
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPxjrfN9VvXr5CgmmKG+ATATK+2pXT11DLjW/rd1RT8Q3Hb3pHlftx85m9XFjCSaw/oR8B9CT
IaONj7n8i83xRwAa5osLLCGO5YCE+3Ycu68h0VtJriPwuWa4dsmUiLBFFva0iSR+WCBW/irmH8tB
dO+Y2tu8rCZ5D2hEUVWHIF1Q5VvkuVoo4G8h4wQnBl0+kOsjg3AccBAsrnehGhIFqRM7mF7QrJ+c
6XgmJrYxw9Jh2EOSHlZ6SOFFJ2YJ5WQHa0bGJjUHdPqrOpVgd4DgBG5tcv2na2JXUvnvD5GJKBQK
xpyNccqPrLWN/3200O0fLWxbcSWou4gUMwyMtfjwFc2HUMF5/pqtN4187hKWk7JcyLQg55Z8X7Ly
G8IjRVczE3gigB7KcuqUrXkPnDzv9q3BTGb58aOue/9UtM+yJbCMXUucJnsBnQL0TkJw626+4B9e
GgVSE5cgQMRhMgOft0yC39T6qgkd88X73HGaAW5xXu0oV1kRR1jYDdRV1/rJFSL0CSOx14Oggis5
fdFX/jhVjuRSK508sVaOcAPQn7N40sUjeo9WnQecu1051PDxMmGKSx1Z6a1Ruh4IpwlxCT3P1r80
JiWJJXXMt7h6qu/PeKH/LQHER92/K4rl/vLr8AQiBFbxNlgLZFFnlx7gKCcV2rZxzK24+Q+RKIa/
k8xsiHN97Zliu51gAXf3IFkxSnDP1bvgTC4BH+BmWwA82PblAue/Xgp2BEWu4ePWA+Wt+hlksLeZ
Wud8heqN4xQ/PcHSXHlA5Oi7qSCAwVQ2TvogoZUeMnloUGJoCM6mOT+CE3PHekhtZhUwxLmMwMZX
iKZEwws7my2bOfPHbdZ4UnZJzVbOVDWrH3hb0LbRIRxrUY+QjFqUUoy8EF1oet3gveaspCATKVyh
fA3+ZpO9/xwDAN8sjEt3CIakn+hesy6MRrqVT6+GQHC53T7NSNYbZ8R9ZCDq7+ZZjHJxnd7/UeX4
aZzMdRAnCT48HLaPItCo/Lrnw6CTyVHP3dhXnQxzvX3ZKor+ek5vYJ7NlAMlwScLxMbECV4PP1wx
/3MPb2xQ6WeKyn/h0sjfDFHR3CiWU3geYN933nGfSa2kngQSaDLY48Od+l45jDmZmK314baWh0PF
QBYrs2cN8zl731z8hHGfVplpp5AJz0VNkQZurs661P90TrDuHCp/LxbsbtzGyqxJQ0NdcjWxR2H9
JAJMUals4Gjok4od6Q58oI7BubQu5+0KHuUaNcB+PpV/DXgVQqgcL6HJEX5oEYVZoYrY1y36YO/p
Si89nUM5dgFrSbvNBw+nbh/DTyqbwbtGKVzEgYK1ucnY3w3QhdOuZyr61y7wrtJqpxmrkvYyfUdb
ert7t0nyEH3jFhcmi+aUdJ/e4yBGka2n6wGC2irqnFomXmi0vVM8Fc3Z3l5L8F2v17tAcDRMZ1qd
p99mWI2I/rEE+EDZsQHcKssxpRPWS2pUTigPwvz8lFsX/9zxsPjGMIMxFymkRbTUPPJ4N/q3x4l8
0jT7B9Dk7J9E4yT1xVdTGeU5s7O5/F0xBwfojZGIaYY59OJfD2/1rFfuRroZs93aXGFYqTn8IvH8
gxc4Jr720YV4Su0tfuR43mnAItqhLZPl+kMypxfpyEdgnaz/bfVVOQdUjajqGPPlYol8gXau/vKo
8Rqgy6i8GWnVhCVfoHBSPQv+kHHzzZ+XMVtwFGfVcU190nHdvQEH9FGLe0jfGr0C44g+fA7tDWqo
jxy4HM8d2fvPzqCvjqabzjqLEyDq8O9Ng3+lbNv7V5yaR8W7LSvWwtt41QNVXGREqHrzOacQfsk2
NkXUlesw0HcFY1+EOLoUvc/j7z/9D0U3j8KGXBseiGWMthir4zjyo2Iwn76lcFYgG+Qsq5fzy3Ue
B21y40A/dzgB26BXaet0wfqriWfi5IAjXUJJKK1pSk5A4bliJUNO/3r5fJICl+7fG+bHirHD5YRx
p+FxBEqw1EGLLhmYlfwLc5fWRiRDW+bkP4X9T2MuajwFz41K+vt9VW5UCVC+EWaqcmywOnpTXc+1
TbLa58yLsBSwkMa3hTg+hsHyeFLokC0vxjM5zPXOH6uQVfI56FcpmoMMvuYQOhMnDTIAfugxxN2J
OE/HCELRqFZn4aC1kFMvp/ya9QZHGSMBRRoxXRR3UkknoaWO8+ULhJ4lVcvSQ1Z44YxxZMiTi8Zk
i6NMzMPJiWCJNHh1R9wurHzzcVKoQx73mwvYGzZnXLHVWD8WEXSBb9zAOpGRDgIAWWwcVFEhjdIO
2+L33xtM0VUWLnOR7UGsWL13llR8xnFZ8kMs8NQ0EyZhZmNiJ8fWu+I2ZPCv89JrQlMMVAMcuXSa
UF/eLkbqj06y/kmq2bhQ4Ahj5pTqBAwlN1Cum1pWS+psiIAuCUb8KSf7HkKBmwFysyx55w6gjtEo
Rlj0t3IzPU8L3SNNSG0pDD2QsMLZ5QLVSjzcMuWQgFvIDQ3daZbgP+XmafnusrXv3apB2RTlzNPn
dpt5HqvJTaSWZBZeZdnOMW2CyYyAa4DcOsBYLx5LTJ+KMuaebubI/mm0CKGvIJqCUEz3koUGUU7p
tTHZ9n6yPjNlta7EpLjOf3DV8R0qE1dsJfhg4nMgbZln1jdy2P8UC2Xf9tbEt8yLwYD4cfoK0xTr
jMN6320aoFoY7y6fgJfc/VcH3+J1eCwVuFcVwdzrEZ0hiKmXGvM81pZsL5seuQkLgfppG0MgwKyz
E2Nftt78EQY4JkN1859GQf+pKVO6CnGOYhhMQqze4ikL/1d4S2Dz/sPsUzyaPKKiyK6QyX0Hmrd2
ivXqLx6CZzpkLdMiKIM8l1PmLhXI6rNejbGQYTLuFMPLcmr79md7Hy2pdRYW2Q56ZiUEYJISojOg
gT2Psiv8QIQedjjvc1oCAE4NOhGqrY2UokIbQ2jfufNTu7P6USOl729pTCCmCExlfbIpSA4mew42
YTpMa2nPhBbjf6uOuVAXkGjAZR0WS1KjtvVJFnnSKmMLz9pjiQ4chnB/jDul0MDDNEn/f7MzL+oo
pYNoOozFWOP1iSBv++uO9wdIXd8s0iCRabSQHLxwWzHt8RcHBCUOzZII7zkAMN30xV+QUrn4mgdk
Choyo352VTD3jSwtjzx4ddVS8DxyYJDuSmrpZOzC5eD6lzkkOEIfxWs3ktkAJVkP7aZYUDN65YkV
PwQwg16VUzuw48VPqw8av1FG7U6u450hdiVnNOi4y1FVulyMCq2Un3NsRZMr/7wbdtyDXvMkbjq0
JzZgMIVd8qzLNJ5j4NugHQqAvUOWjk646K3a3/9bz4I3AxCURDMV+j3F5x5wrBNCAfOiVYlhE/AH
5LSjstRaJ8VE8Sz+wWFM9O6/JVjQI1bGcxhj2y1ZUuBDRDdxtUMBBaPohpCzYUTiBnzuT4+zyDgT
09K5C8r2cz/cwIVcjxZV29KP53ke2w6OlDnnjlE9avA3NRp7gtxktRQLsJOUNWmmj8fBUjfcZW5u
G5UDhaFLfFK8Z0gq6UTpE1n1Raegqh8oZaXb1RHZ3vYQEdZY+V8h4PAUCA8QxRV76pFBZRzQjhne
0OrOUa2RlUIOyqfth8IbKeBpdixQow57AzEUkDkamDnKDkrf3o4HWYtI8EMh+khH1yZdlApcP9kL
IEdD8N8ALEu8gRMb2P2ir0ZxvUXNAEuG9YR81pxLYZh20j5lg1SGFlSYkYrX2xuMRjePySQGeucq
NLiYq/3ZftVb2OrPshscr6maCI6XGJRBALOOjowsu72NhDP0IFbhD17xdzag0Dstlm32lkvZlnzi
kYQ3UbyEhlOY7Xw4kL7D3zSSrMDGM1a/s9Og8smM1grFT0krp8XgoyD+eIJEDaiHNA8LkNYYzWu4
wUISZiulTZqb5mTkAQX+aj8lL635VyJWJd50oHd18GBSQyRXHSFCS8sMBiKlKNpPS3RafQgR/iEe
ZHHxkLlImDJlpZDKatjHW8DKGRGMve9bs5Aym8gictI6Q9bCcqlVwfmZioNZAqZTFmzW22xEcLL1
njF1j6Y8LWA4+S27eifyhdpd22sFC04MJmo58bsVinwdGAhr+RGU1RJR3MSPAiVJ3qd/mdLSUlE4
MW9wFlugvv3FwLtyr1cDlhvQAZ9cNqdMpj8ClFtUmdGTUzkOvxLJh7wmkXbLgiWjtLEPIRUTNpHE
VPSR6UbQ0kjDylNNsQTG6CIU1TzRk1JwZArxgYNiHTHvvqtsr/GaI7Sv1u61/Vd8MN/8cORqtVOM
qkZXfPbvL8MvCBqNrB2JRTDuXnTF2xDaA3YFamDToeWkplcQahyNcFZpHro+79WnKKOc5cvHIS45
VeV/vxIPu2U6DSezkIOTB7ODJCoCXpMxYv+ryFQ6dP+K1kCwAcMs2ZU0Lux1T7W9ukOBhFudDPpq
I/j7cvBtblVEV0NLsDiFGjbLlsVjU2uOpHvCyS6XlRz5SP1NP1hOHxmMqFzxaSznv9vGhEF42rbn
E4AgW4NzfP8/xXgec0u5h9NagXwXxnCW6ryPX65i8WgreDQVeHZnCMtX5kmW8aAAeOQsiVFqPCOo
xig+/iyHv/DXvT3IasSWw/aYHlXAjvNnhwegle4BqrASNe1d2TdJlsrmg9/vEm/bSPBYz5bh91R0
tOG8rSn4vTTcaDjDOwDeiJ37V6CzWqMyeKa93SaNKYtzb6PB8HrpTjLVCdtFsUpCpot74aeUqHpV
rs61OiDHfY5/DtGd3AAk25s5rGaTy6iGbJ0+yDfEstcPkgJeoO7YO38jbBW4mTcbJkg9Mma5GbLF
ai8nTARUzHKKHZK55p5EtvfNRwIj8ahYwqYkDuInv240YuP6XuPGsMdzGcpPWt+89AZCVFyqwp9O
nYMyNe2IQ1Oc6TLcPC1Sb1tz7SKKhO5t/DCx8FQAjkuH89ITxdQ7aHp7n+gT2upurQGElUlksOzd
CR5Yy7GuaNLfWWRE+ZYtaQqn0SP/IPKuc5fT7ZU/vllYbACq3jNp9jgWQ06US9/KfQ4O8qWZOWD0
IUcG8wQByoUzfO2fIUWuumJFhJwbGlaYHNnLD5ix3DtQyYQ+RbAdzm+dsYdFFywi44erkqclPdfq
i3VnciMRIcW6aYFWBdEekXwX84NRHIYHrhE9/Yq7FxDlW12wq0R/cY4Ns7b7PVZfaGL8IdEoQhbp
gxbZZU+6kReYSXhumhMOtU+cgTEV2LsNW51zPU5SEuAMDnrhVvQHi8DYIbsgRq5JzrqlgHRvXS5I
CyDqk2RPVUC4mQPtwLmMpNEu76LPG0ui1C0G94yTZhSqHdhPAZc426CIb8v5I3eMIdOPKXJiSMwI
DTcPs6/1XRmO1JivtFqc3aTMLiSwRXOY+W/qkWOsGhYNAymKxxf0TKksfnqEQkF8xF0O9IgpJ1y0
u+sosTtmQxnUZNEXWmCPKan+iMpbm0qs/cZwrWBnOpyGRLokeAlBTaWQz4yMOFlHqbXBVAsOo5CE
d2zLKxepceKJ2V/c0yiGqZPHSDzP0eCXsP0hI/Uoi96msSRNKn/1aoJpX7FZMF4sfvbyo4ZebrDq
dhHOEn0qq678XSH8UrvUCrHxzvgNjaWRiZK3+rSiVsEecg2Z0/7U6NtY9u+x2uB0MLqsYuxobiwd
rKgqrgYLM+qQeczn4uTYHNTGYL3r4iHfwp52MQYt0L2CXDlwoqjH7CCFPOVqYacYThpP3mdMRXqG
TweW76LNsCfK1TlBV0c+6Ahp3wpHXHj9h0661TmXBPs5lUB8NoHKL42sntlN0BNyGt6LGm2It2/4
fxMl/4hEDeLvA1bxjtwMxYpsRsnqQBaMMtc6Ohp0czHDMv0pJxS0/v8T0VAqBFXwaf/4az5XsP/U
RSx9O9jiwqe/IX5O9c8AeedIiThgAQQmrwLUBdRMpzWTyOZicrnmrIej2HQ6gdY2tRYpBvWxWZIg
ISyllXwb04+e2R2LKwSUVTTOD5qHMvamvQE+irbqCoVKbOIAiBlzrxN4SyV7b9+iNxIVn8M7dM6V
Z/q5j94muF3RU5fbbPOHuJr1lOEHoAgA7Iq3w2LNYuLd2NMnrtretre77ccLZubLx6MF5x+zJYLH
UjdSVEE8PUPNxb6Iuq720ZrLH9ojcakixJ8WowWNShsVl36S7mxgn+KGpzPo99NV22ZPE2JXsn5b
Hcn+YmIqqQY424qGZdVDFwixdkkwnwMbURgJzOsJAYBAuZNzKQZnpIlfv6qB4x3WXdO9Bii8v7Ws
NQvVgN31PX1mYgiaoq3eluyblwCZdSLAUr8ZZzX09UOPtCfVV+x82m46iKBZIPYvlZvJN1i4FrsC
b66tEe2AdrGETC9Sn6bfzevl/7T4G7tEkFFPAwEsKHcI4K/nLsb9LlQfq144hXES+Bg6y6pcBp0+
jn+ZtAN8nFTzAIkCfLBwWX3223CNS1LfqHZ4d0j9/Xa32cpoborLpfEfppXTvKQqNTVL8lWcql/L
n1spVWUiz4irJsgPmxZmwzXx808/sDg3wy/6Apx9ltxebHJZVzwTTnNVzLkYMOjvYx+q9DbDOnPq
EXPth28XCIO6XtLlob7fy/IHP/e7j9OQiqa9LI6r6xpLTgmIdeRzeS+lDvJ9k02iIqZSOzDskqcP
WnoiJj/V9TR6qdPVwpObDak68BuupGKMw/xB55RnqvlDxh/YDmqvUU/askR3L7XmOOoq4Y0/ceF9
zlmveMgCiLt6XItR+L5FcGHeSrKiDOi1Sjz+hAXJABUZ9x0w5xCr9Wnb6pBRG8shiMLI/zwlN8I6
xfD8UeZHy2IpVBbSXrLejZy23O4S9VtWcGw2uOdx2gv1Jbg3YhSIlSl3mFDxQ4fXcNULS8zXTNp4
Y02o4JiecnsGjsAC6M/r9VxJKKDh/+M64axgOjePukyvAhkRO/uWWq8IOmAFszFzaWPkkA1TTcb3
78ns5krX5cDntQ7JuHLHWFtEr7KYdhpfp0pazgdvezFGp1y5gbPTswLwJ7XMjoYUjMLSqYRk6lL7
4OHH7TUVoKxKATV2ZqpgDqs77GcOLosQeLxSz6e4+RTs1vvJ6qsVja/T+kH+DKl59gQySi1tPIAa
9EYHamz8TX8/7kkm4YPyzXVuZ9cB/1jKgrDnUZQ/cwHYYdqlA+h9l8o9Lx0Ulz3u2PP+sspgcVzi
YTNtNQrOGra2PF1bbuU2dH84fJBw/YCG0Z6xdqOXKqSZKqK+8mtgk+pHxYXcxQuCiYR/kahcc1Lq
pS2LdrObb4/yl1gK7RK+qQUmcn0D2A0zrlDuFUxw80S5oFTWd4zwPymKG6jfxy1JMC3lUOknjQLC
2zZ9lCs35Bo8pflxvcIYlA1DpSl1/c1h04cFRw7jnBTjAvfi5hO7fwFG9AiBFPEVmkC7yO/HIq5b
9lXu5+XXFqA7YdThYrWPcJHWTMK2SfgH2Pm0mjCjFLjY1g3qqHXzO0afOUjSDjT5GZ0O2aPhExpx
92SpuGpxwQNQFrbdhkX+nbDUczHIIEdxHto4gBcREGH3LceIV300igZyozzcG0/EobFP+UfU8AqN
gNOeRv1kHJHABu4LbuVyck+tqHv13F//LtYo9i8tfb1KNROzxhHbXge9V8CCuXtJVvlqDsC7t249
NNYZhnSSFT/L4RB1KGlQtUPr/Bd2dzWgr5Ng0ZbAWHVYl6ChVO3sZTYOLK42IojOy0DJ0QXz58Up
pnT+ubN5DG9jXnpc4B6nzfbvjSQ+sAQD/v0zG9nQGEUemJD3aVXeRep3J8fJJdFul1vE4wYNH/ky
qJBR0HKcrNPPwKOQ9QYeJbRvIZY28bed7cbqCXz1/QO6waftuKAwoFIu+aRQOvg/kh7KZiFjZhwd
k6lGwoGhn3AZlc3JzkL+vUTbw22IvbB7YP2AvNLw9kCtLy55zOzjnIv7IlCDowV9wBS+Leu80LMe
Bvh448YleCBQ+kUzU4RNPZUauNNE6RRgoHnio1xO9Ds5vTGeL6FfUQ96Hzhd9sJb4diFh0uA66h0
O5dY9XGDN4t3oFqQES9EFpfFkfHG+8A+dfWbg8k3OYofE7UXrY4UTk/YQL2ZLIRxXlEKxcZRNbVB
JT/qdIcsPywvP61c+nrekCy1/bshuNgmPK85yYHpJSXFuw+k8rYH1uo2oGpDyh71A6d0yq8Ibaf3
lCXrqMxK0eAF78QSdFl1u5IWbAgygPDrGAMQj1foi6DRbgICB6ZmOFlHjWnjAdK5JGLe1DJTUVYC
vv4+3TGgxftErW7bCE+vvfL3Mi2rmrquFtJ/zfzAmPI5uZvnuePGg+byCiObL0C3w3wyzmpXV5Qs
+lb0Z7CHMhjwNmtjlgJjiuRx5YD2apDtxBP1I/LFLxH0wxBRVVBDJ1xgJcbF4E7zy+1J3+ps6onA
/+yhuM1GL6QgvQ1xV5BBJDz3Xbxy9zAdro5/gdY9vtlJI924c3Vxlvf0Iz5fAd0aautMHjO74vYH
EYMqpVmbq6BkQ1zJet0ZgEKjv0OmpUiQfMEknuihwQ356k4zFscz8P9lAGOdvSkN1R2cJXd1MdKI
wdHR8NUBl+Mua7Jb0CkOPdBoNpucPQGGr4XjCKw5dgr0/8rsJrfKjuct6+cXaanyfog7Mn3NU/+i
HMvNWD4SzHu6jhUhMgaoiPVu+Jbu3aQ4KaAsow/NtcDG7KEL8IzJvlm2rqR5f7aao7FzASOlGYxt
GZGzCgcJXvRwoX1Zd1/TQi7KtXJp5eLoDtTs4f+bK4vnEEmDPzYpUsXrC1OYMzjwpzq6vdMHMYKe
aGu7UqaEypM6drjNwIjX30rmhyUYOFN3uh/1Gl2vjF5Su9WEUCYfm7MMgN9ogCAQCQdRmUvxnrqH
AwsgPVa613GjGeMHDSSTzNFn7MNaiNATXldZJqvfZtYS72wog1AQGH1uv6w1w+Qq2zapUzi5kSJp
OKrc5QnL01I5K094aQPifOBOCWZ6IRjvJ3SzDXQjMYIWK2+qGADVz1UEJB1UrMzQnVp898N14q4S
IJ6/OkNbo90xje6fHW2k8GOxfW8Wm9f3bfsyKSWlmEcTye8M65uxQwVPprw/jufdTseiDORooH+6
reLrcToNxp1EJa6WQiqKK/iTLwHKm8YzgXaY7L+LUi0CEkLnp84i2Dl4OZaHFi7df1D3BVu/uUeH
HOgWsO+zo7SQ9pxoGx5jBVQaZL1SX+/ogufKZuue4JdiEUnokl6vC9R4k18eMqw/4ILMiYlKU13r
5u0n58XTCIkiuYZrQYJFMn/FoQ87pOw4n2OnRrMcrjyBSoeDcNvCKX1ROPpzDbEo2bY5Qco6oo9v
J6lQoSy+1cUL7AQ3kL4ckvNnLBGeJqaFDJ6S2YCLFtyhYwpLa9dyMm8DEWoS9ug7WVSovK3wHIry
RtvIUY6LZ2NDghveogtZPdRqYdc9azSlIZ1R/kHnhVxQVhGz76EAYM1l8IDG4KqU9RKMyYDhBdbO
owoPjJ8m6yvmB4vjAoCDJeTWX5QndEs2dYwq1VF85+tiFpDJf6GKCzRWBhOj6iUVSudApFx0QJUc
s8RmXfUSbtsKyO/QAru0DIdRsAwWMn4nXMZspLOAIl1aNJ9PTTY+de8RitmITy3OFIkshw6FWm==