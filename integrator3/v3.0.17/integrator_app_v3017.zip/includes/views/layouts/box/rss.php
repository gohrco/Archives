<div class="box" id="rsswrap">
	
	<?php echo heading( lang( 'rssfeed.title' ), '2' ); ?>
	
	<?php if (! is_null( $rss ) ) : ?>
	
	<ul class="unstyled date">
		
		<?php foreach ( $rss as $item ) : ?>
		
		<li>
			<div class="date">
				<span class="month"><?php echo date( "M", $item->pubDate ); ?></span>
				<span class="day"><?php echo date( "d", $item->pubDate ); ?></span>
			</div>
			<?php echo heading( anchor( $item->link, $item->title, 'target="_blank"' ), '3' ); ?>
			<?php echo $item->description; ?>
		</li>
		
		<?php endforeach; ?>
		
	</ul>
	
	<?php endif; ?>
	
</div>