<div class="row-fluid">
	
	<?php echo form_open( $action, array( 'id' => 'loginForm', 'class' => 'well' ) ); ?>

	<?php foreach ( $fields as $item ) : ?>
	
		<?php if ( $item->type != 'checkbox' ): ?>
			
			<?php echo $item->label; ?>
			<?php echo $item->field; ?>
			
		<?php else: ?>
			
			<div class="row">
				<div class="span1">&nbsp;</div>
				<label class="checkbox span6" for="<?php echo $item->id; ?>">
					<?php echo $item->field; ?>
					<?php echo $item->label; ?>
				</label>
			</div>
			
		<?php endif; ?>
	
	<?php endforeach; ?>

	<?php foreach( $hidden as $hide ) : ?>
		<?php echo $hide->field; ?>
	<?php endforeach; ?>

<div class="row">
	<div class="span1">&nbsp;</div>
	<?php echo form_button( array( 'name' => 'submit', 'id' => 'submit', 'value' => true, 'type' => 'submit', 'content' => lang( $submit ), 'class' => 'btn btn-primary' ) );?>
</div>

<?php echo form_close(); ?>

</div>