<?php

$form['globals']	= array(
	'name'	=> array(
		'value'			=> "",
		'order'			=> 5,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'url' => array(
		'value'			=> "http://",
		'order'			=> 10,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'sslenabled' => array(
			'value'			=> false,
			'order'			=> 25,
			'type'			=> 'toggleyn',
			'validation'	=> '',
	),
	'active' => array(
		'value'			=> null,
		'order'			=> 20,
		'type'			=> 'toggleyn',
		'validation'	=> ''
	),
	'type' => array(
		'value'			=> null,
		'order'			=> 100,
		'type'			=> 'hidden',
		'validation'	=> ''
	),
	'id' => array(
		'value'			=> null,
		'order'			=> 110,
		'type'			=> 'text',
		'validation'	=> '',
		'readonly'		=> true
	)
);


$form['api']	= array(
	'apiurl' => array(
		'value'			=> "http://",
		'order'			=> 10,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'sslverify' => array(
		'value'			=> 0,
		'order'			=> 20,
		'type'			=> 'hidden',
		'validation'	=> ''
	),
	'apisecret' => array(
		'value'			=> null,
		'order'			=> 30,
		'type'			=> 'password',
		'validation'	=> 'required'
	),
	'apikey' => array(
		'value'			=> null,
		'order'			=> 40,
		'type'			=> 'password',
		'validation'	=> 'required'
	)
);

$form['users'] = array (
	'userenable' => array(
		'value'			=> 0,
		'order'			=> 10,
		'type'			=> 'toggleyn',
		'validation'	=> 'required'
	),
	'processlogin' => array(
		'value'			=> 0,
		'order'			=> 20,
		'type'			=> 'dropdown',
		'validation'	=> 'required',
		'list'			=> array( 'always', 'whenconnected', 'never' )
	),
	'usessl' => array(
		'value'			=> 'ignore',
		'order'			=> 22,
		'type'			=> 'hidden',
		'validation'	=> '',
		//'list'			=> array( 'none', 'force', 'ignore' )
	),
	'loginurl'	=> array(
		'value'			=> 'http://',
		'order'			=> 25,
		'type'			=> 'text',
		'validation'	=> ''
	),
	'logouturl' => array(
		'value'			=> 'http://',
		'order'			=> 30,
		'type'			=> 'text',
		'validation'	=> ''
	),
	'storeusername' => array(
		'value'			=> 'random',
		'order'			=> 40,
		'type'			=> 'dropdown',
		'validation'	=> 'required',
		'list'			=> array( 'first.last', 'last.first', 'random', 'flastname','firstnamel', 'firstname', 'lastname' )
	),
	'storename' => array(
		'value'			=> 'firstlast',
		'order'			=> 50,
		'type'			=> 'dropdown',
		'validation'	=> 'required',
		'list'			=> array( 'firstlast', 'firstlastco', 'lastfirst', 'lastfirstco' )
	),
	'usernametype' => array(
		'value'			=> 'email',
		'order'			=> 51,
		'type'			=> 'hidden',
		'validation'	=> 'required'
	),
	'forceadd' => array(
		'value'			=> 1,
		'order'			=> 70,
		'type'			=> 'toggleyn',
		'validation'	=> 'required'
	),
	'forcepwupdate' => array(
		'value'			=> 1,
		'order'			=> 80,
		'type'			=> 'toggleyn',
		'validation'	=> 'required'
	),
	'defaultlastname' => array(
		'value'			=> '(unknown)',
		'order'			=> 100,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
);

$form['visuals'] = array(
	'visualenable' => array(
		'value'			=> 0,
		'order'			=> 10,
		'type'			=> 'toggleyn',
		'validation'	=> 'required'
	),
	'sslenabled' => array(
		'value'			=> 0,
		'order'			=> 20,
		'type'			=> 'hidden',
		'validation'	=> ''
	),
	'imgurl' => array(
		'value'			=> null,
		'order'			=> 30,
		'type'			=> 'text',
		'validation'	=> ''
	),
	'convertcharacterset' => array(
		'value'			=> '1',
		'order'			=> 40,
		'type'			=> 'toggleyn',
		'validation'	=> 'required'	
	)
);

$form['clientarea']	= array(
		'ticketsdisplay'	=> array(
				'value'			=> 1,
				'order'			=> 10,
				'type'			=> 'toggleyn',
				'validation'	=> 'required'
				),
		'ticketsnewwin'	=> array(
				'value'			=> 1,
				'order'			=> 20,
				'type'			=> 'toggleyn',
				'validation'	=> 'required'
		),
);