<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 		API Ping File
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.00 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.5.0
 *
 * @desc       This is the Verify Task which replaces the ping task for the J!WHMCS Integrator API
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Authenticate a user in Joomla
 * @version		3.1.10
 *
 * @since		3.1.00
 * @author		Steven
 */
class AuthenticateIntegratorAPI extends IntegratorAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		3.1.10
	 * 
	 * @since		3.1.00
	 * @see			IntegratorAPI :: execute()
	 */
	public function execute()
	{
		dunloader( 'helpers', 'com_integrator' );
		
		$options		= array(	'remember'	=> false,
									'return'	=> null,
									'silent'	=> true
		);
		
		
		$data	=	AuthenticateIntegratorAPI :: getCredentials();
		
		jimport( 'joomla.user.authentication');
		$authenticate =	JAuthentication::getInstance();
		$response	  = $authenticate->authenticate( $data, $options );
		
		if ( $response->status === 1 ) {
			$this->success( array( 'type' => 'array', 'result' => 'success', 'user' => $response ) );
		}
		else {
			$this->success( array( 'type' => 'binary', 'result' => 'failed' ) );
		}
	}
	
	
	/**
	 * Method to get the credentials from passed array
	 * @static
	 * @access		private
	 * @version		3.1.10
	 * 
	 * @return		array
	 * @since		3.1.00
	 */
	private static function getCredentials()
	{
		if ( version_compare( JVERSION, '1.7.0', 'ge' ) ) {
			$app		=	JFactory :: getApplication();
			$username	=   $app->input->get( 'username', null, JREQUEST_ALLOWRAW );
			$password	=   $app->input->get( 'password', null, JREQUEST_ALLOWRAW );
		}
		else {
			$post		=	JRequest :: get( 'post', JREQUEST_ALLOWRAW );
			$username	=	$post['username'];
			$password	=	$post['password'];
		}
		
		$post	=	array();
		
		foreach ( array( 'username', 'password' ) as $item ) {
			$post[$item] = stripslashes( $$item );
		}
		
		return $post;
	}
}