<?php
/**
 * @package         Integrator 3
 * @version         3.1.10
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       @copyRight@
 * @license         GNU General Public License version 2, or later
 */

defined( 'DUNAMIS' ) OR exit('No direct script access allowed');

/**
 * Dunamis Document class for Integrator 3
 * @desc		This handles document requests for the Dunamis Framework
 * @package		Dunamis
 * @subpackage	Joomla
 * @author		Go Higher Information Services, LLC
 * @link		https://www.gohigheris.com
 * @copyright	2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license		GNU General Public License version 2, or later
 */
class Com_integratorDunDocument extends JoomlaDunDocument
{
	public function __construct( $options = array() )
	{
		parent :: __construct( $options );
	}
	
	
	public function addMedia( $media = null )
	{
		if ( $media == null ) return;
	
		list( $module, $filename, $type ) = explode( "/", $media );
	
		switch ( $type ):
		case 'css':
			if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
				JHtml :: stylesheet( "{$module}/{$filename}.css", array(), true );
			}
			else {
				$uri	= new Juri();
				$path	= "media/{$module}/css/";
				JHtml :: stylesheet( "{$filename}.css", $path, array() );
			}
			break;
		case 'javascript':
		case 'js':
			if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
				JHTML :: script("{$module}/{$filename}.js", array(), true );
			}
			else {
				$uri	= new Juri();
				$path	= "media/{$module}/js/";
				JHTML :: script( "{$filename}.js", $path, array() );
			}
			break;
		endswitch;
	}
	
	
	/**
	 * Singleton
	 * @access		public
	 * @static
	 * @version		3.1.10
	 * @param		array		- $options: contains an array of arguments
	 *
	 * @return		object
	 * @since		3.1.00
	 */
	public static function getInstance( $options = array() )
	{
		static $instance = null;
	
		if (! is_object( $instance ) ) {
				
			$instance = new Com_integratorDunDocument( $options );
		}
	
		return $instance;
	}
}