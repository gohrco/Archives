<?php


class Complete extends MY_Controller
{
	
	public function __construct()
	{
		parent::__construct();
	}
	
	
	public function index()
	{
		die( "COMPLETED - ALL DONE" );
	}
	
	
	public function install()
	{
		
	}
	
	
	public function exists()
	{
		die( "YOU ALREADY HAVE INSTALLED THIS SILLY" );
	}
}