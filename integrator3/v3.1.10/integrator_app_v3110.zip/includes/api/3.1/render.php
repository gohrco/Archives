<?php
/**
 * Integrator 3
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.10 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * API interface for application
 * @version		3.1.10
 *
 * @since		3.1.00
 * @author		Steven
*/
class RenderApi extends BaseApi
{
	protected $_controller	=	'render';
	/*
	public function __construct()
	{
		parent :: __construct();
	}*/
	
	
	public function post()
	{
		$ci		= & get_instance();
		$params	=	Params :: getInstance();
		
		$ci->load->library( 'form_validation' );
		
		// *** VERIFY WE HAVE ALL THE REQUIRED VARIABLES *** //
		$ci->form_validation->set_rules( 'filename', "Filename", 'required' );
		$ci->form_validation->set_rules( 'language', "Language", 'required' );
		$ci->form_validation->set_rules( 'characterset', "Character Set", 'required' );
		$ci->form_validation->set_rules( 'session_id', "Session ID", 'required' );
		$ci->form_validation->set_rules( '_a', "Application ID", 'required|numeric' );
		$ci->form_validation->set_rules( 'signature', "Security Signature", 'required' );
		$ci->form_validation->set_rules( 'salt', "Security Salt", 'required' );
		$ci->form_validation->set_rules( '_v', "Site ID", 'numeric' );
		$ci->form_validation->set_rules( 'isssl', "Using SSL", 'numeric' );
		
		$valid = $ci->form_validation->run();
		
		if (! $valid ) {
			\Tracy\Debugger :: barDump( validation_errors(), 'Validation Errors Encountered' );
			return $this->error( lang( 'msg.error.rendervalidation' ) );
		}
		
		// Put our session and application id into place
		if(! get_application_session( get_var( '_a', 'post' ), get_var( 'session_id', 'post' ) ) ) {
			\Tracy\Debugger :: barDump( array( '_a' => get_var( '_a', 'post' ), 'sess_id' => get_var( 'session_id', 'post' ) ), 'Variables used to pull session that failed' );
			return $this->error( lang( 'msg.error.rendersessionfind' ) );
		}
		
		// Retrieve the Visual Connection
		$_a = get_var( '_a', 'post' );
		$_v = get_application_session()->params['_v'];
		
		// Should not be possible now
		if ( $_v == false ) {
			debug_error( 'msg.error.defaultvisualunset' );
			return $this->error( lang( 'msg.error.defaultvisualunset' ) );
		}
		
		// Check to see if either are disabled visually
		if ( ( is_enabled( 'visual', $_a ) === false ) || ( is_enabled( 'visual', $_v ) === false ) ) {
			debug_error( 'msg.error.cnxndisabled' );
			return $this->error( lang( 'msg.error.cnxndisabled' ) );
		}
		
		$options	= array(
						'page'			=> $ci->input->post( 'filename' ),
						'language'		=> $ci->input->post( 'language' ),
						'characterset'	=> $ci->input->post( 'characterset' ),
						'session_id'	=> get_application_session()->remote,
						'isssl'			=> ( get_var( 'isssl' ) ? secure_task( 'render', array( $_a, $_v ) ) : false ),
						'_a'			=> $_a,
						'_v'			=> $_v
		);
		
		$render = new Render_library( $options );
		_d( $options );
		
		// Be sure to catch errors
		if ( $render->_enabled === false ) {
			debug_error( 'msg.error.misconfiguration' );
			return $this->error( 'msg.error.msconfiguration' );
		}
		
		// Get the site and return the response
		$response = $render->retrieve_site();
		\Tracy\Debugger :: barDump( $response );
		if ( $response === false ) {
			_d( $render );
			return $this->error( array() );
		}
		
		$data = $response->generate_response();
		
		// Close with the response
		$this->success( $data );
	}
}