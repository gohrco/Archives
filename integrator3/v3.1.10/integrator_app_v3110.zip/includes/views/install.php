<!DOCTYPE HTML>
<html lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		
		<!-- Always force latest IE rendering engine & Chrome Frame -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		
		<title><?php echo $template['title']; ?></title>
		
		<base href="<?php echo base_url(); ?>" />
		
		<?php echo $header_includes; ?>
		
		<!-- Mobile Viewport Fix -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
		
		<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
		
		<script type="text/javascript">
			var ajaxurl		= '<?php echo base_url( 'index.php/ajax' ); ?>';
		</script>
		
	</head>
<body>

<header class="row-fluid header" style="background: url('../includes/assets/img/noise.png') repeat scroll 0 0 transparent; border-bottom: 1px solid #B8B8B8; padding: 10px 20px; width: auto; " >
	<div class="span2"> </div>
	<div class="span4">
		<div id="logo">Integrator <small>v</small>3.0</div> 
	</div>
	<!-- <div class="span4">
		<div id="license">
			<dl class="dl-horizontal">
				<dt>License</dt><dd><?php echo $licensekey; ?></dd>
				<dt>Version</dt><dd><?php echo $version; ?><span id="version_results" class="label"><?php echo lang( 'side.versionchecking' ); ?></span></dd>
			</dl>
		</div>
	</div> -->
</header>

<?php echo $template['partials']['navbar']; ?>

<div class="container-fluid maincontainer">
	
	<div class="row-fluid">
		
		<div class="span2">&nbsp;</div>
		
		<div class="span8" id="content">
			<?php if (! empty( $error ) ) : ?>
				<div class="row-fluid">
					<div class="span1">&nbsp;</div>
					<div class="alert alert-error span10">
						<button class="close" data-dismiss="alert">x</button>
						<h4 class="alert-heading"><?php echo lang( 'error.heading' ); ?></h4>
						<ul><?php echo $error; ?></ul>
					</div>
				</div>
			<?php endif; ?>
			
			<?php if (! empty( $success ) ) : ?>
				<div class="row-fluid">
					<div class="span1">&nbsp;</div>
					<div class="alert alert-success span10">
						<button class="close" data-dismiss="alert">x</button>
						<h4 class="alert-heading"><?php echo lang( 'success.heading' ); ?></h4>
						<ul><?php echo $success; ?></ul>
					</div>
				</div>
			<?php endif; ?>
			
			<?php if (! empty( $info ) ) : ?>
				<div class="row-fluid">
					<div class="span1">&nbsp;</div>
					<div class="alert alert-error span10">
						<h4 class="alert-heading"><?php echo lang( 'info.heading' ); ?></h4>
						<ul><?php echo $info; ?></ul>
					</div>
				</div>
			<?php endif; ?>
			
			<div class="row-fluid">
				<div class="span1"> </div>
				<div class="span10">
					<?php 
					$header	= ( isset( $header ) ? $header : $action );
					
					echo heading( lang( str_replace( '/', '.', $header ) ), '2', 'class="header"' );
					
					if ( lang( str_replace( '/', '.', $action ) . '.desc' ) ) : ?>
						<div class="header-text"><?php echo lang( str_replace( '/', '.', $action ) . '.desc' ); ?></div>
					<?php endif; ?>
				</div>
			</div>

			<div class="row-fluid">
				<?php echo $template['partials']['body']; ?>
			</div>
		
		</div>
		
		<div class="span2">&nbsp;</div>
		
	</div>
</div>

<footer class="footer">
	
	Copyright &copy; <?php echo anchor( "https://www.gohigheris.com", "GoHigherIS" ); ?> All Rights Reserved
	
</footer>

<?php echo $template['partials']['modals']; ?>

<?php echo $footer_javascript; ?>

<?php echo $template['partials']['debug']; ?>

</body>
</html>