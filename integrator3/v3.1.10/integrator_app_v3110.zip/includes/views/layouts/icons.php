<div class="row-fluid">
	<div class="span1"> </div>
	<div class="span11">
		<?php echo heading( lang( str_replace( '/', '.', $action ) ), '3', 'class="header"' ); ?>
		<?php if ( lang( str_replace( '/', '.', $action ) . '.desc' ) ) echo '<div class="header-text">' . lang( str_replace( '/', '.', $action ) . '.desc' ) . '</div>' ?>
	</div>
</div>

<div class="row-fluid">
	<div class="span2"> </div>
	<div id="cpanel" class="span10">
	
		<?php foreach ( $icons as $icon ): ?>
		
		<?php echo icon( $icon->path, $icon->image, $icon->options ); ?>
		
		<?php endforeach; ?>
	
	</div>
</div>