<?php
/**
 * Integrator 3
 * Integrator 3 - Login Module File
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.10 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This file is the login controller
 *
 */

/**
 * Login Module for Integrator 3
 * @version		3.1.10
 *
 * @author		Steven
 * @since		3.1.00
 */
class IntegratorLoginDunModule extends WhmcsDunModule
{
	/**
	 * Provide means to check for file integrity
	 * @access		protected
	 * @var			string
	 * @since		3.1.00
	 */
	protected $checkstring	=	"932039411";
	
	private $_creds		=	array(	'username' => null, 'email' => null );
	private $_error		=	null;
	
	
	/**
	 * Authenticate credentials against Joomla
	 * @access		public
	 * @version		3.1.10 ( $id$ )
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function authenticate()
	{
		// We are actually providing our own login routine... ?
		$input		=	dunloader( 'input',		true );
		$api		=	dunloader( 'api',		'integrator' );
		$wapi		=	dunloader( 'whmcsapi',	'integrator' );
		$config		=	dunloader( 'config',	'integrator' );
		$username	=	$input->getVar( 'username', false );
		
		// If we are disabled don't run ;-)
		if (! ensure_active( 'login' ) ) {
			return false;
		}
		
		// If we are using an email address then send back
		if ( is_email( $username ) ) {
			$this->_creds['email']		= $username;
			return;
		}
		
		$this->_creds['username']	=	$username;
		
		$credentials	=	array(
				'username'	=>	$input->getVar( 'username', false ),
				'password'	=>	$input->getVar( 'password', false )
				);
		
		$result	=	$api->post_authenticate( $credentials );
		
		if ( $api->hasErrors() ) {
			$this->setError( $api->getError() );
			return false;
		}
		
		// No email sent back?
		if (! isset( $result->user ) || ! isset( $result->user->email ) ) {
			return false;
		}
		
		// Set our local copies for the jump
		$this->_creds['username']	=	$username;
		$this->_creds['email']		=	$result->user->email;
		
		// ==============================================================
		//	User has been authenticated against Integrator 3 somewhere!
		// 
		//	Determine if we have a local user or not
		// ==============================================================
		
		if (! $user	= get_user_from_db( $this->_creds['email'], 'client', 'email' ) ) {
			$url		=	$config->get( 'integratorurl', null );
			$isssl		=	$config->get( 'loginhandlessl', '2' );
			$cnxnid		=	$config->get( 'cnxnid' );
			
			if ( $isssl == '2' ) {
				$isssl		=	is_ssl();
			}
			
			$uri		=	DunUri :: getInstance( $url, true );
			$uri->setScheme( 'http' . ( $isssl ? 's' : '' ) );
			
			$url		=	rtrim( $uri->toString(), '/' ) . "/index.php/login/index/{$cnxnid}/";
			
			// Create fields
			$fields	=	$credentials;
			$fields['_c']	=	$cnxnid;
			
			if ( $input->get( 'rememberme', null ) == 'on' ) {
				$fields['rememberme']	=	'on';
			}
			
			form_redirect( $url, $fields );
		}
		
		// ==============================================================
		//	If we are here we have a local user so cleanup input and go
		// ==============================================================
		
		// Build our new data
		$data					=	$_POST;
		$data['username']		=	$result->user->email;
		
		global $whmcs;
		
		// Set the user data into the input handler for WHMCS
		if ( version_compare( DUN_ENV_VERSION, '6.0', 'ge' ) ) {
			if ( is_a( $whmcs, 'WHMCS\Application' ) ) {
				$whmcs->replace_input( $data );
			}
		}
		else if ( version_compare( DUN_ENV_VERSION, '5.3', 'ge' ) ) {
			// Find work around if WHMCS_Init doesn't exist...?
			if ( is_a( $whmcs, 'WHMCS_Application' ) ) {
				$whmcs->replace_input( $data );
			}
		}
		else if ( version_compare( DUN_ENV_VERSION, '5.2', 'ge' ) ) {
			// Find work around if WHMCS_Init doesn't exist...?
			if ( is_a( $whmcs, 'WHMCS_Init' ) ) {
				$whmcs->replace_input( $data );
			}
		}
		else {
			// HELP!
			
		}
		
		return true;
	}
	
	
	/**
	 * Method to complete the login to Joomla
	 * @access		public
	 * @version		3.1.10 ( $id$ )
	 * 
	 * @since		3.1.00
	 */
	public function complete( $vars = array() )
	{
		// If we are disabled don't run ;-)
		if (! ensure_active( 'login' ) ) {
			return false;
		}
		
		// Check to see if we arrived here by clicking on the Login as Client
		if ( from_adminarea() || from_oauth() ) {
			return false;
		}
		
		if ( get_filename() == 'cart' ) {
			return false;
		}
		
		$config		=	dunloader( 'config',	'integrator' );
		$input		=	dunloader( 'input', true );
		$redirect	=	false;
		
		// In WHMCS 5.1 we must not be going through the authentication routine so we must store the email somehow
		if ( empty( $this->_creds['email'] ) && empty( $this->_creds['username'] ) && $input->getVar( 'username', false ) ) {
			$email = $input->getVar( 'username' );
			$this->_creds['email']	=	$email;
		}
		
		
		$url		=	$config->get( 'integratorurl', null );
		$isssl		=	$config->get( 'loginhandlessl', '2' );
		
		if ( $isssl == '2' ) {
			$isssl		=	is_ssl();
		}
		
		$cnxnid		=	$config->get( 'cnxnid' );
		$session	=	encode_session( $vars['userid'], session_id() );
		
		// Create fields
		$fields		=	array(
			'_c'		=>	$cnxnid,
			'session'	=>	$session
		);
		
		$uri		=	DunUri :: getInstance( $url, true );
		$uri->setScheme( 'http' . ( $isssl ? 's' : '' ) );
		
		// We've been here before...
		if ( $input->getVar( 'integrator', false ) ) {
			$url		=	rtrim( $uri->toString(), '/' ) . "/index.php/login/succeed";
		}
		// First time logging in
		else {
			
			$url		=	rtrim( $uri->toString(), '/' ) . "/index.php/login/index/{$cnxnid}/";
			
			$fields['username']	=	$input->getVar( 'username', null );
			$fields['password']	=	$input->getVar( 'password', null );
			
			if ( $input->get( 'rememberme', null ) == 'on' ) {
				$fields['rememberme']	=	'on';
			}
		}
		
		form_redirect( $url, $fields );
		exit;
	}
	
	
	/**
	 * Initializes the module
	 * @access		public
	 * @version		3.1.10
	 *
	 * @since		3.1.00
	 */
	public function initialise() { }
	
	
	/**
	 * Method for checking if we are to redirect login requests off WHMCS
	 * @access		public
	 * @version		3.1.10
	 *
	 * @return		void
	 * @since		3.1.04
	 */
	public function loginredirectcheck()
	{
		$config	=	dunloader( 'config', 'integrator' );
		$redir	=	$config->get( 'loginmethod' );
		
		// Use WHMCS
		if ( $redir == '1' ) return;
		
		// Catch Loops
		if ( $config->get( 'loginmethod_cnxn_id' ) == $config->get( 'cnxnid' ) ) return;
		
		// Use a custom URL
		if ( $redir == '2' ) {
			$redirect	=	DunUri :: getInstance( $config->get( 'loginmethod_customurl' ) )->toString();
		}
		// Route to our destination
		else {
			$api		=	dunloader( 'api', 'integrator' );
			$redirect	=   $api->get_route(
					array(	'cnxn_id'	=>	$config->get( 'loginmethod_cnxn_id' ),
							'page'		=>	$config->get( 'loginmethod_page' ),
							'vars'		=>	'',
							'lang'		=>	get_template_var( 'language', 'english' ) 
			) );
		}
		
		header( 'Expires: Sat, 26 Jul 1997 05:00:00 GMT' );
		header( 'Last-Modified: ' . gmdate( 'D, d M Y H:i:s' ) . ' GMT' );
		header( 'Cache-Control: no-store, no-cache, must-revalidate' );
		header( 'Cache-Control: post-check=0, pre-check=0', false );
		header( 'Pragma: no-cache' );
		header( 'Location: ' . $redirect );
		exit;
	}
	
	
	/**
	 * Method to log the user out of WHMCS
	 * @access		public
	 * @version		3.1.10 ( $Id$ )
	 * @param		array		- $vars: what we are passed if anything
	 *
	 * @since		3.1.00
	 */
	public function logout( $vars = array() )
	{
		// If we are disabled don't run ;-)
		if (! ensure_active( 'login' ) ) {
			return false;
		}
		
		$input		=	dunloader( 'input',		true );
		$config		=	dunloader( 'config',	'integrator' );
		
		$url		=	$config->get( 'integratorurl', null );
		$isssl		=	$config->get( 'loginhandlessl', '2' );
		$cnxnid		=	$config->get( 'cnxnid' );
		$sid		=	base64_encode( session_id() );
		
		if ( $isssl == '2' ) {
			$isssl		=	is_ssl();
		}
		
		$uri		=	DunUri :: getInstance( $url, true );
		$uri->setScheme( 'http' . ( $isssl ? 's' : '' ) );
		
		// If we are coming from I3 for logging out...
		if ( $input->getVar( 'integrator', null, 'request', 'string' ) == 'true' ) {
			unset( $_SESSION["uid"] );
			unset( $_SESSION["cid"] );
			unset( $_SESSION["upw"] );
			$url	=	rtrim( $uri->toString(), '/' ) . "/index.php/logout/complete/{$cnxnid}/";
		}
		// If we have already come from I3 for logging out and returning for landing...
		else if ( $input->getVar( 'integrator', null, 'request', 'string' ) == 'false' ) {
			
			// Handling Logout URL setting
			$url	=	$config->get( 'logouturl', null );
			if (! $url ) {
				return;
			}
			
		}
		// If we have never been here before for logging out...
		else {
			$url	=	rtrim( $uri->toString(), '/' ) . "/index.php/logout/index/{$cnxnid}/{$sid}?_c={$cnxnid}";
			unset( $_SESSION["uid"] );
			unset( $_SESSION["cid"] );
			unset( $_SESSION["upw"] );
		}
		
		header( 'Expires: Sat, 26 Jul 1997 05:00:00 GMT' );
		header( 'Last-Modified: ' . gmdate( 'D, d M Y H:i:s' ) . ' GMT' );
		header( 'Cache-Control: no-store, no-cache, must-revalidate' );
		header( 'Cache-Control: post-check=0, pre-check=0', false );
		header( 'Pragma: no-cache' );
		header( 'Location: ' . $url );
		exit;
	}
	
	
	
	
	/**
	 * Method to redirect after logout loopback
	 * @access		public
	 * @version		3.1.10 ( $id$ )
	 * 
	 * @since		3.1.00
	 */
	public function logoutredirect()
	{
		// If we are disabled don't run ;-)
		if (! ensure_active( 'login' ) ) {
			return false;
		}
		
		$input		=	dunloader( 'input', true );
		$config		=	dunloader( 'config', 'jwhmcs' );
		
		// Ensure this is our loopback
		if (! $input->getVar( 'complete', false ) ) {
			return false;
		}
		
		// See if we have already logged out at Joomla and sent a redirect
		if ( ( $jwhmcs = $input->getVar( 'jwhmcs', false ) ) ) {
			$redirect	=	base64_decode( $jwhmcs );
		}
		else {
			
			$url	=	$config->get( 'logouturl' );
			
			// Ensure we actually have a URL to redirect to
			if (! $url || $url == 'http://' || $url == 'https://' ) {
				return false;
			}
			
			$uri	=	DunUri :: getInstance( $url, true );
			
			if ( DunUri :: isInternal( $url ) ) {
				$uri	=	DunUri :: getInstance( base64_decode( $this->_getReturnurl( 'logout' ) ), true );
				$uri->setPath( $config->get( 'logouturl' ) );
			}
			
			$redirect	=	$uri->toString();
		}
		
		header( 'Expires: Sat, 26 Jul 1997 05:00:00 GMT' );
		header( 'Last-Modified: ' . gmdate( 'D, d M Y H:i:s' ) . ' GMT' );
		header( 'Cache-Control: no-store, no-cache, must-revalidate' );
		header( 'Cache-Control: post-check=0, pre-check=0', false );
		header( 'Pragma: no-cache' );
		header( 'Location: ' . $redirect );
		exit;
	}
	
	
	/**
	 * Method for setting the redirection on error logging in
	 * @access		public
	 * @version		3.1.10 ( $id$ )
	 *
	 * @return		void
	 * @since		3.1.00
	 */
	public function redirectOnError()
	{
		$url	=	$_SESSION['loginurlredirect'];
		$uri	=	DunUri :: getInstance( $url );
		$uri->setVar( 'incorrect', 'true' );
		$_SESSION['loginurlredirect']	=	$uri->toString();
	}
	
	
	/**
	 * Method to verify what we entered is an email and not a username
	 * @access		public
	 * @version		3.1.10 ( $id$ )
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function verify()
	{
		$input		=	dunloader( 'input', true );
		$username	=	$input->getVar( 'username', false );
		
		if ( is_email( $username ) ) {
			$this->_creds['email'] = $username;
			return true;
		}
		
		return false;
	}
	
	
	/**
	 * Method to find a username given only the email in the credential array
	 * @access		private
	 * @version		3.1.10 ( $id$ )
	 *
	 * @return		string
	 * @since		3.1.00
	 */
	private function _findUsername()
	{
		$api	=	dunloader( 'api', 'jwhmcs' );
		$user	=	$api->finduser( $this->_creds['email'] ) ;
		
		if ( $api->hasErrors() ) {
			return false;
		}
		
		return $user->username;
	}
	
	
	/**
	 * Method for generating the entire login URL to go over to Joomla with
	 * @access		private
	 * @version		3.1.10 ( $id$ )
	 *
	 * @return		string
	 * @since		3.1.00
	 */
	private function _generateLoginurl( $task = 'login' )
	{
		$api	=	dunloader( 'api', 'jwhmcs' );
		$wapi	=	dunloader( 'whmcsapi', 'jwhmcs' );
		$input	=	dunloader( 'input', true );
		
		if ( $this->_creds['username'] == null ) {
			
			// Find the username
			if (! ( $username = $this->_findUsername() ) ) {
				// No username found so lets see if we can create them
				$wuser		=	$wapi->finduserdetails( $this->_creds['email'], 'email' );
				$iscontact	=	( isset( $wuser->subaccount ) && $wuser->subaccount ? true : false ); 
				
				// Build the user
				$user		=	convert_user( $wuser, array(), true, 'to', ( $iscontact ? 'contact' : 'client' ) );
				
				$user['password']	=	$input->getVar( 'password', false );
				$user['password2']	=	$input->getVar( 'password', false );
				
				if (! ( $result = $api->createuser( $user ) ) ) {
					return false;
				}
				
				if (! $iscontact ) {
					store_username( $wuser->userid, $result->username );
				}
				
				$username = $result->username;	
			}
			
			$this->_creds['username']	=	$username;
		}
		
		// Lets build our return URL
		$returnurl	=	$this->_getReturnurl( $task );
		
		// Gather necessary parts
		$config		=	dunloader( 'config', 'jwhmcs' );
		$token		=	$config->get( 'apitoken', null );
		$jurl		=	$config->get( 'joomlaurl', null );
		
		// Establish the timestamp and build the signature
		$timestamp	=	time();
		$signature	=	base64_encode( hash_hmac( 'sha256', $this->_creds['email'] . $timestamp . $token, $token, true ) );
		$checksign	=	base64_encode( hash_hmac( 'sha256', $this->_creds['username'] . $timestamp . $token, $token, true ) );
		
		$juri	=	DunUri :: getInstance( $jurl, true );
		$juri->setVar( 'timestamp',	$timestamp );
		$juri->setVar( 'signature',	$signature );
		$juri->setVar( 'checksign',	$checksign );
		$juri->setVar( 'username',	$this->_creds['username'] );
		$juri->setVar( 'task',		'autoauth' );
		$juri->setVar( 'returnurl',	$returnurl );
		
		if ( $task == 'useraddlogin' ) {
			$juri->setVar( 'subtask', 'adduser' );
			$juri->setVar( 'password2', $input->getVar( 'password', null ) );
		}
		
		return $juri->toString();
	}
	
	
	/**
	 * Method for building the proper return URL for login purposes 
	 * @access		private
	 * @version		3.1.10 ( $id$ )
	 * @param		string		- $task: indicates we want the login URL
	 * 
	 * @return		string
	 * @since		3.1.00
	 */
	private function _getReturnurl( $task = 'login' )
	{
		$config	=	dunloader( 'config', true );
		$jcfg	=	dunloader( 'config', 'jwhmcs' );
		$use	=	false;
		
		// Check ssl first
		if ( is_ssl() ) {
			$use	=	( $config->get( 'SystemSSLURL' ) ? true : false ); 
		}
		
		$sysurl		=	( $use ? $config->get( 'SystemSSLURL' ) : $config->get( 'SystemURL' ) );
		$gotouri	=	DunUri :: getInstance( $sysurl, true );
		
		switch ( $task ) {
			case 'login':
				
				// We are going to assume that the GOTOURL is global and available for WHMCS 5.2
				global $gotourl;
				
				// Instances without gotourl we need someplace to go
				if (! $gotourl && $_SESSION['loginurlredirect'] ) {
					$gotourl = $_SESSION['loginurlredirect'];
				}
				
				$rediruri	=	DunUri :: getInstance( $gotourl, true );
				$rediruri->delVar( 'incorrect' );
				
				foreach ( $rediruri->getQuery( true ) as $k => $v ) {
					$gotouri->setVar( $k, $v );
				}
				
				// ---- BEGIN JWHMCS-8 / JWHMCS-14
				//		Log in missing subfolders when landing
				$path		=	null;
				$pathinfo	=	(object) @pathinfo( $rediruri->getPath() );
				
				if ( $pathinfo->dirname == '.' ) {
					$path	=	rtrim( $gotouri->getPath(), '/' ) . '/' . $rediruri->getPath();
				}
				else {
					$path	=	$rediruri->getPath();
				}
				
				$gotouri->setPath( $path );
				// ---- END JWHMCS-8 / JWHMCS-14
				
				break;
				
			case 'logout' :
				
				$gotouri->setPath( rtrim( $gotouri->getPath(), '/' ) . '/logout.php' );
				$gotouri->setVar( 'complete', 'true' );
				
				break;

			// Because WHMCS logs in at user add, we need to return to WHMCS with an autoauth URL to log in with
			case 'useraddlogin' :
				
				global $gotourl;
				
				if ( isset( $_SERVER['HTTP_REFERER'] ) && $_SERVER['HTTP_REFERER'] ) {
					$gotourl	=	$_SERVER['HTTP_REFERER'];
				}
				else {
					$gotourl	=	rtrim( $gotouri->toString( array( 'path' ) ), '/' ) . '/clientarea.php';
				}
				
				$gmt		=	new DateTime( null, new DateTimeZone('GMT') );
				$token		=	$jcfg->get( 'apitoken' );
				$email		=	$this->_creds['email'];
				$timestamp	=	$gmt->format("U");
				$hash		=	sha1( $email . $timestamp . $token );
				$return		=	$this->_getReturnurl();
				
				// Create our own hash for logging in
				$gotouri	=	DunUri :: getInstance( $sysurl, true );
				$gotouri->setPath( rtrim( $gotouri->getPath(), '/' ) . '/dologin.php' );
				$gotouri->setVar( 'email', $email );
				$gotouri->setVar( 'timestamp', $timestamp );
				$gotouri->setVar( 'hash', $hash );
				$gotouri->setVar( 'goto', urlencode( 'clientarea.php' ) );
				$gotouri->setVar( 'jwhmcs', $return );
				
				break;
		}
		
		return base64_encode( $gotouri->toString() );
	}
	
	
	/**
	 * Method for determining if a user exists in WHMCS (cant use local API)
	 * @access		private
	 * @version		3.1.10 ( $id$ )
	 * @param		string		- $email: the address to check for
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	private function _user_exists( $email )
	{
		$db	=	dunloader( 'database', true );
		
		// Find clients first
		$query	=	"SELECT 1 FROM tblclients WHERE `email` = " . $db->Quote( $email );
		$db->setQuery( $query );
		
		if ( $db->loadResult() ) {
			return true;
		}
		
		// Check for contacts next
		$query	=	"SELECT 1 FROM tblcontacts WHERE `subaccount` = '1' AND `email` = " . $db->Quote( $email );
		$db->setQuery( $query );
		
		if ( $db->loadResult() ) {
			return true;
		}
		
		return false;
	}
	
	
	/**
	 * Getter / Setter / Haser function
	 * @desc		Use by calling getUrl() or setUrl('value') to get/set $this->_url
	 * @access		public
	 * @version		3.1.10 ( $id$ )
	 * @param		string		- $name: the method invoked
	 * @param		mixed		- $arguments: any arguments passed along
	 * 									For setter we can do setProperty( $name, $value, $replaceval ) - third to indicate replace an array value
	 *
	 * @return		mixed
	 * @since		3.1.00
	 */
	public function __call( $name, $arguments )
	{
		if ( strpos( $name, 'get' ) !== false && strpos( $name, 'get' ) == 0 ) {
			$var	=	'_' . strtolower( preg_replace( "#^get#", '', $name ) );
			return $this->$var;
		}
		
		// Set the requested property to the value (arrays get added to)
		if ( strpos( $name, 'set' ) !== false && strpos( $name, 'set' ) == 0 ) {
			$var		=	'_' . strtolower( preg_replace( "#^set#", '', $name ) );
			$value		=	array_shift( $arguments );
			$replace	=	false;
			
			// If we have any left see if the next argument is a boolean
			if (! empty( $arguments ) ) {
				$replace	=	array_shift( $arguments );
			}
			
			// Test the original
			$getter		=	'get' . ucfirst( $var );
			$original	=	$this->$getter();
			
			if ( is_array( $original ) ) {
				
				if ( $replace ) {
					$original	=	array();
				}
				
				$original[]	=	$value;
				$this->$var	=	$original;
			}
			else {
				$this->$var	=	$value;
			}
			
			return $this;
		}
		
		// Check to see if the object has the requested property
		if ( strpos( $name, 'has' ) !== false && strpos( $name, 'has' ) == 0 ) {
			$var	=	'_' . strtolower( preg_replace( "#^has#", '', $name ) );
			$value	=	(bool) ( isset( $this->$var ) && ! empty( $this->$var ) );
			return $value;
		}
	}
}