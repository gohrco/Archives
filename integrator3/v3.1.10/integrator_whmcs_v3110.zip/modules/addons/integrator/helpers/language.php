<?php
/**
 * Integrator 3
 * WHMCS - Configuration File
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.10 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.1 (0.2)
 * 
 * @desc       This file is a helper file for common language tasks needed by the Integrator
 *  
 */

/*-- Security Protocols --*/
defined( 'WHMCS' ) or die( 'Restricted access' );
/*-- Security Protocols --*/


/**
 * Function for recursively converting an array using iconv
 * @version		3.1.10
 * @param		mixed		- $data:  can be string or an array
 * @param		string		- $from:  the character set to convert from
 * @param		string		- $to:    the character set to convert to
 * @param		bool		- $trans: true indicates we should try to transliterate unknown characters, false false silently
 * 
 * @return		mixed array or string
 * @since		3.0.1 (0.2)
 */
if (! function_exists( 'my_iconv' ) ) {
function my_iconv( $data, $from, $to, $trans = true ) {
	
	// Ensure iconv even exists
	if (! function_exists( 'iconv' ) ) return $data;
	
	// Ensure we are correctly sending data
	$translit	= $trans === true ? "//TRANSLIT" : "";
	$from		= strtoupper( $from );
	$to			= strtoupper( $to );
	
	// Ensure from and to are different
	if ( $from == $to ) return $data;
	
	// If we received a string send it back converted
	if (! is_array( $data ) ) {
		return iconv( "{$from}", "{$to}{$translit}", $data );
	}
	
	// Otherwise the data must be an array so cycle through it
	foreach( $data as $key => $value ) {
		$data[$key] = my_iconv( $value, $from, $to, $trans );
	}
	
	return $data;
}
}