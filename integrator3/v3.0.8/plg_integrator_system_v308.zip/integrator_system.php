<?php
/**
 * Integrator
 * System - Integrator Plugin
 * 
 * @package    Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.8 ( $Id: integrator_system.php 176 2013-01-07 21:41:24Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the file executed by the System - Integrator plugin for handling system level calls including debug output and redirection
 * 
 */


/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.plugin.plugin');
jimport( 'joomla.application.component.helper' );

if ( $path = JApplicationHelper :: getPath( 'class', 'com_integrator' ) ) {
	require_once( $path );
}
/*-- File Inclusions --*/


/**
 * System - Integrator Plugin
 * @version		3.0.8
 * 
 * @since		3.0.0
 * @author		Steven
 */
class plgSystemIntegrator_system extends JPlugin
{
	/**
	 * Local enable
	 * @access		public
	 * @since		3.0.0
	 * @var			bool
	 */
	public $enabled	= true;
	
	/**
	 * Constructor
	 *
	 * @param object $subject The object to observe
	 * @param 	array  $config  An array that holds the plugin configuration
	 * @since 1.5
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		$this->params->merge( JComponentHelper::getParams( "com_integrator" ) );
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$this->loadLanguage();
		}
		
		// Catch in case helper missing
		if (! class_exists( 'IntegratorHelper' ) ) $this->enabled = false;
	}
	
	
	/**
	 * Joomla onAfterInitialise system level event
	 * @access		public
	 * @version		3.0.8
	 * @version		3.0.8		- Jan 2013: Changes to the email address are reverted due to session - added session updating
	 * 
	 * @since		3.0.2
	 */
	public function onAfterInitialise()
	{
		// Initialize variables
		$app		= & JFactory::getApplication();
		$vars		=   array(	'option'	=> IntegratorHelper :: get ( 'option', null, 'cmd' ),
								'view'		=> IntegratorHelper :: get ( 'view', null, 'cmd' )
		);
		$newlink	=   null;
		
		// Test for password reset
		if ( $vars['option'] == 'com_integrator' && $vars['view'] == 'pwreset' )							// I3 Password Reset Link
		{
			if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
				$newlink = JRoute :: _( 'index.php?option=com_users&view=reset' );
			}
			else {
				$newlink = JRoute :: _( 'index.php?option=com_user&view=reset' );
			}
		} // End test for password reset
		
		if ( $newlink != null ) {
			$app->redirect( $newlink );
		}
		
		if ( defined( 'INTEGRATOR_API' ) ) return;
		
		$session  =& JFactory::getSession();
		$instance =& $session->get('user');
		
		if ( is_a( $instance, 'JUser' ) && ! $instance->guest ) {
			$dbuser		= new Juser( $instance->get( 'id' ) );
			$changes	= false;
			
			foreach( array( 'email', 'username', 'name' ) as $item ) {
				if ( $dbuser->get( $item ) == $instance->get( $item ) ) continue;
				$instance->set( $item, $dbuser->get( $item ) );
				$changes	= true;
			}
			
			if ( $changes ) {
				$instance->set( 'email', $dbuser->get( 'email' ) );
				$session->set( 'user', $instance );
			}
		}
		
		
		
	}
	
	
	/**
	 * Joomla onAfterRender system level event
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @since		3.0.0
	 */
	public function onAfterRender()
	{
		// Ensure we don't throw errors if Integrator missing
		if (! $this->enabled ) return;
		
		// Process redirects first
		$this->redirectRequests();
		
		// Render the debug output if called for
		$this->debugOutput();
		
		return;
	}
	
	
	/**
	 * Method to grab the debug output and append it to the body
	 * @access		private
	 * @version		3.0.8
	 * 
	 * @since		3.0.0
	 */
	private function debugOutput()
	{
		// Grab local copy
		$params	= $this->params;
		
		// Grab the debug data (clearing it if no debug active)
		$debug	= & IntDebug :: getInstance();
		$data	=   $debug->get_output();
		
		// Bail if no debugging is on
		if ( $params->get( 'IntegratorDebug' ) != 'Yes' && ! JDEBUG ) return;
		
		// Bail if we are in the API!
		if ( defined( 'INTEGRATOR_API' ) ) return;
		
		// Bail if nothing to do
		if ( empty( $data ) ) return;
		
		$response	= '<div style="width: 100%; clear: both; position: relative; color: #000; ">'
					. '<fieldset style="padding: 5px 17px 17px; background-color: #fff; border: 1px solid #CCCCCC; ">'
					. '<legend style="color: #146295; font-size: 1.15em; font-weight: bold; margin: 0; padding: 0; ">'
					. 'Integrator Debug Information'
					. '</legend>'
					. '<ul class="list-style: none outside none; margin: 0; padding: 0; ">';
		$closing	= '</ul></fieldset></div>';
		
		foreach ( $data as $line ) {
			$response  .= '<li style="list-style: none outside none; border-bottom: 1px solid #666666; padding: 5px; ">'
						. '<div style="float: left; font-weight: bold; ' . ( $line['type'] == 'error' ? 'color: DarkRed; ' : '' ) . '">[' . $line['type'] . '] ' . $line['message'] . '</div>'
						. '<div style="float: right; font-size: smaller; ' . ( $line['type'] == 'error' ? 'color: DarkRed; ' : '' ) . '">' . $line['filename'] . '  @ line ' . $line['line'] . '</div>'
						. '<div style="clear: both; line-height: 1px; ">&nbsp;</div>'
						. '</li>';
		}
		
		JResponse :: appendBody( $response .= $closing );
	}
	
	
	/**
	 * Method to redirect requests
	 * @access		private
	 * @version		3.0.8
	 * 
	 * @since		3.0.0
	 */
	private function redirectRequests()
	{
		$app	= & JFactory::getApplication();
		$user 	= & JFactory::getUser();
		$api 	= & IntApi::getInstance();
		$params	=   $this->params;
		
		// Don't redirect any admin requests
		if ( $app->isAdmin() ) return;
		
		// Don't run if product or user integration disabled
		if ( $params->get( 'UserEnabled' ) != 'Yes' || $params->get( 'Enabled' ) != 'Yes' ) return;
		
		// Initialize variables
		$vars		=   array(	'option'	=> IntegratorHelper :: get ( 'option', null, 'cmd' ),
								'view'		=> IntegratorHelper :: get ( 'view', null, 'cmd' ),
								'task'		=> IntegratorHelper :: get ( 'task', null, 'cmd' ),
								'layout'	=> IntegratorHelper :: get ( 'layout', null, 'cmd' )
						);
		$newlink	=   null;
		
		// Test for registration page
		if ( ( $vars['option'] == 'com_users' && $vars['view'] == 'registration' )	// Joomla 1.6+
		  || ( $vars['option'] == 'com_users' && $vars['task'] == 'registration' )	//   - also J1.6+
		  || ( $vars['option'] == 'com_user' && $vars['task'] == 'register' ) 		// Joomla 1.5
		  || ( $vars['option'] == 'com_user' && $vars['view'] == 'register' ) )		//   - also Joomla 1.5
		{
			
			// Be sure we are a guest
			if ( $user->get( 'guest' ) )
			{
				// Integrated Page
				if ( $params->get( 'register_override' ) == '1' ) {
					$a		= $params->get( 'register_cnxn_id', false );
					$page	= $params->get( 'register_page', false );
					
					// In case we haven't selected an a or page
					if ( $a !== false && $page !== false ) {
						$newlink = $api->get_route( array( 'cnxn_id' => $a, 'page' => $page ) );
					}
					
				}
				// Custom URL
				else if ( $params->get( 'register_override' ) == '2' ) {
					$newlink = $params->get( 'register_customurl' );
				}
			} // End test for guest
		} // End test for registration page
		
		// Test for editing a profile
		if ( ( $vars['option'] == 'com_users' && $vars['view'] == 'profile' && $vars['layout'] == 'edit' )		// Joomla 1.6+
		  || ( $vars['option'] == 'com_user' && $vars['view'] == 'user' && $vars['layout'] == 'edit' ) )		// Joomla 1.5
		{
			if (! $user->get('guest') ):
				if ( ( $params->get( 'RegMethod' ) == 1 ) || ( $params->get( 'RegMethod' ) == 3 ) ) {
					$uri = new JURI( $params->get( 'ApiUrl' ) );
					$uri->setPath( $uri->getPath() . '/clientarea.php' );
					$uri->setVar( 'action', 'details' );
					$newlink = $uri->toString();
				}
			endif;
			
		} // End test for editing a profile
		
		// Test for password reset
		if ( ( $vars['option'] == 'com_integrator' && $vars['view'] == 'pwreset' )							// I3 Password Reset Link
		  || ( $vars['option'] == 'com_users' && $vars['view'] == 'reset' && $vars['layout'] == 'edit' )	// Joomla 1.6+
		  || ( $vars['option'] == 'com_user' && $vars['view'] == 'reset' ) )								// Joomla 1.5
		{
			// load J!WHMCS Edit page
			if ( $user->get('guest') ):
				if ( ( ( $params->get( 'RegMethod' )== 1 ) && ( $params->get( 'PwresetRedirect' ) != 1 ) ) || ( $params->get( 'PwresetRedirect' ) == 2 ) ) {
					$uri = new JURI( $params->get( 'ApiUrl' ) );
					$uri->setPath( $uri->getPath() . '/pwreset.php' );
					$newlink = $uri->toString();
				}
				elseif ( ( $params->get( 'PwresetRedirect' ) == 1 ) && ( $params->get( 'PwresetMenu' ) ) && ( $params->get( 'PwresetMenu' ) != $Itemid ) ) {
					$newlink = JRoute::_( "index.php?Itemid={$params->get( 'PwresetMenu' )}", false );
					$mainframe->redirect( $newlink );
				}
			endif;
		} // End test for password reset
		
		// Test for username request
		if ( ( $vars['option'] == 'com_users' && $vars['view'] == 'remind' && $vars['layout'] == 'edit' )	// Joomla 1.6+
		  || ( $vars['option'] == 'com_user' && $vars['view'] == 'remind' ) ) 								// Joomla 1.5
		{
			
			
			
		} // End test for username request
		
		if ( $newlink != null ) {
			$app->redirect( $newlink );
		}
	}
}