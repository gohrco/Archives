<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.8 ( $Id: api.php 74 2012-10-01 15:55:25Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file contains the api model which allows the api interface to interact with the data
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
jimport( 'joomla.application.component.model' );	// Import model
/*-- Localscope import --*/

/**
 * API model class object
 * @version		3.0.8
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntegratorModelApi extends JModel
{
	/**
	 * Constructor
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Gets an email from a username
	 * @access		public
	 * @version		3.0.8
	 * @param		string		- $username: the username to search for
	 * 
	 * @return		string containing username or false on no result
	 * @since		3.0.0
	 */
	public function get_email( $username )
	{
		$db 	= & JFactory::getDBO();
		$query	=   "SELECT u.email FROM `#__users` u WHERE u.username = " . $db->Quote( $username );
		$db->setQuery( $query );
		return $db->loadResult();
	}
	
	
	/**
	 * Method to retrieve information about Joomla Integrator pieces
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @return		array
	 * @since		3.0.1 (0.1)
	 */
	public function get_info()
	{
		$db		= & JFactory :: getDbo();
		$result	=
		$data	=   array();
		
		$query	= array();
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$query[]	=   "SELECT * FROM #__extensions WHERE `name` LIKE '%integrator%'";
		}
		else {
			$query[]	=	"SELECT *, 'component' as `type` FROM #__components WHERE `option` LIKE '%com_integrator%'";
			$query[]	=	"SELECT *, 'module' as `type`, `module` as 'element' FROM #__modules WHERE `module` LIKE '%mod_intlogin%'";
			$query[]	=	"SELECT *, 'plugin' as `type` FROM #__plugins WHERE `element` LIKE '%integrator_%'";
		}
		
		foreach ( $query as $q ) {
			$db->setQuery( $q );
			$result[]	= $db->loadObjectList();
		}
		
		foreach ( $result as $res ) {
			if (! is_array( $res ) ) continue;
			foreach ( $res as $row )
			{
				$xml = & JFactory::getXMLParser('Simple');
				
				switch ( $row->type ):
				case 'component':
					$possible	= array();
					$files		= JFolder::files( JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_integrator' . DS, '\.xml$', false, false );
					if(! empty( $files ) ) foreach ( $files as $filename ) {
						if ( strpos( $filename, 'com_integrator' ) === false ) continue;
						$possible[]	= $filename;
					}
					
					rsort( $possible );
					$filename	= JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_integrator' . DS . array_shift( $possible );
					$name		= 'cnxns|joomla|component';
				break;
				case 'module':
					// Switch based on element (in case we add other modules down the road)
					switch( $row->element ):
					case 'mod_intlogin':
						$filename	= JPATH_SITE . DS . 'modules' . DS . 'mod_intlogin' . DS . 'mod_intlogin.xml';
						$name		= 'cnxns|joomla|intlogin';
					break;
					endswitch;
				break;
				case 'plugin':
					$path		= version_compare( JVERSION, '1.6.0', 'ge' ) ? $row->element . DS : '';
					$filename	= JPATH_PLUGINS . DS . $row->folder . DS . $path . $row->element . '.xml';
					$name		= 'cnxns|joomla|' . $row->folder . 'plugin';
				break;
				endswitch;
				
				if (! $xml->loadFile( $filename ) ) {
					$data[$name] = null;
					continue;
				}
				
				if ( ( $xml->document->name() != 'install' ) && ( $xml->document->name() != 'extension' ) ) {
					unset($xml);
					$data[$name] = null;
					continue;
				}
				
				$element = & $xml->document->version[0];
				$data[$name] = $element ? $element->data() : null;
			}
		}
		
		return $data;
	}
	
	
	/**
	 * Gets the languages from this site
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @return		array of languages or false on empty
	 * @since		3.0.0
	 */
	public function get_languages()
	{
		$db = & JFactory::getDbo();
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$query	= "SELECT sef as 'value', title as 'name' FROM #__languages WHERE published=1";
			$db->setQuery($query);
			
			return $db->loadAssocList();
		}
		
		// Joomla 1.5 below
		// Check to see if we have Joomfish installed
		if ( $this->_check_table( "languages" ) ) {
			
			$query = "SELECT `shortcode` as 'value', `name` as 'name' FROM #__languages WHERE `active` = 1";
			$db->setQuery( $query );
			
			if ( ( $rows = $db->loadAssocList() ) ) {
				$results = array();
				foreach ( $rows as $row ) {
					$results[$row->value] = $row->name;
				}
				return $results;
			}
		}
		
		// No Joomfish, so pull the languages like Joomla does
		jimport('joomla.client.helper');
		jimport('joomla.filesystem.folder');
		
		$client		= & JApplicationHelper::getClientInfo(JRequest::getVar('client', '0', '', 'int'));
		$results	=   array();
		$ftp		= & JClientHelper::setCredentialsFromRequest('ftp');
		$path		=   JLanguage::getLanguagePath($client->path);
		$params		=   JComponentHelper::getParams( 'com_languages' );
		$dirs		=   JFolder::folders( $path );
		$rowid		= 0;
		
		foreach ($dirs as $dir) {
			$files = JFolder::files( $path.DS.$dir, '^([-_A-Za-z]*)\.xml$' );
			foreach ($files as $file) {
				$data = JApplicationHelper::parseXMLLangMetaFile($path.DS.$dir.DS.$file);
				if ( $params->get( $client->name, 'en-GB' ) == $data['name'] ) {
					$results = array( substr($file,0,-4) => $data['name'] ) + $results;
				}
				else {
					$results = $results + array( substr($file,0,-4) => $data['name'] );
				}
			}
		}
		
		return $results;
	}
	
	
	/**
	 * Retrieves the menu tree from Joomla
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @return		array containing menus or empty array
	 * @since		3.0.0
	 */
	public function get_menutree()
	{
		$db			= & JFactory::getDBO();
		$children	=   array();
		
		$query = 'SELECT menutype, title' .
				' FROM #__menu_types' .
				' ORDER BY title';
		$db->setQuery( $query );
		$menuTypes = $db->loadObjectList();
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$query = 'SELECT id, parent_id, title as name, title, menutype, type, link, ordering FROM #__menu WHERE published = 1';
		}
		else {
			$query = 'SELECT id, parent, parent as parent_id, name, name as title, menutype, type, link, ordering, sublevel FROM #__menu WHERE published = 1';
		}
		
		$db->setQuery($query);
		$menuItems = $db->loadObjectList();
		
		if ($menuItems)
		{
			foreach ($menuItems as $v)
			{
				$pt 	= $v->parent_id;
				$list 	= @$children[$pt] ? $children[$pt] : array();
				array_push( $list, $v );
				$children[$pt] = $list;
			}
		}
		
		$list = JHTML::_('menu.treerecurse', 0, '', array(), $children, 9999, 0, 0 );
		
		$n = count( $list );
		$groupedList = array();
		foreach ($list as $k => $v) {
			if ( empty( $v->menutype ) ) continue;
			$groupedList[$v->menutype][] = &$list[$k];
		}
		
		return array( 'data' => $groupedList, 'version' => JVERSION );
	}
	
	
	/**
	 * Gets a user from the database
	 * @access		public
	 * @version		3.0.8
	 * @param		string		- $search: the string to search by
	 * @param		string		- $by: what to search by (email or username)
	 * 
	 * @return		array or false on no find
	 * @since		3.0.0
	 */
	public function get_user( $search, $by = 'email' )
	{
		if ( is_null( $search ) ) return null;
		
		$db = & JFactory::getDBO();
		$query = "SELECT `id`, `username`, `email`, `name`, `block` FROM #__users WHERE `" . $by . "` = " . $db->Quote( $search );
		$db->setQuery($query, 0, 1);
		return $db->loadAssoc();
	}
	
	
	/**
	 * Gets a username from an email address
	 * @access		public
	 * @version		3.0.8
	 * @param		string		- $email: the email to search for
	 * 
	 * @return		string containing username or false on no result
	 * @since		3.0.0
	 */
	public function get_username( $email )
	{
		$db		= & JFactory::getDBO();
		$query	=   "SELECT u.username FROM `#__users` u WHERE u.email = " . $db->Quote( $email );
		$db->setQuery( $query );
		return $db->loadResult();
	}
	
	
	/**
	 * Searches for users from the database
	 * @access		public
	 * @version		3.0.8
	 * @param		string		- $search: the string to search by
	 *
	 * @return		array or false on no find
	 * @since		3.0.1 (0.2)
	 */
	public function search_user( $search )
	{
		if ( is_null( $search ) ) return null;
		
		$search	= "%{$search}%";
		$db = & JFactory::getDBO();
		$query = "SELECT `id`, `username`, `email`, `name`, `block` FROM #__users WHERE `email` LIKE " . $db->Quote( $search ) . " OR `username` LIKE " . $db->Quote( $search );
		$db->setQuery( $query );
		return $db->loadAssocList();
	}
	
	
	/**
	 * Updates I3 settings for Joomla
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @return		true on success, string with error message otherwise
	 * @since		3.0.0 (0.2)
	 */
	public function update_settings()
	{
		$data	= & IntegratorHelper :: get( 'data', array(), 'array' );
		$data	=   $data['settings'];
		
		$bind	=   array();
		$check	=   array( 'debug' => array( 'IntegratorDebug', array( '0' => 'No', '1' => 'Yes' ) ) );
		
		foreach ( $check as $chk => $b ) {
			if ( isset( $data[$chk] ) ) {
				$bind[$b[0]] = $b[1][$data[$chk]];
			}
		}
		
		if ( ( IntegratorHelper :: update_settings( $bind ) ) === false ) {
			return 'UPDATE_SETTINGS_ERROR';
		}
		
		return true;
	}
	
	
	/**
	 * Creates the user on this site
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @return		true on success, string with error message otherwise
	 * @since		3.0.0
	 */
	public function user_create()
	{
		$data	= & IntegratorHelper :: get ( 'data', array(), 'array' );
		
		// Create the user
		$acl			= & JFactory::getACL();
		$user			=   new JUser();
		$usersConfig	= & JComponentHelper::getParams( 'com_users' );
		
		$newUsertype = $usersConfig->get( 'new_usertype' );
		if (! $newUsertype) $newUsertype = 'Registered';
		
		// We handle groups differently in J1.6+
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$data['groups'][] = $newUsertype;
		}
		else {
			$data['gid'] = $acl->get_group_id( '', $newUsertype, 'ARO' );
		}
		
		if (! $user->bind( $data ) ) {
			return 'USERCREATE_ERRORBIND';
		}
		
		$date = & JFactory::getDate();
		$user->set('registerDate', $date->toMySQL());
		
		if (! $user->save() ) {
			return 'USERCREATE_ERRORSAVE';
		}
		else {
			return true;
		}
	}
	
	
	/**
	 * Finds a user for the API
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @return		string on error or array on succes
	 * @since		3.0.0
	 */
	public function user_find()
	{
		$data	= & IntegratorHelper :: get( 'data', array(), 'array' );
		
		if ( (! isset( $data['email'] ) ) && (! isset( $data['username'] ) ) ) {
			return JText::_( 'COM_INTEGRATOR_API_USERFIND_ERRORNOSEND' );
		}
		
		$by = ( isset( $data['email'] ) ? 'email' : 'username' );
		
		if (! ( $user = $this->get_user( $data[$by], $by ) ) ) {
			return JText::sprintf( 'COM_INTEGRATOR_API_USERFIND_ERRORNOFIND', $data[$by] );
		}
		
		return $user;
	}
	
	
	/**
	 * Search for users for the API
	 * @access		public
	 * @version		3.0.8
	 *
	 * @return		string on error or array on succes
	 * @since		3.0.1 (0.2)
	 */
	public function user_search()
	{
		$data	= & IntegratorHelper :: get( 'data', array(), 'array' );
		
		if (! isset( $data['search'] ) ) {
			return JText::_( 'COM_INTEGRATOR_API_USERSEARCH_ERRORNOSEND' );
		}
		
		$users = $this->search_user( $data['search'] ); 
		
		return $users;
	}
	
	
	/**
	 * Removes a user from this site
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @return		boolean true upon success, string on error
	 * @since		3.0.0
	 */
	public function user_remove()
	{
		$data	= & IntegratorHelper :: get ( 'data', array(), 'array' );
		$by		=   ( isset( $data['email'] ) ? 'email' : 'username' );
		
		if (! ( $user = $this->get_user( $data[$by], $by ) ) ) {
			return JText::sprintf( 'COM_INTEGRATOR_API_USERREMOVE_ERRORNOFIND', $data['email'] );
		}
		
		// Grab the user if it exists
		$user	= & JFactory::getUser( $user['id'] );
		
		if (! $user->delete() ) {
			return JText::_( 'COM_INTEGRATOR_API_USERREMOVE_ERRORDELETE' );
		}
		return true;
	}
	
	
	/**
	 * Updates a user on this connection
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @return		boolean true upon success, string on error
	 * @since		3.0.0
	 */
	public function user_update()
	{
		$data	= & IntegratorHelper :: get( 'data', array(), 'array' );
		$by		=   ( isset( $data['email'] ) ? 'email' : 'username' );
		
		if (! ( $user = $this->get_user( $data[$by], $by ) ) ) {
			return JText::sprintf( 'COM_INTEGRATOR_API_USERUPDATE_ERRORNOFIND', $data[$by] );
		}
		
		// Grab the user if it exists
		$user	= & JFactory::getUser( $user['id'] );
		
		// Build the name info based on variables array
		$binder	=   $data['update'];
		
		if (! $user->bind( $binder ) ) {
			return 'USERUPDATE_ERRORBIND';
		}
		
		if (! $user->save() ) {
			return 'USERUPDATE_ERRORSAVE';
		}
		
		return true;
	}
	
	
	/**
	 * Validates provided user credentials
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @return		boolean true on success, string on error
	 * @since		3.0.0
	 */
	public function user_validation_on_create()
	{
		$db		= & JFactory::getDbo();
		$data	= & IntegratorHelper :: get( 'data', array(), 'array' );
		$query	=   null;
		
		extract( $data );
		
		foreach ( array( 'email', 'username' ) as $check ) {
			if (! isset( $$check ) ) continue;
			$query	= "SELECT u.id FROM `#__users` u WHERE `{$check}` = {$db->Quote( $$check )}";
			$db->setQuery( $query );
			if ( $exists = $db->loadResult() ) {
				return JText::sprintf( 'COM_INTEGRATOR_API_USERVALIDATION_ERROR' . strtoupper( $check ), $$check );
			}
		}
		
		return true;
	}
	
	
	/**
	 * Validates provided user credentials for update
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @return		boolean true on success, string on error
	 * @since		3.0.0
	 */
	public function user_validation_on_update()
	{
		$db		= & JFactory::getDbo();
		$data	= & IntegratorHelper :: get( 'data', array(), 'array' );
		$query	=   null;
		
		extract( $data );
		
		if ( isset( $username ) ) {
			$query	= "SELECT u.id FROM `#__users` u WHERE `username` = {$db->Quote( $username )} AND `username` <> {$db->Quote( $username )}";
		}
		
		if ( isset( $email ) ) {
			$query	= "SELECT u.id FROM `#__users` u WHERE `email` = {$db->Quote( $email )} AND `email` <> {$db->Quote( $email )}";
		}
		
		if ( $query == null ) return false;
		
		$db->setQuery( $query );
		
		if ( $exists = $db->loadResult() ) {
			return JText::sprintf( 'COM_INTEGRATOR_API_USERVALIDATION_ERROR' . ( isset( $email ) ? 'EMAIL' : 'USERNAME' ), isset( $email ) ? $email : $username );
		}
		
		return true;
	}
	
	
	/**
	 * Checks the database for a specific table
	 * @access		private
	 * @version		3.0.8
	 * @param		string		- $table: the table name minus the database key (such as jos) and the leading underscore
	 * 
	 * @return		boolean true if found, false otherwise
	 * @since		3.0.0
	 */
	private function _check_table( $table = null )
	{
		if ( $table == null ) return false;
		
		$db		= & JFactory::getDBO();
		$query	= "SHOW TABLES";
		$db->setQuery( $query );
		$result	= $db->loadAssocList();
		$exists = false;
		
		foreach( $result as $row ) {
			foreach( $row as $r ) {
				if ( substr( $r, ( strlen( $r ) - strlen( $table ) ) ) == $table ) {
					$exists = true;
					break 2;
				}
			}
		}
		return $exists;
	}
	
	
	/**
	 * Method to find a manifest file
	 * @access		private
	 * @version		3.0.8
	 * @param		string		- $path: path to the manifest location
	 *
	 * @return		string of filename or false on unfound
	 * @since		1.1.0
	 */
	private function _searchForManifest($path)
	{
		jimport( 'joomla.filesystem.folder' );
		$files = JFolder::files( $path, '\.xml$', false, true );
		if(! empty( $files ) ) foreach ( $files as $filename ) {
			$xml = JFactory::getXMLParser('simple');
			$result = $xml->loadFile($filename);
			if (! $result ) continue;
			if ( ( $xml->document->name() != 'install' ) && ( $xml->document->name() != 'extension' ) && ( $xml->document->name() != 'mosinstall' ) ) continue;
			unset( $xml );
			return $filename;
		}
	
		return false;
	}
}