<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.8 ( $Id: class.debug.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file is the API handler and calls the curl object and returns responses to the Integrator
 *  
 */

/*-- Security Protocols --*/
jimport( 'joomla.event.profiler' );
defined('_JEXEC') or exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Handles debug information for Integrator
 * @version		3.0.8
 * 
 * @since		3.0.0
 * @author		Steven
 *
 */
class IntDebug extends JObject
{
	/**
	 * Stores any debug data
	 * @access		public
	 * @since		3.0.0
	 * @var			array
	 */
	public	$data		= array();
	
	/**
	 * Enabled or disabled indicator
	 * @access		public
	 * @since		3.0.0
	 * @var			bool
	 */
	public	$enabled	= false;
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		$params			= & JComponentHelper::getParams( "com_integrator" );
		$this->enabled	=   $params->get( 'IntegratorDebug' ) == 'Yes' || JDEBUG  ? true : false;
	}
	
	
	/**
	 * Adds a line for debugging purposes
	 * @access		public
	 * @version		3.0.8
	 * @param		string		- $data: contains the message to add
	 * @param		string		- $filename: the filename the debug was called from
	 * @param		integer		- $line: the line number called from
	 * @param		string		- $type: indicates what type of debug info this is
	 * @param		bool		- $translate: true to translate the string
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function add( $data = null, $filename = null, $line = 0, $type = 'info', $translate = false )
	{
		// Grab the debug from the session storehouse
		$session	= & JFactory::getSession();
		$debugs		=   $session->get( 'debug', array(), 'integrator' );
		
		// If we have something in the session, unserialize it
		if ( $debugs ) $debugs = unserialize( $debugs );
		
		// Add to the debug array
		$debugs[]	= array( 'message' => ( $translate ? JText::_( $data ) : $data ), 'filename' => $filename, 'line' => $line, 'type' => $type );
		
		// Serialize the debug array and set it into the storehouse
		$session->set( 'debug', serialize( $debugs ), 'integrator' );
		return true;
	}
	
	
	/**
	 * Permits adding an entire array of data from the API to the debug class
	 * @access		public
	 * @version		3.0.8
	 * @param		array		- $data: any debug errors returned by the API
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function add_array( $data = array() )
	{
		if ( empty( $data ) ) return;
		
		foreach ( $data as $d ) {
			$this->add( $d['message'], $d['filename'], $d['line'], $d['type'] );
		}
		
		return true;
	}
	
	
	/**
	 * Instantiates the debug object
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @return		instance of IntDebug object
	 * @since		3.0.0
	 */
	public function getInstance()
	{
		static $instance = null;
		
		if ( $instance == null ) {
			$instance = new self;
		}
		
		return $instance;
	}
	
	
	/**
	 * Get method
	 * @access		public
	 * @version		3.0.8
	 * @param		string		- $name: the name of the property to get
	 * @param		mixed		- $default: the default value to return if not set
	 * 
	 * @return		mixed value of property or default value if unset
	 * @since		3.0.0
	 */
	public function get( $name, $default = null )
	{
		$isset = $this->$name;
		return ( $isset == null ? $default : $isset );
	}
	
	
	public function get_last( $remove = false )
	{
		$data	= $this->get( 'data', array() );
		if ( $this->enabled == false || empty( $data ) ) return array();
		$return	= array_pop( $data );
		if ( $remove ) {
			$this->set( 'data', $data );
		}
		return $return;
	}
	
	
	/**
	 * Retrieves the output to respond with
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @return		array of data or empty array if disabled / empty
	 * @since		3.0.0
	 */
	public function get_output()
	{
		// If not enabled return empty
		if ( $this->enabled == false ) return array();
		
		// Grab the session and debug from the session storehouse
		$session	= & JFactory::getSession();
		$data		=   $session->get( 'debug', array(), 'integrator' );
		
		// Clear out the sesion to prevent redisplay
		$session->clear( 'debug', 'integrator' );
		
		// If we have something unserialize it
		if ( $data ) $data = unserialize( $data );
		
		// Send back
		return $data;
	}
}