<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php if (! empty( $this->debug ) ) : ?>

<style type="text/css">

fieldset.adminform .debug_item {
	border-bottom: 1px solid #666;
	clear: both;
	font-weight: bold;
	padding: 5px;
}

fieldset.adminform .debug_notice {
	font-style: italics;
	font-weight: normal;
}

fieldset.adminform .debug_info {
	font-weight: normal;
}

fieldset.adminform .debug_error {
	color: DarkRed;
	font-weight: bold;
}

fieldset.adminform .debug_message {
	float: left;
	font-weight: bold;
}

fieldset.adminform .debug_details {
	float: right;
	font-size: smaller;
}

.fltlft { float: left; }
.fltrt { float: right; }

</style>

<div class="width-60 fltlft">
	<fieldset class="adminform">
		
		<legend><?php echo JText::_( "INTEGRATOR_DEFAULT_DEBUG_HEAD" ); ?></legend>
		
		<span><?php echo JText::_( "INTEGRATOR_DEFAULT_DEBUG_DESC" ); ?></span>
		
		<ul class="adminformlist">
		
		<?php $cnt = 0; ?>
		<?php foreach ( $this->debug as $debug ) : ?>
		
		<li class="debug_item debug_<?php echo $debug['type']; ?>">
			<div class="debug_message">[<?php echo $debug['type']; ?>] <?php echo $debug['message']; ?></div>
			<div class="debug_details"><?php echo $debug['filename']; ?> @ line <?php echo $debug['line']; ?></div>
			<div style="clear: both; line-height: 1px; ">&nbsp;</div>
		</li>
		
		<?php endforeach; ?>
		
		</ul>
		
	</fieldset>
</div>

<?php endif; ?>

<div class="width-40 fltrt">
	<fieldset class="adminform">
		<legend><?php echo JText::_( "INTEGRATOR_DEFAULT_API_HEAD" ); ?></legend>
		<ul class="adminformlist">
		<li>
			<span><?php echo JText::_( "INTEGRATOR_DEFAULT_API_DESC" ); ?></span><br/>
			<input id="apiresult" class="readonly" type="text" readonly="readonly" value="<?php echo ( $this->status === true ? "Successfully Connected" : $this->status ); ?>" style="color: <?php echo ( $this->status === true ? "DarkGreen" : "DarkRed" ) ?>;" size="50" />
		</li>
		</ul>
	</fieldset>
</div>

<form action="index.php" method="post" name="adminForm">
<input type="hidden" name="option" value="com_integrator" />
<input type="hidden" name="controller" value="default" />
<input type="hidden" name="task" value="" />
</form>