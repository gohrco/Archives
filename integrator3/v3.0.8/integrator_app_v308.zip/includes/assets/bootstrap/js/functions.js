/**
 * Performs an ajax call to validate database
 */
function validateDatabase()
{
	var dbhost		= jQuery( '#db_hostname' ).val();
	var dbuser		= jQuery( '#db_username' ).val();
	var dbpass		= jQuery( '#db_password' ).val();
	var dbport		= jQuery( '#db_port' ).val();
	var updateurl	= ajaxurl + '/check_db';
	
	jQuery.ajax({
		type: 'POST',
		url: updateurl,
		data: 'dbhost=' + dbhost + '&dbuser=' + dbuser + '&dbpass=' + dbpass + '&dbport=' + dbport,
	}).success( function( obj ) {
		//var obj = jQuery.parseJSON( msg );
		
		if ( obj.success == "true" ) {
			ajaxResponse( obj.message, 'success' );
			jQuery( '#db_valid' ).val( '1' );
		}
		else if ( obj.success == "false" ) {
			ajaxResponse( obj.message, 'error' );
			jQuery( '#db_valid' ).val( '0' );
		}
		else {
			ajaxResponse( 'Problem making ajax call', 'error' );
		}
	});
	return false;
}


/**
 * Ajax call to verify the database
 * @returns {Boolean}
 */
function verifyDatabase( create )
{
	if ( create == undefined ) {
		var dbmake		= jQuery( '#db_create' ).is( ':checked' ) ? '1' : '0';
	}
	else {
		var dbmake		= create;
	}
	
	var dbname		= jQuery( '#db_database' ).val();
	var dbpref		= jQuery( '#db_dbprefix' ).val();
	var updateurl	= ajaxurl + '/validate_db';
	
	jQuery.ajax({
		type:	'POST',
		url:	updateurl,
		data:	'dbname=' + dbname + '&dbmake=' + dbmake + '&dbpref=' + dbpref,
	}).success( function ( obj ) {
		
		if ( obj.success == "true" ) {
			ajaxResponse( obj.message, 'success' );
			jQuery( '#db_valid' ).val( '1' );
		}
		else if ( obj.success == "false" ) {
			ajaxResponse( obj.message, 'error' );
			jQuery( '#db_valid' ).val( '0' );
		}
		else {
			ajaxResponse( 'Problem making ajax call', 'error' );
		}
	});
	
	return false;
}


/**
 * Handle the create toggle
 */
function verifyWithcreate()
{
	var create = jQuery( '#db_create' ).is( ':checked' ) ? '0' : '1';
	verifyDatabase( create );
}


/**
 * Sends a response to the screen
 * @param		msg		string
 * @param		type	(error|success)
 */
function ajaxResponse( msg, type )
{
	var resp	= jQuery( '#ajaxResponse' );
	resp.addClass( 'row-fluid' );
	
	var title	= jQuery( '#ajaxTitle' + type ).val();
	
	var data	= '<div class="span1">&nbsp;</div><div class="alert alert-' + type + ' span10"><button class="close" data-dismiss="alert">x</button>'
				+ '<h4 class="alert-heading">' + title + '</h4>'
				+ '<ul><li>' + msg + '</li></ul>'
				+ '</div></div>';
	
	resp.html( data );
}
