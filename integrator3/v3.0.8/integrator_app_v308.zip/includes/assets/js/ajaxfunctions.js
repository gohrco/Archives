function ajaxvalidate( item ) {
	var myurl		= document.getElementById( 'myurl' ).value;
	var valid		= jQuery( '#validate' + item.name );
	var field		= jQuery( '#field' + item.name );
	
	valid.html( 'Checking ' + item.name ).addClass( 'checking' ).removeClass( 'success' ).removeClass( 'error' );
	field.addClass( 'checking' ).removeClass( 'success' ).removeClass( 'error' );
	
	jQuery.ajax({
		type: 'POST',
		url: myurl + '/register/verify',
		data: 'item=' + item.name + '&value=' + item.value,
	}).success( function ( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		field.removeClass( 'checking' );
		
		if ( obj.result == true ) {
			valid.html( 'Validated!' ).addClass( 'success' );
			field.addClass( 'success' );
		}
		else {
			valid.html( obj.msg ).addClass( 'error' );
			field.addClass( 'error' );
		}
		
	});
	
}


function updatecheck() {
	var myurl		= document.getElementById( 'updurl' ).value;
	var updtxt		= jQuery( '#version_results' );
	
	jQuery.ajax({
		type: 'POST',
		url: myurl,
	}).success( function( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		updtxt.html( obj.msg );
		if ( obj.result == 'success' ) {
			if ( obj.data == true ) {
				updtxt.removeClass( 'version_checking' ).addClass( 'version_outdated' );
			}
			else {
				updtxt.removeClass( 'version_checking' ).addClass( 'version_uptodate' );
			}
		}
	});
}