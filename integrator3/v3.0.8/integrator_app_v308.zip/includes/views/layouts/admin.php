<!DOCTYPE HTML>
<html lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		
		<!-- Always force latest IE rendering engine & Chrome Frame -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		
		<title><?php echo $template['title']; ?></title>
		
		<base href="<?php echo base_url(); ?>" />
		
		<?php echo $header_includes; ?>
		
		<!-- Mobile Viewport Fix -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
		
		<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
		
		<script type="text/javascript">
			var ajaxurl		= '<?php echo base_url( 'index.php/ajax' ); ?>';
		</script>
		
	</head>
<body>

<header class="row header">
	<div class="header-inner">
		<div id="logoWrap">
			<div id="logo">Integrator <small>v</small>3.0</div> 
		</div>
		<?php if ( $licensekey != null ) : ?>
		<div id="license">
			<dl class="dl-horizontal">
				<dt><?php echo lang( 'dt.license' ); ?></dt><dd><?php echo $licensekey; ?></dd>
				<dt><?php echo lang( 'dt.version' ); ?></dt><dd><?php echo $version; ?><span id="version_results" class="label"><?php echo lang( 'side.versionchecking' ); ?></span></dd>
				<dt></dt><dd><a href="<?php echo site_url( 'admin/logout' ); ?>" class="btn btn-mini" id="logout"><?php echo lang( 'btn.logout' ); ?></a>
			</dl>
		</div>
		<?php endif; ?>
	</div>
</header>

<?php echo $template['partials']['navbar']; ?>

<div class="container">
	
	<div class="row-fluid">
		
		<div id="content">
			<?php if (! empty( $error ) ) : ?>
				<div>
					<div class="alert alert-error">
						<button class="close" data-dismiss="alert">x</button>
						<h4 class="alert-heading"><?php echo lang( 'error.heading' ); ?></h4>
						<ul><?php echo $error; ?></ul>
					</div>
				</div>
			<?php endif; ?>
			
			<?php if (! empty( $success ) ) : ?>
				<div>
					<div class="alert alert-success">
						<button class="close" data-dismiss="alert">x</button>
						<h4 class="alert-heading"><?php echo lang( 'success.heading' ); ?></h4>
						<ul><?php echo $success; ?></ul>
					</div>
				</div>
			<?php endif; ?>
			
			<?php if (! empty( $info ) ) : ?>
				<div>
					<div class="alert alert-info">
						<button class="close" data-dismiss="alert">x</button>
						<h4 class="alert-heading"><?php echo lang( 'info.heading' ); ?></h4>
						<ul><?php echo $info; ?></ul>
					</div>
				</div>
			<?php endif; ?>
			
			<div class="row-fluid">
				<?php echo $template['partials']['body']; ?>
			</div>
		
		</div>
		
		
	</div>
</div>

<footer class="footer">
	
	Copyright &copy; <?php echo anchor( "https://www.gohigheris.com", "GoHigherIS" ); ?> All Rights Reserved
	
</footer>

<?php echo $template['partials']['modals']; ?>

<?php echo $footer_javascript; ?>

<?php echo $template['partials']['debug']; ?>

</body>
</html>