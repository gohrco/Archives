<div class="row-fluid">
	<div class="span1"> </div>
	<div class="span11">
		<?php 
		$header	= ( isset( $header ) ? $header : $action );
		
		echo heading( lang( str_replace( '/', '.', $header ) ), '3', 'class="header"' );
		
		if ( lang( str_replace( '/', '.', $header ) . '.desc' ) ) : ?>
			<div class="header-text"><?php echo lang( str_replace( '/', '.', $header ) . '.desc' ); ?></div>
		<?php endif; ?>
	</div>
</div>

<div class="row-fluid">
	
	<?php foreach ( $data as $item ) : ?>
	
	<div class="well">
	
	<?php echo heading ( $item->heading, '2' ); ?>
	
	<?php echo $item->body; ?>
	
	</div>
	
	<?php endforeach; ?>
	
</div>

<?php if (! empty( $buttons ) ) : ?>

<div class="row-fluid">
	<div class="form-actions">
		<?php 
		foreach ( $buttons as $button )
		{
			$type = $button->btntype; 
			unset( $button->btntype );
			
			if ( $type == 'anchor' )
			{
				$uri	= $button->uri;
				$title	= $button->title;
				unset ( $button->uri, $button->title );
				echo anchor( $uri, $title, (array) $button );
			}
			else
			{
				echo form_button( (array) $button );
			}
		}	
		?>
	</div>
</div>

<?php endif; ?>