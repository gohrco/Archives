<?php //00923
/**
 * ---------------------------------------------------------------------
 * Integrator v3.0
 * ---------------------------------------------------------------------
 * 2009 - 2012 Go Higher Information Services.  All rights reserved.
 * 2013 January 7
 * version 3.0.8
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPzPANkbY3wFERvFBoWw1fliZH26lXBKbEO6ijcyD9CjOsD2s8w2mt3XWDgbccj424nFZp3GR
vmcFvrvYoYeKpNHALwVlWOB8PxEJjefUSYLRN1QJrDHrVwhsLcNG6JapABcjJ0e44hT0X5mrqfUE
38/J3rFzbKb6C9ZqgsP7jNYU31PVPQXUl2EFnHzTn+MQ+RjfHWZnzeB0AXTkG2u7LBXmQt8E65PP
HLcONgefup+LJzSLyVGNVHTTZ4zbuTsiA+SF7hzVj4HTuknQn2oeOCSrPNnuwxenTLVYRb/3uu7v
WwUa2Dj8jblLTxg6SvVnKpRaU2+Z//00yVJrWP1NanVj0juf+8dpKlhkyprdXyWwBa7fFhsgK1wb
E1XcK85h9b2ljhONJ69DnBgtOIQ+TJ4d1kwkXHIT58nTq5AKyU56Vt9KyDogLSnOyUH+MP7lMtFg
1cmnpsVpLh7HQtE/wy/1rEBuVv86rWKijAmAdmUaAvqhCm+afDqium2m01+pXg74LV0IFyaPfm1d
3Xsk4SOW9bcAgnsvepQTSEuZU1ybXZiJsYmu8If3wiOMxWlu7CZLl0icdI5zZTCzjZcyUHByVIWb
cyfe5TsAVGkwEMJnL4mefq0RCKpDhs00AXS/9ZCdvQjFK04owNwUprzK6+Q4YZwccP2pUMKTrpIa
MpZnei6+PdJyRQy+cZiC/OonprXZat+RCUDSg3NPQFT2bo9/lujsoGQXuEcJCMvFpNxgPNrLIqHR
0INDn3OFDyOY6o6zQ5n0vzXce6PK39ORT3xBMeJop5Lru52leXQeXnD5Eashow2I7nH5Y2XLlbjK
8VGUk9vv0QMKz1ryfsDPBdv5iIId29agjsa8vVM4BIpdKoIq/LA6Bb5vUt4ECyce7pJdtmwE2zqO
dR36rgCd6M7yNfpr942PRD6v2xSA1f5GL0rPRw5SPWQfY3aSPGpLJdapyp6hn9D7c3W0Hy57ZVRB
B64K+pbKCCpRKc0hLkmpanYtkroQznVjbCF1grlTvAnjVaHSwmSl/nDtmXgdn1bXRikT23MbPEiW
TvSTM2hwqoN7YfZYa6XV2prtT8+OOb4L3tWTdGH6idC+Z2ZuyHgKcxCTZ8qidSW5cb7FruFyODyg
Un1WAelTl92AFs8A6Kd3wCTY8MKkpzDwRvGseFj1rWP29zzKX2/bNOFYuZLtdUaEcMJ2UfrRVlZs
Bq/M5/M8j5tctD1oKnhCdIvTZ+rrXLLOprPhwrNhKQhMK83jGFkr2qvwMfLHxLoYBQrhbrkfs9LY
y1FbG6XikX5BIoKPHm/zOMDQvMOWHCjYJujzh0dD/HLrlMTWGHuwCb7xuXdv3pVqvSHmrnQcBgGH
a1BDrd6+H/zJt3kIEvRsle/qM1JVR9RBwkomn67TxOWuKXTBeKbBz6kc8aI7SSMIIHhcC+gSiHkA
kf4LtLWcSjZ3Zp0VwvAQaf6Tk2I5s71IgrFXu/KpwUx8V/nnZdvPxJsAIA+8R/G1Ces9XQxO0+Ov
VcfkSqJwFGxAtfJh1YDO5Nt+e44eYLqKNX2bjeyFT+nM3cibg4sEy+fN/ziQ6OIekw8GrPNVHZF4
DRY42vapixZ+Pycvgm0PwBmoErRV8jpaphALAeP0z1lw6hBgpRpEGaZzcELJ2aHUOGE6YraDWZVn
HrXfQ9TcQMZpItu+4hOYpGs+PPL68VJeI2gueAEOSq1uKzHuYQbLpu5oTRWY3x5HwVgCKlxKCdEi
auLhpwfm8HiTNgLLQPzkDggU92c0H9k/Z8dR2sO2hsGAXCs3iVw4G8JskqwGWWjEmLBwq7Eol7Zu
7lrmqQeEqDlK8E/4IFtoy34bmNtwqOoL9mvgYpz1229M3rsaRinizFNPD6jMJJbFdxHa/5t6f7+i
GK8Cq+H2/FMfI9J4PJGXiLaux5YPRO0MIN5yTxFTP/IZgz+9RNe/xnnX+FwIcF/yEKZTpH0Rqfei
f63/JO2HMHhBtC7YbV2HERINDEyBzCp3PsRF8B8kNMcYz8AErzZhNkTBdnqnJFuKXUxS9YB2YP/W
OGtT9x7h/EFONH8i9PdEIZ0S3vgWE4wPhqSgIuDFzikt9CKrhPW5M6c9QAZALs9AGufaTdW/W9uT
NN5JI+i4NDQ151+LrX/Y+SfzU3yMThvCgU2RxC+l4AJUP2tCvN2JCFap/iaaI8Z9zqrL2shVtCV6
CpWPsdZr/HrKOiJkE+iuB/rtN2NL/YOW8wlYifmW2vlGPplE1HqfiI2FO3TMWzyh/DSz9g14ioxC
kNKTfa4T3PwUeaPuIRP9rWrybjc7zPWXO/MicCSj1d55JQj+rfNeFuppAKaY+80aU/XsqA0pcsuD
BfHqzFFw6BeTb0oRdRaF58pBGnaJ1t378otxNK4vQMNuOfRZikfPq2v3I5K0WuXgvNAUG/r30Jaf
/5VCFoVc6CqdiNq1MkqREbHpEhKjhkAWibmEbrhBbSETbpZUeICn3Xl//UeWDlH+imppobBGRKUH
hi/ZzkK9BW8cRo1x1qD1vlYUbAdNSF6dRI8zp1H0HL8f4PS9XSTR8VC796u3t12jJXY264AvIOu1
KaNh5ZkIaJKGOD+yxNt2eSr7LtP588AAH6D9Zw0ATNP1Gd/mC6YvSHUWRG84ehM3PJTw1X7cU68L
mvcwcHaLwm2VvXqbs0QsxGSd6ItXZJuTAoBCqkH2U+34xQTro1poPPPop6lcMAQ9gjjx/2deXScx
cxwu9qJe1eaAtgfUDlhY+Ubae1FyAyya0HZCZMZwG6MMUvXIKobflWtpY/GkbKQ4AnpIfJ39hAPN
vJ5J2sULO6DhON3uPNUjR84eH4DZMF3N1yQ4ti9AM74IbPo5b16JWwTdxzMFJBbwHvUzbMO3drc0
2B4NxIgBsE+7K0b0iorf7e3KbrTP23g/qyghZpeNNMPoB1rrS/Ncb7mA+XThTByEiB9f7NjRgtCb
ABEQJm+sY6SW8HoZ87xlXki89aLc4nfejxRc2CyCg7CtENh/3YRu8jO8qj6NRlhYLxZBFoJd+0ok
OHcyL+hEdBN4IcbRhnU98aCfo9jRLGAfaJd/skaFRIR9WgvwV7O4aqkSzmB6/TvsueRv7wwhnPDN
lkECHMr2xqRX4IyOuHSFNt9LI0wOC8yP9geMp72dM8eoOww+BRkIIK8AAI9hfOcgY0GNqSJqmVn9
+bdIUboU5aX3UC0pqeYPN6el6YqkTk4iDsKBdoQrjtxVVyAaKu6k2ZTqQCV47U4bjCUwTUzoTcPR
Sw0r4QzuWlL4LL39yA0Byb16f53B6+m1u/7W7fpXKDrQVsLfJ9Cw8EefuJHlJCoOvLKPEJAEJoi0
5QwFZsVZcQnpC5Pq9lI8CD0RpoKWqv9RkiBTVnURyYkSLhhP0goR7WapNDJfKeLfNFed7WQaTV/q
ptoNsjQXlyAffnFdBcqouWfkhbVNO2F9j867YHz9EtT2vVvCTKqC+ycM0LzlN9NH36eGeu25XuED
W74bA2YSGoA6+tLXNIn06Chys+ewaC74/wMNBa7aK6c5RmjskyqA7lc0JZcWcyzn2W0MiLFcrjKR
fagMHoc+kb3Rgpg3hkpCgR+erUWXKgXobHjSuctUH+gr8xprZVCI6BLlOsSzLg0ZuMF7KyUr+Gau
JgNe3rYxTr3edGv7/E6LPmzeJ/SigAhCDTsUzDIYPAs0DcBRE1FCS5odcGAfTKCDfCEQeQ+aTPRY
wg9DuR2aD+F+6eYXw/jpsmEYvXvTzy/FlI9d9dGG1iw7QSaHBvOgsyq2pmA5sco0UNze40Y1qqKg
LTWTp8XgCkZmXmPbsBIg8Kh+RVbRsPlWN+Tcxzkd6vbLg1GS4RCJzBQoyzvtqrbc4fy6ocS7qDhx
drOkDDWA6mWB/aA7ZrILN5Mb3ILKHQ4sC5n7WDDSpjOHu7mUePwt/DdxX3GaOC1hL+ab8oDh4Ilj
PW3TX46+Jln2qqkGq7K0wy3PAeK4mQ/V22AfqmCDxAXSQ1GTJUmRs+Qe57fdNUCXJqVzzO9cZPGH
nuh3NVkJE3Saubyi9RFrfUESPHoKd/Acoaofq0/fGdhsaHkBv5T1pkSNKRVvH8VijAnSVDHvGZOR
nGnnhEV7eyL+Wix56sCRt/6DP7tO5nQSgCEN1+URL0sm9VQuYWMO/N9GX+98LMkGdNWOapLwVJch
u8NHHEUK+y4KUjDH8EvLPz6M2IGuOaP55iOX/IPNroawjZV/Dg44+UGogFkmpBrwfOhkO7VRWPnr
mZ6Ci2kDxLtnX/hZCKCjVhQwM09NL6tKsU6XhkJvyOjN+52rV+O7g+M/WPegItKFNYt9vkYaMt1b
DRMN6CCtHRu1Cmb+6DhJZkJItZfAbfl7/0FP3MRj1SaEWnDRgoN2XTBa7yZYMT7EAIEFV27nlm7s
0NE8JpYUmlIZxKB0nWyq3MYS648SxLUR9R7whg7blwCRI/yjl4p+m4pKYZ4C3Jb3kUKtkfbmmC61
2thGNTMIEJdtt6K0odcqCnWpJqQnDwNmoh2rbKSqJvvLlBPBwukyXMefy8vNyNcPo2dRt8sLd/k8
kOvlphZ8BXZ91TJhcOJ4k4KvHr6b7ufA0HfvntKd0ojH6OXB7cKa+F1scDDWfuVyPCwfqKJ+ACl1
T1D4hzhrL4NsePNr294nVuevmUNIj7CMrh2xa1jHA0Ay5VFe7Kl5NvsL/wHk8UcsKLp9rQXL6z15
7nXu6qapupgZu4s7maAWj003aUgMTrZtdM+lCntc2nUvxMRiYCA9Q7vO7FVUXlUd8KU1SUFLEbeo
KH6eyFGv/+A4tmTssinLR5ino6qhM/40SAg1Fv4XjeqjwBksy1OGpgvdbnZq2mkaA11sbNDjP+Ct
yRqoWzBLSUUmzO4kjSuIHlh+hEGT9Q77ClmAHI9QyJgXe9WOU3bI+oiecvTksgqARhUpN08oVc+A
ZrUlDvnQKXYXn6tWD1x1JyL3OgjZOiaqkV4K4Ks6M5CrylA29TwRu6c1IoRX3ETekGT/BuZ5ZjgD
Z9iNmxxZx5aPeHzrf23AxRAfVPj1buhcv5fmuGuDVeEqyGBSPZ3834Z0N8iUazfNDXHcHHqCh5h6
0K9o5ZwDkwMIol/mHgpzN1FomQDFkFXV/CTCvVAUkxhWQ0p/f5diYUYGXjO2jF3P2+xoIldQJwKA
Ttxorwz86g+GdCu0WAduSxNwDhXiQwtPi2/VJB9Mz2lU1J11cVgmq20dV88fjvu0c4iFxkdN8fLT
cA6fWr40+a+rI5DSNhvkitWjIP8vJ6onKOvEMZWiolaPECaYVW8deL10RBgPPwUIqcWOP48XjmHn
1mOHfgbcCPKYqKbdnx3Z9XuTUP4qmzE9XrqSb++O12MoN3OdEZv2dSRZAhiopsYJNUeraKI1gkp8
3ysFrYTnYUw4OaP5XD6u+EdluUcAPjju/eJ5BUeESdFRqOO4Gsq26R0xA3ljhbLJ/STtC/GsS7FZ
KWXrjxLpJKwWUyxEHEVXgmL17qieUirhoAo/5kYh/HHl+pBvYee9KAusMX3AfAy8mZL+KjBUZweg
9pyb72LrV725+xkYkJXZ0YmN++BMFnoN9TWZb9MDRKyFuI41zcwZbD7tTEQEElLIZun3e025QMiT
e3lYuo26ZgdRbqwqcRv3Ko0KUUeW88yE/98v6CPV50YrVs3Yi54wAN1XZwrMVW/ge98Kd3iz3QsH
yE3grOc9U0c56D7Ppy4oXR/BtMtiRd+sH1EJBTLT02l1LsWFZ2Ocf1oggkLPGaryYyvmwwnSCM/V
YcIbK20S/OSBgU8n3aNk3leM0K2Hm+aWceAnHJ4GChPSX2Fovzj65uS0cwbHS03H3D5p/mNRwKPq
veLxuhNM/3HeqrgiXvYpBSW6tMZo24xCZfKhiemI3PKCUF3XTASsCcVUWKQR3jzn2RNdYZdv6Y8I
uOozMRaY+jPSRF47eWs/NvmZZRCQRpPFRYRQCrfx959v5JExQFRK0VnBORZpl47RjmUdP9wHgZgY
JBc61m02sTxDm7ILBnILg40P2eoSywjMVzUXW7TP9nTZuuz4x17dJuzStduBjdboKdfTaIbI7hoR
P2sWWtQAcrKFiONr2PaAD2tXVoI0uvxpf5gnWbHHQCF3PxjBtV/9z/zonMyTQEQIzObVk41Ralbq
o6Lrw6+KU0y1NOzb80i0nVblayJmiIfjVJx/5Rv1UE0vToYFEUXc4WH4/olNyh2kaKkp5+K8qnaJ
8dBV1scKTzWTakq6hXPjQ3IiyCd1lPs60SNADDK4TPTbplYwVZyMRGLRhcwYi73ZFnv7y3P+TCCG
Ty+sY25j9WNuKDlmI+Ff76iJi37pH+8o5O77teIs+M7Rlx8bjoDyQtLpi03wau+yy7erbULXKg4t
GEKFWOXOuTLqOwKm0ScOjsVUUKvC6tLflo1GbCK9mMBZhl952/Ep1wzmslsPmr18IjzTwjiEXVZO
ocS/FRndYJB7dOXsrD1GMAOfSRY8+ke5MXWpAAJnMgBqlaG+hGlxpjdLd0I1VkhTJLA7b5XdV1e5
KlsZaNkS+ZP3yM/6WD8rJHEk3l753hcb1vnEFUGNkgltj/UOsD4kRbJnGHHB6u5RAn5um43MlcHi
0WzSe2IZprRV36OQH26Xj6KFiEnwjs4+/BEAQeuCYwltXraQMuLcGjKn8hW/skfVjsBSMJ1r2UZd
Xa/8pBETE9MGkEXRw/neI1usItpoos0IaO9ukFYHnPPBECIkDPFBIwdauFDGd9ESl1wiT3DBiwBD
haOnZDXR1HSKzsGIbheWEsYO0fNdp7unHWOPgmYjfYDc/TdnzOJZVCj8+4K/T0Z2LqW5cc6oxEwO
MJIq01GXjyVFb6rVHUV8quUSoqjeoA2BW3i5i112QhbNEQ5+oK5TkWrT5NEnpQzHgw5CQx4YLtGW
wK9yDbKDTDbM4n2zHOBAMXCj0d3kemxH1MN6FJ4UCDtB5h0iCX5QTE75Rb1h8uvjWNk7X+cEd2rb
bS6wtKuDfolWy0A8yuYVAkgV0uCYWsw2X4r3Io9d8WjIt9aUZAStPc5xMpOSurIqNgWLIkjetghb
txtgdzv6aVGZnvPOPrugo0NutnfG7HHUKBz0pFeGOqp95nPK4urpEZK2lAdH3jLGjYe1zL7BKrms
QqatOg6KWgqckjm8ZaLgooinabVAgQIpkVbxM6F4FlIWoolg49eo2HhZwRl3oqV8deUIxVvuDfgb
Fk77BmW5Eb2Qb2O2zFM6jbfqGOew8hFul16d8UAWw9p6xTxZ0QifbKP1GUju+xvp79p0BQ96wZU/
Z2zg6zvl/aAw4ZZt/FL8tG7XIPPma8P4DFNA5jOTnD1C4B75uH/6UW0dVUQQR6FPL4+0cPZR0yjx
O9JenBtdNdwHcQrNRCunukWpVOcQlHE7qNq7TfOwYxHE9zpT9PoKILIHRN/EHoYOmC12fIdJQMVz
lO5G6GEs9Z7/ho7ozw3unmnDk5EPzjHqMufNoyZu8y2M/3xo4u6rL3jl9GyEeFaGUDlw9zOnDZ6M
aX7lT0V/HUIqBcrVAPyYXkVaiLEREpb+USw/B4DHdozUHMexogkQNzm0a+Ws8lzgUH5+rqCd01R4
LHHXQcn7zO5VqDxgwnL3QKPiRvuz37UFZAVSFJHUlTNMYFAety6+ny589FBfCSi4HFaF223QUJyW
yAiq1XkBWfRbuGRFSVdZr9Uns88Blax2xDNKluVGetCVsT8RAoWSAig+8EuaVdBB+9v5EyVlS0l+
XT876Y6carrSEKjvkFKq5EBbtp4XiZxd5e85TzaunWe/O7U1lwiH8ED+mOFFftFOnRMQjSl44TrD
UuJEDVL6dsob2E6Enm9FSW2yeYPfjiBeQHKtrfmGVrNa+dUfWBhYq0nS4nGLetDThTYRkZuP9YMm
6TgzV4So7P+JO9jP+UGFsJWhlheWxSRGjiF8RARXttb6BEuX9VgoA+iW22R9KPONyIvIkTS9VDpP
EDctzkjzzl29m8+LVqoJE4pskKxC2KqBm/BEhows1REdoM6vwDxn0uig7J0dHRIy2DeKy/gAvwSg
KpGizm5x7WWKCAfl/aT7Z+rbbF2PiMWr/U7ZJYPwa+zfqFpCmAuJXh3PuLkQFVT6FR5ogCDf4LZN
MPXGEhzCjUtH4aH+8FcqHkFG15RskQgJdNNhXIeW6Vnmzi6SHtMBEbr0mnqzM1ytcdBQr17PWz+t
y4EXVD0B4yE9n00pCyb3FqbOtIO/7eAG7/n4OkdR9pcV1KFCzW1J75byaaG9hLtKr4d/D3r/z+i1
FccLn0Q7Q5SbuzJurwtQGrZTmMiK67G5hbwrsQXiE+yD8CqHJBeU++7vusDiUIOU07X6o/Br+PI7
ZVTvyd8To0zjQ2I11f/R/PVaQi45jhekQbyZE2pvb64XXkz5eb4YOIZExzsuxXOS/OGoTCJS5HTG
J8AWnnd89VlkhNl8FlOc6SrMyDair4ziimPnh89QP5HxipKVggg1mnIkFp2xP4E+aE8uytj1EjNL
aCDIrnF0F+APOx4Iees3EIPCdryn9ov+FQn+AkTJ2UF9Td9Ea6q1FLqhX1HUP5Bxyhoug2VnNC2k
ElTOW8RQenLEqbogHF8DuZZ5nDuIHoxrTvKDkUzgdNDLea013a+DCSURy+JJSw7MsmfBEPsZybFn
YAIdegrAtcCINnLFXzT7qAHiOgPlAKROW2HaPisv3xWzcCGOz5hwc4YBAA4F0hMYPuWqyMqW2wxD
MC5IJJNtW2yPJFJZc146UkrqAhr37WR4YTM9KFdm/y6KMGXN95C25jHXWOlEesZD+P8MO5FkYyyO
oH3r8IH5pZCD4mnzafr16EVlTH89fauehr8BYj8BjmhPkw2z7FYGLmKkKn4gy7nUuSLN23s5MdtU
GmyIJ0QK/RwJ9VXPAIKa+WfGmXFMvK9iMlfF09q8XpjnEq+hWbxzQAasTtTtXdnoMEhkpor4C7Sc
FrbNhLXpUJFAHi+UFj7XQGxFCDQTYSs/HDTGaXI8nTIRQ7m6AQ+ppGgs7phcv8H4KiK75xq1Qkms
rxAGvu0LkM+Br6l2HSFCuPO/CwO38m0bGDNe88aGiFdOu2bDl+Tx2I+eNoVXHe9VWfpk9RwKD2p9
DdJMv05oYSWv3Qe6umFNAR9UZLro0YVme78zRZSbi9NYuPB+p02lgAljgaam7XQigY2q3nXtL4oP
RuMIWsWiYu6quKhjqN8h5fmtqI/SyMkFtwNL57iGqWbXl71bo0IAoZzxNOX29yvn9H5RuifkRxOG
dKEKz72+P0V7Ic3DcPor/IQF3v85MGWOHDLEvX8CanFFf4+ImYxV1znU+ofd8pTzbHebj/56INVJ
3FvGLnZ7G4BhsYzO2Sqho9np28g9qHfvFy/0Gl9AGJyrmhiffzsZAhVEL4RGwewSFXtsDVt3bUm0
M7Lwv8rw8++n6jDRjl969CTMg1l/KrSbET9SdYu3D8VgEnBbyRWsPftBMvx65iaBCgv1cX//y3gW
XfXp8NICx+J8j33tt8aH7We4czV+fpNUa4WYlXD4pbl2KM1Jw6/K3/HyP7aK5HuVOWbMQ4aI3wdZ
RmDvKgEeGNIi4FS0iyXvqAe=