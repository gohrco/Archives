<?php
/**
 * Integrator
*
* @package    Integrator 3.0 Core Package
* @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
* @license    Commercial
* @version    3.0.8 ( $Id: admin_lang.php 163 2012-12-18 14:56:38Z steven_gohigher $ )
* @author     Go Higher Information Services
* @since      3.0.0
*
* @desc       This is the English language file for the Joomla admin controller pages for the Integrator
*
*/

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


// ===================================================================
// 	Pagemapping (pagemap/index)
// ===================================================================
//		v 3.0.2
// -------------------------------------------------------------------
$lang['whmcs.page.header']	= 'The settings below indicate which pages on this WHMCS connection are mapped from the application selected on the left and the associated page beneath `Page`.  A default page must be set (at the top) and you can choose to have certain pages retrieved when the user is on the associated WHMCS page.';



// ===================================================================
// 	Language Mapping (langmap/index)
// ===================================================================
//		v 3.0.2
// -------------------------------------------------------------------
$lang['whmcs.lang.header']	= 'The settings below indicate which languages on this WHMCS connection are mapped from the application selected on the left and the associated language beneath `Language`.  A default language must be set (at the top) and you can choose to have certain languages retrieved when the user is on the associated WHMCS language.';



// ===================================================================
// 	Edit Connection (cnxns/edit)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['whmcs_globals.accesskey']				= "Access Key";

$lang['whmcs_users.testpwstrength']				= 'Test Password Strength';
$lang['whmcs_users.testpwstrength.desc']		= 'Enabling this setting allows WHMCS to test your updated or new password against the set password strength in WHMCS to maintain a level of strength across your applications.  This only affects password checks performed through the API from another connection.';

$lang['whmcs_users.defaultaddress1']			= "Default Address";
$lang['whmcs_users.defaultaddress1.desc']		= "When creating a new user in WHMCS, you must supply this field.  If the connection creating the user doesn't supply the field, the Integrator will use this setting as a default.";

$lang['whmcs_users.defaultcity']				= "Default City";
$lang['whmcs_users.defaultcity.desc']			= $lang['whmcs_users.defaultaddress1.desc'];

$lang['whmcs_users.defaultcountry']				= "Default Country";
$lang['whmcs_users.defaultcountry.desc']		= $lang['whmcs_users.defaultaddress1.desc'];

$lang['whmcs_users.defaultphonenumber']			= "Default Phone";
$lang['whmcs_users.defaultphonenumber.desc']	= $lang['whmcs_users.defaultaddress1.desc'];

$lang['whmcs_users.defaultpostcode']			= "Default Postal Code";
$lang['whmcs_users.defaultpostcode.desc']		= $lang['whmcs_users.defaultaddress1.desc'];

$lang['whmcs_users.defaultstate']				= "Default State";
$lang['whmcs_users.defaultstate.desc']			= $lang['whmcs_users.defaultaddress1.desc'];

$lang['whmcs_users.defaultlastname']			= "Default Last Name";
$lang['whmcs_users.defaultlastname.desc']		= $lang['whmcs_users.defaultaddress1.desc'];

// ----- Users Settings Tab
$lang['whmcs_users.sendemail']				= 'Send Welcome Email';
$lang['whmcs_users.sendemail.desc']			= 'WHMCS permits you to send a welcome email when the client signs up.  Setting this to Enabled will tell WHMCS to send the email, Disabled will prevent the message from being sent.';

// ----- Clientarea Settings Tab
$lang['whmcs_clientarea.invoicesdisplay']	= 'Display Invoices';
$lang['whmcs_clientarea.invoicesnewwin']	= 'Invoices in New Window';
$lang['whmcs_clientarea.ticketsdisplay']	= 'Display Tickets';
$lang['whmcs_clientarea.ticketsnewwin']		= 'Tickets in New Window';

$lang['whmcs_desc.clientarea.invoicesdisplay']	= 'Do you want the invoice summary to be included on the Client Area page for your logged in clients?';
$lang['whmcs_desc.clientarea.invoicesnewwin']	= 'Do you want the invoices to be opened in a new window or tab?';
$lang['whmcs_desc.clientarea.ticketsdisplay']	= 'Do you want the ticket summary to be included on the Client Area page for your logged in clients?';
$lang['whmcs_desc.clientarea.ticketsnewwin']	= 'Do you want the tickets to be opened in a new window or tab?';



// ===================================================================
// 	User Management (usermgr/modify)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['whmcs_user.label']				= "Email Address";
$lang['whmcs_user.desc']				= "Type in the current email address for the user you are searching for.";

$lang['whmcs_userinfo.email']			= "Email Address";
$lang['whmcs_userinfo.email.desc']		= 'The email address is required by WHMCS and is the single identifier across all connections.  Changing this may prevent the user from logging in across all your applications.';

$lang['whmcs_userinfo.firstname']		= "First Name";
$lang['whmcs_userinfo.firstname.desc']	= '(required)';

$lang['whmcs_userinfo.lastname']			= "Last Name";
$lang['whmcs_userinfo.lastname.desc']		= '(required)';

$lang['whmcs_userinfo.companyname']			= "Company Name";
$lang['whmcs_userinfo.companyname.desc']	= ' ';



// ===================================================================
// 	System Update (help/systemstatus/updates)
// ===================================================================
//		v 3.0.8
// -------------------------------------------------------------------
$lang['dialog.whmcs.update.content']	= '<p>The updates for this connection are handled through FTP and finalized in the backend of WHMCS.  To update, download the latest package for WHMCS from our site, FTP the files to your WHMCS site and then navigate to your admin area by clicking the button below.  The button will take you to your admin area where you will need to log in, navigate to the WHMCS > Setup > Addon Modules and allow WHMCS to update the addon module for you.</p><p><strong>The link below may not work if you have a custom admin folder name set!</strong></p>';
$lang['dialog.whmcs.update.header']		= 'Redirect to WHMCS Admin Area';
$lang['dialog.whmcs.button.redirect']	= 'Redirect';
