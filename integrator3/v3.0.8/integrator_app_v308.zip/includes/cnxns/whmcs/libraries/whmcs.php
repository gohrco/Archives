<?php defined('BASEPATH') OR exit('No direct script access allowed');

include_once( 'render.php' );
include_once( 'api.php' );

/**
 * WHMCS 4.5.1 Connections Library extended class
 * @version		3.0.8
 * 
 * @since		3.0.0
 * @author Steven
 */
class Whmcs extends Cnxns_library
{
	protected	$apiparams		= array();		// The parameters to post / put for API connections
	protected	$isvisual		= false;
	protected	$renderparams	= array();		// The parameters to post / put for Rendering the site back to user
	protected 	$type			= "whmcs";	// The type reference for this object
	//protected	$uri			= null;			// The global URI object for use
	protected 	$version		= "3.0.8";	// The version of this object in use
	public		$cnxn_id		= null;			// Changes depending on which cnxn needs the library
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		$this->_ci = & get_instance();
	}
	
	
	/**
	 * Bind the parameters to connection
	 * @access		public
	 * @version		3.0.8
	 * @param		varies		- $params: if empty, does nothing, if integer, loads from DB, else a json_encoded string
	 * 
	 * @since		3.0.0
	 * @see 		Cnxns::bind()
	 */
	public function bind( $params = null )
	{
		// Return json-decoded params back
		
		parent::bind( $params );
	}
	
	
	/**
	 * Verifies settings for the connection
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @return		boolean true on success
	 * @since		3.0.0
	 * @see Cnxns_library::update_settings()
	 */
	public function verify_settings()
	{
		$api	= & get_api( $this->cnxn_id );
		$CI		= & get_instance();
		
		// =================================================
		// ---BEGIN: Verify settings updated in parent first
		// -------------------------------------------------
		if (! ( $model = parent::verify_settings() ) ) {
			error_message( 'msg.error.noconnection' );
			return false;
		}
		// ---END:   Verify settings updated in parent first
		// =================================================
		// ---BEGIN: Test the Base Connection URL
		// -------------------------------------------------
		$baseuri	= new Uri( $model->get( 'url', null, 'globals' ) );
		$baseuri->setPath( rtrim( $baseuri->getPath(), '/' ). '/' );
		
		if (! ( $result = $api->ping( $baseuri->toString() ) ) ) {
			$model->set( 'active', false );
			$model->save();
			error_message( 'msg.error.cnxnping' );
			return true;
		}
		else {
			$model->set( 'url', $baseuri->toString(), 'globals' );
			$model->save();
		}
		// ---END:   Test the Base Connection URL
		// =================================================
		// ---BEGIN: Test API URL for active connection
		// -------------------------------------------------
		$ping	= $api->ping();
		
		if ( $ping['result'] != 'success' ) {
			if ( ( $sslset = $model->get( 'sslverify', false, 'api' ) ) AND ( $CI->curl->error_code == 60 ) ) {
				info_message( 'msg.info.nosslverify' );
				$model->set( 'sslverify', 0, 'api' );
				$model->save( $model->get_properties() );
				//return false;
			}
			else if ( $ping['result'] == 'error' ) {
				error_message( 'msg.error.cnxndeactivated', $model->get( "name" ) );
				error_message( 'msg.error.msgreturned', 'API Credential Test', $model->get( 'name' ), $ping['message'] );
			}
			else {
				error_message( 'msg.error.cnxndeactivated', $model->get( "name" ) );
			}
			$model->set( 'active', 0 );
			$model->save( $model->get_properties() );
			return true;
		}
		// ---END:   Test API URL for active connection
		// =================================================
		
		return true;
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE RELATED TO TRANSLATING BETWEEN CUSER AND THIS CNXN
	 * **********************************************************************
	 */
	
	
	/**
	 * Creates an array of fields to filter cuser object for this object
	 * @access		public
	 * @version		3.0.8
	 * @param		array		- $full_form: the full form from the cuser object
	 * @param		boolean		- $is_new: if this is a new user form
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function cuser_fields( $full_form, $is_new = false )
	{
		$data		= array();
		$use_fields	= array( 	'id'		=> array( 'type' => 'hidden', 'req' => $is_new ? false : true ),
								'firstname'	=> array( 'req' => true ),
								'lastname'	=> array( 'req' => true ),
								'email'		=> array( 'req' => true ),
								'password'	=> array( 'req' => $is_new ),
								'address1'	=> array( 'req' => true ),
								'address2'	=> array( 'req' => false ),
								'city'		=> array( 'req' => true ),
								'state'		=> array( 'req' => true ),
								'postal'	=> array( 'req' => true ),
								'country'	=> array( 'req' => false ),
								'phone'		=> array( 'req' => true ),
								'companyname'	=> array( 'req' => false )
		);
		
		foreach( $use_fields as $name => $optns ) {
			$data[$name] = $full_form[$name];
			
			if ( $optns['req'] ) {
				$data[$name]['validation'] = 'required|' . $full_form[$name]['validation'];
			}
			
			if ( isset( $optns['type'] ) ) $data[$name]['type'] = $optns['type'];
			
		}
		
		return $data;
	}
	
	
	/**
	 * Processes an array of data and inserts into the common user object
	 * @access		public
	 * @version		3.0.8
	 * @param		array		- $juser: array of data from this connection type
	 * 
	 * @since		3.0.0
	 */
	public function cuser_place( $wuser )
	{
		$cuser	= & Cuser::getInstance( true );
		$data	=   array();
		$trans	=   $this->cuser_table( true );
		
		foreach ( $wuser as $k => $v ) {
			
			if ( $k == 'status' ) {
				if ( $v == 'Active' ) $v = true;
				elseif ( $v == 'Closed' ) $v = false;
				else $v = null;
			}
			
			if ( isset( $trans[$k] ) ) {
				$data[$trans[$k]] = $v;
				continue;
			}
			
			if ( $k == 'update' ) {
				
				foreach( $v as $k2 => $v2 ) {
					if ( $k2 == 'status' ) {
						if ( $v2 == 'Active' ) $v2 = true;
						elseif ( $v2 == 'Closed' ) $v2 = false;
						else $v2 = null;
					}
					
					if ( isset( $trans[$k2] ) ) {
						$data['update'][$trans[$k2]] = $v2;
						continue;
					}
				}
			}
		}
		
		// Set the data
		$cuser->set_properties( $data );
		
		// If we are coming from the API interface, we must establish username and fullname for cnxns requiring such
		if ( defined( 'INTEGRATOR_API' ) && ( get_var( '_c' ) == $this->get( 'cnxn_id' ) ) ) {
			$cuser->complete( $this->get( 'cnxn_id' ) );
		}
		
		return;
	}
	
	
	/**
	 * Processes an array of raw data from the cuser object and converts to WHMCS object
	 * @access		public
	 * @version		3.0.8
	 * @param		array		- $raw: data to convert
	 * 
	 * @return		array of converted data
	 * @since		3.0.0
	 */
	public function cuser_process( $raw )
	{
		$trans	=   $this->cuser_table();
		$data	=   array();
		
		// Loop through data array
		foreach( $raw as $k => $c ) :
		
		// Convert raw active values
		if ( $k == 'active' ) {
			if ( $c == true ) $c = 'Active';
			else if ( $c == false ) $c = 'Closed';
			else $c = 'Inactive';
		}
		
		// Convert array values
		if ( is_array( $c ) ) {
			$data[$k] = $this->cuser_process( $c );
			continue;
		}
		
		// Convert raw keys to refined keys
		if ( isset( $trans[$k] ) ) {
			$data[$trans[$k]] = $c;
		}
		
		endforeach;
		
		// Check for names
		if ( isset( $raw['fullname'] ) && (! isset( $data['firstname'] ) || ! isset( $data['lastname'] ) ) ) {
			$names	= explode( " ", trim( $raw['fullname'] ) );
			if ( count( $names ) > 1 ) {
				$first	= array_shift( $names );
				if (! isset( $data['firstname'] ) ) 
					$data['firstname'] = $first;
				if (! isset( $data['lastname'] ) )
					$data['lastname'] = implode( " ", $names );
			}
			else {
				if (! isset( $data['lastname'] ) ) 
					$data['lastname'] = $this->get( 'defaultlastname', null, 'users' );
				if (! isset( $data['firstname'] ) )
					$data['firstname'] = $raw['fullname'];
			}
		}
		
		return $data;
	}
	
	
	/**
	 * Extracts user data from the common user object for use on this connection type
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @return		array of user data
	 * @since		3.0.0
	 */
	public function cuser_retrieve()
	{
		$cuser	= & Cuser::getInstance();
		$cdata	=   $cuser->get_properties();
		$trans	=   $this->cuser_table();
		
		return $this->cuser_process( $cdata );
	}
	
	
	/**
	 * Translation table from WP to cuser object
	 * @access		public
	 * @version		3.0.8
	 * @param		boolean		- $from: if coming from cuser then true
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function cuser_table( $from = false )
	{
		$data	= array();
		
		$data['id']				= 'id';
		$data['firstname']		= 'firstname';
		$data['lastname']		= 'lastname';
		$data['companyname']	= 'companyname';
		$data['email']			= 'email';
		$data['password']		= 'password'; // upon flip password => password2
		$data['password2']		= 'password'; // this way we get password sent by api
		$data['address1']		= 'address1';
		$data['address2']		= 'address2';
		$data['city']			= 'city';
		$data['state']			= 'state';
		$data['postcode']		= 'postal';
		$data['country']		= 'country';
		$data['phonenumber']	= 'phone';
		$data['subaccount']		= 'active';
		$data['active']			= 'active';
		
		return ( $from ? $data : array_flip( $data ) );
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE RELATED TO THE USER INTEGRATION OF THE CONNECTION
	 * **********************************************************************
	 */
	
	
	/**
	* Builds the country array
	* @access		public
	* @version		3.0.8
	*
	* @return		array containing country array
	* @since		3.0.0 (0.2)
	* @see			Cnxns_library :: build_country_array()
	*/
	public function build_country_array()
	{
		return parent::build_country_array();
	}
	
	
	/**
	 * Builds a new name based on settings
	 * @access		public
	 * @version		3.0.8
	 * @param		integer		- $cnxnid: the connection id the data set is originating from
	 * @param		array		- $data: the data sent by the connection
	 * 
	 * @return		string containing the new name
	 * @since		3.0.0
	 */
	public function build_new_fullname( $cnxnid = null, $data = array() )
	{
		// Must have a cnxnid
		if ( $cnxnid == null ) return null;
		
		$cnxn	= cnxn( $cnxnid );
		$method	= $cnxn->get( 'storename', 'firstlast', 'users' );
		$user	= null;
		
		switch( $method ) :
		
		case 'lastfirstco':
			$user = ( isset( $data['companyname'] ) ? ' (' . $data['companyname'] . ')' : null );
			
		case 'lastfirst':
			$user = $data['lastname'] . ' ' . $data['firstname'] . $user;
			break;
		
		case 'firstlastco':
			$user = ( isset( $data['companyname'] ) ? ' (' . $data['companyname'] . ')' : null );
		
		case 'firstlast':
		default:
			$user = $data['firstname'] . ' ' . $data['lastname'] . $user;
			break;
		
		endswitch;
		
		return $user;
	}
	
	
	/**
	 * Builds a new username based on settings
	 * @access		public
	 * @version		3.0.8
	 * @param		integer		- $cnxnid: the connection id the data set is originating from
	 * @param		array		- $data: the data sent by the connection
	 * 
	 * @return		string containing the new username
	 * @since		3.0.0
	 */
	public function build_new_username( $cnxnid = null, $data = array() )
	{
		// Must have a cnxnid
		if ( $cnxnid == null ) return null;
		
		$cnxn	= cnxn( $cnxnid );
		$method	= $cnxn->get( 'storeusername', 'random', 'users' );
		$user	= null;
		
		switch( $method ) :
		case 'first.last':
			$user = $data['firstname'] . ' ' . $data['lastname'];
			break;
		case 'last.first':
			$user = $data['lastname'] . ' ' . $data['firstname'];
			break;
		case 'flastname':
			$user = substr( $data['firstname'], 0, 1 ).$data['lastname'];
			break;
		case 'firstnamel':
			$user = $data['firstname'].substr( $data['lastname'], 0, 1 );
			break;
		case 'firstname':
		case 'lastname':
			$user = $data[$method];
			break;
		case 'custom':
			$field	= $cnxn->get( 'customfield', 'email', 'users' );
			$user	= $data[$field];
			break;
		default:
		case 'random':
			for ($i=0; $i<12; $i++) {
				$d = rand(1,30)%2;
				$user .= ( $d ? chr(rand(65,90)) : chr(rand(48,57)));
			}
			$user = ucfirst(strtolower($user));
			break;
		endswitch;
		
		return $user;
	}
	
	
	/**
	 * Builds the user array to send to this connection
	 * @access		public
	 * @version		3.0.8
	 * @param		array		- $data: the Integrator data set to translate
	 * 
	 * @return		array containing data set for this connection
	 * @since		3.0.0
	 * @see 		Cnxns_library::build_user_array()
	 */
	public function build_user_array( $data )
	{
		$data	= parent::build_user_array( $data );
		
		$isnew = ( ( isset( $data['newusername'] ) ) && ( isset( $data['newemail'] ) ) && (! isset( $data['email'] ) ) && (! isset( $data['username'] ) ) ) ? true : false;
		
		if ( isset( $data['username'] ) ) unset( $data['username'] );
		if ( isset( $data['newusername'] ) ) unset( $data['newusername'] );
		
		if ( $isnew ) {
			$cnxn	= cnxn( $this->get( "cnxn_id" ) );
			$data['password2']	= $data['password'];
			$data['email']		= $data['newemail'];
			$data['lastname']	= (! isset( $data['lastname'] ) )		? $cnxn->get( 'defaultlastname', null, 'users' ): $data['lastname'];
			$data['address1']	= (! isset( $data['address1'] ) )		? $cnxn->get( 'defaultaddress', null, 'users' )	: $data['address1'];
			$data['city']		= (! isset( $data['city'] ) )			? $cnxn->get( 'defaultcity', null, 'users' )	: $data['city'];
			$data['state']		= (! isset( $data['state'] ) )			? $cnxn->get( 'defaultstate', null, 'users' )	: $data['state'];
			$data['postcode']	= (! isset( $data['postcode'] ) )		? $cnxn->get( 'defaultpostal', null, 'users' )	: $data['postcode'];
			$data['phonenumber']= (! isset( $data['phonenumber'] ) )	? $cnxn->get( 'defaultphone', null, 'users' )	: $data['phonenumber'];
			$data['country']	= (! isset( $data['country'] ) )		? $cnxn->get( 'defaultcountry', null, 'users' )	: $data['country'];
			unset( $data['newemail'], $data['password'] );
		}
		
		return $data;
	}
	
	
	/**
	 * Decodes the return url
	 * @access		public
	 * @version		3.0.8
	 * @param		base64 string	- $return: base64 encoded string
	 * 
	 * @return		string containing URL
	 * @since		3.0.0
	 */
	public function decode_return_url( $return )
	{
		return base64_decode( $return );
	}
	
	
	/**
	 * Decodes the session id posted to the renderer
	 * @access		public
	 * @version		3.0.8
	 * @param		base64 string	- $sid: base64 encoded string
	 * 
	 * @return		string containing session id
	 * @since		3.0.0
	 */
	public function decode_session_id( $sid ) {
		return $sid;
	}
	
	
	/**
	 * Returns the correct URL for the forgot password link
	 * @access		public
	 * @version		3.0.8
	 *
	 * @return		string
	 * @since		3.0.2
	 * @see			Cnxns_library::get_forgot_password_url()
	 */
	public function get_forgot_password_url()
	{
		$cnxn_model	=   cnxn( $this->get( 'cnxn_id' ) );
		$base_url	=   $cnxn_model->get( 'baseurl' );
		$redirect	=   rtrim( $base_url, '/' ) . '/pwreset.php';
		return $redirect;
	}
	
	
	/**
	 * Builds the login error page with error message
	 * @access		public
	 * @version		3.0.8
	 * @param		string		- $error: contains the error message to send along
	 *
	 * @return		string containing URL of login error landing page
	 * @since		3.0.0
	 */
	public function get_login_error_url( $error = null )
	{
		$cnxn	= cnxn( $this->get( 'cnxn_id' ) );
		$erruri	= new Uri( $cnxn->get( 'loginlandingerrorurl' ) );
		if ( $error ) $erruri->setVar( 'errmsg', $error );
		return $erruri->toString();
	}
	
	
	/**
	 * Grabs the login fields from the session and sends back to login redirecter
	 * @access		public
	 * @version		3.0.8
	 * @param		string		- $fields: contains any fields already assembled by child classes
	 * 
	 * @return		string containing html hidden fields
	 * @since		3.0.0
	 */
	public function get_login_fields( $fields = null )
	{
		$this->_ci->load->helper( "form" );
		
		$fields .= form_hidden( "integrator", "true" );
		
		return parent::get_login_fields( $fields );
	}
	
	
	/**
	 * Gets the secondary information for display on the user client area page
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @return		array or false if none
	 * @see			Cnxns_library::get_secondary_info()
	 */
	public function get_secondary_info()
	{
		$data	=   array();
		$email	=   is_logged_in( true );
		$api	=   get_api( $this->cnxn_id );
		$cuser	= & Cuser :: getInstance( true );
		
		$cuser->set( 'email', $email );
		
		return $api->get_secondary_info();
	}
	
	
	/**
	 * Gets the route to redirect to
	 * @access		public
	 * @version		3.0.8
	 * @param		string		- $page: if set will send user to the requested page or else it will pull from post variables
	 * 
	 * @return		string containing proper URL
	 * @since		3.0.0
	 */
	public function get_route( $page = null )
	{
		$page	= ( $page == null ? get_var( 'page' ) . '.php' : $page );
		$lang	= get_var( 'lang' );
		
		// Get an instance of the URL first
		$uri	= Uri :: getInstance( cnxn( $this->get( 'cnxn_id' ) )->get( 'baseurl' ), '/' );
		
		// Handle x and a vars
		$parts	= explode( '-', $page );
		if ( count( $parts ) > 1 ) {
			$page = array_shift( $parts ) . '.php';
			$var	= ( $parts[0] == 'x' ? 'action' : $parts[0] );
			$val	= str_replace( '.php', '', $parts[1] );
			$uri->setVar( $var, $val );
		}		
		
		$uri->setPath( rtrim( $uri->getPath(), '/' ) . '/' . $page );
		$uri->setVar( '_v', get_var( '_c' ) );
		
		// Set the language
		if ( ( $lang = get_var( 'lang' ) ) ) {
			$lang = find_mapped_item( 'lang', $this->get( 'cnxn_id' ), $lang, get_var( '_c' ), true );
			if ( $lang ) {
				$uri->setVar( 'language', $lang ) ;
			}
		}
		
		// Pull the posted vars to add to the URL
		if ( ( $vars = get_var( 'vars' ) ) ) {
			$vp	= explode( '&', $vars );
			foreach ( $vp as $v ) {
				if ( empty( $v ) ) continue;
				$ip = explode( '=', $v );
				if ( count( $ip ) == 1 ) continue;
				$key	= array_shift( $ip );
				$uri->setVar( $key, implode( '=', $ip ) );
			}
		}
		
		return $uri->toString();
	}
	
	
	/**
	 * Gets an item for the update process
	 * @access		public
	 * @version		3.0.8
	 * @param		string		- $item: href|modal|action|url...
	 *
	 * @return		varies
	 * @since		3.0.8
	 * @see			Cnxn_Library :: get_update()
	 */
	public function get_update( $item = null )
	{
		switch ( $item ) {
			// For the link in help/systemstatus/updates we want to popup a modal
			case 'href' :
				return $this->get_update( 'modal' );
				break;
			case 'modalbuttons' :
				return array(
				(object) array( 'uri' => $this->get_update( 'uri' ), 'title' => lang( 'dialog.wp.button.redirect' ), 'id' => 'confirmModal', 'class' => 'btn btn-primary', 'btntype' => 'anchor', 'target' => '_blank' ),
				(object) array( 'content' => lang( 'cancel' ), 'name' => 'cancel', 'id' => 'cancelModal', 'value' => true, 'class' => 'btn', 'data-dismiss' => 'modal', 'btntype' => 'button' )
				);
				break;
			case 'uri' :
				$model = cnxn ( $this->cnxn_id );
				$url	= $model->get( 'url', null, 'globals' );
				$uri	= new Uri( $url );
				$uri->setPath( rtrim( $uri->getPath(), '/' ) . '/admin/configaddonmods.php' );
				return $uri->toString();
				break;
			default:
				return parent :: get_update( $item );
		}
	}
	
	
	/**
	 * Takes care of storing session cookies
	 * @access		public
	 * @version		3.0.8
	 * @param		base64 string	- $sid: contains the session id base 64 encoded
	 * @param		base64 string	- $sname: contains the session name base 64 encoded
	 * 
	 * @since		3.0.0
	 */
	public function handle_session_cookies( $sid, $sname )
	{
		if ( ( $sid == NULL ) OR ( $sname == NULL ) ) return false;
		
//		$sid	= base64_decode( $sid );
//		$sname	= base64_decode( $sname );
		
		save_session_id( $sid, $this->cnxn_id );
	}
	
	
	/**
	 * Takes the user array from WHMCS and converts it to a standard user array
	 * @access		public
	 * @version		3.0.8
	 * @param		array		- $user: contains the data passed by the API to the Integrator
	 * 
	 * @return		array containing standardized user data
	 * @since		3.0.0
	 */
	public function handle_user_array( $data )
	{
		$isnew = ( ( ( isset( $data['newusername'] ) ) || ( isset( $data['newemail'] ) ) ) && (! isset( $data['email'] ) ) && (! isset( $data['username'] ) ) ) ? true : false;
		
		if ( ( in_array( $this->_ci->router->fetch_method(), array( 'user_create', 'user_validation_on_create' ) ) ) && (! isset ( $data['newusername'] ) ) ) {
			$data['newusername'] = $this->build_newusername( get_var( '_c', 'post' ), $data );
		}
		return $data;
	}
	
	
	/**
	 * Removes session cookies and session from database
	 * @access		public
	 * @version		3.0.8
	 * 
	 * @since		3.0.0
	 * @see			Cnxns_library::remove_session_cookies()
	 */
	public function remove_session_cookies()
	{
		remove_session_id( $this->cnxn_id, false );
		parent::remove_session_cookies();
	}
}