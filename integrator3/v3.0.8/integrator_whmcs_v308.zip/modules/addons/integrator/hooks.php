<?php
/**
 * Integrator
 * WHMCS - Hook File
 * 
 * @package    Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.8 ( $Id: hooks.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file included in the hooks execution and calls appropriate functions for actions
 * 
 */

/*-- Security Protocols --*/
if (!defined("WHMCS")) die("This file cannot be accessed directly");
/*-- Security Protocols --*/

/*-- File Inclusions --*/
require_once( "factory.php" );
/*-- File Inclusions --*/

$INT_hook	= & IntFactory::getHook();
$INT_log	= & IntFactory::getLog();
IntHook::addHooks();

/**
 * Not sure what I need this for... :)
 * @version		3.0.8
 * 
 * @since		3.0.0
 */
function integrator_adminhomepage()
{
	
}


/**
 * ClientDetailsValidation applies only to client
 *		no validation hook point available for contact
 *		as of (WHMCS v4.5.2)
 */
add_hook( "ClientDetailsValidation", 20, "integrator_clientvalidation", "" );

// ------------------------------------------------------

/**
 * Handles successful log in process
 * @version		3.0.8
 * @param 		array		- $vars: contains data passed by WHMCS hook point
 * 
 * @since		3.0.0
 */
function integrator_login( $vars )
{
	if ( defined( "INTEGRATORAPI" ) ) return;
	
	global $INT_hook;
	$INT_hook->login( $vars );
}


/**
 * Handles log out process
 * @version		3.0.8
 * @param		array		- $vars: contains data passed by WHMCS hook point
 * 
 * @since		3.0.0
 */
function integrator_logout( $vars )
{
	if ( defined( "INTEGRATORAPI" ) ) return;
	
	global $INT_hook;
	$INT_hook->logout( $vars );
}


/**
 * Handles client area rendering
 * @version		3.0.8
 * @param		array		- $vars: contains data passed by WHMCS hook point
 * 
 * @since		3.0.0
 */
function integrator_clientarea( $vars )
{
	if ( defined( "INTEGRATORAPI" ) ) return;
	
	global $INT_hook;
	$INT_hook->clientarea( $vars );
}

// ------------------------------------------------------


/**
 * Handles adding a client to the system
 * @version		3.0.8
 * @param		array		- $vars: contains data passed by WHMCS hook point
 * 
 * @since		3.0.0
 */
function integrator_clientadd( $vars )
{
	if ( defined( "INTEGRATORAPI" ) ) return;
	
	global $INT_hook, $INT_log;
	$INT_log->set( 'action', 'Client add' );
	$INT_hook->set( 'contact', false );
	$INT_hook->clientadd( $vars );
	$INT_log->write();
}


/**
 * Handles editing a client in the system
 * @version		3.0.8
 * @param		array		- $vars: contains data passed by WHMCS hook point
 * 
 * @since		3.0.0
 */
function integrator_clientedit( $vars )
{
	if ( defined( "INTEGRATORAPI" ) ) return;
	
	global $INT_hook, $INT_log;
	$INT_log->set( 'action', 'Client edit' );
	$INT_hook->set( 'contact', false );
	$INT_hook->clientedit( $vars );
	$INT_log->write();
}


/**
 * Handles changing a password for a client
 * @version		3.0.8
 * @param		array		- $vars: contains data passed by WHMCS hook point
 * 
 * @since		3.0.0
 */
function integrator_changepw( $vars )
{
	if ( defined( "INTEGRATORAPI" ) ) return;
	
	global $INT_hook, $INT_log;
	$INT_log->set( 'action', 'Change password' );
	$INT_hook->changepw( $vars );
	$INT_log->write();
}

// ------------------------------------------------------


/**
 * Handles adding a contact to the system
 * @version		3.0.8
 * @param		array		- $vars: contains data passed by WHMCS hook point
 * 
 * @since		3.0.0
 */
function integrator_contactadd( $vars )
{
	if ( defined( "INTEGRATORAPI" ) ) return;
	
	global $INT_hook, $INT_log;
	$INT_log->set( 'action', 'Contact Add' );
	$INT_hook->set( 'contact', true );
	$INT_hook->clientadd( $vars );
	$INT_log->write();
}


/**
 * Handles editing a contact in the system
 * @version		3.0.8
 * @param		array		- $vars: contains data passed by WHMCS hook point
 * 
 * @since		3.0.0
 */
function integrator_contactedit( $vars )
{
	if ( defined( "INTEGRATORAPI" ) ) return;
	
	global $INT_hook, $INT_log;
	$INT_log->set( 'action', 'Contact Edit' );
	$INT_hook->set( 'contact', true );
	$INT_hook->clientedit( $vars );
	$INT_log->write();
}


// ------------------------------------------------------


/**
 * Handles client information validation
 * @version		3.0.8
 * @param		array		- $vars: contains data passed by WHMCS hook point
 * 
 * @since		3.0.0
 */
function integrator_clientvalidation( $vars )
{
	if ( defined( "INTEGRATORAPI" ) ) return;
	
	if ( empty( $vars ) ) {
		$vars = $_POST;
	}
	
	global $INT_hook, $INT_log;
	$INT_log->set( 'action', 'Client Validation' );
	$INT_hook->clientvalidation( $vars );
	$INT_log->write();
}


?>