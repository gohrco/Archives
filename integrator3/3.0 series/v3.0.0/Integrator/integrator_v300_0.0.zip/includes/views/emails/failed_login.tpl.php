<html>
<body>
	<p>A recent login attempt failed:</p>
	<table>
		<tr>
			<td>Time</td><td><?php echo date( "d / m / Y  H:i T", $timestamp ); ?></td>
		</tr>
		<tr>
			<td>Username</td><td><?php echo $username; ?></td>
		</tr>
		<tr>
			<td>IP Address</td><td><?php echo $ip_address; ?></td>
		</tr>
	</table>
</body>
</html>