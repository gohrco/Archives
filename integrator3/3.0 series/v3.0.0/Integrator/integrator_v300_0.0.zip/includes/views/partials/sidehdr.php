<div id="side-hdr">
	<?php echo image( 'logo.png', null, array( 'id' => 'logo' ) ); ?>
	<h3>Integrator <small>v</small>3.0</h3>
	
	<?php if (! empty( $admin_user ) ) : ?>
	
	<span>
	<?php echo sprintf( lang( 'side.greeting' ), $admin_user->first_name, $admin_user->last_name ); ?><br/>
	<?php echo anchor( 'admin/logout', 'Logout' ); ?>
	</span>
	
	<?php endif; ?>
</div>