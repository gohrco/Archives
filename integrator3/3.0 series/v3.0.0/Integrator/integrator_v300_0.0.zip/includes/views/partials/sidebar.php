<div id="main-nav">
	<ul id="menu-nav">
		<?php if ( isset( $nav ) ) : foreach ( $nav as $n ) : ?>
		<?php if ( isset( $n->submenu ) ) : ?>
		<li>
		<?php echo anchor ( $n->anchor, $n->text, 'class="top-link' . ( $n->current ? ' current' : '' ) . '"' ); ?>
		<ul>
			<?php foreach( $n->submenu as $o ) : ?>
			<li><?php echo anchor( $o->anchor, $o->text, ( $o->current ? 'class="currentsub"' : '' ) ); ?></li>
			<?php endforeach; ?>
		</ul></li>
		<?php else : ?>
		<li><?php echo anchor( $n->anchor, $n->text, 'class="no-submenu' . ( $n->current ? ' current' : '' ) . '"' ); ?></li>
		<?php endif; ?>
		<?php endforeach; endif; ?>
	</ul>
</div>