<div id="cpanel">
<?php foreach ( $cnxns as $cnxn ): ?>
<?php echo icon( $cnxn->path, $cnxn->image, $cnxn->options ); ?>
<?php endforeach; ?>
</div>