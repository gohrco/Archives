<?php


/**
 * Create a menu tree from the provided variables
 * @access		public
 * @version		3.0.0.0.0
 * @param		array		- $itemlist: Containing values
 * @param		integer		- $parent: Contains parent id or 0 for default
 * @param		string		- $pre: Contains the prepended text
 * 
 * @return		Array containing menu items
 * @since		3.0.0
 */
function build_menu_tree( $itemlist, $parent = 0, $pre = '' )
{
	$return				= array();
	$uselist			= $itemlist[$parent];
	$return[$parent]	= array();
	
	foreach( $uselist as $item ) {
		//Build the indent
		if ( $pre == '' )
			$indent = "&nbsp;&nbsp;-&nbsp;";	// First level
		else
			$indent = $pre;						// Subsequent levels
		
		$return[$parent][] = array( 'value' => $item['value'], 'name' => "{$indent}{$item['name']}" );
		
		if ( isset( $itemlist[$item['value']] ) )
		{
			$children = build_menu_tree( $itemlist, $item['value'], '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' . $indent );
			$indent = $pre;
			
			foreach( $children[$item['value']] as $child ) {
				$return[$parent][] = array( 'value' => $child['value'], 'name' => "{$child['name']}" );
			}
		}
	}
	
	if ( $pre == '' ) return $return[$parent];
	else return $return;
}


/**
 * Retrieves a connection by name or id
 * @access		public
 * @version		3.0.0.0.0
 * @param		varies		- $id: can be string representing name of connection or integer of connection id
 * 
 * @return		object of loaded connection in library or false if non-exist
 * @since		3.0.0
 */
function cnxn( $id = null )
{
	if ( $id == null ) return false;
	$isName	= (! is_numeric( $id ) ? TRUE : FALSE );
	$CI =& get_instance();
	$CI->load->library('cnxns_library');
	
	if ( ( $isName ) AND ( isset( $CI->cnxns_library->cnxnsbyname[strtolower( $id )] ) ) ) {
		$cnxn = & $CI->cnxns_library->cnxnsbyname[strtolower( $id )];
	}
	elseif ( (! $isName ) AND ( isset( $CI->cnxns_library->cnxns[$id] ) ) ) {
		$cnxn = & $CI->cnxns_library->cnxns[$id];
	}
	else {
		$cnxn = false;
	}
	
	return $cnxn;
}


/**
 * Retrieves a connection library and sets the connection id for reference
 * @access		public
 * @version		3.0.0.0.0
 * @param		string		- $type: the type of connection to get
 * @param		integer		- $id: the connection id to set for reference
 * 
 * @return		object of connection library
 * @since		3.0.0
 */
function cnxn_library( $type = null, $id = null )
{
	$CI = & get_instance();
	$CI->load->library( 'cnxns_library' );
	$types	= $CI->cnxns_library->get( "types" );
	$data	= array();
	foreach ( $types as $t => $toss ) {
		if ( $type == $toss->get( "type" ) ) {
			$data = clone $CI->$type;
			
			break;
		}
		$data[]	= & $CI->$t;
	}
	$data->set( "cnxn_id", $id );
	return $data;
}

/**
 * Finds mapped items in database
 * @access		public
 * @version		3.0.0.0.0
 * @param		string		$type: the type of map to use (lang or page)
 * @param		integer		$_a: the application id
 * @param		string		$item: the item to retrieve
 * @param		integer		$_v: the site id to find value for
 * @param		boolean		$reverse: if true indicates we are going from site to app
 * 
 * @return		mixed value or false on error
 * @since		3.0.0
 */

function find_mapped_item( $type = null, $_a = null, $item = null, $_v = null, $reverse = false )
{
	if ( in_array( null, array( $type, $_a, $item, $_v ) ) ) return false;
	$modelname = $type . "map_model";
	
	$CI = & get_instance();
	$CI->load->model( $modelname );
	
	if (! $pages = $CI->$modelname->load( $_a, $item, ( $reverse ? $_v : false ) ) ) {
		$pages = $CI->$modelname->load( $_a, 'default', ( $reverse ? $_v : false ) );
	}
	
	if ( $reverse ) {
		if ( $CI->$modelname->get( 'item' ) == 'default' ) {
			return false;
		} 
		return $CI->$modelname->get( 'item' );
	}
	
	$pagearray = $CI->$modelname->get( "_v" );
	$return	= $pagearray[$_v];
	if ( $return == 'default' ) return find_mapped_item( $type, $_a, 'default', $_v, $reverse );
	else return $return;
}



function find_origin( $for = null )
{
	$params = & Params::getInstance();
	$origin = false;
	
	switch( $for ):
	case 'logout':															// -- LOGOUT LOGIC --
		if ( $origin = get_var( '_c', array( 'post' ) ) ) return $origin;	// See if we sent it (_c)
		if ( $origin = find_origin() ) return $origin;						// See if we've been here (session)
		if ( $cnxn = cnxn( $params->get( 'Defaultuser' ) ) ) {				// Use the default user then (params)
			return $cnxn->get( 'id' );
		}
		break;
	case 'visual':
		if ( $origin = get_var( "_v", array( 'post', 'get', 'session' ) ) ) return $origin;
		if ( $origin = find_origin() ) return $origin;
		if ( $cnxn = cnxn( $params->get( "Defaultvisual" ) ) ) {
			return $cnxn->get( "id" );
		}
		break;
	case 'creds':
		// See if we have passed a new _c variable
		// @TODO: remove GET before production!  (should we?)
		if ( $origin = get_var( "_c", array( 'post' ) ) ) {
			$c = cnxn( $origin );
			if ( $c ) return $c->get( "id" );
		}
		
		// See if we've been here before
		if ( $origin = get_var( "origin", array( 'session' ) ) ) {
			if ( isset( $origin['c'] ) ) {
				$c = cnxn( $origin['c'] );
				if ( $c ) return $c->get( "id" );
			}
		}
		
		// Next see if we received us/pw vars to determine origin from
		// @TODO:  Cycle through credentials received; not sure how to do this yet - add credentials array to settings?
		
		// Since we have no clue where we are coming from, lets set the default site as the creds origin
		if ( $c = cnxn( $params->get( "Defaultsite" ) ) ) {
			return $c->get( "id" );
		}
		
		// If we are STILL here, try grabbing the visual origin
		if ( $vo = find_origin( "visual" ) ) return $vo;
		
		// We can't figure it out so fail badly!
		return false;
		break;
	case null:
	default:
		if ( $origin = get_var( "origin", array( 'session' ) ) ) return $origin;
		break;
	endswitch;
	
	return $origin;
}


function get_api( $id = null )
{
	if ( $id == null ) return false;
	$CI = & get_instance();
	if (! isset( $CI->cnxnapi[$id] ) ) return false;
	else return $CI->cnxnapi[$id];
}


/**
 * Retrieves and updates an application session (used by renderer)
 * @access		public
 * @version		3.0.0.0.0
 * @param		integer		- $_a: application cnxn id
 * 
 * @return		object of session data
 * @since		3.0.0
 */
function get_application_session( $_a = null, $sess_id = null, $_ov = null )
{
	// Declare an instance
	static $instance;
	
	// Double check we have set the instance or an application id to pull
	if ( ( $instance == null ) && ( $_a == null ) && ( $sess_id == null ) ) return false;
	
	// If this is the first time through build it
	if ( $instance == null ) {
		$CI			= & get_instance();
		$CI->load->model( "session_model" );
		
		$model		= & $CI->session_model;
		$cnxn_lib	=   get_cnxn_library( $_a );
		
		if ( $cnxn_lib === false ) return false;
		
		$sess_id	=   $cnxn_lib->decode_session_id( $sess_id );
		
		if(! ( $model->load( array( 'remote' => $sess_id, 'cnxnid' => $_a ) ) ) ) {
			$model->set( 'cnxnid', $_a );
			$model->set( 'remote', $sess_id );
		}
		
		// See if we are overloading the visual cnxnid
		if ( $_ov != null ) {
			$model->set( "_v", $_ov, 'params' );
		}
		elseif ( $_v = get_var( '_v', array( 'post', 'get' ) ) ) {
			$model->set( "_v", $_v, 'params' );
		}
		// No visual cnxnid sent, see if we have it in the params and retrieve default if not
		elseif (! ( $_v = $model->get( "_v", false, "params" ) ) ) {
			$settings = & Params::getInstance();
			$model->set( "_v", $settings->get( "Defaultvisual", false ), 'params' );
		}
		
		// Save (updates timestamp and visual cnxnid if necessary)
		$model->save();
		
		$instance	= $model->get_properties();
	}
	
	return (object) $instance;
}


/**
 * Gets a specific connection library based on cnxn id
 * @access		public
 * @version		3.0.0.0.0
 * @param		integer		- $id: a connection id to retrieve the library for
 * 
 * @return		object of connection library
 * @since		3.0.0
 */

function get_cnxn_library( $id = null )
{
	if ( $id == NULL ) return false;
	
	if ( $id == 0 ) {
		$CI = & get_instance();
		$CI->load->library( 'cnxns_library' );
		return $CI->cnxns_library;
	}
	
	$cnxn = cnxn( $id );
	
	if (! is_object( $cnxn ) ) return false;
	
	$type = $cnxn->get( "type" );
	
	return cnxn_library( $type, $id );
}


/**
 * Grabs all connections
 * @access		public
 * @version		3.0.0.0.0
 * 
 * @return		array of cnxns
 * @since		3.0.0
 */
function get_cnxns()
{
	static $cnxns = null;
	if ( $cnxns == null ) {
		$CI = & get_instance();
		$CI->load->library( 'cnxns_library' );
		$cnxns = $CI->cnxns_library->get( "cnxns" );
	}
	return $cnxns;
}


/**
 * Retrieves a variable from the input or session, allowing for custom order of retrieval
 * @access		public
 * @version		3.0.0.0.0
 * @param		string		- $name: the name of the variable to find (without 'int_')
 * @param		array		- $order: the search order to follow (defaults to get, post, session)
 * 
 * @return		varies can be value or false on not found
 * @since		3.0.0
 */
function get_var( $name = null, $order = array( 'get', 'post', 'session' ) )
{
	if ( $name == null ) return false;
	if (! is_array( $order ) ) $order = array( $order );
	
	$var	=   false;
	$CI		= & get_instance();
	
	foreach ( $order as $o ) {
		switch ( $o ) {
			case 'get':
				if ( $var = $CI->input->get( $name ) ) return urldecode( $var );
				break;
			case 'post':
				if ( $var = $CI->input->post( $name ) ) return $var;
				break;
			case 'model':
				if ( $name == null ) return false;
				$mname = $name . "_m";
				if (! isset( $CI->$mname ) ) return false;
				else return $CI->$mname;
				break;
			case 'session':
			default:
				if ( $var = $CI->session->userdata( "int_" . $name ) ) return $var;
				break;
		}
	}
	
	return $var;
}


/**
 * Checks to see if a username is an email
 * @access		public
 * @version		3.0.0.0.0
 * @param		string		- $username: the questionable username
 * 
 * @return		boolean true if an email
 * @since		3.0.0
 */
if (! function_exists ( 'is_email' ) ) {
	function is_email( $username) {
		$pattern = "/\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,5}\b/i";
		$match = preg_match( $pattern, $username );
		
		return ( $match > 0 );
	}
}


/**
 * Removes a session from the session model database
 * @access		public
 * @version		3.0.0.0.0
 * @param		integer		- $cnxn_id: the connection id to match to local session_id
 * @param		boolean		- $delete: if set will remove row from DB, else just unset local session id
 * 
 * @since		3.0.0
 */
function remove_session_id( $cnxn_id, $delete = false )
{
	$CI		= & get_instance();
	$CI->load->model( "session_model" );
	
	$model		= & $CI->session_model;
	$session	=   array(	'local'		=> $CI->session->userdata( "session_id" ),
							'cnxnid'	=> $cnxn_id
					);
	if (! $model->load( $session ) ) {
		return;
	}
	
	if ( $delete ) {
		$model->delete( $model->get( "id" ) );
	}
	else {
		$model->set( "local", null );
		$model->save();
	}
	return;
}


/**
 * Called by the individual connection after decoding session variables for storing in database
 * @access		public
 * @version		3.0.0.0.0
 * @param		string		- $sid: contains the remote session id to store
 * @param		integer		- $cnxn_id: the remote connection id
 * 
 * @return		boolean true upon success
 * @since		3.0.0
 */
function save_session_id( $sid, $cnxn_id )
{
	$CI		= & get_instance();
	$CI->load->model( "session_model" );
	
	$model		= & $CI->session_model;
	$session	=   array(	'remote'	=> $sid,
							'cnxnid'	=> $cnxn_id
					);
	
	if(! $model->load( $session ) ) {
		$model->save( $session );
		$model->load( $session );
	}
	
	$model->set( 'local', $CI->session->userdata( "session_id" ) );
	$model->save();
	
	return;
	
}


/**
 * Takes an encoded session array and returns variables
 * @access		public
 * @version		3.0.0.0.0
 * @param		string		- $hash: the encoded session array
 * 
 * @return		array containing data or false on error
 * @since		3.0.0
 */
if (! function_exists ( 'sess_decode' ) ) {
	function sess_decode( $hash = null )
	{
		if (! $hash ) return false;
		
		$params		= & Params :: getInstance();
		$secret		=   $params->get( 'Secret' );
		
		// Get first decode
		$hash		= strrev( $hash );
		$md5hash	= substr( $hash, 0, 32 );
		$encoded	= substr( $hash, 32 );
		$encoded	= base64_decode( $encoded, true );
		$encoded	= unserialize( $encoded );
		
		// Test md5 hash first
		if ( $md5hash != md5( $encoded['salt'] . $secret ) ) {
			debug_error( 'Problem with session hash!', false );
			return false;
		}
		
		// Handle encoded array
		$string		= base64_decode( $encoded['data'], true );
		$key		= md5( $secret . $encoded['salt'] );
		$data		= null;
		$decode		= null;
		
		for ( $i = 0; $i != strlen( $string ); $i++ ) {
			$data .= substr( $string, $i, 1 ) ^ substr( $key, ( $i % strlen( $key ) ), 1 );
		}
		
		for ( $i =0; $i < strlen( $data ); $i++ ) {
			$decode .= ( substr( $data, $i++, 1 ) ^ substr( $data, $i, 1 ) );
		}
		
		return unserialize( $decode );
	}
}


/**
 * Retrieves a type from the connections library if loaded
 * @access		public
 * @version		3.0.0.0.0
 * @param		string		- $name: the hardcoded type to get
 * 
 * @return		object of type or false if not loaded / non-exist
 * @since		3.0.0
 */

function type( $name = null )
{
	if ( $name == null ) return false;
	
	$CI = & get_instance();
	$CI->load->library( 'cnxns_library' );
	$types	= $CI->cnxns_library->get( "types" );
	return ( isset( $types[$name] ) ? $types[$name] : false );
}


/**
 * Retrieves all the types loaded in the library
 * @access		public
 * @version		3.0.0.0.0
 * 
 * @return		array of type objects
 * @since		3.0.0
 */

function types()
{
	$CI = & get_instance();
	$CI->load->library( 'cnxns_library' );
	return $CI->cnxns_library->get( "types" );
}


/**
 * Creates the sys_get_temp_dir function in the event it doesn't exist on this version of php 5
 * @access public
 * 
 * @return string containing temp directory
 * @since  3.0.0
 */
if (! function_exists( 'sys_get_temp_dir' ) ) {
	function sys_get_temp_dir() {
		if( $temp=getenv( 'TMP' ) )		return $temp . DIRECTORY_SEPARATOR;
		if( $temp=getenv( 'TEMP' ) )	return $temp . DIRECTORY_SEPARATOR;
		if( $temp=getenv( 'TMPDIR' ) )	return $temp . DIRECTORY_SEPARATOR;
		$temp=tempnam(__FILE__,'');
		if (file_exists($temp)) {
			unlink($temp);
			return dirname($temp) . DIRECTORY_SEPARATOR;
		}
		return null;
	}
}