<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.0 ( $Id: Render_library.php 363 2012-01-04 17:10:09Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the Render library for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * Render library class
 * @access		public
 * @author		Steven
 * 
 * @since		3.0.0
 */
class Render_library
{
	public	$_enabled		= true;
	public	$_encode		= true;
	private	$__properties	= array();
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $options: an array of options to set at init
	 * 
	 * @since		3.0.0
	 */
	public function __construct( $options = array() )
	{
		$this->set_properties( $options );
		
		if ( ( $this->_build_render_object( $this->_a, 'app_obj' ) ) === false ) {
			debug_error( 'msg.error.constr.appobject' );
			$this->_enabled = false;
			return;
		}
		
		if ( ( $this->_build_render_object( $this->_v, 'site_obj' ) ) === false ) {
			debug_error( 'msg.error.constr.siteobject' );
			$this->_enabled = false;
			return;
		}
		
		$CI = & get_instance();
		$CI->load->helper( "regex" );
		$CI->load->helper( "cnxnmap" );
		
		$this->_build_regex();
	}
	
	
	/**
	 * Method to generate a response back to the calling application - setting headers and xml array
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @return		array containing response
	 * @since		3.0.0
	 */
	public function generate_response()
	{
		return $this->get( 'response', array() );
	}
	
	
	/**
	 * Method to retrieve the site
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		boolean		- $recursive: if set will contain the redirect url
	 * 
	 * @return		instance of object
	 * @since		3.0.0
	 */
	public function retrieve_site( $recursive = false )
	{
		if ( $this->_enabled === false ) {
			debug_error( 'The rendering library is disabled' );
			return false;
		}
		
		$url	=   ( $recursive ? $recursive : $this->site_obj->retrieve_uri->toString() );
		$post	=   $this->site_obj->retrieve_post;
		$optns	=   $this->site_obj->retrieve_options;
		$cache	=   false;
		
		$CI		= & get_instance();
		$params	= & Params::getInstance();
		
		// Check if we are caching the rendered pages
		if ( $params->get( 'Cache' ) ) {
			$cache	= $this->_cache_serialized();
			
			// Check the cache first and return if found
			if ( $response = $CI->cache->get( $cache ) ) {
				$this->set( 'response', $response );
				//return $this;
			}
		}
		
		if (! ( $result = $CI->curl->simple_post( $url, $post, $optns ) ) )
		{
			_d( $url );
			_d( $result );
			// Error message log somehow
			return false;
		}
		_d( $url );
		if ( $redirect = $this->_find_redirect( $result ) ) {
			$result = $this->retrieve_site( $redirect );
		}
		
		if ( $optns['HEADER'] == TRUE ) {
			list( $header, $data ) = explode( "\r\n\r\n", $result, 2 );
			$this->header_info = $header;
		}
		else {
			$data	= $result;
		}
		
		if ( $recursive ) {
			return $result;
		}
		
		// Apply the compiled regular expressions against the resultant data
		foreach ( $this->regex as $regobj ) {
			$data = $regobj->applyRegex( $data );
		}
		
		if ( $this->app_obj->get( 'convertcharacterset', false, 'visuals' ) ) {
			$characterset_regex = $this->site_obj->regex_characterset();
			$characterset_regex->set( "replace", $this->app_obj->get( "characterset" ) );
			$data = $characterset_regex->applyRegex( $data );
			$data	= iconv( strtoupper( $characterset_regex->matches[0]['link'] ), sprintf( "%s//TRANSLIT", strtoupper( $this->app_obj->get( "characterset" ) ) ), $data );
		}
		
		$data	= $this->_split_site( $data );
		
		// Set into the cache if we are using it
		if ( $params->get( 'Cache' ) ) {
			$CI->cache->save( $cache, $data, $params->get( 'CacheTTL' ) );
		}
		
		$this->set( "response", $data );
		
		return $this;
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE PRIVATE
	 * **********************************************************************
	 */
	
	
	/**
	 * Builds and updates the array of regular expression objects
	 * @access		private
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	private function _build_regex()
	{
		// Gather regex first
		$regex = $this->site_obj->regex_gather( array() );
		$regex = $this->app_obj->regex_gather( $regex );
		
		// Update each based on type
		$regex = $this->site_obj->regex_update( $regex );
		$regex = $this->app_obj->regex_update( $regex );
		
		$this->set( "regex", $regex );
	}
	
	
	/**
	 * Builder method to create the site and application render sub-objects
	 * @access		private
	 * @version		3.0.0.0.0
	 * @param		integer		- $cnxn_id: the connection id to build
	 * @param		string		- $name: the name of the object to assign to
	 * 
	 * @since		3.0.0
	 */
	private function _build_render_object( $cnxn_id, $name = "app_obj" )
	{
		if ( $cnxn_id == '0' && $name == 'app_obj' ) {
			$this->$name = new Integrator_Render( $this->get_properties() );
			return;
		}
		
		$cnxn = get_cnxn_library( $cnxn_id );
		
		// Catch any incorrect _a or _v settings without errors being thrown
		if ( $cnxn === false ) {
			debug_error( 'msg.error.nocnxnfound' );
			return false;
		}
		
		if ( $cnxn->get( 'isvisual', false ) == false && $name == 'site_obj' ) {
			debug_error( 'msg.error.incorrectvisual' );
			return false;
		}
		
		//_e( $cnxn );
		$type = ucfirst( $cnxn->get( "type" ) ) . "_Render";
		
		$options	= $this->get_properties();
		if ( $name != "app_obj" ) unset( $options['characterset'] );
		$this->$name = new $type( $options );
	}
	
	
	/**
	 * Generates a serialized cache filename
	 * @access		private
	 * @version		3.0.0.0.0
	 * 
	 * @return		md5 serialized string
	 * @since		3.0.0
	 */
	private function _cache_serialized()
	{
		$serial	= $this->get_properties();
		unset( $serial['regex'] );
		
		$sites	= $this->site_obj->retrieve_options;
		$serial['remote_id']	= ( isset( $sites['COOKIE'] ) ) ? $sites['COOKIE'] : null;
		
		return md5( serialize( $serial ) );
	}
	
	
	/**
	 * Locates the redirect url in the returned response
	 * @access	private
	 * @version	3.0.0
	 * @param	string		- $data: contains headers returned by curl
	 * 
	 * @return	string containing url or false on failure
	 * @since	1.5.3
	 */
	private function _find_redirect($data)
	{
		list($header) = explode("\r\n\r\n", $data, 2);
		$matches = array();
		preg_match('/(Location:|URI:)(.*?)\n/', $header, $matches);
		$url = trim(array_pop($matches));
		$url_parsed = parse_url($url);
		if (isset($url_parsed)) {
			return $url;
		} else {
			return false;
		}
	}
	
	
	/**
	 * Retrieves the branding value
	 * @access		private
	 * @version		3.0.0.0.0
	 * @param		bool		- $tag: if we want the html tag, true else bool
	 * 
	 * @return		string if tag, bool if not
	 * @since		3.0.0
	 */
	private function _get_branding( $tag = true )
	{
		global $license;
		
		if ( $tag ) {
			return ( $license->branding ? "<p style=\"font-size: x-small; \" align=\"center\">Integration by <a href=\"https://www.gohigheris.com\" target=\"blank\" alt=\"custom joomla whmcs integration joomla integration\">Go Higher IS</a></p>" : null );
		}
		else {
			return (bool) $license->branding;
		}
	}
	
	
	/**
	 * Splits the content of the site up into header / footer pieces
	 * @access		private
	 * @version		3.0.0.0.0
	 * @param		string		- $content: contains the site
	 * 
	 * @return		array containing pieces of site
	 * @since		3.0.0
	 */
	private function _split_site( $content = null )
	{
		$data		= $this->site_obj->split_site( $content );
		
		// Set branding
		$branding		= $this->_get_branding( true );
		$data['footer']	= $branding . $data['footer'];
		
		$data			= $this->app_obj->split_site( $data );
		
		// Verify branding remains
		if ( $this->_get_branding( false ) && is_array( $data ) ) {
			$valid = false;
			foreach ( $data as $d ) {
				if ( strpos( $d, $branding ) !== false ) {
					$valid = true;
					break;
				}
			}
			if ( $valid === false ) {
				$data['footer']	= $branding . $data['footer'];
			}
		}
		
		if ( $this->_encode ) {
			foreach ( $data as $k => $v ) {
				$data[$k] = base64_encode( $v );
			}
		}
		
		return $data;
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE COMMON AND PUT HERE SO I DONT HAVE TO SEE THEM :^)
	 * **********************************************************************
	 */
	
	
	/**
	 * Gets a variable from the object
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		string		- $name: the name of the property to get
	 * @param		mixed		- $default: the default value to return if not set
	 * @param		string		- $type: if a parameter, then send the parameter type
	 * 
	 * @return		the value of the property or false on not set
	 * @since		3.0.0
	 */
	public function get( $name, $default = false, $type = 'local' )
	{
		switch( $type ) {
			case 'local':
				return (isset( $this->$name ) ? $this->$name : $default );
				break;
			case 'params':
			default:
				return ( isset( $this->params[$type][$name] ) ? $this->params[$type][$name] : $default );
				break;
		}
	}
	
	
	/**
	 * Gets the properties from the object
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		boolean		- $public: if true only returns public properties
	 * 
	 * @return		array of properties from object
	 * @since		3.0.0
	 */
	public function get_properties( $public = true )
	{
		$vars	= get_object_vars( $this );
		if ( $public ) {
			foreach ( $vars as $key => $value ) {
				if ( in_array( $key, array( 'app_obj', 'site_obj' ) ) ) {
					unset( $vars[$key] );
					continue;
				}
				if ( '__' == substr( $key, 0, 2 ) ) {
					unset( $vars[$key] );
				}
			}
		}
		return $vars;
	}
	
	
	/**
	 * Handles settings specific values to the object
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		string		- $name: the property to set
	 * @param		mixed		- $value: the value to set property to
	 * 
	 * @return		instance of object
	 * @since		3.0.0
	 */
	public function set( $name, $value, $type = 'local' )
	{
		switch( $type ) {
			case 'local':
				$this->$name = $value;
				break;
			case 'params':
			default:
				$this->params[$type][$name] = $value;
				break;
		}
		return $this;
	}
	
	
	/**
	 * Sets properties for the object in one fell swoop
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $data: contains assoc array of the properties to set
	 * 
	 * @return		instance of object
	 * @since		3.0.0
	 */
	public function set_properties( $data )
	{
		if (! is_array( $data ) ) return false;
		ksort( $data );
		foreach ( $data as $k => $v ) {
			$this->$k = $v;
		}
		return $this;
	}
	
	
	/**
	 * Getter method
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		string		- $name: the name of the property to get
	 * 
	 * @return		mixed the value of the property or null if not set
	 * @since		3.0.0
	 */
	public function __get( $name )
	{
		return ( isset( $this->__properties[$name] ) ? $this->__properties[$name] : null );
	}
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		string		- $name: the name of the property to set
	 * @param		mixed		- $value: the value to set the property to
	 * 
	 * @since		3.0.0
	 */
	public function __set( $name, $value )
	{
		if ( in_array($name, array( '_a', '_v', 'page', 'language', 'characterset', 'app_obj', 'site_obj', 'isssl', 'session_id', 'params', 'regex', 'content', 'header', 'footer', 'response' ) ) ) {
			$this->$name = $value;
			return;
		}
		$this->__properties[$name] = $value;
	}
}


class Integrator_Render extends Render_library
{
	/**
	 * Constructor method called by parent Render_library
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $options: an array of options to set to the object at init
	 * 
	 * @since		3.0.0
	 */
	public function __construct( $options = array() )
	{
		$this->set_properties( $options );
		
		$params		= & Params::getInstance();
		
		$this->set( "unicode",	( $params->get( "UnicodeMatching", false ) ? "u" : "" ) );
	}
	
	
	/**
	 * Gathers any regular expressions to run against the site for this application
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $regex: contains any already gathered regular expressions from site
	 * 
	 * @return		array containing more regular expression objects
	 * @since		3.0.0
	 */
	public function regex_gather( $regex )
	{
		// Grab the unicode tag if we are using it
		$u			= $this->get( "unicode" );
		
		return $regex;
	}
	
	
	/**
	 * Updates the regular expression object array with data from this connection
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $regex: array of regular expression IntRegex objects
	 * 
	 * @return		array containing updated regex objects array
	 * @since		3.0.0
	 */
	public function regex_update( $regex )
	{
		foreach ( $regex as $regobj ) {
			
		}
		return $regex;
	}
	
	
	/**
	 * Permits for splitting content further down beyond header and footer for this application
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $content: associative array with header and footer from site
	 * 
	 * @return		array containing final split components to return to application
	 * @since		3.0.0
	 */
	public function split_site( $content )
	{
		$parts = preg_split( '#(</head[^>]*>)#', $content['header'], -1, PREG_SPLIT_DELIM_CAPTURE );
		
		$content['header']	= $parts[0];
		$content['body']	= $parts[1] . $parts[2];
		return $content;
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE OVERRIDES OF PARENT
	 * **********************************************************************
	 */
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		string		- $name: the name of the property to set
	 * @param		mixed		- $value: the value to set the property to
	 * 
	 * @since		3.0.0
	 * @see			Render_library::__set();
	 */
	public function __set( $name, $value )
	{
		if ( in_array($name, array( '_a', 'cnxn_id' ) ) ) {
			$this->cnxn_id = $value;
			return;
		}
		parent::__set( $name, $value );
	}
}