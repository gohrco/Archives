<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.0 ( $Id: install_check.php 373 2012-01-26 18:44:16Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is a hook file to check for the install folder
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


function install_check()
{
	return;
	$ci	= & get_instance();
	
	// Be sure we are in the admin backend and logged in
	if (	( ! in_array( $ci->router->fetch_class(), array( 'admin', 'settings', 'cnxns', 'pagemap', 'langmap', 'usermgr', 'users', 'license' ) ) ) ||	// Not in admin
			(
				( $ci->router->fetch_class() == 'admin' ) &&										// Admin
				( in_array( $ci->router->fetch_method(), array( 'login', 'logout', 'complete' ) ) )	// but not logged in
			 )
		) {
		return;
	}
	
	// Check to see if we have a path to the install
	if ( file_exists( BASEPATH . 'install/index.php' ) ) {
		include_once( BASEPATH . 'install/index.php' );
		
		$params		= & Params::getInstance();
		$current	=   $params->get( 'Version' );
		
		switch( version_compare( $current, INTEGRATOR_INSTALL ) ):
		// --------------------------------
		// Upgrade in order (newer vers in install)
		case -1:
			redirect( BASE_URL . 'install/index.php');
		break;
		// --------------------------------
		// Same version as installed (0) or installed version is newer than install folder (1)
		case 0:
		case 1:
			redirect( 'admin/complete', 'refresh' );
		break;
		// --------------------------------
		endswitch;
		
		// End result:  user should remove install folder OR upgrade
	}
}