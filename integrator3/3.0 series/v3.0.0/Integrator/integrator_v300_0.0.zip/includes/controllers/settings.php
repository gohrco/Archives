<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.0 ( $Id: settings.php 331 2011-11-24 03:13:26Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the settings controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Settings controller of application
 * @version		3.0.0.0.0
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Settings extends Admin_Controller
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::Admin_Controller();
		$this->load->language( 'settings' );
	}
	
	
	/**
	 * Allows for modification of the settings for the Integrator
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	public function index()
	{
		$this->load->helper( "cnxn" );
		
		$model		= & $this->get_model();
		$fields		= & $this->fields_library;
		
		$fields->load( 'settings/global', null, true );
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == TRUE ) {
			$post	= $this->_assemble_post();
			$model->set_properties( $post );
		}
		
		if ( $this->form_validation->run() == true ) {
			if ( $model->save() ) {
				
				$this->session->set_flashdata('success_message', lang( 'msg.success.savedsettings' ) );
				
				if ( $this->input->post( 'submit', false ) ) {
					redirect("settings", 'refresh');
				}
				else {
					redirect( 'admin', 'refresh' );
				}
			}
			else {
				$this->session->set_flashdata( 'error_message', lang( 'msg.error.savedsettings' ) );
			}
		}
		
		$fields->set_values( array( 'global'	=> $model->get_properties() ) );
		$fields->set_values( array( 'email'		=> $model->get_properties() ) );
		$fields->set_values( array( 'users'		=> $model->get_properties() ) );
		$fields->set_values( array( 'visual'	=> $model->get_properties() ) );
		$fields->set_values( array( 'registration'	=> $model->get_properties() ) );
		
		$this->data	+= $fields->render();
		
		$this->template
				->set_partial( "body", 'partials/settings' )
				->build( "admin", $this->data );
	}
	
	
	/**
	 * Means to assemble the post data in a consistent manner
	 * @access		private
	 * @version		3.0.0.0.0
	 * 
	 * @return		array containing posted data
	 * @since		3.0.0
	 */
	private function _assemble_post()
	{
		$post	= $this->input->post();
		$data	= array();
		foreach( $post['params'] as $key ) {
			foreach ( $key as $k => $v ) {
				$data[$k] = $v;
			}
		}
		return $data;
	}
}