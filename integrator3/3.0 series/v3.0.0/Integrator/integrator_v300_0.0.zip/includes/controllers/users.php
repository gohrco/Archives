<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.0 ( $Id: users.php 294 2011-09-13 20:23:34Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the user controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * User Controller
 * @version		3.0.0.0.0
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Users extends Admin_Controller
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::Admin_Controller();
		$this->load->model( "auth_model" );
		$this->load->language( 'users' );
	}
	
	
	/**
	 * Activates a user account
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		integer		- $id: the user id to activate
	 * 
	 * @since		3.0.0
	 */
	public function activate( $id = null )
	{
		if ( $id == null ) redirect( 'users', 'refresh' );
		
		$activation = ( $this->auth->is_admin() ? $this->auth->activate( $id ) : false );
		
		if ( $activation ) {
			$this->session->set_flashdata( 'success_message', $this->auth->messages() );
		}
		else {
			$this->session->set_flashdata('alert_message', $this->auth->errors());
		}
		
		redirect( 'users', 'refresh' );
	}
	
	
	/**
	 * Method to change a users' password
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		integer		- $id: passed by the URL to identify which user to change password for
	 * 
	 * @since		3.0.0
	 */
	public function change_password( $id = null )
	{
		$this->form_validation->set_rules('new', lang( 'users.change_password.newpw' ), 'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|max_length[' . $this->config->item('max_password_length', 'ion_auth') . ']|matches[new_confirm]');
		$this->form_validation->set_rules('new_confirm', lang( 'users.change_password.confpw' ), 'required');
		
		$user_id = ( $id == null ? $this->session->userdata['user_id'] : $id );
		$user = $this->auth->get_user( $user_id );

		if ($this->form_validation->run() == false)
		{
			$this->data['error_message'] .= $this->auth->errors();
			
			$this->data['new_password'] = array('name' => 'new',
				'id' => 'new',
				'type' => 'password',
			);
			$this->data['new_password_confirm'] = array('name' => 'new_confirm',
				'id' => 'new_confirm',
				'type' => 'password',
			);
			$this->data['user_id'] = array('name' => 'user_id',
				'id' => 'user_id',
				'type' => 'hidden',
				'value' => $user->id,
			);
			
			//render
			$this->template
					->set_partial( "body", 'users/change_password' )
					->build('admin', $this->data);
		}
		else
		{
			$user		= $this->auth->get_user( $user_id );
			$identify	= $this->config->item('identity', 'ion_auth');
			$identity	= $user->$identify;
			
			$change = $this->auth->change_password($identity, $this->input->post('old'), $this->input->post('new'));
			
			if ($change)
			{ //if the password was successfully changed
				$this->session->set_flashdata('success_message', $this->auth->messages());
				$uri	= ( $user->id == $this->session->userdata['user_id'] ? "admin/logout" : "users/index" );
				redirect($uri, 'refresh');
			}
			else
			{
				$this->session->set_flashdata('error_message', $this->auth->errors());
				redirect('users/change_password/' . $user_id, 'refresh');
			}
		}
	}
	
	
	/**
	 * Method for creating a new user
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	public function create_user()
	{
		if (! $this->auth->logged_in() || !$this->auth->is_admin() )  redirect('admin/logout', 'refresh');
		
		$fields		= & $this->fields_library;
		$fields->load( 'users/edit' );
		
		$this->form_validation->set_rules( $fields->validation() );
				
		if ($this->form_validation->run() == true) {
			$username	= $this->input->post( 'username' );
			$email		= $this->input->post('email');
			$password	= $this->input->post('password');
			$group_name	= $this->auth_model->get_group( $this->input->post( 'group_id' ) )->name;
			
			$additional_data = array(
				'first_name' => $this->input->post('first_name'),
				'last_name' => $this->input->post('last_name'),
				'company' => $this->input->post('company'),
			);
		}
		
		if ( $this->form_validation->run() == true && $this->auth->register( $username, $password, $email, $additional_data, $group_name ) ) {
			$this->session->set_flashdata('success_message', lang( 'msg.create_user.success' ) );
			redirect("users", 'refresh');
		}
		else {
			$this->data['action']	= 'users/create_user';
			$this->data['submit']	= 'button.create_user';
			$fields->set_values( array( 'id' => 0 ) );
			
			$this->data	= array_merge( $this->data, $fields->render() );
			
			$this->data['error_message'] .= $this->auth->errors();
			
			$this->template
					->set_partial( "body", 'users/form' )
					->build('admin', $this->data);
		}
	}
	
	
	/**
	 * Method to deactivate a user
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	public function deactivate()
	{
		$fields		= & $this->fields_library;
		$fields->load( 'users/verify' );
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( ( $this->form_validation->run() == true ) && ( $this->input->post( 'confirm' ) == '1' ) ) {
			// Ensure we are logged in (how we couldn't be not sure)
			if ($this->auth->logged_in() && $this->auth->is_admin()) {
					$this->auth->deactivate( $this->input->post( 'id' ) );
					$this->session->set_flashdata( 'success_message', $this->auth->messages() );
				}
		}
		
		redirect('users', 'refresh');
		
	}
	
	
	/**
	 * Method to delete a user
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	public function delete_user()
	{
		$fields		= & $this->fields_library;
		$fields->load( 'users/verify' );
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( ( $this->form_validation->run() == true ) && ( $this->input->post( 'confirm' ) == '1' ) ) {
			// Ensure we are logged in (how we couldn't be not sure)
			if ($this->auth->logged_in() && $this->auth->is_admin()) {
				if ( $result = $this->auth->delete_user( $this->input->post( 'id' ) ) ) {
					$this->session->set_flashdata( 'success_message', $this->auth->messages() );
				}
				else {
					$this->session->set_flashdata( 'error_message', $this->auth->errors() );
				}
			}
		}
		
		redirect('users', 'refresh');
	}
	
	
	/**
	 * Method to edit a selected user's information
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		integer		- $id: passed in url to specify which user to get, or else gets admin user
	 * 
	 * @since		3.0.0
	 */
	public function edit_user( $id = NULL )
	{
		$fields		= & $this->fields_library;
		$fields->load( 'users/edit' );
		$fields->set( 'password', 'edit.password.desc', 'desc' );
		
		$id		=   (int) ( $id === NULL ? $this->input->post( 'user_id' ) : $id );
		$user	=   $this->auth->get_user_array( $id );
		unset( $user['password'] );  // Ensure the hash isn't sent out
		
		$fields->set_values( $user );
		$this->form_validation->set_rules( $fields->validation() );
				
		if ($this->form_validation->run() == true) {
			$fields->set_values( $this->input->post() );
			
			$update	= $fields->get_values();
			
			unset( $update['password-confirm'] );
			if ( empty( $update['password'] ) ) unset( $update['password'] );
			
			$user = $update;
		}
		
		if ($this->form_validation->run() == true && $this->auth->update_user( $id, $user ) ) {
			$this->session->set_flashdata('success_message', lang( 'msg.edit_user.success' ) );
			redirect("users", 'refresh');
		}
		else {
			$this->data['action']	= 'users/edit_user/'.$id;
			$this->data['submit']	= 'button.edit_user';
			
			$this->data	= array_merge( $this->data, $fields->render() );
			
			$this->data['error_message'] .= $this->auth->errors();
			
			$this->template
					->set_partial( "body", 'users/form' )
					->build('admin', $this->data);
		}
	}
	
	
	/**
	 * Method for displaying all users for management
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	public function index()
	{
		//list the users
		$this->data['users'] = $this->auth->get_users_array();
		
		$this->template
					->set_partial( "body", 'users/index' )
					->build('admin', $this->data);
	}
	
	
	/**
	 * Provides a common verification facility
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		string		- $task: the action to perform upon verification (deactivate, delete_user)
	 * @param		integer		- $id: the id of the user to perform the action against
	 * 
	 * @since		3.0.0
	 */
	public function verify( $task = null, $id = null )
	{
		if ( in_array( null, array( $task, $id ) ) ) redirect( 'users/index', 'refresh' );
		
		$fields		= & $this->fields_library;
		$fields->load( 'users/verify' );
		$fields->set( 'id', $id );
		$fields->set( 'confirm', 'verify.' . $task, 'lang' );
		$fields->set( 'confirm', 'verify.' . $task . '.desc', 'desc' );
		
		$this->data	= array_merge( $this->data, $fields->render() );
		
		$this->data['action']				= 'users/' . $task . '/' . $id;
		$this->data['submit']				= 'button.' . $task;
		$this->data['content_header']		= 'verify.' . $task;
		$this->data['content_subheader']	= 'verify.' . $task . ".desc";
		
		$this->template
					->set_partial( "body", 'users/form' )
					->build('admin', $this->data);
	}
}