<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.0 ( $Id: admin.php 393 2012-02-21 18:08:21Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the help controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Entry point for configuration and administration of application
 * @version		3.0.0.0.0
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Help extends Admin_Controller
{
	/**
	 * Constructor class
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::Admin_Controller();
		
		$this->load->language( 'help' );
	}
	
	
	
	public function documentation()
	{
		$gohigher	= config_item('gohigher');
		$uri = new Uri( $gohigher['documentation'] );
		redirect( $uri->toString(), 'redirect' );
	}
	
	
	/**
	 * Assembles control panel page
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	public function index()
	{
		$this->data['status']	= $this->get_box( 'cnxnstatus' );
		$this->data['log']		= $this->get_box( 'userlog' );
		$this->data['rss']		= $this->get_box( 'rss' );
		$this->data['steps']	= $this->get_box( 'stepbystep' );
		
		// Grab the latest version
		$latest_version = (string) @file_get_contents( "http://www.gohigheris.com/integrator_currentversion.txt" );
		$this->data['update']	= ( '3.0.0.0.0' < $latest_version ? $latest_version : false );
		
		$this->template
				->set_partial( 'admin-cnxnhealth',	'admin/box/cnxnhealth' )
				->set_partial( 'admin-log',			'admin/box/log' )
				->set_partial( 'admin-rss',			'admin/box/rss' )
				->set_partial( 'admin-update',		'admin/box/update' )
				->set_partial( 'admin-stepbystep',	'admin/box/stepbystep' )
				->set_partial( 'body', 				'admin/index' )
				->build('admin', $this->data);
		
	}
	
	
	
}

?>