<?php defined('BASEPATH') OR exit('No direct script access allowed');
/*
|--------------------------------------------------------------------------
| Language Translations for the Menu
|--------------------------------------------------------------------------
| version 3.0.0
|--------------------------------------------------------------------------
*/
$lang['home']			= "Dashboard";
$lang['globalsettings']	= "Global Settings";
$lang['connections']	= "Connections";
$lang['addnewcnxn']			= "Add New Connection";
$lang['rendering']		= "Rendering";
$lang['pagemaps'] 			= "Page Maps";
$lang['langmaps']			= "Language Maps";
$lang['usermgr']		= "User Management";
$lang['finduser'] 			= "Find User";
$lang['createuser']			= "Create User";
$lang['modifyuser']			= "Modify User";
$lang['userlog']			= "User Log";
$lang['manageadmins']	= "Manage Admins";
