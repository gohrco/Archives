<?php

$form['find']	= array(
	'user'	=> array(
		'value'			=> null,
		'order'			=> 10,
		'type'			=> 'text',
		'validation'	=> 'required|xss_clean'
	)
);

$form['modify/cnxn']	= array(
	'cnxnid' => array(
			'value'			=> null,
			'order'			=> 10,
			'type'			=> 'dropdown-cnxns',
			'validation'	=> 'required|alpha_dash'
		)
);

$form['modify/user']	= array(
	'user' => array(
			'apiname'		=> null,
			'value'			=> null,
			'order'			=> 10,
			'type'			=> 'text',
			'validation'	=> 'required|xss_clean',
			'lang'			=> 'label.modifyuser',
			'desc'			=> 'desc.modifyuser'
		)
);


$form['remove/confirm']	= array(
	'confirm' => array(
		'value'			=> null,
		'order'			=> 10,
		'type'			=> 'yesno',
		'validation'	=> 'required|is_natural',
	)
);