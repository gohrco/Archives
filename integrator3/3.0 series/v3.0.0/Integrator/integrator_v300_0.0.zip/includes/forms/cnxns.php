<?php

$form['add']	= array(
	'type'	=> array(
		'apiname'		=> null,
		'value'			=> null,
		'order'			=> 10,
		'type'			=> 'dropdown-cnxntypes',
		'validation'	=> 'required|alpha_dash'
	)
);