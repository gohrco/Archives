<?php

$form['global']	= array(
	'Sitename' => array(
			'value'			=> 'Integrator',
			'order'			=> 10,
			'type'			=> 'text',
			'validation'	=> 'required|xss_clean'
		),
	'Enable' => array(
			'apiname'		=> null,
			'value'			=> false,
			'order'			=> 20,
			'type'			=> 'yesno',
			'validation'	=> 'required|is_natural'
		),
	'Debug' => array(
			'apiname'		=> null,
			'value'			=> false,
			'order'			=> 30,
			'type'			=> 'yesno',
			'validation'	=> 'required|is_natural'
		),
	'Secret' => array(
			'apiname'		=> null,
			'value'			=> null,
			'order'			=> 40,
			'type'			=> 'text',
			'validation'	=> 'required|xss_clean'
		),
);

$form['email'] = array(
	'Emailprotocol'	=> array(
			'value'			=> 'sendmail',
			'order'			=> 10,
			'type'			=> 'dropdown',
			'validation'	=> 'required'
	),
	'Emailsmtpport'	=> array(
			'value'			=> '25',
			'order'			=> 20,
			'type'			=> 'text',
			'validation'	=> ''
	),
	'Emailsmtphost'	=> array(
			'value'			=> null,
			'order'			=> 30,
			'type'			=> 'text',
			'validation'	=> 'xss_clean'
	),
	'Emailsmtpuser'	=> array(
			'value'			=> null,
			'order'			=> 40,
			'type'			=> 'text',
			'validation'	=> 'xss_clean'
	),
	'Emailsmtppass'	=> array(
			'value'			=> null,
			'order'			=> 50,
			'type'			=> 'password',
			'validation'	=> 'xss_clean'
	),
	'Emailfromname'	=> array(
			'value'			=> 'Integrator Administrator',
			'order'			=> 60,
			'type'			=> 'text',
			'validation'	=> 'required|xss_clean'
	),
	'Emailaddress'	=> array(
			'value'			=> 'admin@yourdomain.com',
			'order'			=> 70,
			'type'			=> 'text',
			'validation'	=> 'required|valid_email'
	)
);

$form['users']	= array(
	'EnableUser' => array(
		'value'			=> false,
		'order'			=> 10,
		'type'			=> 'yesno',
		'validation'	=> 'required|is_natural'
		),
	'DisplayLogin' => array(
		'value'			=> true,
		'order'			=> 15,
		'type'			=> 'yesno',
		'validation'	=> 'required|is_natural'
	),
	'SessionTimeout' => array(
		'value'			=> 7200,
		'order'			=> 20,
		'type'			=> 'text',
		'validation'	=> 'required|is_numeric'
	),
	'Defaultuser' => array(
			'order'			=> 30,
			'type'			=> 'dropdown-cnxns',
			'validation'	=> ''
		),
	'UseSSL' => array(
			'apiname'		=> null,
			'value'			=> true,
			'order'			=> 50,
			'type'			=> 'dropdown',
			'validation'	=> 'required'
		),
);

$form['visual'] = array(
	'EnableVisual' => array(
			'apiname'		=> null,
			'value'			=> false,
			'order'			=> 10,
			'type'			=> 'yesno',
			'validation'	=> 'required|is_natural'
		),
	'Defaultvisual' => array(
			'apiname'		=> null,
			'value'			=> null,
			'order'			=> 30,
			'type'			=> 'dropdown-cnxnvisual',
			'validation'	=> ''
		),
	'UnicodeMatching' => array(
			'apiname'		=> null,
			'value'			=> true,
			'order'			=> 40,
			'type'			=> 'yesno',
			'validation'	=> 'required|is_natural'
		),
	'Cache' => array(
			'value'			=> false,
			'order'			=> 60,
			'type'			=> 'yesno',
			'validation'	=> 'required|is_natural'
		),
	'CacheTTL' => array(
			'value'			=> 300,
			'order'			=> 70,
			'type'			=> 'text',
			'validation'	=> 'required|is_numeric'
		),
	'Clearcache' => array(
			'value'			=> null,
			'order'			=> 80,
			'type'			=> 'checkbox',
			'validation'	=> 'xss_clean'
		),
);

$form['registration']	= array(
	'EnableRegistration' => array(
			'value'			=> true,
			'order'			=> 10,
			'type'			=> 'yesno',
			'validation'	=> 'required|is_natural'
		),
	'EnableCSValidation' => array(
			'value'			=> true,
			'order'			=> 20,
			'type'			=> 'yesno',
			'validation'	=> 'required|is_natural'
		),
	'DefaultVisualreg' => array(
			'value'			=> null,
			'order'			=> 30,
			'type'			=> 'dropdown-cnxnvisual',
			'validation'	=> ''
		),
	'RegRedirectionUrl' 	=> array(
			'value'			=> "http://",
			'order'			=> 40,
			'type'			=> 'text',
			'validation'	=> 'xss_clean'
		),
	'RecaptchaEnable' => array(
			'value'			=> true,
			'order'			=> 80,
			'type'			=> 'yesno',
			'validation'	=> 'required|is_natural'
		),
	'RecaptchaPublickey' 	=> array(
			'value'			=> "",
			'order'			=> 90,
			'type'			=> 'text',
			'validation'	=> ''
		),
	'RecaptchaPrivatekey' 	=> array(
			'value'			=> "",
			'order'			=> 100,
			'type'			=> 'text',
			'validation'	=> ''
		),
	'RecaptchaTheme' 	=> array(
			'value'			=> 'red',
			'order'			=> 110,
			'type'			=> 'dropdown',
			'validation'	=> ''
		),
	'RecaptchaLang' 	=> array(
			'value'			=> 'en',
			'order'			=> 120,
			'type'			=> 'dropdown',
			'validation'	=> ''
		),
	'FieldOrder'		=> array(
			'array'			=> true,
			'value'			=> null,
			'order'			=> 130,
			'type'			=> 'sortfields',
			'validation'	=> 'required'
		),
);
