<?php

$form['edit']	= array(
	'username'	=> array(
		'value'			=> null,
		'order'			=> 10,
		'type'			=> 'text',
		'validation'	=> 'required|xss_clean'
	),
	'first_name' => array(
		'value'			=> null,
		'order'			=> 20,
		'type'			=> 'text',
		'validation'	=> 'required|xss_clean'
	),
	'last_name' => array(
		'value'			=> null,
		'order'			=> 30,
		'type'			=> 'text',
		'validation'	=> 'required|xss_clean'
	),
	'email' => array(
		'value'			=> null,
		'order'			=> 40,
		'type'			=> 'text',
		'validation'	=> 'required|xss_clean|valid_email'
	),
	'company' => array(
		'value'			=> null,
		'order'			=> 50,
		'type'			=> 'text',
		'validation'	=> 'xss_clean'
	),
	'id' => array(
		'value'			=> null,
		'order'			=> 60,
		'type'			=> 'hidden',
		'validation'	=> 'required|is_numeric'
	),
	'group_id' => array(
		'value'			=> null,
		'order'			=> 70,
		'type'			=> 'user-group',
		'validation'	=> 'required|numeric|xss_clean'
	),
	'password' => array(
		'value'			=> null,
		'order'			=> 80,
		'type'			=> 'password',
		'validation'	=> 'xss_clean'
	),
	'password-confirm' => array(
		'value'			=> null,
		'order'			=> 90,
		'type'			=> 'password',
		'validation'	=> 'matches[password]|xss_clean'
	)
);

$form['verify']	= array(
	'confirm' => array(
		'value'			=> null,
		'order'			=> 10,
		'type'			=> 'yesno',
		'validation'	=> 'required|is_numeric',
		'lang'			=> 'deactivate.confirm',
		'desc'			=> 'deactivate.confirm.desc'
	),
	'id'	=> array(
		'value'			=> null,
		'order'			=> 20,
		'type'			=> 'hidden',
		'validation'	=> 'required'
	)
);

$form['forgot_password'] = array(
	'email' => array(
		'value'			=> null,
		'order'			=> 10,
		'type'			=> 'text',
		'validation'	=> 'required|valid_email'
	),
);

$form['login']	= array(
	'username' => array(
		'value'			=> null,
		'order'			=> 10,
		'type'			=> 'text',
		'validation'	=> 'required|xss_clean'
	),
	'password' => array(
		'value'			=> null,
		'order'			=> 20,
		'type'			=> 'password',
		'validation'	=> 'required'
	),
	'remember' => array(
		'value'			=> null,
		'order'			=> 30,
		'type'			=> 'checkbox',
		'validation'	=> ''
	)
);