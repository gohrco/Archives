<?php
/* SECURITY CHECKPOINT */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Overloads the Exceptions class to afford checking of response types
 * @version		3.0.0.0.0
 * 
 * @since		3.0.0
 * @author		Steven
 */
class MY_Session extends CI_Session
{
	public function sess_update()
	{
		// skip the session update if this is an AJAX call!
		if ( ! IS_AJAX ) {
			parent::sess_update();
		}
	}
}