<?php


class Fusion_API extends API_Library
{
	protected		$apioptions	= array();
	protected		$apipost	= array();
	protected		$apiput		= array();
	protected		$apiuri		= null;
	protected		$apiurl		= null;
	
	
	public function __construct( $options = array() )
	{
		$CI	= & get_instance();
		$CI->load->helper( 'simplexml' );
		parent::__construct( $options );
		
	}
	
	
	public function load( $options )
	{
		parent::load( $options );
		
		// =====================================
		// ---BEGIN: Set default api options
		$apioptions	= $this->get( 'apioptions' );
			$apioptions['HEADER'] =  true;
			$apioptions['RETURNTRANSFER'] = true;
		$this->set( 'apioptions', $apioptions );
		// ---END:   Set default api options
		// =====================================
		// ---BEGIN: Setting GLOBAL API curl options
		$apioptions	= $this->get( 'apioptions' );
			if ( $this->get( 'sslverify', 0, 'api' ) == 1 ) {
				$apioptions['SSL_VERIFYHOST'] = true;
				$apioptions['SSL_VERIFYPEER'] = true;
			}
		$this->set( 'apioptions', $apioptions );
		// ---END:   Setting GLOBAL API curl options
		// =====================================
		// ---BEGIN: Setting API url
		$url 	=   $this->get( "apiurl", $this->get( 'baseurl', null, 'params' ), 'api' );
		$uri	= & Uri::getInstance( $url );
		$uri->setScheme( "http" . ( ( $this->get( "sslverify", 0, 'api' ) == 1 ) ? "s" : "" ) );
		$uri->setPath( rtrim( $uri->getPath(), "/" ) . "/api/index.php" );
		$this->set( "apiuri", $uri );
		//echo '<pre>'.print_r($uri,1); die();
		// ---END:   Setting API url
		// =====================================
		// ---BEGIN: Setting API curl options
		$apioptions	= $this->get( 'apioptions' );
			// Do something if needed
		$this->set( 'apioptions', $apioptions );
		// ---END:   Setting API curl options
		// =====================================
		// ---BEGIN: Setting API variables
		$apikey		=   $this->get( 'apikey', null, 'api' );
		$salt		=   mt_rand();
		$signature	=   base64_encode( hash_hmac( 'sha256', $salt, $this->get( 'apisecret', null, 'api' ), true ) );
		
		$apipost	= $this->get( "apipost" );
			$apipost['apikey']		= $apikey;
			$apipost['salt']		= $salt;
			$apipost['signature']	= $signature;
			$apipost['IntAPI']			= true;
		$this->set( "apipost", $apipost );
		//
		// =====================================
		//
		$apiput		= $this->get( 'apiput' );
			$apiput['apikey']		= $apikey;
			$apiput['salt']			= $salt;
			$apiput['signature']	= urlencode( $signature );
		$this->set( 'apiput', $apiput );
		// ---END:   Setting API variables
		// =====================================
		
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE API FUNCTIONS AND ARE CALLED DIRECTLY
	 * **********************************************************************
	 */

	

	/**
	 * Called to authenticate a set of user credentials
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $post: an array of variables to post (should be empty if no child library)
	 * 
	 * @return		boolean true if authenticated, false if failed
	 * @since		3.0.0
	 */
	public function authenticate( $post = array() )
	{
		$credentials	= get_var( "credentials" );
		
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		$post['credentials']	= $credentials;
		
		// Create URL
		$uri	=   $this->get( 'apiuri' );
			$uri->setVar( 'e', '/Integrator/Intuser/Authenticate' );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns );
		
		if ( $result === false ) {
			return false;
		}
		
		$result = simpleXMLToArray( $result );
		
		return ( $result['result'] == 'success' ? true : false );
	}
	
	
	/**
	 * Retrieves the languages on this connection
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @return		array containing either the languages or empty array
	 * @since		3.0.0
	 */
	public function get_languages()
	{
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		
		$uri	=   $this->get( 'apiuri' );
			$uri->setVar( 'e', '/Integrator/Intcore/GetLanguages' );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns );
		
		if ( $result === false ) return false;
		
		$data	= array();
		foreach ( $result->language as $language ) {
			$data["{$language->value}"] = "{$language->name}";
		}
		
		return $data;
	}
	
	
	/**
	 * Retrieves missing credentials from the connection
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		string		- $credential: the item being sought
	 * 
	 * @return		string containing the found item or false on error or nothing found
	 * @since		3.0.0
	 */
	public function get_missing_credential( $credential = 'password' )
	{
		$missing_item = false;
		switch( $credential ):
		case 'password':
		default:
			// We can't get a password from Fusion
			$missing_item = false;
			break;
		endswitch;
		return $missing_item;
	}
	
	
	/**
	 * Retrieves the pages in this connection
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @return		array containing the pages on this connection
	 * @since		3.0.0
	 */
	public function get_pages()
	{
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		
		$uri	=   $this->get( 'apiuri' );
			$uri->setVar( 'e', '/Integrator/Intcore/GetPages' );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns );
		
		if ( $result === false ) return false;
		
		$data	= array();
		foreach ( $result->page as $page ) {
			$data["{$page->value}"] = "{$page->name}";
		}
		
		return $data;
	}
	
	
	/**
	 * Called to test a connection to ensure it responds
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		mixed		- $check: if a string, assume its an URL, if array test credentials
	 * 
	 * @return		mixed depending on need boolean true if responsive
	 * @since		3.0.0
	 */
	public function ping( $check = null )
	{
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		
		if ( is_string( $check ) ) {
			$purl	= $check;
			$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => false );
			
			return $this->_call_api( $purl, $post, $optns );
		}
		else {
			$uri	=   $this->get( 'apiuri' );
				$uri->setVar( 'e', '/Core/Test' );
			$purl	= $uri->toString();
			$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
			
			$result	= $this->_call_api( $purl, $post, $optns );
			$error	= $this->_check_for_errors();
			return ( $error === false ? true : $error );
		}
		
		
	}
	
	
	/**
	 * Creates a new user in WHMCS
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $post: variables to post to the API
	 * 
	 * @return		true on success, false otherwise
	 * @since		3.0.0
	 */
	public function user_create()
	{
		$data	= $this->get_data();
		unset( $data['userid'] );
		
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		$post['update']	= $data;
		
		// Create URL
		$uri	=   $this->get( 'apiuri' );
			$uri->setVar( 'e', '/Integrator/Intuser/Create' );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns );
		
		if ( $result !== false ) {
			$result = simpleXMLToArray( $result );
		}
		
		return ( $result['result'] == 'success' ? true : 'some error' );
	}
	
	
	/**
	 * Finds a user by email
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		boolean		- $data: if we want the data back set true, else return boolean
	 * 
	 * @return		varies can be boolean or the data result
	 * @since		3.0.0
	 */
	public function user_find( $data = false )
	{
		// This is what we are looking for
		$find		= $this->get_data();
		
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		
		// Grab all users to find ID with email address
		$uri	=   $this->get( 'apiuri' );
			$uri->setVar( 'e', '/Integrator/Intuser/Find' );
			$uri->setVar( 'email', $find['email'] );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns );
		
		if ( $result !== false ) {
			$result = simpleXMLToArray( $result );
			$this->place_data( $result );
		}
		else {
			$this->set_error( 'No User Found' );
		}
		
		return ( $result !== false ? ( $data ? $result : true ) : 'Unknown error' );
	}
	
	
	/**
	 * Updates user information on this connection
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $post: an array of variables to update
	 * 
	 * @return		boolean true if successful, error message otherwise
	 * @since		3.0.0
	 */
	public function user_update()
	{
		// For post calls, we put the api vars in here
		$post			= $this->get( 'apipost' );
		$post['user']	= $this->get_data();
		
		// Create URL
		$uri	=   $this->get( 'apiuri' );
			$uri->setVar( 'e', '/Integrator/Intuser/Update' );
			$uri->setVar( 'email', $data['email'] );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns );
		
		if ( $result !== false ) {
			$result = simpleXMLToArray( $result );
		}
		
		return ( $result['result'] == 'success' ? true : 'some error' );
	}
	
	
	/**
	 * User removal call to this connection
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		string		- $email: contains just an email address
	 * 
	 * @return		boolean true if successful, false otherwise
	 * @since		3.0.0
	 */
	public function user_remove()
	{
		$data = $this->get_data();
		
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		
		// Create URL
		$uri	=   $this->get( 'apiuri' );
			$uri->setVar( 'e', '/Integrator/Intuser/Delete' );
			$uri->setVar( 'email', $data['email'] );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns );
		
		if ( $result !== false ) {
			$result = simpleXMLToArray( $result );
		}
		
		return ( $result['result'] == 'success' ? true : 'some error' );
	}
	

	/**
	 * Validates a set of new user credentials
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $data: standard formed user data from Integrator
	 * 
	 * @return		boolean true if valid, false otherwise
	 * @since		3.0.0
	 */
	public function user_validation_on_create()
	{
		$data	= $this->get_data();
		
		if (! empty( $data['fullname'] ) && ! empty( $data['email'] ) ) {
			// For post calls, we put the api vars in here
			$post	= $this->get( 'apipost' );
			$post['update']	= $data;
			
			// Create URL
			$uri	=   $this->get( 'apiuri' );
				$uri->setVar( 'e', '/Integrator/Intuser/ValidateOnCreate' );
			$purl	= $uri->toString();
			$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
			
			$result	= $this->_call_api( $purl, $post, $optns );
			
			if ( $result === false ) {
				return 'Unknown Error';
			}
			
			$result = simpleXMLToArray( $result );
		
			return ( $result['result'] == 'success' ? true : $result['message'] );
		}
		
		return true;
	}
	
	
	/**
	 * Validates an updated set of user information
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $data: standard formed user data from Integrator
	 * 
	 * @return		boolean true if valid, false otherwise
	 * @since		3.0.0
	 */
	public function user_validation_on_update()
	{
		$data	= $this->get_data();
		
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		$post['update']	= $data['update'];
		
		// If the email is the same do nothing more
		if ( $data['email'] == $post['update']['email'] ) return true;
		
		// Create URL
		$uri	=   $this->get( 'apiuri' );
			$uri->setVar( 'e', '/Integrator/Intuser/ValidateOnUpdate' );
			$uri->setVar( 'email', $data['email'] );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns );
		
		if ( $result === false ) {
			return 'Unknown Error';
		}
		
		$result = simpleXMLToArray( $result );
		
		return ( $result['result'] == 'success' ? true : $result['message'] );
	}
	
	
	/**
	 * Calls the API connection through curl
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		string		- $api_url: the API url
	 * @param		array		- $api_options: any additional API CURLSETOPT to set
	 * 
	 * @return		response from API or false on error
	 * @since		3.0.0
	 * @see 		Cnxns_library::_call_api()
	 */
	protected function _call_api( $api_url = null, $api_post = array(), $api_options = array() )
	{
		// Empty post vars
		if ( empty( $api_post ) ) return false;
		
		// Handle URL
		if ( $api_url == null ) return false;
		
		// Handle Options
		$api_options	= array_merge( $this->get( 'apioptions' ), $api_options );
		
		$response		= parent::_call_api( $api_post, $api_url, $api_options );
// 		var_dump( $response );
// 		$CI = & get_instance();
//		echo $CI->curl->debug();
		if (! $this->_check_for_xml( $response ) ) return $response;
		
		if ( ( $response = $this->_simple_xml( $response ) ) === false ) {
			$CI = & get_instance();
			if ( $CI->debug() ) {
				echo $CI->curl->debug( "API Call from Fusion Library" );
				die();
			}
			return false;
		}
		else return $response;
	}
	
	
	/**
	 * 
	 * Enter description here ...
	 */
	protected function _check_for_errors()
	{
		$CI		= & get_instance();
		switch( $CI->curl->info['http_code'] ) :
		case 200:
			return false;
		case 400:
			return 'Bad request - cannot be fulfilled due to poor syntax';
		case 401:
			return 'Unauthorized - the API Key or Secret Key are incorrect for this interface';
		case 403:
			return 'Forbidden - the server is refusing the connection';
		case 404:
			return 'Not found - the server was not found';
		case 405:
			return 'Not allowed - the resource you are requesting does not support the method requested';
		endswitch;
	}
	
	
	protected function _check_for_xml( $response )
	{
		return preg_match('/^<[^>]*>/i', $response) ? true : false;
	}
	
	
	protected function _simple_xml( $response )
	{
		// Convert response to XML object
		try {
			$xml = simplexml_load_string( $response );
		}
		catch ( Exception $e ) {
			if ( ( $this->debug ) || ( $GLOBALS['debug'] == true ) ) {
				echo "<h2>Problem Parsing XML Response from the Integrator</h2>";
				echo "=============================================<br/>\n";
				echo $url . "<br/>\n<pre>";
				echo $e->getLine();
				echo print_r( $e->getTrace(), 1);
				echo "=============================================<br/>\n";
				echo "<h3>Info</h3><pre>";
				echo print_r( $this->curl->info, 1 );
				echo "</pre>=============================================<br/>\n";
				echo "<h3>Posted Variables and Options</h3><pre>";
				echo print_r( $post, 1 );
				echo print_r( $options, 1 );
				echo "</pre>=============================================<br/>\n";
				echo "<h3>Header</h3><pre>";
				echo $header;
				echo "</pre>=============================================<br/>\n";
				echo "<h3>Response</h3><pre>";
				echo print_r( $response, 1 );
				echo "</pre>";
			}
			$xml = false;
		}
		return $xml;
	}
}