<?php
/*
$form['modify/userfields']	= array(
	'userid' => array(
			'value'			=> null,
			'order'			=> 1,
			'type'			=> 'hidden',
			'validation'	=> 'required',
			'lang'			=> null,
			'desc'			=> null
		),
	'email' => array(
			'apiname'		=> 'newemail',
			'value'			=> null,
			'order'			=> 10,
			'type'			=> 'text',
			'validation'	=> 'required|valid_email',
			'lang'			=> 'userinfo.email',
			'desc'			=> 'userinfo.email.desc'
		),
	'fullname' => array(
			'apiname'		=> 'newfirstname',
			'value'			=> null,
			'order'			=> 20,
			'type'			=> 'text',
			'validation'	=> 'required|xss_clean',
			'lang'			=> 'userinfo.fullname',
			'desc'			=> 'userinfo.fullname.desc'
		),
);

$form['create/userfields']	= array(
	'userid' => array(
			'value'			=> null,
			'order'			=> 1,
			'type'			=> 'hidden',
			'validation'	=> 'required',
			'lang'			=> null,
			'desc'			=> null
		),
	'email' => array(
			'apiname'		=> 'newemail',
			'value'			=> null,
			'order'			=> 10,
			'type'			=> 'text',
			'validation'	=> 'required|valid_email',
			'lang'			=> 'userinfo.email',
			'desc'			=> 'userinfo.email.desc'
		),
	'fullname' => array(
			'apiname'		=> 'newfirstname',
			'value'			=> null,
			'order'			=> 20,
			'type'			=> 'text',
			'validation'	=> 'required|xss_clean',
			'lang'			=> 'userinfo.fullname',
			'desc'			=> 'userinfo.fullname.desc'
		),
	'password' => array(
			'apiname'		=> 'newpassword',
			'value'			=> null,
			'order'			=> 30,
			'type'			=> 'password',
			'validation'	=> 'required'
		),
);*/