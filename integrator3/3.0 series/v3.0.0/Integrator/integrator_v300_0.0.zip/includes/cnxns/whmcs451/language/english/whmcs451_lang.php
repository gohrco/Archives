<?php
/*
|--------------------------------------------------------------------------
| Language Translations for the Connections Edit page
|--------------------------------------------------------------------------
| version 3.0.0
|--------------------------------------------------------------------------
*/
$lang['whmcs451_globals.accesskey']	= "Access Key";

$lang['whmcs451_users.ignorepwstrengthapi']		= 'Ignore API Password Strength';
$lang['whmcs451_users.ignorepwstrengthapi.desc']	= 'Enabling this setting allows WHMCS to test your updated or new password against the set password strength in WHMCS to maintain a level of strength across your applications.  This only affects password checks performed through the API from another connection.';

$lang['whmcs451_users.defaultaddress']			= "Default Address";
$lang['whmcs451_users.defaultaddress.desc']		= "When creating a new user in WHMCS, you must supply this field.  If the connection creating the user doesn't supply the field, the Integrator will use this setting as a default.";

$lang['whmcs451_users.defaultcity']				= "Default City";
$lang['whmcs451_users.defaultcity.desc']		= $lang['whmcs451_users.defaultaddress.desc'];

$lang['whmcs451_users.defaultcountry']			= "Default Country";
$lang['whmcs451_users.defaultcountry.desc']		= $lang['whmcs451_users.defaultaddress.desc'];

$lang['whmcs451_users.defaultphone']			= "Default Phone";
$lang['whmcs451_users.defaultphone.desc']		= $lang['whmcs451_users.defaultaddress.desc'];

$lang['whmcs451_users.defaultpostal']			= "Default Postal Code";
$lang['whmcs451_users.defaultpostal.desc']		= $lang['whmcs451_users.defaultaddress.desc'];

$lang['whmcs451_users.defaultstate']			= "Default State";
$lang['whmcs451_users.defaultstate.desc']		= $lang['whmcs451_users.defaultaddress.desc'];

$lang['whmcs451_users.defaultlastname']			= "Default Last Name";
$lang['whmcs451_users.defaultlastname.desc']	= $lang['whmcs451_users.defaultaddress.desc'];

/*
|--------------------------------------------------------------------------
| Language Translations for User Management / Modify
|--------------------------------------------------------------------------
| version 3.0.0
|--------------------------------------------------------------------------
*/

$lang['whmcs451_user.label']			= "Email Address";
$lang['whmcs451_user.desc']				= "Type in the current email address for the user you are searching for.";

$lang['whmcs451_userinfo.email']		= "Email Address";
$lang['whmcs451_userinfo.email.desc']	= 'The email address is required by WHMCS and is the single identifier across all connections.  Changing this may prevent the user from logging in across all your applications.';

$lang['whmcs451_userinfo.firstname']		= "First Name";
$lang['whmcs451_userinfo.firstname.desc']	= '(required)';

$lang['whmcs451_userinfo.lastname']			= "Last Name";
$lang['whmcs451_userinfo.lastname.desc']	= '(required)';

$lang['whmcs451_userinfo.companyname']		= "Company Name";
$lang['whmcs451_userinfo.companyname.desc']	= ' ';