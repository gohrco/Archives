<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Fields Library base class
 * @version		3.0.0.0.0
 * 
 * @since		3.0.0
 * @author		Steven
 */
class Fields_library
{
	public $cnxn_type	= null;
	public $defs		= array();
	public $grouped		= false;
	
	public function __construct()
	{
		
	}
	
	
	public function build( $defs, $vals = array(), $cnxn_type = null )
	{
		if ( $cnxn_type != null ) $this->cnxn_type = $cnxn_type;
		
		$this->set_definitions( $defs, $this->grouped );
		$this->set_values( $vals );
		$this->set_order();
	}
	
	
	/**
	 * Generate a new key value token for CSRF forgery checks
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function generate_csrf()
	{
		$CI		= & get_instance();
		$CI->load->helper('string');
		
		$key	= random_string('alnum', 16);
		$value	= random_string('alnum', 32);
		$CI->session->set_flashdata('csrfkey', $key);
		$CI->session->set_flashdata('csrfvalue', $value);
		return array( 'label' => null, 'field' => form_hidden( $key, $value ), 'desc' => null );
	}
	
	
	public function get( $name )
	{
		$defs	= $this->defs;
		if ( empty( $defs ) ) return;
		
		$obj = array();
		foreach( $defs as & $defobj ) {
			$obj[$defobj->name] = & $defobj;
		}
		
		if ( isset( $obj[$name] ) ) return $obj[$name];
	}
	
	
	public function get_values( $api = false )
	{
		$defs = $this->defs;
		if ( empty( $defs ) ) return array();
		
		$data	= array();
		$name	= ( $api ? 'apiname' : 'name' );
		foreach ( $defs as $def ) {
			$data[$def->$name] = $def->value;
		}
		
		return $data;
	}
	
	
	public function load( $fields, $cnxn = false, $grouped = false )
	{
		static $forms = array();
		
		if (! isset( $forms[$fields] ) ) {
			$path_pieces	= explode( '/', $fields );
			$filename		= $path_pieces[0] . '.php';
			unset( $path_pieces[0] );
			$formset		= implode( '/', $path_pieces );
			
			// Build path
			$path = APPPATH . ( $cnxn ? 'cnxns/'.$cnxn.'/' : '' ) . 'forms/' . $filename;
			
			if ( file_exists( $path ) ) {
				include( $path );
				if ( $grouped === true ) {
					$forms[$fields] = $form;
					$this->grouped	= true;
				}
				else {
					$forms[$fields]	= $form[$formset];
				}
			}
			else {
				return false;
			}
		}
		
		$this->build( $forms[$fields], array(), ( $cnxn ? $cnxn : null ));
	}
	
	
	public function render()
	{
		$defs = $this->defs;
		if ( empty( $defs ) ) return array();
		
		$data = array( 'fields' => array(), 'hidden' => array() );
		
		if ( $this->grouped ) {
			foreach ( $defs as $k => & $defg ) {
				foreach ( $defg as & $defobj ) {
					if ( in_array($defobj->type, array( 'hidden' ) ) ) {
						$data['hidden'][] = (object) $defobj->render();
					}
					else {
						$data['fields'][$k][] = (object) $defobj->render();
					}
				}
			}
		}
		else {
			foreach ( $defs as & $defobj ) {
				$data[( $defobj->type == 'hidden' ? 'hidden' : 'fields' )][] = (object) $defobj->render();
			}
		}
		
		$data['hidden'][] = (object) $this->generate_csrf();
		
		$this->defs = $defs;
		return $data;
	}
	
	
	public function set_cnxntype( $type = null )
	{
		$this->cnxn_type = $type;
		$defs	= $this->defs;
		if ( empty( $defs ) ) return;
		
		foreach( $defs as & $defobj ) {
			$defobj->cnxn_type = $type;
		}
		
		$this->defs = $defs;
	}
	
	
	public function set_definitions( $defs, $grouped = false, $group = null )
	{
		$data		= array();
		
		if ( $grouped ) {
			foreach( $defs as $name => $values ) {
				$data[$name] = $this->set_definitions( $values, false, $name );
			}
		}
		else {
			$defaults	= array();
			if ( $this->cnxn_type != null ) $defaults['cnxn_type'] = $this->cnxn_type;
			
			foreach ( $defs as $name => $values ) {
				//$name	= ( $this->grouped ? 'params[' . $group . '][' . $name . ']' : $name );
				$data[] = new form_definition( array_merge( array( 'name' => $name, 'group' => $group ), $values, $defaults ) );
			}
			
			if ( $this->grouped ) return $data;
		}
		
		$this->defs = $data;
	}
	
	
	public function set_order()
	{
		$defs	= $this->defs;
		if ( empty( $defs ) ) return;
		
		$obj = array();
		
		if ( $this->grouped ) {
			foreach ( $defs as $k => & $defg ) {
				foreach ( $defg as & $defobj ) {
					$obj[$k][$defobj->order] = & $defobj;
				}
				ksort( $obj[$k] );
			}
			
			$defs = array();
			foreach ( $obj as $k => & $defg ) {
				foreach ( $defg as & $defobj ) {
					$defs[$k][] = & $defobj;
				}
			}
		}
		else {
			foreach( $defs as & $defobj ) {
				$obj[$defobj->order] = & $defobj;
			}
			ksort( $obj );
			
			$defs = array();
			foreach ( $obj as & $defobj ) {
				$defs[] = & $defobj;
			}
		}
		
		$this->defs = $defs;
	}
	
	
	public function set( $name, $value, $type = 'value' )
	{
		$defs = $this->defs;
		if ( empty( $defs ) ) return;
		
		$obj = array();
		
		if ( $this->grouped ) {
			foreach( $defs as & $defg ) {
				foreach( $defg as & $defobj ) {
					$obj[$defobj->name] = & $defobj;
				}
			}
		}
		else {
			foreach ( $defs as & $defobj ) {
				$obj[$defobj->name] = & $defobj;
			}
		}
		
		if (! isset( $obj[$name] ) ) return;
		
		$obj[$name]->$type = $value;
		
		$this->defs = $defs;
		
		if ( $type == 'order' ) {
			$this->order();
		}
	}
	
	
	public function set_values( $values )
	{
		$defs = $this->defs;
		if ( empty( $defs ) ) return;
		
		if ( $this->grouped ) {
			foreach( $values as $group => $valueg ) {
				foreach ( $valueg as $name => $value ) $this->set( 'params[' . $group . '][' . $name . ']', $value );
			}
		}
		else {
			foreach ( $values as $name => $value ) $this->set( $name, $value );
		}
	}
	
	
	public function validation()
	{
		$defs	= $this->defs;
		if ( empty( $defs ) ) return false;
		
		$data	= array();
		
		if ( $this->grouped ) {
			foreach( $defs as $defg ) {
				foreach ( $defg as $def ) {
					$data[]	= $def->validation();
				}
			}
		}
		else {
			foreach ( $defs as $def ) {
				$data[]	= $def->validation();
			}
		}
		
		$data[] = $this->validate_csrf();
		return $data;
	}
	
	
	/**
	 * Create the validation return for a CSRF check
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function validate_csrf()
	{
		$CI = & get_instance();
		return array( 'field' => 'csrf.token', 'label' => lang( 'csrf.token' ), 'rules' => 'callback_csrfcheck' );
	}
}


/**
 * Form definition class
 * @version		3.0.0.0.0
 * 
 * @since		3.0.0
 * @author		Steven
 */
class form_definition
{
	/**
	 * If used, the name of the field in an API call
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public	$apiname	= null;
	
	/**
	 * If set contains the cnxn type to apply for language translations
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public	$cnxn_type	= null;
	
	/**
	 * Description language translation tag
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public	$desc		= null;
	public $field;
	
	/**
	 * The group name if used
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public	$group		= null;
	public $label;
	
	/**
	 * Field Name language translation tag
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public	$lang		= null;
	public $name;
	public $order;
	public $type;
	public $validation;
	public $value;
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $options: to set to the object
	 * 
	 * @since		3.0.0
	 */
	public function __construct( $options = array() )
	{
		foreach ( $options as $k => $v ) {
			$this->$k = $v;
		}
		
		// Set langs and descs if not passed along
		if ( $this->lang == null ) $this->lang = ( $this->group ? $this->group . '.' : '' ) . $this->name;
		if ( $this->desc == null ) $this->desc = ( $this->group ? $this->group . '.' : '' ) . $this->name . '.desc';
		
		// If this is a group, rename
		if ( $this->group != null ) {
			$this->name = 'params[' . $this->group . '][' . $this->name . ']';
		}
	}
	
	
	/**
	 * Permits for checking types prior to translation
	 * @access		protected
	 * @version		3.0.0.0.0
	 * 
	 * @return		mixed either null or string containing translated string
	 * @since		3.0.0
	 */
	protected function description()
	{
		if ( $this->type == 'hidden' ) return null;
		else return $this->translate( $this->desc );
	}
	
	
	/**
	 * Generates the form field item
	 * @access		protected
	 * @version		3.0.0.0.0
	 * 
	 * @return		string containing html form field
	 * @since		3.0.0
	 */
	protected function field( $name = false, $type = false )
	{
		if (! $name ) $name = $this->name;
		if (! $type ) $type = $this->type;
		
		$field		= null;
		$options	= array();
		
		switch ( $type ):
		case 'text':
			$use	= array( 'name' => $name, 'value' => set_value( $this->name, $this->value ), 'id' => $this->lang, 'class' => 'span-6' );
			$field	= form_input( $use );
			break;
		
		case 'password':
			$use	= array( 'name' => $name, 'value' => set_value( $this->name, $this->value ), 'id' => $this->lang, 'class' => 'span-6' );
			$field	= form_password( $use );
			break;
			
		case 'hidden':
			$field	= form_hidden( $name, set_value( $this->name, $this->value ) );
			break;

		case 'checkbox':
			$field	= form_checkbox( $name, '1', set_value( $this->name, $this->value ) );
			break;
			
		case 'yesno':
			$field	= '<span class="prepend-1 span-2">' . form_radio( array( 'name' => $name, 'id' => $this->lang . '1', 'value' => 1, 'checked' => ( $this->value ? TRUE : FALSE ) ) ) . lang( "yes" ) . '</span>'
					. '<span>' . form_radio( array( 'name' => $name, 'id' => $this->lang . '0', 'value' => 0, 'checked' => (! $this->value ? TRUE : FALSE ) ) ) . lang( "no" ) . '</span>';
			
			//$options	= array( '1' => lang( "yes" ), '0' => lang( "no" ) );
			//$field		= form_dropdown( $this->name, $options, set_value( $this->name, $this->value ), 'id=' .$this->lang );
			break;
		
		case 'dropdown':
			$options	= $this->translate( $this->lang, true );
			$field		= form_dropdown( $name, $options, set_value( $this->name, $this->value ), 'id=' . $this->lang . ' class="span-6"' );
			break;
		
		case 'dropdown-cnxns':
			$cnxns	= get_cnxns();
			foreach ( $cnxns as $cnxnid => $cnxn ) {
				$options[$cnxnid] = $cnxn->get( 'name' );
			}
			asort( $options );
			$field = form_dropdown( $name, $options, set_value( $this->name, $this->value ), 'id=' . $this->lang . ' class="span-6"' );
			break;
			
		case 'dropdown-cnxntypes':
			$traw	= & types(); // Cnxn helper
			
			if (! $traw ) return false;
			
			foreach ( $traw as $type => $obj ) {
				$options[$type] = $obj->get( "name", $type );
			}
			
			$field = form_dropdown( $name, $options, set_value( $this->name, $this->value ), 'id=' . $this->lang . ' class="span-6"' );
			break;
			
		case 'dropdown-cnxnvisual':
			$cnxns	= get_cnxns();
			$options[null] = "-- " . lang( 'settings.index.defaultcnxn' ) . " --";
			
			if (! empty( $cnxns ) ) {
				foreach ( $cnxns as $cnxn ) {
					$cnxn_lib = get_cnxn_library( $cnxn->get( "id" ) );
					if (! $cnxn_lib->get( "isvisual" ) ) continue;
					$options[$cnxn->get( "id" )] = $cnxn->get( "name" );
				}
			}
			$field = form_dropdown( $name, $options, set_value( $this->name, $this->value ), 'id=' . $this->lang . ' class="span-6"' );
			break;
			break;
			
		case 'cnxn-pageselect':
			$field = 'cnxn-pageselect|' . $name . '|' . $this->value . '|' . $this->lang;
			break;
			
		case 'user-group':
			$CI = & get_instance();
			$groups = array();
			foreach( $CI->ion_auth_model->get_groups() as $group ) {
				$groups[$group->id] = $group->description;
			}
			$field	= form_dropdown( $name, $groups, set_value( $this->name, $this->value ), 'id=' . $this->lang . ' class="span-6"' );
			break;
			
		endswitch;
		
		return $field;
	}
	
	
	/**
	 * Generates a form label
	 * @access		protected
	 * @version		3.0.0.0.0
	 * 
	 * @return		string containing html form label
	 * @since		3.0.0
	 */
	protected function label()
	{
		if ( $this->type == 'hidden' ) return null;
		$id = $this->lang . ( $this->type == 'yesno' ? ( $this->value ? '1' : '0' ) : '' );
		return form_label( $this->translate( $this->lang ), $id );
	}
	
	
	/**
	 * Creates the rendered form item
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @return		array of rendered items
	 * @since		3.0.0
	 */
	public function render()
	{
		$this->label	= $this->label();
		$this->desc		= $this->description();
		$this->field	= $this->field();
		return array( 'label' => $this->label, 'field' => $this->field, 'desc' => $this->desc );
	}
	
	
	/**
	 * Translates an item
	 * @access		protected
	 * @version		3.0.0.0.0
	 * @param		string		- $item: contains the string to translate
	 * @param		boolean		- $options: if true will append '_options' for translation purposes
	 * 
	 * @return		mixed string if no options, else array of translated options
	 * @since		3.0.0
	 */
	protected function translate( $item = null, $options = false )
	{
		if ( $item == null ) return null;
		
		$prefix	= $this->cnxn_type;
		$lang	= lang( $prefix . "_" . $item . ( $options ? "_options" : "" ) );
		if ( empty( $lang ) ) $lang = lang( $item . ( $options ? "_options" : "" ) );
		if ( empty( $lang ) ) return $item;
		
		return $lang;
	}
	
	
	/**
	 * Creates the validation variables for the fields library object
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @return		array containing required items for validation purposes
	 * @since		3.0.0
	 */
	public function validation()
	{
		$field	= $this->name;
		$label	= $this->translate( $this->lang );
		$rules	= $this->validation;
		
		return array( 'field' => $field, 'label' => $label, 'rules' => $rules );
	}
}