<?php

$form['tos']	= array(
	'submit'	=> array(
		'value'			=> null,
		'order' 		=> 10,
		'type'			=> 'checkbox',
		'validation'	=> 'required'
	),
);

$form['database']	= array(
	'db_hostname'	=> array(
		'value'			=> 'localhost',
		'order'			=> 10,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'db_username'	=> array(
		'value'			=> null,
		'order'			=> 20,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'db_password'	=> array(
		'value'			=> null,
		'order'			=> 30,
		'type'			=> 'password',
		'validation'	=> ''
	),
	'db_port'	=> array(
		'value'			=> '3306',
		'order'			=> 40,
		'type'			=> 'text',
		'validation'	=> 'required|numeric'
	),
	'db_valid'	=> array(
		'value'			=> false,
		'order'			=> 50,
		'type'			=> 'hidden',
		'validation'	=> 'required'
	)
);

$form['reqs']	= array(
	'php'		=> array(
		'value'			=> false,
		'order'			=> 10,
		'type'			=> 'hidden',
		'validation'	=> 'required'
	),
	'mysql'		=> array(
		'value'			=> false,
		'order'			=> 20,
		'type'			=> 'hidden',
		'validation'	=> 'required'
	),
	'curl'		=> array(
		'value'			=> false,
		'order'			=> 30,
		'type'			=> 'hidden',
		'validation'	=> 'required'
	),
	'ioncube'	=> array(
		'value'			=> false,
		'order'			=> 40,
		'type'			=> 'hidden',
		'validation'	=> 'required'
	),
);


$form['dirs']	= array(
	'files'		=> array(
		'value'			=> false,
		'order'			=> 10,
		'type'			=> 'hidden',
		'validation'	=> 'required'
	),
	'dirs'		=> array(
		'label'			=> 'reqd.dirs',
		'value'			=> false,
		'order'			=> 20,
		'type'			=> 'hidden',
		'validation'	=> 'required'
	)
);

$form['install']	= array(
	'db_database'	=> array(
		'value'			=> null,
		'order'			=> 10,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'db_dbprefix'	=> array(
		'value'			=> 'int_',
		'order'			=> 15,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'db_create'	=> array(
		'value'			=> true,
		'order' 		=> 20,
		'type'			=> 'checkbox',
		'validation'	=> 'callback_db_permcheck'
	),
	'username'	=> array(
		'value'			=> 'admin',
		'order'			=> 30,
		'type'			=> 'text',
		'validation'	=> 'required|alpha_dash'
	),
	'email'	=> array(
		'value'			=> null,
		'order'			=> 40,
		'type'			=> 'text',
		'validation'	=> 'required|valid_email'
	),
	'password'	=> array(
		'value'			=> null,
		'order'			=> 50,
		'type'			=> 'password',
		'validation'	=> 'required'
	),
	'license'	=> array(
		'value'			=> null,
		'order'			=> 60,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'db_valid'	=> array(
		'value'			=> false,
		'order'			=> 70,
		'type'			=> 'hidden',
		'validation'	=> 'required'
	)
);
