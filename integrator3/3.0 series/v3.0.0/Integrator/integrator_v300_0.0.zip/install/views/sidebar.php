<div id="side-hdr">
	<?php echo image( 'logo.png', null, array( 'id' => 'logo' ) ); ?>
	<h3>Integrator <small>v</small>3.0</h3>
	
</div>

<div id="main-nav">
	<ul id="menu-nav">
		<?php foreach ( $nav as $n ) : ?>
		<?php if ( isset( $n->submenu ) ) : ?>
		<li>
		<?php echo anchor ( $n->anchor, $n->text, 'class="top-link' . ( $n->current ? ' current' : '' ) . '"' ); ?>
		<ul>
			<?php foreach( $n->submenu as $o ) : ?>
			<li><?php echo anchor( $o->anchor, $o->text, ( $o->current ? 'class="currentsub"' : '' ) ); ?></li>
			<?php endforeach; ?>
		</ul></li>
		<?php else : ?>
		<li><a href='javascript:;' onclick="return false" class="no-submenu <?php echo $n->current ? ' current' : ''; ?>"><?php echo lang( $n->text ); ?></a></li>
		<?php endif; ?>
		<?php endforeach; ?>
	</ul>
</div>