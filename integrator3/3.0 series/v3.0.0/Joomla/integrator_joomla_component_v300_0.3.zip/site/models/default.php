<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.0.0.3 ( $Id: default.php 373 2012-01-26 18:44:16Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file contains the default model which allows the user and system to interact with the data
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
jimport( 'joomla.application.component.model' );	// Import model


/**
 * Default model class object
 * @version		3.0.0.0.3
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntegratorModelDefault extends JModel
{
	/**
	 * Constructor
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Gets a username with a given email address
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $email: contains an email address
	 * 
	 * @return		string containing username found or false on not found
	 * @since		3.0.0
	 */
	public function get_username( $email )
	{
		$db		= & JFactory::getDBO();
		$query	=   "SELECT u.username FROM `#__users` u WHERE u.email=" . $db->Quote( $email );
		$db->setQuery( $query );
		return $db->loadResult();
	}
}