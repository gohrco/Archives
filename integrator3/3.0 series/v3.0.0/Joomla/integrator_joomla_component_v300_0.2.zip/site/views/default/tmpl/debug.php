<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php if ( $this->params->get( 'show_page_title' ) ): ?>
<div class="componentheading">
	Integrator Debugging Page
</div>
<?php endif; ?>

<table class="contentpaneopen">
	<tr>
		<td valign="top">
			<p>It should not be possible to see this message.  If you are seeing this, then there is a problem with a setting for this menu item and you have debugging turned on.  Following is the debug output.</p>
		</td>
	</tr>
</table>

<div style="width: 100%; clear: both; position: relative; color: #000; ">
	<fieldset style="padding: 5px 17px 17px; background-color: #fff; border: 1px solid #CCCCCC; ">
		<legend style="color: #146295; font-size: 1.15em; font-weight: bold; margin: 0; padding: 0; ">
			Integrator Debug Information
		</legend>
		<ul class="list-style: none outside none; margin: 0; padding: 0; ">
		<?php foreach ( $this->debug as $debug ): ?>
			<li style="list-style: none outside none; border-bottom: 1px solid #666666; padding: 5px; ">
				<div style="float: left; font-weight: bold; <?php echo $debug['type'] == 'error' ? 'color: DarkRed; ' : ''; ?>">[<?php echo $debug['type']; ?>] <?php echo $debug['message']; ?></div>
				<div style="float: right; font-size: smaller; <?php echo $debug['type'] == 'error' ? 'color: DarkRed; ' : ''; ?>"><?php echo $debug['filename']; ?> @ line <?php echo $debug['line']; ?></div>
				<div style="clear: both; line-height: 1px; ">&nbsp;</div>
			</li>
		<?php endforeach; ?>
