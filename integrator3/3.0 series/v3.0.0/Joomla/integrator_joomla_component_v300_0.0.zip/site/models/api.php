<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.0.0.0 ( $Id: api.php 373 2012-01-26 18:44:16Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file contains the api model which allows the api interface to interact with the data
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
jimport( 'joomla.application.component.model' );	// Import model
/*-- Localscope import --*/

/**
 * API model class object
 * @version		3.0.0.0.0
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntegratorModelApi extends JModel
{
	/**
	 * Constructor
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Gets an email from a username
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		string		- $username: the username to search for
	 * 
	 * @return		string containing username or false on no result
	 * @since		3.0.0
	 */
	public function get_email( $username )
	{
		$db 	= & JFactory::getDBO();
		$query	=   "SELECT u.email FROM `#__users` u WHERE u.username = " . $db->Quote( $username );
		$db->setQuery( $query );
		return $db->loadResult();
	}
	
	
	/**
	 * Gets the languages from this site
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @return		array of languages or false on empty
	 * @since		3.0.0
	 */
	public function get_languages()
	{
		$db = & JFactory::getDbo();
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$query	= "SELECT sef as 'value', title as 'name' FROM #__languages WHERE published=1";
			$db->setQuery($query);
			
			return $db->loadAssocList();
		}
		
		// Joomla 1.5 below
		// Check to see if we have Joomfish installed
		if ( $this->_check_table( "languages" ) ) {
			
			$query = "SELECT `shortcode` as 'value', `name` as 'name' FROM #__languages WHERE `active` = 1";
			$db->setQuery( $query );
			
			if ( ( $rows = $db->loadAssocList() ) ) {
				$results = array();
				foreach ( $rows as $row ) {
					$results[$row->value] = $row->name;
				}
				return $results;
			}
		}
		
		// No Joomfish, so pull the languages like Joomla does
		jimport('joomla.client.helper');
		jimport('joomla.filesystem.folder');
		
		$client		= & JApplicationHelper::getClientInfo(JRequest::getVar('client', '0', '', 'int'));
		$results	=   array();
		$ftp		= & JClientHelper::setCredentialsFromRequest('ftp');
		$path		=   JLanguage::getLanguagePath($client->path);
		$params		=   JComponentHelper::getParams( 'com_languages' );
		$dirs		=   JFolder::folders( $path );
		$rowid		= 0;
		
		foreach ($dirs as $dir) {
			$files = JFolder::files( $path.DS.$dir, '^([-_A-Za-z]*)\.xml$' );
			foreach ($files as $file) {
				$data = JApplicationHelper::parseXMLLangMetaFile($path.DS.$dir.DS.$file);
				if ( $params->get( $client->name, 'en-GB' ) == $data['name'] ) {
					$results = array( substr($file,0,-4) => $data['name'] ) + $results;
				}
				else {
					$results = $results + array( substr($file,0,-4) => $data['name'] );
				}
			}
		}
		
		return $results;
	}
	
	
	/**
	 * Retrieves the menu tree from Joomla
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @return		array containing menus or empty array
	 * @since		3.0.0
	 */
	public function get_menutree()
	{
		$db			= & JFactory::getDBO();
		$children	=   array();
		
		$query = 'SELECT menutype, title' .
				' FROM #__menu_types' .
				' ORDER BY title';
		$db->setQuery( $query );
		$menuTypes = $db->loadObjectList();
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$query = 'SELECT id, parent_id, title as name, title, menutype, type, link, ordering FROM #__menu WHERE published = 1';
		}
		else {
			$query = 'SELECT id, parent, parent as parent_id, name, name as title, menutype, type, link, ordering, sublevel FROM #__menu WHERE published = 1';
		}
		
		$db->setQuery($query);
		$menuItems = $db->loadObjectList();
		
		if ($menuItems)
		{
			foreach ($menuItems as $v)
			{
				$pt 	= $v->parent_id;
				$list 	= @$children[$pt] ? $children[$pt] : array();
				array_push( $list, $v );
				$children[$pt] = $list;
			}
		}
		
		$list = JHTML::_('menu.treerecurse', 0, '', array(), $children, 9999, 0, 0 );
		
		$n = count( $list );
		$groupedList = array();
		foreach ($list as $k => $v) {
			if ( empty( $v->menutype ) ) continue;
			$groupedList[$v->menutype][] = &$list[$k];
		}
		
		return array( 'data' => $groupedList, 'version' => JVERSION );
	}
	
	
	/**
	 * Gets a user from the database
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		string		- $search: the string to search by
	 * @param		string		- $by: what to search by (email or username)
	 * 
	 * @return		array or false on no find
	 * @since		3.0.0
	 */
	public function get_user( $search, $by = 'email' )
	{
		if ( is_null( $search ) ) return null;
		
		$db = & JFactory::getDBO();
		$query = "SELECT `id`, `username`, `email`, `name`, `block` FROM #__users WHERE `" . $by . "` = " . $db->Quote( $search );
		$db->setQuery($query, 0, 1);
		return $db->loadAssoc();
	}
	
	
	/**
	 * Gets a username from an email address
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		string		- $email: the email to search for
	 * 
	 * @return		string containing username or false on no result
	 * @since		3.0.0
	 */
	public function get_username( $email )
	{
		$db		= & JFactory::getDBO();
		$query	=   "SELECT u.username FROM `#__users` u WHERE u.email = " . $db->Quote( $email );
		$db->setQuery( $query );
		return $db->loadResult();
	}
	
	
	/**
	 * Creates the user on this site
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @return		true on success, string with error message otherwise
	 * @since		3.0.0
	 */
	public function user_create()
	{
		$data	= & IntegratorHelper :: get ( 'data', array(), 'array' );
		
		// Create the user
		$acl			= & JFactory::getACL();
		$user			=   new JUser();
		$usersConfig	= & JComponentHelper::getParams( 'com_users' );
		
		$newUsertype = $usersConfig->get( 'new_usertype' );
		if (! $newUsertype) $newUsertype = 'Registered';
		
		// We handle groups differently in J1.6+
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$data['groups'][] = $newUsertype;
		}
		else {
			$data['gid'] = $acl->get_group_id( '', $newUsertype, 'ARO' );
		}
		
		if (! $user->bind( $data ) ) {
			return 'USERCREATE_ERRORBIND';
		}
		
		$date = & JFactory::getDate();
		$user->set('registerDate', $date->toMySQL());
		
		if (! $user->save() ) {
			return 'USERCREATE_ERRORSAVE';
		}
		else {
			return true;
		}
	}
	
	
	/**
	 * Finds a user for the API
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @return		string on error or array on succes
	 * @since		3.0.0
	 */
	public function user_find()
	{
		$data	= & IntegratorHelper :: get( 'data', array(), 'array' );
		
		if ( (! isset( $data['email'] ) ) && (! isset( $data['username'] ) ) ) {
			return JText::_( 'COM_INTEGRATOR_API_USERFIND_ERRORNOSEND' );
		}
		
		$by = ( isset( $data['email'] ) ? 'email' : 'username' );
		
		if (! ( $user = $this->get_user( $data[$by], $by ) ) ) {
			return JText::sprintf( 'COM_INTEGRATOR_API_USERFIND_ERRORNOFIND', $data[$by] );
		}
		
		return $user;
	}
	
	
	/**
	 * Removes a user from this site
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @return		boolean true upon success, string on error
	 * @since		3.0.0
	 */
	public function user_remove()
	{
		$data	= & $app->input->get( 'data', array(), 'array' );
		$by		=   ( isset( $data['email'] ) ? 'email' : 'username' );
		
		if (! ( $user = $this->get_user( $data[$by], $by ) ) ) {
			return JText::sprintf( 'COM_INTEGRATOR_API_USERREMOVE_ERRORNOFIND', $data['email'] );
		}
		
		// Grab the user if it exists
		$user	= & JFactory::getUser( $user['id'] );
		
		if (! $user->delete() ) {
			return JText::_( 'COM_INTEGRATOR_API_USERREMOVE_ERRORDELETE' );
		}
		return true;
	}
	
	
	/**
	 * Updates a user on this connection
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @return		boolean true upon success, string on error
	 * @since		3.0.0
	 */
	public function user_update()
	{
		$data	= & IntegratorHelper :: get( 'data', array(), 'array' );
		$by		=   ( isset( $data['email'] ) ? 'email' : 'username' );
		
		if (! ( $user = $this->get_user( $data[$by], $by ) ) ) {
			return JText::sprintf( 'COM_INTEGRATOR_API_USERUPDATE_ERRORNOFIND', $data[$by] );
		}
		
		// Grab the user if it exists
		$user	= & JFactory::getUser( $user['id'] );
		
		// Build the name info based on variables array
		$binder	=   $data['update'];
		
		if (! $user->bind( $binder ) ) {
			return 'USERUPDATE_ERRORBIND';
		}
		
		if (! $user->save() ) {
			return 'USERUPDATE_ERRORSAVE';
		}
		
		return true;
	}
	
	
	/**
	 * Validates provided user credentials
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @return		boolean true on success, string on error
	 * @since		3.0.0
	 */
	public function user_validation_on_create()
	{
		$db		= & JFactory::getDbo();
		$data	= & IntegratorHelper :: get( 'data', array(), 'array' );
		$query	=   null;
		
		extract( $data );
		
		foreach ( array( 'email', 'username' ) as $check ) {
			$query	= "SELECT u.id FROM `#__users` u WHERE `{$check}` = {$db->Quote( $$check )}";
			$db->setQuery( $query );
			if ( $exists = $db->loadResult() ) {
				return JText::sprintf( 'COM_INTEGRATOR_API_USERVALIDATION_ERROR' . strtoupper( $check ), $$check );
			}
		}
		
		return true;
	}
	
	
	/**
	 * Validates provided user credentials for update
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @return		boolean true on success, string on error
	 * @since		3.0.0
	 */
	public function user_validation_on_update()
	{
		$db		= & JFactory::getDbo();
		$data	= & IntegratorHelper :: get( 'data', array(), 'array' );
		$query	=   null;
		
		extract( $data );
		
		if ( isset( $username ) ) {
			$query	= "SELECT u.id FROM `#__users` u WHERE `username` = {$db->Quote( $username )} AND `username` <> {$db->Quote( $username )}";
		}
		
		if ( isset( $email ) ) {
			$query	= "SELECT u.id FROM `#__users` u WHERE `email` = {$db->Quote( $email )} AND `email` <> {$db->Quote( $email )}";
		}
		
		if ( $query == null ) return false;
		
		$db->setQuery( $query );
		
		if ( $exists = $db->loadResult() ) {
			return JText::sprintf( 'COM_INTEGRATOR_API_USERVALIDATION_ERROR' . ( isset( $email ) ? 'EMAIL' : 'USERNAME' ), isset( $email ) ? $email : $username );
		}
		
		return true;
	}
	
	
	/**
	 * Checks the database for a specific table
	 * @access		private
	 * @version		3.0.0.0.0
	 * @param		string		- $table: the table name minus the database key (such as jos) and the leading underscore
	 * 
	 * @return		boolean true if found, false otherwise
	 * @since		3.0.0
	 */
	private function _check_table( $table = null )
	{
		if ( $table == null ) return false;
		
		$db		= & JFactory::getDBO();
		$query	= "SHOW TABLES";
		$db->setQuery( $query );
		$result	= $db->loadAssocList();
		$exists = false;
		
		foreach( $result as $row ) {
			foreach( $row as $r ) {
				if ( substr( $r, ( strlen( $r ) - strlen( $table ) ) ) == $table ) {
					$exists = true;
					break 2;
				}
			}
		}
		return $exists;
	}
}