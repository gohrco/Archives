<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.0.0.0 ( $Id: view.html.php 373 2012-01-26 18:44:16Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file renders the default view to the admin user
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.view' );
/*-- File Inclusions --*/

/**
 * IntegratorViewDefault class object
 * @version		3.0.0.0.0
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntegratorViewDefault extends JView
{
	
	/**
	 * Displays the backend to the user
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		string		- $tpl: template name (unused)
	 * 
	 * @since		3.0.0
	 */
	public function display($tpl = null)
	{
		$model				= & $this->getModel();
		$this->status		=   $this->get( 'Status' );
		
		if ( $this->status === true ) {
			$model->updateSettings();
		}
		
		IntegratorHelper :: addMedia( 'admin_default/css');
		IntegratorHelper :: addToolbar();
		
		$this->debug		=   $this->get( 'Debug' );
		parent::display($tpl);
	}
}