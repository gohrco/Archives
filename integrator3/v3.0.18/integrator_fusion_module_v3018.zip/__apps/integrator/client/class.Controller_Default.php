<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Kayako Fusion Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.18 ( $Id: class.Controller_Default.php 254 2013-06-03 21:45:24Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the default view file for the Integrator and will redirect after setting _v variable
 *  
 */

/**
 * Controller Default class
 * @version		3.0.18
 * 
 * @since		3.0.0
 * @author		Steven
 */
class Controller_Default extends Controller_client
{
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.18
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
		$this->Language->Load( 'login', SWIFT_LanguageEngine::TYPE_FILE );
		return true;
	}
	
	
	/**
	 * Destructor method
	 * @access		public
	 * @version		3.0.18
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function __destruct()
	{
		parent::__destruct();
		return true;
	}
	
	
	/**
	 * Index method redirects user to desired path
	 * @access		public
	 * @version		3.0.18
	 * 
	 * @since		3.0.0
	 */
	public function Index()
	{
		// Grab locals
		$SWIFT	=   SWIFT :: GetInstance();
		$router	= & $SWIFT->Router;
		$path	=   null;
		
		// Grab the variables passed to us
		$vars	= $router->GetArguments();
		
		// If we are setting the _v variable then do so
		if ( isset( $vars['_v'] ) ) {
			$SWIFT->Cookie->AddVariable( 'client', '_v', $vars['_v'] );
		}
		
		// Handle language
		if ( isset( $vars['_languagecode'] ) ) {
			$query	=	"SELECT `languageid` FROM `swlanguages` WHERE `languagecode` = '" . $vars['_languagecode'] . "'";
			$langs	=	$this->Database->QueryFetch( $query );
			$SWIFT->Cookie->AddVariable('client', 'languageid', $langs['languageid']);
		}
		
		// Set the default template (better by Integrator!)
		$SWIFT->Cookie->AddVariable( 'client', 'templategroupid', $SWIFT->TemplateGroup->GetDefaultGroupID() );
		$SWIFT->Cookie->Rebuild( 'client' );
		
		// Check to see if we have a path request
		if ( isset( $vars['_path'] ) ) {
			$parts	= explode('-', $vars['_path'] );
			for ( $i = 0; $i < count ( $parts ); $i++ ) $parts[$i] = $parts[$i];
			$path	= '/' . implode( '/', $parts );
		}
		else {
			$path = '/Core/Default/Index';
		}
		
		// Redirect appropriately
		header( "location: " . SWIFT::Get('basename') . $path  );
	}
	
	
	public function Login( $_templateGroupName = '' )
	{
		$_SWIFT = SWIFT::GetInstance();
		
		if (! $this->GetIsClassLoaded() ) {
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
			return false;
		}
		
		// Create Form Action
		$curi	=   new IntUri( SWIFT :: Get( 'basename' ) );
		$sslset	=   $_SWIFT->Settings->Get( 'integrator_usessl' );
		$ssl	=   ( $sslset == 'none' ? false : ( $sslset == 'always' ? true : $curi->isSSL() ) );
		$uri	=   new IntUri( $_SWIFT->Settings->Get( 'integrator_url' ) );
		$uri->setPath( rtrim( $uri->getPath(), '/' ) . '/index.php/login/index' );
		$uri->setScheme( 'http' . ( $ssl ? 's' : '' ) );
		$_formAction	= $uri->toString();
		$_cnxn_id		= $_SWIFT->Settings->Get( 'integrator_cnxnid' );
		
		SWIFT_Loader::LoadLibrary('Template:Template');
		
		$this->_LoadTemplateGroup( $_templateGroupName );
		$_SWIFT->Template->Render( 'header' );
//		$this->UserInterface->Header('');
		
		$_SWIFT->Template->Assign( '_formAction', $_formAction );
		$_SWIFT->Template->Assign( '_cnxn_id', $_cnxn_id );
		$_SWIFT->Template->Assign( '_returnUrl',  base64_encode( SWIFT :: Get( 'basename' ) . '/Integrator/Default/Index' ) );
		$_SWIFT->Template->Render( 'integratorlogin' );
		
		$_SWIFT->Template->Render( 'footer' );
		
//		$this->UserInterface->Footer();
		
		return true;
		// Check for empty fields..
		if (! isset( $_POST['searchquery'] ) || trim($_POST['searchquery']) == '')
		{
			$this->UserInterface->CheckFields('searchquery');

			$this->UserInterface->Error(true, $this->Language->Get('requiredfieldempty'));

			$this->Load->Controller('Default', 'Base')->Load->Index();

			return false;

		}

		$_searchResultContainer = $this->SearchManager->Search($_POST['searchquery'], SWIFT::Get('usergroupid'));
		$this->Template->Assign('_searchResultContainer', $_searchResultContainer);
		$this->Template->Assign('_searchResultCount', count($_searchResultContainer));

		$this->UserInterface->Header('');

		$this->Template->Render('integratorlogin');

		$this->UserInterface->Footer();

		return true;
	}
	
}
?>