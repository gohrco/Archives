<div id="languagechooser">
	
	<?php echo form_open( false, array( 'id' => 'languageslxnfrm', 'class' => 'well' ) ); ?>
		
		<div style="text-align: right; margin: 5px 15px; float: left; ">
			
			Language:
			
		</div>
		
		<select onchange="languageslxnfrm.submit()" name="languageslxn" class="input-small">
			
			<?php echo $language_menu; ?>
			
		</select>
		
	</form>
	
</div>