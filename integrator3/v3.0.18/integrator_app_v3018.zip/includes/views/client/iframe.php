<style type="text/css">

#integrator_redirect div {
	text-align: center !important;
}

.redirect-wrapper {
	position: fixed !important;  
	background: transparent url('<?php echo image_url( 'client-trans-bg.png' ); ?>' ) repeat !important; 
	height: 100% !important;
	left: 0px !important;
	top: 0px !important;
	width: 100% !important;
	z-index: 900 !important;
}

.redirect-texthdr {
	clear: both !important;
	color: #000 !important;
	font-size: 18pt !important;
	font-family: Arial !important;
	margin: 0px auto !important;
	position: absolute !important;
	top: 40% !important;
	width: 100% !important;
}

.redirect-texthdr span {
	line-height: 1.2em !important;
}

.redirect-imagebar {
	background-image: url('<?php echo image_url( 'client-progress-bar.gif' ); ?>') !important;
	clear: both !important;
	height: 14px !important;
	margin: 0px auto !important;
	width: 190px !important;
}

</style>

<div class="redirect-wrapper" id="integrator_redirect">
<div class="redirect-texthdr"><span><?php echo $redirectmessage; ?></span><br />
<div class="redirect-imagebar">&nbsp;</div>
</div></div>

<?php echo $iframe; ?>