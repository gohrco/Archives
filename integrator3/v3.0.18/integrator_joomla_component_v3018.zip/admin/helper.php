<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.18 ( $Id: helper.php 298 2013-11-06 18:53:14Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      2.3.0
 * 
 * @desc       This file is a utility helper for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

// Define the DS shortcut (3.0 dropped?)
if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
	if (! defined( 'DS' ) ) define( 'DS', DIRECTORY_SEPARATOR );
}

/**
 * IntegratorHelper class is a utility class for common tasks
 * @version 3.0.18
 * 
 * @since	2.3.0
 * @author	Steven
 */
class IntegratorHelper
{
	/**
	 * Adds a line for debugging purposes
	 * @static
	 * @access		public
	 * @version		3.0.18
	 * @param		string		- $data: contains the message to add
	 * @param		string		- $type: indicates what type of debug info this is
	 * @param		string		- $filename: the filename the debug was called from
	 * @param		integer		- $line: the line number called from
	 * @param		bool		- $translate: true to translate the string
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public static function addDebug( $data, $type = 'info', $filename = null, $line = 0, $translate = false )
	{
		$bt	= debug_backtrace();
		$bt = $bt[0];
		
		$bt['file'] = str_replace( '\\', '/', $bt['file'] );
		if (FALSE !== strpos($bt['file'], '/')) {
			$x = explode('/', $bt['file']);
			$filename = $x[count($x)-2].'/'.end($x);
		}
		$line	=   $bt['line'];
		
		$debug	=	IntDebug :: getInstance();
		$debug->add( $data, $filename, $line, $type, $translate );
	}
	
	
	/**
	 * Handles inclusion of media items into views
	 * @static
	 * @access	public
	 * @version	3.0.18
	 * @param	string		$media - contains filename/type
	 * 
	 * @since	2.3.0
	 */
	public static function addMedia( $media = null )
	{
		if ( $media == null ) return;
		
		list( $filename, $type ) = explode( "/", $media );
		
		switch ( $type ):
		case 'css':
			if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
				JHtml::stylesheet( "com_integrator/{$filename}.css", array(), true );
			}
			else {
				$path	= 'media/com_integrator/css/';
				JHtml::stylesheet( "{$filename}.css", $path, array() );
			}
			break;
		case 'javascript':
		case 'js':
			if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
				JHTML::script("com_integrator/{$filename}.js", array(), true );
			}
			else {
				$path	= 'media/com_integrator/js/';
				JHTML::script( "{$filename}.js", $path, array() );
			}
			break;
		endswitch;
	}
	
	
	/**
	 * Common method to handle toolbar for backend
	 * @static
	 * @access		public
	 * @version		3.0.18
	 * 
	 * @since		3.0.0
	 */
	public static function addToolbar()
	{
		JToolBarHelper :: title( JText::_( 'INTEGRATOR' ), 'integrator.png' );
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			JToolBarHelper :: preferences(	'com_integrator', '550', '875', 'JToolbar_Options', '', 'window.location.reload()' );
		}
		else {
			$toolbar =	JToolbar::getInstance();
			$toolbar->addButtonPath( JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR . "buttons" );
			$toolbar->appendButton( 'Prefs', 'config', 'Preferences', 'index.php?option=com_config&amp;controller=component&amp;component=com_integrator', 875, 550, 0, 0, 'window.location.reload()' );
		}
	}
	
	
	/**
	 * Builds an array of countries for use in a select option box
	 * @access	public
	 * @version	3.0.18
	 * 
	 * @return	Array of countries as XX => Name
	 * @since	1.5.0
	 */
	public function buildCountries()
	{
		return array('AF' => 'Afghanistan', 'AX' => 'Aland Islands', 'AL' => 'Albania', 'DZ' => 'Algeria', 'AS' => 'American Samoa', 'AD' => 'Andorra', 'AO' => 'Angola', 'AI' => 'Anguilla', 'AQ' => 'Antarctica', 'AG' => 'Antigua And Barbuda', 'AR' => 'Argentina', 'AM' => 'Armenia', 'AW' => 'Aruba', 'AU' => 'Australia', 'AT' => 'Austria', 'AZ' => 'Azerbaijan', 'BS' => 'Bahamas', 'BH' => 'Bahrain', 'BD' => 'Bangladesh', 'BB' => 'Barbados', 'BY' => 'Belarus', 'BE' => 'Belgium', 'BZ' => 'Belize', 'BJ' => 'Benin', 'BM' => 'Bermuda', 'BT' => 'Bhutan', 'BO' => 'Bolivia', 'BA' => 'Bosnia And Herzegovina', 'BW' => 'Botswana', 'BV' => 'Bouvet Island', 'BR' => 'Brazil', 'IO' => 'British Indian Ocean Territory', 'BN' => 'Brunei Darussalam', 'BG' => 'Bulgaria', 'BF' => 'Burkina Faso', 'BI' => 'Burundi', 'KH' => 'Cambodia', 'CM' => 'Cameroon', 'CA' => 'Canada', 'CV' => 'Cape Verde', 'KY' => 'Cayman Islands', 'CF' => 'Central African Republic', 'TD' => 'Chad', 'CL' => 'Chile', 'CN' => 'China', 'CX' => 'Christmas Island', 'CC' => 'Cocos (Keeling) Islands', 'CO' => 'Colombia', 'KM' => 'Comoros', 'CG' => 'Congo', 'CD' => 'Congo, Democratic Republic', 'CK' => 'Cook Islands', 'CR' => 'Costa Rica', 'CI' => 'Cote D\'Ivoire', 'HR' => 'Croatia', 'CU' => 'Cuba', 'CY' => 'Cyprus', 'CZ' => 'Czech Republic', 'DK' => 'Denmark', 'DJ' => 'Djibouti', 'DM' => 'Dominica', 'DO' => 'Dominican Republic', 'EC' => 'Ecuador', 'EG' => 'Egypt', 'SV' => 'El Salvador', 'GQ' => 'Equatorial Guinea', 'ER' => 'Eritrea', 'EE' => 'Estonia', 'ET' => 'Ethiopia', 'FK' => 'Falkland Islands (Malvinas)', 'FO' => 'Faroe Islands', 'FJ' => 'Fiji', 'FI' => 'Finland', 'FR' => 'France', 'GF' => 'French Guiana', 'PF' => 'French Polynesia', 'TF' => 'French Southern Territories', 'GA' => 'Gabon', 'GM' => 'Gambia', 'GE' => 'Georgia', 'DE' => 'Germany', 'GH' => 'Ghana', 'GI' => 'Gibraltar', 'GR' => 'Greece', 'GL' => 'Greenland', 'GD' => 'Grenada', 'GP' => 'Guadeloupe', 'GU' => 'Guam', 'GT' => 'Guatemala', 'GG' => 'Guernsey', 'GN' => 'Guinea', 'GW' => 'Guinea-Bissau', 'GY' => 'Guyana', 'HT' => 'Haiti', 'HM' => 'Heard Island & Mcdonald Islands', 'VA' => 'Holy See (Vatican City State)', 'HN' => 'Honduras', 'HK' => 'Hong Kong', 'HU' => 'Hungary', 'IS' => 'Iceland', 'IN' => 'India', 'ID' => 'Indonesia', 'IR' => 'Iran, Islamic Republic Of', 'IQ' => 'Iraq', 'IE' => 'Ireland', 'IM' => 'Isle Of Man', 'IL' => 'Israel', 'IT' => 'Italy', 'JM' => 'Jamaica', 'JP' => 'Japan', 'JE' => 'Jersey', 'JO' => 'Jordan', 'KZ' => 'Kazakhstan', 'KE' => 'Kenya', 'KI' => 'Kiribati', 'KR' => 'Korea', 'KW' => 'Kuwait', 'KG' => 'Kyrgyzstan', 'LA' => 'Lao People\'s Democratic Republic', 'LV' => 'Latvia', 'LB' => 'Lebanon', 'LS' => 'Lesotho', 'LR' => 'Liberia', 'LY' => 'Libyan Arab Jamahiriya', 'LI' => 'Liechtenstein', 'LT' => 'Lithuania', 'LU' => 'Luxembourg', 'MO' => 'Macao', 'MK' => 'Macedonia', 'MG' => 'Madagascar', 'MW' => 'Malawi', 'MY' => 'Malaysia', 'MV' => 'Maldives', 'ML' => 'Mali', 'MT' => 'Malta', 'MH' => 'Marshall Islands', 'MQ' => 'Martinique', 'MR' => 'Mauritania', 'MU' => 'Mauritius', 'YT' => 'Mayotte', 'MX' => 'Mexico', 'FM' => 'Micronesia, Federated States Of', 'MD' => 'Moldova', 'MC' => 'Monaco', 'MN' => 'Mongolia', 'ME' => 'Montenegro', 'MS' => 'Montserrat', 'MA' => 'Morocco', 'MZ' => 'Mozambique', 'MM' => 'Myanmar', 'NA' => 'Namibia', 'NR' => 'Nauru', 'NP' => 'Nepal', 'NL' => 'Netherlands', 'AN' => 'Netherlands Antilles', 'NC' => 'New Caledonia', 'NZ' => 'New Zealand', 'NI' => 'Nicaragua', 'NE' => 'Niger', 'NG' => 'Nigeria', 'NU' => 'Niue', 'NF' => 'Norfolk Island', 'MP' => 'Northern Mariana Islands', 'NO' => 'Norway', 'OM' => 'Oman', 'PK' => 'Pakistan', 'PW' => 'Palau', 'PS' => 'Palestinian Territory, Occupied', 'PA' => 'Panama', 'PG' => 'Papua New Guinea', 'PY' => 'Paraguay', 'PE' => 'Peru', 'PH' => 'Philippines', 'PN' => 'Pitcairn', 'PL' => 'Poland', 'PT' => 'Portugal', 'PR' => 'Puerto Rico', 'QA' => 'Qatar', 'RE' => 'Reunion', 'RO' => 'Romania', 'RU' => 'Russian Federation', 'RW' => 'Rwanda', 'BL' => 'Saint Barthelemy', 'SH' => 'Saint Helena', 'KN' => 'Saint Kitts And Nevis', 'LC' => 'Saint Lucia', 'MF' => 'Saint Martin', 'PM' => 'Saint Pierre And Miquelon', 'VC' => 'Saint Vincent And Grenadines', 'WS' => 'Samoa', 'SM' => 'San Marino', 'ST' => 'Sao Tome And Principe', 'SA' => 'Saudi Arabia', 'SN' => 'Senegal', 'RS' => 'Serbia', 'SC' => 'Seychelles', 'SL' => 'Sierra Leone', 'SG' => 'Singapore', 'SK' => 'Slovakia', 'SI' => 'Slovenia', 'SB' => 'Solomon Islands', 'SO' => 'Somalia', 'ZA' => 'South Africa', 'GS' => 'South Georgia And Sandwich Isl.', 'ES' => 'Spain', 'LK' => 'Sri Lanka', 'SD' => 'Sudan', 'SR' => 'Suriname', 'SJ' => 'Svalbard And Jan Mayen', 'SZ' => 'Swaziland', 'SE' => 'Sweden', 'CH' => 'Switzerland', 'SY' => 'Syrian Arab Republic', 'TW' => 'Taiwan', 'TJ' => 'Tajikistan', 'TZ' => 'Tanzania', 'TH' => 'Thailand', 'TL' => 'Timor-Leste', 'TG' => 'Togo', 'TK' => 'Tokelau', 'TO' => 'Tonga', 'TT' => 'Trinidad And Tobago', 'TN' => 'Tunisia', 'TR' => 'Turkey', 'TM' => 'Turkmenistan', 'TC' => 'Turks And Caicos Islands', 'TV' => 'Tuvalu', 'UG' => 'Uganda', 'UA' => 'Ukraine', 'AE' => 'United Arab Emirates', 'GB' => 'United Kingdom', 'US' => 'United States', 'UM' => 'United States Outlying Islands', 'UY' => 'Uruguay', 'UZ' => 'Uzbekistan', 'VU' => 'Vanuatu', 'VE' => 'Venezuela', 'VN' => 'Viet Nam', 'VG' => 'Virgin Islands, British', 'VI' => 'Virgin Islands, U.S.', 'WF' => 'Wallis And Futuna', 'EH' => 'Western Sahara', 'YE' => 'Yemen', 'ZM' => 'Zambia', 'ZW' => 'Zimbabwe');
	}
	
	
	/**
	 * Creates a quick form redirection to send back to the Integrator securely
	 * @static
	 * @access		private
	 * @version		3.0.18
	 * @param		string		- $url: the form action to send to
	 * @param		array		- $fields: hidden fields to send
	 * 
	 * @since		3.0.0
	 */
	public static function form_redirect( $url = null, $fields = array() )
	{
		$field = null;
		foreach ( $fields as $name => $value ) {
			$field .= "<input type='hidden' name='{$name}' value='{$value}' />";
		}
		
		header("Cache-Control: no-cache, no-store, must-revalidate");
		header("Expires: -1");
		
		$output = <<< OUTPUT
<form action="{$url}" method="post" name="frmlogin" id="frmlogin">
		{$field}
</form>
<script language="javascript"><!--
setTimeout ( "autoForward()", 0 );
function autoForward() {
	document.forms['frmlogin'].submit()
}
//--></script>
OUTPUT;
			exit ( $output );
	}
	
	
	/**
	 * Provides single instance of version logic for retrieving variable
	 * @access		public
	 * @version		3.0.18
	 * @param		string		- $var: the variable sought
	 * @param		mixed		- $default: if not set return this
	 * @param		string		- $filter: variable filter
	 * @param		string		- $hash: where the variable should come from
	 * $param		integer		- $mask: an optional mask for Joomla
	 * 
	 * @return		value of variable or default
	 * @since		3.0.0
	 */
	public static function get( $var, $default = null, $filter = 'none', $hash = 'default', $mask = 0 )
	{
		if ( version_compare( JVERSION, '1.7.0', 'ge' ) ) {
			$app	=	JFactory :: getApplication();
			return $app->input->get( $var, $default, $filter );
		}
		else {
			$value	= JRequest :: getVar( $var, $default, $hash, $filter, $mask );
			// If we are resetting pw on front end, post is empty for some reason
			if ( empty( $value ) && $var == 'post' ) $value = JRequest::get( 'post' );
			return $value;
		} 
	}
	
	
	/**
	 * Method to build the log in credentials array properly
	 * @static
	 * @access		public
	 * @version		3.0.18
	 * 
	 * @return		array containing username / password
	 * @since		3.0.8
	 */
	public static function getCredentials()
	{
		if ( version_compare( JVERSION, '1.7.0', 'ge' ) ) {
			$app	=	JFactory :: getApplication();
			$post	=   $app->input->getArray( array( 'data' => JREQUEST_ALLOWRAW ) );
		}
		else {
			$post	= JRequest :: get( 'post', JREQUEST_ALLOWRAW );
		}
		
		$post	= $post['data'];
		
		foreach ( array( 'username', 'password' ) as $item ) {
			$post[$item] = stripslashes( $post[$item] );
		}
		
		return $post;	
	}
	
	
	/**
	 * Common method to get language across versions
	 * @access		public
	 * @version		3.0.18
	 * 
	 * @return		string
	 * @since		3.0.0
	 */
	public static function getLanguage()
	{
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$langs		=	JLanguageHelper::getLanguages('lang_code');
			return $langs[JFactory :: getLanguage()->getTag()]->sef;
		}
		else {
			$langs		=	JFactory::getLanguage();
			return $langs->getTag();
		}
	}
	
	
	/**
	 * Sends an email to a newly registered user
	 * @access	public
	 * @version	3.0.18
	 * @param	object		$user - JUser object
	 * @param	string		$password - the clear text password to send in the email
	 * 
	 * @since	2.3.0
	 */
	public function sendMail( $user, $password )
	{
		$config	=   JFactory::getConfig();
		$lang	=   JFactory::getLanguage();
		$lang->load( 'com_jwhmcs', JPATH_ADMINISTRATOR );
		
		// Compute the mail subject.
		$emailSubject = JText::sprintf(
			"COM_INTEGRATOR_UTILITY_SENDMAIL_EMAIL_SUBJECT",
				$user->get( 'name' ),
				$config->get('sitename')
		);
		
		// Compute the mail body.
		$emailBody = JText::sprintf(
			"COM_INTEGRATOR_UTILITY_SENDMAIL_EMAIL_BODY",
			$user->get( 'name' ),
			$config->get('sitename'),
			JUri::root(),
			$user->get( 'username' ),
			$password
		);
		
		// Assemble the email data...the sexy way!
		$mail = JFactory::getMailer()
			->setSender(
				array(
					$config->get('mailfrom'),
					$config->get('fromname')
				)
			)
			->addRecipient($user->get( 'email' ) )
			->setSubject($emailSubject)
			->setBody($emailBody);
		
		if (!$mail->Send()) {
			JError::raiseWarning(500, JText::_('ERROR_SENDING_EMAIL'));
		}
	}
	
	
	/**
	 * Creates an encoded session hash for transmittal
	 * @static
	 * @access		public
	 * @version		3.0.18
	 * @param		string		- $name: the session name
	 * @param		string		- $id: the session id
	 * 
	 * @return		string containing hashed array
	 * @since		3.0.0
	 */
	public static function sessionEncode( $name, $id )
	{
		// Initialize items
		$params			=	JComponentHelper::getParams( "com_integrator" );
		$salt			=   mt_rand();
		$secret			=   $params->get( 'IntegratorSecret' );
		$string			=   null;
		$data			=   null;
		$encode			=   null;
		
		// Create base array
		$serial	= serialize( array( 'id' => $id, 'name' => $name ) );
		$key	= md5( $secret . $salt );
		
		for ( $i = 0; $i < strlen( $serial ); $i++ ) {
			$string .= substr( $key, ( $i % strlen( $key ) ), 1 ) . ( substr( $key, ( $i % strlen( $key ) ), 1 ) ^ substr( $serial, $i, 1 ) );
		}
		
		for ( $i = 0; $i < strlen( $string ); $i++ ) {
			$data .= substr( $string, $i, 1 ) ^ substr( $key, ( $i % strlen( $key ) ), 1 );
		}
		
		// Create array and encode
		$encode	= array( 'data' => base64_encode( $data ), 'salt' => $salt );
		$encode = serialize( $encode );
		$encode = base64_encode( $encode );
		$encode = md5( $salt . $secret ) . $encode;
		$encode = strrev( $encode );
		
		return $encode;
	}
	
	
	/**
	 * Common Setter function
	 * @static
	 * @access		public
	 * @version		3.0.18
	 * @param		string		- $name: name of variable to set
	 * @param		mixed		- $value: value to set
	 * @param		string		- $hash: (<J1.7) where to set variable  
	 * @param		bool		- $overwrite: (<J1.7) overwrite or note
	 * 
	 * @return		mixed previous or null if not previously set
	 * @since		3.0.0
	 */
	public static function set( $name, $value, $hash = 'method', $overwrite = true )
	{
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			$app	=	JFactory :: getApplication();
			$prev	=   $app->input->get( $name, $value );
			$app->input->set( $name, $value );
			return $prev;
		}
		else if ( version_compare( JVERSION, '1.7.1', 'ge' ) ) {
			$app	=	JFactory :: getApplication();
			$prev	=   $app->get( $name );
			$app->input->set( $name, $value );
			return $prev;
		}
		else {
			return JRequest :: setVar( $name, $value, $hash, $overwrite );
		} 
	}
	
	
	public function update_settings( $data = array() )
	{
		if ( empty( $data ) ) return false;
		
		$params		=	JComponentHelper::getParams( "com_integrator" );
		$updates	=   array();
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			// Joomla 1.6+
			foreach ( $data as $key => $value ) {
				$params->set( $key, $value );
			}
				
			$uri = new Juri( $params->get( 'IntegratorUrl' ) );
			$uri->setPath( rtrim( $uri->getPath(), "/" ) );
			$params->set('IntegratorUrl', $uri->toString() );
				
			$updates['name']	= "Integrator";
			$updates['element']	= "com_integrator";
			$updates['type']	= "component";
			$updates['params']	= (string) $params;
				
			$table	=	JTable::getInstance('extension');
			$updates['extension_id'] = $table->find( array( 'element' => 'com_integrator', 'type' => 'component' ) );
				
		}
		else {
			// Joomla 1.5 specific
			$params->loadSetupFile( JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR . "config.xml" );
			$existing	= $params->renderToArray();
			$bindarray	= array();
			foreach( $existing as $key => $vals ) {
				$bindarray[$key] = $vals[4];
			}
				
			foreach ( $data as $key => $value ) {
				$bindarray[$key] = $value;
			}
				
			$uri = new Juri( $bindarray['IntegratorUrl'] );
			$uri->setPath( rtrim( $uri->getPath(), "/" ) );
			$bindarray['IntegratorUrl'] = $uri->toString();
				
			$updates['option']	= "com_integrator";
			$updates['params']	= $bindarray;
				
			$table		=	JTable::getInstance('component');
			$table->loadByOption( 'com_integrator' );
				
		}
		
		$table->bind( $updates );
		
		if (!$table->check()) {
			JError::raiseWarning( 500, $table->getError() );
			return false;
		}
		
		// save the changes
		if (!$table->store()) {
			JError::raiseWarning( 500, $table->getError() );
			return false;
		}
		
		return true;
	}
}



if ( version_compare( JVERSION, '3.0', 'ge' ) )
{
	if (! class_exists( 'IntegratorControllerExt' ) ) {
		class IntegratorControllerExt extends JControllerLegacy {}
	}
	if (! class_exists( 'IntegratorControllerForm' ) ) {
		class IntegratorControllerForm extends JControllerForm {}
	}
	if (! class_exists( 'IntegratorModelExt' ) ) {
		class IntegratorModelExt extends JModelLegacy {}
	}
	if (! class_exists( 'IntegratorViewExt' ) ) {
		class IntegratorViewExt extends JViewLegacy {}
	}
}
else if ( version_compare( JVERSION, '1.6', 'ge' ) )
{
	jimport('joomla.application.component.controller');
	jimport('joomla.application.component.controllerform');
	jimport('joomla.application.component.model');

	// Good ol' Joomla changing things up mid-stream
	if ( version_compare( JVERSION, '2.5.5', 'ge' ) ) {
		jimport( 'cms.view.legacy' );
		if (! class_exists( 'IntegratorViewExt' ) ) {
			class IntegratorViewExt extends JViewLegacy {}
		}
	} else {
		jimport( 'joomla.application.component.view' );
		if (! class_exists( 'IntegratorViewExt' ) ) {
			class IntegratorViewExt extends JView {}
		}
	}

	if (! class_exists( 'IntegratorControllerExt' ) ) {
		class IntegratorControllerExt extends JController {}
	}
	if (! class_exists( 'IntegratorControllerForm' ) ) {
		class IntegratorControllerForm extends JControllerForm {}
	}
	if (! class_exists( 'IntegratorModelExt' ) ) {
		class IntegratorModelExt extends JModel {}
	}
}
else
{
	jimport('joomla.application.component.controller');
	jimport('joomla.application.component.model');
	jimport( 'joomla.application.component.view' );

	if (! class_exists( 'IntegratorControllerExt' ) ) {
		class IntegratorControllerExt extends JController {}
	}
	if (! class_exists( 'IntegratorControllerForm' ) ) {
		class IntegratorControllerForm extends JController {}
	}
	if (! class_exists( 'IntegratorModelExt' ) ) {
		class IntegratorModelExt extends JModel {}
	}
	if (! class_exists( 'IntegratorViewExt' ) ) {
		class IntegratorViewExt extends JView {}
	}
}