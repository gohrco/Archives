<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class to generate a hidden field
 * @version		3.0.15
 * 
 * @since		3.0.2
 * @author		Steven
 */
class HiddenField extends form_definition
{

	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.15
	 * @param		array		- $options: contruction options
	 * 
	 * @since		3.0.2
	 */
	public function __construct( $options = array() )
	{
		parent::__construct( $options );
	}


	/**
	 * Method to generate a description
	 * @access		protected
	 * @version		@fileVers2
	 *
	 * @return		null
	 * @since		3.0.2
	 * @see			form_definition::label()
	 */
	protected function description()
	{
		return null;
	}
	
	
	/**
	 * Method to generate a form field
	 * @access		protected
	 * @version		3.0.15
	 *
	 * @return		string
	 * @since		3.0.2
	 * @see			form_definition::field()
	 */
	protected function field()
	{
		$name		= $this->name . ( $this->array ? '[]' : '' );
		$arguments	= $this->get_arguments();
		
		$args = ' ';
		foreach ( $arguments as $k => $v ) $args .= "{$k}=\"{$v}\" ";
		
		return '<input type="hidden" name="'.$name.'" value="'.form_prep( set_value( $this->name, $this->value ), $name ).'"' . $args . '/>';
	}
	
	
	/**
	 * Method to get the arguments from the object
	 * @access		protected
	 * @version		3.0.15
	 * 
	 * @return		array
	 * @since		3.0.2
	 * @see			form_definition::get_arguments()
	 */
	protected function get_arguments()
	{
		$args	= parent :: get_arguments();
		$check	= array( 'id' );
		$data	= array();
		
		foreach ( $args as $k => $v ) {
			if (! in_array( $k, $check ) ) continue;
			$data[$k] = $v;
		}
		
		return $data;
	}
	
	
	/**
	 * Method to generate a label
	 * @access		public
	 * @version		@fileVers2
	 *
	 * @return		null
	 * @since		3.0.2
	 * @see			form_definition::label()
	 */
	public function label()
	{
		return null;
	}
}