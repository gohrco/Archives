<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class to generate HTML markup
 * @version		3.0.15
 * 
 * @since		3.0.6
 * @author		Steven
 */
class MarkupField extends form_definition
{

	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.15
	 * @param		array		- $options: contruction options
	 * 
	 * @since		3.0.2
	 */
	public function __construct( $options = array() )
	{
		parent::__construct( $options );
	}
	
	
	/**
	 * Method to generate the HTML markup
	 * @access		protected
	 * @version		3.0.15
	 * 
	 * @return		string
	 * @since		3.0.6
	 * @see			form_definition::field()
	 */
	protected function field()
	{
		return '<div style="padding-top: 5px; ">' . $this->value . '</div>';
	}
	
	
	/**
	 * Method to set arguments specific to this field type
	 * @access		public
	 * @version		3.0.15
	 * @param		array		- $data: contains the data passed along at field initialization
	 * 
	 * @return		array containing remaining arguments
	 * @since		3.0.6
	 * @see			form_definition :: set_arguments()
	 */
	public function set_arguments( $data = array() )
	{
		$data	= parent :: set_arguments( $data );
		return $data;
	}
}