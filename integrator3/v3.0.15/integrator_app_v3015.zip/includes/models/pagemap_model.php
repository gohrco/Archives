<?php //00922
/**
 * ---------------------------------------------------------------------
 * Integrator v3.0
 * ---------------------------------------------------------------------
 * 2009 - 2012 Go Higher Information Services.  All rights reserved.
 * 2013 June 17
 * version 3.0.15
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPoMAD9xqJutHbLEXlP0vuYlAm0Pb+V8OLleE71cbu+Y+y/7xfM0Bigt4CG8ktp4rjo/iqmh+
xZ/tBIxa4r/WPcjasIjRm6NNVx/wyQCn88s6s645idOujvh/8jBGLalSswl2IsyuqagDP/dqtROu
rYNi7kTVnDuzBv4bqDOFKyadgpldhAKKrIO2l/8KSqh7204akdOAa5w59fK4IKGQJiNO+CYuZmnF
KsLtbp07Vo7AaLqzbnIefie3h/b43Q2Rwp25yGaZcU+Y9RTbtRAAaIs9TAtuDVNl1SrY/vfJpQbS
REdG5LIUO4z6YKeLR9kf1V4H5MPO6/X5H+Skxg4dn36sk8a089ZobQRB4Il+E/nXeCNU6KCx4gIT
paNZkPw8PqaTeRqsWeJ7Xprma+IZhW1eho6JdXDIj25JJ4sz9VK6piQ79GdQVd7JTgXxN/kUf3t8
4B2YfNlUK35twC3kBHKSwY2Jj3GwYAV/stLqXbVlG9CV/1O6DeXVDCMgLufPdSGFvUBDw8e98gGK
RQA3CHwOi7MkGDPgwv5Jax/KcCcdn5AVnxogf0LWqmvpTODNXOYqUTCqPgxAtRAgQ77xqYhrLWfk
YyEDHd1aYxisz2WOtN+jlRAvOCdqNMh/vhZ1cXJ9DNbqDzBqsKAvSa8LtyuGpuPKcO0zW4hwagGp
Vg3I+s0osOQ/CHDcdlvZr4ZWRRSBZqGoUAaw/DwLkBVYD9WldKIhiAziBy7nmamT1TabDuNxcp1f
OVRZk+QFi+9DVb+55hfAJ49G8nuTKziSSb81rHgYrP1GyxRD6yFnbyt+TMvuB9wYIHXgLtI6r3tY
XQO7dPk/SShjlxoKDm+OLQE+c9aTYgjy4QaShzo1ZA3pTuwhUzCHMRUBW+LvfsMoPxdSRIyki0pO
a7kWHzMU5pGwqMwsvYifAs338PCzmeVMBE/N77Iv08qgh4csNzqf1SzTIVU0yazuDuIgLF/xif+R
7gmXR/NYIUa80kKWogEWaRugVLie/NG695+v4oKJptN8EKRq7+YCY8TIgauhQ0HJ22sKGydTsWVy
ihGGUVZOogWfj6yZmOKSqnmu6wJafFzouEe+X8aQKwzLuFYK3gAaWp9dKslzNKCMUhu6HvyZuU7l
aVZPVTNystGN8QcaRS6W+1Y3BYR1QplWVcqqYVm3TPiCV4DTQAjGbsEXUFV6LkiKKJzug2KI/KSa
JM0lB5Gq/boJunpJgKJrUoogsCeMwQwuEcRwOGBSG+PcVkbVgZISf1rCz8Xn3kCKx3gPfKDSulDD
q7rY+BEX8gEx991kqJlxj/Th+3aPXnSnJwtRHKbUfQ2xeapRaGkKSUUXlZsZMgO6IRWuOdjSyKIu
qxWuw+jB6JhgDyPsnynBZYYDECAQk1a3aIiZ4/or7ElTPNmwdlsiNfZy56sjmxYHlJi61oDH63ys
czXC7v8QxhZVQ2e5WtLjqwWv3FIbixGBaKDZdb95S44j15kCyXPXjxPEyrZXDUlqH+DnOSwqYsCA
7sdkjjwsMPSh4Tadd0Q209ylOp9SS4NB0BY8q18fO5w37mfgVaNrmhCR4O4H4exm7HSHfWd7qKDD
vryhhge7mlwBMT1YShuLmUKQPlO1VvQCKoQ1dexdvCdaPUU8UP1+YwcmEngS6uumx+peB6veeF/e
fM5b/REvnMWgyqD3x22pBBj3V8oSU/OAsPoZUWyTVwplcjP48tNgQ+sGfNJAgbsZQQKqY9DPr5hN
kPYrgFi231DOZID6VlIVPLiLuMzEA0vhVpMriC1bg4BCRj8fc5ZaisrZVal/FSWhKBckhYcTOWrL
XwKZpJzr1Xl0VFNjiSHZgvIDGULQIUl25dS57Hjj5p1hGiReOszL7IBLYzKD40qJhzGeUE4n59gy
lsXcHXBcZdjUSMMSGAExQ4BSCqbE+ykcv8Z37SHhi+T5DGTL9dCaqwM0xWOTKnrTM3X0trrJR1I+
8T/di8ZZv2WUaiT+GBuBDVTXzislzuR4If/3AtHaMN/nMpw7BTNt5OfPo68i2H4pcS9NVON1CoE+
mCSC2z68HJLGjm7DPuBnEixoSR+U3LWVfDpCL6nJJTqPHBfGB2AITSpACy6wXL7LbtCo6Ps8Qc2L
vAPHwWfNqnYoNp65G3vVzMbFB46xfz2rQeDgrWKDM8tI89O6PP4WzeOgUYigpu+f8hU5HQywq6Nw
YSAPk2UBWmULcHDqa0bMmD5+uhbx6uLg6K/l/AyZj8hUTR6lTGKxCe6VWEVBuacWZWmhJRC9dEKm
swZD7HCZw09aioYLDqesmffjrHsFjY02fAul6MGm4gnauiVf/j+sd1BF5vMynfcQ2N7hjdi1exC5
+/QZgZ3U24M/P/QF5EP9/vyDZtMxbZIScFSuTTANmNZ7cL/YgNQKg4b4/viklhDUjxyrQDwTRGf+
KNQ9I/nhONFtrddi/N/QiH64MuGMWomWBqIt2G1pebM3KjfPGZRLRQetrSwHEUT/JoGz1toxfTaJ
vuEJ4ruCvRG7Mm+NVSGLMSSKXqNLj/ucmXtWuRaob+vQQFQaI2Y1909y5Yk4p2lvBa9lRqMO/XHS
PJSTYLkTHwbEdXm6plU9yuD0/pzUX3gjt2sUYm6xVEPPfcMZY1GJs+3ddqtclUuaHwF4RVuxcMbg
EUvN9qQm3ctJ+4X9uzm0ySH9ufr9STpFS55AXoWnYuRZZ/n88YPu+WVzX2//qH/LNqUfm/fqgFrA
PG958Otv2bh5+lGj/Uugz93UfHF3ZC+yUQhRko0QQteovqRap7wY/s4/M3176vv8YYjuC7/7sKVP
8HHw1VVrIfnSBXY1ec5LhO8mouUE9kdLVHp8fBzoo4v8HptPHqk6OD9aSxiq7o9lBTEz/0AJas3t
XYvfhUlE8Bd0N3r5gIUyS2idW8ggboWsUT0TQyV4rFUyrxvU3tqDdgWVQxDMw2X+j2fL139bDo2I
vzjnD48ras6TsmMrr4Kv7W4Lhn6OqfEo0l4nywFmaxjq5B00D9PbhzIwDULA+DEEqs8qe/pOjM5M
+LasWPpDmRKTiwNoZ1FrIlyhC3S/tQ+R4G7TUjQs8QYIW/KjXKS4wVRQGRqgY32Km9Q1b11BRQa5
F/78Awz/bSUSfJB4dwEHQ3hf9JquGnyqFTEiG/ijS/5Rg+MXKQSFUUeAMXj9l4Xk9Jb3wBDuftqc
5VSVQR30WneplmqM8HJ/hsM3f269fBzVGgtcL3O1CZd17/AykZexEISg+mVDDhDuMQD3z2bQ5JE/
Lw6eR7jInSiZlU7GAFqN1DaAZiGLw/zjXx7CVr4W+r5g8guINDLgIn4UCPIzVD4tpGLh9osE7OUF
tvDpTVT/Z638oNmHcNk0f5gI38HoZ5enaZFzmDqFOt055MLW40xWW6EjW7OLG61dSfUp2CEtqJNw
hABXAycsfwt44CuK47altY+QCLsTd8kccxT7O5x18lMmKlURMTpSw/xY74CMPgbpCNd4YpYL2mSc
cuZfxsSPSWjhsM+Ih4lU+U2YXlzRQOS34YT7pQdEfWoKqO3wbK67MXoN0DnFbE1E3SiPQuEKdVFL
8s3Za6KVDmQYTXavaCIhoV+sHRryTPiKObuTBmprwMGtq+EiZ2GoGXQBYq3onRZOD+9jIvOtkmWg
t1bb60HaVUf/RVrezXxrfULES2C9XhLVQd3jUXnspqPGBbWOkO6P4Neq5Ms4uat3hiQY+hGLqHfq
uVpv9T6Zkvlfr+rXiglvrvEpXYA3n4sM47zxfVyDxRu+YlrWUkZxTX0B9qLsD/z71LzublOez221
SweUzVvxJMK4poDIdn8ptMtmwpeLn2JWFP8X9Ahim9RILXulm+tsnk7yMF/cH2dLbjehirNkzauT
8Hcbyt7T7YMhX7yX6X9gCvPlbYO5QaMWnexHiDNouejrd7+W6LnrCXy38AUHHgc9HijqO+qLf4fL
8fCYZUK8Q6w8GJJOmBVSvk9/vOzWOc4dnHp9i5de47qZVPT2xiIKrHn+JrdejfEre+Dr0tOT6j2v
VzJG3YkQ30rup2rvbXf7L5Zk8drR2BKDzfADQddZUoCHXc34TS/AYWVHU1402LCrbpYNX+SXMV+G
IYpDRvLZxdu8IJMvHHwVsRhv/ENIqW/TNXSAN81G/JDwo/s3fh7F39Jor6XhCAcZaEpKfRousTPl
YCYtE7H1x6HCj+OYYRC4mnoCHbYIGQeCv6J/zhDIhzCkOV1PKEEX7ivz98fMxFSSJn70ebY1sFkb
mdR5ZJ4U7Hyzcllq14obYLvNcEmt0sv/2QkXOV6ttGuOtgMpXVKLwdNWPRs+ievt0zOLtq0zcfLr
nfU2+h0pQ0uglL2asypY7AfJixNMPDJ6ElgUcakRkehuIbkf2ojx+Oud0hz5Y5gJNUrb4H+fxk/E
iOPfKnVgLbql3Gc18LuXir2ILp5Ti3Zcr418aHjiUTeLHE92BvT9fHlkXHadsLd4jLBrCnK4hdaF
Q8EmHUgMnNvFK+z5RW6vRV9dmxGetZ1svRqjHt+7+Kc48R3mB93Yqqbjry7Ma+eKu3W/l7YJKfAb
4ikbxXDysfzg9QkynPL0EZOulwAAFfZNLhMCN6Ny53wRPNleN1KMS6m6y4Goh/r2CsOxiAMqOrLx
zQI8M1mZck/ht/VcsvCl7GNgNVcNYp/gZhljkNJHgShHbiZURcfDGGoS3G8Ogl1dyfuiaES2bQ0H
T+rnHpRLjKkKjv4wWYSPCCA+DG1Y2gsTtduUUQI4g87zAtDI5+JPrVbTDo+qTmvUxlcCwANxrckS
EKdKV3tLu5H9Srktr8WTAlF+mwvow9XKuDPuCLyktNwGnueUdBF/0aZCPs57tkCxS6QyntF2C5gn
OM2+BFxhU5I+902xwOCMQTYC1f/t6GpbjPIk6xN7QdPsAthFV/naU1vQD/r8GJ4WnFm0Mm7N0NDO
6jCnfxAK54g8v/vtO0P6uNJ2sKTFHjTBpxbMKrXv/fV0Fdx2JgTnLren0/RLOqVhgLw6BDDBDLU4
Kqb6sYY3Rhm4v+XR4IhPLQPtRVvQGHepmXgM3/wHP3jFCCOHU0N8UGqeGcEjBJyn+fNA3OqE9LaB
DLGuMtve3N4GBeQ4rT2+fPLlxpbY/syL5zgAKFKVHgEcRMGZA72nN//upJ4zmlaIm/0QCHH+OCEB
vR7AYwDXOOU1PJi6AP9lSO/NPewX612kNBQ/TgzIvYinAcXENpyMLMo4AzRR0vE0pURMztcASNqD
jU/EYiVn9UZd5w5gZNr9XQUbPEtUq+OWW/kjKF2+PlhI/jLqvYJReaklCs47NBQgK68ciOpXoxKz
z2VkknLXFW0JK69TEQU3QfT8ac0SuJ7fJkn+ASE72GKOa1XndsmzKNyE9QhNG1T8Le8/2qXPTgAQ
VwpFUuXOv+A73baYSkKJZPZkgob53L7UBDOicI++X+E6aOUd2k4Hv3YbBV7cKyI1HoZg9S1t7e52
Mbo6A6C+lAsmIe1A9A6sGvqov65rCYgFuG8zTBX++IlVxmVqQJOnm/gHxCFyJ6DaT8gGQzhRsbNb
Q/Y4wyydWgIp7TR4OtLEjhcLi/KsqmpIJf6vJwQWMpZol3Q54P5dHZUEvVuL/spdZ+C97xxLUbL0
r/4hLGUKu21oIU/7LJsj5ns29OEVjUKKPFsTJpYcdMZ4uGUcGTo+cBHbAIFk5W+tV/p82sgomeHX
Vr3rX/lD92Gq0g8txa7yYE4cq/th4tk40nwrophbPfp4dsbaXPe0SfbW61fn4vARbkLskmlDRLb0
tnfhCPKhR8lmJhcnjRwa3KWrjUEucmG0/CUv0hQ9ttIUkxiv/A2KBqPys5d/7aCwMZ7y7w3Oo5Jt
Oa9Sf7UaKhJkKEyQIv/6fNQMZSvM8rPwdODifntifltOaKRQV4NIhgPJPeJYkwOi5fXxHrFNWtGv
sr4eAWdSFiUKVzfFy9SSZ66aFpuCKeLXrbiOmnk7uY3XJfhmdIe8FuCXxG2KC4lksuwCji6l2/93
rbOBzja2EHDiOKl4ytR6ziJf4uWztg6p6YBnyuG+sh2wInMlwf38zZxkix0ZSEogAfh5s23vr3vz
OkFjPMHV/3g/RjrGZlNUKka7nvyIgjz0uvGaz4GMK/90z2x08g4G5EbQ2YQD9r9890kcdIbgn+6C
/W4WRcEnj7KqLG2apPjWMoHttbiWTd4PTr/wBrsgljmOBQVMUYqutqQ63czNHd+H4M2NcP+Redkj
KHcVfW27HoNEfOZtyqeWz7G4hHXJRPrP1R5+z20/7M7j6MvxSwqmzGriTTPDuK5HvEmq/ib7dWmv
YsTQl1GUFuqfnB+QpsLuJ2f3j4ySecVBqCph2uvGuwxGwYeQyUs+Z8TI0Loxo3ah5x29ES+MuZNJ
bFhpdCu+DHx2jf0HS6lrfw1tkWx5lHlFY94MNqqK1hkzIu1W4kSu+R/34h79FwHyDBFwA60knpzL
vGYRdaqiYXld9kzpjZ7VkkBnTFrNVyS18vxoTP6iMSJ4VXB3Gp/abQCLK8L+kPDzqJGa/r2UiUI1
4MT6gNbJmSxSRLwD5cX7QL0LiXKcG0rYoI9a1pvUY1oMSoIRapXs5Qky3AFHM0MxavVBUr13rbCL
K7kj/nNr0rLz/S1AZY6LU34i4HS1fOfGVT5sXKedM1jJEc4R+M/B+d1FbWk3wWvtHbJCMxzhPuso
rOS99CLHnOEwxWb907qau+DoxwlXLcHXUts6yQonYtSSHSq19NCuNadaLdYcQJPZQMlfKWnvptsZ
ISabmFHPGAxOPgXsTVjsgq/l9C+5+mtYCDvdWmwiXw9GXLrpYwJqvfJgWMBxPPkSmwAe2HpEWSEa
PQQyBpgim4ClhHfjQH1FK4QtkHVyJ5F/ZsbYlMg+N2jnG0tMZY6yCw6hSZeKs9ST5BOMc0QffrqI
yB2O/S5NPbaoB41Aj1MkejfaeS/8UeQo3UMjX195b2TET2LpFsYAqXJnTu/+CanGuNmazkerVtoQ
hVYb2m6+gVRzqxHDS+F6vNadPd9+5ZLqBHd3AG40SMjmtph+DAz+d1FCGfH+Jpfv8pw2uOyN1GbS
/YU3zDKlsp+pC7koewUBfkVzIy65kl0thNv36hsTEKzceWlQWRYI+SYyjhdcYvw+AMPcieKuDJI/
PYqsD39B47ZdryneGtIEGI/tckSXA+fBzw0I/AJYFbaHsCxnPfx8UL1YSqTDcGkZBMk/Fd9TZHFz
12C9eHdqKHl+D2h7fLC+vezjbWFpdGHBqRmvZ+ESFtxVOnqnDXeZvF6XD3TV/4WQtRmSL0Nv9eZx
KJf/ES4bHBCw5KDk69+A8BJzcWuzeaYLJ4qfhPoH5Y8BSImh8J8cd+jzNXswACkQcTA56bQUVLDI
BL949Qk8zbMjBkSXA8EZv14fusRx8jnW00/CWZM2xeDgr7CYwalxO2S9a9LrScwtBTErrmHc+qa0
Qc9UUzFTsPIOgzBQFIo5l4g9MQg5Z6D4ePDrFJcTd/6cJKE0uG9K7nFzK1jlBzOB0j73+TxMknV5
S0+YkmGwv30jImUQrZUngs5+OnPEsUBSYwiObgX9Wr2x7yuJbMaJesFajnV7EEEM0O+uEq68Kk19
Xz8zsgrxaA2oixVuDHHRKGd3Oy+SecK9xQ8HBSXceub22smspueS926vQwkQQwqg418BO/Helxdw
+5q6TBEmVe+WOs1jKUchoZRlM31+Ymg7Q3+jLq7gIq07cj1SkCWHldNXO0/DxIEkYVbIGu54Nkbg
9HJKCKyWKPDeLw7xGnQF/std6IK4aJ9aafFZbxiKfwM0cGDhnurc8o/0nJw5oDhoUWXipbcX6orE
KM2hehcI+oqtkltStiYvw4gCDaeXdq4mVUhHU9mHCTM9ETf8sguDZpZ99NcYaDWS5r1pvZETPkRe
AiTn7aKVh4vAqA98Q1JWzNInjNbbVkzrCdGAunvXGt3w7H3yXizS7XPo8lQcbU+8m5N+M7zNhdlW
z+4zJpuNxAjxoUv4X5G3eitViD+6gF1BXk2E7G0Qxu7S1gwA5TwQ9uimOPbQb9Sg4c7Y0rcNMUs0
3ZLOZ44oQgQzfSx/ZJzAnUhUK5ZITrY6c6lr1NVYD7agVSysZfurIERr2zcYUVUbcGw7t0rNM7kJ
K0Zj3TD4wcrP8mD9/Z8KIzxkLytIELC4QkTvk/vJLoSOKvMY6a1nU65/4p0z3oL3BeZyB3JzULxJ
aAQnmww7aMhLnjFuCuBOxwysIi2HVYyCiNPkPgohcetEmXgyr7reym2wPYutAKbQZsWz7Wb2vuC6
TbAYZ/lq6oe7QVUlZ+fSaX76CU3p+F2Fz2M0hSyPDrqPTSE88L/J/r8zadHCAzJArFkEWRDayIh6
tr2M1gTzYVrlG1Ufor8BZ43OrWYR/FiTX9ogJrHSLvUqdigUHGn8G9mf5nbA2j3UoDK3eGcfqK6n
fhnZ4JYkQQeGtdtbSao6qEAFao5AwwDgdT14JGq0tL6OZ/Qxr+3NBnK2ydybRjpMLsZzuB9KqKG5
AS/KfFnKyVdBqxlhZJ3fqRngsXethDDPGK5EGfsbVSoSDJDxI0w1P7SfEpgIAD6LvJAd0xad9nDG
WyYxLWdmvtqlHIh6VN2xEGa5dWXjYc2XNSOXHJHKnBimxraol77PgW0b4/qc6ZSpBo4U58hmerLt
ivhSRF600AHLNx/36zVW6UvioeMYN7gopQMDDAlE4PiQXYYryv1Ove646xcR3fcZH0iqn9BK7vjS
0cJHEyLU5Ff2tbQi4OsPBz8tUH0e/Hyev7IQgA4N5Pcvv8zIJlFzhqvP0BRVAixXTNRh8Zr0hn/N
Sa+91tW3BbOSWNyFHQgV8SReCV3P1iak19ipIyYAK0KjwGAMhiGBCD7bMnsxAf8F3EVx/QOfIfGs
LmawaX+5ALk2S6I4eGrI++E6AzLX/qTK9O0SCnKL8GJ196wUoohRWMB+S+rH43igzlJ//0oY/V8X
S3R/dgurr8A30OQpu49TKVnpTHqr1z8JI/S3bc8YOmWtMYn/PaugMnRSDuILX1syUWpRcrHMIhm7
qYoyYEvBBeOUFe8ubnjfCJiGY0OqAvKpNYixUqkf+GBavtcy882Hy58D+zXdjohzAOcje3gYV8j5
jwQ7j+4huMwexE0qYbx5+Dm+09/oEC/GlyhPWdido8vC+Dm7e1iIlCRhzbEzdXZ9DOA1/5RQYwoi
U2DxnD1k66+RaeidAGEThAf6KoRCVsaCc7g2WjWAogeG12NfGMzuOv1tHWx/05InxeykCEnU2c9k
4e9kjHeBKygT7vi1baA5KRWkZjkdnYoJj5Lm6CV56KOrVVgUhxM2uYg4EbTsCB8OvAnhoj2Gp2yc
/Ovqpg3n6aJljLlgK/zgQBQ4DnQuw3M4vpE+oGQILLQUYk/TsEawcKOwnEdtcIWg5wMadCrxfDEx
aRb5aUe57tV3X6EHifjhYYmGSw/mYmiW9Ml2OItGjZJZ8bVvR9NdWMfFKqaDZsWp4sjv1pFruuSs
YHg5LHIhM6y7fMtqgP6C+fTduZ9RKWiNueepLEfl0Py/yI64mTk3dSU787barNk82i0Bi7yY8Lua
HykPqtNpveZgESQHRkPbIqSC6RszMN6YHm==