<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.15 ( $Id: routes.php 74 2012-10-01 15:55:25Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the primary configuration file for the Integrator
 *  
 */


/*-- Security Protocols --*/
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*-- Security Protocols --*/

$route['default_controller'] = "process";
$route['404_override'] = '';