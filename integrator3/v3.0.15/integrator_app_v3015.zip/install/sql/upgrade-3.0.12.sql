
UPDATE IGNORE `__DBPREFIX__settings` SET `value`='3.0.13' WHERE `key` = 'Version';
