
UPDATE IGNORE `__DBPREFIX__settings` SET `value`='3.0.14' WHERE `key` = 'Version';
