
UPDATE IGNORE `__DBPREFIX__settings` SET `value`='3.0.9' WHERE `key` = 'Version';
