<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.22 ( $Id: integrator.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This is the main file for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die('Restricted access');

// Ensure Dunamis is loaded
jimport( 'dunamis.dunamis' );

// -------------------------------------------------------
// Ensure we have Dunamis and it's loaded
if (! function_exists( 'get_dunamis' ) ) {
	$path	= dirname( dirname( dirname(__FILE__) ) ) . DIRECTORY_SEPARATOR . 'libraries' . DIRECTORY_SEPARATOR . 'dunamis' . DIRECTORY_SEPARATOR . 'dunamis.php';
	if ( file_exists( $path ) ) require_once( $path );
}

if (! function_exists( 'get_dunamis' ) ) {
	// EPIC FAILURE HERE
	return;
}

get_dunamis( 'com_integrator' );


// -------------------------------------------------------
// Load up files
foreach ( array( 'legacy', 'helper', 'toolbar' ) as $item ) {
	$path	=	JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_integrator' . DIRECTORY_SEPARATOR . 'integrator.' . $item . '.php';
	if ( @file_exists( $path ) ) {
		require_once( $path );
	}
}

if( $controller = JRequest::getWord( 'controller', 'default' ) ) {
	$path = JPATH_COMPONENT . DIRECTORY_SEPARATOR . 'controllers' . DIRECTORY_SEPARATOR . $controller . '.php';
	if ( @file_exists( $path ) ) {
		require_once $path;
	}
	else {
		$path = JPATH_COMPONENT . DIRECTORY_SEPARATOR . 'controllers' . DIRECTORY_SEPARATOR . 'default.php';
		require_once $path;
		$controller = 'default';
	}
}

// Create the controller class
$classname	= 'IntegratorController' . ucfirst( $controller );
$controller	= new $classname( );

// Perform the Request task
$controller->execute( JRequest::getVar( 'task' ) );

// Redirect if set by the controller
$controller->redirect();
