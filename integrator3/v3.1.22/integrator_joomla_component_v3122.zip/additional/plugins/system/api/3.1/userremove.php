<?php
/**
 * Integrator 3 - System Plugin
 * 		Updateuser File
 *
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.22 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This is the Userremove Task which will update a given user in our Joomla site from I3
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * User Update API Class
 * @version		3.1.22
 *
 * @since		3.1.00
 * @author		Steven
 */
class UserremoveIntegratorAPI extends IntegratorAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		3.1.22
	 * 
	 * @since		3.1.00
	 * @see			IntegratorAPI :: execute()
	 */
	public function execute()
	{
		$helper	=	dunloader( 'helpers', 'com_integrator' );
		$input	=	dunloader( 'input', true );
		$data	=	$input->getVar( 'data', array(), 'array' );
		
		if (! ( $user = get_joomlauser( $data['email'], 'email' ) ) ) {
			$this->error( JText::sprintf( 'COM_INTEGRATOR_API_USERREMOVE_ERRORNOFIND', $data['email'] ) );
		}
		
		// Grab the user if it exists
		$user	=	JFactory::getUser( $user['id'] );
		
		if (! $user->delete() ) {
			$this->error( JText::_( 'COM_INTEGRATOR_API_USERREMOVE_ERRORDELETE' ) );
		}
		
		$this->success( true );
	}
}