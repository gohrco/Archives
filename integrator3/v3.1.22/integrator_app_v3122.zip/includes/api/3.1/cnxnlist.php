<?php
/**
 * Integrator 3
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.00 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * API interface for application
 * @version		3.1.00
 *
 * @since		3.1.00
 * @author		Steven
*/
class CnxnlistApi extends BaseApi
{
	protected $_controller	=	'cnxnlist';
	
	function get()
	{
		$ci		= & get_instance();
		$data	=   array();
		$cnxns	=   get_cnxns();
		$type	=	get_var( 'type', 'applications' );
		$_c		=	get_var( '_c', '0' );
		
		// Add the Integrator to the mix
		$cnxns['0'] = $ci->cnxns_library;
		
		foreach ( $cnxns as $id => $cnxn ) {
			
			// Find Integrator and catch
			if ( $id == 0 ) {
				$data[] = array( 'id' => 0, 'name' => get_cnxn_name( '0' ) );
				continue;
			}
			
			if ( $type == 'applications' && get_cnxn_library( $id )->get( 'isvisual' ) === true ) continue;
			if ( $type == 'notme' && $_c == $id ) continue;
			
			$data[]	= array( 'id' => $cnxn->get( 'id' ), 'name' => $cnxn->get( 'name' ) . ( $cnxn->get( 'active' ) != '1' ? ' (inactive)' : '' ) );
		}
		
		$response	=	array(
				'type'		=>	'array',
				'data'		=>	$data,
		);
		
		$this->success( $response );
	}
}