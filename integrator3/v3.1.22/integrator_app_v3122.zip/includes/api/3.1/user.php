<?php
/**
 * Integrator 3
 *
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.22 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * API interface for application
 * @version		3.1.22
 *
 * @since		3.1.00
 * @author		Steven
*/
class UserApi extends BaseApi
{
	protected $_controller	=	'user';
	
	
	/**
	 * Method for deleting a user
	 * @access		public
	 * @version		3.1.22
	 *
	 * @since		3.1.00
	 */
	public function delete()
	{
		$cnxn	= get_cnxn_library( get_var( "_c", 'delete' ) );
		$cnxn->cuser_place( get_instance()->input->delete() );
		$stack	= build_api_stack( get_var( "_c", 'delete' ) );
		
		foreach ( $stack as $s ) {
			$s->user_remove();
		}
		
		$data	=	array(
				'type'		=>	'binary',
				'data'		=>	true,
		);
		
		$this->success( $data );
	}
	
	
	/**
	 * Method to update a user
	 * @access		public
	 * @version		3.1.22
	 *
	 * @since		3.1.00
	 */
	public function put()
	{
		$cnxn	= get_cnxn_library( get_var( "_c", 'put' ) );
		$cnxn->cuser_place( get_instance()->input->put() );
		$stack	= build_api_stack( get_var( "_c", 'put' ) );
		
		foreach ( $stack as $s ) {
			$s->user_update();
		}
		
		$data	=	array(
				'type'		=>	'binary',
				'data'		=>	true,
		);
		
		$this->success( $data );
	}
	
	
	/**
	 * Method to handle user creation
	 * @access		public
	 * @version		3.1.22
	 *
	 * @since		3.1.00
	 */
	public function post()
	{
		$cnxn	=	get_cnxn_library( get_var( "_c", 'post' ) );
		$cnxn->cuser_place( get_instance()->input->post() );
		$stack	=	build_api_stack( get_var( "_c", 'post' ) );
		
		foreach ( $stack as $s ) {
			if ( ( $msg = $s->user_create() ) === true ) {
				userlog( 'api-usercreated', get_instance()->input->post(),  $s->id );
			}
			else {
				userlog( 'api-usercreatefailed', $msg, $s->id );
			}
		}
		
		userwrite( 'API: ' . cnxn( get_var( '_c' ) )->get( 'name' ) . ' (origin)' );
		
		$data	=	array(
				'type'		=>	'binary',
				'data'		=>	true,
		);
		
		$this->success( $data );
	}
}