<?php
/**
 * Integrator 3
 *
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.22 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * API interface for application
 * @version		3.1.22
 *
 * @since		3.1.00
 * @author		Steven
*/
class SettingsApi extends BaseApi
{
	protected $_controller	=	'settings';
	
	function post()
	{	
		$ci		= & get_instance();
		$ci->load->helper( 'cnxn' );
		
		$cnxnid	=	get_instance()->input->{$this->_method}( '_c' );
		
		if ( ( $cnxn = cnxn( $cnxnid ) ) === false ) {
			$data	=	array(
				'type'		=>	'binary',
				'data'		=>	'false',
			);
			return $this->error( $data, 'CNXN' . $cnxnid . '|SETTINGS01' );
		}
		
		$post	=	$cnxn->get_properties();
		
		$post['active']							=	get_instance()->input->{$this->_method}( 'active' );
		$post['params']['globals']['url']		=	get_instance()->input->{$this->_method}( 'cnxnurl' );
		$post['params']['api']['apiurl']		=	get_instance()->input->{$this->_method}( 'cnxnurl' );
		$post['params']['users']['userenable']	=	get_instance()->input->{$this->_method}( 'useractive' );
		
		// Handle requests to set the SSL
		$usessl	=	get_instance()->input->{$this->_method}( 'usessl' );
		
		if ( $usessl !== false ) {
			$post['params']['globals']['sslenabled'] = ( $usessl == '1' ? true : false );
		}
		
		$cnxn->save( $post );
		
		// See if we should set the debug
		if ( get_instance()->input->{$this->_method}( 'debug' ) ) {
			$params	=	Params :: getInstance();
			$params->set( 'Debug', true );
			$params->save();
		}
		
		$data	=	array(
				'type'		=>	'binary',
				'data'		=>	'true',
		);
		
		$this->success( $data );
	}
}