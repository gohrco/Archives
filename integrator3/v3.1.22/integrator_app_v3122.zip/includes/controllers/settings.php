<?php //00982
/**
 * ---------------------------------------------------------------------
 * Integrator 3 v3.1.22
 * ---------------------------------------------------------------------
 * 2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * 2017 January 28
 * version 3.1.22
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.    Go Higher Information Services, LLC  may  terminate  this
 * license if you don't comply with any of the terms and  conditions set
 * forth in our  commercial  end user license agreement(EULA).   In such
 * event,  licensee  agrees  to  return license or destroy all copies of
 * software upon termination of the license.
 *
 * For the full End User License Agreement, please visit our web site at
 * https://www.gohigheris.com/policies/commercial-eula
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPvoXJqC9AhHqr7ZQOAIYjaWjprPk+nL2JC8JkinjYYN3VOzg/aRSubybd03a/g2aU4EhvlXx
QK7A3luZ2j10iq+1lz/yU5V4pIhJJkVU5htjiw0gDXHP5zfWteYREKlt6T8UREEYg/CoufXmg4L6
Nsip+KAHYYPZnab+0Sj/TjjNrpt8aAxQmQJCh2IrkX6m54Are9/SIgOgBEVidQf6Nq+00nPv4ENa
61bBtTf7q2Xu1Opm67nhhNpvZfwSlOkKBXwUA2JdXFI/8EgU1vza5LGO2H2kQaXZLnqa1X/2kHtw
tqDSV1+dyva8/5Uah4Vf6DPWXfbCrQVM3ySNHWDxxgxAkBBEd8eQtrPlkgwHcszHn98IUNz3+sEY
vE4aDXzWXv83MOGIjl3USkus4fB8QJ0B1BPMnZ5UujSoKH2WETm+fBTD52+U8QSiA4MuKv2xna3J
rzbsAmYa5Mp1pnvo2hiNjF0+kMX59KIRtKfFXmvl+/MeGapbz02p+c/aGiml2DGlMQRVqs0xpe+k
OOR/kLhcQbpUIrXzxJ7CGqCFDDk7K+hqx9geM6QbxKFPRHRhlnRu8qHIKXcaCdMmJjrMHC8XOPaK
GvhLBDXGXzSnxxEyk2F3+RDImA5Rdq93LLqI26RsAYwIaJ4K/+eOzNxydrh+v7/532sCQYbT3JzI
5MzIx7EN7/62hjwkRD7BGflqUdmC2n2zMUuopAHG1RLGdSsgd9GoXehDoCGwrVm9ob1BSKLICOKR
uE6ti4LjvmtFWSf4sJ8Egry3AqlUsm0/qouOWotk4ujlT+1ddqZ7FU8znEmS1LVXszzLpBNyv2jZ
zwYToI+kjxVV9ySjx1Pl9AvqBJzi9iFmcgZWDrqx5RPw0xlQ+d6D/d25rdbQCpJCGi38sNVvULYV
y9Njzrc9ELI/l1MBgHwsUzFyhxqD0TLKNSPmilQm25kh+G9mtQEAhb6ve/cjp0UzL+sk9Q/OZvnA
uhqzgkpOaaa50ky3Bd+9lpFv4ScKGatZJRyVWLeRGd0JLYkBRi9jwrzXoFtodXWTDwrU4iErGhup
lJWsBJXfdXfi/UD12vse+BUnPmG36c/dfjOKQvTq0BrM+ga2l/kbex1wM/jzRbxup3aTrXIhT6jV
hCD53YAWeUSYptpd8HQoa9n+M4uKmt0Iv9bL6nKRzAmU7gwaOS87JevAQL8pT2Xem0TqZVt/Shn6
gvfHxoOxpWN6Dg0AQ7i+jVH5qIAZdRcLynK4s5MMgLcMP50MXIchLveRqUP6WRjIGPdvIFmsXrfQ
RYFklTih/0gdxsKcziZD1Y1TS8FB+rReaz/SRFVSBejQTqgqK1a/DVzdCl1JAGDPnwKJUWiIrGV9
oZK9YS9zhc7Is20r3VDarIO6HR3FRfHO5TRxyQQKiPaFNc7gKUZ2DtffRwDdcDfnH1XKKWijsGAc
l6X8bx65DoKK3kV9mxQQqkBy+zCKpQa211+DX5w2CAkHmyYl6Qs7tvy6OELEA7SJ9WuwzLz6dMhU
D7NjGe16hk/FD0kXg/WTwaX78XFqvOUqyVL7kqfAmNvTTOZ5AjTftP2Vub4HXhL063al7U9guoQi
hpwAO7TX+idyPY3AddG3mSvk5FYp/jZPDsIrFQZ9CLdBOJaZT+2N4wQTVLWeFkEQ4rBQnH5qkzNC
0Ezez+5A4YKeaEiXKYx+RVX+LztUmGL59i9pji1viLDHBMJRiwZ59n0VglIAQaFPGxxs+6KYCUhB
O5vDyBLvgmImcq07jTfOfADP07JErXQKL4Pw7iP2jEz8PqYkfCk1YGuitA8UmUGDS8WZQ/nnd+NR
QPualoyQiOXUeTORewk8rMJvE/d6A/JVbvcBEnAEdcz/+eQGb9J4EQxa+ZGSusdeum2BosLisrrq
XOqjOZtfT0Qgs2L9TwI+slg5S3q3uRIaRXe9j5sfuyxiFhJgigt5mXWFmfYkgT+vN0+qDXNJUWyP
df1zWacCZ0RY2uCcJ6iFnzbvO5sqD8aioMxuUsUFu1PPBz8xUNe49DrIpqRNuHp/LM8djhtFko2V
u1v0hV2YNtWGSW6JZL+W3ChNuS8qQDkq1X2a5KFKmNcE4tnCR3EWXRfbuGEwwPklSB3LT/Rsf3Gq
/Z/TMZqlDhO5Wn4SzJWmtg8w42Fbe2YYNl5cOvFzeAZB2/RfWCa9/R8BIdPvaDcrJazKX/SXteJW
L0gAhSWFOGpgrZbKDfswHU2zXpcfNEZNCfyeKT+xUC5YEa1jA74Fb3rPbbt2aWngup7wNztFTaLC
yC1yQ2G6sBuPWycHswSTpLI3hhWRNXEfnVAJspfg0qkU7uStNlD9yRm+VOL9/3YHNaoxd5XT6zXK
AE3L5dCH0OmeS6+PrD2vZIdK9UyVEzS0U4LBdzTCMrz1s/iwjknCZoUNxdYwan9kOHWkPO3Ug+FW
ej9EPq9Vht3EyHNYgV2bjVzADcNdIUto/kxTXfpJ1tRCR6j9BCxMFTGFpFXLQH5XSrCDrAeh+yOQ
51oN0PsydPpjUNmB5CrOZ5/fVRTHz95oM5q96V2nFOBMS0UDASj6/0zYSn8xK8m5s4kCG1wSjpcd
y6tZfopK3zEAN8Cguw50f0M4/gAfXEzLgpsjj78uo4zOZGnPkgIAbSPbxsSD4FOCeDFa9GiUEJ9x
5oZlkkgDB6XiYdnlAQFFR9UH6ZCSy63QRAmTQXvabOLKEGyftsRL46KkYa9C3aGPACHw0/MxXfhr
7VlUabgasNE+N+VQ2gddpKPKXBmPH/zw+t3G8rE18uIcMWpArQe53Q2rLAu6Kne43X3DVCllT6iB
QPFhC/bAMj4XaJq45/2tIUnRSeF+VT7zhTm1ESRqFrWVKf5fILYS7A26Z7PwRdyPl8o8dsa0eChn
pBTO0mrkGX+m8xOQHNFpw8yU2bUwhEZ4te3VkPkVQDFZl7le+cCEBk5qG6KDkqN1YhKT6dvtR1h0
I5mqLP4oOhlmEhxAyJGfDLHZj9JK6hzz/6+XVD/k7CrAIm+XTbHNBqvJCrdEBnEYwMKxTpQQPHiI
chENMBNe4Hgibwj9SCk3FmjG1h6pUcKIUaR/qSi7AcJaq2UwT3LbbZ7TEzUCDCgE+L9nv1lStRgH
48gClHFXTIhKrg+R8EBsYUM6rNPCx/YIEj/qR9k7Leogr0fmQSRMTS6P5SawqRG7ljnOX0fTC/4m
njOg7Wok+ICbgkjIsRav9AQIRG41Z1mJX9MkHZBiuasGkSEZXDIPmxUJsKY90wxXZVFMHv2qW0Ya
mQAS8Ic4qBhnA29B5igypGpU6OBjvqoSIowd8RZz3sko2Kuf0rB26w8fUhAO1Apeu/v6dLqrw8dl
PnMZDX173gi89L74nPKmDrb75tAH2JHi8/6+u+RhylmMYr5M/G6Dwly7ZkijBAQ45zf258ViEV+j
BAqT3ibcB0ps8XWdmGIUVlM0lQy2amlyiJSvCi+oNCkOfPGiS5Qug26ZOVRYsQymPooO4NqrKXfc
ZLC+s/ZXFcuRlpeIpcbrKRNiM7I9wEbQqau43DFTBq2p5DUV1afavFpG26sYaXv7yUCm0FrkuhZ1
bcGXDOXfkHd/KSYsVBkdOzZMU+cXwbRA1iTXYLy4EXugPB2NEv8MZGHSiWN656NrhuFx1QNAR7yZ
Jx4hC6+GjAdQoDHqHIHvZbaJUt9GIjJhkeiQWXNnBf5RXshX6BeurxpxNFyxVOkh/53FUofkJW+J
FkYeR7cviVWRnVSE/cep3LTj18Qa6LET2z9N/oNRbg253m5BqZ3Cdfda0H/BWiEdLY7Q6x2SArwf
xUj0dRGLu0IRNtUS5Ht8EAd6ee98sgpWO9Y8W+LVX1CSEB8qf2mvVMaVt5sP4vcauDMozawaaOpE
awEbiCK5bts20t5I3tUm28P9sHGuu5okx+UPuNgCXHe9gRbGHP9V2E9RA71R1DSXYGIsaaNVzbqZ
MLNFsgZUj8CiMJZN9P5bsu1MSxsLBy8bJliJBwkcn4P15a+eCi1Zx5iundIGqj7TpDXwEyeddPy2
z+SMotcoW+BB14FwNFD1q/et9SC0MA0X/NvNM8SLU1SiOh62j70VrML/D7seDUGsQJaiFqtE+q8Y
lZfiiRNQ9P3rDmsLrO7J6FXZMz3xKHBpm3ZlzVh80ckpX89MOGb9gM+h3lMbIs21R2+3dwWnZcvn
S0AtU0jgvEF1ryoY0iJtcuBq1mGEecCX6tR4X7+e88n6VSrV0Mpvyp95k+Y7GRAzoTwBxoo+9xTh
NfbeakXv4kiLoZF719Kmd3lr3tLvAMrjsJ2XnmJOVqyJWuTP6QOTHTatq5I/4hO/N7OY4Hy1rvJJ
2uubcfP9utRgiCAF9NS1tPVeVKpblnoRuIhBAv+KiqEhQ/f3w+/V/Uj6VEsqny9z6LCn9pWAE08V
/NgvvRiUwEtaiu27oP/kJC5rmYqscLIdZ9R9JJUjgoD3y5eBVHPkJn6hNc5i2nKnwFt0gx+nXEsv
Hu/G5Q/UplZ2qD8rM5QfRmKiAbLSepMI+nevFnAVKkMkRE1KOfwImhrf+wvLV+t+B4crzKZk6rUI
D0koqfCe26yVpOCkVuip3wkTLsdbknnuBK/d6kZbFYWRNbB30nr0Mf2CAZs7Q+pzS/1cqWumc6Uv
wZ90qgumyR3d9+D+7YPmA9Z4byQVp35SeVDmjRpVKjPQmIrSJoOAABBqZDKLe8rcVnFryGKopy1k
JJHRmm6FzId+bKm15WHYle7SnPsuTRDa0aorttY/pDeYqHA1w3CcRsONI4IZdkruxxb4k48HENKH
aFWOLG9mxdzVZEGA1cmMjytNQ0iO/ryXldwCE8zQiNH7cKMDjG1/kUZPsOGqTH+aVbPfbJi9hjlO
FTUY7vSJHf8gulErv6B58LE/YGFY9xdUtjVvLUUfmkvObuuoudp2+DKbi/t2jtRBlhwP7s9XjeO3
aPkfdgzziqKOT4ARp7SPkxMLqpxNf77f8iDxh9Tt9UHP2HgESRjq/L39GAWcr7MTTeWBVMsuhdwM
CkdcoOgj1dJtJ/sQb9fkBExje6q2XE0MAyLyFVyNakYzmClTYCXe40N2H3LI2fw0VCfqgahKUe8f
vjeZhaNCjZaAfhejxa40WmqmG9I2HRj+0GGDs50HIw661cBJKsdlTSExEi4TRprim2XqXhHYLtJS
pCdKeFwSrEFBbLiUcjjLgPesY2fh+uYerAu6fz851HWxx4tBnzbZ9GcgZFTqSFFBl4SfgEaMfDng
9Zxi9RsBLnxHTnJ7fjrI3MbuTj15ocHlCvFNsEnDWomqXBQC7pRaj13h6XF0oIfQIFcjBB+8zGUA
j6HlbAAn8T45RkJdoWY49+VFcD+Q9NYyHqYtoUJqCwVQeGSc3KobXZCjuIzXg7YWCslAu/AMIK5S
OkSR2bJPSZ/BZ16E0NZ8Zfw72ytSR7iDQOje5aNvqFTn/9ipQzqCGz0D1RhYZQYc31TY/roYGjU9
8fGOfqY75n3ImFUBHmjw69DUvep7EbI33/+23Qatx7wZztlsNd81B6Axhy79/FuB1Ot48LdBjA2y
Qo4WbOoMikvd7CxJSsgOe0vq2Ml0k5A39BuAQ/xs7CIIprinOuk+tl5GOU2u4dkDziFZeFpDi77S
IKIYPW6onlHI9acjyU2tNcPbpgUTIddErSeCjt0b5HNq5a5mrDMoup4L+YM9x4+Y8058mu5U3+YH
dNUB0dsKTER9SzxhjVdW4V+CAswkv6iTwgJ/uDJd8x80A8pG0Q3Y7Co4fGoCAHujiyUmWjnMR1SG
7aMH8biJGR719JIlOxsuqdjmhFqY7j7f8cxyE+PplMKzFS06n+86Qq5jUwjVjOLm+klAbsfD/+iD
MiQfPsKAm427NWMNN1WXnSkyghm1PGL7WCof+Jg2+CpOKM+TD4rMgdYJCSDwQqFNwAEdYESI95ls
A4qTXnO+bUcvTMtXhgEWC57md9yGGY91Mrw0dPsAswq8Tq/FxphGVygThTfxrulRKqLuIBd+Nm7P
ujCTd32agXhFvr3Z/7R7zWeR70QOiBNfAus0oWfBwI56lQ660VfQG9/n+VYpu5SiL+8u9BNI183+
XZypFjZhf0YA71tM6RW/eyUH7GQ6e26jClyTwJVmxaH/lor9CcvtIoUDnZ42hi3T9uSQSQcXec+1
QwblHS/MO2k6L1s2rZ5v09EgA91W7V4YBmsI4+lncHleSAjm9Jvz6IJHl//c1CXdeUGQIYZG3G1r
0XRuIRB/2/xgdkgW0ag0moZwh1ac5Dq5+MzYQIK8EtBmQAgPOB4LcqoLOIHaRz3PyOB/hpJ39u3T
R5BavvPdUa8ELvWYb35tsjoPGISoN7ZYea6FGb9FUuyfurz2w9Yk/O4VuwSN+gdiy1cSA+1RXJc+
63UDUqfi7XsOdjYx5wLLI2yNr/qP1espCEREtBG57ZHhd+kMrlP7I8cd87M/VZ+xYx0hm/CVG94N
fhbC7+raYTsUAExy0k1Fzmimm7yOmwFjUvGP/nOw0vaD1CeqCdEXOmPxE5+j9VxOJZLaknAUFMTE
OjxqjjIgU+wSbHRrk2hXIfSF/OK5oEgRrxYV84Mgw50PSKfcnmK2atMCsz+H35r99xQpEMAH2OZQ
onBAcplihQ/U7xvUylGNV/kpxnjcTMOLsu60y7pm8tsBykiHhI9Lc0rmrULo8OT6kE6HD9BSgDqu
3Qxj9+dbepOX4B2YKQ0rvRAA2O0CM4vedUoyG5rOzen6/U3hn3wlNqGeqRqk6vfhkGblM3j69CRh
1XcXtyIApA8zN4wvqP4rqyFpzoMEF+xgPOEBCsjwP+9I/tv1aqM4pGUasByPisnaYmmBeP22+LaW
oPjCJ+CHY9dHyQlgJ+JgXfgDseR1/KdBVWV/rawit/HQYjaHsmF3oAfMRgxqB/2HOuHKQrtRJOU6
B8sU1p5hS5VRA3uPC+zIMlukqnhsmvPrH/P7dFlut5TDYGuMatfnYMqPyipOtylOQzvuciO2XZZw
pOOEmYVwIDngmL9q0jDDfQnmKstROz9oPDGUjhu44mubymupnMC3SH3kWF5NPC06VB4J3kkOzlJd
d9hWP7JBNpJ3jV//l78/kp4EMmmAUb4oqtqeFyBZBpgpeFbzoCy/VzcPv9EZRUi6Yr4kbi4wTQez
3UXeOAT447RU/qYgMxNvTMTFE3kPQu49U9W5R9ba4MtlrfLFZbcDtWKQI9agSI7l4cNWkp5+qAKX
SaFH5s8iJst/T37aX50JaO5PkpBvgN7x4B9FpzQIHVyvvDzrww0N+YKr1DSjqkblAWBcgwoqrFdO
6uueNF7pCBVwyrh2v7LxeMrPIJ+Ny8KnDipxuiqFclmgP1h48hqsVqCOLYoGpKNHd217u70wogvu
Enq0fcIn4N8Hby6mUMrnsZ2N2/Y4r9PUab/HylxwWdSY3FEJxonFOhwf7g4iV7fmTHpnae/1AOyH
mihvepyoy6UC8l0Gnsu0DPGOy3xWCRSFRmqg5Jzx7iMMCclNrqTebjwH46Jr9wlNpBaD1FKMGgUV
dO8lH26qRzJkY1ez4yJ9VjVM7mwZae7YzT0Zqg3EnY0fX+rNUF/RUFS2Sr/BwcL5aUcPorlc1Bku
q3eR4sG6RSWtbkGjpK/P+A8ji+0ixTF7v8PXdLG/AY8RsW/WPkROzGqxiGZInqv+xoQ7/sRT1nZ7
q894fsbOK0Bs33dGPy4a6uPSjm4K54lJYvwLwYxgE9YloZcTQg54/Ha+f1XOCZwihEPyWuWBwgwn
AI1bS5Ff91bgfjxT2e5RyMiN1AD0QUccP1wFhKYydP2cJ+YKB2wWDl26JUbe+Ku46pAKSdobjJA5
PtrTcCUkbfkFIIkjvbRYBXzPZQHOmX3hDybNbtjOdi1k1E7Vg9cmxBYWxc/3QjHSGOx6QbBT+f/l
0J2pIwGIfTrY/qWnbxK1gdbYiSFCZsDyEcPTSdaBAR2GXj4foYTxCI0OUuDNkhtjjGCtH6x5Z0pW
0LNovF2i81y8hlLcKA5C5tgkpe+hMvmzx9iU+h3X9nZ1g46e7uDUNNeMHfQOHZwfv1okXt+ujzZ4
/c3Ne6nO6gury096mwCHFQNzLgHCBZtL0hDGVYUYRyFad0s6YwXpSTwlFH6k1lP6veI3dOB/wge0
HvoTj/FcRi/QIdUQ/hX5s0GAc+gfQYhogM8q7+sOfGAaMP0BulLfZtbW91tB5ZF3wBGb6b+G9gB9
xi4kIbZz7SPaqIUiTrC/JsEuzb5SDO+NBsqGglXDCECGsaZ/kaF/AQAG0LK5zzPsXWw7aGlRs4sg
/XJ5NCt5HI+h112lrt12d4lozpJECtqx7LdmHZfFVZC7hr0mqnPoqie5IGjEkYwjWOmDxMaAfLO7
UXPWb/a/7SPRpDLGB0AzuCbvvagJzP91/FajuEkog3kkGXkIFemL1UNJla+M1kS2kgVOxDkthNPi
zCFg021zHn8MkRbUHPduLhsuQGRFYzCWwawiOhQmy+mdGKQHxe8OmEiIqnmsInRa3qd6ZIqZSwfT
N7dyAPqivkjmvGqWvMrgqhBt5Xw4JrOSoaH1yaE/lTtoiqcu8ysJE+rzdtDFiwXPkwYWbBmlnLPz
CizcLVqb06QgQpa7aL8SXH0zfLPpyfPFgvbCRG28Xh1ijiSBHsgmQqIwNwTbxWkIZWdGBmBuv1Yx
chL+ExSJ0bzy+3wBR1p5EzMBiBiETdK4d5tZLqsMmNluybG50sbDm9lbw0aXYUDm9uRTJdDS12zv
a5HchgLllKeHCeWiWAM0pi77dfQEeXwdHqFL9fA9byTnzHJHNFyC5Gma9C1yJjZq/Vt90gNi2qxu
nAIg9xVkQOjtMQQbyP26Zb9MXf2/51FKFQhlBYS7fbs9K9M+Sa/9ESR8687dxR1lgEFtbqThBJDE
jZ0dziwloEUCaXonucP3hsYWYVU1YCewB9OnoGYuJlLPj65BeJCSYYPn/oqZgtombx+sbvKs2drH
fPmY/Y0ElwB14EdTWAn8kVMoDBTjQvDsepT5mmGJdD1/Uf2BXn7wScujI4jRfr9Br4EJmspWAYIk
c4k62qP9VKex+tUmSwou1duBCefCHzeCPxXovk4hVE1blK2lMhTrzJ4tsYzT+cy94dDbm6CSpRV2
2NfjRNRv5dyEmdYGMNFiRioYEMGZtfTnYMwlZIGYgOqv64ECz45Cj1AQr/WxtmwnbaLfDEf8dP5Q
MzxYDXyWqt90C1rTXmB6L8Dw5j8WJtADaukw3VeVgbUp5LXMO9Wg67yRvSdWIUaBBuvd61IrIauc
9Q6YBVqbRwtN2qYsTXL5ZaA1dby3S2ZlCVZ0fvZTfxGA2+zuDyq4bkIM7zNzXrJ3M4LKaHI2RSTI
AlAXhEPUAJxHxJInWKC1VKdH0axoUfTYDsHebTy2HypBXjSOXvsWd02VcNlXo66zbQnmndT6v4HT
KW3q8EhS2m0FO+c4hovpk0gDbQb4PmLAak+iIBFjbXTZbZgeQ0+RsP3vsuwzWfmx5nVGCZZ+BM82
i7aANK726CkRGwmhGpKSc/4f0Zg3fs5ye9u=