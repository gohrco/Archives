<?php if (! empty( $steps ) ) : ?>

<div class="box">
	
	<?php echo heading( lang( 'stepbystep.title' ), '2' ); ?>
	
	<dl>
		
		<?php foreach ( $steps as $i => $step ) :?>
		
		<dt><span class="badge badge-info"><?php echo lang( 'stepbystep.num.' . $i ); ?></span><?php echo lang( 'stepbystep.title.' . $i ); ?></dt>
		<dd><?php echo sprintf( lang( 'stepbystep.desc.' . $i ), $step ); ?></dd>
		
		<?php endforeach; ?>
		
	</dl>
	
</div>

<?php endif; ?>