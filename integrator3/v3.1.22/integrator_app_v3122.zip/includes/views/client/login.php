<?php echo heading( lang( 'title.login' ), '2' ); ?>

<?php if (! empty( $error ) ) : ?>

<div class="alert alert-error">
	
	<button class="close" data-dismiss="alert">x</button>
	
	<h4 class="alert-heading"><?php echo lang( 'error.heading' ); ?></h4>
	
	<ul><?php echo $error; ?></ul>
	
</div>

<?php endif; ?>

<?php if (! empty( $success ) ) : ?>

<div class="alert alert-success">
	
	<button class="close" data-dismiss="alert">x</button>
	
	<h4 class="alert-heading"><?php echo lang( 'success.heading' ); ?></h4>
	
	<ul><?php echo $success; ?></ul>
	
</div>

<?php endif; ?>

<?php echo lang( 'page.login' ); ?>

<?php echo form_open( 'user/login', array( 'class' => 'intReg well', 'id' => 'intReg', 'name' => 'intReg' ) ); ?>

<?php $row = 0; ?>

<?php foreach ( $fields as $item ) : ?>

<div class="control-group<?php echo $item->error ? ' error' : ''; ?>">
	
	<?php if ( $item->type == 'checkbox' ) : ?>
		
		<label class="checkbox" for="<?php echo $item->id; ?>">
			
			<?php echo $item->field; ?>
			<?php echo $item->label; ?>
		
		</label>
		
	<?php else : ?>
		
		<?php echo $item->label; ?>
		<?php echo $item->field; ?>
		
	<?php endif; ?>
	
</div>

<?php endforeach; ?>

<?php foreach( $hidden as $hide ) : ?>
<?php echo $hide->field; ?>
<?php endforeach; ?>

<div class="row">
	
	<div class="span1" style="text-align: right; ">
		
		<?php echo form_button( array( 'name' => 'submit', 'id' => 'submit', 'value' => true, 'type' => 'submit', 'content' => lang( 'btn.login' ), 'class' => 'btn btn-primary' ) ); ?>
		
	</div>
	
	<div class="span3">
		
		<a class="btn" href="<?php echo site_url( 'user/forgotpassword' ); ?>"><?php echo lang( 'btn.forgotpassword' ); ?></a>
		
	</div>
	
</div>

<input type="hidden" id="myurl" value="<?php echo site_url( 'user/login' ); ?>" />

<?php echo form_close(); ?>

<script language="javascript">
document.intReg.email.focus();
</script>