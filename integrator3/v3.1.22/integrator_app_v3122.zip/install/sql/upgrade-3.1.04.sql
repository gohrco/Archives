
INSERT IGNORE INTO `__DBPREFIX__settings` (`key`, `value`) VALUES
( 'downloadid', '' );

-- command split --

DELETE FROM `__DBPREFIX__settings` WHERE `key` = 'GoHigherUsername';

-- command split --

DELETE FROM `__DBPREFIX__settings` WHERE `key` = 'GoHigherPassword';
