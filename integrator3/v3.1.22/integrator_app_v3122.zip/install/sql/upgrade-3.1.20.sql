
ALTER TABLE `__DBPREFIX__sess` CHANGE session_id id VARCHAR(40);

-- command split --

ALTER TABLE `__DBPREFIX__sess` CHANGE user_data data BLOB;

-- command split --

ALTER TABLE `__DBPREFIX__sess` CHANGE last_activity timestamp INT(10);

-- command split --

ALTER TABLE `__DBPREFIX__sess` DROP user_agent;
 