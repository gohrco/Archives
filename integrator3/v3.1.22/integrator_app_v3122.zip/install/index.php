<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.22 ( $Id: index.php 485 2017-01-08 04:39:59Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This is the primary executable for the Integrator
 *  
 */


define( 'INTEGRATOR_INSTALL', '3.1.22' );


/**
 * **********************************************************************
 * ENVIRONMENT / ERROR REPORTING
 * **********************************************************************
 */

// Set the environment constant - can be specified in configuration.php
defined( 'ENVIRONMENT' ) or define( 'ENVIRONMENT', 'development' );

if (defined('ENVIRONMENT')) {
	switch (ENVIRONMENT) :
	// -----------------------------------------
	case 'development':
		defined( 'ENVIRONMENT_LOG' ) or define( 'ENVIRONMENT_LOG', '4' );
		error_reporting(-1);
		ini_set('display_errors', 1);
	break;
	// -----------------------------------------
	case 'testing':
		defined( 'ENVIRONMENT_LOG' ) or define( 'ENVIRONMENT_LOG', '1' );
	break;
	// -----------------------------------------
	case 'production':
		defined( 'ENVIRONMENT_LOG' ) or define( 'ENVIRONMENT_LOG', '0' );
		ini_set('display_errors', 0);
		if ( version_compare( PHP_VERSION, '5.3', '>=' ) ) {
			error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT & ~E_USER_NOTICE & ~E_USER_DEPRECATED);
		}
		else {
			error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_USER_NOTICE);
		}
	break;
	// -----------------------------------------
	default:
		header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
		echo 'The application environment is not set correctly.';
		exit(1); // EXIT_ERROR
	break;
	// -----------------------------------------
	endswitch;
}


/**
 * **********************************************************************
 * SYSTEM AND APPLICATION FOLDER NAMES
 * **********************************************************************
 */

// Set the system folder - can be specified in configuration.php to permit
//		testing of new versions of CI
$system_path		=	dirname( dirname( __FILE__ ) );
$application_folder	=	'install';
$view_folder		=	'';

/**
 * **********************************************************************
 * RESOLVE PATH AND DECLARE CONSTANTS
 * **********************************************************************
 */

// Set the current directory correctly for CLI requests
if ( defined( 'STDIN' ) ) {
	chdir( dirname( __FILE__ ) );
}

if ( ( $_temp = realpath( $system_path ) ) !== FALSE ) {
	$system_path = $_temp . '/';
}
else {
	// Ensure there's a trailing slash
	$system_path = rtrim( $system_path, '/' ) . '/';
}

// Is the system path correct?
if (! is_dir( $system_path ) ) {
	header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
	echo 'Your system folder path does not appear to be set correctly. Please open the following file and correct this: '.pathinfo(__FILE__, PATHINFO_BASENAME);
	exit(2); // EXIT_CONFIG
}



// The name of THIS file
defined( 'SELF' ) or define('SELF', pathinfo(__FILE__, PATHINFO_BASENAME));

// Path to the system folder
defined( 'BASEPATH' ) or define('BASEPATH', str_replace("\\", "/", $system_path));

// Path to the front controller (this file)
defined( 'FCPATH' ) or define( 'FCPATH', dirname( __FILE__ ) . '/' );

// Name of the "system folder"
defined( 'SYSDIR' ) or define('SYSDIR', trim(strrchr(trim(BASEPATH, '/'), '/'), '/'));


// The path to the "application" folder
if ( is_dir( $application_folder ) ) {
	if ( ( $_temp = realpath( $application_folder ) ) !== FALSE ) {
		$application_folder = $_temp;
	}

	define('APPPATH', $application_folder.DIRECTORY_SEPARATOR);
}
else {
	if (! is_dir( BASEPATH . $application_folder . DIRECTORY_SEPARATOR ) ) {
		header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
		echo 'Your application folder path does not appear to be set correctly. Please open the following file and correct this: '.SELF;
		exit(4); // EXIT_CONFIG
	}
	
	define('APPPATH', BASEPATH.$application_folder.DIRECTORY_SEPARATOR);
}

// The path to the "views" folder
if (! is_dir( $view_folder ) ) {
	if (! empty( $view_folder ) && is_dir( APPPATH . $view_folder . DIRECTORY_SEPARATOR ) ) {
		$view_folder = APPPATH.$view_folder;
	}
	elseif ( ! is_dir( APPPATH . 'views'.DIRECTORY_SEPARATOR ) ) {
		header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
		echo 'Your view folder path does not appear to be set correctly. Please open the following file and correct this: '.SELF;
		exit(5); // EXIT_CONFIG
	}
	else {
		$view_folder = APPPATH . 'views';
	}
}

if ( ( $_temp = realpath( $view_folder ) ) !== FALSE ) {
	$view_folder = $_temp.DIRECTORY_SEPARATOR;
}
else {
	$view_folder = rtrim($view_folder, '/\\').DIRECTORY_SEPARATOR;
}

define('VIEWPATH', $view_folder);

// Ensure the timezone is set for those that choose not to configure their servers
date_default_timezone_set(@date_default_timezone_get());

/**
 * **********************************************************************
 * ALL SET - LETS LOAD
 * **********************************************************************
 */

if (! defined( 'INTEGRATOR_VERSION' ) ) {
	require_once APPPATH . 'core/MY_Common.php';
	require_once BASEPATH . 'core/CodeIgniter.php';
}
