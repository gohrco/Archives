<?php
/* SECURITY CHECKPOINT */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Overloads the Exceptions class to afford checking of response types
 * @version		3.1.22
 * 
 * @since		3.0.0
 * @author		Steven
 */
class MY_Exceptions extends CI_Exceptions
{
	/**
	 * Native PHP error handler
	 *
	 * @access	private
	 * @param	string	the error severity
	 * @param	string	the error string
	 * @param	string	the error filepath
	 * @param	string	the error line number
	 * @return	string
	 */
	function show_php_error($severity, $message, $filepath, $line)
	{
		$sevcode	=   $severity;
		$severity	=   ( ! isset($this->levels[$severity])) ? $severity : $this->levels[$severity];
		$ci			= & get_instance();
		$ci->load->library( 'template' );
		$ci->template->add_debug( $sevcode, $severity, $message, $filepath, $line );
	}
}