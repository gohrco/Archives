<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 		API Ping File
 *
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.22 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.5.0
 *
 * @desc       This is the Verify Task which replaces the ping task for the J!WHMCS Integrator API
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Verify Jwhmcs API Class
 * @version		3.1.22
 *
 * @since		2.5.3
 * @author		Steven
 */
class VerifyIntegratorAPI extends IntegratorAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		3.1.22
	 * 
	 * @since		3.1.00
	 * @see			IntegratorAPI :: execute()
	 */
	public function execute()
	{
		if (! function_exists( 'curl_exec' ) ) {
			$this->error( JText :: _( 'INTEGRATOR_SYSTEM_API_PING_NOCURL' ) );
		}
		
		// ---- END JWHMCS-4
		
		$this->success( 'pong' );
	}
}