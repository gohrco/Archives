<?php defined('DUNAMIS') OR exit('No direct script access allowed');
/**
 * Integrator 3
 * Integrator 3 - Admin Module Base File
 *
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.22 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This file is the admin controller
 *
 */


/**
 * Define the Integrator 3 version here
 */
if (! defined( 'DUN_MOD_INTEGRATOR' ) ) define( 'DUN_MOD_INTEGRATOR', "3.1.22" );

/**
 * Admin Module Class for Integrator 3
 * @version		3.1.22
 * 
 * @author		Steven
 * @since		3.1.00
 */
class IntegratorAdminDunModule extends WhmcsDunModule
{
	/**
	 * Stores what the action we are using
	 * @access		protected
	 * @var			string
	 * @since		3.1.00
	 */
	protected $action	= 'default';
	
	/**
	 * Stores the alerts to display back
	 * @access		protected
	 * @var			array
	 * @since		3.1.00
	 */
	protected $alerts	= array( 'error' => array(), 'success' => array(), 'info' => array(), 'block' => array() );
	
	/**
	 * Provide means to check for file integrity
	 * @access		protected
	 * @var			string
	 * @since		2.5.13
	 */
	protected $checkstring	=	"12345";
	
	/**
	 * Stores any modals to render
	 * @access		protected
	 * @var			array
	 * @since		3.1.00
	 */
	protected $modals	= array();
	
	/**
	 * Stores what the task is for this page
	 * @access		protected
	 * @var			string
	 * @since		3.1.00
	 */
	protected $task	= 'default';
	
	/**
	 * Stores the type of module this is
	 * @access		protected
	 * @var			string
	 * @since		3.1.00
	 */
	protected $type	= 'addon';
	
	
	/**
	 * Builds the alerts for display
	 * @access		public
	 * @version		3.1.22
	 *
	 * @return		string containing html formatted output
	 * @since		3.1.00
	 */
	public function buildAlerts()
	{
		$data	= null;
		$check	= array( 'success', 'error', 'block', 'info' );
	
		foreach ( $check as $type ) {
			if ( empty( $this->alerts[$type] ) ) continue;
			$data	.=	'<div class="alert alert-' . $type . '"><h4>' . t( 'integrator.alert.' . $type ) . '</h4>'
			.	implode( "<br/>", $this->alerts[$type] )
			.	'</div>';
		}
	
		return $data;
	}
	
	
	/**
	 * Builds any modals that are set to the object
	 * @access		public
	 * @version		3.1.22
	 *
	 * @return		html formatted string
	 * @since		3.1.00
	 */
	public function buildModals()
	{
		if ( empty( $this->modals ) ) return null;
	
		$data	= null;
		foreach ( $this->modals as $modal ) {
			$id	= $modal['id'];
			$btns	=	implode("\n", $modal['buttons'] );
			$data	.=	'<div aria-hidden="true" aria-labelledby="' . $id . 'Label" role="dialog" tabindex="-1" class="modal" id="' . $id . '" style="display: none; ">'
					.	'	<div class="modal-header">'
					.	'		<button aria-hidden="true" data-dismiss="modal" class="close" type="button">x</button>'
					.	'		<h3 id=' . $id . 'Label">' . $modal['hdr'] .'</h3>'
					.	'	</div>'
					.	'	<div class="modal-body">'
					.	'		<h4>' . $modal['title'] . '</h4>'
					.	'		' . $modal['body']
					.	'	</div>'
					.	'	<div class="modal-footer">'
					.	'		' . $btns
					.	'	</div>'
					.	'</div>';
		}
	
		return $data;
	}
	
	
	/**
	 * Builds the navigation menu
	 * @access		public
	 * @version		3.1.22
	 *
	 * @return		string containing html formatted output
	 * @since		3.1.00
	 */
	public function buildNavigation()
	{
		$uri	=	DunUri :: getInstance( 'SERVER', true );
		$uri->delVars();
		$uri->setVar( 'module', 'integrator' );
	
		$data		=	'<ul class="nav nav-pills">';
		$actions	=	array( 'default', 'syscheck', 'settings', 'updates' );
		
		// See if we can test the API
		$config		=	dunloader( 'config', 'integrator' );
		$apiurl		=	$config->get( 'integratorurl', null );
		$token		=	$config->get( 'apitoken', null );
		$activeapi	=	( $apiurl && $token ? true : false ); 
		
		foreach( $actions as $item ) {
			$state	=	( $item != 'apicnxn' ? '' : ( $activeapi ? '' : ' disabled' ) );
			
			if ( $item == $this->action && in_array( $this->task, array( 'default', 'save' ) ) ) {
				$data .= '<li class="active' . $state . '"><a href="#">' . t( 'integrator.admin.navbar.' . $item ) . '</a></li>';
			}
			else {
				$uri->setVar( 'action', $item );
				$data .= '<li class="' . $state . '"><a href="' . $uri->toString() . '">' . t( 'integrator.admin.navbar.' . $item ) . '</a></li>';
			}
		}
	
		$data	.= '</ul>';
		return $data;
	}
	
	
	/**
	 * Builds the title of the page
	 * @access		public
	 * @version		3.1.22
	 *
	 * @return		string containing html formatted output
	 * @since		3.1.00
	 */
	public function buildTitle()
	{
		$base	=	get_baseurl( 'integrator' );
		$doc	=	dunloader( 'document', true );
	
		$doc->addStyleDeclaration( 'h1#integratortitle { padding-left: 60px; background: url(' . $base . '/assets/integrator-48.png) no-repeat scroll 6px 50% transparent; height: 52px; line-height: 52px; }' );	// Wipes out WHMCS' h1
	
		$data	= '<h1 id="integratortitle">' . t( 'integrator.admin.title', t( 'integrator.admin.subtitle.' . $this->action . '.' . $this->task ) ) . '</h1>';
		return $data;
	}
	
	
	/**
	 * Retrieves the configuration array for the product in the addon modules menu
	 * @access		public
	 * @version		3.1.22
	 *
	 * @return		array
	 * @since		3.1.00
	 */
	public function getAdminConfig()
	{
		$data = array(
				"name"			=> t( 'integrator.addon.title' ),
				"version"		=> "3.1.22",
				"author"		=> t( 'integrator.addon.author' ),
				"description"	=> t( 'integrator.addon.description' ),
				"language"		=> "english",
				"logo"			=> get_baseurl( 'integrator' ) . 'assets/integrator-48.png',
				"fields"		=> array()
		);
	
		return $data;
	}
	
	
	/**
	 * Initializes the module
	 * @access		public
	 * @version		3.1.22
	 *
	 * @since		3.1.00
	 */
	public function initialise()
	{
		static $instance = false;
	
		if (! $instance ) {
			dunloader( 'language', true )->loadLanguage( 'integrator' );
			dunloader( 'hooks', true )->attachHooks( 'integrator' );
			dunloader( 'helpers', 'integrator' );
			
			// Perform checkstring
			if ( $this->checkstring != "12345" ) {
				return false;
			}
			
			$instance	= true;
		}
		
		global $task;
		
		if ( $task ) {
			$this->task = $task;
		}
	}
	
	
	/**
	 * Method to render the response back to the user
	 * @access		public
	 * @version		3.1.22
	 * @param		string		- $data: contains compiled data from the sub-view
	 *
	 * @return		html formatted string
	 * @since		3.1.00
	 */
	public function render( $data = null )
	{
		load_bootstrap( 'integrator' );
		
		// Compatibility check
		if (! check_compatible( 'dunamis' ) ) $this->setAlert( 'alert.dunamis.compatible', 'error' );
		
		$title	= $this->buildTitle();
		$navbar	= $this->buildNavigation();
		$alerts	= $this->buildAlerts();
		$modals	= $this->buildModals();
		
		$baseurl = get_baseurl( 'integrator' );
		$doc = dunloader( 'document', true );
		
		$doc->addStyleDeclaration( '#contentarea > div > h1, #content > h1 { display: none; }' );	// Wipes out WHMCS' h1
		$doc->addStyleDeclaration( '.contentarea > h1 { display: none; }' );	// Wipes out WHMCS' h1 in 5.0.3
		$doc->addStyleDeclaration( '#contentarea #integrator input { height: auto; }' );						// Cleanup Input Height issue in WHMCS v6
		$doc->addStylesheet( $baseurl . 'assets/css/admin.css' );
		
		return 		'<div style="float:left;width:100%;">'
					.	'<div id="integrator">'
					.	'	' . $title
					.	'	' . $navbar
					.	'	' . $alerts
					.	'	' . $data
					.	'	' . $modals
					.	'</div>'
					.	'</div>';
	}
	
	
	/**
	 * Renders the output for the admin area of the site (WHMCS > Addons > Module name)
	 * @access		public
	 * @version		3.1.22
	 *
	 * @return		string containing formatted output
	 * @since		3.1.00
	 */
	public function renderAdminOutput()
	{
		$action	= dunloader( 'input', true )->getVar( 'action', 'default' );
	
		$controller = dunmodule( 'integrator.' . $action );
		$controller->execute();
	
		return $controller->render();
	}
	
	
	/**
	 * Renders the sidebar for the admin area
	 * @access		public
	 * @version		3.1.22
	 *
	 * @return		string
	 * @since		3.1.00
	 */
	public function renderAdminSidebar()
	{
		return;
	}
	
	
	/**
	 * Common method for rendering fields into a form
	 * @access		protected
	 * @version		3.1.22
	 * @param		array		- $fields: contains an array of Field objects
	 *
	 * @return		string
	 * @since		3.1.00
	 */
	protected function renderForm( $fields = array(), $options = array() )
	{
		$data	= null;
		$foptn	= ( array_key_exists( 'fields', $options ) ? $options['fields'] : array() );
			
		foreach ( $fields as $field ) {
	
			if ( in_array( $field->get( 'type' ), array( 'wrapo', 'wrapc' ) ) ) {
				$data .= $field->field();
				continue;
			}
	
			$data	.= <<< HTML
<div class="control-group">
	{$field->label( array( 'class' => 'control-label' ) )}
	<div class="controls">
		{$field->field( $foptn )}
		{$field->description( array( 'type' => 'span', 'class' => 'help-block help-inline' ) )}
	</div>
</div>
HTML;
		}
	
		return $data;
	}
	
	
	/**
	 * Method for setting the action to the object
	 * @access		public
	 * @version		3.1.22
	 * @param		string		- $action: the action to set
	 *
	 * @since		3.1.00
	 */
	public function setAction( $action = 'default' )
	{
		$this->action = $action;
	}
	
	
	/**
	 * Method for setting an alert to the object
	 * @access		protected
	 * @version		3.1.22
	 * @param		mixed		- $msg: contains an array of items to use for translate or an alert msg string
	 * @param		string		- $type: indicates which type of alert to set to
	 * @param		boolean		- $trans: indicates if we should translate (true default)
	 *
	 * @since		3.1.00
	 */
	protected function setAlert( $msg = array(), $type = 'success', $trans = true )
	{
		// If we are passing an array we are assuming:
		//		first item is string
		//		rest of items are variables to insert
		if ( is_array( $msg ) ) {
			$message = array_shift( $msg );
			$message = 'integrator.'.$message;
			array_unshift( $msg, $message );
			$this->alerts[$type][] = call_user_func_array('t', $msg );
			return;
		}
	
		if ( $trans ) {
			$msg = t( 'integrator.' . $msg );
		}
	
		$this->alerts[$type][] = $msg;
	}
	
	
	/**
	 * Method for setting a modal into place
	 * @access		protected
	 * @version		3.1.22
	 * @param		string		- $id: the id string of the modal
	 * @param		string		- $title: the title to use
	 * @param		string		- $header: the header of the modal
	 * @param		string		- $body: content of the body
	 * @param		string		- $href: the destination URL of the modal on success
	 * @param		string		- $btnlbl: the label to use for the affirming action button
	 * @param		string		- $type: the style of button to use (success|danger|etc)
	 *
	 * @since		3.1.00
	 */
	protected function setModal( $id, $title, $header, $body, $href, $btnlbl, $type = 'danger' )
	{
		$btns	= array(	'<button data-dismiss="modal" class="btn">' . t( 'integrator.form.close' ). '</button>',
				'<a href="' . $href . '" class="btn btn-' . $type . '">' . $btnlbl . '</a>'
		);
		$this->modals[]	= array(	'id'		=> $id,
				'title'		=> $title,
				'hdr'		=> $header,
				'body'		=> $body,
				'buttons'	=> $btns
		);
	}
	
}
