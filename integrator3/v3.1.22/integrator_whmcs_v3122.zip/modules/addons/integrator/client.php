<?php defined('DUNAMIS') OR exit('No direct script access allowed');
/**
 * Integrator 3
 * Integrator 3 - Client Module Base File
 *
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.22 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This file is the client controller
 *
 */


/**
 * Define the JWHMCS version here
 */
if (! defined( 'DUN_MOD_INTEGRATOR' ) ) define( 'DUN_MOD_INTEGRATOR', "3.1.22" );

/**
 * Client Module Class for Integrator 3
 * @version		3.1.22
 * 
 * @author		Steven
 * @since		3.1.00
 */
class IntegratorClientDunModule extends WhmcsDunModule
{
	/**
	 * Stores what the action we are using
	 * @access		protected
	 * @var			string
	 * @since		3.1.00
	 */
	protected $action	= 'default';
	
	/**
	 * Stores the alerts to display back
	 * @access		protected
	 * @var			array
	 * @since		3.1.00
	 */
	protected $alerts	= array( 'error' => array(), 'success' => array(), 'info' => array(), 'block' => array() );
	
	/**
	 * Provide means to check for file integrity
	 * @access		protected
	 * @var			string
	 * @since		2.5.13
	 */
	protected $checkstring	=	"12345";
	
	/**
	 * Stores any modals to render
	 * @access		protected
	 * @var			array
	 * @since		3.1.00
	 */
	protected $modals	= array();
	
	/**
	 * Stores what the task is for this page
	 * @access		protected
	 * @var			string
	 * @since		3.1.00
	 */
	protected $task	= 'default';
	
	/**
	 * Stores the type of module this is
	 * @access		protected
	 * @var			string
	 * @since		3.1.00
	 */
	protected $type	= 'addon';
	
	
	/**
	 * Method to check our registration setting and handle accordingly
	 * @access		public
	 * @version		3.1.22 ( $id$ )
	 * 
	 * @since		3.1.00
	 */
	public function checkRegistration()
	{
		// Double check us...
		if (! ensure_active( 'user' ) ) return;
		
		$config		=	dunloader( 'config', 'integrator' );
		$method		=	$config->get( 'regmethod' );
		
		// `1` indicates WHMCS registration form
		if ( $method == '1' ) return;
		
		// `2` Means we have a custom URL to send off to
		if ( $method == '2' ) {
			$uri		=	DunUri :: getInstance( $config->get( 'register_customurl' ), true );
			$redirect	=	$uri->toString();
		}
		// Anything else and we are trying to route to an integrated page
		else {
			$api		=	dunloader( 'api', 'integrator' );
			$lang		=	$_SESSION['Language'];
			$redirect	=   $api->get_route( array( 'cnxn_id' => $config->get( 'register_cnxn_id' ), 'page' => $config->get( 'register_page' ), 'lang' => $lang  ) );
		}
		
		header( 'Expires: Sat, 26 Jul 1997 05:00:00 GMT' );
		header( 'Last-Modified: ' . gmdate( 'D, d M Y H:i:s' ) . ' GMT' );
		header( 'Cache-Control: no-store, no-cache, must-revalidate' );
		header( 'Cache-Control: post-check=0, pre-check=0', false );
		header( 'Pragma: no-cache' );
		header( 'Location: ' . $redirect );
		exit;
	}
	
	
	/**
	 * Method to call our admin config
	 * @desc		Apparently WHMCS calls up the config on the front end also
	 * @access		public
	 * @version		3.1.22 ( $id$ )
	 *
	 * @return		array
	 * @since		2.5.3
	 */
	public function getAdminConfig()
	{
		$module	=	dunmodule( 'integrator.admin' );
		return $module->getAdminConfig();
	}
	
	
	/**
	 * Initializes the module
	 * @access		public
	 * @version		3.1.22
	 *
	 * @since		3.1.00
	 */
	public function initialise()
	{
		static $instance = false;
	
		if (! $instance ) {
			dunloader( 'language', true )->loadLanguage( 'integrator' );
			dunloader( 'hooks', true )->attachHooks( 'integrator' );
			dunloader( 'helpers', 'integrator' );
			
			// Perform checkstring
			if ( $this->checkstring != "12345" ) {
				return false;
			}
			
			$instance	= true;
		}
		
		global $task;
		
		if ( $task ) {
			$this->task = $task;
		}
	}
	
	
	/**
	 * Container for handling front end output
	 * @access		public
	 * @version		3.1.22 ( $id$ )
	 *
	 * @return		void
	 * @since		3.1.00
	 */
	public function renderClientOutput()
	{
		$config	=	dunloader( 'config', 'integrator' );
		$input	=	dunloader( 'input', true );
		$debug	=	$config->get( 'debug', false );
		$task	=	$input->getVar( 'task', 'cp' );
		
		if (! $debug ) return;
		
		load_bootstrap( 'integrator' );
		
		$data	=	array(
				'pagetitle'		=>	t( 'integrator.client.breadcrumb.' . $task ),
				'breadcrumb'	=>	array( 'index.php?m=integrator&task=checkinstall' => t( 'integrator.client.breadcrumb.' . $task ) ),
				'templatefile'	=>	'templates/client-' . $task,
				'requirelogin'	=>	false,
				'vars'			=>	array(
						'title'		=>	t( 'integrator.client.pagetitle' ),
						'desc'		=>	t( 'integrator.client.pagedesc.'. $task ),
					),
				);
		
		switch ( $task ) :
		case 'checkinstall' :
			$doc	=	dunloader( 'document', true );
			
			$doc->addScript( get_baseurl( 'integrator' ) . 'assets/syscheck.js' );
			$doc->addScriptDeclaration( 'var ajaxurl = "' . get_baseurl( 'integrator' ) . '";' );
			
			$syschk	=	dunmodule( 'integrator.syscheck' );
			$model	=	$syschk->getModel();
			$rows	=	array();
		
			// Let's build our table
			foreach ( array( 'api', 'files', 'whmcs', 'env' ) as $row ) {
				
				$rows[]	=	'<table class="table-bordered table-striped">';
				$rows[]	=	'	<thead><tr><th colspan="2">' . t( 'integrator.syscheck.tblhdr.' . $row ) . '</th></tr></thead>';
				$rows[]	=	'	<tbody>';
				
				foreach ( $model->$row as $item => $value ) {
					// Skip some
					if ( in_array( $item, array( 'files', 'supported', 'templatesupported' ) ) ) continue;
					
					$rows[]	=	'	<tr>';
					$rows[]	=	'		<td class="span4">' . $syschk->getItem( 'label', $item, $model->$row, $row ) . '</td>';
					$rows[]	=	'		<td class="span3">' . $syschk->getItem( 'value', $item, $model->$row, $row ) . '</td>';
					$rows[]	=	'	</tr>';
				}
				
				$rows[]	=	'</tbody></table><br/><br/>';
			}
			
			$data['vars']['data']	=	implode( "\r\n", $rows );
			
			break;
			
		case 'checkrender' :
			
			$render	=	dunmodule( 'integrator.render' );
			$render->execute();
			$info	=	$render->getItem( 'debug' );
			
			$rows[]	=	'<table class="table-bordered table-striped">';
			$rows[]	=	'	<tbody>';
			
			foreach ( $info as $key => $value ) {
				
				$rows[]	=	'	<tr>';
				
				if ( $key == 'url' ) {
					$value	=	'<textarea class="span6">' . $value . '</textarea>';
				}
				else {
					$value	=	'<code>' . $value . '</code>';
				}
				
				$rows[]	=	'		<td class="span2 pull-right">' . $key . '</td>';
				$rows[]	=	'		<td class="span6">' . $value . '</td>';
				$rows[]	=	'	</tr>';
			}
			
			$rows[]	=	'</tbody></table><br/><br/>';
			
			$data['vars']['data']	=	implode( "\r\n", $rows );
			
			break;
		endswitch;
		
		return $data;
	}
	
}
