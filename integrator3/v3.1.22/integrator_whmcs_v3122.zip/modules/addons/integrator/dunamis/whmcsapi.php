<?php defined('DUNAMIS') OR exit('No direct script access allowed');
/**
 * Integrator 3
 * Integrator 3 - WHMCS API Handler File
 *
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.22 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This file handles requests to the WHMCS API (localAPI calls)
 *
 */


/**
 * WHMCS API Handler Class for Integrator 3
 * @version		3.1.22
 *
 * @author		Steven
 * @since		2.5.0
 */
class IntegratorDunWhmcsapi extends DunObject
{
	
	private $_apiuser	= 1;
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.1.22
	 * @param		array		- $options: options to set
	 * 
	 * @since		2.0.0
	 */
	public function __construct( $options = array() )
	{
		parent :: __construct( $options );
		
		$config	=	dunloader( 'config', 'integrator' );
		$apiuser	=	$config->get( 'apiuser' );
		
		if ( $apiuser ) {
			$this->_apiuser	=	$apiuser;
		}
	}
	
	
	public function addclient( $options )
	{
		$result	=	(object) localAPI( 'addclient', $options, $this->_apiuser );
		return ( $result->result == 'success' ? $result->message : false );
	}
	
	
	/**
	 * Method for validating a login against WHMCS internally
	 * @access		public
	 * @version		3.1.22 ( $id$ )
	 * @param		string		- $email: the users' email to validate
	 * @param		string		- $password: their password
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	public function authenticate( $email, $password )
	{
		$options	=	array(
				'email'		=>	$email,
				'password2'	=>	$password
				);
		
		$result	=	(object) localAPI( 'validatelogin', $options, $this->_apiuser );
		
		return $result->result == 'success';
	}
	
	
	/**
	 * Method for gathering a clients details
	 * @desc		CANNOT USE IN LOGIN ROUTINE DUE TO REDECLARATION OF CLIENT FUNCTIONS
	 * @access		public
	 * @version		3.1.22 ( $id$ )
	 * @param unknown_type $id
	 * @param unknown_type $by
	 *
	 * @return		void
	 * @since		1.0.0
	 */
	public function finduserdetails( $id, $by = 'clientid' )
	{
		$task	=	'getclientsdetails';
		$data	=
		$optns	=	array();
		
		switch ( $by ) :
		case 'clientid' :
			$optns['clientid']	=	$id;
			break;
		case 'email' :
			$optns['email']	=	$id;
			break;
		endswitch;
		
		$client	=	(object) localAPI( $task, $optns, $this->_apiuser );
		
		if ( $client->result == 'success' ) {
			return $client;
		}
		else if ( $by == 'clientid' ) {
			return false;
		}
		
		// Try a contact
		$contact	=	(object) localAPI( 'getcontacts', $optns, $this->_apiuser );
		
		if ( $contact->result == 'success' && $contact->totalresults == '1' ) {
			return (object) $contact->contacts['contact'][0];
		}
		else {
			return false;
		}
	}
	
	
	/**
	 * Singleton object
	 * @access		public
	 * @version		3.1.22
	 * @param		array		- $options: array of options
	 * 
	 * @return		Aortacloud2DunWhmcsapi object
	 * @since		2.0.0
	 */
	public static function getInstance( $options = array() )
	{
		static $instance = null;
	
		if (! is_object( $instance ) ) {
			$instance = new self( (object) $options );
		}
	
		return $instance;
	}
	
	
	/**
	 * Retrieves the email templates from WHMCS API
	 * @access		public
	 * @version		3.1.22
	 * @param		array		- $options: to pass to api
	 * 
	 * @return		array of id => templates | false
	 * @since		2.0.0
	 */
	public function getEmailtemplates( $options = array() )
	{
		$data	=	array();
		$emails	=	localAPI( 'GetEmailTemplates', $options, $this->_apiuser );
		
		if ( $emails['result'] != 'success' ) return false;
		$emails	=	$emails['emailtemplates']['emailtemplate'];
		
		foreach ( $emails as $emailtemplate ) {
			$data[$emailtemplate['id']] = $emailtemplate['name'];
		}
		
		return $data;
	}
	
	
	/**
	 * Retrieves an unencoded password if not using md5, else returns false
	 * @access		public
	 * @version		3.1.22
	 * @param		string		- $pw: a password to decode
	 * 
	 * @return		string | false
	 * @since		1.0.0
	 */
	public function getPassword( $pw = null )
	{
		$data = localAPI( 'decryptpassword', array( 'password2' => $pw ), $this->_apiuser );
		return ( $data['result'] == 'success' ? $data['password'] : false );
	}
	
	
	/**
	 * Method for getting a value from the product config
	 * @access		public
	 * @version		3.1.22 ( $id$ )
	 * @param		integer		- $id: the product id
	 * @param		string		- $optn: what we want [USERS|type|storage]
	 *
	 * @return		string
	 * @since		2.0.0
	 */
	public function getProductOption( $id, $optn = 'type' )
	{
		$db	=	dunloader( 'database', true );
		
		switch ( $optn ) {
			case 'users' :
				$get = 'configoption1';
				break;
			case 'storage' :
				$get = 'configoption2';
				break;
			case 'type' :
			default:
				$get = 'configoption3';
				break;
		}
		
		$db->setQuery( "SELECT `{$get}` FROM `tblproducts` WHERE `id` = " . $db->Quote( $id ) );
		return $db->loadResult();
	}
	
	
	public function getProductUsers( $type = 'all' )
	{
		$data = localAPI( 'getclientsproducts', array(), $this->_apiuser );
		_e( $data );
	}
	
	
	/**
	 * Method for getting a product type for a given product id
	 * @access		public
	 * @version		3.1.22 ( $id$ )
	 * @param		integer		- $id: the product id to find
	 *
	 * @return		string | false
	 * @since		2.0.0
	 */
	public function getProductType( $id = 1 )
	{
		$db	=	dunloader( 'database', true );
		$db->setQuery( "SELECT `configoption3` FROM `tblproducts` WHERE `id` = " . $db->Quote( $id ) );
		return $db->loadResult();
	}
	
	
	public function getUserList()
	{
		$error		=	dunloader( 'error', 'aortacloud2' );
		$products	=	localAPI( 'getproducts', array( 'module' => 'aortacloud2' ), $this->_apiuser );
		$users		=	array();
		
		if ( $products['result'] != 'success' ) {
			$error->set( $products['message'] );
			return false;
		}
		
		foreach ( $products['products']['product'] as $product ) {
			$type		=	extractType( $this->getProductOption( $product['pid'] ) );
			$clients	=	localAPI( 'getclientsproducts', array ('pid' => $product['pid'] ), $this->_apiuser );
			
			if ( $clients['result'] != 'success' ) {
				$error->set( $clients['message'] );
				return false;
			}
			
			foreach ( $clients as $client ) {
				
			}
			_e( $type );
			_e( $clients, 1 );
		}
		
	}
	
	
	/**
	 * Method to log an API call
	 * @access		public
	 * @version		3.1.22
	 * @param		string		- $task: what task we are running
	 * @param		string		- $method: the method making the call
	 * @param		string		- $msg: what message we want to pass along
	 * 
	 * @since		2.5.0
	 */
	public function log()
	{
		$args	=	func_get_args();
		$task	=	array_shift( $args );
		$method	=	array_shift( $args );
		$msg	=	array_shift( $args );
		$type	=	( count( $args ) ? array_shift( $args ) : 'log' );
		$label	=	( count( $args ) ? array_shift( $args ) : 'WHMCS Log' );
		
		// Provide translation if possible
		$x		=	dunloader( 'language', true )->translate( $msg, array(), 'integrator' );
		$msg	=	( strpos( $x, 'integrator.' ) === 0 ? $msg : $x );
		
		logModuleCall('integrator', $task, $method, $msg );
		
		return $method . ': ' . ( is_string( $msg ) ? $msg : null ) ;
	}
	
	
	/**
	 * Method to change a password for a given service module
	 * @access		public
	 * @version		3.1.22
	 * @param		integer		- $id: should be the ID of the service
	 * @param		string		- $pw: should be the password to set
	 * 
	 * @return		boolean
	 * @since		2.0.0
	 */
	public function moduleChangepw( $id, $pw )
	{
		$data	=	array();
		$result	=	localAPI( 'modulechangepw', array( 'serviceid' => $id, 'servicepassword' => $pw ), $this->_apiuser );
		
		if ( $result['result'] != 'success' ) return false;
		
		return true;
	}
}