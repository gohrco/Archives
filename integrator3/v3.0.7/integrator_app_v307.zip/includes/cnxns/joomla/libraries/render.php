<?php

/**
 * Render class for Joomla site
 * @access		public
 * @author		Steven
 *
 * @since		3.0.0
 */
class Joomla_Render extends Render_library
{
	/**
	 * Constructor method called by Render_library
	 * @access		public
	 * @version		3.0.7
	 * @param		array		- $options: array of options to set
	 * 
	 * @since		3.0.0
	 */
	public function __construct( $options = array() )
	{
		$this->set_properties( $options );
		
		$params		= & Params::getInstance();
		$cnxn_model =   cnxn( $this->get( "cnxn_id" ) );
		
		$this->set( "params",			$cnxn_model->get_param_array() );
		$this->set( "retrieve_options",	$cnxn_model->get( "visualoptions" ) );
		$this->set( "retrieve_post",	$cnxn_model->get( "visualvars" ) );
		$this->set( "retrieve_uri", 	$this->_build_retrieve_uri( $cnxn_model->get( "visualuri" ) ) );
		$this->set( "split_marker",		"<!-- Integrator_Marker -->" );
		$this->set( "split_tag",		"<!-- Integrator_Tag -->" );
		$this->set( "unicode",			( $params->get( "UnicodeMatching", false ) ? "u" : "" ) );
		
		$this->_build_urls();
		$this->_set_cookies();
		
	}
	
	
	/**
	 * Provides the regular expression for replacing the characterset tag in the content for this connection type
	 * @access		public
	 * @version		3.0.7
	 * 
	 * @return		regular expression object
	 * @since		3.0.0
	 */
	public function regex_characterset()
	{
		// Grab the unicode tag if we are using it
		$u			= $this->get( "unicode" );
		
		return new IntRegex( '/(?P<front><meta.*charset=\"?)(?P<link>utf-8)(?P<back>.*\/>)/i' . $u, "characterset", null, true );
	}
	
	
	/**
	 * Gathers any regular expressions to run against the site for this connection
	 * @access		public
	 * @version		3.0.7
	 * @param		array		- $regex: contains an empty array to add to
	 * 
	 * @return		array containing more regular expression objects
	 * @since		3.0.0
	 */
	public function regex_gather( $regex )
	{
		// Grab the unicode tag if we are using it
		$u			= $this->get( "unicode" );
		
		$regex[]	= new IntRegex( '/(?P<front><link.+?href=\"?\'?)\/?(?P<link>[^>\"\']+)(?P<back>\'?\"?.*?\/>)/' . $u, "image" );
		$regex[]	= new IntRegex( '/(?P<front><a[^>]+?href=\'?\"?)\/?(?P<link>[^>\"\']+)(?P<back>\"?\'?[^>]*?>)/' . $u, "href" );
		$regex[]	= new IntRegex( '/(?P<front><form.+?action=\"?\'?)(?P<link>[^>\'\">]+)(?P<back>\"?\'?.*?>)/' . $u, "action" );
		$regex[]	= new IntRegex( '/(?P<front><script[^>]+?src=\"?\'?)\/?(?P<link>[^>\"\']+)(?P<back>\'?\"?.*?>)/' . $u, "image" );
		$regex[]	= new IntRegex( '/(?P<front><img.+?src=\"?\'?)\/?(?P<link>[^>\"\']+)(?P<back>\"?\'?.*?>)/' . $u, "image" );
		$regex[]	= new IntRegex( '/(?P<front>style=\"?\'?[^>]+?url\(\"?\'?)\/?(?P<link>[^\)]+\..{3})(?P<back>\"?\'?\);?[^>]*>)/i' . $u, "image" );
		$regex[]	= new IntRegex( '/(?P<front>{[\w\s]*.*background[-\w]*:[^\)]*url\(\"?\'?)\/?(?P<link>[^\)]+\..{3})(?P<back>\"?\'?\)[^}]*})/i' . $u, "image" );
		$regex[]	= new IntRegex( '/(?P<front>onmouse.+?=\"?\'?javascript:this.src=\"?\'?)(?P<link>https?:\/\/[^>\'\" ]+)(?P<back>\'?\"?[^>]*?)/' . $u, "image" );
		$regex[]	= new IntRegex( '/(?P<front><base.+?href=\"?\'?)(?P<link>https?:\/\/[^>\'\" ]+)(?P<back>\'?\"?.*?\/>)/i' . $u, "base", "INTEGRATOR_BASETAG", true );
		$regex[]	= new IntRegex( '/(?P<front><title>)(?P<link>[^<\/]+?)(?P<back><\/title>)/' . $u, "title", "INTEGRATOR_TITLE", true );
		//$regex[]	= new IntRegex( '#(?P<front><!DOCTYPE html)(?P<link>[^>]*)(?P<back>>)#i'  . $u, 'title', '', true );
		return $regex;
	}
	
	
	/**
	 * Updates the regular expression object array with data from this connection
	 * @access		public
	 * @version		3.0.7
	 * @param		array		- $regex: array of regular expression IntRegex objects
	 * 
	 * @return		array containing updated regex objects array
	 * @since		3.0.0
	 */
	public function regex_update( $regex )
	{
		$urls = $this->urls;
		
		foreach ( $regex as $regobj ) {
			switch( $regobj->get( "type" ) ):
			case "image":
				$regobj->set( "host", true );
				$regobj->set( "scheme", true );
				$regobj->set( "replace", $urls['imgs'] );
				break;
			case "action":
				$regobj->set( "host", true );
				$regobj->set( "scheme", true );
				$regobj->set( "replace", $urls['action'] );
				break;
			case "href":
				$regobj->set( "replace", $urls['href'] );
				break;
			endswitch;
		}
		
		return $regex;
	}
	
	
	/**
	 * Splits the content into known header and footer pieces
	 * @access		public
	 * @version		3.0.7
	 * @param		string		- $content: the rendered site returned to the Integrator
	 * 
	 * @return		array containing split components to return to Integrator
	 * @since		3.0.0
	 */
	public function split_site( $content )
	{
		$marker		= $this->get( "split_marker" );
		$tag		= $this->get( "split_tag" );
		$htmlhdr	= null;
		$htmlftr	= null;
		
		$parts	= explode($marker, $content);
		$item	= 0;
		
		// Tag the content (trash)
		for( $i=0; $i<count( $parts ); $i++ )
		{
			$exists = preg_match($tag, $parts[$i]);
			if ($exists) $item = $i;
		}
		
		// Slice header up and rebuild
		$hdr = array_slice($parts, 0, $item);
		for ($i=0; $i<count($hdr); $i++) $htmlhdr.= $hdr[$i];
		
		// Slice footer up and rebuild
		$ftr = array_slice($parts, $item+1);
		for ($i=0; $i<count($ftr); $i++) $htmlftr.= $ftr[$i];
		
		// Add ID tag to style WHMCS content specifically
		$htmlhdr .= '<div id="integrator-wrapper">';
		$htmlftr  = '</div>'.$htmlftr;
		
		return array( 'header' => $htmlhdr, 'footer' => $htmlftr );
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE PRIVATE
	 * **********************************************************************
	 */
	
	
	/**
	 * Builds the uri object to use to retrieve the site from
	 * @access		private
	 * @version		3.0.7
	 * @param		Uri		- $uri: a URI object set from connection model
	 * 
	 * @return		Uri object
	 * @since		3.0.0
	 */
	private function _build_retrieve_uri( Uri $uri )
	{
		$lang	= find_mapped_item( 'lang', $this->_a, $this->get( 'language' ), $this->cnxn_id );
		$item	= $this->cnxn_id . ( is_multilingual( $this->cnxn_id ) ? '-' . $lang : '' );
		$page	= find_mapped_item( 'page', $this->_a, $this->get( 'page' ), $item );
		
		$uri->setVar( "Itemid", $page );
		$uri->setVar( "lang", $lang );
		$uri->setVar( "override", true );
		
		if ( $this->isssl ) {
			$uri->setScheme( 'https' );
		}
		return $uri;
	}
	
	
	/**
	 * Builds the URLs for this connection to use in regular expression replacements
	 * @access		private
	 * @version		3.0.7
	 * 
	 * @since		3.0.0
	 */
	private function _build_urls()
	{
		// We are using the image url since the API url can be changed if redirections detected
		$hrefuri	= & Uri::getInstance( $this->get( 'imgurl', null, 'visuals' ), true );
		$hrefuri->setPath( rtrim( $hrefuri->getPath(), "/" ) );
		$urls['href']	= $hrefuri->toString();
		
		// Action replacements
		//$hrefuri->setScheme( "http" . ( $this->isssl ? ( $this->get( 'sslenabled', false, 'visuals' ) ? "s" : "" ) : "" ) );
		$hrefuri->setScheme( 'http' . ( $this->isssl ? 's' : '' ) );
		$urls['action']	= $hrefuri->toString();
		
		// Image url replacement
		$imguri		= & Uri::getInstance( $this->get( 'imgurl', null, 'visuals' ), true );
		$imguri->setScheme( 'http' . ( $this->isssl ? 's' : '' ) );
		//$imguri->setScheme( "http" . ( ( $this->isssl && $this->get( 'sslenabled', false, 'visuals' ) ) ? "s" : "" ) );
		$imguri->setPath( rtrim( $imguri->getPath(), "/" ) . "/" );
		$urls['imgs'] = $imguri->toString();
		
		$this->urls = $urls;
	}
	
	
	/**
	 * Method to set the cookies from the remote site in place for calling purposes
	 * @access		private
	 * @version		3.0.7
	 * 
	 * @since		3.0.0
	 * @deprecated
	 */
	private function _set_cookies_old()
	{
		$CI = & get_instance();
		$CI->load->model( "session_model" );
		$model = & $CI->session_model;
		
		if (! $model->load( array( 'remote' => $this->session_id, 'cnxnid' => $this->_a, 'local' => $model->local ) ) ) {
			_d( 'Unable to load session cookies' );
			return false;
		}
		
		$data		= null;
		$cookiefile	= getcwd() . DIRECTORY_SEPARATOR . 'tmp' . DIRECTORY_SEPARATOR . $this->cnxn_id . "-" . $model->local . ".tmp";
		
		ob_start();
			$cookies = @file( "{$cookiefile}" );
		ob_end_clean();
		
		if ( empty( $cookies ) ) {
			_d( 'No cookies found (filename: ' . $this->cnxn_id . '-' . $model->local . '.tmp )' );
			return;
		}
		
		foreach ( $cookies as $cookie ) {
			$data = rtrim( $cookie );
		}
		
		// Grab the options and set the cookie in place
		$options = $this->retrieve_options;
		$options['COOKIE'] = $data;
		$this->retrieve_options = $options;
		
		return;
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE OVERRIDES OF PARENT
	 * **********************************************************************
	 */
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		3.0.7
	 * @param		string		- $name: the name of the property to set
	 * @param		mixed		- $value: the value to set the property to
	 * 
	 * @since		3.0.0
	 */
	public function __set( $name, $value )
	{
		if ( in_array( $name, array( 'urls', 'split_marker', 'split_tag' ) ) ) {
			$this->$name = $value;
			return;
		}
		
		if ( in_array($name, array( '_v', 'cnxn_id' ) ) ) {
			$this->cnxn_id = $value;
			return;
		}
		
		parent::__set( $name, $value );
	}
}