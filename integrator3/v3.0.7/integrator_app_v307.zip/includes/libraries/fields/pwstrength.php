<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class to generate a password strength field
 * @version		3.0.7
 * 
 * @since		3.0.2
 * @author		Steven
 */
class PwstrengthField extends form_definition
{
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.7
	 * @param		array		- $options: contruction options
	 * 
	 * @since		3.0.2
	 */
	public function __construct( $options = array() )
	{
		parent::__construct( $options );
	}
	
	
	/**
	 * Method to generate a description
	 * @access		protected
	 * @version		@fileVers2
	 *
	 * @return		null
	 * @since		3.0.2
	 * @see			form_definition::label()
	 */
	protected function description()
	{
		return null;
	}
	
	
	/**
	 * Method to generate a form field
	 * @access		protected
	 * @version		3.0.7
	 * 
	 * @return		string
	 * @since		3.0.2
	 * @see			form_definition::field()
	 */
	protected function field()
	{
		// Add the javascript values first
		$this->append_javascript();
		$this->append_metadata();
		
		$field	=	'<div class="row-fluid"><div style="width: 102px; margin: 0 auto; text-align: center; ">'
				.	lang( 'desc.pwstrength' ) . br()
				.	'<div id="passwordstrengthpos" style="position:relative;float:left;width:0px;background-color:#33CC00;border:1px solid #000;border-right:0px;">&nbsp;</div><div id="passwordstrengthneg" style="position:relative;float:right;width:100px;background-color:#efefef;border:1px solid #000;border-left:0px;">&nbsp;</div></td></tr></table></td></tr><tr><td><div id="passwordstrength" style="width: 100%; text-align: center; ">'
				.	'<script>jQuery("#pwtxtweak").val()</script>'
				.	'</div></div></div>'
				.	'<input type="hidden" id="pwtxtstrong" value="' . lang( 'pwtxtstrong' ) . '" />'
				.	'<input type="hidden" id="pwtxtmod" value="' . lang( 'pwtxtmod' ) . '" />'
				.	'<input type="hidden" id="pwtxtweak" value="' . lang( 'pwtxtweak' ) . '" />'
				.	br();
		
		return $field;
	}
	
	
	/**
	 * Method to generate a label
	 * @access		public
	 * @version		@fileVers2
	 * 
	 * @return		null
	 * @since		3.0.2
	 * @see			form_definition::label()
	 */
	public function label()
	{
		return null;
	}
	
	
	/**
	 * Adds necessary javascript calls to the template
	 * @access		protected
	 * @version		3.0.7
	 *
	 * @since		3.0.2
	 */
	protected function append_javascript()
	{
		static $data = false;
		
		if (! $data ) {
			$data	= true;
			$params	= & Params :: getInstance();
			$ci		= & get_instance();
			$ci->template->append_javascript( bootstrap( 'passwordstrength.js', 'js' ) );
			$ci->template->prepend_metadata( '<script type="text/javascript">var passtxt="' . $params->get( "PasswordText" ) . '"</script>' );
		}
	}
	
	
	/**
	 * Adds the necessary metadata info to the template header
	 * @access		protected
	 * @version		3.0.7
	 * 
	 * @since		3.0.2
	 */
	protected function append_metadata()
	{
		static $data = false;
		
		if (! $data ) {
			$data	=   true;
			$ci		= & get_instance();
// 			$ci->template->append_metadata( );
		}
	}
}