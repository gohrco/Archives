<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class to generate a usergroup selection field
 * @version		3.0.7
 * 
 * @since		3.0.2
 * @author		Steven
 */
class UserGroupField extends form_definition
{
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.7
	 * @param		array		- $options: contruction options
	 * 
	 * @since		3.0.2
	 */
	public function __construct( $options = array() )
	{
		parent::__construct( $options );
	}
	
	
	/**
	 * Method to generate a form field
	 * @access		protected
	 * @version		3.0.7
	 * 
	 * @return		string
	 * @since		3.0.2
	 * @see			form_definition::field()
	 */
	protected function field()
	{
		$name		= $this->name . ( $this->array ? '[]' : '' );
		$arguments	= $this->arguments();
		
		if (! isset( $arguments['class'] ) ) $arguments['class'] = 'span5';
		
		$extras		= "id=\"{$this->lang}\"";
		foreach ( $arguments as $key => $value ) $extras .= " {$key}=\"{$value}\"";
		
		$options	= $this->get_options();
		$field		= form_dropdown( $name, $options, set_value( $this->name, $this->value ), $extras );
		
		return $field;
	}
	
	
	/**
	 * Method to get the options for the drop down box
	 * @access		protected
	 * @version		3.0.7
	 * 
	 * @return		array
	 * @since		3.0.2
	 * @see			form_definition::get_options()
	 */
	protected function get_options()
	{
		$ci			= & get_instance();
		$options	=   array();
		
		foreach( $ci->auth_model->get_groups() as $group ) {
			$options[$group->id] = $group->description;
		}
		
		return $options;
	}
}