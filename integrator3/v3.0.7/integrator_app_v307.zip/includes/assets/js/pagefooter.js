/**
 * 
 */

function pageLimiter(o) {
	var index = o.selectedIndex;
	var value = o.options[index].value;

	var lmtCnt	= document.getElementById( 'pagelimitCount' );
	var lmtLnk	= document.getElementById( 'pagelimitLink' );
	var lmtLnkT	= document.getElementById( 'pagelimitLinktail' );
	
	var page    = parseInt( parseInt( lmtCnt.value ) / parseInt( value ) ) + 1;
	window.location.href = lmtLnk.value + '/' + page + '/' + value + lmtLnkT.value;
}