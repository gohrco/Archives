<?php

$form['visual'] = array(
	'EnableVisual' => array(
			'apiname'		=> null,
			'value'			=> false,
			'order'			=> 10,
			'type'			=> 'toggleyn',
			'validation'	=> 'required|is_natural'
		),
	'Defaultvisual' => array(
			'apiname'		=> null,
			'value'			=> null,
			'order'			=> 30,
			'type'			=> 'dropdown-cnxnvisual',
			'validation'	=> ''
		),
	'SystemSSL' => array(
			'value'			=> false,
			'order'			=> 20,
			'type'			=> 'hidden',
			'validation'	=> 'required|is_natural'
	),
	'UnicodeMatching' => array(
			'apiname'		=> null,
			'value'			=> true,
			'order'			=> 40,
			'type'			=> 'toggleyn',
			'validation'	=> 'required|is_natural'
		),
);

$form['cache'] = array(
	'Cache' => array(
			'value'			=> false,
			'order'			=> 60,
			'type'			=> 'toggleyn',
			'validation'	=> 'required|is_natural'
		),
	'CacheTTL' => array(
			'value'			=> 300,
			'order'			=> 70,
			'type'			=> 'text',
			'validation'	=> 'required|is_numeric'
		),
	'Clearcache' => array(
			'value'			=> null,
			'order'			=> 80,
			'type'			=> 'checkbox',
			'validation'	=> 'xss_clean'
		),
);
