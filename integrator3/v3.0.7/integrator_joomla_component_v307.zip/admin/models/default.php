<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.7 ( $Id: default.php 74 2012-10-01 15:55:25Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file is the default model file for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.model' );	// Import model
/*-- File Inclusions --*/

/**
 * Default Integrator Model
 * @version		3.0.7
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntegratorModelDefault extends JModel
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.7
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Retrieves any debug information for rendering to the admin user
	 * @access		public
	 * @version		3.0.7
	 * 
	 * @return		array of data or empty array
	 * @since		3.0.0
	 */
	public function getDebug()
	{
		$debug = & IntDebug :: getInstance();
		return $debug->get_output();
	}
	
	
	/**
	 * Retrieves the status of the API connection
	 * @access		public
	 * @version		3.0.7
	 * 
	 * @return		true on success or string containing failed message
	 * @since		3.0.0
	 */
	public function getStatus()
	{
		$api	= IntApi::getInstance();
		return ( ( $message = $api->ping() ) === true ? true : $message );
	}
	
	
	/**
	 * Sends an update settings call to pull the cnxnid from Integrator
	 * @access		public
	 * @version		3.0.7
	 * 
	 * @return		true upon successful completion or an error message
	 * @since		3.0.0
	 */
	public function updateSettings()
	{
		$api		= IntApi::getInstance();
		$response	= $api->update_settings();
		
		if ( $response['result'] != 'success' ) {
			return $response['data'];
		}
		
		return $this->_updateParameters( $response['data'] );
	}
	
	
	/**
	 * Updates the component parameters with current settings from the Integrator
	 * @access		private
	 * @version		3.0.7
	 * @param		array		- $data: contains items to bind to component parameters
	 * 
	 * @return		boolean true on success
	 * @since		3.0.0
	 */
	private function _updateParameters( $data = array() )
	{
		if ( empty( $data ) ) return false;
		
		$params		= & JComponentHelper::getParams( "com_integrator" );
		$updates	=   array();
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			// Joomla 1.6+
			foreach ( $data as $key => $value ) {
				$params->set( $key, $value );
			}
			
			$uri = new Juri( $params->get( 'IntegratorUrl' ) );
			$uri->setPath( rtrim( $uri->getPath(), "/" ) );
			$params->set('IntegratorUrl', $uri->toString() );
			
			$updates['name']	= "Integrator";
			$updates['element']	= "com_integrator";
			$updates['type']	= "component";
			$updates['params']	= (string) $params;
			
			$table	= & JTable::getInstance('extension');
			$updates['extension_id'] = $table->find( array( 'element' => 'com_integrator', 'type' => 'component' ) );
			
		}
		else {
			// Joomla 1.5 specific
			$params->loadSetupFile( JPATH_COMPONENT_ADMINISTRATOR . DS . "config.xml" );
			$existing	= $params->toArray();
			$bindarray	= array();
			foreach( $existing as $key => $vals ) {
				$bindarray[$key] = $vals;
			}
			
			foreach ( $data as $key => $value ) {
				$bindarray[$key] = $value;
			}
			
			$uri = new Juri( $bindarray['IntegratorUrl'] );
			$uri->setPath( rtrim( $uri->getPath(), "/" ) );
			$bindarray['IntegratorUrl'] = $uri->toString();
			
			$updates['option']	= "com_integrator";
			$updates['params']	= $bindarray;
			
			$table		= & JTable::getInstance('component');
			$table->loadByOption( 'com_integrator' );
			
		}
		
		$table->bind( $updates );
		
		if (!$table->check()) {
			JError::raiseWarning( 500, $table->getError() );
			return false;
		}
		
		// save the changes
		if (!$table->store()) {
			JError::raiseWarning( 500, $table->getError() );
			return false;
		}
		
		return true;
	}
}