<?php foreach ( $modals as $modal ) : ?>
<div class="<?php echo $modal->attribs ?>" id="<?php echo $modal->id ?>">
	<div class="modal-header">
		<button class="close" data-dismiss="modal">x</button>
		<?php echo heading( $modal->header, '3' ); ?>
	</div>
	<div class="modal-body">
		<?php echo $modal->content ?>
	</div>
	<div class="modal-footer">
		<?php 
		foreach ( $modal->buttons as $button )
		{
			$type = $button->btntype; 
			unset( $button->btntype );
			
			if ( $type == 'anchor' )
			{
				$uri	= $button->uri;
				$title	= $button->title;
				unset ( $button->uri, $button->title );
				echo anchor( $uri, $title, (array) $button );
			}
			else
			{
				echo form_button( (array) $button );
			}
		}
		?>
	</div>
</div>
<?php endforeach; ?>