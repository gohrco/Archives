<?php defined('DUNAMIS') OR exit('No direct script access allowed');
/**
 * Integrator 3
 * Integrator 3 - Settings Module File
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.02 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This file is the settings controller
 *
 */


/**
 * Settings Module Class for Integrator 3
 * @version		3.1.02
 *
 * @author		Steven
 * @since		3.1.00
 */
class IntegratorSettingsDunModule extends IntegratorAdminDunModule
{
	/**
	 * Provide means to check for file integrity
	 * @access		protected
	 * @var			string
	 * @since		3.1.00
	 */
	protected $checkstring	=	"@checkString@";
	
	/**
	 * Initialise the object
	 * @access		public
	 * @version		3.1.02
	 *
	 * @since		3.1.00
	 * @see			IntegratorAdminDunModule :: initialise()
	 */
	public function initialise()
	{
		$this->action = 'settings';
		parent :: initialise();
	}
	
	/**
	 * Method to execute tasks
	 * @access		public
	 * @version		3.1.02
	 * 
	 * @since		3.1.00
	 */
	public function execute()
	{
		global $whmcs;
		
		$db		=	dunloader( 'database', true );
		$input	=	dunloader( 'input', true );
		
		switch ( $this->task ):
		case 'save' :
			
			$config		=	dunloader( 'config', 'integrator' );
			$dconfig	=	dunloader( 'config', 'dunamis' );
			$values		=	$config->getValues();
			
			// Deal with language array first
			//$values['languagesettings']	=	json_encode( $input->getVar( 'lang', array(), 'post', 'array' ) );
			
			foreach ( $values as $item => $default ) {
				
				$key = $item;
				$value = $input->getVar( $item, $default );
				
				if ( $key == 'debug' ) {
					$dconfig->set( $key, $value );
				}
				
				if ( is_array( $value ) ) $value = implode( '|', $value );
				
				$config->set( $key, $value );
			}
			
			$config->save();
			$dconfig->save();
			$this->setAlert( 'alert.settings.saved' );
			
			break;
		endswitch;
		
	}
	
	
	/**
	 * Method to render back the view
	 * @access		public
	 * @version		3.1.02
	 * 
	 * @return		string containing formatted output
	 * @since		3.1.00
	 */
	public function render( $data = null )
	{
		$data	= $this->buildBody();
		
		return parent :: render( $data );
	}
	
	
	/**
	 * Builds the body of the action
	 * @access		public
	 * @version		3.1.02
	 * 
	 * @return		string containing html formatted output
	 * @since		3.1.00
	 */
	public function buildBody()
	{
		$form	=	dunloader( 'form', true );
		$values	=	dunloader( 'config', 'integrator' )->getValues( true );
		$fields	=	new stdClass();
		
		// Cycle through the fields now...
		foreach ( array( 'general', 'user', 'visual', 'login', 'pages', 'advanced' ) as $i ) {
			$form->setValues( $values, 'integrator.setting-' . $i );
			$fields->$i	= $form->loadForm( 'setting-' . $i, 'integrator' );
		}
		
		// Handle the autoauth key
		$autoauth	=	$this->_getAutoauthkey();
		$form->setValue( 'apitoken', $autoauth, 'integrator.setting-general' );
		
		$data	=	'<form action="addonmodules.php?module=integrator&action=settings&task=save" class="form-horizontal" method="post">'
				.	'	<div class="tabbable tabs-left">'
				.	'		<ul class="nav nav-tabs">'
				.	'			<li class="active"><a href="#general" data-toggle="tab">' . t( 'integrator.admin.settings.subnav.general' ) . '</a></li>'
				.	'			<li><a href="#user" data-toggle="tab">' . t( 'integrator.admin.settings.subnav.user' ) . '</a></li>'
				.	'			<li><a href="#visual" data-toggle="tab">' . t( 'integrator.admin.settings.subnav.visual' ) . '</a></li>'
				.	'			<li><a href="#login" data-toggle="tab">' . t( 'integrator.admin.settings.subnav.login' ) . '</a></li>'
				.	'			<li><a href="#pages" data-toggle="tab">' . t( 'integrator.admin.settings.subnav.pages' ) . '</a></li>'
				.	'			<li><a href="#advanced" data-toggle="tab">' . t( 'integrator.admin.settings.subnav.advanced' ) . '</a></li>'
				.	'		</ul>'
				.	'		<div class="tab-content">'
				.	'			<div class="tab-pane active" id="general">'
				.	'				' . $this->renderForm( $fields->general )
				.	'			</div>'
				.	'			<div class="tab-pane" id="user">'
				.	'				' . $this->renderForm( $fields->user )
				.	'			</div>'
				.	'			<div class="tab-pane" id="visual">'
				.	'				' . $this->renderForm( $fields->visual )
				.	'			</div>'
				.	'			<div class="tab-pane" id="login">'
				.	'				' . $this->renderForm( $fields->login )
				.	'			</div>'
				.	'			<div class="tab-pane" id="pages">'
				.	'				' . $this->renderForm( $fields->pages )
				.	'			</div>'
				.	'			<div class="tab-pane" id="advanced">'
				.	'				' . $this->renderForm( $fields->advanced )
				.	'			</div>'
				.	'		</div>'
				.	'	</div>'
				.	'	<div class="form-actions">'
				.			$form->getButton( 'submit', array( 'class' => 'btn btn-primary span2', 'value' => t( 'integrator.form.submit' ), 'name' => 'submit' ) )
				.	'		<a href="addonmodules.php?module=integrator&action=default" class="btn btn-inverse pull-right span2">' . t( 'integrator.form.close' ) . '</a>'
				.	'	</div>'
				.	'</form>';
		
		return $data;
	}
	
	
	/**
	 * Method for getting the autoauth key from the configuration file
	 * @access		private
	 * @version		3.1.02 ( $id$ )
	 *
	 * @return		string
	 * @since		3.1.00
	 */
	private function _getAutoauthkey()
	{
		$configfile	=	DUN_ENV_PATH . 'configuration.php';
		$default	=	dunloader( 'config', 'integrator' )->get( 'apitoken', null );
		
		if (! file_exists( $configfile ) ) {
			return $default;
		}
		
		ob_start();
		@include( $configfile );
		ob_end_clean();
		
		if (! isset ( $autoauthkey ) ) {
			return $default;
		}
		
		return $autoauthkey;
	}
	
	
}