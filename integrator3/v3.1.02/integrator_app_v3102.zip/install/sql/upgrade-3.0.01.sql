
INSERT IGNORE INTO `__DBPREFIX__settings` (`key`, `value`) VALUES
('DisplayLogin', '0'),
('SystemURL', '__SYSTEMURL__'),
('SystemSSL', '0'),
('TmpDir', '__TMPDIR__'),
('LogCount', '1000'),
('LoginMsg', 'msg.redirectingnow'),
('LogoutMsg', 'msg.redirectingnow');

-- command split --

INSERT IGNORE INTO `__DBPREFIX__settings` (`key`, `value`) VALUES
('PasswordText', 'This password is insufficient'),
('PasswordStrength', '0'),
('DefaultCountry', 'US'),
('LogPurge', '0');

-- command split --

INSERT IGNORE INTO `__DBPREFIX__settings` (`key`, `value`) VALUES
('BanFreebies', '0' );

-- command split --

CREATE TABLE IF NOT EXISTS `__DBPREFIX__cnxnlog` (
`id`  int(100) NOT NULL AUTO_INCREMENT ,
`timestamp`  timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP ,
`cnxn`  mediumint(10) NOT NULL ,
`destcnxn`  mediumint(10) NOT NULL ,
`action`  varchar(100) NOT NULL ,
`request`  text NULL ,
`response`  text NULL ,
`data`  text NULL ,
`remote`  tinyint NOT NULL DEFAULT 0 ,
PRIMARY KEY (`id`)
);

