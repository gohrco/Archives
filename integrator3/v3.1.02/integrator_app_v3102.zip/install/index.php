<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.02 ( $Id: index.php 246 2013-04-24 21:04:19Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This is the primary executable for the Integrator
 *  
 */


define( 'INTEGRATOR_INSTALL', '3.1.02' );


/**
 * **********************************************************************
 * ENVIRONMENT / ERROR REPORTING
 * **********************************************************************
 */

// Set the environment constant - can be specified in configuration.php
defined( 'ENVIRONMENT' ) or define( 'ENVIRONMENT', 'development' );

if (defined('ENVIRONMENT')) {
	switch (ENVIRONMENT) :
	// -----------------------------------------
	case 'development':
		defined( 'ENVIRONMENT_LOG' ) or define( 'ENVIRONMENT_LOG', '4' );
		error_reporting(E_ALL);
	break;
	// -----------------------------------------
	case 'testing':
		defined( 'ENVIRONMENT_LOG' ) or define( 'ENVIRONMENT_LOG', '1' );
		error_reporting(0);
	break;
	// -----------------------------------------
	case 'production':
		defined( 'ENVIRONMENT_LOG' ) or define( 'ENVIRONMENT_LOG', '0' );
		error_reporting(0);
	break;
	// -----------------------------------------
	default:
		exit('The application environment is not set correctly.');
	break;
	// -----------------------------------------
	endswitch;
}


/**
 * **********************************************************************
 * SYSTEM AND APPLICATION FOLDER NAMES
 * **********************************************************************
 */

// Set the system folder - can be specified in configuration.php to permit
//		testing of new versions of CI
$system_path		= dirname( dirname( __FILE__ ) );

// Application folder must always be includes
$application_folder	= 'install';


/**
 * **********************************************************************
 * RESOLVE PATH AND DECLARE CONSTANTS
 * **********************************************************************
 */

// Set the current directory correctly for CLI requests
if (defined('STDIN')) {
	chdir(dirname(__FILE__));
}

if (realpath($system_path) !== FALSE) {
	$system_path = realpath($system_path).'/';
}

// ensure there's a trailing slash
$system_path = rtrim($system_path, '/').'/';

// Is the system path correct?
if ( ! is_dir( $system_path ) ) {
	exit( "You are attempting to override the system path with an invalid path.  Please correct your configuration.php file and try again." );
}


// The name of THIS file
defined( 'SELF' ) or define('SELF', pathinfo(__FILE__, PATHINFO_BASENAME));

// The PHP file extension
defined( 'EXT' ) or define('EXT', '.php');

// Path to the system folder
defined( 'BASEPATH' ) or define('BASEPATH', str_replace("\\", "/", $system_path));

// Path to the front controller (this file)
defined( 'FCPATH' ) or define('FCPATH', str_replace(SELF, '', __FILE__));

// Name of the "system folder"
defined( 'SYSDIR' ) or define('SYSDIR', trim(strrchr(trim(BASEPATH, '/'), '/'), '/'));


// The path to the "application" folder
if ( is_dir( BASEPATH . 'install' ) ) {
	defined( 'APPPATH' ) or define('APPPATH', '' );
}
else {
	if ( ! is_dir(BASEPATH.$application_folder.'/')) {
		exit( "You are missing the installation folders.  Please upload the folders and try again." );
	}
	
	defined( 'APPPATH' ) or define('APPPATH', BASEPATH.$application_folder.'/');
}

// Ensure the timezone is set for those that choose not to configure their servers
date_default_timezone_set(@date_default_timezone_get());

/**
 * **********************************************************************
 * ALL SET - LETS LOAD
 * **********************************************************************
 */

if (! defined( 'INTEGRATOR_VERSION' ) ) {
	require_once APPPATH . 'core/MY_Common' . EXT;
	require_once BASEPATH . 'core/CodeIgniter'.EXT;
}
