/**
 * Performs an ajax call on button click
 */
function ajaxbutton( call, target ) {
	var caller		= jQuery( target );
	var updateurl	= ajaxurl + '/' + call;
	
	caller.button('loading');
	
	jQuery.ajax({
		type: 'POST',
		url: updateurl,
	}).success( function( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		if ( obj == null ) {
			caller.button( 'error' );
			caller.removeClass( 'btn-inverse' ).addClass( 'btn-danger' );
		}
		else if ( obj.result == 'success' ) {
			if ( obj.data == true ) {
				caller.button( 'complete' );
				caller.removeClass( 'btn-inverse' ).addClass( 'btn-success' );
			}
			else {
				caller.button( 'error' );
				caller.removeClass( 'btn-inverse' ).addClass( 'btn-warning' );
			}
		}
	});
	return false;
}