<?php

defined('_JEXEC') or die( 'Restricted access' );

/**
 * Define the Integrator3 version here
 */
if (! defined( 'DUN_MOD_INTEGRATOR' ) ) define( 'DUN_MOD_INTEGRATOR', "3.1.02" );
if (! defined( 'DUN_MOD_INTEGRATOR_SYSTEM' ) ) define( 'DUN_MOD_INTEGRATOR_SYSTEM', "3.1.02" );


class Integrator_systemDunModule extends DunModule
{
	public function initialise()
	{
		
	}
}