<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.02 ( $Id: default.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This file is the default model file for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.model' );	// Import model
/*-- File Inclusions --*/

/**
 * Default Integrator Model
 * @version		3.1.02
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntegratorModelDefault extends IntegratorModelExt
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.1.02
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Retrieves any debug information for rendering to the admin user
	 * @access		public
	 * @version		3.1.02
	 * 
	 * @return		array of data or empty array
	 * @since		3.0.0
	 */
	public function getDebug()
	{
		$debug		=	dunloader( 'debug', 'com_integrator' );
		return $debug->render();
	}
	
	
	/**
	 * Retrieves the status of the API connection
	 * @access		public
	 * @version		3.1.02
	 * 
	 * @return		true on success or string containing failed message
	 * @since		3.0.0
	 */
	public function getStatus()
	{
		$api	=	dunloader( 'api', 'com_integrator' );
		$result	=	$api->ping();
		return ( $result ? true : $api->getError() );
	}
	
	
	/**
	 * Sends an update settings call to pull the cnxnid from Integrator
	 * @access		public
	 * @version		3.1.02
	 * 
	 * @return		true upon successful completion or an error message
	 * @since		3.0.0
	 */
	public function updateSettings()
	{
		$api		=	dunloader( 'api', 'com_integrator' );
		$config		=	dunloader( 'config', 'com_integrator' );
		
		// Lets figure out our Joomla URL first
		$uri	=	clone Juri::getInstance();
		$path	=	array_reverse( explode( "/", $uri->getPath() ) );
		
		foreach( $path as $k => $p ) {
			if ( in_array( $p, array( "index.php", "administrator" ) ) ) unset( $path[$k] );
		}
		
		$uri->setPath( "/" . implode( '/', array_reverse( $path ) ) );
		
		// Grab our other config settings
		
		$post		=	array(
			'cnxnurl'		=>	$uri->toString( array( "scheme", "host", "path" ) ),
			'active'		=>	( $config->get( 'Enabled' ) == 'Yes' ? true : false ),
			'useractive'	=>	( $config->get( 'UserEnabled' ) == 'Yes' ? true : false ),
		);
		
		// Determine if we should update SSL
		if ( $config->get( 'UseSSL' ) == 'force' ) {
			$post['usessl']	=	'1';
		}
		else if ( $config->get( 'UseSSL' ) == 'none' ) {
			$post['usessl']	=	'0';
		}
		
		// Determine if we should set the debug on
		if ( $config->get( 'IntegratorDebug' ) == 'Yes' ) {
			$post['debug']	=	true;
		}
		
		// Make the call
		try{
			$api->post_settings( $post );
		}
		catch( Exception $e ) {
			return $e->getMessage();
		}
		
		if ( $response['result'] != 'success' ) {
			return $response['data'];
		}
		
		
		return $this->_updateParameters( $response['data'] );
	}
	
	
	/**
	 * Updates the component parameters with current settings from the Integrator
	 * @access		private
	 * @version		3.1.02
	 * @param		array		- $data: contains items to bind to component parameters
	 * 
	 * @return		boolean true on success
	 * @since		3.0.0
	 */
	private function _updateParameters( $data = array() )
	{
		if ( empty( $data ) ) return false;
		
		$params		=	JComponentHelper::getParams( "com_integrator" );
		$updates	=   array();
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			// Joomla 1.6+
			foreach ( $data as $key => $value ) {
				$params->set( $key, $value );
			}
			
			$uri = new Juri( $params->get( 'IntegratorUrl' ) );
			$uri->setPath( rtrim( $uri->getPath(), "/" ) );
			$params->set('IntegratorUrl', $uri->toString() );
			
			$updates['name']	= "Integrator";
			$updates['element']	= "com_integrator";
			$updates['type']	= "component";
			$updates['params']	= (string) $params;
			
			$table	=	JTable::getInstance('extension');
			$updates['extension_id'] = $table->find( array( 'element' => 'com_integrator', 'type' => 'component' ) );
			
		}
		else {
			// Joomla 1.5 specific
			$params->loadSetupFile( JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR . "config.xml" );
			$existing	= $params->toArray();
			$bindarray	= array();
			foreach( $existing as $key => $vals ) {
				$bindarray[$key] = $vals;
			}
			
			foreach ( $data as $key => $value ) {
				$bindarray[$key] = $value;
			}
			
			$uri = new Juri( $bindarray['IntegratorUrl'] );
			$uri->setPath( rtrim( $uri->getPath(), "/" ) );
			$bindarray['IntegratorUrl'] = $uri->toString();
			
			$updates['option']	= "com_integrator";
			$updates['params']	= $bindarray;
			
			$table		= & JTable::getInstance('component');
			$table->loadByOption( 'com_integrator' );
			
		}
		
		$table->bind( $updates );
		
		if (!$table->check()) {
			JError::raiseWarning( 500, $table->getError() );
			return false;
		}
		
		// save the changes
		if (!$table->store()) {
			JError::raiseWarning( 500, $table->getError() );
			return false;
		}
		
		return true;
	}
}