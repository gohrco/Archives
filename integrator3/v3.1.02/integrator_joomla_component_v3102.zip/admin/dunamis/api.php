<?php defined('DUNAMIS') OR exit('No direct script access allowed');
/**
 * Integrator 3
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.02 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This file handles requests to the Integrator 3 API interface
 *
 */


/**
 * Apirequest Class for Integrator 3
 * @version		3.1.00
 *
 * @author		Steven
 * @since		3.1.00
 */
class Com_integratorDunApi extends DunObject
{
	/**
	 * Holds the curl handler
	 * @access		protected
	 * @var			Object
	 * @since		3.1.00
	 */
	protected $curl		=	null;
	
	private $_apiaccept	=	null;
	
	/**
	 * Stores the joomla options for the API
	 * @access		private
	 * @var			array
	 * @since		3.1.00
	 */
	private $_apioptions	= array();
	
	/**
	 * Stores the variables to post each time through the API
	 * @access		private
	 * @var			array
	 * @since		3.1.00
	 */
	private $_apipost	= array();
	
	/**
	 * Stores the timestamp generated for this set of calls
	 * @access		private
	 * @var			Unix Timestampe
	 * @since		3.1.00
	 */
	private $_apitimestamp	= null;
	
	/**
	 * Stores the secret token being used
	 * @access		private
	 * @var			string
	 * @since		3.1.00
	 */
	private $_apitoken	= null;
	
	/**
	 * Stores the uri for the API
	 * @access		private
	 * @var			DunUri Object
	 * @since		3.1.00
	 */
	private $_apiuri		= null;
	
	/**
	 * Indicates which version of the Joomla API we want to call up
	 * @access		private
	 * @var			string
	 * @since		3.1.00
	 */
	private $_apiversion = '3.1';
	
	/**
	 * Stores our connection ID with I3
	 * @access		private
	 * @var			integer
	 * @since		3.1.00
	 */
	private $_cnxnid	=	0;
	
	
	private $_debug		=	false;
	
	/**
	 * Indicates we are enabled or disabled
	 * @access		private
	 * @var			boolean
	 * @since		3.1.00
	 */
	private $_enabled		=	false;
	
	/**
	 * Stores any errors we encounter
	 * @access		private
	 * @var			array
	 * @since		3.1.00
	 */
	private $_error			=	array();
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.1.00
	 * 
	 * @since		3.1.00
	 */
	public function __construct()
	{
		parent :: __construct();
		
		$this->_load();
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Method for creating a client on the connection
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 * @param		array		- $user: the assembled data to send to WHMCS
	 *
	 * @return		object or false on error
	 * @since		3.1.00
	 */
	public function addclient( $user = array() )
	{
		// Catch errors
		if ( empty( $user ) ) return false;
		
		$client = $this->_call_api( 'addclient', $user );
		
		return $client->result == 'success' ? (object) $client : false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Method for closing a client account on the connection
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 * @param		array		- $user: the assembled data to send to WHMCS
	 *
	 * @return		object or false on error
	 * @since		3.1.00
	 */
	public function closeclient( $user = array() )
	{
		// Catch errors
		if ( empty( $user ) ) return false;
		$client = $this->_call_api( 'closeclient', $user );
		return $client->result == 'success' ? (object) $client : false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Method for deleting a client on the connection [permanent]
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 * @param		array		- $user: the assembled data to send to WHMCS
	 *
	 * @return		object or false on error
	 * @since		3.1.00
	 */
	public function deleteclient( $user = array() )
	{
		// Catch errors
		if ( empty( $user ) ) return false;
		$client = $this->_call_api( 'deleteclient', $user );
		return $client->result == 'success' ? (object) $client : false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Method for deleting a contact on the connection [permanent]
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 * @param		array		- $user: the assembled data to send to WHMCS
	 *
	 * @return		object or false on error
	 * @since		3.1.00
	 */
	public function deletecontact( $user = array() )
	{
		// Catch errors
		if ( empty( $user ) ) return false;
		$client = $this->_call_api( 'deletecontact', $user );
		return $client->result == 'success' ? (object) $client : false;
	}
	
	
	/**
	 * Finds a matching user checking first the client then contact api
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 * @param		string		- $email: contains the email address to search for
	 * @param		boolean		- $force: permits overriding cache and loading again
	 *
	 * @return		object or false on error
	 * @since		1.0.0
	 */
	public function findmatchinguser( $email = null, $force = false )
	{
		static $found	=	array();
		
		if ( $email == null ) return false;
		
		// Caching of call
		if ( isset( $found[$email] ) && ! $force ) {
			return $found[$email];
		}
		
		if (! isset( $found[$email] ) || $force ) {
			$found[$email] = false;
		}
		
		$client	=	$this->getclientsdetails( $email, 'email' );
		
		if ( $client ) {
			$client->type	=	'client';
			$found[$email] = $client;
			return $client;
		}
		
		$contact	=	$this->getcontact( $email, 'email' );
		
		if ( $contact->totalresults == 1 ) {
			$contact		=	$contact->contacts->contact[0];
			$contact->type	=	'contact';
			$found[$email] = $contact;
			return $contact;
		}
		
		return false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Method for retrieving a clients details from the connection
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 * @param		mixed		- $id: contains either the client id, email address or an array of data [int|STRING|array]
	 * @param		string		- $by: indicates what the id is if integer / string passed [EMAIL|clientid]
	 *
	 * @return		object or false on error
	 * @since		3.1.00
	 */
	public function getclientsdetails( $id = null, $by = 'email' )
	{
		static $found	=	array();
		
		$data	=	array();
		
		// Permit passing data array directly
		if ( is_array( $id ) ) {
			if (! isset( $id['email'] ) && ! isset( $id['clientid'] ) ) {
				return false;
			}
			$data	=	$id;
			$find	=	isset( $id['email'] ) ? $id['email'] : $id['clientid'];
		}
		else {
			$find	=	$data[($by == 'email' ? 'email' : 'clientid' )] = $id;
		}
		
		if (! isset( $found[$find] ) ) {
			$client = $this->_call_api( 'getclientsdetails', $data );
			$found[$find]	=	$client->result == 'success' ? (object) $client : false;
		}
		
		return $found[$find];
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Method for retrieving a contacts details from the connection
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 * @param		mixed		- $id: contains either the client id, email address or an array of data [int|STRING|array]
	 * @param		string		- $by: indicates what the id is if integer / string passed [EMAIL|userid]
	 *
	 * @return		object or false on error
	 * @since		3.1.00
	 */
	public function getcontact( $id = null, $by = 'email' )
	{
		static $found	=	array();
	
		$data	=	array();
	
		// Permit passing data array directly
		if ( is_array( $id ) ) {
			if (! isset( $id['email'] ) && ! isset( $id['userid'] ) ) {
				return false;
			}
			$data	=	$id;
			$find	=	isset( $id['email'] ) ? $id['email'] : $id['clientid'];
		}
		else {
			$find	=	$data[($by == 'email' ? 'email' : 'clientid' )] = $id;
		}
	
		if (! isset( $found[$find] ) ) {
			$client = $this->_call_api( 'getcontacts', $data );
			$found[$find]	=	$client->result == 'success' ? $client : false;
		}
	
		return $found[$find];
	}
	
	
	/**
	 * Method to retrieve an error from the object
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 *
	 * @return		string
	 * @since		3.1.00
	 */
	public function getError()
	{
		if (! empty( $this->_error ) ) {
			return array_pop( $this->_error );
		}
		
		$config	=	dunloader( 'config', 'com_integrator' );
		$debug	=	$config->get( 'debug', false );
		
		$error	=	$this->curl->has_errors();
		
		// If we have debug on, lets return the curl error raw 
		if ( $debug ) return $error;
		
		$error	=	preg_replace( '#\[[^\]]*\]#i', '', $error );
		return $error;
	}
	
	
	/**
	 * Singleton
	 * @access		public
	 * @static
	 * @version		3.1.00
	 * @param		array		- $options: contains an array of arguments
	 *
	 * @return		object
	 * @since		3.1.00
	 */
	public static function getInstance( $options = array() )
	{
		static $instance = null;
		
		if (! is_object( $instance ) || ( isset( $options['force'] ) && $options['force'] ) ) {
			
			if ( isset( $options['force'] ) ) {
				unset( $options['force'] );
			}
			
			$instance = new Com_integratorDunApi( $options );
		}
	
		return $instance;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Method for retrieving the languages on WHMCS
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function getlanguages( $post = array() )
	{
		$post['module']	=	'jwhmcs';
		$post['method']	=	'api';
		$post['task']	=	'getlanguages';
	
		$call = $this->_call_api( 'dunamis', $post );
		return $call->result == 'success' ? (object) $call->data : false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Method for retrieving a price for the J!WHMCS Pricing Plugin
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 * @param		string		- $price: a comma separated list of price options to fetch
	 * @param		string		- $by: indicates how we are identifying the product (name or id)
	 *
	 * @return		object or false on error
	 * @since		3.1.00
	 */
	public function getprice( $price, $by )
	{
		$post['module']	=	'jwhmcs';
		$post['method']	=	'api';
		$post['task']	=	'getprice';
		$post['price']	=	$price;
		$post['by']		=	$by;
		
		$call = $this->_call_api( 'dunamis', $post );
		return $call->result == 'success' ? (object) $call->data : false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Method for retrieving a clients username from WHMCS
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 * @param		string		- $email: the users' email to find on
	 *
	 * @return		object or false on error
	 * @since		3.1.00
	 */
	public function getusername( $email )
	{
		$post['module']	=	'jwhmcs';
		$post['method']	=	'api';
		$post['task']	=	'getusername';
		$post['email']	=	$email;
		
		$call = $this->_call_api( 'dunamis', $post );
		
		return $call->result == 'success' ? $call->data : false;
	}
	
	
	/**
	 * Method for determining if we encountered any errors
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function hasErrors()
	{
		// Check local object first
		$state	= empty( $this->_error );
		if ( $state === false ) return true;
		
		$state	=	$this->curl->has_errors();
		return $state ? true : false;
	}
	
	
	public function isEnabled()
	{
		return (bool) $this->_enabled;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Method for testing the connection
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function pingOLD()
	{
		$ping	=	$this->_call_api();
		
		if (! $ping || ! is_object( $ping ) || $ping->result != 'success' ) return false;
		
		return true;
	}
	
	
	/**
	 * Method for setting an error message
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 * @param		string		- $msg: the message string
	 * @param		boolean		- $trans: translate the string [T/f]
	 *
	 * @return		false always
	 * @since		3.1.00
	 */
	public function setError( $msg, $trans = true )
	{
		$this->_debug->error( $msg );
		$this->_error[]	=	$msg;
		return false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Method for updating an existing client on the connection
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 * @param		array		- $user: the assembled data to send to WHMCS
	 *
	 * @return		object or false on error
	 * @since		3.1.00
	 */
	public function updateclient( $user = array() )
	{
		// Catch errors
		if ( empty( $user ) ) return false;
		
		$client = $this->_call_api( 'updateclient', $user );
		
		return $client->result == 'success' ? (object) $client : false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Method for updating an existing contact on the connection
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 * @param		array		- $user: the assembled data to send to WHMCS
	 *
	 * @return		object or false on error
	 * @since		3.1.00
	 */
	public function updatecontact( $user = array() )
	{
		// Catch errors
		if ( empty( $user ) ) return false;
		
		$client = $this->_call_api( 'updatecontact', $user );
	
		return $client->result == 'success' ? (object) $client : false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Method for updating the username on the connection
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function updatesettings( $data = array() )
	{
		if ( empty( $data ) ) return false;
		
		$data	=	array(
				'data'		=>	$data,
				'module'	=>	'jwhmcs',
				'method'	=>	'api',
				'task'		=>	'updatesettings'
				);
		
		$call	=	$this->_call_api( 'dunamis', $data );
		return $call->result == 'success';
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Method for updating the username on the connection
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function updateusername( $user = array() )
	{
		if ( empty( $user ) ) return;
		$user['module']	=	'jwhmcs';
		$user['method']	=	'api';
		$user['task']	=	'updateusername';
		
		$client = $this->_call_api( 'dunamis', $user );
		return $client->result == 'success' ? (object) $client : false;	
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 3.1
	 * --------------------------------------------------------------------
	 * Method for validating a login is good
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function validatelogin( $email, $password )
	{
		$user	=	array(
				'email'		=> $email,
				'password2'	=> $password
				);
		
		$data = $this->_call_api( 'validatelogin', $user );
		return $data->result == 'success';
	}
	
	
	/**
	 * Global call
	 * @access		public
	 * @version		3.1.00
	 * @param		string
	 * @param		array
	 *
	 * @throws		\Exception
	 * @return		string
	 * @since		2.0.0
	 */
	public function __call( $method, $arguments )
	{
		// Catch calls if we aren't enabled
		if (! $this->isEnabled() ) {
			return false;
		}
		
		// Determine verb to use
		$parts	=	explode( '_', $method );
		$verb	=	'get';
		
		// If we didn't specify a verb check arg count
		if ( count( $parts ) == 1 ) {
			if (! empty( $arguments ) ) {
				$verb	=	'post';
			}
		}
		else {
			$verb	=	array_shift( $parts );
			$method	=	implode( '_', $parts );
		}
		
		// For now we are assuming every API call has one argument (an array)
		if (! empty( $arguments ) && is_array( $arguments[0] ) ) {
			$arguments	=	$arguments[0];
		}
		
		$call	=	$this->_call_api( $verb, ucfirst( $method ), $arguments );
		
		// If we don't have a response key then thats problematic
		if ( $call === false || ! isset( $call->response ) ) {
			$error	=	$this->curl->has_errors();
			$this->setError( $error ? $error : 'An unknown error occured in the curl handler' );
			throw new \Exception( $error );
		}
	
		// If we have an error throw an exception
		if ( isset( $call->error ) ) {
			throw new \Exception( $call->error );
		}
		
		// If we are sending back a true/false
		if ( $call->type == 'binary' ) {
			return ( $call->data == 'true' ? true : false );
		}
	
		// Fuggetaboutit
		return $call->data;
	}
	
	
	/**
	 * Method for calling up the API
	 * @access		private
	 * @version		3.1.00
	 * @param		string		- $call: the actual API method on the remote system
	 * @param		array		- $post: any additional post variables
	 * @param		array		- $optns: we can specify curl options in this
	 * @param		bool		- @wantresult: true if we want the result back false if we just want to know it worked
	 *
	 * @return		mixed array or boolean
	 * @since		3.1.00
	 */
	private function _call_api( $verb = 'get', $call = 'getactivitylog', $post = array(), $optns = array(), $wantresult = true )
	{
		// Last chance to test before epic fails
		if ( empty( $this->_apiuri ) || empty( $this->_apitoken ) ) {
			$this->_debug->log( 'No ' . ( empty( $this->_apiuri ) ? 'API URL' : 'API TOKEN' ) . ' set - unable to execute ' . $call );
			return false;
		}
		
		// Now we should test to ensure it's live
		$uri	=	clone $this->_apiuri;
		$optns	=	array_merge( $this->_apioptions, $optns );
		$post	=	array_merge( $this->_apipost, $post );
		
		$uri->setPath( rtrim( $uri->getPath(), '/' ) . '/' . $call );
		
		$config	=	dunloader( 'config', 'com_integrator' );
		
		// Put methods require the e in the URL
		if ( in_array( $verb, array( 'get' ) ) ) {
			$uri->setVar( 'integrator', $call );
			$uri->setVar( 'apitimestamp', $this->_apitimestamp );
			unset( $post['apitimestamp'] );
			foreach ( $post as $k => $v ) $uri->setVar( $k, $v );
		}
		
		// Generate the signature
		$sign	=	$this->_generateSignature( $verb, $uri, $post );
		
		// include the signature in the method variable and the header
		if ( in_array( $verb, array( 'get' ) ) ) {
			$uri->setVar( 'apisignature', rawurlencode( $sign ) );
			$uri->setVar( '_c', $this->_cnxnid );
		}
		else {
			$post['apisignature']	=	rawurlencode( $sign );
			$post['_c']				=	$this->_cnxnid;
		}
		
		// Assemble the API Request
		$this->curl->create( $uri->toString() );
		$this->curl->http_header( 'IntegratorRequestSignature', rawurlencode( $sign ) );
		$this->curl->http_header( $this->_apiaccept );
		
		if ( $verb == 'get' ) {
			$this->curl->http_method( 'get' );
			$this->curl->options( $optns );
		}
		else {
			$this->curl->$verb( $post, $optns );
		}
		
		// Execute the Curl Call
		$result	=	$this->curl->execute();
		
		dunloader( 'debug', true )->addApi( array(
			'call'		=>	$call,
			'method'	=>	$method,
			'post'		=>	$post,
			'optns'		=>	$optns,
			'result'	=>	$result,
			'curlinfo'	=>	$this->curl->info
			) );
		
		// Return result
		if (! $wantresult ) {
			return $this->curl->has_errors() ? false : true;
		}
		
		// Clean up our result
		$result	=	$this->_cleanupJson( $result );
		
		// Process for returned errors
		$data	= json_decode( $result, false );
		
		if ( $data->response == 'error' ) {
			if ( $this->_debug ) $msg = $data->message . ' (' . $data->code .')';
			else $msg = $data->message;
			$this->setError( $msg, false );
		}
		
		return $data;
	}
	
	
	/**
	 * Method to cleanup the Json string for PHP just in case Joomla left us a surprise
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 * @param		string		- $string: what we are starting with
	 *
	 * @return		string cleaned up
	 * @since		2.5.4
	 */
	private function _cleanupJson( $string )
	{
		// Clean BOMs from beginning of output
		$string	=	preg_replace( '#^\xEF\xBB\xBF#', '', $string );
		
		// Strip off anything before the first curly bracket
		$string	=	preg_replace( "#^[^{]*#im", "", $string );
		
		return $string;
	}
	
	
	/**
	 * Method for generating the signature request
	 * @access		private
	 * @version		3.1.00
	 * @param		string		- $method: method used (get|post|put...)
	 *
	 * @return		string containing hash
	 * @since		3.1.00
	 */
	private function _generateSignature( $method, $uri, $post = array() )
	{
		$token	=	$this->_apitoken;
		$string	=	$uri->toString();
	
		if ( $method != 'get' ) {
			ksort( $post );
			$usepost	=	array();
				
			foreach ( $post as $k => $v ) {
				if (! in_array( $k, array( 'apisignature', '_c' ) ) ) {
					$usepost[$k] = $v;
				}
			}
			
			dunloader( 'debug', true )->variable( $usepost, 'Variables Used to Assemble Signature With' );
			$string	.=	$this->_generateString( $usepost );
		}
	
		$hash	=	base64_encode( hash_hmac( 'sha256', rawurldecode( $string ), $token, true ) );
		return $hash;
	}
	
	
	/**
	 * Method to generate string
	 * @access		public
	 * @version		3.1.02
	 * @param		array
	 *
	 * @return		string
	 * @since		3.1.00
	 */
	private function _generateString( $data = array() )
	{
		$string	=	null;
		foreach ( $data as $k => $v ) {
			if ( is_array( $v ) ) {
				$string		.=	$this->_generateString( $v );
			}
			else {
				$string	.=	$k . $v;
			}
		}
		return $string;
	}
	
	
	/**
	 * Loads the API and enables if checks out
	 * @access		private
	 * @version		3.1.00
	 *
	 * @since		3.1.00
	 */
	private function _load()
	{
		$this->curl		=	dunloader( 'curl', false );
		$config			=	dunloader( 'config', 'com_integrator' );
		$apiurl			=	$config->get( 'IntegratorUrl', null );
		$apitoken		=	$config->get( 'IntegratorSecret', null );
		$cnxnid			=	$config->get( 'cnxnid' );
		$this->_debug	=	dunloader( 'debug', 'com_integrator' );
		
		// We can't do anything if these are empty
		if ( empty( $apiurl ) || empty( $apitoken ) ) {
			return $this->setError( 'error.apicnxn.' . ( empty( $apiurl ) ? 'nourl' : 'nosecret' ) );
		}
		
		// Clean the URL and complete it
		$apiurl	= rtrim( $apiurl, '/' ) . '/index.php/api/';
		
		$this->_apiuri			=	new DunUri( $apiurl );
		$gmt					=	new DateTime( null, new DateTimeZone('GMT') );
		$this->_apitimestamp	=	$gmt->format( "U" );
		$this->_apitoken		=	$apitoken;
		$this->_cnxnid			=	$cnxnid;
		
		// This gets used every time
		$this->_apipost	=   array(
										'apitimestamp'		=> $this->_apitimestamp
		);
		
		$this->_apiaccept	=	'Accept: application/vnd.gohigheris-com.int3api+json; version=' . $this->_apiversion;
		$this->_apioptions	= array(	'HEADER'			=> false,
										'RETURNTRANSFER'	=> true,
										'SSL_VERIFYPEER'	=> false,
										'SSL_VERIFYHOST'	=> false,
										'CONNECTTIMEOUT'	=> 2,
										'FORBID_REUSE'		=> true,
										'FRESH_CONNECT'		=> true,
										'HTTP_VERSION'		=> CURL_HTTP_VERSION_1_1,
										'HTTPHEADER'		=> array(),
										'COOKIEFILE'		=> "",
										'COOKIEJAR'			=> "",
										'COOKIESESSION'		=> true,
										
		);
		
// 		$result	=	$this->_call_api( 'get', 'Ping', array() );
		
// 		if ( $result->response == 'error' ) {
// 			return;
// 		}
		
		$this->_enabled = true;
		
		return;
	}
}