<?php
/**
 * Integrator 3 - System Plugin
 * 		API Getpages File
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.02 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This is the Get Pages Task which allows us to retrieve the pages of menus in Joomla
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

jimport( 'joomla.filesystem.folder' );
jimport( 'joomla.filesystem.file' );
jimport( 'joomla.filesystem.path' );

/**
 * Verify Jwhmcs API Class
 * @version		3.1.00
 *
 * @since		2.5.3
 * @author		Steven
 */
class GetpagesIntegratorAPI extends IntegratorAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		3.1.00
	 * 
	 * @since		3.1.00
	 * @see			IntegratorAPI :: execute()
	 */
	public function execute()
	{
		$db			=	dunloader( 'database', true );
		$children	=   array();
		
		$query = 'SELECT menutype, title' .
				' FROM #__menu_types' .
				' ORDER BY title';
		$db->setQuery( $query );
		$menuTypes = $db->loadObjectList();
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			$query = 'SELECT id, parent_id, title as name, title, menutype, type, link, lft as ordering FROM #__menu WHERE published = 1';
		}
		else if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$query = 'SELECT id, parent_id, title as name, title, menutype, type, link, ordering FROM #__menu WHERE published = 1';
		}
		else {
			$query = 'SELECT id, parent, parent as parent_id, name, name as title, menutype, type, link, ordering, sublevel FROM #__menu WHERE published = 1';
		}
		
		$db->setQuery($query);
		$menuItems = $db->loadObjectList();
		
		if ($menuItems)
		{
			foreach ($menuItems as $v)
			{
				$pt 	= $v->parent_id;
				$list 	= @$children[$pt] ? $children[$pt] : array();
				array_push( $list, $v );
				$children[$pt] = $list;
			}
		}
		
		$list = JHTML::_('menu.treerecurse', 0, '', array(), $children, 9999, 0, 0 );
		
		$n = count( $list );
		$groupedList = array();
		foreach ($list as $k => $v) {
			if ( empty( $v->menutype ) ) continue;
			$groupedList[$v->menutype][] = &$list[$k];
		}
		
		return $this->success( array( 'data' => $groupedList, 'version' => JVERSION ) );
	}
}