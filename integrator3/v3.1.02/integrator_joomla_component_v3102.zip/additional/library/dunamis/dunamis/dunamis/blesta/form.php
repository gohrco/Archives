<?php
/**
 * @package         Dunamis
 * @version         1.4.1
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2009 - 2015 Go Higher Information Services.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */

defined('DUNAMIS') OR exit('No direct script access allowed');

/**
 * Dunamis Form class for Blesta
 * @desc		This is the form handler for creating and handling forms with the Blesta environment
 * @package		Dunamis
 * @subpackage	Blesta
 * @author		Go Higher Information Services, LLC
 * @link		https://www.gohigheris.com
 * @copyright	2009 - 2015 Go Higher Information Services.  All rights reserved.
 * @license		GNU General Public License version 2, or later
 */
class BlestaDunForm extends DunForm
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.4.1
	 * @param		array		- $options: any options to set
	 * 
	 * @since		1.0.0
	 */
	public function __construct()
	{
		parent :: __construct();
		
		Loader :: loadHelpers( $this, array( "Form" ) );
	}
}