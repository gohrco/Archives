<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.20 ( $Id: default.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This file contains the default model which allows the user and system to interact with the data
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
jimport( 'joomla.application.component.model' );	// Import model


/**
 * Default model class object
 * @version		3.1.20
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntegratorModelDefault extends IntegratorModelExt
{
	/**
	 * Constructor
	 * @access		public
	 * @version		3.1.20
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Gets a username with a given email address
	 * @access		public
	 * @version		3.1.20
	 * @param		string		- $email: contains an email address
	 * 
	 * @return		string containing username found or false on not found
	 * @since		3.0.0
	 */
	public function get_username( $email )
	{
		$db		=	JFactory::getDBO();
		$query	=   "SELECT u.username FROM `#__users` u WHERE u.email=" . $db->Quote( $email );
		$db->setQuery( $query );
		return $db->loadResult();
	}
}