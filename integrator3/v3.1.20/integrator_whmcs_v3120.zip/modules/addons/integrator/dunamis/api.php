<?php defined('DUNAMIS') OR exit('No direct script access allowed');
/**
 * Integrator 3
 * Integrator 3 - API Request Handler File
 *
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.20 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This file handles requests to the Joomla connection
 *
 */


/**
 * Apirequest Class for J!WHMCS Integrator
 * @version		3.1.20
 *
 * @author		Steven
 * @since		3.1.00
 */
class IntegratorDunApi extends DunObject
{
	/**
	 * Holds the curl handler
	 * @access		protected
	 * @var			Object
	 * @since		3.1.00
	 */
	protected $curl		=	null;
	
	/**
	 * Holds the curl info for debugging purposes
	 * @access		public
	 * @var			array
	 * @since		2.5.3
	 */
	public $debug		= array();
	
	/**
	 * Stores the joomla options for the API
	 * @access		private
	 * @var			array
	 * @since		3.1.00
	 */
	private $_apioptions	= array();
	
	/**
	 * Stores the variables to post each time through the API
	 * @access		private
	 * @var			array
	 * @since		3.1.00
	 */
	private $_apipost	= array();
	
	/**
	 * Stores the timestamp generated for this set of calls
	 * @access		private
	 * @var			Unix Timestampe
	 * @since		3.1.00
	 */
	private $_apitimestamp	= null;
	
	/**
	 * Stores the secret token being used
	 * @access		private
	 * @var			string
	 * @since		3.1.00
	 */
	private $_apitoken	= null;
	
	/**
	 * Stores the uri for the API
	 * @access		private
	 * @var			DunUri Object
	 * @since		3.1.00
	 */
	private $_apiuri		= null;
	
	/**
	 * Indicates which version of the Joomla API we want to call up
	 * @access		private
	 * @var			string
	 * @since		3.1.00
	 */
	private $_apiversion = '3.1';
	
	/**
	 * Stores our connection ID with I3
	 * @access		private
	 * @var			integer
	 * @since		3.1.00
	 */
	private $_cnxnid	=	0;
	
	/**
	 * Indicates we are enabled or disabled
	 * @access		private
	 * @var			boolean
	 * @since		3.1.00
	 */
	private $_enabled		=	false;
	
	/**
	 * Stores any errors we encounter
	 * @access		private
	 * @var			array
	 * @since		3.1.00
	 */
	private $_error			=	array();
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.1.20
	 * 
	 * @since		3.1.00
	 */
	public function __construct()
	{
		parent :: __construct();
		
		$this->_load();
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for authenticating a user against Joomla!
	 * @access		public
	 * @version		3.1.20 ( $id$ )
	 * @param		array		- $post: contains username / password to test
	 *
	 * @return		array
	 * @since		3.1.00
	 */
	public function authenticate( $post )
	{
		$data	=	array( 'data' => $post );
		$call	=	$this->_call_api( 'post', 'Authenticate', $data );
		return ( (! $call || ! is_object( $call ) || $call->result != 'success' ) ? array() : $call->data );
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for changing a password for the user on Joomla
	 * @access		public
	 * @version		3.1.20 ( $id$ )
	 *
	 * @return		void
	 * @since		3.1.00
	 */
	public function changepassword( $user )
	{
		$data	=	array( 'data' => $user );
		$wapi	=	dunloader( 'whmcsapi', 'integrator' );
		$result	=	$this->_call_api( 'post', 'Changepassword', $data );
		
		if (! $result || ! is_object( $result ) || $result->result != 'success' ) {
			$wapi->log( 'API: changepassword', $data, $result->error, 'error', 'Failed call to Joomla API' );
			return false;
		}
		
		$wapi->log( 'API: changepassword', $data, $result->data, 'log', 'Successful call to Joomla API' );
		return true;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for creating the user on Joomla
	 * @access		public
	 * @version		3.1.20 ( $id$ )
	 *
	 * @return		void
	 * @since		3.1.00
	 */
	public function createuser( $user )
	{
		$data	=	arraY( 'data' => base64_encode( serialize( $user ) ) );
		$result	=	$this->_call_api( 'post', 'Createuser', $data );
		
		if (! $result || ! is_object( $result ) ) {
			$this->setError( 'noresult' );
			return false;
		}
		
		if ( $result->result != 'success' ) {
			$this->setError( $result->error );
			return false;
		}
		
		return $result->data;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for deleting the user on Joomla
	 * @access		public
	 * @version		3.1.20 ( $id$ )
	 *
	 * @return		void
	 * @since		3.1.00
	 */
	public function deleteuser( $user )
	{
		$data	=	array( 'data' => $user );
		$wapi	=	dunloader( 'whmcsapi', 'integrator' );
		$result	=	$this->_call_api( 'post', 'Deleteuser', $data );
		
		if (! $result || ! is_object( $result ) || $result->result != 'success' ) {
			$wapi->log( 'API: deleteuser', $data, $result->error, 'error', 'Failed call to Joomla API' );
			return false;
		}
		
		$wapi->log( 'API: deleteuser', $data, $result->data, 'log', 'Successful call to Joomla API' );
		return true;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for editing the user on Joomla
	 * @access		public
	 * @version		3.1.20 ( $id$ )
	 *
	 * @return		void
	 * @since		3.1.00
	 */
	public function edituser( $user )
	{
		$data	=	array( 'data' => base64_encode( serialize( $user ) ) );
		$wapi	=	dunloader( 'whmcsapi', 'integrator' );
		$result	=	$this->_call_api( 'post', 'Edituser', $data );
		
		if (! $result || ! is_object( $result ) || $result->result != 'success' ) {
			$wapi->log( 'API: edituser', $data, $result->error, 'error', 'Failed call to Joomla API' );
			return false;
		}
		
		$wapi->log( 'API: edituser', $data, $result->data, 'log', 'Successful call to Joomla API' );
		return true;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for finding a username on Joomla
	 * @access		public
	 * @version		3.1.20 ( $id$ )
	 *
	 * @return		void
	 * @since		3.1.00
	 */
	public function finduser( $email )
	{
		$data	=	array( 'find' => $email );
		$wapi	=	dunloader( 'whmcsapi', 'integrator' );
		$result	=	$this->_call_api( 'get', 'Finduser', $data );
		
		if (! $result || ! is_object( $result ) || $result->result != 'success' ) {
			$wapi->log( 'API: finduser', $data, $result->error, 'error', 'Failed call to Joomla API' );
			return false;
		}
		
		$wapi->log( 'API: finduser', $data, $result->data, 'log', 'Successful call to Joomla API' );
		return $result->data;
	}
	
	
	/**
	 * Method to retrieve an error from the object
	 * @access		public
	 * @version		3.1.20 ( $id$ )
	 *
	 * @return		string
	 * @since		3.1.00
	 */
	public function getError()
	{
		if (! empty( $this->_error ) ) {
			return array_pop( $this->_error );
		}
		
		$config	=	dunloader( 'config', 'integrator' );
		$debug	=	$config->get( 'debug', false );
		
		$error	=	$this->curl->has_errors();
		
		// If we have debug on, lets return the curl error raw 
		if ( $debug ) return $error;
		
		$error	=	preg_replace( '#\[[^\]]*\]#i', '', $error );
		return $error;
	}
	
	
	/**
	 * Singleton
	 * @access		public
	 * @static
	 * @version		3.1.20
	 * @param		array		- $options: contains an array of arguments
	 *
	 * @return		object
	 * @since		3.1.00
	 */
	public static function getInstance( $options = array() )
	{
		static $instance = null;
		
		if (! is_object( $instance ) ) {
			
			$instance = new IntegratorDunApi( $options );
		}
	
		return $instance;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.6
	 * --------------------------------------------------------------------
	 * Method for retrieving a list of Joomla users
	 * @access		public
	 * @version		3.1.20 ( $id$ )
	 *
	 * @return		array
	 * @since		2.6.0
	 */
	public function getuserlist( $search )
	{
		$data	=	array( 'search' => $search );
		$wapi	=	dunloader( 'whmcsapi', 'integrator' );
		$result	=	$this->_call_api( 'get', 'Getuserlist', $data );
	
		if (! $result || ! is_object( $result ) || $result->result != 'success' ) {
			$wapi->log( 'API: finduser', $data, $result->error, 'error', 'Failed call to Joomla API' );
			return false;
		}
	
		$wapi->log( 'API: finduser', $data, $result->data, 'log', 'Successful call to Joomla API' );
		
		$return	=	array();
		foreach( $result->data as $row ) {
			$return[$row->email]	=	$row;
		}
		
		return $return;
	}
	
	
	/**
	 * Method for determining if we encountered any errors
	 * @access		public
	 * @version		3.1.20 ( $id$ )
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function hasErrors()
	{
		// Check local object first
		$state	= empty( $this->_error );
		if ( $state === false ) return true;
		
		$state	=	$this->curl->has_errors();
		return $state ? true : false;
	}
	
	
	/**
	 * Method for determining if the API is enabled
	 * @access		public
	 * @version		3.1.20 ( $id$ )
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function isEnabled()
	{
		return $this->_enabled == true;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for retrieving the languages from Joomla!
	 * @access		public
	 * @version		3.1.20 ( $id$ )
	 * 
	 * @return		array
	 * @since		3.1.00
	 */
	public function languageitems()
	{
		$call	=	$this->_call_api( 'get', 'Languageitems' );
		
		if ( (! $call || ! is_object( $call ) || $call->result != 'success' ) ) {
			return array();
		}
		
		// ---- BEGIN JWHMCS-28
		//		Language dropdown selection on WHMCS is not displaying correctly
		$call->data->languageitems =	unserialize( base64_decode( $call->data->languageitems ) );
		
		foreach ( $call->data->languageitems as $lt => $item ) {
			$call->data->languageitems[$lt]->name	=	( is_utf8( $item->name ) ? $item->name : utf8_encode( $item->name ) );
		}
		// ---- END JWHMCS-28
		
		return ( (! $call || ! is_object( $call ) || $call->result != 'success' ) ? array() : $call->data );
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for testing the connection
	 * @access		public
	 * @version		3.1.20 ( $id$ )
	 *
	 * @return		void
	 * @since		3.1.00
	 */
	public function menuitems()
	{
		$call	=	$this->_call_api( 'get', 'Menuitems' );
		
		if (  (! $call || ! is_object( $call ) || $call->result != 'success' ) ) {
			return array();
		}
		
		// ---- BEGIN JWHMCS-17
		//		Menu items with non-utf8 characters arent being displayed in settings
		$call->data->menuitems	=	unserialize( base64_decode( $call->data->menuitems ) );
		$call->data->menutypes	=	unserialize( base64_decode( $call->data->menutypes ) );
		
		foreach ( $call->data->menuitems as $mt => $items ) {
			foreach ( $items as $cnt => $item ) {
				// ---- BEGIN JWHMCS-21
				//		Accomodate the possibility the string is already utf8
				$call->data->menuitems[$mt][$cnt]->name		=	( is_utf8( $item->name ) ? $item->name : utf8_encode( $item->name ) );
				$call->data->menuitems[$mt][$cnt]->title	=	( is_utf8( $item->title ) ? $item->title : utf8_encode( $item->title ) );
				$call->data->menuitems[$mt][$cnt]->treename	=	( is_utf8( $item->treename ) ? $item->treename : utf8_encode( $item->treename ) );
				// ---- END JWHMCS-21
			}
		}
		
		$call->data->menutypes	=	(object) $call->data->menutypes;
		foreach ( $call->data->menutypes as $mt => $item ) {
			$call->data->menutypes->$mt	=	( is_utf8( $item ) ? $item : utf8_encode( $item ) );
		}
		// ---- END JWHMCS-17
		
		return $call->data;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for testing the connection
	 * @access		public
	 * @version		3.1.20 ( $id$ )
	 * @param		boolean		- $auth: if we are testing for the authentication then true 
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function ping( $auth = true )
	{
		static	$instance = array();
		$find	=	$auth ? 1 : 0;
		
		if (! isset( $instance[$find] ) ) {
			if ( $auth ) {
				$ping	=	$this->_call_api( 'get', 'Ping' );
				$instance[1]	=	( (! $ping || ! is_object( $ping ) || $ping->response != 'success' ) ? false : true );
			}
			else {
				$ping	=	$this->_call_api( 'get', 'Ping', array(), array(), false );
				$instance[0]	=	$ping ? true : $this->curl->has_errors();
			}
		}
		
		return $instance[$find];
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for retrieving the site from Joomla
	 * @access		public
	 * @version		3.1.20 ( $id$ )
	 * @param		array		- $params: a set of parameters to pass along
	 *
	 * @return		object
	 * @since		3.1.00
	 */
	public function render( $params = array() )
	{
		$wapi		=	dunloader( 'whmcsapi', 'integrator' );
		$input		=	dunloader( 'input', true );
		$config		=	dunloader( 'config', 'integrator' );
		
		// Build our options array to pass along
		if ( $config->get( 'passalonguseragent' ) ) {
			$options	=	array( 'USERAGENT' => $input->getVar( 'HTTP_USER_AGENT', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13', 'server' ) );
		}
		else {
			$options	=	array( 'USERAGENT' => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13', 'server');
		}
		
		$result		=	$this->_call_api( 'post', 'render', $params, $options );
		
		if (! $result || ! is_object( $result ) || $result->response != 'success' ) {
			$wapi->log( 'API: render', 'render', $result->error, 'error', 'Failed call to Joomla API' );
			return false;
		}
		
		$wapi->log( 'API: render', 'Rendering', "Successfully retrieved site from Joomla API", 'log', 'Successful call to Joomla API' );
		return $result;
	}
	
	
	/**
	 * Method for setting an error message
	 * @access		public
	 * @version		3.1.20 ( $id$ )
	 * @param		string		- $msg: the message string
	 * @param		boolean		- $trans: translate the string [T/f]
	 *
	 * @return		false always
	 * @since		3.1.00
	 */
	public function setError( $msg, $trans = true )
	{
		$this->_error[]	=	( $trans ? t( 'integrator.' . $msg ) : $msg );
		return false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for validating a user
	 * @access		public
	 * @version		3.1.20 ( $id$ )
	 * @param		array		- $user: contains the information to validate
	 * 
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function validate( $user = array() )
	{
		$data		=	array( 'data' => base64_encode( serialize( $user ) ) );
		$validate	=	$this->_call_api( 'post', 'Validate', $data );
		
		return ( (! $validate || ! is_object( $validate ) || $validate->result != 'success' ) ? false : true );
	}
	
	
	/**
	 * Global call
	 * @access		public
	 * @version		3.1.00
	 * @param		string
	 * @param		array
	 *
	 * @throws		\Exception
	 * @return		string
	 * @since		3.1.00
	 */
	public function __call( $method, $arguments )
	{
		// Catch calls if we aren't enabled
		if (! $this->isEnabled() ) {
			return false;
		}
	
		// Determine verb to use
		$parts	=	explode( '_', $method );
		$verb	=	'get';
	
		// If we didn't specify a verb check arg count
		if ( count( $parts ) == 1 ) {
			if (! empty( $arguments ) ) {
				$verb	=	'post';
			}
		}
		else {
			$verb	=	array_shift( $parts );
			$method	=	implode( '_', $parts );
		}
	
		// For now we are assuming every API call has one argument (an array)
		if (! empty( $arguments ) && is_array( $arguments[0] ) ) {
			$arguments	=	$arguments[0];
		}
	
		$call	=	$this->_call_api( $verb, ucfirst( $method ), $arguments );
	
		// If we don't have a response key then thats problematic
		if ( $call === false || ! isset( $call->response ) ) {
			$error	=	$this->curl->has_errors();
			$this->setError( $error ? $error : 'An unknown error occured in the curl handler' );
			return false;
		}
	
		// If we have an error throw an exception
		if ( isset( $call->error ) ) {
			$this->setError( $error ? $error : 'An unknown error occured in the curl handler' );
			return false;
		}
		
		if ( isset( $call->response ) && $call->response == 'error' ) {
			$this->setError( $call->message );
			return false;
		}
		
		// If we are sending back a true/false
		if ( $call->type == 'binary' ) {
			return ( $call->data == 'true' ? true : false );
		}
	
		// Fuggetaboutit
		return $call->data;
	}
	
	
	/**
	 * Method for calling up the API
	 * @access		private
	 * @version		3.1.20
	 * @param		string		- $method: get|put|post...
	 * @param		string		- $call: the actual API method on the remote system
	 * @param		array		- $post: any additional post variables
	 * @param		array		- $optns: we can specify curl options in this
	 * @param		bool		- @wantresult: true if we want the result back false if we just want to know it worked
	 *
	 * @return		mixed array or boolean
	 * @since		3.1.00
	 */
	private function _call_api( $method = 'post', $call = '/Ping', $post = array(), $optns = array(), $wantresult = true )
	{
		// Last chance to test before epic fails
		if ( empty( $this->_apiuri ) || empty( $this->_apitoken ) ) {
			return false;
		}
		
		// Now we should test to ensure it's live
		$uri	=	clone $this->_apiuri;
		$optns	=	array_merge( $this->_apioptions, $optns );
		$post	=	array_merge( $this->_apipost, $post );
		
		$uri->setPath( rtrim( $uri->getPath(), '/' ) . '/' . $call );
		
		// Lets allow forcing everything to get if we need to
		$config	=	dunloader( 'config', 'integrator' );
		
		// Put methods require the e in the URL
		if ( in_array( $method, array( 'get' ) ) ) {
			$uri->setVar( 'integrator', $call );
			$uri->setVar( 'apitimestamp', $post['apitimestamp'] );
			unset( $post['apitimestamp'] );
			foreach ( $post as $k => $v ) $uri->setVar( $k, $v );
		}
		else {
			$post['integrator']		= $call;
		}
		
		// Generate the signature
		$sign	=	$this->_generateSignature( $method, $uri, $post );
		
		// include the signature in the method variable and the header
		if ( in_array( $method, array( 'get' ) ) ) {
			$uri->setVar( 'apisignature', rawurlencode( $sign ) );
			$uri->setVar( '_c', $this->_cnxnid );
		}
		else {
			$post['apisignature']	= rawurlencode( $sign );
			$post['_c']				= $this->_cnxnid;
		}
		
		// Assemble the API Request
		$this->curl->create( $uri->toString() );
		$this->curl->http_header( 'IntegratorRequestSignature', rawurlencode( $sign ) );
		$this->curl->http_header( $this->_apiaccept );
		
		if ( $method == 'get' ) {
			$this->curl->http_method( 'get' );
			$this->curl->options( $optns );
		}
		else {
			$this->curl->$method( $post, $optns );
		}
		
		// Execute the Curl Call
		$result	=	$this->curl->execute();
		
		// Debug handling
		dunloader( 'debug', true )->addApi( array(
				'call'		=>	$call,
				'method'	=>	$method,
				'post'		=>	$post,
				'optns'		=>	$optns,
				'result'	=>	$result,
				'curlinfo'	=>	$this->curl->info
		) );
		
		// Return result
		if (! $wantresult ) {
			return $this->curl->has_errors() ? false : true;
		}
		
		//		Cleanup string just in case
		$result	=	$this->_cleanupJson( $result );
		
		// Process for returned errors
		$data	= json_decode( $result, false );
		
		if ( $data->response == 'error' ) {
			$this->setError( $data->message, false );
		}
		
		return $data;
	}
	
	
	/**
	 * Method to cleanup the Json string for PHP just in case Joomla left us a surprise
	 * @access		public
	 * @version		3.1.20 ( $id$ )
	 * @param		string		- $string: what we are starting with
	 *
	 * @return		string cleaned up
	 * @since		2.5.4
	 */
	private function _cleanupJson( $string )
	{
		// Strip off anything before the first curly bracket
		$string	=	preg_replace( "#^[^{]*#im", "", $string );
		
		return $string;
	}
	
	
	/**
	 * Method for generating the signature request
	 * @access		private
	 * @version		3.1.20
	 * @param		string		- $method: method used (get|post|put...)
	 *
	 * @return		string containing hash
	 * @since		3.1.00
	 */
	private function _generateSignature( $method, $uri, $post = array() )
	{
		$token	=	$this->_apitoken;
		$string	=	$uri->toString();
		
		if ( $method != 'get' ) {
			ksort( $post );
			$usepost	=	array();
			
			foreach ( $post as $k => $v ) {
				if (! in_array( $k, array( 'apisignature', '_c' ) ) ) {
					$usepost[$k] = $v;
				}
			}
			
			dunloader( 'debug', true )->variable( $usepost, 'Variables Used to Assemble Signature With' );
			$append	=	$this->_generateString( $usepost );
		}
		
		$hash	=	base64_encode( hash_hmac( 'sha256', rawurldecode( $string ) . $append, $token, true ) );
		return $hash;
	}
	
	
	/**
	 * Method to generate string
	 * @access		public
	 * @version		3.1.20
	 * @param		array
	 * @param		array
	 *
	 * @return		string
	 * @since		3.1.00
	 */
	private function _generateString( $data = array() )
	{
		$string	=	null;
		foreach ( $data as $k => $v ) {
			if ( is_array( $v ) ) {
				$string		.=	$this->_generateString( $v );
			}
			else {
				$v			=	( is_bool( $v ) ? $v == true ? '1' : '0' : $v );
				$string		.=	$k . $v;
			}
		}
		return $string;
	}
	
	
	/**
	 * Loads the API and enables if checks out
	 * @access		private
	 * @version		3.1.20
	 *
	 * @since		3.1.00
	 */
	private function _load()
	{
		// MD5 the version first
		$this->curl			=	dunloader( 'curl', false );
		
		$config		=	dunloader( 'config', 'integrator' );
		$apiurl		=	$config->get( 'integratorurl', null );
		$apitoken	=	$config->get( 'apitoken', null );
		$cnxnid		=	$config->get( 'cnxnid', null );
		
		// We can't do anything if these are empty
		if ( empty( $apiurl ) || empty( $apitoken ) ) {
			return $this->setError( 'error.apicnxn.' . ( empty( $apiurl ) ? 'nourl' : 'notoken' ) );
		}
		
		// Test for index.php
		$apiurl	= rtrim( $apiurl, '/' ) . '/index.php/api/';
		
		$this->_apiuri			=	new DunUri( $apiurl );
		$gmt					=	new DateTime( null, new DateTimeZone('GMT') );
		$this->_apitimestamp	=	$gmt->format( "U" );
		$this->_apitoken		=	$apitoken;
		$this->_cnxnid			=	$cnxnid;
		
		// This gets used every time
		$this->_apipost		=   array(	'apitimestamp'	=> $this->_apitimestamp );
		$this->_apiaccept	=	'Accept: application/vnd.gohigheris-com.int3api+json; version=' . $this->_apiversion;
		$this->_apioptions	=	array(	'HEADER'			=> false,
										'RETURNTRANSFER'	=> true,
										'SSL_VERIFYPEER'	=> false,
										'SSL_VERIFYHOST'	=> false,
										'CONNECTTIMEOUT'	=> 2,
										'FORBID_REUSE'		=> true,
										'FRESH_CONNECT'		=> true,
										'HTTP_VERSION'		=> CURL_HTTP_VERSION_1_1,
										'HTTPHEADER'		=> array(),
										'COOKIEFILE'		=> "",
										'COOKIEJAR'			=> "",
										'COOKIESESSION'		=> true,
										
		);
		
		/*$result	=	$this->_call_api( 'get', 'Ping', array() );
		
		if ( $result->response == 'error' ) {
			return;
		}*/
		
		$this->_enabled = true;
		
		return;
	}
}