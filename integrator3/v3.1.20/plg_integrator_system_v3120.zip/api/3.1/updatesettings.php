<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 		API Ping File
 *
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.20 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.5.0
 *
 * @desc       This is the Verify Task which replaces the ping task for the J!WHMCS Integrator API
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Verify Jwhmcs API Class
 * @version		3.1.20
 *
 * @since		2.5.3
 * @author		Steven
 */
class UpdatesettingsIntegratorAPI extends IntegratorAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		3.1.20
	 * 
	 * @since		3.1.00
	 * @see			IntegratorAPI :: execute()
	 */
	public function execute()
	{
		get_dunamis( 'com_integrator' );
		get_dunamis( 'com_dunamis' );
		$input		=	dunloader( 'input', true );
		$iconfig	=	dunloader( 'config', 'com_integrator' );
		$dconfig	=	dunloader( 'config', 'com_dunamis' );
		
		$settings	=	$input->getVar( 'settings', array(), 'array', 'post' );
		
		foreach ( $settings as $key => $value ) {
			switch ( $key ) :
			case 'debug' :
				$dconfig->set( 'debug', ( $value ? 'Yes' : 'No' ) );
				$iconfig->set( 'IntegratorDebug', ( $value ? 'Yes' : 'No' )  );
			break;
			endswitch;
		}
		
		if ( ( $error = $iconfig->save() ) !== true ) {
			\Tracy\Debugger :: barDump( $error, 'Error Saving Integrator 3 Settings' );
		}
		
		if ( ( $error = $dconfig->save() ) !== true ) {
			\Tracy\Debugger :: barDump( $error, 'Error Saving Dunamis Settings' );
		}
		
		return $this->success();
	}
}