<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.20 ( $Id: admin_lang.php 406 2015-07-17 02:14:46Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the Joomla admin controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


// ===================================================================
// 	Edit Connection (cnxns/edit)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['joomla_users.storename']				= "Account Name Creation";
$lang['joomla_users.storename.desc']		= "When a new user is created on this connection from another connection, this setting controls this connection assembles the `name` field if there isn't a specific field called `name` from the originating connection.";
$lang['joomla_users.storename_options']		= array( 'firstlast' => "First Last", 'firstlastco' => "First Last (Company)", 'lastfirst' => "Last, First", 'lastfirstco' => "Last, First (Company)" );

$lang['joomla_users.storeusername']			= "Username Creation";
$lang['joomla_users.storeusername.desc']	= "When a new user is created on another connection that doesn't utilize a `username` field, this setting will control how a new username is generated for the user on this connection.";
$lang['joomla_users.storeusername_options']	= array( 'first.last' => "first.last style", 'last.first' => "last.first style", 'random' => "Random username generation", 'flastname' => "flastname style", 'firstnamel' => "firstnamel style", 'firstname' => "Firstname Only", 'lastname' => "Lastname Only" );

$lang['joomla_users.usessl']				= "Use SSL on Log In / Out";
$lang['joomla_users.usessl.desc']			= "If you have a valid security certificate for this connection and for the domain the Integrator is using, you can enable this to protect sensitive information for customers when logging in or out.";
$lang['joomla.options.users.usessl']		= array( 'none' => "Do Not Use", 'force' => "Always Use (Force)", 'ignore' => "Defer to Global Setting (Ignore)" );

$lang['joomla_globals.ismultisite']			= 'Multisite';
$lang['joomla_globals.ismultisite.desc']	= 'Joomla permits ';


// ===================================================================
// 	User Management (usermgr/modify)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['joomla_userinfo.email.desc']		= 'The email address is required by Joomla and is the single identifier across all connections.  Changing this may prevent the user from logging in across all your applications.';
$lang['joomla_userinfo.username.desc']	= 'The username field is required by Joomla and can be modified here directly.';
$lang['joomla_userinfo.name.desc']		= 'The name field is required but can be set to any value your user would like.';



// ===================================================================
// 	User Management Create (usermgr/create)
// ===================================================================
//		v 3.0.2
// -------------------------------------------------------------------
$lang['joomla_label.fullname']	= 'Fullname';
$lang['joomla_desc.fullname']	= 'Joomla! requires a full name to create a new user.  Please enter a complete name to use for this new user';



// ===================================================================
// 	System Update (help/systemstatus/updates)
// ===================================================================
//		v 3.0.8
// -------------------------------------------------------------------
$lang['dialog.joomla.update.content']	= '<p>If your Integrator 3 addon module for WHMCS is already at version 3.1.05 at least, you can automatically perform updates through this interface by clicking on the button below.  If you have an earlier version, you will need to download the latest version from our site and install through the backend of Joomla.</p>';
$lang['dialog.joomla.update.header']	= 'Upgrade Integrator 3 Addon for Joomla!';
//
//		v 3.1.05
// -------------------------------------------------------------------
$lang['dialog.joomla.button.update']	=	'<i class="icon-white icon-cog">&nbsp;</i>&nbsp;Update Now';
