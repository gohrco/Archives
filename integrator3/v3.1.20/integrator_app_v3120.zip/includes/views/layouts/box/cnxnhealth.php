<div class="box">
	
	<?php echo heading ( lang( 'cbox.title' ), '2' ); ?>
	
	<?php if (! is_null( $status ) ) : ?>
	 
	 <table class="table table-striped table-bordered table-condensed">
	 	<thead>
	 		<tr>
	 			<th><?php echo lang( 'cbox.hdr.cnxn' ); ?></th>
	 			<th class="center"><?php echo lang( 'cbox.hdr.type' ); ?></th>
	 			<th class="center"><?php echo lang( 'cbox.hdr.active' ); ?></th>
	 			<th class="center"><?php echo lang( 'cbox.hdr.user' ); ?></th>
	 			<th class="center"><?php echo lang( 'cbox.hdr.visual' ); ?></th>
	 			<th class="center"><?php echo lang( 'cbox.hdr.api' ); ?></th>
	 		</tr>
	 	</thead>
	 	<tbody>
	 		<?php foreach ( $status as $item ) : ?>
	 		<tr>
	 			<td><?php echo anchor( 'cnxns/edit/' . $item->id, $item->name ); ?></td>
	 			<td class="center"><?php echo $item->type; ?></td>
	 			<td class="center"><i class="fam-<?php echo ( $item->active ? 'accept' : 'cross' ); ?>"></i></td>
				<td class="center"><i class="fam-<?php echo ( $item->user ? 'accept' : 'cross' ); ?>"></i></td>
				<td class="center"><i class="fam-<?php echo ( $item->visual ? 'accept' : 'cross' ); ?>"></i></td>
				<td class="center"><i class="fam-<?php echo ( $item->ping ? 'accept' : 'cross' ); ?>"></i></td>
	 		</tr>
	 		<?php endforeach; ?>
	 	</tbody>
	 </table>
	 
	<?php endif; ?>
</div>