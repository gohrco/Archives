<?php
// =========================================
// Titles
// =========================================
$lang['process.step1']			= 'Terms of Service';
$lang['process.step2']			= 'Database Settings';
$lang['process.step3']			= 'Server Requirements Check';
$lang['process.step4']			= 'File Permissions Check';
$lang['process.step5']			= 'Installation';

// =========================================
// Headers and Descriptions
// =========================================
$lang['process.step1.hdr']		= 'Terms of Service <small>Step 1</small>';
$lang['process.step1.desc']		= 'Before proceeding, please review our Terms of Service in using Integrator 3. When are done, click "I Agree" to proceed, if you do not wish to be bound by these terms, please click "I Disagree" to cancel installation.';

$lang['process.step2.hdr']		= 'Database Settings <small>Step 2</small>';
$lang['process.step2.desc']		= 'Fill in the database settings below. For most, the server should remain as Localhost, however if you are using a remote database server, you can the correct value. Be sure to enter the correct username and password. The installer will attempt to connect to your database and will alert you to the results below.';

$lang['process.step3.hdr']		= 'Server Requirements Check <small>Step 3</small>';
$lang['process.step3.desc']		= 'Integrator has checked your server for the requirements necessary to run the application. If everything checks out, you should see all green checks and can proceed. If there is a requirement missing, you will not be able to continue with the installation and will need to resolve it prior to proceeding.';

$lang['process.step4.hdr']		= 'File Permissions Check <small>Step 4</small>';
$lang['process.step4.desc']		= 'Integrator has checked your server for the necessary directory and file permissions. If all checks out, you will see green checks and can continue. If for some reason there is a problem with a permission or directory, you will need to fix the indicated issue prior to proceeding.';

$lang['process.step5.hdr']		= 'Installation <small>Step 5</small>';
$lang['process.step5.desc']		= 'Before installation, Integrator needs some further information. The first portion asks for further database settings to use; if you have a limited number of databases on your hosting plan, you can opt to use a pre-existing database and a custom prefix; Integrator will verify your database settings for you to alert you of any problems before proceeding. The second portion asks for your actual log in information for the admin user as well as the license key you received when you purchased Integrator.';

// =========================================
// Required Item Titles (step3+4)
// =========================================
$lang['title.php']				= 'PHP Version';
$lang['title.mysql']			= 'MySQL Version';
$lang['title.curl']				= 'Curl Extension';
$lang['title.ioncube']			= 'ionCube Loaders';
$lang['title.xmlwriter']			= 'XMLWriter Extension';
$lang['title.files']			= 'Configuration Files';
$lang['title.dirs']				= 'Directory Permissions';

// =========================================
// Error Messages
// =========================================
$lang['error.heading']			= 'Error Message';
$lang['error.tosaccept']		= 'You must accept the Terms of Service before continuing with the installation.';
$lang['error.dbinvalid']		= 'Unable to connect to your database!  Recheck your settings';
$lang['error.php']				= 'Your server is running version %s, but PHP 5 or higher is required.  Please update your server and try again.';
$lang['error.mysql']			= 'Your server is running version %s and your client is running version %s.  Both server and client are required to be version 5 or above.  Please update your server and try again.';
$lang['error.curl']				= 'You do not have curl installed on your server!  Curl is required for the core functionality of the Integrator!  Please install on your server and try again.';
$lang['error.ioncube']			= 'Your server is running version %s.  Please update your ionCube loaders before proceeding.';
$lang['error.xmlwriter']		= 'You must compile PHP to include XMLWriter for Integrator 3 to function.';
$lang['error.files']			= 'Your configuration files are not writable.  Please correct the permissions in the root directory `%s`';
$lang['error.err1.files']		= 'You are missing the configuration.php.new file.  Please upload the configuration.php.new file to `%s` and try again.';
$lang['error.err2.files']		= 'You have an old configuration.php file in place, but it cannot be changed or you are missing the configuration.php.new template.  Please upload the configuration.php.new file to `%s` and try again.';
$lang['error.dir']				= 'The directory `%s` is not writable by the system.  Please correct and try again.';
$lang['error.db_connect']		= 'Problem reported with settings: ';
$lang['error.db_connect2']		= 'There was a problem pulling your database settings from the session.  You may need to start the installation over to complete install.';
$lang['error.db_connect3']		= 'You need to specify a name for the database';
$lang['error.db_create']		= 'The database `%s` already exists and cannot be created';
$lang['error.db_nocreate']		= 'The database `%s` does not exist but you didn\'t ask to create it.';
$lang['error.db_prefix']		= 'The prefix `%s` results in a conflict on the database `%s`';
$lang['error.db_permcheck']		= 'You do not have permission to create the database table.  Please create the table before continuing.';
$lang['error.run-dbcon']		= 'Unable to connect to the data server';
$lang['error.run-dbcreate']		= 'Unable to create database `%s`';
$lang['error.run-dbsel']		= 'Unable to select the database `%s`';
$lang['error.run-dbsql']		= 'Unable to execute SQL statements';
$lang['error.run-config']		= 'Unable to write the new configuration file';

// =========================================
// Success Messages
// =========================================
$lang['success.heading']		= 'Success!';

// =========================================
// General Message Statements
// =========================================
$lang['msg.php']				= 'Your server is currently running version %s';
$lang['msg.mysql']				= 'Your server is running version %s and your client is running version %s.';
$lang['msg.curl']				= 'Curl detected.';
$lang['msg.ioncube']			= 'Your server is running version %s.';
$lang['msg.xmlwriter']			= 'XMLWriter detected.';
$lang['msg.files']				= 'Your configuration files are ready to go!';
$lang['msg.dir']				= 'The directory `%s` is writable';
$lang['msg.db_connect']			= 'Your settings are valid!';
$lang['msg.db_create']			= 'The database `%s` can be created!';
$lang['msg.db_nocreate']		= 'No conflicts found in using the database `%s`!';

// =========================================
// Buttons
// =========================================
$lang['btn.agree']			= 'I Agree';
$lang['btn.disagree']		= 'I Disagree';
$lang['btn.tryagain']		= 'Try Again';
$lang['btn.step2']			= 'Proceed to Requirements Check';
$lang['btn.step3']			= 'Proceed to Permissions Check';
$lang['btn.step4']			= 'Proceed to Install';
$lang['btn.step5']			= 'INSTALL';

// =========================================
// Menu Items
// =========================================
$lang['menu.step1']				= 'Terms of Service';
$lang['menu.step2']				= 'Database Setup';
$lang['menu.step3']				= 'Check Requirements';
$lang['menu.step4']				= 'Check Permissions';
$lang['menu.step5']				= 'Install';
$lang['menu.step6']				= 'Complete';

// =========================================
// Form Items
// =========================================
// Database Selection Items
// -----------------------------------------
$lang['db_hostname']			= 'Server Name';
$lang['db_hostname.desc']		= 'Enter the name of your database - for most this will be `localhost`';
$lang['db_username']			= 'Database Username';
$lang['db_username.desc']		= 'Enter the username that has access to your database';
$lang['db_password']			= 'Database Password';
$lang['db_password.desc']		= 'Enter the password for the username above';
$lang['db_port']				= 'Database Port';
$lang['db_port.desc']			= 'If your database is on a different port, enter that here';
$lang['db_database']			= 'Database Name';
$lang['db_database.desc']		= 'Enter a unique database name to use';
$lang['db_dbprefix']			= 'Table Prefix';
$lang['db_dbprefix.desc']		= 'If you are using the same database for multiple applications, you can specify a custom database table prefix here.';
$lang['db_create']				= 'Create database';
$lang['db_create.desc']			= 'Select this to have the Integrator attempt to create the database for you.  If it is unable to, you will need to create the database yourself.';
// -----------------------------------------
// Username Items
// -----------------------------------------
$lang['username']				= 'Admin Username';
$lang['username.desc']			= 'Enter the username you would like to use for administrative access to the Integrator.  You can always change this later.';
$lang['email']					= 'Admin Email';
$lang['email.desc']				= 'Enter the email address associated with the administrative account.  You can always change this later.';
$lang['password']				= 'Admin Password';
$lang['password.desc']			= 'Enter a password you would like to use for administrative access to the Integrator.  You can always change this later.';
// -----------------------------------------
// License Items
// -----------------------------------------
$lang['license']				= 'License Key';
$lang['license.desc']			= 'Enter the license for the Integrator you received at the time of purchase.';







$lang['reqd.perms']				= 'File and directory permissions must be correct before proceeding!';

$lang['csrfcheck']				= 'An error occurred - please try again';
$lang['db_permcheck']			= 'You do not have permission to create the database table.  Please create the table before continuing.';
$lang['db_valid']				= 'database validation';


// --------------
$lang['install']				= 'Installation';
$lang['install.index']			= 'Checking your install...';
