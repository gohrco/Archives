<?php

defined('_JEXEC') or die( 'Restricted access' );

/**
 * Define the Integrator3 version here
 */
if (! defined( 'DUN_MOD_INTEGRATOR' ) ) define( 'DUN_MOD_INTEGRATOR', "3.1.08" );
if (! defined( 'DUN_MOD_INTEGRATOR_USER' ) ) define( 'DUN_MOD_INTEGRATOR_USER', "3.1.08" );


class Integrator_userDunModule extends DunModule
{
	public function initialise()
	{
		
	}
}