<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.08 ( $Id: router.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This is the router file for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Router for building SEF link
 * @version		3.1.08
 * @param		array		$query - contains the query items of the url
 * 
 * @return		array of segments in order of assembly for the url (ie /component/com_jwhmcs/controller/model/...)
 * @since		3.0.0
 */
function IntegratorBuildRoute(&$query)
{
	$segments = array();
	
	return $segments;
}


/**
 * Parses the url for query items
 * @version		3.1.08
 * @param		array		$segments - items pulled in order from the URL
 * 
 * @return		array containing query items in key => value format
 * @since		3.0.0
 */
function IntegratorParseRoute($segments)
{
	$vars = array();
	
	return $vars;
}
