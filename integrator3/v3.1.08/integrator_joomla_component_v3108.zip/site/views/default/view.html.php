<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.08 ( $Id: view.html.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      1.5.0
 * 
 * @desc       This is the default view file to assemble the view for the user
 *  
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );


/**
 * Default view is used to render the wrapper
 * @version	3.0.0
 * 
 * @since	1.5.0
 * @author Steven
 */
class IntegratorViewDefault extends IntegratorViewExt
{
	/**
	 * Builds the view from the display task for the user
	 * @access	public
	 * @version	3.0.0
	 * @param 	string		$tpl - presumably a template name never used
	 * 
	 * @since	1.5.0
	 */
	public function display($tpl = null)
	{

		get_dunamis( 'com_integrator' );
		dunloader( 'helpers', 'com_integrator' );
		
		$app		=	JFactory::getApplication();
		$params		=	$app->getParams();
		$config		=	dunloader( 'config',	'com_integrator' );
		$input		=	dunloader( 'input',		true );
		$uri		=	JURI::getInstance();
		$document	=	JFactory::getDocument();
		$layout		=	$input->getVar( 'layout', 'default' );
		$route		=   false;
		
		// If we aren't passing the override variable, redirect to desired location
		if (! $input->getVar( "override", false ) && $layout == 'default' ) {
			
			$api		=	dunloader( 'api', 'com_integrator' );
			$lang		=   get_language();
			$route		=   $api->get_route( array( 'cnxn_id' => $params->get( 'menu_cnxn_id' ), 'page' => $params->get( 'menu_page' ), 'vars' => $params->get( 'qrystring' ), 'lang' => $lang  ) );
			$layout		=   'debug';
			
			if ( $route === false ) {
				$debug	= $params->get( 'IntegratorDebug' );
				if ( $debug == 'No' ) $route = '';
			}
		}
		
		// If we have a route to redirect to then do so
		if ( $route !== false ) {
			
			if (! is_null( $enable = JRequest :: getVar( 'dg' ) ) ) {
				// Must occur after pulling any info from API
				defined( 'INTEGRATOR_API' ) or define( 'INTEGRATOR_API', true );
				$user	= & JFactory :: getUser();
				$user->setParam( 'display_gravatar', $enable );
				$user->save();
			}
			
			$app->redirect( $route );
			$app->close();
		}
		
		switch( $layout ):
		case 'loginerror':
			$errormsg	= 'COM_INTEGRATOR_LOGINERROR_' . strtoupper( IntegratorHelper :: get( 'errmsg' ) );
			$errorcode	= ( $params->get( 'IntegratorDebug' ) == 'Yes' ? ' (' . IntegratorHelper :: get( 'errmsg' ) . ')' : '' );
			
			JError::raiseWarning( IntegratorHelper :: get( 'errmsg' ), JText::_( $errormsg ) . $errorcode );
			
			if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
				$app->redirect(JRoute::_('index.php?option=com_users&view=login', false));
			}
			else {
				$app->redirect( JRoute::_('index.php?option=com_user&view=login', false ) );
			}
			
			$app->close();
			
			break;
		case 'debug':
			$debug	=	IntDebug :: getInstance();
			$data	=   $debug->get_output();
			
			$this->setLayout( 'debug' );
			$this->assignRef( 'debug', $data );
			
			break;
		case 'default':
		default:
			
// 			$base =	$document->getBase();
// 			if ( empty( $base ) ) {
// 				$document->setBase( $uri->toString( array('scheme', 'host', 'path') ) );
// 			}
			
			add_media( "frontendfixes/css", array(), true );
			
			$doc	=	dunloader( 'document', true );
			$base	=	$doc->getBase();
			
			if ( empty( $base ) ) {
				$base	=	$uri->toString( array('scheme', 'host', 'path') );
				$doc->setBase( $base );
			}
			
			break;
		endswitch;
		
		$this->assignRef('params',	$params);
		
		parent::display($tpl);
		
	}
}