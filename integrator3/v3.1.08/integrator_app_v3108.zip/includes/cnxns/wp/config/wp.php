<?php

/*
|--------------------------------------------------------------------------
| Default name for Connection
|--------------------------------------------------------------------------
| If no name is specified, this name will be used until changed
|--------------------------------------------------------------------------
*/
$config['name']		= 'Wordpress';

/*
|--------------------------------------------------------------------------
| Connection Version
|--------------------------------------------------------------------------
| This reflects what version of the files you are using.  This should not
| be changed.
|--------------------------------------------------------------------------
*/
$config['version']	= '3.1.08';

/*
|--------------------------------------------------------------------------
| Connection Type
|--------------------------------------------------------------------------
| This should never be changed and should always match the folder name of
| this connection.
|--------------------------------------------------------------------------
*/
$config['type']		= 'wp';

/*
|--------------------------------------------------------------------------
| Credentials Received Array
|--------------------------------------------------------------------------
| This array is used to translate what values are sent by this connection to
| the Integrator when logging in.  The array key (on the left) is what the
| Integrator uses, and the value assigned to it is what the Integrator will
| look for if being sent credentials by this connection.
|--------------------------------------------------------------------------
*/
$config['credentials']['received'] = array(
			'username'	=> 'log',
			'password'	=> 'pwd',
			'remember'	=> 'rememberme'
);

/*
|--------------------------------------------------------------------------
| Credentials Sent Array
|--------------------------------------------------------------------------
| This array is used to translate what values are sent to this connection 
| from the Integrator when logging in.  The array key (on the left) is what
| the Integrator uses, and the value assigned to it is what the Integrator
| will send to this connection for logging in.
|--------------------------------------------------------------------------
*/
$config['credentials']['sent'] = array(
			'username'	=> 'log',
			'password'	=> 'pwd',
			'remember'	=> 'rememberme'
);

/*
|--------------------------------------------------------------------------
| Credentials Source
|--------------------------------------------------------------------------
| This is an array of possible locations to find the credentials being sent
| to the Integrator.  For security purposes, it should always look for
| credentials in the post variables, as get variables are insecure.
|--------------------------------------------------------------------------
*/
$config['credentials']['source'] = array( 'post' );

/*
|--------------------------------------------------------------------------
| Credentials Required
|--------------------------------------------------------------------------
| This is an array of INTEGRATOR values that are required in order to log a
| user into this connection.  Note that the values are what are stored by the
| Integrator, and not what the connection is sending or expecting.
|--------------------------------------------------------------------------
*/
$config['credentials']['required']	= array( 'username', 'password' );

/*
|--------------------------------------------------------------------------
| API Curl Post Variables Array
|--------------------------------------------------------------------------
| Used to set default values for API Curl Post Variables.  Allows for the
| specification of hard coded values.
|--------------------------------------------------------------------------
*/
$config['apivars']	= array(	'apiusername'	=> null,
								'apipassword'	=> null
);

/*
|--------------------------------------------------------------------------
| API Curl Options Array
|--------------------------------------------------------------------------
| This array contains the default curl options to set for the API curl
| handler.  Note that the prefix CURLOPT_ is prepended to the array key
| at the time of execution.
|--------------------------------------------------------------------------
*/
$config['apioptions']	= array(	'POST'				=> true,
									'TIMEOUT'			=> 30,
									'RETURNTRANSFER'	=> true,
									'POSTFIELDS'		=> array(),
									'FOLLOWLOCATION'	=> false,
									'HEADER'			=> true,
									'HTTPHEADER'		=> array( 'Expect:' ),
									'MAXREDIRS'			=> 5,
									'SSL_VERIFYHOST'	=> false,
									'SSL_VERIFYPEER'	=> false
);

/*
|--------------------------------------------------------------------------
| Visual Curl Post Variables Array
|--------------------------------------------------------------------------
| Used to set default values for Visual Curl Post Variables.  Allows for the
| specification of hard coded values.
|--------------------------------------------------------------------------
*/
$config['visualvars']	= array(	);

/*
|--------------------------------------------------------------------------
| Visual Curl Options Array
|--------------------------------------------------------------------------
| This array contains the default curl options to set for the visual curl
| handler.  Note that the prefix CURLOPT_ is prepended to the array key
| at the time of execution.
|--------------------------------------------------------------------------
*/
$config['visualoptions']= array(	'POST'				=> true,
									'TIMEOUT'			=> 30,
									'RETURNTRANSFER'	=> true,
									'POSTFIELDS'		=> array(),
									'FOLLOWLOCATION'	=> false,
									'HEADER'			=> true,
									'HTTPHEADER'		=> array( 'Expect:' ),
									'MAXREDIRS'			=> 5,
									'SSL_VERIFYHOST'	=> false,
									'SSL_VERIFYPEER'	=> false
);