<?php
/**
 * Integrator 3
 * WHMCS - Configuration File
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.08 ( $Id: config.php 323 2014-02-21 14:28:19Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This file is used to handle configuration values needed by the Integrator
 *  
 */

/*-- Security Protocols --*/
defined( 'WHMCS' ) or die( 'Restricted access' );
/*-- Security Protocols --*/


/**
 * Config Class
 * @version		3.1.08
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntConfig extends IntObject
{
	/**
	 * Stored by WHMCS to control who has access to the Integrator module (not used by Integrator)
	 * @access		public
	 * @version		3.1.08
	 * @var			string
	 */
	public $access			= null;
	
	/**
	 * Stores the corresponding cnxn id for this connection
	 * @access		public
	 * @version		3.1.08
	 * @var			string
	 */
	public $cnxnid			= null;
	
	/**
	 * Stores the debug setting
	 * @access		public
	 * @version		3.1.08
	 * @var			boolean
	 */
	public $Debug			= false;
	
	/**
	 * The global override for the module
	 * @access		public
	 * @version		3.1.08
	 * @var			string
	 */
	public $Enabled			= "No";
	
	/**
	 * Enables the User Integration
	 * @access		public
	 * @version		3.1.08
	 * @var			string
	 */
	public $UserEnabled		= "No";
	
	/**
	 * Enables the Visual Integration
	 * @access		public
	 * @version		3.1.08
	 * @var			string
	 */
	public $VisualEnabled	= "No";
	
	/**
	 * Stores the URL to the Integrator - no index.php
	 * @access		public
	 * @version		3.1.08
	 * @var 		string
	 */
	public $IntegratorUrl	= null;
	
	/**
	 * The Username for the Integrator API User
	 * @access		public
	 * @version		3.1.08
	 * @var			string
	 */
	public $IntegratorUsername	= null;
	
	/**
	 * The Password for the Integrator API User
	 * @access		public
	 * @version		3.1.08
	 * @var			string
	 */
	public $IntegratorPassword	= null;
	
	/**
	 * The API Secret Key from the Integrator
	 * @access		public
	 * @version		3.1.08
	 * @var			string
	 */
	public $IntegratorApisecret	= null;
	
	/**
	 * The registration method to use for this connection
	 * @access		public
	 * @version		3.1.08
	 * @var			string
	 */
	public $RegistrationMethod	= null;
	
	/**
	 * Indicates to use SSL on login / logout
	 * @access		public
	 * @version		3.1.08
	 * @var			string (Never,Always,Ignore)
	 */
	public $UseSSL				= null;
	
	/**
	 * Toggle to wrap our invoices and quotes in I3 wrapper
	 * @access		public
	 * @version		3.1.08
	 * @var			string
	 */
	public $WrapInvoice			= "No";
	
	/**
	 * Stored by WHMCS to indicate the version of the Integrator currently installed in the database
	 * @access		public
	 * @version		3.1.08
	 * @var			string
	 */
	public $version			= "3.1.08";
	
	/**
	 * Catchall for any missing variables - we need to define them
	 * @access		private
	 * @version		3.1.08
	 * @var			array
	 */
	private $data			= array();
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.1.08
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		$this->load();
	}
	
	
	/**
	 * Binds an array or object of data to the data field for saving
	 * @access		public
	 * @version		3.1.08
	 * @param		array or object	- $data: contains the data to save to the database
	 * 
	 * @since		3.0.0
	 */
	public function bind( $data = array() )
	{
		$bind	= array();
		foreach ( $data as $k => $v ) $bind[$k] = $v;
		$this->data	= $bind;
	}
	
	
	/**
	 * Loads the data from the database and sets it to this object
	 * @access		public
	 * @version		3.1.08
	 * @version		3.0.8		- Dec 2012:  Added capability to specify debug mode in URL
	 * @param		string		- $setting: permits an individual setting to be loaded
	 * 
	 * @since		3.0.0
	 */
	public function load( $setting = null )
	{
		$where	= ( $setting != null ? " AND `setting` = '{$setting}'" : "" );
		
		$db = & IntFactory::getDbo();
		$db->setQuery( "SELECT `setting`, `value` FROM tbladdonmodules WHERE `module` = 'integrator'".$where );
		$settings	= $db->loadObjectList();
		
		if ( $setting != null ) {
			return (! is_array( $settings ) ? false : $row[0]->value );
		}
		
		foreach ( $settings as $row ) {
			$var = $row->setting;
			if ( in_array( $var, array( "Debug", "WrapInvoice" ) ) ) {
				$this->$var = ( $row->value == "Yes" ? true : false );
			}
			else {
				$this->$var = $row->value;
			}
		}
		
		// Permit displaying of debug output if provided by URL parameter
		if ( isset( $GLOBALS['integrator_debug'] ) ) {
			$override = $GLOBALS['integrator_debug'] == 'Yes' ? true : false;
			$this->Debug = $override;
		}
		
		if ( isset( $GLOBALS['integrator_enabled'] ) ) {
			$override = $GLOBALS['integrator_enabled'] == 'Yes' ? 'Yes' : 'No';
			$this->Enabled = $override;
			$this->UserEnabled = $override;
			$this->VisualEnabled = $override;
		}
	}
	
	
	/**
	 * Saves any bound data to the database
	 * @access		public
	 * @version		3.1.08
	 * 
	 * @since		3.0.0
	 */
	public function save()
	{
		$data	=   $this->data;
		$db		= & IntFactory::getDbo();
		
		foreach ( $data as $key => $val ) {
			if ( $this->load( $key ) === false ) {
				$query	= sprintf( "INSERT INTO tbladdonmodules (`module`, `setting`, `value`) VALUES ('integrator', %s, %s)",
							$db->Quote( $key ),
							$db->Quote( $val ) );
			}
			else {
				$query	= sprintf( "UPDATE tbladdonmodules SET `value` = %s WHERE `module` = 'integrator' AND `setting` = %s",
							$db->Quote( $val ),
							$db->Quote( $key ) );
			}
			$db->setQuery( $query );
			$db->query();
		}
		$this->data = array();
		$this->load();
	}
}