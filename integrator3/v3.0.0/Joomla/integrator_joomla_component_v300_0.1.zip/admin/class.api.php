<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.0.0.1 ( $Id: class.api.php 373 2012-01-26 18:44:16Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file is the API handler and calls the curl object and returns responses to the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or exit('No direct script access allowed');
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.helper' );
jimport( 'joomla.event.profiler' );
require_once( 'class.curl.php' );
require_once( 'class.debug.php' );
/*-- File Inclusions --*/

/**
 * IntApi class object
 * @version		3.0.0.0.1
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntApi extends JObject
{
	/**
	 * The default Integrator option variables
	 * @access		public
	 * @var			array
	 * @since		3.0.0
	 */
	public $apioptions	= array();
	
	/**
	 * The default Integrator Post variables
	 * @access		public
	 * @var			array
	 * @since		3.0.0
	 */
	public $apipost	= array();
	
	/**
	 * The Integrator URL for the API interface
	 * @access		public
	 * @var			string
	 * @since		3.0.0
	 */
	public $apiurl	= null;
	
	/**
	 * This connections identifier in the Integrator (if known)
	 * @access		public
	 * @var			string
	 * @since		3.0.0
	 */
	public $cnxnid	= null;
	
	/**
	 * Integrator Curl Object
	 * @access		public
	 * @var			object
	 * @since		3.0.0
	 */
	public $curl	= null;
	
	/**
	 * Integrator JParameters Object
	 * @access		public
	 * @var			object
	 * @since		3.0.0
	 */
	public $params	= array();
	
	/**
	 * Catchall for undeclared data
	 * @access		public
	 * @var 		array
	 * @since		3.0.0
	 */
	private $data	= array();
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.0.0.1
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		$this->curl 	=   new IntCurl();
		$params	= & JComponentHelper::getParams( "com_integrator" );
		
		$apiurl = trim( $params->get( "IntegratorUrl" ) );
		
		if (! empty( $apiurl ) ) {
			$uri = new Juri( $apiurl );
			$uri->setPath( rtrim( $uri->getPath(), "/" ) . "/index.php/api/" );
			$this->apiurl	= $uri->toString();
		}
		else {
			$this->apiurl	= $apiurl;
		}
		
		// Build secret code
		$salt		= mt_rand();
		$secret		= $params->get( 'IntegratorSecret' );
		$signature	= base64_encode( hash_hmac( 'sha256', $salt, $secret, true ) );
		
		// Default POST VARIABLES
		$post		= array	(	"apiusername"	=> $params->get( "IntegratorUsername" ),
								"apipassword"	=> $params->get( "IntegratorPassword" ),
								'apisignature'	=> $signature,
								'apisalt'		=> $salt
		);
		$this->apipost	= $post;
		
		// Default CURL OPTIONS
		$options	= array(	'POST'				=> true,
								'TIMEOUT'			=> 30,
								'RETURNTRANSFER'	=> true,
								'POSTFIELDS'		=> array(),
								'FOLLOWLOCATION'	=> false,
								'HEADER'			=> true,
								'HTTPHEADER'		=> array( 'Expect:' ),
								'MAXREDIRS'			=> 5,
								'SSL_VERIFYHOST'	=> false,
								'SSL_VERIFYPEER'	=> false
		);
		$this->apioptions = $options;
		
		$this->cnxnid	= $params->get( "cnxnid" );
		$this->params	= $params;
	}
	
	
	/**
	 * Getter method
	 * @access		public
	 * @version		3.0.0.0.1
	 * @param		string		- $name: the name of the property trying to be gotten
	 * 
	 * @return		mixed value of property or null if not set
	 * @since		3.0.0 
	 */
	public function __get( $name )
	{
		return ( isset( $this->data[$name] ) ? $this->data[$name] : null );
	}
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		3.0.0.0.1
	 * @param		string		- $name: the name of the property to set
	 * @param		mixed		- $value: the value to set the property to
	 * 
	 * @since		3.0.0
	 */
	public function __set( $name, $value )
	{
		$this->data[$name] = $value;
	}
	
	
	/**
	 * Calls up the debug screen from the API
	 * @access		public
	 * @version		3.0.0.0.1
	 * 
	 * @since		3.0.0
	 */
	public function debug()
	{
		echo $this->curl->debug();
	}
	
	
	/**
	 * Grabs a singleton instance of this object
	 * @access		public
	 * @version		3.0.0.0.1
	 * @param		boolean		- $force: if true creates a new object
	 * 
	 * @return		object of IntApi class
	 * @since		3.0.0
	 */
	public function getInstance( $force = false )
	{
		static $instance;
		
		if ( (! is_object( $instance ) ) || ( $force === true ) ) {
			$instance = new self;
		}
		
		return $instance;
	}
	
	
	/**
	 * Retrieves all the pages for all the connections
	 * @access		public
	 * @version		3.0.0.0.1
	 * 
	 * @return		result of api call
	 * @since		3.0.0
	 */
	public function get_allcnxn_pages()
	{
		$post['_c']	= $this->params->get( "cnxnid" );
		
		$url		= $this->apiurl . "get_allcnxn_pages/";
		$response	= $this->_call_api( $url, $post );
		
		// If we have an error, it has been debugged
		if ( $response['result'] == 'error' ) return false;
		
		return $response['data'];
	}
	
	
	/**
	 * Retrieves the correct route for a selected connection / page combination
	 * @access		public
	 * @version		3.0.0.0.1
	 * @param		array		- $post: contains the cnxn_id and page being requested
	 * 
	 * @return		string containing URL
	 * @since		3.0.0
	 */
	public function get_route( $post = array() )
	{
		$post['_c']	= $this->params->get( "cnxnid" );
		
		$url		= $this->apiurl . "get_route/";
		$response	= $this->_call_api( $url, $post );
		
		// If we have an error, it has been debugged
		if ( $response['result'] == 'error' ) return false;
		
		return $response['data']['route'];
	}
	
	
	/**
	 * Retrieves the info from the Integrator for the given user
	 * @access		public
	 * @version		3.0.0.0.1
	 * @param		array		- $post: contains the email address of the user being sought
	 * 
	 * @return		array containing user data
	 * @since		3.0.0
	 */
	public function get_user_info( $post = array() )
	{
		$post['_c']	= $this->params->get( "cnxnid" );
		
		$url		= $this->apiurl . "get_user_info/";
		$response	= $this->_call_api( $url, $post );
		
		return $response['data'];
	}
	
	
	/**
	 * Retrieves connections requiring wrapping
	 * @access		public
	 * @version		3.0.0.0.1
	 * 
	 * @return		result of api call
	 * @since		3.0.0
	 */
	public function get_wrapped_cnxns()
	{
		$post['_c']	= $this->params->get( "cnxnid" );
		
		$url		= $this->apiurl . "get_wrapped_cnxns/";
		$response	= $this->_call_api( $url, $post );
		
		// If we have an error, it has been debugged
		if ( $response['result'] == 'error' ) return false;
		
		return $response['data'];
	}
	
	
	/**
	 * Pings the Integrator with the configuration settings provided to test connection
	 * @access		public
	 * @version		3.0.0.0.1
	 * 
	 * @return		boolean true or string response error
	 * @since		3.0.0
	 */
	public function ping()
	{
		// Ensure we have a URL to set
		if ( empty( $this->apiurl ) ) {
			return JText::_( 'INT_ERROR01' );
		}
		
		$url		= $this->apiurl . "ping/";
		$response	= $this->_call_api( $url );
		
		return ( $response['result'] == 'success' ? true : $response['data'] );
	}
	
	
	/**
	 * Updates the settings on the Integrator with the settings provided by this connection
	 * @access		public
	 * @version		3.0.0.0.1
	 * 
	 * @return		string containing true or error message
	 * @since		3.0.0
	 */
	public function update_settings()
	{
		// Ensure we have a URL to set
		if ( empty( $this->apiurl ) ) {
			return JText::_( 'INT_ERROR01' );
		}
		
		if (! empty( $this->cnxnid ) ) {
			$post['cnxnid']	= $this->cnxnid;
		}
		
		$uri	= clone Juri::getInstance();
		$path	= array_reverse( explode( "/", $uri->getPath() ) );
		
		foreach( $path as $k => $p ) {
			if ( in_array( $p, array( "index.php", "administrator" ) ) ) unset( $path[$k] );
		}
		
		$uri->setPath( "/" . implode( "/", $path ) );
		
		$post['cnxnurl']	= $uri->toString( array( "scheme", "host", "path" ) );
		
		$url		= $this->apiurl . "update_settings/";
		$response	= $this->_call_api( $url, $post );
		
		return $response;
	}
	
	
	/**
	 * Create a new user throughout the Integrator
	 * @access		public
	 * @version		3.0.0.0.1
	 * @param		array		- $post: the user array to send
	 * 
	 * @return		string containing true or error message
	 * @since		3.0.0
	 */
	public function user_create( $post = array() )
	{
		$post['_c']	= $this->params->get( "cnxnid" );
		
		$url		= $this->apiurl . "user_create/";
		$response	= $this->_call_api( $url, $post );
		
		return $response['data'];
	}
	
	
	/**
	 * Calls the Integrator to remove a user
	 * @access		public
	 * @version		3.0.0.0.1
	 * @param		string		- $email: the email address of the user being deleted
	 * 
	 * @return		string containing true or error message
	 * @since		3.0.0
	 */
	public function user_remove( $email )
	{
		$post			= array();
		$post['email']	= $email;
		$post['_c']		= $this->params->get( "cnxnid" );
		
		$url		= $this->apiurl . "user_remove/";
		$response	= $this->_call_api( $url, $post );
		
		return $response['data'];
	}
	
	
	/**
	 * Updates user information across the various Integrator connections
	 * @access		public
	 * @version		3.0.0.0.1
	 * @param		array		- $post: the user array to send
	 * 
	 * @return		string containing true or error message
	 * @since		3.0.0
	 */
	public function user_update( $post = array() )
	{
		$post['_c']	= $this->params->get( "cnxnid" );
		
		$url		= $this->apiurl . "user_update/";
		$response	= $this->_call_api( $url, $post );
		
		return $response['data'];
	}
	
	
	/**
	 * Validate user information prior to creation
	 * @access		public
	 * @version		3.0.0.0.1
	 * @param		array		- $post: the user array to send
	 * 
	 * @return		string containing true or error message
	 * @since		3.0.0
	 */
	public function user_validation_on_create( $post = array() )
	{
		$post['_c']	= $this->params->get( "cnxnid" );
		
		$url		= $this->apiurl . "user_validation_on_create/";
		$response	= $this->_call_api( $url, $post );
		
		return $response['data'];
	}
	
	
	/**
	 * Validates user information across the various Integrator connections
	 * @access		public
	 * @version		3.0.0.0.1
	 * @param		array		- $post: the user array to send
	 * 
	 * @return		string containing true or error message
	 * @since		3.0.0
	 */
	public function user_validation_on_update( $post = array() )
	{
		$post['_c']	= $this->params->get( "cnxnid" );
		
		$url		= $this->apiurl . "user_validation_on_update/";
		$response	= $this->_call_api( $url, $post );
		
		return $response['data'];
	}
	
	
	/**
	 * Wrapper for calling up the API interface
	 * @access		private
	 * @version		3.0.0.0.1
	 * @param		string		- $url: the url to connect to
	 * @param		array		- $post: any additional post variables to send
	 * @param 		array		- $options: any options to set
	 * 
	 * @return		json_decoded response
	 * @since		3.0.0
	 */
	private function _call_api( $url, $post = array(), $options = array() )
	{
		// Final catch
		if ( defined( "INTEGRATOR_API" ) ) return;
		
		// Grab instance of debug
		$debug		= IntDebug :: getInstance();
		
		$post		= array_merge( $this->apipost, $post );
		$options	= array_merge( $this->apioptions, $options );
		
		$result		= $this->curl->simple_post( $url, $post, $options );
		
		if ( $result === false ) {
			// error trapping for debug purposes
			return array( 'result' => 'error', 'data' => $this->curl->has_errors() );
		}
		
		if ( $options['HEADER'] == TRUE ) {
			list( $header, $response ) = explode( "\r\n\r\n", $result, 2 );
		}
		else {
			$response = $result;
		}
		
		$return	= json_decode( $response, true );
		
		if (! isset( $return['result'] ) ) {
			return $response;
		}
		else {
			
			if ( isset( $return['debug'] ) ) {
				$debug->add_array( $return['debug'] );
			}
			
			return $return;
		}
	}
}