<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.3 ( $Id: ajax.php 373 2012-01-26 18:44:16Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the ajax controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Ajax controller 
 * @version		3.0.0.0.3
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Ajax extends MY_Controller
{
	/**
	 * Construtor method
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Checks the database settings in step 2 of the installation
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @since		3.0.0
	 */
	public function check_db()
	{
		$data		= array();
		$server		= $this->input->post('dbhost');
		$username	= $this->input->post('dbuser');
		$password	= $this->input->post('dbpass');
		$port		= $this->input->post('dbport');
		
		$link = @mysql_connect($server . ':' . $port, $username, $password, true );
		
		if (! $link ) {
			$data['success'] = 'false';
			$data['message'] = lang( 'error.db_connect') . mysql_error();
		}
		else {
			$data['success'] = 'true';
			$data['message'] = lang( 'msg.db_connect');
		}
		
		$this->output_json( $data );
	}
	
	
	/**
	 * Validates the database settings in step 5 of the installation
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @since		3.0.0
	 */
	public function validate_db()
	{
		$data		= array();
		$database	= $this->input->post( 'dbname' );
		$dbcreate	= $this->input->post( 'dbmake' );
		$db			= $this->install->test_db_connection();
		
		if (! $db ) {
			$data['success'] = 'false';
			$data['message'] = lang( 'error.db_connect2' );
			return $this->output_json( $data );
		}
		
		// We should be able to create it if the database doesn't exist and we select to create it
		$dbexists	= @mysql_select_db( $database, $db );
		$dbcreate	= $dbcreate == 'true';
		$dbperms	= $this->db_permcheck();
		$dbprefix	= ( $dbexists ? $this->install->test_db_prefix() : true );
		
		
		// DB does exist and we aren't asking to create
		if ( $dbexists && $dbcreate ) {
			$data['success']	= 'false';
			$data['message']	= sprintf( lang( 'error.db_create' ) , $database );
		}
		// DB exists, but prefix conflicts
		else if ( $dbexists && (! $dbprefix ) ) {
			$data['success']	= 'false';
			$data['message']	= sprintf( lang( 'error.db_prefix' ) , $this->input->post( 'dbpref' ), $database );
		} 
		// DB doesn't exist, we asked to craete it but we can't
		else if ( (! $dbexists ) && $dbcreate && (! $dbperms ) ) {
			$data['success']	= 'false';
			$data['message']	= lang( 'error.db_permcheck' );
		}
		// DB doesn't exist, we didn't ask to create it
		else if ( (! $dbexists ) && (! $dbcreate ) ) {
			$data['success']	= 'false';
			$data['message']	= sprintf( lang( 'error.db_nocreate' ), $database );
		}
		// DB doesn't exist, everything else checks out
		else if (! $dbexists ) {
			$data['success']	= 'true';
			$data['message']	= sprintf( lang( 'msg.db_create' ) , $database );
		}
		// DB does exist, everything checks out though
		else {
			$data['success']	= 'true';
			$data['message']	= sprintf( lang( 'msg.db_nocreate' ) , $database );
		}
		
		$this->output_json( $data );
	}
	
	
	/**
	 * Sends the response via JSON
	 * @access		private
	 * @version		3.0.0.0.3
	 * @param		array		- $data: data to output
	 * 
	 * @since		3.0.0
	 */
	private function output_json( $data = array() )
	{
		header('Cache-Control: no-cache, must-revalidate');
		header('Expires: Mon, 7 Mar 1997 05:00:00 GMT');
		header('Content-type: application/json');

		echo json_encode( $data );
	}
}