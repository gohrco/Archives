<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.3 ( $Id: license_lang.php 293 2011-09-13 02:52:16Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the admin controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * LICENSE MANAGEMENT
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['license.index']			= "Integrator Licensing";
		$lang['license.index.desc']		= "Here you can manage your Integrator license directly.";
		
		$lang['label.License']			= "Integrator License";
		$lang['desc.License']			= "Enter the license associated with your product purchase from Go Higher.  Please note that a valid license is required for product usage.  For more information, please visit the Go Higher website at " . anchor( "https://www.gohigheris.com", "https://www.gohigheris.com", array( 'target' => '_blank' ) );
		
		$lang['btn.license']			= "Update License";
		
		$lang['msg.success.licsaved']	= "License Saved!";
		
		