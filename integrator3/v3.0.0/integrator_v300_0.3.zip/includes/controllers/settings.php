<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.3 ( $Id: settings.php 424 2012-03-14 16:52:56Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the settings controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Settings controller of application
 * @version		3.0.0.0.3
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Settings extends Admin_Controller
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::Admin_Controller();
		$this->load->language( 'settings' );
		$this->load->helper( "cnxn" );
	}
	
	
	/**
	 * Allows for modification of the api settings for the Integrator
	 * @access		public
	 * @version		3.0.0.0.3
	 *
	 * @since		3.0.0
	 */
	public function api()
	{
		$model	= & $this->get_model();		// pulls settings_model
		$fields	= & $this->fields_library;	// Grabs fields library for ref
		$fields->load( 'api', true, true );	// Loads API fields up
		
		$this->_handle_task( 'api', array( 'api' ) );		// Callup task handler
		
	}
	
	
	/**
	 * Allows for modification of the settings for the Integrator
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @since		3.0.0
	 */
	public function index()
	{
		$model		= & $this->get_model();
		$fields		= & $this->fields_library;
		$fields->load( 'global', true, true );
		
		$this->_handle_task( 'index', array( 'global', 'system', 'email' ) );
	}
	
	
	/**
	 * Allows for modification of the visual settings for the Integrator
	 * @access		public
	 * @version		3.0.0.0.3
	 *
	 * @since		3.0.0
	 */
	public function registrations()
	{
		$model	= & $this->get_model();		// pulls settings_model
		$fields	= & $this->fields_library;	// Grabs fields library for ref
		$fields->load( 'registration', true, true );	// Loads API fields up
	
		$this->_handle_task( 'registrations', array( 'reggeneral', 'password', 'recaptcha', 'fieldorder' ) );		// Callup task handler
	
	}
	
	
	/**
	 * Allows for modification of the user settings for the Integrator
	 * @access		public
	 * @version		3.0.0.0.3
	 *
	 * @since		3.0.0
	 */
	public function user()
	{
		$model	= & $this->get_model();		// pulls settings_model
		$fields	= & $this->fields_library;	// Grabs fields library for ref
		$fields->load( 'user', true, true );	// Loads API fields up
	
		$this->_handle_task( 'user', array( 'users', 'display' ) );		// Callup task handler
	
	}
	
	
	/**
	* Allows for modification of the visual settings for the Integrator
	* @access		public
	* @version		3.0.0.0.3
	*
	* @since		3.0.0
	*/
	public function visual()
	{
		$model	= & $this->get_model();		// pulls settings_model
		$fields	= & $this->fields_library;	// Grabs fields library for ref
		$fields->load( 'visual', true, true );	// Loads API fields up
	
		$this->_handle_task( 'visual', array( 'visual', 'cache' ) );		// Callup task handler
	
	}
	
	
	/**
	 * Means to assemble the post data in a consistent manner
	 * @access		private
	 * @version		3.0.0.0.3
	 * 
	 * @return		array containing posted data
	 * @since		3.0.0
	 */
	private function _assemble_post()
	{
		$post	= $this->input->post();
		$data	= array();
		foreach( $post['params'] as $key ) {
			foreach ( $key as $k => $v ) {
				$data[$k] = $v;
			}
		}
		return $data;
	}
	
	
	/**
	 * Common method to handle repetitive settings task
	 * @access		private
	 * @version		3.0.0.0.3
	 * @param		string		- $task: contains the task to run
	 * @param		array		- $tabs: which tabs to render
	 * 
	 * @since		3.0.0
	 */
	private function _handle_task( $task = 'index', $tabs = array() )
	{
		$model		= & $this->get_model();
		$fields		= & $this->fields_library;
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == TRUE ) {
			$post	= $this->_assemble_post();
			$model->set_properties( $post );
		}
		
		if ( $this->form_validation->run() == true ) {
			if ( $model->save() ) {
				
				if ( $task == 'index' ) {
					$params	= $this->input->post( 'params' );
					$post	= array( 'debug' => $params['global']['Debug'] );
					
					$apis	= get_apis();
					foreach( $apis as $api ) $api->update_settings( $post );
				}
				
				$this->session->set_flashdata('success_message', lang( 'msg.success.savedsettings' ) );
				
				if ( $this->input->post( 'submit', false ) ) {
					redirect( 'settings/' . $task, 'refresh');
				}
				else {
					redirect( 'admin', 'refresh' );
				}
			}
			else {
				$this->session->set_flashdata( 'error_message', lang( 'msg.error.savedsettings' ) );
			}
		}
		
		// If we are still here, there was a problem or first time through
		$values	= $model->get_properties();
		foreach( $tabs as $tab ) $fields->set_values( array( $tab => $values ) );
		
		$this->data	+= $fields->render();
		$this->data['action']	= 'settings/' . $task;
		
		$this->template
				->set_partial( "body", 'partials/settings' )
				->build( "admin", $this->data );
	}
}