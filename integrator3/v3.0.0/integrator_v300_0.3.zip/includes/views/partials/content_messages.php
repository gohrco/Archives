<?php if ( $alert_message ) : ?>
<div class="alert"><div class="content"><?php echo $alert_message; ?></div></div>
<?php endif; ?>

<?php if ( $info_message ) : ?>
<div class="info"><div class="content"><?php echo $info_message;?></div></div>
<?php endif; ?>

<?php if ( $notice_message ) : ?>
<div class="notice"><div class="content"><?php echo $notice_message;?></div></div>
<?php endif; ?>

<?php if ( $error_message ) : ?>
<div class="error"><div class="content"><?php echo $error_message;?></div></div>
<?php endif; ?>

<?php if ( $success_message ) : ?>
<div class="success"><div class="content"><?php echo $success_message;?></div></div>
<?php endif; ?>
