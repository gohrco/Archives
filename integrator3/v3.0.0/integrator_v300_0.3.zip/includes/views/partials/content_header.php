<h2><?php echo lang( $content_header ); ?></h2>
<h4><?php echo lang( $content_subheader ); ?></h4>
