
<?php foreach( $items as $count => $item ) : ?>

<div class="append-bottom">
	
	<div class="span-23 last">
		
		<div class="star span-2"><?php echo $count; ?></div>
		
		<div class="span-21 last"><h3><?php echo lang( 'help.sbs.' . $count . '.title' ); ?></h3></div>
		
	</div>
	
	<div class="span-23 last"><hr /></div>
	
	<div class="push-2 span-21 last clearfix">
	
	<?php foreach ( $item as $msg ) : ?>
	
	<p>
		
		<?php echo $msg; ?>
		
	</p>
	
	<?php endforeach; ?>
	
	</div>
	
</div>

<?php if ( $count != ( count( $items ) +1 ) ) : ?>
<hr />
<?php endif; ?>

<?php endforeach; ?>
