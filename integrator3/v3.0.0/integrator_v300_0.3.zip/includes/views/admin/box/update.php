<div class="boxer">
	
	<h2>
	
	<?php echo lang( 'update.title' ); ?>
	
	</h2>
	
	<?php if ( $update === false ) : ?>
	
	<div class='content'><?php echo lang( 'update.okay' ); ?></div>
	
	<?php else : ?>
	
	<div class='content'><?php echo sprintf( lang( 'update.needed' ), $update, anchor( 'https://www.gohigheris.com', 'Go Higher' ) ); ?></div>
	
	<?php endif; ?>
	
</div>