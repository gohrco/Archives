<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<!-- Always force latest IE rendering engine & Chrome Frame -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	
	<title><?php echo $template['title']; ?></title>
	<base href="<?php echo base_url(); ?>" />
	<?php echo $template['metadata']; ?>
	
	<!-- Mobile Viewport Fix -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
	
	<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
	
</head>
<body>

<div id="sidebar">
	<?php echo $template['partials']['sidehdr']; ?>
	<?php echo $template['partials']['sidebar']; ?>
	<?php echo $template['partials']['sidelic']; ?>
</div>

<div id="contenthdr">
	<?php echo $template['partials']['content_header']; ?>
</div>


<div id="contentwrapper">
	<div class="container">
		
		<div class="span-24 last" id="content">
			<div class="push-1 span-23 prepend-top last">
				
				<?php echo $template['partials']['content_messages']; ?>
				<p><?php echo $template['partials']['body']; ?></p>
			</div>
		</div>
		
	</div>
</div>

<div id="footer">
	<?php echo $template['partials']['footer']; ?>
</div>

<?php echo $template['partials']['debug']; ?>	

</body>
</html>