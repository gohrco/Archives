<?php 
$icon_enabled = image( "icon16-enabled.png" );
$icon_inactive = image( "icon16-inactive.png" );
$icon_disabled = image( "icon16-disabled.png" ); 
?>
<script>
$(document).ready(function() {
	$('#createUser').click(function() {
		window.location = "<?php echo site_url( 'users/create_user' ); ?>";
	});
});
</script>
<table cellspacing="10" cellpadding="0">
	<thead>
		<tr>
			<th>Username</th>
			<th>Group</th>
			<th>Contact Info</th>
			<th>Active</th>
			<th colspan="2">Actions</th>
		</tr>
	</thead>
	<?php $count = 1;?>
	<tbody>
		<?php foreach ( $users as $user ): ?>
		<tr>
			<td class="span-4<?php echo ( $count&1?"": " even" ) ?>"><?php echo $user['username']; ?></td>
			<td class="span-3<?php echo ( $count&1?"": " even" ) ?>"><?php echo $user['group_description']; ?></td>
			<td class="span-8<?php echo ( $count&1?"": " even" ) ?>">
				<?php echo $user['first_name']?>&nbsp;<?php echo $user['last_name']?><br/>
				<?php echo $user['email'];?>
			</td>
			<td class="span-2 <?php echo ( $count&1?"": " even" ) ?>"><?php echo ( $user['active'] ? $icon_enabled . "&nbsp;" . anchor( "users/verify/deactivate/".$user['id'], $icon_inactive, array( "title" => "Deactivate User" ) ) : anchor( "users/activate/".$user['id'], $icon_inactive, array( "title" => "Activate User" ) ) . "&nbsp;" . $icon_disabled); ?></td>
			<!-- <td class="<?php echo ( $count&1?"": " even" ) ?>"><?php echo anchor( "users/change_password/" . $user['id'], image( "icon16-chpassword.png" ), array( "title" => "Change Password" ) ); ?></td> -->
			<td class="<?php echo ( $count&1?"": " even" ) ?>"><?php echo anchor( "users/edit_user/" . $user['id'], image( "icon16-edituser.png" ), array( "title" => "Edit User" ) ); ?></td>
			<td class="<?php echo ( $count&1?"": " even" ) ?>"><?php echo ( $user['id'] == $admin_user->id ? "" : anchor( "users/verify/delete_user/" . $user['id'], image( "icon16-delete.png" ), array( "title" => "Delete User" ) ) ); ?></td>
		</tr>
		<?php $count++;?>
		<?php endforeach; ?>
	</tbody>
</table>

<?php echo form_button( array( 'name' => 'createUser', 'id' => "createUser", 'type' => 'button', 'content' => "Create A New User" ) ); ?>