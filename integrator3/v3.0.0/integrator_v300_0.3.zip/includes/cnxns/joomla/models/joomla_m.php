<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Joomla Connections Model extended class
 * @version		3.0.0.0.3
 * 
 * @since		3.0.0
 * @author Steven
 */
class Joomla_m extends Cnxns_m
{
	/**
	 * The base url for the connection
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public		$baseurl		= null;
	
	/**
	 * Contains the credentials array from the configuration file for easy reference
	 * @access		public
	 * @since		3.0.0
	 * @var			array
	 */
	public		$credentials	= array();
	
	/**
	 * Stores this connection's cnxnid from the database
	 * @access		public
	 * @since		3.0.0
	 * @var			integer
	 */
	public		$id				= null;	
	
	/**
	 * The determined login action url (for form redirection on logins)
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public		$loginaction	= null;
	
	/**
	 * The determined landing url after logging in (if originating from this connection)
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public		$loginlandingurl = null;
	
	/**
	 * The login landing url when there is an error
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public		$loginlandingerrorurl	= null;
	
	/**
	 * The determined landing url after logging a user out (if originating from this connection)
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public		$logoutlandingurl = null;
	
	/**
	 * The calculated log out url for logging a user out (used to point user to for log out)
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public		$logouturl		= null;
	
	/**
	 * The parameters set for this connection in the database stored here
	 * @access		public
	 * @since		3.0.0
	 * @var			array
	 */
	public		$params			= array();
	
	
	/**
	 * Contains the default CURL options to use for the site rendering
	 * @access		public
	 * @since		3.0.0
	 * @var 		array
	 */
	public		$visualoptions	= array();
	
	
	/**
	 * The URI object used to retrieve the visual site from
	 * @access		public
	 * @since		3.0.0
	 * @var			object
	 */
	public		$visualuri		= null;
	
	
	/**
	 * Contains the default post variables for the site rendering
	 * @access		public
	 * @since		3.0.0
	 * @var			array
	 */
	public		$visualvars		= array();
	
	
	/**
	 * Binds an array of data to the object
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		array		- $data to bind to the object
	 * 
	 * @return		true
	 * @since		3.0.0
	 * @see			Cnxns_m::bind()
	 */
	public function bind( $data = array() )
	{
		return parent::bind( $data );
	}
	
	
	/**
	 * Loads a database result object onto the model
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		object		- $data: contains the data straight from the database result row
	 * 
	 * @return		true on success, false on error
	 * @see Cnxns_m::load()
	 * @since		3.0.0
	 */
	public function load( $data = array() )
	{
		if (! parent::load( $data ) ) return false;
		
		$params	= & Params::getInstance();
		
		// ---BEGIN: Setting Base url
		$url	=   $this->get( 'url', null, 'globals' );
		$uri	= & Uri::getInstance( $url, true );
		$uri->setPath( rtrim( $uri->getPath(), '/' ) . '/' );
		$this->set( 'baseurl', $uri->toString() );
		// ---END:   Setting Base url
		// =====================================
		// ---BEGIN: Setting Login Action Url
		$url	=   $this->get( 'apiurl', null, 'api' );
		$uri	= & Uri::getInstance( $url, true );
		$uri->setPath( rtrim( $uri->getPath(), '/' ) . '/index.php' );
		$uri->setVar( "option", "com_integrator" );
		$uri->setVar( "task", "login" );
		$uri->setScheme( "http" . ( $params->get( "UserSSL" ) ? "s" : "" ) );
		$this->set( "loginaction", $uri->toString() );
		// ---END:   Setting Login Action Url
		// =====================================
		// ---START: Setting Logout URL
		$url	=   $this->get( 'baseurl', null );
		$uri	= & Uri::getInstance( $url, true );
		$uri->setVar( "option", "com_integrator" );
		$uri->setVar( "task", "logout" );
		$uri->setVar( "integrator", "true" );
		$uri->setScheme( "http" . ( $params->get( "UserSSL" ) ? "s" : "" ) );
		$this->set( "logouturl", $uri->toString() );
		// ---END:   Setting Logout URL
		// =====================================
		// ---BEGIN: Setting Login Landing Url
		$loginland	= $this->get( "loginurl", null, "users" );
		
		$lin	= Uri::getInstance( $loginland, true );
		if ( trim( $lin->toString( array( 'host', 'path' ) ) ) == null ) {
			$loginland = null;
		}
		
		if ( $loginland == null ) {
			$uri	= & Uri::getInstance( $this->get( 'baseurl', null ), true );
			$loginland = $uri->toString();
		}
		$this->set( "loginlandingurl", $loginland );
		// ---END:   Setting Login Landing Url
		// =====================================
		// ---START: Setting Logout Langing URL
		$logouturl	= $this->get( "logouturl", null, "users" );
		
		// Test logout url
		$lout = Uri::getInstance( $logouturl, true );
		if ( trim( $lout->toString( array( 'host', 'path' ) ) ) == null ) {
			$logouturl = null;
		}
		
		if ( $logouturl == null ) {
			$uri	= & Uri::getInstance( $url, true );
			$logouturl = $uri->toString();
		}
		$this->set( "logoutlandingurl", $logouturl );
		// ---END:   Setting Logout Langing URL
		// =====================================
		// ---BEGIN: Login Error Landing URL
		$url = $this->get( "loginaction" );
			$uri	= & Uri::getInstance( $url, true );
			$uri->setVar( "task", "loginerror" );
		$this->set( 'loginlandingerrorurl', $uri->toString() );
		// ---END:   Login Error Landing URL
		// ======================================
		// ---BEGIN: Setting Visual uri
		$url = $this->get( "baseurl", null );
		$uri = & Uri::getInstance( $url, true );
		$uri->setPath( rtrim( $uri->getPath(), "/" ) . "/" );
		$uri->setVar( "option", "com_integrator" );
		$uri->setVar( "controller", "default" );
		
		$this->set( "visualuri", $uri );
		// ---END:   Setting API url
		
		return true;
	}
	
	
	/**
	 * Checks the status of a connection(non-PHPdoc)
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		object containing results
	 * @since		3.0.0
	 * @see			Cnxns_m::status_check()
	 */
	public function status_check()
	{
		$data	= parent::status_check();
		$api	= get_api( $this->id );
		$data['ping']	= $api->ping();
		return (object) $data;
	}
}