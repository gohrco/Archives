<?php

/*
|--------------------------------------------------------------------------
| Default name for Connection
|--------------------------------------------------------------------------
| If no name is specified, this name will be used until changed
|--------------------------------------------------------------------------
*/
$config['name']		= 'WHMCS v4.5.1';

/*
|--------------------------------------------------------------------------
| Connection Version
|--------------------------------------------------------------------------
| This reflects what version of the files you are using.  This should not
| be changed.
|--------------------------------------------------------------------------
*/
$config['version']	= '3.0.0.0.3';

/*
|--------------------------------------------------------------------------
| Connection Type
|--------------------------------------------------------------------------
| This should never be changed and should always match the folder name of
| this connection.
|--------------------------------------------------------------------------
*/
$config['type']		= 'whmcs451';

/*
|--------------------------------------------------------------------------
| Credentials Received Array
|--------------------------------------------------------------------------
| This array is used to translate what values are sent by this connection to
| the Integrator when logging in.  The array key (on the left) is what the
| Integrator uses, and the value assigned to it is what the Integrator will
| look for if being sent credentials by this connection.
|--------------------------------------------------------------------------
*/
$config['credentials']['received'] = array(
			'email'		=> 'username',
			'password'	=> 'passwd',
			'remember'	=> 'rememberme',
			'return'	=> 'return'
);

/*
|--------------------------------------------------------------------------
| Credentials Sent Array
|--------------------------------------------------------------------------
| This array is used to translate what values are sent to this connection 
| from the Integrator when logging in.  The array key (on the left) is what
| the Integrator uses, and the value assigned to it is what the Integrator
| will send to this connection for logging in.
|--------------------------------------------------------------------------
*/
$config['credentials']['sent'] = array(
			'email'		=> 'username',
			'password'	=> 'password',
			'remember'	=> 'rememberme',
			'return'	=> 'return'
);

/*
|--------------------------------------------------------------------------
| Credentials Source
|--------------------------------------------------------------------------
| This is an array of possible locations to find the credentials being sent
| to the Integrator.  For security purposes, it should always look for
| credentials in the post variables, as get variables are insecure.
|--------------------------------------------------------------------------
*/
$config['credentials']['source'] = array( 'post' );

/*
|--------------------------------------------------------------------------
| Credentials Required
|--------------------------------------------------------------------------
| This is an array of INTEGRATOR values that are required in order to log a
| user into this connection.  Note that the values are what are stored by the
| Integrator, and not what the connection is sending or expecting.
|--------------------------------------------------------------------------
*/
$config['credentials']['required']	= array( 'email', 'password' );

/*
|--------------------------------------------------------------------------
| API Curl Post Variables Array
|--------------------------------------------------------------------------
| Used to set default values for API Curl Post Variables.  Allows for the
| specification of hard coded values.
|--------------------------------------------------------------------------
*/
$config['apivars']	= array(	'username'		=> null,
								'password'		=> null,
								'responsetype'	=> "json"
);

/*
|--------------------------------------------------------------------------
| API Curl Options Array
|--------------------------------------------------------------------------
| This array contains the default curl options to set for the API curl
| handler.  Note that the prefix CURLOPT_ is prepended to the array key
| at the time of execution.
|--------------------------------------------------------------------------
*/
$config['apioptions']	= array(	'POST'				=> true,
									'TIMEOUT'			=> 30,
									'RETURNTRANSFER'	=> true,
									'POSTFIELDS'		=> array(),
									'FOLLOWLOCATION'	=> false,
									'HEADER'			=> false,
									'HTTPHEADER'		=> array( 'Expect:' ),
									'MAXREDIRS'			=> 5,
									'SSL_VERIFYHOST'	=> false,
									'SSL_VERIFYPEER'	=> false
);

/*
|--------------------------------------------------------------------------
| Visual Curl Post Variables Array
|--------------------------------------------------------------------------
| IS THIS USED?
|--------------------------------------------------------------------------
*/
$config['visualvars']	= array(	);

/*
|--------------------------------------------------------------------------
| Visual Curl Options Array
|--------------------------------------------------------------------------
| This array contains the default curl options to set for the visual curl
| handler.  Note that the prefix CURLOPT_ is prepended to the array key
| at the time of execution.
|--------------------------------------------------------------------------
*/
$config['visualoptions']= array(	);

/*
|--------------------------------------------------------------------------
| User Modification Fields Array
|--------------------------------------------------------------------------
| Used to be able to determine which fields can be edited and what settings
| to use for the translation, labels and validation.
|--------------------------------------------------------------------------
*/
$config['userfields']	= array(
	'newemail' => array(
			'value'			=> 'newemail',
			'order'			=> 10,
			'type'			=> 'text',
			'validation'	=> 'required|valid_email',
			'lang'			=> 'userfields.newemail'
		),
);