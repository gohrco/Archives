<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.3 ( $Id: API_Library.php 424 2012-03-14 16:52:56Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the API library for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * API Library class
 * @version		3.0.0.0.3
 * 
 * @since		3.0.0
 * @author		Steven
 */
class API_Library
{
	/**
	 * Paramters array
	 * @access		public
	 * @since		3.0.0
	 * @var			array
	 */
	public	$_params		= array();
	
	/**
	 * Container for unknown items to set / get
	 * @access		public
	 * @since		3.0.0
	 * @var			array
	 */
	public	$_properties	= array();
	
	/**
	 * Contains any errors encountered
	 * @access		public
	 * @since		3.0.0
	 * @var			array
	 */
	public	$_errors		= array();
	
	
	/**
	 * Constructor Method
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		array		- $options: to load
	 * 
	 * @since		3.0.0
	 */
	public function __construct( $options = array() )
	{	
		if (! empty( $options ) ) {
			$this->load( $options );
		}
	}
	
	
	/**
	 * Object Getter Method
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $name: the name of the item to get
	 * 
	 * @return		mixed the value of the item to get
	 * @since		3.0.0
	 */
	public function __get( $name )
	{
		if ( isset( $this->_params[$name] ) ) {
			return $this->_params[$name];
		}
		return $this->_properties[$name];
	}
	
	
	/**
	 * Object Setter Method
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $name: the name of the item to set
	 * @param		mixed		- $value: the value to set
	 * 
	 * @since		3.0.0
	 */
	public function __set( $name, $value )
	{
		if ( isset( $this->_params[$name] ) ) {
			$this->_params[$name] = $value;
			return;
		}
		$this->_properties[$name] = $value;
	}
	
	
	/**
	 * Getter method
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $name: the name of the item to get
	 * @param		mixed		- $default: the default if not set to return
	 * @param		string		- $type: the type of item to get (local or params)
	 * 
	 * @return		mixed value requested
	 * @since		3.0.0
	 */
	public function get( $name, $default = null, $type = 'local' )
	{
		switch ( $type ) {
			case 'local':
				return isset( $this->$name ) ? $this->$name : $default;
				break;
			case 'params':
			default:
				return ( isset( $this->_params[$name] ) ? $this->_params[$name] : $default );
		}
	}
	
	
	/**
	 * Gets the common user data from the id'd cnxn library
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		array of data
	 * @since		3.0.0
	 */
	public function get_data()
	{
		$cnxnlib = get_cnxn_library( $this->id );
		return $cnxnlib->cuser_retrieve();
	}
	
	
	/**
	 * Retrieves the first error found
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		string or false on none
	 * @since		3.0.0
	 */
	public function get_error()
	{
		return ( isset( $this->_errors[0] ) ? $this->_errors[0] : false );
	}
	
	
	/**
	* Retrieves the pages to make available for I3 connection
	* @access		public
	* @version		3.0.0.0.3
	*
	* @return		array containing the pages on this connection
	* @since		3.0.0 (0.1)
	*/
	public function get_pages()
	{
		$data	= array();
		$data['register/index'] = lang( 'api.registration' );
		
		return $data;
	}
	
	
	/**
	 * Gets a parameter from the id'd cnxn
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $param: the item tog et
	 * @param		string		- $type: the type of param to get (users, visual, etc)
	 * 
	 * @return		mixed requested value
	 * @since		3.0.0
	 */
	public function get_param( $param, $type = 'users' )
	{
		$cnxn = cnxn( $this->id );
		return $cnxn->get( $param, false, $type );
	}
	
	
	/**
	 * Loads parameters onto object
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		array		- $options:  options to load
	 * 
	 * @since		3.0.0
	 */
	public function load( $options )
	{
		foreach( $options as $k => $v ) $this->set( $k, $v );
		
		// =====================================
		// ---BEGIN: Check for parameters
		if (! isset( $options['params']['globals'] ) ) {
			return;
		}
		// ---END:   Check for parameters
		// =====================================
		// ---BEGIN: Setting base url
		$url	=   $options['params']['globals']['url']['value'];
		$uri	= & Uri::getInstance( $url, true );
		$uri->setPath( rtrim( $uri->getPath(), '/' ) . '/' );
		$this->set( 'baseurl', $uri->toString(), 'params' );
		// ---END:   Setting base url
		// =====================================
		// ---BEGIN: Set GLOBAL API variables
		$apipost	= $this->get( "apipost" );
			// Do something if need be
		$this->set( "apipost", $apipost );
		// ---END:   Set GLOBAL API variables
		// =====================================
	}
	
	
	/**
	 * Placed data into the Common User object
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		array		- $data: the data sent back by cnxn to place into common user
	 * 
	 * @since		3.0.0
	 */
	public function place_data( $data = array() )
	{
		$cnxnlib = get_cnxn_library( $this->id );
		$cnxnlib->cuser_place( $data );
	}
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $name: the name of the variable to set
	 * @param		mixed		- $value: the value to set
	 * @param		string		- $type: the type (local to the object or params)
	 * 
	 * @since		3.0.0
	 */
	public function set( $name, $value, $type = 'local' )
	{
		switch( $type ) {
			case 'local':
				// Handle parameters
				if ( $name == 'params' ) {
					if (! isset( $value['api'] ) ) return;
					foreach( $value['api'] as $k => $v ) {
						$this->set( $k, $v['value'], 'params' );
					}
					return;
				}
				// Force active as boolean
				if ( $name == 'active' ) {
					$this->active = (bool) $value;
					return;
				}
				// Set remaining items
				$this->$name = $value;
				break;
			case 'params':
			default:
				$this->_params[$name] = $value;
				break;
		}
	}
	
	
	/**
	 * Sets an error response in the Common User object for API calls
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		mixed		- $msg: the response to set
	 * 
	 * @since		3.0.0
	 */
	public function set_error( $msg ) {
		$cuser = & Cuser::getInstance();
		$cuser->set( 'error', $msg );
		$this->_errors[]	= $msg;
	}
	
	
	/**
	 * Updates a setting on the cnxn
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		array		- $post: contains the settings array to update
	 * 
	 * @return		true
	 * @since		3.0.0 (0.3)
	 */
	public function update_settings( $post = array() )
	{
		return true;
	}
	
	
	/**
	 * Filters settings to ensure only certain ones are set
	 * @access		protected
	 * @version		3.0.0.0.3
	 * @param		array		- $post: contains the settings array to update
	 *
	 * @return		array or false on empty
	 * @since		3.0.0 (0.3)
	*/
	protected function _filter_setting_array( $post = array() )
	{
		$check	= array( 'debug' );
		$data	= array();
		
		foreach( $check as $ch ) {
			if ( isset( $post[$ch] ) ) {
				$data[$ch] = $post[$ch];
			}
		}
		
		if ( empty( $data ) ) return false;
		else return $data;
	}
	
	
	/**
	 * Calls the API connection, called by child classes after assembling api items
	 * @access		protected
	 * @version		3.0.0.0.3
	 * @param 		array		- $api_post: contains any post variables
	 * @param 		string		- $api_url: the url to connect to
	 * @param 		array		- $api_options: any curl options to set
	 * 
	 * @return		result or false on error
	 * @since		3.0.0
	 */
	protected function _call_api( $post, $url, $options )
	{
		// Initialize Objects
		$CI	= & get_instance();
		
		// Grab Cookies!
		$options['COOKIE'] = $this->_grab_cookies();
		
		// Execute CURL request
		$result	= $CI->curl->simple_post( $url, $post, $options );
		
		// Test result
		if ( $result == false ) {
			// Indicates a CURL problem
			debug_error( $CI->curl->error_string, false );
			return false;
		}
		
		// Check options and handle response appropriately
		if ( ( $options['HEADER'] == TRUE ) && ( $options['RETURNTRANSFER'] == TRUE ) ) {
			list( $header, $data ) = explode( "\r\n\r\n", $result, 2 );
		}
		else {
			$header	= null;
			$data	= $result;
		}
		
		// Check CURL response code in case we are redirected
		$code = $CI->curl->info['http_code'];
		
		// See if code is a 301, 302 or 303
		if ( $code > 200  && $code < 400 ) {
			
			// Try to find the redirection in response header and try again
			if ( $redirect = $this->_findRedirect( $header ) ) {
				$data = self::_call_api( $post, $redirect, $options );
			}
		}
		else {
			// Handle cookies
			if ( $cookie = $this->_find_api_cookies( $header ) ) {
				$this->_write_cookies( $cookie );
			}
		}
		
		return $data;
	}
	
	
	/**
	 * Used to make XML-RPC calls to a remote API interface
	 * @access		protected
	 * @version		3.0.0.0.3
	 * @param		string		- $url: the url of the api interface
	 * @param		string		- $method: the remote method to call
	 * @param		array		- $post: various values using XML-RPC set
	 * @param		integer		- $port: the port to call (always 80, but for future use)
	 * 
	 * @return		array containing results
	 * @since		3.0.0
	 */
	protected function _call_xmlrpc( $url, $method, $post, $port )
	{
		$param	= & Params::getInstance();
		$debug	=   ( $param->get( 'Debug', false ) && (! defined( 'INTEGRATOR_API' ) ) ) ;
		$CI		= & get_instance();
		$CI->load->library( 'xmlrpc' );
		
		$CI->xmlrpc->server( $url, $port );
		$CI->xmlrpc->method( $method );
		$CI->xmlrpc->request( $post );
		$CI->xmlrpc->set_debug( $debug );
		
		// Output buffering in case we have debug turned on
		ob_start();
			
			// Send the request
			$result = $CI->xmlrpc->send_request();
			
			// Test the request and grab output buffer for debug if necessary
			if (! $result ) {
				$debug	= ( $debug === true ? ob_get_contents() : false );
			}
			
		ob_end_clean();
		
		if ( ! $result ) {
			if ( $debug ) {
				_e( $method );
				_e( $post );
				_e( $debug );
				_e( $CI->xmlrpc );
				_e( 'Error in send request API Library', true );
			}
			return array( 'result' => 'error', 'data' => $CI->xmlrpc->display_error() );
		}
		
		return array( 'result' => 'success', 'data' => $CI->xmlrpc->display_response() );
	}
	
	
	/**
	 * Takes the header and detects the cookies, setting the most current cookie in the file
	 * @access		protected
	 * @version		3.0.0.0.3
	 * @param		string		- $header: contains the header data returned by the API
	 * 
	 * @since		3.0.0
	 */
	protected function _find_api_cookies( $header )
	{
		preg_match_all('/^Set-Cookie: (.*?);/m', $header, $cookies);
		$data	= end( $cookies[1] );
		
		if ( empty( $data ) ) {
			// Log / debug errors
			log_message( 'debug', 'API_library (line ' . __LINE__ . '): Unable to find a cookie in header' );
			debug( 'api.findapicookie.nocookie', 'debug' );
			return false;
		}
	}
	
	
	/**
	 * Locates the redirect url in the header
	 * @access private
	 * @param  string		Contains header data
	 * 
	 * @return Redirection URL or false on failure
	 * @since  1.5.3
	 */
	private function _findRedirect($data)
	{
		list($header) = explode("\r\n\r\n", $data, 2);
		$matches = array();
		preg_match('/(Location:|URI:)(.*?)\n/', $header, $matches);
		$url = trim(array_pop($matches));
		$url_parsed = parse_url($url);
		if (isset($url_parsed)) {
			return $url;
		} else {
			return false;
		}
	}
	
	
	/**
	 * Grabs the API cookies being sent to the API connection ( so we don't reconnect 20 million times)
	 * @access		private
	 * @version		3.0.0.0.3
	 * 
	 * @return		string containing cookie or null if empty
	 * @since		3.0.0
	 */
	private function _grab_cookies()
	{
		$params	= & Params :: getInstance();
		$path	=   $params->get( 'TmpDir' ) . DIRECTORY_SEPARATOR . $this->id . '_apivariables.tmp';
		$data	=   null;
		
		if (! is_readable( $path ) ) {
			// Log / debug errors
			log_message( 'debug', 'API_library (line ' . __LINE__ . '): Unable to read file ' . $path );
			debug( 'api.grabcookies.noread', 'debug' );
			return null;
		}
		
		if ( ( $cookies = read_file( $path ) ) === false ) {
			// Log / debug errors
			log_message( 'debug', 'API_library (line ' . __LINE__ . '): Unable to open file ' . $path );
			debug( 'api.grabcookies.noopen', 'debug' );
			return null;
		}
		
		if ( empty( $cookies ) ) {
			// Log / debug errors
			log_message( 'debug', 'API_library (line ' . __LINE__ . '): Cookie file ' . $path . ' is empty.');
			debug( 'api.grabcookies.empty', 'debug' );
			return null;
		}
		
		$data = rtrim( $cookies );
		
		return $data;
	}
	
	
	/**
	 * Writes cookie data to a cookie file
	 * @access		private
	 * @version		3.0.0.0.3
	 * @param		string		- $data: contains the cookie data to write
	 * 
	 * @return		boolean
	 * @since		3.0.0 (0.1)
	 */
	private function _write_cookies( $data )
	{
		$params	= & Params :: getInstance();
		$path	= $params->get( 'TmpDir' ) . DIRECTORY_SEPARATOR . $this->id . '_apivariables.tmp';
		
		if ( ( $result = write_file( $path, $data ) ) === false ) {
			// Log / debug errors
			log_message( 'debug', 'API_library (line ' . __LINE__ . '): Unable to write to ' . $path );
			debug( 'api.writecookies.error', 'debug' );
			return false;
		}
		
		return true;
	}
}