<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Rssparser_Library
{
	public	$cache_dir			= null;
	public	$cache_life			= 2;
	public	$channel_data		= array();
	public	$current_feed		= array(	'title'	=> null, 'description' => null, 'link' => null );
	public	$data				= array();
	public	$feed_unavailable	= true;
	public	$feed_uri			= null;
	public	$write_cache_flag	= false;
	
	
	public function __construct( $params )
	{
		$CI = & get_instance();
		$this->cache_dir	= ( $CI->config->item( 'cache_path' ) == '' ) ? BASEPATH . 'cache/' : $CI->config->item( 'cache_path' );
		
		$this->cache_life	= ( isset( $params['life'] ) ? $params['life'] : 2 );
		
		if (! isset( $params['url'] ) ) {
			show_error( 'no url for RSS parsing' );
			return;
		}
		
		$this->feed_uri		= $params['url'];
		
		$this->parse();
	}
	
	
	public function parse()
	{
		$CI = & get_instance();
		
		if ($this->cache_life != 0) {
			$filename = 'rss_Parse_'.md5( $this->feed_uri );
			
			if ( $data = $CI->cache->get( $filename ) ) {
			//is there a cache file ?
//			if ( file_exists( $filename ) ) {
				
				$this->data = $data;
				return true;
			}
			
			$this->write_cache_flag = true;
		}


		//Parse the document
		if ( ( $rawFeed	= @file_get_contents( $this->feed_uri ) ) === false ) {
			// Failed to parse URI so return
			return false;
		}
		
		$xml		= new SimpleXmlElement( $rawFeed );
		
		//Assign the channel data
		$this->channel_data['title']		= $xml->channel->title;
		$this->channel_data['description']	= $xml->channel->description;
		
		//Build the item array
		foreach ($xml->channel->item as $item) {
			$data = array();
			$data['title']			= (string) $item->title;
			$data['description']	= preg_replace( "`\n`", "", (string) $item->description );
			$data['pubDate']		= strtotime( (string) $item->pubDate );
			$data['link']			= (string) $item->link;
			$this->data[]			= (object) $data;
		}
		
		//Do we need to write the cache file?
		if ($this->write_cache_flag) {
			$CI->cache->save( $filename, $data, ( $this->cache_life * 60 ) );
			
//			if ( ! $fp = @fopen($filename, 'wb'))
//			{
//				echo "ERROR";
//				log_message('error', "Unable to write cache file: ".$cache_path);
//				return;
//			}
//			flock($fp, LOCK_EX);
//			fwrite($fp, serialize($this->data));
//			flock($fp, LOCK_UN);
//			fclose($fp);
		}
		return true;
	}
	
	
	public function getFeed( $num )
	{
		$c = 0;
		$return = array();
		foreach($this->data AS $item) {
			$return[] = $item;
			$c++;
			if($c == $num) break;
		}
		return $return;
	}
	
	
	public function & getChannelData()
	{
		$flag = false;
		if(!empty($this->channel_data)) {
			return $this->channel_data;
		} else {
			return $flag;
		}
	}
	
	
	public function errorInResponse() {
	   return $this->feed_unavailable;
	}

}

?>  