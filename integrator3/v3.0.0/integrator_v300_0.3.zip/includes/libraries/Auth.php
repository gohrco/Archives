<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.3 ( $Id: Auth.php 373 2012-01-26 18:44:16Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the authentication library for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Authentication Library
 * @version		3.0.0.0.3
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Auth
{
	/**
	 * The field that identifies a user
	 * @access		protected
	 * @since		3.0.0
	 * @var			string
	 */
	protected $identity	= 'username';
	
	/**
	 * The message results
	 * @access		protected
	 * @since		3.0.0
	 * @var			array
	 */
	protected $messages		= array();
	
	/**
	 * The error results
	 * @access		protected
	 * @since		3.0.0
	 * @var			array
	 */
	protected $errors		= array();
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		$ci = & $this->ci();
		$ci->load->library('email');
		$ci->load->library('session');
		$ci->load->language( 'auth' );
		$ci->load->model( 'auth_model' );
		$ci->load->helper('cookie');

		$this->messages = array();
		$this->errors = array();
		$this->message_start_delimiter = '<p>';
		$this->message_end_delimiter   = '</p>';
		$this->error_start_delimiter   = '<p>';
		$this->error_end_delimiter     = '</p>';

		//auto-login the user if they are remembered
		if (! $this->logged_in() && get_cookie( 'identity' ) && get_cookie( 'remember_code' ) ) {
			$ci->auth = $this;
			$ci->auth_model->login_remembered_user();
		}
	}
	
	
	/**
	 * Caller method
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $method: the unset method being called
	 * @param		array		- $arguments: passed arguments to the unset method
	 * 
	 * @return		result of user function
	 * @throws		Exception
	 * @since		3.0.0
	 */
	public function __call($method, $arguments)
	{
		if (! method_exists( $this->ci()->auth_model, $method) ) {
			throw new Exception( 'Undefined method Auth::' . $method . '() called' );
		}
		
		return call_user_func_array( array( $this->ci()->auth_model, $method), $arguments );
	}
	
	
	/**
	 * Activate a user
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		integer		- $id: the user id to activate
	 * @param		string		- $code: activation code or false
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function activate( $id, $code = false )
	{
		if ( $this->ci()->auth_model->activate( $id, $code ) ) {
			$this->set_message( 'msg.success.activate' );
			return true;
		}
		
		$this->set_error( 'msg.error.activate' );
		return false;
	}
	
	
	/**
	 * Deactivate a user
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		integer		- $id: the user id to activate
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function deactivate( $id )
	{
		if ( $this->ci()->auth_model->deactivate( $id ) ) {
			$this->set_message( 'msg.success.deactivate' );
			return true;
		}
		
		$this->set_error('msg.error.deactivate');
		return false;
	}
	
	
	/**
	 * Change a password for a user
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		$identity: the username or email of the user
	 * @param		string		$old: the old password
	 * @param		string		$new: the new password
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function change_password( $identity, $old, $new )
	{
		if ( $this->ci()->auth_model->change_password( $identity, $old, $new ) ) {
			$this->set_message('msg.success.pwchange');
			return true;
		}
		
		$this->set_error('msg.error.pwchange');
		return false;
	}
	
	
	/**
	 * Handle a forgotten password request
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		$identity: the username or email of the user
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function forgotten_password( $identity )
	{
		if ( $this->ci()->auth_model->forgotten_password( $identity ) ) {
			$user = $this->get_users_by_email( $identity );
			$user = $user[0];
			
			$data = array(
				'identity'		=> $user->{$this->identity},
				'forgotten_password_code' => $user->forgotten_password_code
			);
			
			if ( $this->ci()->notify->send( 'forgot_password', $data, $user->email ) ) {
				$this->set_message( 'msg.success.pwforgot' );
				return true;
			}
			else {
				$this->set_error('msg.error.pwforgot');
				return false;
			}
		}
		else {
			$this->set_error('msg.error.pwforgot');
			return false;
		}
	}

	/**
	 * Complete a forgotten password request
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		$code: the confirmation code sent to the user
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function forgotten_password_complete( $code )
	{
		$identity = $this->identity;
		$profile  = $this->ci()->auth_model->profile( $code, true );
		
		if (! is_object( $profile ) ) {
			$this->set_error( 'msg.error.pwchange' );
			return false;
		}
		
		$new_password = $this->ci()->auth_model->forgotten_password_complete( $code, $profile->salt );
		
		if ( $new_password ) {
			$data = array(
				'identity'     => $profile->{$identity},
				'new_password' => $new_password
			);
			
			if ( $this->ci()->notify->send( 'new_password', $data, $profile->email ) ) {
				$this->set_message( 'msg.success.pwchange' );
				return true;
			}
			else {
				$this->set_error( 'msg.error.pwchange' );
				return false;
			}
		}
		
		$this->set_error( 'msg.error.pwchange' );
		return false;
	}
	
	
	/**
	 * Register a user
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $username: the username to register
	 * @param		string		- $password: the password to use
	 * @param		string		- $email: the email to register
	 * @param		array		- $additional_data: array of other data or false
	 * @param		string		- $group_name: if known, or false to find it
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function register( $username, $password, $email, $additional_data, $group_name = false )
	{
		$id = $this->ci()->auth_model->register( $username, $password, $email, $additional_data, $group_name );
		
		if ( $id !== false ) {
			$this->set_message( 'msg.success.acctcreated' );
			return $id;
		}
		else {
			$this->set_error('msg.error.acctcreated');
			return false;
		}
	}
	
	
	/**
	 * Log a user in
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $identity: username or email of user
	 * @param		string		- $password: password supplied
	 * @param		boolean		- $remember: set the remember cookie
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function login( $identity, $password, $remember = false )
	{
		if ( $this->ci()->auth_model->login( $identity, $password, $remember ) ) {
			$this->set_message( 'msg.success.login' );
			return true;
		}
		
		$this->set_error( 'msg.error.login' );
		return false;
	}
	
	
	/**
	 * Log a user out
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function logout()
	{
		$identity = $this->identity;
		$this->ci()->session->unset_userdata($identity);
		$this->ci()->session->unset_userdata( 'group' );
		$this->ci()->session->unset_userdata( 'id' );
		$this->ci()->session->unset_userdata( 'user_id' );
		
		//delete the remember me cookies if they exist
		if ( get_cookie( 'identity' ) ) {
			delete_cookie( 'identity' );
		}
		
		if ( get_cookie( 'remember_code' ) ) {
			delete_cookie( 'remember_code' );
		}
		
		$this->ci()->session->sess_destroy();
		
		$this->set_message( 'msg.success.logout' );
		return true;
	}
	
	
	/**
	 * Checks the log in status of a user
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function logged_in()
	{
		$identity = $this->identity;
		return (bool) $this->ci()->session->userdata( $identity );
	}
	
	
	/**
	 * Checks the permission status of the logged in user
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function is_admin()
	{
		$user_group  = $this->ci()->session->userdata( 'group' );
		return $user_group == 'admin';
	}
	
	
	/**
	 * Checks to see if the user belongs to a specific group
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		mixed		- $check_group: string of the group name or array of groups to find against
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function is_group( $check_group )
	{
		$user_group = $this->ci()->session->userdata( 'group' );
		
		if( is_array( $check_group ) ) {
			return in_array( $user_group, $check_group );
		}
		
		return $user_group == $check_group;
	}
	
	
	/**
	 * Retrieves the profile of the user
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function profile()
	{
		$identity = $this->ci->session->userdata( $this->identity );
		return $this->ci()->auth_model->profile( $identity );
	}
	
	
	/**
	 * Gets users
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $group_name: the group to get users from
	 * @param		integer		- $limit: the max number of records to get
	 * @param		integer		- $offset: the start record
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_users( $group_name = false, $limit = NULL, $offset = NULL )
	{
		return $this->ci()->auth_model->get_users( $group_name, $limit, $offset )->result();
	}
	
	
	/**
	 * Gets a count of users
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $group_name: the group to get users from
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_users_count( $group_name = false )
	{
		return $this->ci()->auth_model->get_users_count( $group_name );
	}
	
	
	/**
	 * Get array of users
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $group_name: the group to get users from
	 * @param		integer		- $limit: the max number of records to get
	 * @param		integer		- $offset: the start record
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_users_array( $group_name = false, $limit = NULL, $offset = NULL )
	{
		return $this->ci()->auth_model->get_users( $group_name, $limit, $offset )->result_array();
	}
	
	
	/**
	 * Gets the newest users
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		integer		- $limit: the max number of records to get
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_newest_users( $limit = 10 )
	{
		return $this->ci()->auth_model->get_newest_users( $limit )->result();
	}
	
	
	/**
	 * Gets an array of the newest users
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		integer		- $limit: the max number of records to get
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_newest_users_array( $limit = 10 )
	{
		return $this->ci()->auth_model->get_newest_users( $limit )->result_array();
	}
	
	
	/**
	 * Gets the active users
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $group_name: the group to get users from
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_active_users( $group_name = false )
	{
		return $this->ci()->auth_model->get_active_users( $group_name )->result();
	}
	
	
	/**
	 * Gets an array of active users
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $group_name: the group to get users from
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_active_users_array( $group_name = false )
	{
		return $this->ci()->auth_model->get_active_users( $group_name )->result_array();
	}
	
	
	/**
	 * Gets the inactive users
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $group_name: the group to get users from
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_inactive_users( $group_name = false )
	{
		return $this->ci()->auth_model->get_inactive_users( $group_name )->result();
	}
	
	
	/**
	 * Gets an array of inactive users
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $group_name: the group to get users from
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_inactive_users_array( $group_name = false )
	{
		return $this->ci()->auth_model->get_inactive_users( $group_name )->result_array();
	}
	
	
	/**
	 * Gets a user by id
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		integer		- $id: the user id to get
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_user( $id = false )
	{
		return $this->ci()->auth_model->get_user( $id )->row();
	}
	
	
	/**
	 * Gets a user by email address
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $email: the email address to retrieve user for
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_user_by_email( $email )
	{
		return $this->ci()->auth_model->get_user_by_email( $email )->row();
	}
	
	
	/**
	 * Gets a result of users by email
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $email: the email address to retrieve user for
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_users_by_email( $email )
	{
		return $this->ci()->auth_model->get_users_by_email( $email )->result();
	}
	
	
	/**
	 * Gets a user by username
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $username: the username of the user to get
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_user_by_username( $username )
	{
		return $this->ci()->auth_model->get_user_by_username( $username )->row();
	}
	
	
	/**
	 * Gets a result of users by username
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $username: the username of the user to get
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_users_by_username( $username )
	{
		return $this->ci()->auth_model->get_users_by_username( $username )->result();
	}
	
	
	/**
	 * Get user by identity
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $identity: the user identity to get
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_user_by_identity( $identity )
	{
		return $this->ci()->auth_model->get_user_by_identity( $identity )->row();
	}
	
	
	/**
	 * Get user array
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		integer		- $id: the user id to get
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_user_array( $id = false )
	{
		return $this->ci()->auth_model->get_user( $id )->row_array();
	}
	
	
	/**
	 * Update a user
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		integer		- $id: the user id to update
	 * @param		array		- $data: items to update
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function update_user( $id, $data )
	{
		if ( $this->ci()->auth_model->update_user( $id, $data ) ) {
			$this->set_message( 'msg.success.update' );
			return true;
		}
		
		$this->set_error( 'msg.error.update' );
		return false;
	}


	/**
	 * Deletes a user
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		integer		- $id: the user id to delete
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function delete_user( $id )
	{
		if ( $this->ci()->auth_model->delete_user( $id ) ) {
			$this->set_message( 'msg.success.delete' );
			return true;
		}
		
		$this->set_error( 'msg.error.delete' );
		return false;
	}
	
	
	/**
	 * Allows for extra where fields (unusued)
	 */
	public function extra_where()
	{
		$where =& func_get_args();
		$this->_extra_where = count($where) == 1 ? $where[0] : array($where[0] => $where[1]);
	}
	
	
	/**
	 * Sets extra where fields (unused)
	 */
	public function extra_set()
	{
		$set =& func_get_args();
		$this->_extra_set = count($set) == 1 ? $set[0] : array($set[0] => $set[1]);
	}
	
	
	/**
	 * Sets message delimiters
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $start_delimiter: the starting delimiter
	 * @param		string		- $end_delimiter: the ending delimiter
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function set_message_delimiters( $start_delimiter, $end_delimiter )
	{
		$this->message_start_delimiter = $start_delimiter;
		$this->message_end_delimiter   = $end_delimiter;
		return true;
	}
	
	
	/**
	 * Sets error delimiters
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $start_delimiter: the starting delimiter
	 * @param		string		- $end_delimiter: the ending delimiter
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function set_error_delimiters( $start_delimiter, $end_delimiter )
	{
		$this->error_start_delimiter = $start_delimiter;
		$this->error_end_delimiter   = $end_delimiter;
		return true;
	}

	
	/**
	 * Sets a message to the array
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $message: message to set
	 * 
	 * @return		string
	 * @since		3.0.0
	 */
	public function set_message( $message )
	{
		$this->messages[] = $message;
		return $message;
	}
	
	
	/**
	 * Retrieves the messages from the array
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		string
	 * @since		3.0.0
	 */
	public function messages()
	{
		$_output = '';
		foreach ( $this->messages as $message ) {
			$_output .= $this->message_start_delimiter . $this->ci()->lang->line($message) . $this->message_end_delimiter;
		}
		
		return $_output;
	}

	
	/**
	 * Sets an error message
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $error: the error message to set
	 * 
	 * @return		string
	 * @since		3.0.0
	 */
	public function set_error( $error )
	{
		$this->errors[] = $error;
		return $error;
	}
	
	
	/**
	 * Gets the errors from the error array
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		string
	 * @since		3.0.0
	 */
	public function errors()
	{
		$_output = '';
		foreach ( $this->errors as $error ) {
			$_output .= $this->error_start_delimiter . $this->ci->lang->line($error) . $this->error_end_delimiter;
		}
		
		return $_output;
	}
	
	
	/**
	 * Single location for grabbing CI object
	 * @access		private
	 * @version		3.0.0.0.3
	 * 
	 * @return		object
	 * @since		3.0.0
	 */
	private function ci()
	{
		static $ci;
		if ( $ci == null ) {
			$ci =& get_instance();
		}
		return $ci;
	}
}