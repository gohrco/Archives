<?php

/* SECURITY CHECKPOINT */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Base Admin Controller for all configuration and administration controllers
 * @version		3.0.0.0.3
 * 
 * @since		3.0.0
 * @author		Steven
 */
class Admin_Controller extends MY_Controller
{
	/**
	 * Construtor for this class (called directly by siblings)
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @since		3.0.0
	 */
	public function Admin_Controller()
	{
		parent::__construct();
		
		// Start Benchmark Point
		$this->benchmark->mark('admin_controller_start');
		
		// Load session and form validation libraries
		$this->load->library('session');
		log_message('debug', 'Session Loaded in Admin Controller' );
		
		$this->load->library('form_validation');
		$this->load->library( 'fields_library' );
		//$this->form_validation->set_error_delimiters( '<p><span class="ui-icon ui-icon-alert" style="float: left; margin-right: 0.3em;"></span><strong>Alert:</strong>  ', '</p>' );
		//$this->form_validation->set_error_delimiters();
		// Load the template library
		$this->load->library('template');
		$this->load->helper( "html" );
		$this->load->helper( "icon" );
		
		$this->load->language( 'globals' );
		
		if ( ! self::_check_access()) {
			show_error($this->lang->line('admin_access_denied'));
			exit;
		}
		
		if ( ! parent::_check_license() ) {
			$this->session->set_flashdata('error_message', lang( 'licensing.error' ) );
			redirect( 'license/index', 'refresh' );
			exit;
		}
		
		$params	= & Params::getInstance();
		
		// Use $admin_user in templates to avoid collissions
		$this->data['admin_user'] = $this->user;
		$this->data['infoMsg']	= $this->session->flashdata('infoMsg');
		$this->data['error_message']	= null;
		$this->data['success_message']	= null;
		$this->data['alert_message']	= null;
		$this->data['info_message']		= null;
		$this->data['notice_message']	= null;
		$this->data['menu_cnxns']		= null;
		
		$pcs = explode( "-", $params->get( 'License' ) );
		$this->data['licensekey']		= array( 'key' => $params->get( 'License' ), 'type' => $pcs[0] );
		$this->data['license']			= $GLOBALS['license'];
		
		$version = $params->get( 'Version' );
		$pcs = explode( '.', $version );
		$sub	= array_pop( $pcs );
		$sub	= array_pop( $pcs ) . '.' . $sub;
		$main	= implode( '.', $pcs );
		
		$this->data['version']			= $main . ' (' . $sub . ')';
		
		$this->data['guest']			= $this->_is_public();
		
		// ADMIN USERS ONLY
		if (! $this->_is_public() ) {
			$this->data['menu_cnxns']	= $this->_set_connection_menu();
			$this->data['nav']	= $this->_build_menu();
		}
		else {
			$this->template->append_metadata( css( 'login.css' ) );
		}
		
		$this->template
					->append_metadata( blueprint( "screen.css" ) )
					->append_metadata( blueprint( "print.css", "media" ) )
					->append_metadata( "<!--[if lt IE 9]>" . blueprint( "ie.css" ) . "<![endif]-->" )
					->append_metadata( blueprint( "plugins/buttons/screen.css" ) )
					->append_metadata( blueprint( "plugins/fancy-type/screen.css" ) )
					->append_metadata( js( "jquery-1.5.1.min.js" ) )
					->append_metadata( js( "jquery-ui-1.8.13.custom.min.js" ) )
					->append_metadata( js( 'functions.js' ) )
					->append_metadata( css( "jquery-ui-1.8.13.custom.css" ) )
					->append_metadata( css( "admin.css" ) )
					->set_partial( 'footer',			'partials/footer' )
					->set_partial( 'sidehdr',			'partials/sidehdr' )
					->set_partial( 'sidebar',			'partials/sidebar' )
					->set_partial( 'sidelic',			'partials/sidelic' )
					->set_partial( 'debug',				'partials/debug' )
					->set_partial( 'content_header',	'partials/content_header' )
					->set_partial( 'content_messages',	'partials/content_messages' );
		
		// End Benchmark Point
		$this->benchmark->mark('admin_controller_end');
	}
	
	
	/**
	 * Builds the menu array for use
	 * @access		private
	 * @version		3.0.0.0.3
	 * 
	 * @return		array of menu objects
	 * @since		3.0.0
	 */
	private function _build_menu()
	{
		$menu	= array();
		$menu[]	= (object) array( 'anchor' => 'admin/index', 'text' => lang( 'menu.home' ) );
		
		// Settings Menu
		$submenu	= array();
		$submenu[]	= (object) array( 'anchor' => 'settings/index',			'text' => lang( 'menu.globalsettings' ) );
		$submenu[]	= (object) array( 'anchor' => 'settings/api',			'text' => lang( 'menu.apisettings' ) );
		$submenu[]	= (object) array( 'anchor' => 'settings/user',			'text' => lang( 'menu.userbridging' ) );
		$submenu[]	= (object) array( 'anchor' => 'settings/visual',		'text' => lang( 'menu.visualsetup' ) );
		$submenu[]	= (object) array( 'anchor' => 'settings/registrations',	'text' => lang( 'menu.registrations' ) );
		//$submenu[]	= (object) array( 'anchor' => 'settings/notifications',	'text' => lang( 'menu.notifications' ) );
		$menu[]		= (object) array( 'anchor' => '#', 'text' => lang( 'menu.settings' ), 'submenu' => $submenu );
		
		// Connection menu
		$cnxns		= $this->_set_connection_menu();
		$submenu	= array();
		
		if ( empty( $cnxns ) ) {
			if ( $this->can_add_cnxns() ) {
				$submenu[]	= (object) array( 'anchor' => 'cnxns/add', 'text' => lang( 'menu.addnewcnxn' ) );
				$menu[]	= (object) array( 'anchor' => '#', 'text' => lang( 'menu.connections' ), 'submenu' => $submenu );
			}
		}
		else {
			foreach ( $cnxns as $c ) {
				$submenu[] = (object) array( 'anchor' => 'cnxns/edit/' . $c->id, 'text' => $c->name );
			}
			
			if ( $this->can_add_cnxns() ) {
				$submenu[]	= (object) array( 'anchor' => 'cnxns/add', 'text' => lang( 'menu.addnewcnxn' ) );
			}
			$menu[]	= (object) array( 'anchor' => '#', 'text' => lang( 'menu.connections' ), 'submenu' => $submenu );
		}
		
		// Rendering Menu
		$submenu	= array();
		$submenu[]	= (object) array( 'anchor' => 'pagemap/index', 'text' => lang( 'menu.pagemaps' ) );
		$submenu[]	= (object) array( 'anchor' => 'langmap/index', 'text' => lang( 'menu.langmaps' ) );
		$menu[]		= (object) array( 'anchor' => '#', 'text' => lang( 'menu.rendering' ), 'submenu' => $submenu );
		
		// Users Menu
		$submenu	= array();
		$submenu[]	= (object) array( 'anchor' => 'usermgr/find', 'text' => lang( 'menu.finduser' ) );
		$submenu[]	= (object) array( 'anchor' => 'usermgr/create', 'text' => lang( 'menu.createuser' ) );
		$submenu[]	= (object) array( 'anchor' => 'usermgr/modify', 'text' => lang( 'menu.modifyuser' ) );
		$submenu[]	= (object) array( 'anchor' => 'usermgr/log', 'text' => lang( 'menu.userlog' ) );
		$menu[]		= (object) array( 'anchor' => '#', 'text' => lang( 'menu.usermgr' ), 'submenu' => $submenu );
		
		$menu[]		= (object) array( 'anchor' => 'users/index', 'text' => lang( 'menu.manageadmins' ) );
		
		// Help  Menu
		$submenu	= array();
		$submenu[]	= (object) array( 'anchor' => 'help/stepbystep', 'text' => lang( 'menu.stepbystep' ) );
		$submenu[]	= (object) array( 'anchor' => 'help/documentation', 'text' => lang( 'menu.documentation' ) );
		$submenu[]	= (object) array( 'anchor' => 'help/systemstatus', 'text' => lang( 'menu.systemstatus' ) );
		$menu[]		= (object) array( 'anchor' => '#', 'text' => lang( 'menu.help' ), 'submenu' => $submenu );
		
		// Set the current menu item
		$current	= $this->uri->segment(1, '') . '/' . $this->uri->segment(2, 'index');
		$currentsub	= trim( $this->uri->segment(1, '') . '/' . $this->uri->segment(2, 'index') . ( in_array( $this->uri->segment( 1, '' ), array( 'cnxns') ) ?  '/' . $this->uri->segment(3, '' ) : '' ), '/' );
		foreach ( $menu as & $m ) {
			$m->current	= false;
			if ( isset( $m->submenu ) ) {
				foreach ( $m->submenu as & $sub ) {
					$sub->current = false;
					if ( $sub->anchor == $currentsub ) {
						$sub->current	= true;
						$m->current		= true;
					}
				}
			}
			else {
				if ( $m->anchor == $current ) {
					$m->current = true;
				}
			}
		} 
		
		return $menu;
	}
	
	
	/**
	 * Checks access to the configuration / backend (only admins allowed)
	 * @access		private
	 * @version		3.0.0.0.3
	 * 
	 * @return		boolean true if access is allowed, false if denied
	 * @since		3.0.0
	 */
	private function _check_access()
	{
		// Dont need to log in, this is an open page
		if ( $this->_is_public() ) {
			return true;
		}
		else if ( ! $this->user) {
			redirect('admin/login');
		}
		
		// Admins can go straight in
		else if ( $this->auth->is_admin() === true ) {
			return true;
		}
		
		return false;
	}
	
	
	/**
	 * Creates a quick list of menu items of connections
	 * @access		private
	 * @version		3.0.0.0.3
	 * 
	 * @return		array containing available connections
	 * @since		3.0.0
	 */
	private function _set_connection_menu()
	{
		$menu	= array();
		$cnxns	= get_cnxns();
		foreach ( $cnxns as $id => $cnxn ) {
			$menu[]	= (object) array( 'id' => $id, 'name' => $cnxn->get( 'name' ) );
		}
		return $menu;
	}
}