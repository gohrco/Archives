<?php
/* SECURITY CHECKPOINT */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Overloads the Exceptions class to afford checking of response types
 * @version		3.0.0.0.3
 * 
 * @since		3.0.0
 * @author		Steven
 */
class MY_Exceptions extends CI_Exceptions
{
	
	/**
	 * Stores the response type
	 * @access		public
	 * @since		3.0.0
	 * @var			integer
	 */
	public	$response	= 0;
	
	
	/**
	 * Constructor class
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * $since		3.0.0
	 */
	public function __construct()
	{
		$CI		= & get_instance();
		
		if (! is_object( $CI ) ) {
			$ctrl = array();
		}
		else {
			$ctrl = $CI->router->class;
		}
		
		// Test for response types
		if ( in_array($ctrl, array( 'api' ) ) ) {
			$this->response = EXC_JSON;
		}
		else if ( in_array( $ctrl, array( 'render' ) ) ) {
			$this->response = EXC_XML;
		}
		else if ( in_array( ENVIRONMENT_LOG, array( 0, 1 ) ) ) {
			$this->response = EXC_STD;
		}
		else {
			$this->response	= EXC_ALL;
		}
		
		// If we are using a standard interface, then finish building parent class
		if ( in_array( $this->response, array( EXC_ALL, EXC_STD ) ) ) {
			return parent::__construct();
		}
	}
	
	
	/**
	 * Exception Logger
	 *
	 * This function logs PHP generated error messages
	 *
	 * @access	private
	 * @param	string	the error severity
	 * @param	string	the error string
	 * @param	string	the error filepath
	 * @param	string	the error line number
	 * @return	string
	 */
	function log_exception($severity, $message, $filepath, $line)
	{
		parent::log_exception( $severity, $message, $filepath, $line );
	}
	
	
	/**
	 * 404 Page Not Found Handler
	 *
	 * @access	private
	 * @param	string
	 * @return	string
	 */
	function show_404($page = '', $log_error = TRUE)
	{
		$CI = & get_instance();
		
		switch( $this->response ):
		case EXC_STD:
			debug_error( $page );
			parent::show_404( $page, $log_error );
			return;
			break;
		case EXC_JSON:
			debug_error( $page );
			
				
			
			break;
		case EXC_XML:
			// We need the response helper
			$CI->load->helper( 'response' );
			
			// Send current error to debug
			debug_error( $page );
			
			// Grab all errors and process
			$debug		= debug_output();
			$response	= xml_response( array( 'debug' => $debug ) );
			
			$CI->output->set_header( 'Cache-Control: no-cache, must-revalidate' );
			$CI->output->set_header( 'Expires: Fri, 7 Mar 1997 05:00:00 GMT' );
			$CI->output->set_content_type( 'text/xml' );
			$CI->output->set_output( $response );
			
			$CI->session->sess_destroy();
			break;
		endswitch;
	}
	
	
	/**
	 * General Error Page
	 *
	 * This function takes an error message as input
	 * (either as a string or an array) and displays
	 * it using the specified template.
	 *
	 * @access	private
	 * @param	string	the heading
	 * @param	string	the message
	 * @param	string	the template name
	 * @return	string
	 */
	function show_error($heading, $message, $template = 'error_general', $status_code = 500)
	{
		switch( $this->response ):
		case EXC_ALL:
		case EXC_STD:
			debug_error( $message, false, 2 );
			return parent::show_error( $heading, $message, $template, $status_code );
			break;
		case EXC_JSON:
		case EXC_XML:
			debug_error( $message, false, 2 );
			break;
		endswitch;
	}
	
	
	/**
	 * Native PHP error handler
	 *
	 * @access	private
	 * @param	string	the error severity
	 * @param	string	the error string
	 * @param	string	the error filepath
	 * @param	string	the error line number
	 * @return	string
	 */
	function show_php_error($severity, $message, $filepath, $line)
	{
		switch( $this->response ):
		case EXC_ALL:
			parent::show_php_error( $severity, $message, $filepath, $line );
		case EXC_STD:
		case EXC_JSON:
		case EXC_XML:
			debug_error( $message, false, 2 );
			break;
		endswitch;
	}
}