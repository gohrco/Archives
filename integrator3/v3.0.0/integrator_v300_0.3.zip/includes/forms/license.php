<?php

$form['index']	= array(
	'License' => array(
			'value'			=> false,
			'order'			=> 10,
			'type'			=> 'text',
			'validation'	=> 'required|xss_clean'
		)
);