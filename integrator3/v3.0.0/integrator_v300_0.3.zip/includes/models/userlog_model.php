<?php

/* SECURITY CHECKPOINT */
defined('BASEPATH') OR exit('No direct script access allowed');


/**
 * Userlog model class
 * @version		@fileVers2
 * 
 * @author		Steven
 * @since		3.0.0
 */
class Userlog_Model extends CI_Model
{
	private		$data	= null;
	private		$email	= null;
	private		$ip		= null;
	private		$log	= array();
	private		$task	= null;
	private		$time	= null;
	private		$write	= true;
	private		$_bind	= null;
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		$this->load->language( 'usermgr' );
		$sess = & $this->session;
		$this->log = ( ( $u = $sess->userdata( 'userlog' ) ) === false ? array() : $u );
		$sess->unset_userdata( 'userlog' );
	}
	
	
	/**
	 * Record an action to the log
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $method: the action method being recorded
	 * @param		array		- $data: the data used in the action
	 * @param		integer		- $c: the cnxn_id if known (optional)
	 * 
	 * @since		3.0.0
	 */
	public function action( $method, $data, $c = null )
	{
		$this->log[] = $this->_convert_action( $method, $data, $c );
	}
	
	
	/**
	 * Binds the data array to a new object and stores it to model object allowing for validation
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		array		- $data: contains name => value paired array
	 * 
	 * @return		boolean true on completion, false on error
	 * @since		3.0.0
	 */
	public function bind( $data = array() )
	{
		if ( ! is_array( $data ) ) return false;
		$bind	= array();
		
		foreach ( $data as $key => $value ) {
			$bind[$key] = $value;
		}
		
		$this->_bind = (object) $bind;
		return true;
	}
	
	
	/**
	 * Checks the data prior to storage to ensure consistant with expectations
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		boolean true if ok, false otherwise
	 * @since		3.0.0
	 */
	public function check()
	{
		$data = $this->_bind;
		if ( $data->email == null ) $data->email = $this->_find_email( $data->log  );
		if ( ( $data->email == null ) || ( $data->email === false ) ) $data->email = 'not found';
		if ( $data->task == null )	return false;
		if ( $data->ip == null )	$data->ip	= $this->session->userdata( 'ip_address' );
		if ( $data->time == null )	$data->time	= $this->session->now;
		if ( is_array( $data->log ) ) $data->log	= json_encode( $data->log );
		
		$fix	= array( 'log' => 'data', 'time' => 'timestamp' );
		foreach ( $fix as $o => $n ) {
			$data->$n = $data->$o;
			unset( $data->$o );
		}
		
		$this->_bind = $data;
		return true;
	}
	
	
	public function clean( $count = 1000 )
	{
		$count = (int) $count;
		$this->db->query( "DELETE FROM #__userlog WHERE timestamp < ( SELECT timestamp FROM ( SELECT timestamp FROM #__userlog ORDER BY timestamp DESC LIMIT 1 OFFSET " . $count . " ) foo )" );
	}
	
	
	/**
	 * Wrapper for getting the count
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $type: the count type to return
	 * 
	 * @return		integer containing the desired count
	 * @since		3.0.0
	 */
	public function count( $type = 'last' )
	{
		switch ( $type ) {
			case 'last':
				return $this->last_count;
			case 'all':
				return $this->all_count;
		}
	}
	
	
	/**
	 * Deletes a row from the table
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		integer		- $id: the id of the row to delete
	 * 
	 * @return		true on success, false on error
	 * @since		3.0.0
	 */
	public function delete( $id = null, $by = 'id' )
	{
		$this->db->where( 'type', 'page' );
		
		if ( $id ) {
			if ( $by == 'id' ) {
				$this->id = $id;
				$this->db->where( 'id', $this->id );
			}
			else {
				$this->_a = $id;
				$this->item = $by;
				$this->db->where( array( '_a' => $id, 'item' => $by ) );
			}
		}
		else {
			$this->db->where( 'id', $this->id );
		}
		
		$this->db->delete( 'userlog' );
		
		return ( $this->db->affected_rows() > 0 ? TRUE : FALSE ); 
	}
	
	
	/**
	 * Getter function
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $name: generally required (the thing we are looking for)
	 * @param		varies		- $default: the default value if $name doesn't exist
	 * @param		string		- $type: what we are getting.  Possible values include
	 * 								local:  Local variable $this->$name
	 * 								_v:   The _v setting being sought
	 * 
	 * @return		varies could be value, null or object being sought
	 * @since		3.0.0
	 */
	public function get( $name, $default = null, $type = 'local' )
	{
		$return	= null;
		switch ( $type ) {
			case 'local':
				$return = ( isset( $this->$name ) ? $this->$name : $default );
				break;
			default:
				$return	= ( isset( $this->_v[$name] ) ? $this->_v[$name] : $default );
				break;
		}
		return $return;
	}
	
	
	/**
	 * Retrieves object properties
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		array of object properties
	 * @since		3.0.0
	 */
	public function get_properties()
	{
		$data = array();
		foreach( array( 'task', 'ip', 'email', 'data', 'time', 'log' ) as $item ) {
			$data[$item] = $this->$item;
		}
		return $data;
	}
	
	
	/**
	 * Loads the results by email
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $email: the email to load or null for all
	 * @param		string		- $order: what field to order by
	 * @param		boolean		- $asc: if true order ascend
	 * @param		integer		- $st: the starting record number
	 * @param		integer		- $limit: the number of records to get
	 * 
	 * @return		array on success, false on error
	 * @since		3.0.0
	 */
	public function load_by_email( $email = null, $order = 'timestamp', $asc = false, $st = 0, $limit = 20 )
	{
		if ( $email == null ) return $this->_load( null, $order, $asc, $st, $limit );
		else return $this->_load( array('email' => $email ), $order, $asc, $st, $limit );
	}
	
	
	/**
	 * Used to store any log info to the session prior to shutdown (cant rely on __destruct)
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @since		3.0.0
	 */
	public function redirect()
	{
		if ( empty( $this->log ) ) return;
		
		$sess = & $this->session;
		$sess->set_userdata( 'userlog', $this->log );
	}
	
	
	/**
	 * Shortcut for saving data to the database
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		true upon success
	 * @since		3.0.0
	 */
	public function save( $data = null )
	{
		if ( $data == null ) { 
			$data = $this->get_properties();
			$this->log = null;
		}
		
		if (! $this->bind( $data ) ) {
			$this->_bind = null;
			return false;
		}
		
		if (! $this->check() ) {
			$this->_bind = null;
			return false;
		}
		
		if (! $this->store() ) {
			$this->_bind = null;
			return false;
		}
		
		return true;
	}
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $name: the name to set
	 * @param		varies		- $value: the value to set
	 * @param		string		- $type: the type to set.
	 * 								local:  Local variable $this->$name
	 * 
	 * @return		varies will return the previous value
	 * @since		3.0.0
	 */
	public function set( $name, $value, $type = 'local' )
	{
		$return	= null;
		
		switch( $type ) {
			case 'local':
				$return = $this->get( $name );
				$this->$name = $value;
				break;
			default:
				$return = $this->get( $name, $value, $type );
				$this->_v[$name] = $value;
				break;
		}
		
		return $return;
	}
	
	
	/**
	 * Stores the data array to the database
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		boolean true if successful, false if not
	 * @since		3.0.0
	 */
	public function store()
	{
		$data			= $this->_bind;	// Grab local copy
		$this->_bind	= null;
		
		$this->db->insert( 'userlog', $data );
		//$sql = "INSERT INTO `userlog` ( `task`, `email`, `ip`, `timestamp`, `data` ) VALUES ( '{$data->task}', '{$data->email}', '{$data->ip}', '{$data->time}', '{$data->log}' )";
		//$this->db->query( $sql );
		
		return ( $this->db->affected_rows() > 0 );
	}
	
	
	/**
	 * Instructs the userlog to write on close with given task if provided
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $task: the task to attach to entry
	 * 
	 * @since		3.0.0
	 */
	public function write( $task = null )
	{
		if ( $task != null ) $this->task = $task;
		$this->write = true;
		$this->save();
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE PRIVATE TO THIS MODEL
	 * **********************************************************************
	 */
	
	
	/**
	 * Convert a posted action to a log entry
	 * @access		private
	 * @version		3.0.0.0.3
	 * @param		string		- $method: the performed action
	 * @param		array		- $data: the data used to perform action
	 * @param		integer		- $c: the cnxn_id if known (optional)
	 * 
	 * @return		array of formatted log action
	 * @since		3.0.0
	 */
	private function _convert_action( $method, $data, $c = null )
	{
		$log			= array( 'msg' => null, 'c' => $c, 'd' => array() );
		$this->write	= false;
		
		switch( $method ) {
			case 'authentication':
			case 'auth':
				$log['msg']	= 'AUTH';
				$log['d'][]	= (! empty( $data['username'] ) ) ? $data['username'] : $data['email'];
				break;
			// Bad password
			case 'auth-badpw':
				$log['msg']	= 'AUTH_BADPW';
				$log['d'][]	= (! empty( $data['username'] ) ) ? $data['username'] : $data['email'];
				break;
			// Missing credential
			case 'auth-misscred':
				$log['msg']	= 'AUTH_MISSCRED';
				$log['d'][]	= (! empty( $data['username'] ) ) ? $data['username'] : $data['email'];
				$log['d'][] = $data['credential'];
				break;
			// Missing Credential Found!
			case 'auth-credfound':
				$log['msg']	= 'AUTH_CREDFOUND';
				$log['d'][] = $data[$data['credential']];
				$log['d'][] = $data['credential'];
				$log['d'][] = ( $data['credential'] == 'email' ? $data['username'] : $data['email'] );
				break;
			// No Return URL error
			case 'auth-returnerror':
				$log['msg']	= 'AUTH_RETERROR';
				$this->task	= 'login';
				$this->write= true;
				break;
			// The logout landing url was used
			case 'auth-returnlogout':
				$log['msg'] = 'AUTH_RETERRLOUT';
				$this->task = 'login';
				break;
			// The credentials were missing
			case 'auth-credsmissing':
				$log['msg']	= 'AUTH_CREDSMISS';
				$this->task = 'login';
				$this->write= true;
				break;
			// No connection stack able to be assembled
			case 'auth-cnxnstackerror':
				$log['msg'] = 'AUTH_CNXNERR';
				$this->task = 'login';
				$this->writer= true;
				break;
			// Credential type mismatch
			case 'auth-typemismatch':
				$log['msg'] = 'AUTH_TYPEMIS';
				$this->task = 'login';
				$this->writer= true;
				break;
			// Login was successful
			case 'login-success':
				$use = cnxn( $c )->get( 'usernametype', 'email', 'users' );
				$log['msg']	= 'LOGINY';
				$log['d'][]	= (! empty( $data[$use] ) ) ? $data[$use] : $data['email'];
				break;
			// Login failed
			case 'login-failed':
				$use = cnxn( $c )->get( 'usernametype', 'email', 'users' );
				$log['msg']	= 'LOGINN';
				$log['d'][]	= (! empty( $data[$use] ) ) ? $data[$use] : $data['email'];
				break;
			// Cant find user
			case 'find-notfound':
				$use = cnxn( $c )->get( 'usernametype', 'email', 'users' );
				$log['msg']	= 'FINDN';
				$log['d'][]	= (! empty( $data[$use] ) ) ? $data[$use] : $data['email'];
				break;
			// Login failed
			case 'cuser-created':
				$use = cnxn( $c )->get( 'usernametype', 'email', 'users' );
				$log['msg']	= 'CREATENEW';
				$log['d'][]	= (! empty( $data[$use] ) ) ? $data[$use] : $data['email'];
				break;
			/**
			 * API ERROR MESSAGES 
			 */
			// API: cnxn user create succeed
			case 'api-usercreated':
				$use = cnxn( $c )->get( 'usernametype', 'email', 'users' );
				$log['msg']	= 'APIUSERCREATEYES';
				$log['d'][]	= (! empty( $data[$use] ) ) ? $data[$use] : $data['email'];
				break;
			// API: cnxn user create failed
			case 'api-usercreatefailed':
				$use = cnxn( $c )->get( 'usernametype', 'email', 'users' );
				$log['msg']	= 'APIUSERCREATENO';
				$log['d'][]	= (string) $data; // Better contain error message from cnxn
				break;
		}
		
		return $log;
	}
	
	
	/**
	 * Finds an email in a data array
	 * @access		private
	 * @version		3.0.0.0.3
	 * @param		array		- $data: an array of data to scour
	 * 
	 * @return		string of found email or false on no find
	 * @since		3.0.0
	 */
	private function _find_email( $data )
	{
		if (! is_array( $data ) ) $data = (array) $data;
		$pattern = "/\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,5}\b/i";
		foreach( $data as $value ) {
			if ( is_array( $value ) ) {
				if ( $found = $this->_find_email( $value ) ) return $found;
			}
			else {
				if ( @preg_match( $pattern, $value, $match ) ) return $match[0];
			}
		}
		return false;
	}
	
	
	/**
	 * Loads the data from the database
	 * @access		private
	 * @version		3.0.0.0.3
	 * @param		array		- $where: if set is an array, else null
	 * @param		string		- $order: the field to sort by (default timestamp)
	 * @param		boolean		- $asc: sets the ascending (true) or descending (false) sort order
	 * @param		integer		- $st: the starting record
	 * @param		integer		- $limit: the limit of records to show
	 * 
	 * @return		array of data or false on none found
	 * @since		3.0.0
	 */
	private function _load( $where = null, $order = 'timestamp', $asc = false, $st = 0, $limit = 20 )
	{
		$this->db->from( 'userlog' );
		if ( $where != null ) $this->db->where( $where );
		$this->all_count = $this->db->count_all_results();
		
		$this->db->select( 'task, email, ip, timestamp, data' );
		$this->db->from( 'userlog' );
		
		if ( $where != null ) {
			$this->db->where( $where );
		}
		
		$this->db->order_by( $order, ( $asc ? 'ASC' : 'DESC' ) );
		
		$this->db->limit( $limit, $st );
		$result	= $this->db->get();
		
		$this->last_count = $this->db->count_all_results();
		
		if ( ( $count = $result->num_rows() ) > 0 ) {
			$this->last_count = $count;
			foreach( $result->result() as $row ) {
				$row->data = $this->_translate_action( json_decode( $row->data, true ) );
				$data[] = $row;
				$this->_find_email( $row->data );
			}
			
			return $data;
		}
		
		$this->last_count = 0;
		return false;
	}
	
	
	/**
	 * Translates a log entry into an array of strings
	 * @access		private
	 * @version		3.0.0.0.3
	 * @param		array		- $logs: a log entry from the database
	 * 
	 * @return		array of log entry strings
	 * @since		3.0.0
	 */
	private function _translate_action( $logs = array() )
	{
		if ( empty( $logs ) ) return false;
		
		$data	= array();
		
		foreach ( $logs as $log ) {
			$cnxn	= cnxn( $log['c'] );
			if (! $cnxn ) continue;
			$cname	= $cnxn->get( 'name' );
			$msg	= lang( 'USERMGR_LOG_'.$log['msg'] );
			
			switch ( $log['msg'] ) {
				case 'AUTH':
					$data[]	= sprintf( $msg, $log['d'][0], $cname );
					break;
				case 'AUTH_BADPW':
					$data[] = sprintf( $msg, $log['d'][0], $cname );
					break;
				case 'AUTH_MISSCRED':
					$data[] = sprintf( $msg, $log['d'][0], $log['d'][1], $cname );
					break;
				case 'AUTH_CREDFOUND':
					$data[] = sprintf( $msg, $log['d'][0], $log['d'][1], $log['d'][2], $cname );
					break;
				case 'AUTH_RETERROR':
					$data[]	= sprintf( $msg, $cname );
					break;
				case 'AUTH_RETERRLOUT':
					$data[]	= sprintf( $msg, $cname );
					break;
				case 'AUTH_CREDSMISS':
					$data[] = sprintf( $msg, $cname );
					break;
				case 'AUTH_CNXNERR':
					$data[] = sprintf( $msg, $cname );
					break;
				case 'AUTH_TYPEMIS':
					$data[] = sprintf( $msg, $cname );
					break;
				case 'LOGINY':
					$data[]	= sprintf( $msg, $cname, $log['d'][0] );
					break;
				case 'LOGINN':
					$data[]	= sprintf( $msg, $cname, $log['d'][0] );
					break;
				case 'FINDN':
					$data[] = sprintf( $msg, $log['d'][0], $cname );
					break;
				case 'CREATENEW':
					$data[]	= sprintf( $msg, $cname, $log['d'][0] );
					break;
				/**
				 * API MESSAGES
				 */
				case 'APIUSERCREATEYES':
					$data[] = sprintf( $msg, $log['d'][0], $cname );
					break;
				case 'APIUSERCREATENO':
					$data[] = sprintf( $msg, $cname, $log['d'][0] );
					break;
			}
		}
		return $data;
	}
}