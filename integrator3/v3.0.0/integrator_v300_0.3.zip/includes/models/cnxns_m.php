<?php

class Cnxns_m extends CI_Model
{
	/**
	 * Reference to the cnxn api object
	 * @access		protected
	 * @since		3.0.0
	 * @var			object
	 */
	protected	$api			= null;
	
	/**
	 * Data to bind and save to the database
	 * @access		private
	 * @since		3.0.0
	 * @var 		object
	 */
	public		$data			= null;
	
	/**
	 * Indicates the connection is active or not
	 * @access		protected
	 * @since		3.0.0
	 * @var			boolean
	 */
	protected	$active			= false;
	
	/**
	 * The reference name given to this connection in the settings
	 * @access		protected
	 * @since		3.0.0
	 * @var			string
	 */
	protected	$name			= null;
	
	/**
	 * The type of connection this model is
	 * @access		protected
	 * @since		3.0.0
	 * @var			string
	 */
	protected	$type			= null;
	
	/**
	 * The version of this file
	 * @access		protected
	 * @since		3.0.0
	 * @var			string
	 */
	protected	$version		= '3.0.0.0.3';		// The version of this object in use
	
	/**
	 * A reference to the database object
	 * @access		protected
	 * @since		3.0.0
	 * @var			object
	 */
	protected	$_db = null;
	
	/**
	 * Properties storage (undeclared properties)
	 * @access		protected
	 * @since		3.0.0
	 * @var			array
	 */
	protected	$_properties = array();
	
	
	/**
	 * Constructor
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		$CI = & get_instance();
		$this->_db = & $CI->db;
	}
	
	
	/**
	 * Binds the data array to a new object and stores it to model object allowing for validation
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		array		- $data: contains name => value paired array
	 * 
	 * @since		3.0.0
	 */
	public function bind( $data = array() )
	{
		$isNew	= ( ! isset( $data['id'] ) ? TRUE : FALSE );
		$bind	= array();
		
		if ( $isNew ) {
			$type			= type( $data['type'] );
			$bind['type']	= $type->get( "type" );
			$bind['name']	= $type->get( "name" );
			$bind['active']	= $type->get( "active" );
			$bind['params']	= $type->get( "params" );
		}
		else {
			$bind['id']		= $data['id'];
			$bind['name']	= $data['name'];
			$bind['active']	= $data['active'];
			$bind['type']	= $data['type'];
			$bind['params']	= $data['params'];
		}
		
		if ( is_array( $bind['params'] ) ) $bind['params'] = json_encode( $bind['params'] );
		$this->data = (object) $bind;
		
		return true;
	}
	
	
	/**
	 * Checks the data to be saved to ensure consistancy
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		boolean true on okay
	 * @since		3.0.0
	 */
	public function check() {
		$data = $this->data;
		if (! is_object( $data ) ) $data = (object) $data;
		if (! isset( $data->type ) ) return false;
		if (! isset( $data->name ) ) return false;
		if (! isset( $data->params ) ) return false;
		if (! is_string( $data->params ) ) $data->params = json_encode( $data->params );
		$this->data = $data;
		return true;
	}
	
	
	/**
	 * Deletes a row from the connection table
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		integer		- $id: the id of the row to delete
	 * 
	 * @return		true on success, false on error
	 * @since		3.0.0
	 */
	public function delete( $id = null )
	{
		if ( $id == NULL ) return false;
		
		$this->_db->delete( 'cnxns', array( 'id' => $id ) );
		
		return ( $this->_db->affected_rows() > 0 ? TRUE : FALSE ); 
	}
	
	
	/**
	 * Getter function
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $name: generally required (the thing we are looking for)
	 * @param		varies		- $default: the default value if $name doesn't exist
	 * @param		string		- $type: what we are getting.  Possible values include
	 * 								local:  Local variable $this->$name
	 * 								cnxn:   The cnxn being sought (by id or name)
	 * 
	 * @return		varies could be value, null or object being sought
	 * @since		3.0.0
	 */
	public function get( $name, $default = null, $type = 'local' )
	{
		$return	= null;
		switch ( $type ) {
			case 'local':
				$return = ( isset( $this->$name ) ? $this->$name : $default );
				break;
			default:
				$return	= ( isset( $this->params[$type][$name]['value'] ) ? $this->params[$type][$name]['value'] : $default );
				break;
		}
		return $return;
	}
	
	
	/**
	 * Wrapper to grab a single cnxn
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		integer		- $id: either a cnxn id or null for all (should use get_cnxns instead)
	 * 
	 * @return		object containing data or false on empty
	 * @since		3.0.0
	 */
	public function get_cnxn( $id = NULL )
	{
		// We are trying to get all cnxns through this function for some reason
		if ( $id == NULL ) return $this->get_cnxns();
		
		// Grab cnxn
		$data = $this->get_cnxns( $id );
		
		// We didn't get any cnxn with the specified id so return false
		if ( empty( $data ) ) return false;
		
		return $data[0];
	}
	
	
	/**
	 * Gets the connection requested or return all of them
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		integer		- $id: either a cnxn id or null for all
	 * 
	 * @return		single object, an array of objects or an empty array
	 * @since		3.0.0
	 */
	public function get_cnxns( $id = NULL )
	{
//		$where	= ( $id != NULL ? " WHERE `id` = " . $id : "" );
		$result	= ( $id != null ? $this->_db->get_where( 'cnxns', array( 'id' => $id ) ) : $this->_db->get( 'cnxns' ) );
//		$sql	= "SELECT `id`, `name`, `active`, `type`, `params` FROM cnxns" . $where;
//		$result	= $this->_db->query( $sql );
		return $result->result();
	}
	
	
	/**
	 * Generate the form fields, labels and descriptions for editing
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		array containing form field info
	 * @since		3.0.0
	 */
	public function get_form_fields()
	{
		$data	=   array();
		$params	=	$this->get( "params", array() );
		foreach( $params as $key => $paramset ) {
			foreach( $paramset as $k => $v ) {
				$v['name'] = "params[{$key}][{$k}]";
				$v['label']	= '<div>' . form_label( $this->_lang( "cnxns.edit.tab." . $v['lang'] ), "params.".$v['lang'], array( 'class' => 'span-6', 'style' => 'text-align: right; ') );
				$data[$key][$v['order']] = $this->_build_form_fields( $v );
				ksort( $data[$key] );
			}
		}
		
		return $data;
	}
	
	
	/**
	 * Assembles the form validation rules for the connection
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		array containing field, label and rules for rules specified in config file ($form['validation'])
	 * @since		3.0.0
	 */
	public function get_form_validation()
	{
		$data	=   array();
		$params	=   $this->get( "params", array() );
		
		foreach ( $params as $key => $paramset ) {
			foreach ( $paramset as $k => $v ) {
				$data[]	= array(	'field' => "params[{$key}][{$k}]",
									'label' =>  $this->_lang( "cnxns.edit.tab." . $v['lang'] ),
									'rules' => $v['validation']
				);
			}
		}
		
		$data[]	= array( 'field' => "name", 'label' => $this->_lang( "main.name" ), 'rules' => "required" );
		return $data;
	}
	
	
	/**
	 * Gets just the values from the parameter array
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		array containing values
	 * @since		3.0.0
	 */
	public function get_param_array()
	{
		$params	=   $this->get( "params", array() );
		$data	=   array();
		
		foreach( $params as $group => $paramset ) {
			foreach( $paramset as $name => $p ) {
				$data[$group][$name] = $p['value'];
			}
		}
		
		return $data;
	}
	
	
	/**
	 * Retrieves either a single set of parameters or all params
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		integer		- $id: either a single record id or null for all
	 * 
	 * @return		parameters field of cnxn requested or false on empty
	 * @since		3.0.0
	 */
	public function get_params( $id = null )
	{
		// We are trying to get all cnxns through this function for some reason
		if ( $id == NULL ) return false;
		
		// Grab cnxns
		$data = $this->get_cnxns( $id );
		
		// We didn't get any cnxn with the specified id so return false
		if ( empty( $data ) ) return false;
		
		return $data[0]->params;
	}
	
	
	/**
	 * Gets the properties of the object
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		array of object properties or false on error
	 * @since		3.0.0
	 */
	public function get_properties()
	{
		$data = array();
		
		foreach ( array( "id", "type", "active", "name", "params" ) as $item ) {
			$data[$item] = $this->get( $item, null );
		}
		return $data;
	}
	
	
	/**
	 * Retrieves all the loaded types
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		array of type => name
	 * @since		3.0.0
	 */
	
	public function get_types()
	{
		$CI = & get_instance();
		$CI->load->library( "cnxns_library" );
		$traw	= $CI->cnxns_library->get( "types", false );
		
		if (! $traw ) return false;
		
		$types	= array();
		foreach ( $traw as $type => $obj )
		{
			$types[$type] = $obj->get( "name", $type );
		}
		
		return $types;
	}
	
	
	/**
	 * Loads a database result object onto the model
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		object		- $data: contains the data straight from the database result row
	 * 
	 * @return		true on success, false on error
	 * @since		3.0.0
	 */
	public function load( $data = NULL )
	{
		if ( $data == NULL ) return false;
		if ( ! is_object( $data ) ) return false;
		
		foreach ( $data as $k => $v ) {
			if ( $k == "params" ) {
				$params	= ( is_string( $v ) ? json_decode( $v, TRUE ) : $v );
				foreach ( $params as $key => $paramset ) {
					foreach( $paramset as $param => $value ) {
						$value = ( is_array( $value ) ? $value['value'] : $value );
						$this->set( $param, $value, $key );
					}
				}
				continue;
			}
			$this->set( $k, $v );
		}
		
		// Setup the cnxn api while we are here
		$apiname	= ucfirst( $data->type ) . '_API';
		
		$CI = & get_instance();
		$CI->cnxnapi[$data->id] = new $apiname( $this->get_properties() );
		$this->api	= & $CI->cnxnapi[$data->id];
		return true;
	}
	
	
	/**
	 * Saves the bound data to the database (requires $model->bind first)
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		true or inserted id upon success
	 * @since		3.0.0
	 */
	public function save( $data = null )
	{
		if ( $data == null ) {
			if (! ( $data = $this->get_properties() ) )
				return false;
		}
		
		if (! $this->bind( $data ) ) {
			$this->data = null;
			return false;
		}
		
		if (! $this->check() ) {
			$this->data = null;
			return false;
		}
		
		if (! $id = $this->store() ) {
			$this->data = null;
			return false;
		}
		
		return $id;
	}
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $name: the name to set
	 * @param		varies		- $value: the value to set
	 * @param		string		- $type: the type to set.
	 * 								local:  Local variable $this->$name
	 * 
	 * @return		varies will return the previous value
	 * @since		3.0.0
	 */
	public function set( $name, $value, $type = 'local' )
	{
		$return	= null;
		
		switch( $type ) {
			case 'local':
				$return = $this->get( $name );
				$this->$name = $value;
				break;
			default:
				$return = $this->get( $name, $value, $type );
				$this->params[$type][$name]['value'] = $value;
				break;
		}
		
		return $return;
	}
	
	
	/**
	 * Properly sets the default values from the config file
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @since		3.0.0
	 */
	public function set_defaults()
	{
		$ci = & get_instance();
		$type	= $this->type;
		$config = $ci->config->item( $type );
		
		foreach ( $config as $k => $vals )
		{
			$this->set( $k, $vals );
		}
	}
	
	
	/**
	 * Checks the status of the connection
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		array containing basic items
	 * @since		3.0.0
	 */
	public function status_check()
	{
		$data	= array();
		$data['id']		= (int) $this->get( 'id' );
		$data['name']	= (string) $this->get( 'name' );
		$data['type']	= (string) $this->get( 'type' );
		$data['user']	= (bool) $this->get( 'userenable', false, 'users' );
		$data['visual']	= (bool) $this->get( 'visualenable', false, 'visuals' );
		$data['active']	= (bool) $this->get( 'active', false );
		return $data;
	}
	
	
	/**
	 * Performs the actual storage of data to database
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		boolean true on success or insert id
	 * @since		3.0.0
	 */
	public function store()
	{
		$data		= $this->data;	// Grab local copy
		$this->data	= null;			// Reset so we don't keep saving it in
		
		if ( isset( $data->id ) ) {
			$this->_db->where( 'id', $data->id );
			$this->_db->update( 'cnxns', $data );
//			$sql = "UPDATE `cnxns` SET `name` = '{$data->name}', `active` = '{$data->active}', `type` = '{$data->type}', `params` = '{$data->params}' WHERE `id` = {$data->id}";
		}
		else {
			$this->_db->insert( 'cnxns', $data );
//			$sql = "INSERT INTO `cnxns` ( `name`, `active`, `type`, `params` ) VALUES ( '{$data->name}', '{$data->active}', '{$data->type}', '{$data->params}' )";
		}
//		$CI = & get_instance();
//		$CI->db->query( $sql );
		return ( isset( $data->id ) ? true : $this->_db->insert_id() );
	}
	
	
	/**
	 * Passed a bundled array to create the input field
	 * @access		protected
	 * @version		3.0.0.0.3
	 * @param		array		- $field: contains the field data to use
	 * 
	 * @return		array containing original data plus the field
	 * @since		3.0.0
	 */
	protected function _build_form_fields( $field )
	{
		$prefix	=   $this->get( "type" ) . "_";
		switch( $field['type'] ) {
			case 'text':
				$use	= array( 'name' => $field['name'], 'value' => set_value( $field['name'], $field['value'] ), 'id' => 'params.'.$field['lang'] );
				$field['field'] = form_input( $use ) . '</div>';
				break;
			case 'password':
				$use	= array( 'name' => $field['name'], 'value' => set_value( $field['name'], $field['value'] ), 'id' => 'params.'.$field['lang'] );
				$field['field'] = form_password( $use ) . '</div>';
				break;
			case 'hidden':
				$field['field'] = form_hidden( $field['name'], set_value( $field['name'], $field['value'] ) );
				break;
			case 'yesno':
				$options	= array( '1' => lang( "yes" ), '0' => lang( "no" ) );
				$field['field'] = form_dropdown( $field['name'], $options, set_value( $field['name'], $field['value'] ), 'id="params.'.$field['lang'].'"' ) . '</div>';
				break;
			case 'dropdown':
				$options	= $this->_lang( "cnxns.edit.tab." . $field['lang'], true );
				$field['field'] = form_dropdown( $field['name'], $options, set_value( $field['name'], $field['value'] ), 'id="params.'.$field['lang'].'"'  ) . '</div>';
				break;
		}
		return $field;
	}
	
	
	/**
	 * Allows for cross checking for cnxn, then main language array
	 * @access		protected
	 * @version		3.0.0.0.3
	 * @param		string		- $line:  The language line to translate
	 * 
	 * @return		string containing translation hopefully
	 * @since		3.0.0
	 */
	protected function _lang( $line, $options = false )
	{
		$prefix	= $this->get( "type" );
		$lang	= lang( $prefix . "_" . $line . ( $options ? "_options" : "" ) );
		if ( empty( $lang ) ) $lang = lang( $line );
		return $lang;
	}
	
	
	/**
	 * Getter method
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $name: the name of the property to get
	 * 
	 * @return		mixed the value of the property or null if not set
	 * @since		3.0.0
	 */
	public function __get( $name )
	{
		return ( isset( $this->_properties[$name] ) ? $this->_properties[$name] : null );
	}
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $name: the name of the property to set
	 * @param		mixed		- $value: the value to set the property to
	 * 
	 * @since		3.0.0
	 */
	public function __set( $name, $value )
	{
		$this->_properties[$name] = $value;
	}
}