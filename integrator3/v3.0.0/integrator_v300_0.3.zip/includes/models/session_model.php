<?php
/* SECURITY CHECKPOINT */
defined('BASEPATH') OR exit('No direct script access allowed');

class Session_Model extends CI_Model
{
	public $cnxnid		= null;
	public $id			= null;
	public $local		= null;
	public $params		= array();
	public $remote		= null;
	public $timestamp	= null;
	private $_gc_expire	= 2400;
	private $_gc_now	= null;
	private $_gc_prob	= 10;
	
	/**
	 * Data array to bind to for storing or removing data
	 * @version		3.0.0.0.3
	 * @var 		array
	 */
	private $_data		= null;
	
	
	/**
	 * Constructor
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
		
		// Setup Garbage Collection
		$params	= & Params::getInstance();
			$this->set( "_gc_expire", $params->get( "SessionTimeout" ) );
			$this->set( "_gc_now", time() );
		$this->_gc_sessions();
	}
	
	
	/**
	 * Binds data to this object for manipulation
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		array		- $data: an array of data to bind
	 * 
	 * @return		boolean true upon success
	 * @since		3.0.0
	 */
	public function bind( $data = array() )
	{
		if ( ( ! is_array( $data ) ) || ( empty( $data ) ) ) return false;
		$bind	= array();
		
		foreach( $data as $key => $value ) {
			if ( $key == "params" ) $value = (! is_string( $value ) ? json_encode( $value ) : $value );
			$bind[$key] = $value;
		}
		
		$bind['timestamp'] = time();
		
		$this->_data = (object) $bind;
		return true;
	}
	
	
	/**
	 * Checks data bound to be sure its ready for the database
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		boolean true if okay
	 * @since		3.0.0
	 */
	public function check()
	{
		$data = $this->_data;
		if (! is_object( $data ) ) $data = (object) $data;
		if (! isset( $data->cnxnid ) ) {
			_e( debug_backtrace(), 1 );
			_e( 'missing cnxnid', 1 );
			return false;
		}
		if (! isset( $data->remote ) ) {
			_e( 'missing remote id' );
			return false;
		}
		if (! isset( $data->local ) ) $data->local = null;
		if (! isset( $data->timestamp ) ) $data->timestamp = time();
		if (! isset( $data->params ) ) $data->params = json_encode( null );
		if (! is_string( $data->params ) ) $data->params = json_encode( $data->params );
		$this->_data = $data;
		return true;
	}
	
	
	/**
	 * Remove session information
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $type: which form of deletion to perform
	 * 
	 * @return		boolean true upon success
	 * @since		3.0.0
	 */
	public function delete( $type = "presave" )
	{
		switch( $type ):
		// Presave is done to remove duplicates before saving new sessions to the database
		case "presave":
			$data	= $this->_data;
//			$sql	= "DELETE FROM `session` WHERE `cnxnid` = {$data->cnxnid} AND `local` = '{$data->local}'";
//			$query	= $this->db->query( $sql );
//			
			$this->db->delete( 'session', array( 'cnxnid' => $data->cnxnid, 'local' => $data->local ) );
			
			$ci = & get_instance();
			$ci->cnxns_library->remove_session_cookies( $data->cnxnid, $data->local );
// 			$cnxn->remove_session_cookies( $data->local );
			
// 			$cookiefile	= sys_get_temp_dir() . $data->cnxnid . "-" . $data->local . ".tmp";
// 			if ( file_exists( $cookiefile ) ) {
// 				unlink( $cookiefile );
// 			}
			
			// Now check for remote session matches (duplicates - meaning they have already logged in)
			// and remove those and other local session matches
//			$sql	= "SELECT * FROM `session` WHERE `remote` = '{$data->remote}'";
//			$result	= $this->db->query( $sql );
//			
			$result	= $this->db->get_where( 'session', array( 'remote' => $data->remote ) );
			
			if ( $result->num_rows() == 0 ) return true;
			foreach( $result->result() as $row ) {
//				$sql	= "DELETE FROM `session` WHERE `local` = '{$row->local}'";
//				$query	= $this->db->query( $sql );
				$this->db->delete( 'session', array( 'local' => $row->local ) );
			}
			 
			break;
		default:
//			$sql	= "SELECT * FROM `session` WHERE `id` = {$type}";
//			$result	= $this->db->query( $sql );
//			
			$result = $this->db->get_where( 'session', array( 'id' => $type ) );
			
			if ( $result->num_rows() == 0 ) return true;
			foreach( $result->result() as $row ) {
//				$sql	= "DELETE FROM `session` WHERE `id` = {$row->id}";
//				$query	= $this->db->query( $sql );
				$this->db->delete( 'session', array( 'id' => $row->id ) );
				
				$ci = & get_instance();
				$ci->cnxns_library->remove_session_cookies( $row->cnxnid, $row->local );
				
// 				$cookie	= sys_get_temp_dir() . $row->cnxnid . "-" . $row->local . ".tmp";
// 				if ( file_exists( $cookie ) ) unlink( $cookie );
// 				unset ( $cookie );
			}
			
			break;
		endswitch;
		
		return true;
	}
	
	
	/**
	 * Getter function
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $name: generally required (the thing we are looking for)
	 * @param		varies		- $default: the default value if $name doesn't exist
	 * @param		string		- $type: what we are getting.  Possible values include
	 * 								local:  Local variable $this->$name
	 * 
	 * @return		varies could be value, null or object being sought
	 * @since		3.0.0
	 */
	public function get( $name, $default = null, $type = 'local' )
	{
		$return	= null;
		switch ( $type ) {
			case 'local':
				$return = ( isset( $this->$name ) ? $this->$name : $default );
				break;
			default:
				$return	= ( isset( $this->params[$name] ) ? $this->params[$name] : $default );
				break;
		}
		return $return;
	}
	
	
	/**
	 * Gets the public properties of the object
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		boolean		- $public: if false will pull all properties
	 * 
	 * @return		array containing properties
	 * @since		3.0.0
	 */
	public function get_properties( $public = true )
	{
		$vars  = get_object_vars($this);
		
		if($public) {
			foreach ($vars as $key => $value) {
				if ('_' == substr($key, 0, 1)) {
					unset($vars[$key]);
				}
			}
		}
		
        return $vars;
	}
	
	
	/**
	 * Loads a database result object onto the model
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		object		- $data: contains the data straight from the database result row
	 * 
	 * @return		true on success, false on error
	 * @since		3.0.0
	 */
	public function load( $id = null, $by = 'id' )
	{
		if ( $id == null ) return false;
		
		if ( is_array( $id ) ) {
			$where = array();
			foreach ( $id as $k => $v ) {
				$this->db->where( $k, $v );
//				$where[] = "{$k} = '{$v}'";
			}
//			$where = implode( " AND ", $where );
//			$query	= "SELECT * FROM `session` WHERE {$where}";
//			$result	= $this->db->query( $query  );
			$result = $this->db->get( 'session' );
			
		}
		else {
//			$query	= "SELECT * FROM `session` WHERE {$by}=?";
//			$result	= $this->db->query( $query, $id );
			$result = $this->db->get_where( 'session', array( $by => $id ) );
		}
		
		if ( $result->num_rows() == 0 ) {
			return false;
		}
		
		$session	= $result->result_array();
		for( $i=0; $i<count( $session ); $i++) $session[$i]['params'] = json_decode( $session[$i]['params'], true );
		
		// If there are multiple rows return false (should not be possible)
		if ( $result->num_rows > 1 ) return false;
		
		foreach ( array( "id", "cnxnid", "local", "params", "remote", "timestamp" ) as $item ) $this->$item = null;
		
		foreach ( $result->result_array() as $row ) {
			foreach ( $row as $item => $value ) {
				$value = ( $item == 'params' ? json_decode( $value, true ) : $value );
				$this->$item = $value;
			}
		}
		
		return true;
	}
	
	
	/**
	 * Shortcut for saving data to the database
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		true upon success
	 * @since		3.0.0
	 */
	public function save( $data = null )
	{
		if ( $data == null ) {
			$data	= $this->get_properties();
		}
		
		if (! $this->bind( $data ) ) {
			_d( 'Problem binding session data' );
			$this->_data = null;
			return false;
		}
		
		if (! $this->check() ) {
			_d( 'Problem checking session data' );
			$this->_data = null;
			return false;
		}
		
		if (! $this->store() ) {
			_d( 'Problem storing session data' );
			$this->_data = null;
			return false;
		}
		
		return true;
	}
	
	
	/**
	 * Saves bound data to the database
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @since		3.0.0
	 */
	public function store()
	{
		$data = $this->_data;
		$this->_data = null;
		
		if ( isset( $data->id ) ) {
			$this->db->update( 'session', $data, array( 'id' => $data->id ) );
//			$sql = "UPDATE `session` SET `remote` = '{$data->remote}', `local` = '{$data->local}', `cnxnid` = '{$data->cnxnid}', `params` = '{$data->params}', `timestamp` = {$data->timestamp} WHERE `id` = {$data->id}";
		}
		else {
			$this->db->insert( 'session', $data );
//			$sql = "INSERT INTO `session` ( `remote`, `local`, `cnxnid`, `params`, `timestamp` ) VALUES ( '{$data->remote}', '{$data->local}', '{$data->cnxnid}', '{$data->params}', {$data->timestamp} )";
		}
		
//		$this->db->query( $sql );
		return ( isset( $data->id ) ? ( $this->db->affected_rows() > 0 ) : $this->db->insert_id() );
	}
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $name: the name to set
	 * @param		varies		- $value: the value to set
	 * @param		string		- $type: the type to set.
	 * 								local:  Local variable $this->$name
	 * 
	 * @return		varies will return the previous value
	 * @since		3.0.0
	 */
	public function set( $name, $value, $type = 'local' )
	{
		$return	= null;
		
		switch( $type ) {
			case 'local':
				$return = $this->get( $name );
				$this->$name = $value;
				break;
			default:
				$return = $this->get( $name, $value, $type );
				$this->params[$name] = $value;
				break;
		}
		
		return $return;
	}
	
	
	/**
	 * Garbage collector for expired / old sessions
	 * @access		private
	 * @version		3.0.0.0.3
	 * 
	 * @since		3.0.0
	 */
	private function _gc_sessions()
	{
		srand(time());
		
		if ((rand() % 100) < $this->_gc_prob )
		{
			$expire = $this->_gc_now - $this->_gc_expire;

			$this->db->where( "timestamp < {$expire}" );
			$this->db->delete( "session" );
			
			log_message('debug', 'Integrator Session garbage collection performed.');
		}
	}
}