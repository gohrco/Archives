<?php 

/* SECURITY CHECKPOINT */
defined('BASEPATH') OR exit('No direct script access allowed');

$CI			= & get_instance();
$params		= & Params::getInstance();
$license	= & Rishyon::getInstance();

$GLOBALS['license']	= (object) $license;
unset( $license);


/**
 * Params class
 * @access		public
 * @author		Steven
 * 
 * @since		3.0.0
 */
class Params 
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		$CI = & get_instance();
		$CI->load->model( "settings_model" );
	}
	
	
	/**
	 * Define a settings property of the array if not already set
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $property: Contains the property to define
	 * @param		string		- $default: Contains the default value or null if not provided
	 * 
	 * @return		Returns the value of the property
	 * @since		3.0.0
	 */
	public function def( $property, $default = null )
	{
		$model = & $this->_get_model();
		$value =   $model->get( $property, $default );
		return $model->set( $property, $value );
	}
	
	
	/**
	 * Get a property from the settings array
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $property: Contains the property to retrieve
	 * @param		varies		- $default: Contains a default value or null if not provided
	 * 
	 * @return		Returns value of property or value of default if not set
	 * @since		3.0.0
	 */
	public function get($property, $default=null)
	{
		$model = & $this->_get_model();
		return $model->get( $property, $default );
	}
	
	
	/**
	 * Creates a singular instance of the params object
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		instance of Params object
	 * @since		3.0.0
	 */
	public function getInstance()
	{
		static $instance = NULL;
		
		if ( $instance == NULL ) {
			$instance = new self;
		}
		return $instance;
	}
	
	
	/**
	 * Saves the settings model
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		result of save
	 * @since		3.0.0
	 */
	public function save()
	{
		$model = & $this->_get_model();
		return $model->save();
	}
	
	
	/**
	 * Sets a property for the settings array to the given value
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $property: Contains the name of the property to set
	 * @param		varies		- $value: Contains the value of the property to set
	 * 
	 * @return		Sends back the previous value or null if this is new
	 * @since		3.0.0
	 */
	function set( $property, $value = null )
	{
		$model = & $this->_get_model();
		return $model->set( $property, $value );
	}
	
	
	/**
	 * Method to retrieve the model object
	 * @access		private
	 * @version		3.0.0.0.3
	 * 
	 * @return		Settings_model object
	 * @since		3.0.0
	 */
	private function _get_model()
	{
		$CI = & get_instance();
		return $CI->settings_model;
	}
}


/**
 * The license handling class
 * @access		singleton only!
 * @author		Steven
 * @final
 * 
 * @since		3.0.0
 */
final class Rishyon
{
	/**
	 * Contains the info returned by Go Higher or the license local key
	 * @access		private
	 * @since		3.0.0
	 * @var			array
	 */
	private	$info	= array();
	
	
	/**
	 * Constructor method - we want it private to prevent instantiation
	 * @access		private
	 * @version		3.0.0.0.3
	 * 
	 * @since		3.0.0
	 */
	private function __construct()
	{
		$params		= & Params::getInstance();
		$license	=   $this->_check_license( $params->get( 'License', null ), $params->get( 'LocalKey', null ) );
		foreach( $license as $k => $v ) $this->set( $k, $v );
		unset ( $license );
	}
	
	
	/**
	 * Gets an instance of object but only once
	 * @access		public
	 * @version		3.0.0.0.3
	 * 
	 * @return		Rishyon object properties
	 * @since		3.0.0
	 */
	public function getInstance()
	{
		static $instance = null;
		
		if ( is_object( $instance ) ) {
			return false;
		}
		
		if (! is_object( $instance ) ) {
			$instance = new self;
		}
		
		return $instance->get_properties();
	}
	
	
	/**
	 * Getter method
	 * @access		private
	 * @version		3.0.0.0.3
	 * @param		string		- $name: the name of the property to get
	 * @param		string		- $default: the default value to return if not set
	 * 
	 * @return		string value
	 * @since		3.0.0
	 */
	private function get( $name, $default = null )
	{
		return ( isset( $this->info[$name] ) ? $this->info[$name] : $default );
	}
	
	
	/**
	 * Gets the properties of the object
	 * @access		private
	 * @version		3.0.0.0.3
	 * 
	 * @return		array of object properties
	 * @since		3.0.0
	 */
	private function get_properties()
	{
		$data	= array( 'is_valid' => false, 'name' => 'Invalid', 'company' => null, 'email' => null, 'registered' => null, 'duedate' => null, 'cnxns' => 0, 'branding' => true );
		
		if ( ( $data['is_valid'] = $this->is_valid() ) ) {
			$data['name']	= $this->get( 'registeredname' );
			$data['company']	= $this->get( 'companyname' );
			$data['email']		= $this->get( 'email' );
			$data['registered']	= $this->get( 'regdate' );
			$data['duedate']	= $this->get( 'nextduedate', 'Never' );
			$data['cnxns']		= $this->get( 'cnxns', 0 );
			$data['branding']	= $this->get( 'branding', true );
		}
		else {
			$data['error'] = $this->get( 'message', 'The license entered is invalid.' );
		}
		
		return $data;
	}
	
	
	/**
	 * Checks the information to see if it is valid
	 * @access		private
	 * @version		3.0.0.0.3
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	private function is_valid()
	{
		return $this->info['geldige'];
	}
	
	
	/**
	 * Setter method
	 * @access		private
	 * @version		3.0.0.0.3
	 * @param		string		- $name: the name of the property to get
	 * @param		string		- $value: the value to set $name to
	 * 
	 * @return		mixed containing previous value or value to set
	 * @since		3.0.0
	 */
	private function set( $name, $value = null )
	{
		$previous	= ( isset( $this->info[$name] ) ? $this->info[$name] : $value );
		$this->info[$name] = $value;
		return $previous;
	}
	
	
	/**
	 * Checks a license set
	 * @access		private
	 * @version		3.0.0.0.3
	 * @param		string		- $licensekey: the product key
	 * @param		string		- $localkey: the local stored key (if available)
	 * 
	 * @return		array of results
	 * @since		3.0.0
	 */
	private function _check_license( $licensekey = null, $localkey = null )
	{
		$params		= & Params::getInstance();
		$results	= $this->_validate_license( $licensekey, $localkey );
		
		// Test results returned
		$licparts = explode('-', $licensekey);
		if (( $results["status"] == "Active" ) || (($results["status"] == "Expired" ) && ($licparts[0] == 'Owned' ))) {
			// Check to see if a new localkey was sent back
			if ( isset( $results["localkey"] ) ) {
				// Save Updated Local Key to DB
				$params->set( "LocalKey", $results["localkey"], true );
				$params->save();
			}
			$results['geldige'] = true;
		}
		else {
			$results['geldige'] = false;
		}
		
		// Set the default cnxn count
		$results['cnxns']		= $results['geldige'] ? 3 : 0;
		
		// Set default branding (true unless reg before Oct 1 2010)
		$results['branding']	= true;
		
		// If we are invalid, then no addons to go through
		if ( $results['geldige'] === false ) return $results;
		
		$runthru = array( 'addons', 'configoptions' );
		foreach ( $runthru as $run ) {
			if (! isset( $results[ $run ] ) ) continue;
			
			// Run through each (addon / configoptions )
			foreach ( $results[ $run ] as $addon ) {
				
				// These should be an array
				if (! is_array( $addon ) ) continue;
				
				// Be sure 'name' is set before cycling
				if ( isset( $addon['name'] ) ) {
					
					// Branding Removal Check
					// ----------------------
					if ( ( strstr( $addon['name'], 'Branding' ) !== false ) && ( $addon['status'] == 'Active' ) ) {
						
						// If we have set it for renewal check date
						if ( ( $addon['nextduedate'] != '0000-00-00' ) && ( $addon['nextduedate'] < date( 'Y-m-d' ) ) ) continue;
						
						$results['branding'] = false;
					}
					
					// Support and Update Check
					// -------------------------
					if ( ( strstr( $addon['name'], 'Support and Upgrade' ) !== false ) ) {
						
						// Grab the upgrade cutoff date and compare to the addon date
						if ( $this->_upgrade_date() > strtotime( $addon['nextduedate'] ) ) {
							
							// If we are here then the upgrade pack is out of date and they can't run this version!
							$results['geldige'] = false;
							$this->set( 'message', 'Your Support and Upgrade pack expired prior to this release.  Please renew your upgrade pack in order to run this version' );
						}
					}
				}
				
				// Check for addition connections addon
				if ( isset( $addon['Additional Connections'] ) ) $results['cnxns'] = $results['cnxns'] + $addon['Additional Connections'];
			}
		}
		
		return $results;
	}
	
	
	/**
	 * Extracts any addon information stored in the license
	 * @access		private
	 * @version		3.0.0.0.3
	 * @param		string		- $licpart: Contains a string from the licensing data to extract addon info from
	 * 
	 * @return		An array containing the addons in a key => value format
	 * @since		3.0.0
	 */
	private function _extract_addons( $licpart = null )
	{
		if ( $licpart == null ) return array(); // Nothing sent return empty array
		$data	= array();	// Init data array
		$i		= 0;		// Init count
		
		$addonset = explode( "|", $licpart );
		foreach ( $addonset as $addon )
		{
			$addonvars = explode( ";", $addon );
			foreach( $addonvars as $additem )
			{
				$item	= explode( "=", $additem );
				$key	= $item[0];
				unset( $item[0] );
				$value	= implode( "=", $item );
				$data[$i][$key] = $value;
			}
			$i++;
		}
		return $data;
	}
	
	
	/**
	 * Retrieves the upgrade date for the given version
	 * @access		private
	 * @version		3.0.0.0.3
	 * @param		string		- $version: the version to retrieve the date for
	 * 
	 * @return		integer containing unix timestamp of date
	 * @since		3.0.0
	 */
	private function _upgrade_date( $version = INTEGRATOR_VERSION )
	{
		$data = array(
				'3.0.01' => strtotime( '2011-10-15' )
		);
		$value	= ( isset( $data[$version] ) ? $data[$version] : $data['3.0.01'] );
		unset( $data );
		return $value;
	}
	
	
	/**
	 * Handles the unencoding, encoding and retrieval of the license from Go Higher server
	 * @access		private
	 * @version		3.0.0.0.3
	 * @param		string		- $licensekey: Contains the key generated by Go Higher for the product (ie Owned-xxxxx)
	 * @param		string		- $localkey:   Contains the locally stored license if found
	 * 
	 * @return		An array containing the results of the retrieval
	 * @since		3.0.0
	 */
	private function _validate_license( $licensekey, $localkey="" )
	{
		$whmcsurl				=   "http://client.gohigheris.com/";
		$licensing_secret_key	=   ILICSECRET; # Set to unique value of chars
		$checkdate				=   date("Ymd"); # Current date
		$usersip				= ( isset($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : ( isset( $_SERVER['LOCAL_ADDR'] ) ? $_SERVER['LOCAL_ADDR'] : '192.168.1.1' ) );
		$localkeydays			= 8; # How long the local key is valid for in between remote checks
		$allowcheckfaildays		= 5; # How many days to allow after local key expiry before blocking access if connection cannot be made
		$localkeyvalid			= false;
		$remotecheck			= false;
		
		if ($localkey)
		{
			$localkey = str_replace("\n",'',$localkey); # Remove the line breaks
			$localdata = substr($localkey,0,strlen($localkey)-32); # Extract License Data
			$md5hash = substr($localkey,strlen($localkey)-32); # Extract MD5 Hash
				
			if ($md5hash==md5($localdata.$licensing_secret_key))
			{
				$localdata = strrev($localdata); # Reverse the string
				$md5hash = substr($localdata,0,32); # Extract MD5 Hash
				$localdata = substr($localdata,32); # Extract License Data
				$localdata = base64_decode($localdata);
				$localkeyresults = unserialize($localdata);
				$originalcheckdate = $localkeyresults["checkdate"];
				
				if ($md5hash==md5($originalcheckdate.$licensing_secret_key))
				{
					$localexpiry = date("Ymd",mktime(0,0,0,date("m"),date("d")-$localkeydays,date("Y")));
					
					if ($originalcheckdate>$localexpiry)
					{
						$localkeyvalid	= true;
						$results		= $localkeyresults;
						$validdomains	= explode(",",$results["validdomain"]);
						
						if ( $results['nextduedate'] != '0000-00-00' ) {
							$pcs	= explode( "-", $localkeyresults['nextduedate'] );
							$xpry	= date( "Ymd", mktime( 0, 0, 0, $pcs[1], $pcs[2], $pcs[0] ) );
							
							if ( $xpry < $checkdate ) {
								$localkeyvalid = false;
								$localkeyresults["status"] = "License Due";
							}
						}
						
						if (!in_array($_SERVER['SERVER_NAME'], $validdomains))
						{
							$localkeyvalid = false;
							$localkeyresults["status"] = "Invalid";
						}
						
						$validips = explode(",",$results["validip"]);
						
						if (!in_array($usersip, $validips))
						{
							if (! in_array( "*", $validips ) )
							{
								$localkeyvalid = false;
								$localkeyresults["status"] = "Invalid";
							}
						}

						if ( $results["validdirectory"] != BASEPATH.APPPATH )
						{
							$localkeyvalid = false;
							$localkeyresults["status"] = "Invalid";
						}
					}
				}
			}
		}

		if (!$localkeyvalid) {
			$results	= array();
			$postfields["licensekey"] = $licensekey;
			$postfields["domain"] = $_SERVER['SERVER_NAME'];
			$postfields["ip"] = $usersip;
			$postfields["dir"] = BASEPATH.APPPATH;
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $whmcsurl."modules/servers/licensing/verify.php");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $postfields);
			curl_setopt($ch, CURLOPT_TIMEOUT, 30);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			$data = curl_exec($ch);
			$info = curl_getinfo($ch);
			curl_close($ch);
			
			if (!$data) {
				$localexpiry = date("Ymd",mktime(0,0,0,date("m"),date("d")-($localkeydays+$allowcheckfaildays),date("Y")));

				if ($originalcheckdate>$localexpiry) {
					$results = $localkeyresults;
				}
				else {
					$results["status"] = "Remote Check Failed";
					return $results;
				}
			}
			else {
				preg_match_all('/<(.*?)>([^<]+)<\/\\1>/i', $data, $matches);
				$results = array();

				foreach ($matches[1] AS $k=>$v)	{
					$results[$v] = $matches[2][$k];
				}
				
				$remotecheck = true;
			}
				
				
			$licparts = explode('-', $licensekey);
			if (( $results["status"] == "Active" ) || (($results["status"] == "Expired" ) && ($licparts[0] == 'Owned' )))
			{
				$results["checkdate"] = $checkdate;
				$data_encoded = serialize($results);
				$data_encoded = base64_encode($data_encoded);
				$data_encoded = md5($checkdate.$licensing_secret_key).$data_encoded;
				$data_encoded = strrev($data_encoded);
				$data_encoded = $data_encoded.md5($data_encoded.$licensing_secret_key);
				$data_encoded = wordwrap($data_encoded,80,"\n",true);
				$results["localkey"] = $data_encoded;
			}
		}
		if ($remotecheck) $results["remotecheck"] = true;
		
		unset($postfields,$data,$matches,$whmcsurl,$licensing_secret_key,$checkdate,$usersip,$localkeydays,$allowcheckfaildays,$md5hash);
		
		$results['addons']			= ( isset( $results['addons'] ) ? $this->_extract_addons( @$results['addons'] ) : array() );
		$results['configoptions']	= ( isset( $results['configoptions'] ) ? $this->_extract_addons( $results['configoptions'] ) : array() );
		return $results;
	}
}