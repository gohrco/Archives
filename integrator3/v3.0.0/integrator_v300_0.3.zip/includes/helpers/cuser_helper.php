<?php 

/* SECURITY CHECKPOINT */
defined('BASEPATH') OR exit('No direct script access allowed');

$cuser	= & Cuser::getInstance();

/**
 * Common User Object class
 * @access		public
 * @author		Steven
 * 
 * @since		3.0.0
 */
class Cuser
{
	/**
	 * Builds a form for creating or editing a user based on the common user object
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		integer		- $cnxn_id: the connection id of the user to create / modify
	 * @param		boolean		- $is_new: if this is a new user, we must require diff fields
	 * 
	 * @return		array of form items
	 * @since		3.0.0 
	 */
	public function build_form( $cnxn_id, $is_new = false )
	{
		// Final form
		$form			= array();
		
		// Build the form for the common user library
		$full_form		= $this->_complete_form();
		
		// Grab the cnxn library to filter form by
		$cnxn_lib	= get_cnxn_library( $cnxn_id );
		$form		= $cnxn_lib->cuser_fields( $full_form, $is_new );
		
		return $form;
	}
	
	
	/**
	 * Completes the typical required fields for a cuser object based on cnxn settings
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		int		- $cnxn_id: contains the originating cnxn_id
	 * 
	 * @since		3.0.0
	 */
	public function complete( $cnxn_id )
	{
		$cycle	= array( 'fullname', 'firstname', 'lastname', 'username' );
		
		foreach ( $cycle as $item ) {
			if (! $this->get( $item, false ) ) {
				$method = '_create_' . $item;
				$this->set( $item, $this->$method( $cnxn_id ) );
			}
		}
	}
	
	
	/**
	 * Creates a singular instance of the Cuser object
	 * @access		public
	 * @version		3.0.0.0.3
	 * $param		varies		- $new: true forces new, an array forces new and sets data, false (default) retrieves instance
	 * 
	 * @return		instance of Cuser object
	 * @since		3.0.0
	 */
	public function getInstance( $new = false )
	{
		static $instance = NULL;
		
		if ( is_array( $new ) ) {
			$instance	= new self( $new );
			$new		= false;
		}
		
		if ( ( $instance == NULL ) || ( $new ) ) {
			$instance = new self;
		}
		
		return $instance;
	}
	
	
	/**
	 * Getter method
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $name: the name of the property to get
	 * @param		mixed		- $default: the default value if not set
	 * 
	 * @return		mixed depending on value
	 * @since		3.0.0
	 */
	public function get( $name, $default = null )
	{
		if ( (! isset( $this->$name ) ) || ( empty( $this->$name ) ) ) {
			if ( (! isset( $this->_properties[$name] ) ) || ( empty( $this->_properties[$name] ) ) ) {
				return $default;
			}
			else {
				return $this->_properties[$name];
			}
		}
		else {
			return $this->$name;
		}
		//return ( (! isset( $this->$name ) ) || ( empty( $this->$name ) ) ) ? $default : $this->$name;
	}
	
	
	/**
	 * Get properties of the object
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		boolean		- $public: true for public only, false for all
	 * 
	 * @return		array containing properties
	 * @since		3.0.0
	 */
	public function get_properties( $public = true )
	{
		$vars = get_object_vars( $this );
		
		if ( $public ) {
			$data	= array();
			foreach ( $vars as $k => $v ) {
				if ( substr( $k, 0, 1 ) == "_" ) continue;
				$data[$k] = $v;
			}
			return $data;
		}
		else { 
			return $vars;
		}
	}
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $name: the name of the property to set
	 * @param		mixed		- $value: the value to set it to
	 * 
	 * @since		3.0.0
	 */
	public function set( $name, $value )
	{
		$this->$name = $value;
	}
	
	
	/**
	 * Set properties of the object
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		array		- $data: contains the properties and values to set
	 * 
	 * @since		3.0.0
	 */
	public function set_properties( $data = array() )
	{
		foreach( $data as $k => $v )
		{
			if ( in_array( $k, array( 'apiusername', 'apipassword', '_c' ) ) ) continue;
			$this->set( $k, $v );
		}
	}
	
	
	/**
	 * **********************************************************************
	 * OBJECT DECLARATIONS AND MAGIC METHODS BELOW
	 * **********************************************************************
	 */
	
	public	$id				= null;
	public	$fullname		= null;
	public	$firstname		= null;
	public	$lastname		= null;
	public	$username		= null;
	public	$email			= null;
	public	$password		= null;
	public	$address1		= null;
	public	$address2		= null;
	public	$city			= null;
	public	$state			= null;
	public	$postal			= null;
	public	$country		= null;
	public	$phone			= null;
	public	$companyname	= null;
	public	$active			= true;
	public	$update			= array();
	
	private	$_properties	= array();
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		array		- $data: if set provides properties to set
	 * 
	 * @since		3.0.0
	 */
	public function __construct( $data = array() )
	{
		if ( (! empty( $data ) ) && ( is_array( $data ) ) ) {
			$this->set_properties( $data );
		}
	}
	
	
	/**
	 * Getter magic
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $name: the name of the property to get
	 * 
	 * @return		mixed value if set, false if not
	 * @since		3.0.0
	 */
	public function __get( $name )
	{
		return ( isset( $this->_properties[$name] ) ? $this->_properties[$name] : false );
	}
	
	
	/**
	 * Setter magic
	 * @access		public
	 * @version		3.0.0.0.3
	 * @param		string		- $name: the name of the property to set
	 * @param		mixed		- $value: the value being set
	 * 
	 * @since		3.0.0
	 */
	public function __set( $name, $value )
	{
		if ( substr( $name, 0, 3 ) == 'new' ) {
			$this->update[substr( $name, 3 )] = $value;
			return;
		}
		$this->_properties[$name] = $value;
	}
	
	
	/**
	 * Builds a complete form based on public settings
	 * @access		private
	 * @version		3.0.0.0.3
	 * 
	 * @return		array of all form elements
	 * @since		3.0.0
	 */
	private function _complete_form()
	{
		$form	= $this->get_properties();
		
		$order	= 0;
		foreach ( $form as $item => $value ) {
			$form[$item]	= array();
			$form[$item]['value']		= $value;
			$form[$item]['order']		= ( $order++ * 10 );
			$form[$item]['type']		= 'text';
			$form[$item]['validation']	= 'xss_clean';
		}
		
		foreach ( $form as $item => $vals ) {
			if ( $item == 'email' )		$form[$item]['validation']	= 'valid_email';
			if ( $item == 'password' )	$form[$item]['type']		= 'password';
		}
		
		if ( isset( $form['country'] ) ) $form['country']['type'] = 'dropdown-country';
		
		return $form;
	}
	
	
	/**
	 * **********************************************************************
	 * PRIVATE METHODS FOR CREATING CUSER FIELDS BELOW
	 * **********************************************************************
	 */
	
	
	/**
	 * Creates a fullname based on cnxn settings
	 * @access		private
	 * @version		3.0.0.0.3
	 * @param		int		- $cnxn_id: contains the originating cnxn_id
	 * 
	 * @return		string containing created fullname
	 * @since		3.0.0
	 */
	private function _create_fullname( $cnxn_id )
	{
		$cnxn	= cnxn( $cnxn_id );
		$method	= $cnxn->get( 'storename', 'firstlast', 'users' );
		$user	= null;
		$data	= $this->get_properties();
		
		switch( $method ) :
		
		case 'lastfirstco':
			$user = ( isset( $data['companyname'] ) ? ' (' . $data['companyname'] . ')' : null );
			
		case 'lastfirst':
			$user = $data['lastname'] . ' ' . $data['firstname'] . $user;
			break;
			
		case 'firstlastco':
			$user = ( isset( $data['companyname'] ) ? ' (' . $data['companyname'] . ')' : null );
			
		case 'firstlast':
		default:
			$user = $data['firstname'] . ' ' . $data['lastname'] . $user;
			break;
		
		endswitch;
		
		return $user;
		
	}

	
	/**
	 * Creates a firstname based on the fullname
	 * @access		private
	 * @version		3.0.0.0.3
	 * @param		int		- $cnxn_id: contains the originating cnxn_id
	 * 
	 * @return		string containing created firstname
	 * @since		3.0.0
	 */
	private function _create_firstname( $cnxn_id )
	{
		$fullname	= $this->get( 'fullname', null );
		$names		= explode( ' ', $fullname );
		
		return ( count( $names ) > 1 ? $names[0] : $fullname );
		
		
	}
	
	
	/**
	 * Creates a lastname based on the fullname
	 * @access		private
	 * @version		3.0.0.0.3
	 * @param		int		- $cnxn_id: contains the originating cnxn_id
	 * 
	 * @return		string containing created lastname
	 * @since		3.0.0
	 */
	private function _create_lastname( $cnxn_id )
	{
		$cnxn		= cnxn( $cnxn_id );
		$fullname	= $this->get( 'fullname', null );
		$names		= explode( ' ', $fullname );
		$firstname	= array_shift( $names );
		
		if ( count( $names ) > 0 ) {
			return implode( ' ', $names );
		}
		
		if ( ( $lastname = $cnxn->get( 'defaultlastname', false, 'users' ) ) ) {
			return $lastname;
		}
		
		return null;
	}
	
	
	/**
	 * Creates a username based on cnxn settings
	 * @access		private
	 * @version		3.0.0.0.3
	 * @param		int		- $cnxn_id: contains the originating cnxn_id
	 * 
	 * @return		string containing created username
	 * @since		3.0.0
	 */
	private function _create_username( $cnxn_id )
	{
		$cnxn	= cnxn( $cnxn_id );
		$method	= $cnxn->get( 'storeusername', 'random', 'users' );
		$data	= $this->get_properties();
		$user	= null;
		
		switch( $method ) :
		case 'first.last':
			$user = $data['firstname'] . ' ' . $data['lastname'];
			break;
		case 'last.first':
			$user = $data['lastname'] . ' ' . $data['firstname'];
			break;
		case 'flastname':
			$user = substr( $data['firstname'], 0, 1 ).$data['lastname'];
			break;
		case 'firstnamel':
			$user = $data['firstname'].substr( $data['lastname'], 0, 1 );
			break;
		case 'firstname':
		case 'lastname':
			$user = $data[$method];
			break;
		case 'custom':
			$field	= $cnxn->get( 'customfield', 'email', 'users' );
			if ( isset( $data[$field] ) ) {
				$user	= $data[$field];
				break;
			}
		default:
		case 'random':
			for ($i=0; $i<12; $i++) {
				$d = rand(1,30)%2;
				$user .= ( $d ? chr(rand(65,90)) : chr(rand(48,57)));
			}
			$user = ucfirst(strtolower($user));
			break;
		endswitch;
		
		return $user;
	}
}