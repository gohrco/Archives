<?php

/**
 * Permits forced use of SSL on log in / log out
 * @version		3.0.0.0.3
 * @param		string		- $uri: a location uri (internal or otherwise)
 * @param		string		- $method: method of redirection to use
 * @param		mixed		- $http_response_code: either integer for response code or array of form fields
 * 
 * @since		3.0.0
 */
function cnxn_redirect( $uri = '', $method = 'location', $http_response_code = 302 )
{
	$params = & Params :: getInstance();
	$usessl =   $params->get( 'UseSSL', 0 );
	
	// Catch local references and create full url
	if ( ! preg_match('#^https?://#i', $uri)) {
		$uri	= site_url($uri);
	}
	
	$myuri	= new Uri( $uri );
	$myuri->setScheme( $usessl == 1 ? 'https' : ( $usessl == 0 ? 'http' : $myuri->getScheme() ) );
	$uri	= $myuri->toString();
	
	return redirect( $uri, $method, $http_response_code );
}


/**
 * Overridden redirect function
 * @version		3.0.0.0.3
 * @param		string		- $uri: the uri to go to
 * @param		string		- $method: the method to use (location, refresh or form)
 * @param		mixed		- $http_response_code: can be integer OR array of form fields
 * 
 * @since		3.0.0
 */
function redirect($uri = '', $method = 'location', $http_response_code = 302)
{
	// Catch local references and create full url
	if ( ! preg_match('#^https?://#i', $uri)) {
		$uri	= site_url($uri);
	}
	
	// Store the userlog in the session before continuing
	userredirect();
	
	// Change methods
	switch($method)
	{
		case 'form'		:		// Form Redirection
			$field = null;
			
			foreach ( $http_response_code as $name => $value ) {
				$field .= "<input type='hidden' name='{$name}' value='{$value}' />";
			}
			
			$output = <<< OUTPUT
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<body>
<form action="{$uri}" method="post" name="frmlogin" id="frmlogin">
		{$field}
</form>
<script language="javascript"><!--
setTimeout ( "autoForward()", 0 );
function autoForward() {
	document.forms['frmlogin'].submit()
}
//--></script></body></html>
OUTPUT;
			
			// Set the output to the output class
			$OUT =& load_class('Output', 'core');
			$OUT->set_output( $output );
			
			return;
			break;
		case 'refresh'	:		// Refresh redirection
			header("Refresh:0;url=".$uri);
			break;
		case 'oframe'	:		// Used to kick OUT of an iframe
			
			$output = <<< OUTPUT
<html>
<body>
<script language="javascript" type="text/javascript">
self.parent.location="{$uri}";
</script> 
</body>
</html>
OUTPUT;
			
			// Set the output to the output class
			$OUT =& load_class('Output', 'core');
			$OUT->set_output( $output );
			
			return;
			
			break;
		case 'iframe'	:		// Used to log in using an iframe
			
			$output = '<iframe src="' . $uri . '" width="1024" height="768">You have an old browser!</iframe>';
			
			return $output;
			
			break;
		default			:		// Location redirection
			header("Location: ".$uri, TRUE, $http_response_code);
			break;
	}
	exit;
}