<?php

if (! function_exists( 'userlog' ) ) {
	function userlog( $method, $data, $c = null ) {
		$CI = & get_instance();
		$CI->load->model( 'userlog_model' );
		$CI->userlog_model->action( $method, $data, $c );
	}
}


if (! function_exists( 'userredirect' ) ) {
	function userredirect() {
		$CI = & get_instance();
		$CI->load->model( 'userlog_model' );
		$CI->userlog_model->redirect();
	}
}


if (! function_exists( 'userwrite' ) ) {
	function userwrite( $task = null ) {
		$CI = & get_instance();
		$CI->load->model( 'userlog_model' );
		$CI->userlog_model->write( $task );
	}
}