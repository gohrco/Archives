<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.3 ( $Id: database.php 419 2012-03-01 03:14:09Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the database configuration file for the Integrator
 *  
 */

/*-- Security Protocols --*/
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*-- Security Protocols --*/

/*-- File Inclusions --*/
if ( file_exists( BASEPATH . 'configuration.php' ) ) {
	include( BASEPATH . 'configuration.php' );
}
else {
	show_error( 'Your configuration file is missing!', '404' );
}
/*-- File Inclusions --*/

$check		= array( 
				array(	'n' => 'hostname',	'd' => null,				'r' => true ),
				array(	'n' => 'username',	'd' => null,				'r' => true ),
				array(	'n' => 'password',	'd' => null,				'r' => true ),
				array(	'n' => 'database',	'd' => null,				'r' => true ),
				array(	'n'	=> 'port',		'd' => '3306',				'r'	=> false ),
				array(	'n' => 'dbdriver',	'd' => 'mysql',				'r' => false ),
				array(	'n' => 'dbprefix',	'd' => '',					'r' => false ),
				array(	'n' => 'pconnect',	'd' => true,				'r' => false ),
				array(	'n' => 'db_debug',	'd' => true,				'r' => false ),
				array(	'n' => 'cache_on',	'd' => false,				'r' => false ),
				array(	'n' => 'cachedir',	'd' => '',					'r' => false ),
				array(	'n' => 'char_set',	'd' => 'utf8',				'r' => false ),
				array(	'n' => 'dbcollat',	'd' => 'utf8_general_ci',	'r' => false ),
				array(	'n' => 'swap_pre',	'd' => '#__',				'r' => false ),
				array(	'n' => 'autoinit',	'd' => true,				'r' => false ), 
				array(	'n' => 'stricton',	'd' => false,				'r' => false )
);

$default	= array();
foreach ( $check as $c ) {
	$item = 'db_' . $c['n'];
	if ( $c['r'] && (! isset( $$item ) ) ) {
		show_error( 'Your configuration is incomplete (' . $item. ')', '404' );
	}
	
	if ( isset( $$item ) ) {
		$default[$c['n']] = $$item;
	}
	else {
		$default[$c['n']] = $c['d'];
	}
}

if (! isset( $active_group ) ) $active_group = 'default';
if (! isset( $active_record ) ) $active_record = true;

$db = array( 'default' => $default );
