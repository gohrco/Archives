INSERT INTO `__DBPREFIX__settings` (`key`, `value`) VALUES
('PasswordText', 'This password is insufficient'),
('PasswordStrength', '0'),
('DefaultCountry', 'US')
('LogPurge', '');

-- command split --

UPDATE `__DBPREFIX__settings` SET `value`='3.0.0.0.2' WHERE `key` = 'Version';