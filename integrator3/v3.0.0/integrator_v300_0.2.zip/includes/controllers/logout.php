<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.2 ( $Id: logout.php 410 2012-02-28 02:50:48Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the logout controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Entry point for configuration and administration of application
 * @version		3.0.0.0.2
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Logout extends MY_Controller
{
	/**
	 * Constructor class
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->language( "logout" );
		
		// --- BEGIN: ORIGIN
		$origin = find_origin( 'logout' );
		
		$this->set( "origin", $origin );
		// --- END:   ORIGIN
	}
	
	
	/**
	 * Handles a completed log out event
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param 		string		- $session_id: contains an encoded session id (if applicable)
	 * @param 		string		- $session_name: contains an encoded session name (if applicable)
	 */
	public function complete( $session_id = null, $session_name = null )
	{
		$login_stack			= $this->get( "logout" );
		$cnxnid					= $login_stack['next'];
		$login_stack['done'][]	= $cnxnid;
		$this->set( "logout", $login_stack );
		
		$cnxn_lib		= get_cnxn_library( $cnxnid );
		$cnxn_lib->remove_session_cookies();
		cnxn_redirect('logout/redirect', 'refresh');
	}
	
	
	/**
	 * Handles the initial log out encounter with the Integrator
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param 		integer		- $sending_id: if set, contains the id of a connection already logged out
	 * 
	 * @since		3.0.0
	 */
	public function index( $sending_id = null )
	{
		// If we are sending an ID, overwrite the origin just in case they dont match
		if ( $sending_id != null ) {
			if ( cnxn ( $sending_id ) ) {
				$origin = $sending_id;
				//$this->set( 'origin', $origin );
				$this->set( 'logoutorigin', $origin );
			}
		}
		else {
			$origin = find_origin( 'logout' );
			$this->set( 'logoutorigin', $origin );
		}
		
		// Check for global user disable and return back over to origin login landing url
		$params = & Params :: getInstance();
		
		if ( $params->get( 'EnableUser', false ) == false ) {
			$cnxn = get_cnxn_library( find_origin() );
			$url	= $cnxn->get_login_landing_url();
			debug( 'msg.error.userdisabled' );
			redirect( $url, 'redirect' );
		}
		
		// Build the logout stack
		if ( ( $logout_stack = $this->_build_logout_stack() ) === FALSE ) {
			$cnxn = get_cnxn_library( find_origin() );
			$url	= $cnxn->get_login_landing_url();
			debug( 'msg.error.cnxnsdisabled' );
			redirect( $url, 'redirect' );
		}
		
		// The Sending Id indicates we have logged out at the sending id location already
		//		Redirect to success method to register completed log out
		if ( $sending_id != null ) {
			
			$redirect_url = "logout/complete/{$sending_id}";
			
			// Pull the sending id off the todo list (not necessarily the origin id - first in line)
			foreach( $logout_stack as $k => $item ) {
				if ( $item == $sending_id ) {
					unset( $logout_stack[$k] );
					break;
				}
			}
			
			$cnxn_lib		= get_cnxn_library( $sending_id );
			$cnxn_lib->remove_session_cookies();
		}
		else {
			$redirect_url = 'logout/redirect';
		}
		
		$this->set( "logout", array( "todo" => $logout_stack, "done" => array(), "next" => ( $sending_id != null ? $sending_id : null ) ) );
		
		/**
		 * See what method to use to display logout routine - iframe or standard
		 */
		$redirect_method	= ( $params->get( 'DisplayLogin' ) ? 'iframe' : 'refresh' );
		
		// Build the embed page
		if ( $redirect_method == 'iframe' ) {
			// Retrieve the visual cnxn id (MY_Controller)
			$_v = $this->get_visual_cnxn( $sending_id );
			
			$this->local_render( 'logout', $_v );
			
			$msg	= lang( $params->get( 'LogoutMsg' ) );
			$msg	= ( empty( $msg ) ? $params->get( 'LogoutMsg' ) : $msg );
			
			// Set empty holders
			$this->data['error']			= '';
			$this->data['header_includes']	= '';
			$this->data['redirectmessage']	= $msg;
				
		}
		
		$output = cnxn_redirect( $redirect_url, $redirect_method );
		
		if ( $redirect_method == 'iframe' ) {
			
			// Set the output to the output class
			$this->data['iframe'] = $output;
			$this->template
					->set_partial( 'body',	'client/iframe' )
					->build( 'client', $this->data );
			}
	}
	
	
	/**
	 * Redirects the user to the next connection to log in with
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function redirect()
	{
		$params	= & Params :: getInstance();
		
		// We are pulling the next connection to redirect to - if FALSE we return to origin
		if ( ( $cnxnid = $this->_get_logout_connection_id() ) === FALSE ) {
			//$cnxnid		= find_origin( 'logout' );
			$cnxnid		= $this->get( 'logoutorigin' );
			$cnxn_lib	= get_cnxn_library( $cnxnid );
			
			$return_url	= $cnxn_lib->get_logout_landing_url();
			
			// Accomodate login display
			if ( $params->get( 'DisplayLogin' ) ) {
				return redirect( $return_url, 'oframe' );
			}
			else {
				redirect( $return_url, 'redirect' );
			}
		}
		
		// Pull the appropriate connection library
		if ( ( $cnxn_lib = get_cnxn_library( $cnxnid ) ) === FALSE ) {
			// @TODO:  log error
			show_error( "CANT FIND LIBRARY", 200 );
//			redirect('login/redirect', 'refresh');
		}
		
		cnxn_redirect( $cnxn_lib->get_logout_url(), 'refresh' );
	}
	
	
	/**
	 * Creates the logout stack from the connection stack, setting the authenticated connection as first
	 * @access		private
	 * @version		3.0.0.0.2
	 * @param		array		- $connection_stack: contains the assembled connection stack
	 * 
	 * @return		array of integers referencing the cnxn ids to log in to
	 * @since		3.0.0
	 */
	private function _build_logout_stack()
	{
		$logout_stack	= array();
		$cnxns			= get_cnxns();
		
		foreach( $cnxns as $cnxn ) {
			if ( $cnxn->get( 'active', false ) == false ) continue;
			if ( $cnxn->get( "processlogin", "always", "users" ) == "never" ) continue;
			$logout_stack[] = $cnxn->get( "id" );
		}
		
		return (! empty( $logout_stack ) ? $logout_stack : false );
	}
	
	
	/**
	 * Takes the next connection off the stack, setting the new stack and returning shifted cnxn id
	 * @access		private
	 * @version		3.0.0.0.2
	 * 
	 * @return		integer containing 
	 * Enter description here ...
	 */
	private function _get_logout_connection_id()
	{
		$login_stack	= $this->get( "logout" );
		if ( $login_stack["todo"] == NULL ) return false;
		$nextid			= array_shift($login_stack["todo"]);
		$login_stack["next"] = $nextid;
		$this->set( "logout", $login_stack );
		return $nextid;
	}
	
	
	/**
	 * Wipes session data before sending back on error or completion of login routine
	 * @access		private
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	private function _kill_session()
	{
		$this->set( "origin", null );
		$this->set( "credentials", null );
		$this->set( "authentication", null );
	}
	
	
	
}

?>