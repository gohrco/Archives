<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.2 ( $Id: usermgr.php 418 2012-02-29 21:42:14Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the user manager controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * User Manager Controller
 * @version		3.0.0.0.2
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Usermgr extends Admin_Controller
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::Admin_Controller();
		$this->load->language( 'usermgr' );
	}
	
	
	/**
	 * Creates a new user on the selected connection
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		integer		- $cnxnid: the selected connection (if there yet)
	 * 
	 * @since		3.0.0
	 */
	public function create( $cnxnid = null, $user = null )
	{
		$fields		= & $this->fields_library;
		
		// Find out if a cnxn has been selected yet
		if ( $cnxnid == null ) {
			$fields->load( 'usermgr/modify/cnxn' );
			
			// Validate for a cnxnid first and redirect if valid
			$this->form_validation->set_rules( $fields->validation() );
			
			if ( $this->form_validation->run() == TRUE ) {
				redirect('usermgr/create/' . get_var( 'cnxnid', 'post' ), 'refresh');
			}
			else {
				// No cnxnid means we must pick one at step 1
				$this->data['action']	= 'usermgr/create';
				$this->data['submit']	= 'btn.selcnxn';
			}
		}
		// We have a valid cnxnid
		else {
			$cnxn_lib	=   get_cnxn_library( $cnxnid );
			$api		=   get_api( $cnxnid );
			
//			$fields->load( 'usermgr/create/userfields', $cnxn_lib->get( 'type' ) );
			
			$cuser		= & Cuser::getInstance();
			$fields->build( $cuser->build_form( $cnxnid, true ) );
			
			$this->form_validation->set_rules( $fields->validation() );
			
			if ( $this->form_validation->run() == true ) {
				$fields->set_values( $this->input->post() );
				
				// Set fields into the common user object
				$cuser	= & Cuser::getInstance( true );
				$cuser->set_properties( $fields->get_values() );
				
				// Validate First
				if ( ( $result = $api->user_validation_on_create() ) !== true ) {
					$this->data['error_message'] = $result;
				}
				else {
					// Create if we are still here
					if ( ( $result = $api->user_create() ) === true ) {
						$this->session->set_flashdata('success_message', lang( 'msg.success.usercreated' ) );
						redirect( 'usermgr/find/' . base64_encode( get_var( 'email', 'post' ) ), 'refresh' );
					}
					else {
						$this->data['error_message']	= $result;
					}
				}
			}
			
			if ( $user != null ) {
				$user = base64_decode( $user );
				$fields->set( (is_email($user) ? 'email':'username'), $user );
			}
			
			$this->data['action']	= 'usermgr/create/' . $cnxnid;
			$this->data['submit']	= 'btn.createuser';
		}
		
		$this->data	+= $fields->render();
		
		$this->template
					->set_partial( 'body', 'form' )
					->build('admin', $this->data);
	}
	
	
	/**
	 * Find a user across all connections
	 * @access		public
 	 * @version		3.0.0.0.2
 	 * @param		base64 string	- $user: user to find if entered
 	 * 
 	 * @since		3.0.0
	 */
	public function find( $user = null )
	{
		$fields		= & $this->fields_library;
		$results	=   array();
		
		if ( $user == null ) {
			$fields->load( 'usermgr/find' );
			
			$this->form_validation->set_rules( $fields->validation() );
			
			if ( $this->form_validation->run() == true ) {
				redirect( 'usermgr/find/' . base64_encode( get_var( 'user', 'post' ) ), 'refresh' );
			}
			
			$this->data['action']	= 'usermgr/find';
			$this->data['submit']	= 'btn.finduser';
		}
		else {
			// Place the user in the Cuser object
			$cnxns		= $this->_build_active_cnxns();
			
			$results	= array();
			foreach ( $cnxns as $cnxn_lib ) {
				// Prep the cuser object
				$cnxn_id	= $cnxn_lib->get( 'cnxn_id' );
				
				$find		= $this->_cuser_place( $user );
				
				// Grab the API and make the call
				$api	= get_api( $cnxn_id );
				$api->user_find();
				
				// Grab the results
				$results[$cnxn_id] = (object) $this->_cuser_retrieve(array( 'cnxn_id' => $cnxn_id, 'user' => $find ) );
			}
			
			$this->data['results']	= $results;
			$this->data['user']		= ( isset( $find ) ? $find : null );
		}
		
		$this->data	+= $fields->render();
		
		$this->template
					->set_partial( 'body', 'usermgr/' . ( $user == null ? 'modify' : 'result' ) )
					->build('admin', $this->data);
	}
	
	
	/**
	 * View the user log
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		base64 string	- $user: user to filter by if entered
	 * 
	 * @since		3.0.0
	 */
	public function log( $page = 1, $limit = 20, $user = null, $order = null, $asc = false )
	
	{
		if ( $user == '_' ) $user = null;
		if ( $limit == 0 ) $limit = 10;
		if ( $page == 0 ) $page = 1;
		
		$asc	= (bool) $asc;
		
		$model	= $this->get_model( 'userlog_model', '' );
		$user	= ( $user != null ? base64_decode( $user ) : null );
		$order	= ( $order != null ? $order : 'timestamp' );
		$start	= ( $page <= 1 ? 0 : ( ( $page - 1 ) * $limit ) - 0 );
		
		if (! ($log = $model->load_by_email( $user, $order, $asc, $start, $limit ) ) ) {
			$log = array();
		}
		
		$this->_paged_footer( $page, $limit, $user, $order, $asc );
		
		$this->data['logs']	= $log;
		$this->template
					->set_partial( 'body', 'usermgr/log' )
					->build('admin', $this->data);
	}
	
	
	/**
	 * Modify a user
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		integer			- $cnxnid: the cnxn id if selected
	 * @param		base64 string	- $user: username or email if entered
	 * 
	 * @since		3.0.0
	 */
	public function modify( $cnxnid = null, $user = null )
	{
		$fields		= & $this->fields_library;
		
		// Find out if a cnxn has been selected yet
		if ( $cnxnid == null ) {
			$fields->load( 'usermgr/modify/cnxn' );
			
			// Validate for a cnxnid first and redirect if valid
			$this->form_validation->set_rules( $fields->validation() );
			
			if ( $this->form_validation->run() == TRUE ) {
				redirect('usermgr/modify/' . get_var( 'cnxnid', 'post' ), 'refresh');
			}
			else {
				// No cnxnid means we must pick one at step 1
				$step = 1;
				$this->data['action']	= 'usermgr/modify';
				$this->data['submit']	= 'btn.selcnxn';
			}
		}
		// We have a valid cnxnid
		elseif ( $user == null ) {
			// If we have a cnxnid, we are on step 2
			$step		=   2;
			$cnxn_lib	=   get_cnxn_library( $cnxnid );
			
			$fields->load( 'usermgr/modify/user' );
			$fields->set_cnxntype( $cnxn_lib->get( 'type' ) );
			
			$this->data['cnxnid'] = $cnxnid;
			
			$this->form_validation->set_rules( $fields->validation() );
			if ( $this->form_validation->run() == TRUE ) {
				// Prep the cuser object
				$this->_cuser_place( get_var( 'user', 'post' ), false );
				
				// Find the user
				$api		= get_api( $cnxnid );
				$api->user_find();
				
				// No errors so redirect to modify
				if (! ( $error = $this->_cuser_errors( true ) ) ) {
					redirect( 'usermgr/modify/' . $cnxnid . '/' . base64_encode( get_var( 'user', 'post' ) ), 'refresh' );
				}
				
				$this->data['error_message'] = $error;
			}
			
			$this->data['action']	= 'usermgr/modify/' . $cnxnid;
			$this->data['submit']	= 'btn.finduser';
			
		}
		// We have a cnxnid and user selected
		else {
			$step		=   3;
			$cnxn_lib	=   get_cnxn_library( $cnxnid );
			$api		=   get_api( $cnxnid );
			
			// Prep the cuser object
			$this->_cuser_place( $user );
			$api->user_find();
			
			if ( $error = $this->_cuser_errors( true ) ) {
				$this->session->set_flashdata('error_message', $error);
				redirect( 'usermgr/modify/' . $cnxnid, 'refresh' );
			}
			
			$cuser		= & Cuser::getInstance();
			$fields->build( $cuser->build_form( $cnxnid ) );
			
			$this->form_validation->set_rules( $fields->validation() );
			
			if ( $this->form_validation->run() == true ) {
				$fields->set_values( $this->input->post() );
				$cuser	= & Cuser::getInstance( true );
				
				// Decode the username
				$uval	= base64_decode( $user );
				
				// Set fields into the common user object
				$cuser->set_properties( array( 'update' => $fields->get_values() ) );
				$cuser->set( (is_email( $uval ) ? 'email' : 'username' ), $uval );
				
				// Validate First
				if ( ( $result = $api->user_validation_on_update() ) === true ) {
					
					// Update if we are still here
					if ( ( $result = $api->user_update() ) == true ) {
						$this->session->set_flashdata('success_message', lang( 'msg.success.userupdated' ) );
						
						$update	= $cuser->get( 'update' );
						$user	= base64_encode( $update[( is_email( $uval ) ? 'email' : 'username' )] );
						
						redirect( 'usermgr/find/' . $user, 'refresh' );
					}
					else {
						$this->data['error_message']	= sprintf( lang( 'msg.error.userupdate' ), $result );
					}
				}
				// If API user validation failed set message
				else {
					$this->data['error_message'] = $result;
				}
			}
			
			$this->data['action']	= 'usermgr/modify/' . $cnxnid . '/' . $user;
			$this->data['submit']	= 'btn.updateuser';
		}
		
		$this->data	= array_merge( $this->data, $fields->render() );
		
		$this->template
					->set_partial( 'body', 'usermgr/modify' )
					->build('admin', $this->data);
	}
	
	
	/**
	 * The actual removal function
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		integer			- $cnxnid: the connection id to remove user from
	 * @param		base64 string	- $user: the user by email to remove
	 * 
	 * @since		3.0.0
	 */
	public function remove( $cnxnid = null, $user = null )
	{
		if ( ( $cnxnid == null ) || ( $user == null ) ) {
			$this->session->set_flashdata('error_message', 'Program error!' );
			redirect('usermgr/find', 'refresh');
		}
		
		$cnxn_lib	=   get_cnxn_library( $cnxnid );
		$api		=   get_api( $cnxnid );
		
		// Prep the cuser object
		$this->_cuser_place( $user );
		
		if ( ( $api->user_remove() ) !== true ) {
			$this->session->set_flashdata('error_message', 'Problem deleting user!' );
			redirect('usermgr/find', 'refresh');
		}
		
		$this->session->set_flashdata('success_message', 'User removed!' );
		redirect( 'usermgr/find/' . $user, 'refresh' );
	}
	
	
	/**
	 * Confirms removal prior to doing so
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		integer			- $cnxnid: the connection id to remove user from
	 * @param		base64 string	- $user: the user by email to remove
	 * 
	 * @since		3.0.0
	 */
	public function removeconfirm( $cnxnid = null, $user = null )
	{
		if ( ( $cnxnid == null ) || ( $user == null ) ) {
			$this->session->set_flashdata('error_message', 'Program error!' );
			redirect('usermgr/find', 'refresh');
		}
		
		$fields		= & $this->fields_library;
		$fields->load( 'usermgr/remove/confirm' );
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == true ) {
			if ( $this->input->post( 'confirm' ) == '1' ) {
				redirect('usermgr/remove/' . $cnxnid . '/' . $user, 'refresh' );
			}
			else {
				$this->session->set_flashdata('info_message', 'Removal cancelled!' );
				redirect('usermgr/find/' . $user, 'refresh' );
			}
		}
		
		$this->data['action']	= 'usermgr/removeconfirm/' . $cnxnid . '/' . $user;
		$this->data['submit']	= 'btn.removeuser';
		
		$this->data	= array_merge( $this->data, $fields->render() );
		
		$this->template
					->set_partial( 'body', 'usermgr/modify' )
					->build('admin', $this->data);
		
	}
	
	
	/**
	 * Retrieves the active connections
	 * @access		private
	 * @version		3.0.0.0.2
	 * 
	 * @return		array of connection libraries or false if none
	 * @since		3.0.0
	 */
	private function _build_active_cnxns()
	{
		$cnxns	= get_cnxns();
		$data	= array();
		
		foreach ( $cnxns as $id => $cnxn ) {
			if ( ! $cnxn->get( "userenable", true, "users" ) ) continue;
			$data[] = get_cnxn_library( $id );
		}
		
		if ( empty( $data ) ) return false;
		else return $data;
	}
	
	
	/**
	 * Puts a user item into the common user library
	 * @access		private
	 * @version		3.0.0.0.2
	 * @param		string		- $user: the email or username to place into the cuser object
	 * @param		boolean		- $base64: if the user string is base64 encoded
	 * 
	 * @return		string of unencoded user item or true if not base64 encoded
	 * @since		3.0.0
	 */
	private function _cuser_place( $user = null, $base64 = true )
	{
		if ( $user == null ) return;
		
		$user	=   ( $base64 ? base64_decode( $user ) : $user );
		$cuser = & Cuser::getInstance( true );
		$cuser->set( ( is_email( $user ) ? 'email' : 'username' ), $user );
		
		return ( $base64 ? $user : true );
	}
	
	
	/**
	 * Checks the common user object for errors generated during retrieval of data
	 * @access		private
	 * @version		3.0.0.0.2
	 * @param		boolean		- $verbose: for error message true, else just boolean
	 * 
	 * @return		varies boolean if not verbose, string if so, false if empty regardless
	 * @since		3.0.0
	 */
	private function _cuser_errors( $verbose = false )
	{
		$cuser	= & Cuser::getInstance();
		$error	=   $cuser->error;
		
		return ( empty( $error ) ? false : ( $verbose ? $error : true ) );
	}
	
	
	/**
	 * Retrieves data from the common user object and creates an array of resultant data
	 * @access		private
	 * @version		3.0.0.0.2
	 * @param		array		- $post: should contain at least the cnxn id as 'cnxn_id' => $value
	 * 
	 * @return		array of compiled data
	 * @since		3.0.0
	 */
	private function _cuser_retrieve( $post = array() )
	{
		extract ( $post );
		
		$cuser	= & Cuser::getInstance();
		$cnxn_m	=   cnxn( $cnxn_id );
		
		if ( $cuser->error ) {
			$data = array( 'username' => null, 'email' => null, 'isfound' => false, 'error' => $cuser->error, 'active' => false );
		}
		else {
			$data = $cuser->get_properties();
			$data['isfound'] = true;
		}
		
		$data['cnxn_name']	= $cnxn_m->get( 'name' );
		$data['link_user']	= ( ( isset( $data['username'] ) && ( $data['username'] != $user ) ) ? anchor( 'usermgr/find/' . base64_encode( $data['username'] ), image( 'icon16-find.png' ), array( "title" => sprintf( lang( 'usermgr.linkuser' ), $data['username'] ) ) ) : false );
		$data['link_email']	= ( ( isset( $data['email'] ) && ( $data['email'] != $user ) ) ? anchor( 'usermgr/find/' . base64_encode( $data['email'] ), image( 'icon16-find.png' ), array( "title" => sprintf( lang( 'usermgr.linkemail' ), $data['email'] ) ) ) : false );
		$data['add_user']	= ( (! $data['isfound'] ) ? anchor( 'usermgr/create/' . $cnxn_id . '/' . base64_encode( $user ), image( 'icon16-adduser.png' ), array( 'title' => lang( 'usermgr.createnew' ) ) ) : '' );
		$data['edit_user']	= ( $data['isfound'] ? anchor( 'usermgr/modify/' . $cnxn_id . '/' . base64_encode( $user ), image( 'icon16-edituser.png' ), array( 'title' => lang( 'usermgr.modifyuser' ) ) ) : '' );
		$data['del_user']	= ( $data['isfound'] ? anchor( 'usermgr/removeconfirm/' . $cnxn_id . '/' . base64_encode( $user ), image( 'icon16-deleteuser.png' ), array( 'title' => lang( 'usermgr.deleteuser' ) ) ) : '' );
		$data['user_log']	= ( isset( $data['email'] ) ? anchor( 'usermgr/log/1/20/' . base64_encode( $data['email'] ), image( 'icon16-userlog.png' ), array( 'title' => lang( 'usermgr.viewlog' ) ) ) : '' );
		
		return $data;
	}
	
	
	/**
	 * Creates a paged footer for the log view
	 * @access		private
	 * @version		3.0.0.0.2
	 * @param		integer		- $page: the current page
	 * @param		integer		- $limit: the records limit
	 * @param		string		- $user: the user being sought
	 * @param		string		- $order: the field to order by
	 * @param		boolean		- $asc: true is asc, false is desc
	 * 
	 * @since		3.0.0
	 */
	private function _paged_footer( $page, $limit, $user, $order, $asc )
	{
		$model		= $this->get_model( 'userlog_model', '' );
		
		$this->load->library( 'pagination' );
		$config['base_url']			= site_url( 'usermgr/log' );
		$config['total_rows']		= $model->count( 'all' );
		$config['per_page']			= $limit;
		
		$this->pagination->initialize($config);
		
		$this->data['page']	= $this->pagination->create_links();
		
		$this->template->append_metadata( css( 'pagination.css' ) );
		$this->template->append_metadata( css( 'pagination-blue.css' ) );
		
	}
}