<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.2 ( $Id: admin.php 393 2012-02-21 18:08:21Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the admin controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Entry point for configuration and administration of application
 * @version		3.0.0.0.2
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Admin extends Admin_Controller
{
	/**
	 * Constructor class
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::Admin_Controller();
		
		$this->load->language( 'admin' );
		
	}
	
	
	/**
	 * Completes installation by removing the install folder
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function complete( $upgrade = false )
	{
		if ( ( file_exists( BASEPATH . 'install' ) ) && ( is_really_writable( BASEPATH . 'install' ) ) ) {
			$this->load->helper( 'file' );
			delete_files( BASEPATH . 'install', true );
			if ( @rmdir( BASEPATH . 'install' ) ) {
				$this->session->set_flashdata('success_message', lang( ( $upgrade ? 'msg.success.upgradecomplete' : 'msg.success.installcomplete' ) ) );
			}
			else {
				$this->session->set_flashdata('error_message', sprintf( lang( ( $upgrade ? 'msg.error.upgrade' : 'msg.error.install' ) ), BASEPATH . 'install' ) );
			}
		}
		else if ( ( file_exists( BASEPATH . 'install' ) ) && (! is_really_writable( BASEPATH . 'install' ) ) ) {
			$this->session->set_flashdata('success_message', sprintf( lang( ( $upgrade ? 'msg.success.upgradecomplete' : 'msg.success.installcomplete' ) ), BASEPATH . 'install' ) );
		}
		
		if ( $upgrade === false ) {
			$params	= & Params :: getInstance();
			$params->set( 'Secret', $this->random_generator( 12 ) );
			$params->save();
		}
		
		redirect( 'admin/login', 'location', 301 );
	}
	
	
	/**
	 * Handles the forgot password routine
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function forgot_password()
	{
		$fields		= & $this->fields_library;
		$fields->load( 'users/forgot_password' );
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == true ) {
			$forgotten = $this->auth->forgotten_password( $this->input->post( 'email' ) );
			
			if ( $forgotten ) {
				$this->session->set_flashdata( 'success_message', lang( 'msg.success.forgotpwsent' ) );
				redirect( 'admin/login', 'refresh' );
			}
			else {
				$this->session->set_flashdata('error_message', lang( 'msg.error.forgotpwsent' ) );
				redirect( 'admin/forgot_password', 'refresh' );
			}
		}
		
		$this->data['action']	= 'admin/forgot_password';
		$this->data['submit']	= 'btn.sendreminder';
		
		$this->data	+= $fields->render();
		
		$this->template
			->set_partial( 'body', 'form' )
			->build('admin', $this->data);
	}
	
	
	/**
	 * Assembles control panel page
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function index()
	{
		$this->data['status']	= $this->get_box( 'cnxnstatus' );
		$this->data['log']		= $this->get_box( 'userlog' );
		$this->data['rss']		= $this->get_box( 'rss' );
		$this->data['steps']	= $this->get_box( 'stepbystep' );
		
		// Grab the latest version
		$latest_version = (string) @file_get_contents( "http://www.gohigheris.com/integrator_currentversion.txt" );
		$this->data['update']	= ( '3.0.0.0.2' < $latest_version ? $latest_version : false );
		
		$this->template
				->set_partial( 'admin-cnxnhealth',	'admin/box/cnxnhealth' )
				->set_partial( 'admin-log',			'admin/box/log' )
				->set_partial( 'admin-rss',			'admin/box/rss' )
				->set_partial( 'admin-update',		'admin/box/update' )
				->set_partial( 'admin-stepbystep',	'admin/box/stepbystep' )
				->set_partial( 'body', 				'admin/index' )
				->build('admin', $this->data);
		
	}
	
	
	/**
	 * Login routine
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function login()
	{
		$fields	= & $this->fields_library;
		$fields->load( 'users/login' );
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == true ) {
			$remember = (bool) $this->input->post('remember');
			
			if ($this->auth->login( $this->input->post( 'username' ), $this->input->post( 'password' ), $remember ) ) {
				$this->session->set_flashdata( 'success_message', lang( 'msg.success.login' ) );
				redirect('admin/index', 'refresh');
			}
			else {
				// Notify administrators of failed login attempt
				$data	= array(
									'ip_address'	=> $this->session->userdata( 'ip_address' ),
									'timestamp'		=> $this->session->userdata( 'last_activity' ),
									'username'		=> $this->input->post( 'username' )
				);
				$this->notify->send( 'failed_login', $data );
				$this->session->set_flashdata( 'error_message', lang( 'msg.error.login' ) );
				redirect('admin/login', 'refresh');
			}
		}
		
		$this->data	+= $fields->render();
		
		$this->template
			->set_partial( "body", 'admin/login' )
			->build('login', $this->data);
	}
	
	
	/**
	 * Logout routine
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function logout()
	{
		//log the user out
		$logout = $this->auth->logout();
		
		//redirect them back to the page they came from
		redirect( 'admin/login', 'refresh' );
	}
	
	
	/**
	 * Resets a password given a provided reset code
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		string		- $code: generated by authentication routine
	 * 
	 * @since		3.0.0
	 */
	public function reset_password( $code = null )
	{
		if ( $code == null ) redirect( 'admin/login', 'refresh' );
		
		if ( $this->auth->forgotten_password_complete( $code ) ) {
			$this->session->set_flashdata('success_message', lang( 'msg.success.passwordreset' ) );
		}
		else {
			$this->session->set_flashdata('error_message', lang( 'msg.error.passwordreset' ) );
		}
		
		redirect('admin/login', 'refresh');
	}
	
	
	/**
	 * Allows for the disabling of a box
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function turn_off( $item = 'stepbystep')
	{
		$params		= & Params::getInstance();
		$messages	=   $params->get( 'Messages', array() );
		
		$messages[$item] = false;
		
		$params->set( 'Messages', $messages );
		$params->save();
		
		redirect( 'admin/index', 'refresh' );
	}
	
	
	/**
	 * Allows for the enabling of a box
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function turn_on( $item = 'stepbystep')
	{
		$params		= & Params::getInstance();
		$messages	=   $params->get( 'Messages', array() );
		
		$messages[$item] = true;
		
		$params->set( 'Messages', $messages );
		$params->save();
		
		redirect( 'admin/index', 'refresh' );
	}
	
	
	/**
	 * Builds the boxes for the admin page
	 * @access		private
	 * @version		3.0.0.0.2
	 * @param		string		- $item: indicates which box to create
	 * 
	 * @return		object or null on no messages set
	 * @since		3.0.0
	 */
	private function get_box( $item = 'cnxnstatus' )
	{
		$params = & Params::getInstance();
		$msgs	=   $params->get( 'Messages' );
		
		if (! is_array( $msgs ) ) return null;
		if (! isset( $msgs[$item] ) ) return null;
		if ( $msgs[$item] == false ) return null;
		
		$data	= array();
		
		switch ( $item ):
		
		case 'rss':
			$this->load->library( 'Rssparser_library', array( 'url' => 'http://www.gohigheris.com/forum/external.php?type=RSS2&forumids=2', 'life' => 0 ) );
			$data	= $this->rssparser_library->getFeed(5);
			
			if ( empty( $data ) ) {
				// No RSS feed so set something
				$data = array( (object) array( 'title' => 'News Feed', 'description' => 'News feed unavailable at this time', 'pubDate' => time(), 'link' => null ) );
			}
			
			break;
			
		case 'userlog':
			
			$model	= $this->get_model( 'userlog_model', '' );
			$data	= ( ( $log = $model->load_by_email( null, 'timestamp', false, 0, 5 ) ) ? $log : array() );
			
			break;
			
		case 'cnxnstatus':
			$cnxns	= get_cnxns();
			foreach ( $cnxns as $id => $cnxn ) {
				$data[]	= $cnxn->status_check();
			}
			break;

		case 'stepbystep':
			$data[1]	= anchor( 'settings', lang( 'stepbystep.lang.1' ) );
			$data[2]	= anchor( 'users', lang( 'stepbystep.lang.2' ) );
			$data[3]	= anchor( 'cnxns/add', lang( 'stepbystep.lang.3' ) );
			$data[4]	= anchor( 'cnxns/add', lang( 'stepbystep.lang.4' ) );
			$data[5]	= anchor( 'pagemap', lang( 'stepbystep.lang.5' ) );
			$data[6]	= anchor( 'langmap', lang( 'stepbystep.lang.6' ) );
			$data[7]	= null;
			$data		= (object) $data;
			break;
		endswitch;
		
		return $data;
	}
	
	
	/**
	 * Random generator of string
	 * @access		private
	 * @version		3.0.0.0.2
	 * @param		integer		- $length:  indicates length of string
	 * 
	 * @return		string containing random code
	 * @since		3.0.0
	 */
	private function random_generator( $length = 8 ) {
		$chars	= 'bcdfghjklmnprstvwxzaeiouBCDFGHJKLMNPRSTVWXAEIOU1234567890';
		$result	= null;
		for ($p = 0; $p < $length; $p++) {
			$result .= ($p%2) ? $chars[mt_rand(29, 56)] : $chars[mt_rand(0, 28)];
		}
		return $result;
	}
}

?>