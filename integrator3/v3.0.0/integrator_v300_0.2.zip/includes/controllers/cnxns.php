<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.2 ( $Id: cnxns.php 355 2011-12-12 19:26:54Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the cnxns controller for administrering the various connections in Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Connection class to create, edit and remove connections from the system
 * @version		3.0.0.0.2
 * 
 * @since		3.0.0
 * @author		Steven
 */
class Cnxns extends Admin_Controller
{
	/**
	 * Constructor
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::Admin_Controller();
		$this->load->language( 'cnxns' );
	}
	
	
	/**
	 * Assembles to add a new connection to the system
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function add()
	{
		$model	=   $this->get_model( null, "_m" );
		$fields	= & $this->fields_library;
		
		$fields->load( 'cnxns/add' );
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == TRUE ) {
			if ( $id = $model->save( $this->input->post() ) ) {
				$this->session->set_flashdata('success_message', lang( 'msg.success.cnxnadd' ) );
				redirect("cnxns/edit/{$id}", 'refresh');
			}
			else {
				$this->session->set_flashdata('error_message', lang( 'msg.error.unknown' ) );
			}
		}
		
		$fields->set_values( $model->get_properties() );
		
		$this->data	+= $fields->render();
		
		$this->data['action']	= 'cnxns/add';
		$this->data['submit']	= 'btn.addcnxn';
		
		$this->template
					->set_partial( 'body',	'form' )
					->build('admin', $this->data);
	}
	
	
	/**
	 * Handles the request to delete a connection
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		integer		- $id: the connection id passed through the URL string
	 * 
	 * @since		3.0.0
	 */
	public function delete( $id = NULL )
	{
		// Be sure we got something to edit
		if ( $id == NULL ) {
			$this->session->set_flashdata( 'error_message', lang( 'msg.error.nocnxnselected' ) );
			redirect( "cnxns/index", 'refresh' );
		}
		
		$model = $this->get_model( null, "_m" );
		
		if ( $model->delete( $id ) ) {
			$this->session->set_flashdata( 'success_message', lang( 'msg.success.cnxndeleted' ) );
			redirect( "cnxns/index", 'redirect' );
		}
		else {
			$this->session->set_flashdata( 'error_message', lang( 'msg.error.cnxndelete' ) );
			redirect( "cnxns/edit/{$id}", 'redirect' );
		}
	}
	
	
	/**
	 * Assembles the data to edit an individual connection
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		integer		- $id: the connection id passed through the URL string
	 * 
	 * @since		3.0.0
	 */
	public function edit( $id = NULL )
	{
		// Be sure we got something to edit
		if ( $id == NULL ) {
			$this->session->set_flashdata( 'error_message', lang( 'msg.error.nocnxnselected' ) );
			redirect("cnxns/index", 'refresh');
		}
		
		if ( ( $cnxn	=   cnxn( $id ) ) === false ) {
			$this->session->set_flashdata( 'error_message', lang( 'msg.error.nocnxnselected' ) );
			redirect( 'cnxns/index', 'refresh' );
		};
		
		$fields		= & $this->fields_library;
		$fields->load( 'cnxns/edit', $cnxn->get( 'type' ), true );
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == TRUE ) {
			$post = $this->_assemble_post();
			
			// data is validated so save it
			if ( $cnxn->save( $post ) ) {
				// data saved so update settings
				redirect("cnxns/verify/{$id}", 'refresh');
			}
		}
		
		$fields->set_values( $cnxn->get_param_array() );
		$fields->set( 'params[globals][name]', $cnxn->get( 'name' ) );
		$fields->set( 'params[globals][active]', $cnxn->get( 'active' ) );
		$fields->set( 'params[globals][type]', $cnxn->get( 'type' ) );
		$fields->set( 'params[globals][id]', $id );
		
		$this->data	+= $fields->render();
		
		$this->data['cnxn_id']	= $id;
		$this->data['name']		= $cnxn->get( "name" );
		$this->data['action']	= 'cnxns/edit/' . $id;
		$this->data['submit']	= 'btn.editcnxn';
		$this->data['delete']	= 'btn.delcnxn';
		
		$this->_set_menus();
		
		$this->template
					->set_partial( "body", 'cnxns/edit' )
					->build('admin', $this->data);
	}
	
	
	/**
	 * Assembles the data for the default connection view
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function index()
	{
		// Initialize
		$model	= $this->get_model( null, "_m" );
		$data	= array();
		
		// Get the current cnxns
		$cnxns	= $model->get_cnxns();
		
		// Create objects for rendering
		foreach ( $cnxns as $cnxn ) {
			$data[]	= (object) array( 'path' => 'cnxns/edit/' . $cnxn->id, 'image' => 'includes/cnxns/' . $cnxn->type . '/icon.png', 'options' => array( 'name' => $cnxn->name, 'title' => 'Edit '. $cnxn->name ) );
		}
		
		// If we can add new cnxns allow so
		if ( $this->can_add_cnxns() ) {
			$data[]	= (object) array( 'path' => 'cnxns/add', 'image' => 'includes/assets/img/icon48-addnew.png', 'options' => array( "name" => "Add New Connection", "title" => "Add New Connection" ) );
		}
		
		$this->data['cnxns']	= $data;
		
		$this->template
					->set_partial( "body", 'cnxns/index' )
					->build('admin', $this->data);
	}
	
	
	/**
	 * Verifies the connection settings and corrects any inconsistant or errant settings
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		integer		- $id: passed in the url to indicate which connection to verify
	 * s
	 * @since		3.0.0
	 */
	public function verify( $id = null )
	{
		if ( $id == null ) redirect( "cnxns", "refresh" );
		
		// Pull model
		$cnxn	= cnxn( $id );
		
		$cnxn_lib = cnxn_library( $cnxn->get( "type" ), $id );
		if (! $cnxn_lib->verify_settings() ) {
			redirect( "cnxns/verify/{$id}", "refresh" );
		}
		
		$this->session->set_flashdata( 'success_message', lang( 'msg.success.connectionsaved' ) );
		redirect( "cnxns", "refresh" );
	}
	
	
	/**
	 * Assembles the post data for the model
	 * @access		private
	 * @version		3.0.0.0.2
	 * 
	 * @return		array containing post data
	 * @since		3.0.0
	 */
	private function _assemble_post()
	{
		$post	= $this->input->post();
		$check	= array( 'name', 'active', 'id', 'type' );
		foreach( $check as $key ) {
			$post[$key] = $post['params']['globals'][$key];
			unset( $post['params']['globals'][$key] );
		}
		return $post;
	}
	
	
	/**
	 * Permits for setting menus based on page selection from connection
	 * @access		private
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	private function _set_menus()
	{
		$vis = & $this->data['fields']['visuals'];
		foreach ( $vis as & $v ) {
			if ( substr( $v->field, 0, 15 ) != 'cnxn-pageselect' ) continue;
			$pcs = explode( "|", $v->field );
			$cnxn = get_cnxn_library( $this->data['cnxn_id'] );
			$v->field = form_dropdown( $pcs[1], $cnxn->get_pages(), $pcs[2], 'id=' . $pcs[3] . ' class="span-6"' );
		}
	}
}