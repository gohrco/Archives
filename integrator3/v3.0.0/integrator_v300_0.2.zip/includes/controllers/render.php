<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.2 ( $Id: render.php 366 2012-01-19 02:24:25Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the rendering controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * API interface for application
 * @version		3.0.0.0.2
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Render extends MY_Controller
{
	public	$enabled	= false;
	public	$error		= null;
	
	
	/**
	 * Constructor class
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
		
		$this->load->language( 'render' );
		
		$this->load->library( 'session' );
		$this->load->library( 'form_validation' );
		
		// See if Integrator is Enabled
		if ( $this->is_enabled( true ) === false ) {
			$this->error	= 'msg.error.disabled';
			return;
		}
		
		// See if Visual Integration is Enabled
		if ( $this->is_enabled( 'visual' ) === false ) {
			$this->error	= 'msg.error.visualdisabled';
			return;
		}
		
		// *** VERIFY WE HAVE ALL THE REQUIRED VARIABLES *** //
		$this->form_validation->set_rules( 'filename', "Filename", 'required' );
		$this->form_validation->set_rules( 'language', "Language", 'required' );
		$this->form_validation->set_rules( 'characterset', "Character Set", 'required' );
		$this->form_validation->set_rules( 'session_id', "Session ID", 'required' );
		$this->form_validation->set_rules( '_a', "Application ID", 'required|numeric' );
		$this->form_validation->set_rules( 'signature', "Security Signature", 'required' );
		$this->form_validation->set_rules( 'salt', "Security Salt", 'required' );
		$this->form_validation->set_rules( '_v', "Site ID", 'numeric' );
		$this->form_validation->set_rules( 'isssl', "Using SSL", 'numeric' );
		
		$valid = $this->form_validation->run();
		
		if ( (! $valid ) AND (! $this->debug ) ) {
			show_404();
			exit;
		}
		else if ( (! $valid ) AND ( $this->debug ) ) {
			echo validation_errors();
			exit;
		}
		
		// Test the secret / hash generated
		if ( $this->secret_hash_valid( get_var( 'salt', 'post' ), get_var( 'signature', 'post' ) ) ) {
			// If we are here then we can proceed
			$this->enabled = true;
		}
		else {
			debug_error( 'msg.error.secrethashinvalid' );
			return $this->_close( array() );
		}
		
		$this->load->model( "session_model" );
		$this->load->helper( "settings" );
		$this->load->helper( 'response' );
		
		// Initialize the session info
		if(! get_application_session( get_var( '_a', 'post' ), get_var( 'session_id', 'post' ) ) ) {
			show_404();
			exit;
		}
	}
	
	
	/**
	 * Index method to retrieve a page
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function index()
	{
		// Check enabled
		if ( $this->enabled === false ) {
			debug_error ( $this->error );
			return $this->_close( array() );
		}
		
		// Retrieve the Visual Connection
		$_a = get_var( '_a', 'post' );
		$_v = get_application_session()->params['_v'];
		
		// Should not be possible now
		if ( $_v == false ) {
			debug_error( 'msg.error.defaultvisualunset' );
			return $this->_close( array() );
		}
		
		// Check for multisite _v
		$isms = $this->is_multisite( $_v, $this->input->post('language' ) );
		
		_e($isms,1);
		
		// Check to see if either are disabled visually
		if ( ( $this->is_enabled( 'visual', $_a ) === false ) || ( $this->is_enabled( 'visual', $_v ) === false ) ) {
			debug_error( 'msg.error.cnxndisabled' );
			return $this->_close( array() );
		}
		
		$options	= array(
						'page'			=> $this->input->post( 'filename' ),
						'language'		=> $this->input->post( 'language' ),
						'characterset'	=> $this->input->post( 'characterset' ),
						'session_id'	=> get_application_session()->remote,
						'isssl'			=> $this->input->post( 'isssl' ),
						'_a'			=> $_a,
						'_v'			=> $_v
		);
		
		$render = new Render_library( $options );
		_d( $options );
		
		// Be sure to catch errors
		if ( $render->_enabled === false ) {
			debug_error( 'msg.error.misconfiguration' );
			return $this->_close( array() );
		}
		
		// Get the site and return the response
		$response = $render->retrieve_site();
		
		if ( $response === false ) {
			_d( $render );
			return $this->_close( array() );
		}
		
		$data = $response->generate_response();
		
		// Close with the response
		$this->_close( $data );
	}
	
	
	/**
	 * Close with appropriate headers and session handling
	 * @access		private
	 * @version		3.0.0.0.2
	 * @param		array		- $message: generated response by render object
	 * 
	 * @since		3.0.0
	 */
	private function _close( $message )
	{
		$debug = debug_output();
		
		if (! empty( $debug ) ) {
			$message += array( 'debug' => $debug );
		}
		
		$response	= xml_response( $message );
		
		$CI = & get_instance();
		$CI->output->set_header( 'Cache-Control: no-cache, must-revalidate' );
		$CI->output->set_header( 'Expires: Fri, 7 Mar 1997 05:00:00 GMT' );
		$CI->output->set_content_type( 'text/xml' );
		$CI->output->set_output( $response );
		
		$this->session->sess_destroy();
	}
}