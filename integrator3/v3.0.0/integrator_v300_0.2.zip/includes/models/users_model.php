<?php
/* SECURITY CHECKPOINT */
defined('BASEPATH') OR exit('No direct script access allowed');

class Users_Model extends CI_Model
{
	function __construct()
	{
		
	}
}