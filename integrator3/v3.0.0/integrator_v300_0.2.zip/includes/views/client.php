<?php echo $header; ?>

<?php echo $header_includes; ?>

<?php echo $body; ?>

<?php echo $template['partials']['body']; ?>

<?php echo $footer; ?>