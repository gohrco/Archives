<h2><?php echo $error; ?></h2>
<?php echo form_open( $action, array( 'class' => 'intReg', 'id' => 'intReg' ) ); ?>

<?php $row = 0; ?>

<?php foreach ( $fields as $item ) : ?>

<div class="row<?php echo $row & 1; ?>">
	<div class="label"><?php echo $item->label; ?></div>
	<div class="field<?php echo ( form_error( $item->name ) ? ' error' : '' ); ?>" id="field<?php echo $item->name; ?>"><?php echo $item->field; ?></div>
	<div class="desc<?php echo ( form_error( $item->name ) ? ' error' : '' ); ?>" id="validate<?php echo $item->name; ?>"><?php echo ( form_error( $item->name ) ? form_error( $item->name ) : $item->desc ); ?></div>
	<div class="clear"> </div>
</div>

<div class="clear"> </div>

<?php $row++; ?>

<?php endforeach; ?>

<?php foreach( $hidden as $hide ) : ?>
<?php echo $hide->field; ?>
<?php endforeach; ?>

<?php if ( $recaptcha['enabled'] ) : ?>

<script>
var RecaptchaOptions = {
   theme : '<?php echo $recaptcha['theme']; ?>',
   lang: '<?php echo $recaptcha['lang']; ?>'
};
</script>
<div class="row<?php echo $row & 1; ?>">
	<div class="label">&nbsp;</div>
	<div class="field"><?php echo recaptcha_get_html( $recaptcha['pubkey'], null, $recaptcha['usessl'] ); ?></div>
	<div class="clear"> </div>
</div>

<?php $row++; ?>

<?php endif; ?>

<div class="push-4 append-bottom clear">
	<?php echo form_button( array( 'name' => 'submit', 'id' => 'submit', 'value' => true, 'type' => 'submit', 'content' => lang( $submit ) ) );?>
</div>

<input type="hidden" id="myurl" value="<?php echo $myurl; ?>" />
<?php echo form_close(); ?>

<script>

jQuery(document).ready(function(){
	jQuery( "#intReg" ).validationEngine( 'attach', {ajaxFormValidation: false })
});

</script>