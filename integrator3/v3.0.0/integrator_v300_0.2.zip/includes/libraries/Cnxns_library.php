<?php defined('BASEPATH') OR exit('No direct script access allowed');

include_once( "API_Library.php" );
include_once( "Render_library.php" );

/**
 * Connections Library base class
 * @version		3.0.0.0.2
 * 
 * @since		3.0.0
 * @author		Steven
 */
class Cnxns_library
{
	protected $id	= null;
	protected $type	= "cnxns";
	protected $userarray	= array( 'email' => null, 'firstname' => null, 'lastname' => null, 'username' => null );
	
	/**
	 * Constructor for Cnxns class
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		$this->types		=   array();
		$this->cnxns		=   array();
		$this->cnxnsbyname	=   array();
		
		$CI	= get_instance();
		$CI->load->database();
		$CI->load->helper( 'file' );
		$CI->load->helper( 'directory' );
		$CI->load->helper( 'cnxn' );
		$CI->load->helper( 'cuser' );
		
		if (! isset( $CI->cnxnapi ) ) {
			$CI->cnxnapi = array();
		}
		
		$db	= & $CI->db;
		
		// Load the types first
		$map = directory_map( APPPATH . "cnxns" );
		foreach ( $map as $m => $toss ) {
			if ( is_dir( APPPATH . "cnxns/" . $m ) ) {
				$CI->load->add_package_path( APPPATH . "cnxns/" . $m );
				$CI->load->config( $m, TRUE );
				$CI->load->library( $m );
				$CI->load->language( $m );
				$mname = "{$m}_m";
				$CI->load->model( $mname );
					$this->types[$m] = & $CI->$mname;
					$this->types[$m]->set( "type", $m );
					$this->types[$m]->set_defaults( $CI->config->item( $m ) );
				$CI->load->remove_package_path( APPPATH . "cnxns/" . $m );
			}
		}
		
		// Load the individual connections, cloning and binding them to their types
		$model		= $this->get_model();
		$results	= $model->get_cnxns();
		
		if ( $results !== FALSE ) {
			foreach( $results as $row ) {
				// Add a log entry for noting a missing type
				if (! isset( $this->types[$row->type] ) ) {
					log_message( 'debug', "The type {$row->type} does not exist to clone and bind to - Cnxns.php library" );
					continue;
				}
				
				// Clone Type
				$this->cnxns[$row->id] = clone $this->types[$row->type];
				
				// Load database row to cloned type
				if ( $this->cnxns[$row->id]->load( $row ) === FALSE ) {
					unset ( $this->cnxns[$row->id] );
					log_message( 'debug', "Unable to load the database array onto connection object" );
					continue;
				}
				
				// Reference by name to cloned type
				$this->cnxnsbyname[strtolower( $row->name )] = & $this->cnxns[$row->id];
			}
		}
	}
	
	
	/**
	 * Common functionality for binding parameters to connection
	 * @access		public
	 * @version		3.0.0.0.2
	 * @params		varies		- $params: sent by child::bind()
	 * 
	 * @since		3.0.0
	 */
	public function bind( &$params = null )
	{
		$model	= $this->get_model();
		
		// Nothing we can do
		if ( $params == NULL ) return;
		
		// Params is actually an ID so pull the params from DB
		if ( is_integer( $params ) ) {
			$params	= $model->get_params( (int) $params );
		}
		
		// Decode em!
		$params	= json_decode( $params, true );
		
		// Bind em up!
		$this->set_params( $params );
		
		// Create the global URI object (common to all connections)
		$uri	= $this->get( 'url', null, 'globals' );
		$uri	= ( is_array( $uri ) ? $uri['value'] : $uri );
		$uri = Uri::getInstance( $uri, true );
		$uri->setPath( rtrim( $uri->getPath(), "/" ) );
		
		$this->set( "uri", $uri );
	}
	
	
	/**
	 * Builds the country array
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		array containing country array
	 * @since		3.0.0 (0.2)
	 */
	public function build_country_array()
	{
		$data	= array( 'AF' => 'Afghanistan', 'AX' => 'Aland Islands', 'AL' => 'Albania', 'DZ' => 'Algeria', 'AS' => 'American Samoa', 'AD' => 'Andorra', 'AO' => 'Angola', 'AI' => 'Anguilla', 'AQ' => 'Antarctica', 'AG' => 'Antigua And Barbuda', 'AR' => 'Argentina', 'AM' => 'Armenia', 'AW' => 'Aruba', 'AU' => 'Australia', 'AT' => 'Austria', 'AZ' => 'Azerbaijan', 'BS' => 'Bahamas', 'BH' => 'Bahrain', 'BD' => 'Bangladesh', 'BB' => 'Barbados', 'BY' => 'Belarus', 'BE' => 'Belgium', 'BZ' => 'Belize', 'BJ' => 'Benin', 'BM' => 'Bermuda', 'BT' => 'Bhutan', 'BO' => 'Bolivia', 'BA' => 'Bosnia And Herzegovina', 'BW' => 'Botswana', 'BV' => 'Bouvet Island', 'BR' => 'Brazil', 'IO' => 'British Indian Ocean Territory', 'BN' => 'Brunei Darussalam', 'BG' => 'Bulgaria', 'BF' => 'Burkina Faso', 'BI' => 'Burundi', 'KH' => 'Cambodia', 'CM' => 'Cameroon', 'CA' => 'Canada', 'CV' => 'Cape Verde', 'KY' => 'Cayman Islands', 'CF' => 'Central African Republic', 'TD' => 'Chad', 'CL' => 'Chile', 'CN' => 'China', 'CX' => 'Christmas Island', 'CC' => 'Cocos (Keeling) Islands', 'CO' => 'Colombia', 'KM' => 'Comoros', 'CG' => 'Congo', 'CD' => 'Congo, Democratic Republic', 'CK' => 'Cook Islands', 'CR' => 'Costa Rica', 'CI' => "Cote D'Ivoire", 'HR' => 'Croatia', 'CU' => 'Cuba', 'CY' => 'Cyprus', 'CZ' => 'Czech Republic', 'DK' => 'Denmark', 'DJ' => 'Djibouti', 'DM' => 'Dominica', 'DO' => 'Dominican Republic', 'EC' => 'Ecuador', 'EG' => 'Egypt', 'SV' => 'El Salvador', 'GQ' => 'Equatorial Guinea', 'ER' => 'Eritrea', 'EE' => 'Estonia', 'ET' => 'Ethiopia', 'FK' => 'Falkland Islands (Malvinas)', 'FO' => 'Faroe Islands', 'FJ' => 'Fiji', 'FI' => 'Finland', 'FR' => 'France', 'GF' => 'French Guiana', 'PF' => 'French Polynesia', 'TF' => 'French Southern Territories', 'GA' => 'Gabon', 'GM' => 'Gambia', 'GE' => 'Georgia', 'DE' => 'Germany', 'GH' => 'Ghana', 'GI' => 'Gibraltar', 'GR' => 'Greece', 'GL' => 'Greenland', 'GD' => 'Grenada', 'GP' => 'Guadeloupe', 'GU' => 'Guam', 'GT' => 'Guatemala', 'GG' => 'Guernsey', 'GN' => 'Guinea', 'GW' => 'Guinea-Bissau', 'GY' => 'Guyana', 'HT' => 'Haiti', 'HM' => 'Heard Island & Mcdonald Islands', 'VA' => 'Holy See (Vatican City State)', 'HN' => 'Honduras', 'HK' => 'Hong Kong', 'HU' => 'Hungary', 'IS' => 'Iceland', 'IN' => 'India', 'ID' => 'Indonesia', 'IR' => 'Iran, Islamic Republic Of', 'IQ' => 'Iraq', 'IE' => 'Ireland', 'IM' => 'Isle Of Man', 'IL' => 'Israel', 'IT' => 'Italy', 'JM' => 'Jamaica', 'JP' => 'Japan', 'JE' => 'Jersey', 'JO' => 'Jordan', 'KZ' => 'Kazakhstan', 'KE' => 'Kenya', 'KI' => 'Kiribati', 'KR' => 'Korea', 'KW' => 'Kuwait', 'KG' => 'Kyrgyzstan', 'LA' => "Lao People's Democratic Republic", 'LV' => 'Latvia', 'LB' => 'Lebanon', 'LS' => 'Lesotho', 'LR' => 'Liberia', 'LY' => 'Libyan Arab Jamahiriya', 'LI' => 'Liechtenstein', 'LT' => 'Lithuania', 'LU' => 'Luxembourg', 'MO' => 'Macao', 'MK' => 'Macedonia', 'MG' => 'Madagascar', 'MW' => 'Malawi', 'MY' => 'Malaysia', 'MV' => 'Maldives', 'ML' => 'Mali', 'MT' => 'Malta', 'MH' => 'Marshall Islands', 'MQ' => 'Martinique', 'MR' => 'Mauritania', 'MU' => 'Mauritius', 'YT' => 'Mayotte', 'MX' => 'Mexico', 'FM' => 'Micronesia, Federated States Of', 'MD' => 'Moldova', 'MC' => 'Monaco', 'MN' => 'Mongolia', 'ME' => 'Montenegro', 'MS' => 'Montserrat', 'MA' => 'Morocco', 'MZ' => 'Mozambique', 'MM' => 'Myanmar', 'NA' => 'Namibia', 'NR' => 'Nauru', 'NP' => 'Nepal', 'NL' => 'Netherlands', 'AN' => 'Netherlands Antilles', 'NC' => 'New Caledonia', 'NZ' => 'New Zealand', 'NI' => 'Nicaragua', 'NE' => 'Niger', 'NG' => 'Nigeria', 'NU' => 'Niue', 'NF' => 'Norfolk Island', 'MP' => 'Northern Mariana Islands', 'NO' => 'Norway', 'OM' => 'Oman', 'PK' => 'Pakistan', 'PW' => 'Palau', 'PS' => 'Palestinian Territory, Occupied', 'PA' => 'Panama', 'PG' => 'Papua New Guinea', 'PY' => 'Paraguay', 'PE' => 'Peru', 'PH' => 'Philippines', 'PN' => 'Pitcairn', 'PL' => 'Poland', 'PT' => 'Portugal', 'PR' => 'Puerto Rico', 'QA' => 'Qatar', 'RE' => 'Reunion', 'RO' => 'Romania', 'RU' => 'Russian Federation', 'RW' => 'Rwanda', 'BL' => 'Saint Barthelemy', 'SH' => 'Saint Helena', 'KN' => 'Saint Kitts And Nevis', 'LC' => 'Saint Lucia', 'MF' => 'Saint Martin', 'PM' => 'Saint Pierre And Miquelon', 'VC' => 'Saint Vincent And Grenadines', 'WS' => 'Samoa', 'SM' => 'San Marino', 'ST' => 'Sao Tome And Principe', 'SA' => 'Saudi Arabia', 'SN' => 'Senegal', 'RS' => 'Serbia', 'SC' => 'Seychelles', 'SL' => 'Sierra Leone', 'SG' => 'Singapore', 'SK' => 'Slovakia', 'SI' => 'Slovenia', 'SB' => 'Solomon Islands', 'SO' => 'Somalia', 'ZA' => 'South Africa', 'GS' => 'South Georgia And Sandwich Isl.', 'ES' => 'Spain', 'LK' => 'Sri Lanka', 'SD' => 'Sudan', 'SR' => 'Suriname', 'SJ' => 'Svalbard And Jan Mayen', 'SZ' => 'Swaziland', 'SE' => 'Sweden', 'CH' => 'Switzerland', 'SY' => 'Syrian Arab Republic', 'TW' => 'Taiwan', 'TJ' => 'Tajikistan', 'TZ' => 'Tanzania', 'TH' => 'Thailand', 'TL' => 'Timor-Leste', 'TG' => 'Togo', 'TK' => 'Tokelau', 'TO' => 'Tonga', 'TT' => 'Trinidad And Tobago', 'TN' => 'Tunisia', 'TR' => 'Turkey', 'TM' => 'Turkmenistan', 'TC' => 'Turks And Caicos Islands', 'TV' => 'Tuvalu', 'UG' => 'Uganda', 'UA' => 'Ukraine', 'AE' => 'United Arab Emirates', 'GB' => 'United Kingdom', 'US' => 'United States', 'UM' => 'United States Outlying Islands', 'UY' => 'Uruguay', 'UZ' => 'Uzbekistan', 'VU' => 'Vanuatu', 'VE' => 'Venezuela', 'VN' => 'Viet Nam', 'VG' => 'Virgin Islands, British', 'VI' => 'Virgin Islands, U.S.', 'WF' => 'Wallis And Futuna', 'EH' => 'Western Sahara', 'YE' => 'Yemen', 'ZM' => 'Zambia', 'ZW' => 'Zimbabwe' );
		return $data;
	}
	
	
	/**
	 * Builds a new username based on settings
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		integer		- $cnxnid: the connection id the data set is originating from
	 * @param		array		- $data: the data sent by the connection
	 * 
	 * @return		string containing the new username
	 * @since		3.0.0
	 */
	public function build_new_username( $cnxnid = null, $data = array() )
	{
		// Must have a cnxnid
		if ( $cnxnid == null ) return null;
		
		$cnxn	= cnxn( $cnxnid );
		$method	= $cnxn->get( 'storeusername', 'random', 'users' );
		$user	= null;
		
		switch( $method ) :
		case 'first.last':
			$user = $data['firstname'] . ' ' . $data['lastname'];
			break;
		case 'last.first':
			$user = $data['lastname'] . ' ' . $data['firstname'];
			break;
		case 'flastname':
			$user = substr( $data['firstname'], 0, 1 ).$data['lastname'];
			break;
		case 'firstnamel':
			$user = $data['firstname'].substr( $data['lastname'], 0, 1 );
			break;
		case 'firstname':
		case 'lastname':
			$user = $data[$method];
			break;
		case 'custom':
			$field	= $cnxn->get( 'customfield', 'email', 'users' );
			$user	= $data[$field];
			break;
		default:
		case 'random':
			for ($i=0; $i<12; $i++) {
				$d = rand(1,30)%2;
				$user .= ( $d ? chr(rand(65,90)) : chr(rand(48,57)));
			}
			$user = ucfirst(strtolower($user));
			break;
		endswitch;
		
		return $user;
	}
	
	
	/**
	 * Handles creation of a new user on a connection based upon the cuser object data
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function cuser_create()
	{
		// Gather Info
		$cuser	= & Cuser :: getInstance();
		$cnxn	= & cnxn( $this->get( 'cnxn_id' ) );
		
		// Pull the array of values
		$values =   $this->cuser_retrieve();
		$update	=   array();
		
		// Cycle through and get defaults if not set
		foreach ( $values as $key => $value )
		{
			if (! empty( $value ) ) continue;
			
			if ( ( $default = $cnxn->get( 'default' . $key, false, 'users' ) ) !== false ) {
				$values[$key] = $default;
			}
		}
		
		// Put the gathered data into cuser and create the new user
		$this->cuser_place( $values );
		get_api( $this->get( 'cnxn_id' ) )->user_create();
		userlog( 'cuser-created', $values, $this->get( 'cnxn_id' ) );
	}
	
	
	/**
	 * Decodes the session id posted to the renderer (placeholder)
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		string		- $sid: base64 encoded string
	 * 
	 * @return		string containing session id
	 * @since		3.0.0
	 */
	public function decode_session_id( $sid ) {
		return $sid;
	}
	
	
	/**
	 * Retrieves the authentication credentials from the model (not specific to a connection)
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		array containing the credentials set by config (received, sent, required etc)
	 * @since		3.0.0
	 */
	public function get_authentication_credentials()
	{
		$model	= $this->get_model();
		$creds	= $model->get( "credentials" );
		return $creds;
	}
	
	
	/**
	 * Grabs the login action for redirecting to log user in
	 * @access		public
	 * @version		3.0.0.0.2
	 *
	 * @return		string containing the login action
	 * @since		3.0.0
	 */
	public function get_login_action()
	{
		$cnxn	= cnxn( $this->get( "cnxn_id" ) );
		$usessl	= $cnxn->get( 'usessl', 'ignore', 'users' );
		$uri	= new Uri ( $cnxn->get( "loginaction" ) );
		$uri->setScheme( ( $usessl == 'force' ? 'https' : ( $usessl == 'none' ? 'http' : $uri->getScheme() ) ) );
		return $uri->toString();
	}
	
	
	/**
	 * Grabs the login landing url for returning a user after completing the login
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		string containing the landing url
	 * @since		3.0.0
	 */
	public function get_login_landing_url()
	{
		$cnxn	= cnxn( $this->get( "cnxn_id" ) );
		return $cnxn->get( "loginlandingurl" );
	}
	
	
	/**
	 * Grabs the logout URL for redirecting to log a user out
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		string containing the log out url
	 * @since		3.0.0
	 */
	public function get_logout_url()
	{
		$cnxn	= cnxn( $this->get( "cnxn_id" ) );
		$usessl	= $cnxn->get( 'usessl', 'ignore', 'users' );
		$uri	= new Uri ( $cnxn->get( 'logouturl' ) );
		$uri->setScheme( ( $usessl == 'force' ? 'https' : ( $usessl == 'none' ? 'http' : $uri->getScheme() ) ) );
		return $uri->toString();
	}
	
	
	/**
	 * Grabs the landing URL for redirecting a user upon completed log out
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		string containing the landing url
	 * @since		3.0.0
	 */
	public function get_logout_landing_url()
	{
		$cnxn	= cnxn( $this->get( "cnxn_id" ) );
		return $cnxn->get( "logoutlandingurl" );
	}
	
	
	/**
	 * Grabs the login fields from the session and sends back to login redirecter
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		string		- $fields: contains any fields already assembled by child classes
	 * 
	 * @return		string containing html hidden fields
	 * @since		3.0.0
	 */
	public function get_login_fields( $fields = null )
	{
		$data	= array();
		$this->_ci->load->helper( "form" );
		$creds	= $this->_ci->session->userdata( 'int_credentials' );
		$model	= $this->get_model();
		$sends	= $model->get( "credentials" );
		$sends	= $sends['sent'];
		
		foreach ( $sends as $key => $item ) {
			$fields .= form_hidden( $item, $creds[$key] );
			$data[$item] = $creds[$key];
		}
		
		$data['integrator'] = true;
		
		return $data;
		return $fields;
	}
	
	
	/**
	 * Wrapper function to get the model object
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		object from getter
	 * @since		3.0.0
	 */
	public function get_model()
	{
		$name	= $this->type . "_m";
		$CI		= & get_instance();
		return ( isset( $CI->$name ) ? $CI->$name : false );
	}
	
	
	/**
	 * Generates a route for cnxn library when requested
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		string		- $page: contains the class/method to route
	 * 
	 * @return		string containing url
	 * @since		3.0.0 (0.1)
	 */
	public function get_route( $page = null )
	{
		$page	= ( $page == null ? get_var( 'page' ) : $page );
		$url	= site_url( $page );
		return $url;
	}
	
	
	/**
	 * Getter function
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		string		- $name: generally required (the thing we are looking for)
	 * @param		varies		- $default: the default value if $name doesn't exist
	 * @param		string		- $type: what we are getting.  Possible values include
	 * 								local:  Local variable $this->$name
	 * 
	 * @return		varies could be value, null or object being sought
	 * @since		3.0.0
	 */
	public function get( $name, $default = null, $type = 'local' )
	{
		$return	= null;
		switch ( $type ) {
			case 'local':
				$return = ( isset( $this->$name ) ? $this->$name : $default );
				break;
			default:
				$return	= ( isset( $this->params[$type][$name]['value'] ) ? $this->params[$type][$name]['value'] : $default );
				break;
		}
		
		return $return;
	}
	
	
	/**
	 * Retrieves the user fields from the configuration that can be edited
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		array containing form field definitions
	 * @since		3.0.0
	 */
	public function get_user_fields()
	{
		$type = $this->get( "type" );
		$CI = & get_instance();
		$config	= $CI->config->item( $type );
		return $config['userfields'];
	}
	
	
	/**
	 * Checks to see if connection is multisite
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		boolean
	 */
	public function is_multisite()
	{
		return false;
	}
	
	
	/**
	 * Writes the cookie data to the session cookie
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		string		- $data: contains the data to write to the cookie
	 * 
	 * @since		3.0.0
	 */
	public function handle_session_cookies( $data )
	{
		$params	= & Params :: getInstance();
		$CI		= & get_instance();
		
		$path	= $params->get( 'TmpDir' ) . DIRECTORY_SEPARATOR . $this->get( 'cnxn_id' ) . '-' . $CI->session->userdata( 'session_id' ) . '.tmp';
		
		if ( ( $result = write_file( $path, $data ) ) === false ) {
			// Log / debug errors
			log_message( 'debug', 'Cnxns_library (line ' . __LINE__ . '): Unable to write to ' . $path );
			debug( 'cnxns.handlecookie.error', 'debug' );
			return false;
		}
		
		return true;
	}
	
	
	/**
	 * Removes the cookie from the temp directory
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		mixed		- $id: false indicates use internal ID, else use specified integer
	 * @param		mixed		- $sessid: false indicates use session from userdata, else use specified session id
	 * 
	 * @since		3.0.0
	 */
	public function remove_session_cookies( $id = false, $sessid = false )
	{
		$params	= & Params :: getInstance();
		$CI		= & get_instance();
		
		$id		= ( $id ? $id : $this->get( 'cnxn_id' ) );
		$sessid	= ( $sessid ? $sessid : $CI->session->userdata( 'session_id' ) );
		
		$path	= $params->get( 'TmpDir' ) . DIRECTORY_SEPARATOR . $id . '-' . $sessid . '.tmp';
		
		if ( file_exists( $path ) ) {
			if (! @unlink( $path ) ) {
				// Log / debug errors
				log_message( 'debug', 'Cnxns_library (line ' . __LINE__ . '): Unable to delete ' . $path );
				debug( 'cnxns.removecookie.error', 'debug' );
				return false;
			}
		}
		else {
			// Log / debug errors
			log_message( 'debug', 'Cnxns_library (line ' . __LINE__ . '): File doesnt exist ' . $path );
			debug( 'cnxns.removecookie.nofile', 'debug' );
			return false;
		}
		
		return true;
	}
	
	
	/**
	 * Placeholder for retrieving the site from the designated connection
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		false - to be overwritten by child classes
	 * @since		3.0.0
	 */
	public function retrieve_site()
	{
		return false;
	}
	
	
	/**
	 * Properly sets the default values from the config file
	 * @access		protected
	 * @version		3.0.0.0.2
	 * @param		array		- $config: contains the data from the config file
	 * 
	 * @since		3.0.0
	 */
	protected function set_defaults( $config )
	{
		foreach ( $config as $k => $vals )
		{
			if (! in_array( $k, array( "name", "version", "type", "params", "credentials" ) ) ) continue;
			$this->set( $k, $vals );
		}
	}
	
	
	/**
	 * Wrapper for setting parameters in one fell swoop
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		array		- $params:  an array of parameters to set
	 * @param		string		- $type: the type of parameter to set
	 * 
	 * @since		3.0.0
	 */
	public function set_params( $params, $type = 'local' )
	{
		if (! is_array( $params ) ) return;
		
		foreach ( $params as $key => $paramset ) {
			if ( ! is_array( $paramset ) ) continue;
			foreach ( $paramset as $k => $v ) {
				$this->set( $k, $v, $key );
			}
		}
	}
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		string		- $name: the name to set
	 * @param		varies		- $value: the value to set
	 * @param		string		- $type: the type to set.
	 * 								local:  Local variable $this->$name
	 * 
	 * @return		varies will return the previous value
	 * @since		3.0.0
	 */
	public function set( $name, $value, $type = 'local' )
	{
		$return	= null;
		
		switch( $type ) {
			case 'local':
				$return = $this->get( $name );
				$this->$name = $value;
				break;
			default:
				$return = $this->get( $name, $value, $type );
				$this->params[$type][$name]['value'] = $value;
				break;
		}
		
		return $return;
	}
	
	
	/**
	 * Place holder for verifying settings in the connection
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function verify_settings()
	{
		if (! ( $model = & cnxn( $this->get( "cnxn_id" ) ) ) ) {
			return false;
		}
		
		$data	= $model->get_properties();
		$model->load( $data );
		return $model;
	}
	
	
	/**
	 * Verifies the fields required for login are present
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		boolean true if all set, false if not
	 * @since		3.0.0
	 */
	public function verify_login_requirements()
	{
		// Grab the current cnxn library and model (ie joomla15_m) and get required credentials
		$cnxn			= cnxn( $this->get( 'cnxn_id' ) );
		$model			= $this->get_model();
		$model_creds	= $model->get( "credentials" );
		$model_creds	= $model_creds['required'];
		$logins			= $this->_ci->session->userdata['int_login'];
		$stack			= array_merge( array( $logins['next'] ), $logins['done'], $logins['todo'] );
			
		// Pull current credentials
		$creds	=   $this->_ci->session->userdata['int_credentials'];
		$cuser	= & Cuser::getInstance( true );
		
		// Test the model's required creds against what we have and see if we have em
		foreach ( $model_creds as $reqd )
		{
			// If we have the required credentials for this cnxn then loop back and continue on
			if ( isset( $creds[$reqd] ) && ! empty( $creds[$reqd] ) ) continue;
			
			// We dont have the credential so we must find it now
			// Try each cnxn id in the stack to find the missing credential
			foreach ( $stack as $try )
			{
				// If we found it we will get something back
				if ( ( $found = get_api( $try )->get_missing_credential( $reqd ) ) ) {
					$creds[$reqd] = $found;
					$this->_ci->session->set_userdata( 'int_credentials', $creds );
					userlog( 'auth-credfound', array_merge( $creds, array( 'credential' => $reqd ) ), $try );
					break;
				}
			}
			
			// If we didn't find a cred then we cant log in with this cnxn
			if ( ( (bool) $found ) === false ) {
				userlog( 'auth-misscred', array_merge( $creds, array( 'credential' => $reqd ) ), $this->get( 'cnxn_id' ) );
				return false;
			}
		}
		
		// Put the credentials into the cuser object
		foreach ( array( 'username', 'email', 'password' ) as $item ) {
			$cuser->set( $item, $creds[$item] );
		}
		
		// Grab the API object for the matching cnxn
		$api	=   get_api( $this->get( 'cnxn_id' ) );
		$api->user_find( true );
		
		// User wasn't found so see if we should add them
		if ( (bool) $cuser->get( 'error', false ) )
		{
			// Test to see if we should force add the user
			if ( ( (bool) $cnxn->get( 'forceadd', false, 'users' ) ) === false ) {
				// We aren't adding the user by force so redirect to next connection
				userlog( 'find-notfound', $creds, $this->get( 'cnxn_id' ) );
				return false;
			}
			
			// Cycle through completed cnxns to build cuser
			foreach ( $logins['done'] as $cid )
			{
				// Find the user on this cnxn
				get_api( $cid )->user_find();
				$fuser	= & Cuser :: getInstance();
				
				// Error returned so try loop to try next one
				if ( (bool) $fuser->get( 'error', false ) ) continue;
				
				// We found the user, so set the password and create it
				$fuser->set( 'password', $creds['password'] );
				$this->cuser_create();
			}
		}
		
		// Authenticate the user now
		if ( $api->authenticate() === false )
		{
			// Test to see if we should update the password for the user
			if ( ( (bool) $cnxn->get( 'forcepwupdate', false, 'users' ) ) === false ) {
				// We can't update the password by force so redirect to next connection
				userlog( 'auth-badpw', $creds, $this->get( 'cnxn_id' ) );
				return false;
			}
			
			// Update the password for the user
			$fuser	= & Cuser :: getInstance();
			$update	=   array( 'password' => $creds['password'] );
			$fuser->set( 'update', $update );
			$api->user_update();

		}
		
		return true;
	}
}