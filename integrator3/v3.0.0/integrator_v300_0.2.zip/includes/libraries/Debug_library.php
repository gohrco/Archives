<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.2 ( $Id: Debug_library.php 373 2012-01-26 18:44:16Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the Debug library for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Handles debugging messages for the application
 * @version		3.0.0.0.2
 * 
 * @since		3.0.0
 * @author		Steven
 */
class Debug_library
{
	/**
	 * Stores individual lines of debug data
	 * @access		public
	 * @since		3.0.0
	 * @var			array
	 */
	public	$data			= array();
	
	/**
	 * Stores enabled property
	 * @access		public
	 * @since		3.0.0
	 * @var			bool
	 */
	public	$enabled		= false;
	
	/**
	 * Stores unset properties
	 * @access		private
	 * @since		3.0.0
	 * @var			array
	 */
	private	$_properties	= array();
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		array		- $options: any options to set at init
	 * 
	 * @since		3.0.0
	 */
	public function __construct( $options = array() )
	{
		// Type cast
		$options = ( is_array( $options ) ? $options : array( 'string' => $options ) );
		
		// Assign out
		foreach( $options as $k => $v ) {
			$this->$k = $v;
		}
		
		// Grab the debug array from session
		$data	=   array();
		$CI		= & get_instance();
		
		if ( isset( $CI->session ) ) {
			$data = unserialize( $CI->session->userdata( 'debug' ) );
			$CI->session->set_userdata( array( 'debug' => serialize( array() ) ) );
		}
		
		$this->data = $data;
	}
	
	
	/**
	 * Destructor method
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function __destruct()
	{
		$CI = & get_instance();
		
		$data	= $this->get_output();
		if ( $data ) {
			$CI->session->set_userdata( array( 'debug' => serialize( $data ) ) );
		}
		
		return true;
	}
	
	
	/**
	 * Getter method
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		string		- $name: name of property to get
	 * 
	 * @return		value or null if unset
	 * @since		3.0.0
	 */
	public function __get( $name )
	{
		return isset( $this->_properties[$name] ) ? $this->_properties[$name] : null;
	}
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		string		- $name: name of property to set
	 * @param		mixed		- $value: value of property to set
	 * 
	 * @return		mixed previous value if set or null if not previously set
	 * @since		3.0.0
	 */
	public function __set( $name, $value )
	{
		$previous	= $this->$name;
		$this->_properties[$name] = $value;
		return ( $previous != null ? $previous : true );
	}
	
	
	/**
	 * Adds a line for debugging purposes
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		string		- $data: contains the message to add
	 * @param		string		- $filename: the filename the debug was called from
	 * @param		integer		- $line: the line number called from
	 * @param		string		- $type: indicates what type of debug info this is
	 * @param		bool		- $translate: true to translate the string
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function add( $data = null, $filename = null, $line = 0, $type = 'info', $translate = false )
	{
		$this->data[]	= array( 'message' => ( $translate ? lang( $data ) : $data ), 'filename' => $filename, 'line' => $line, 'type' => $type );
		return true;
	}
	
	
	/**
	 * Get method
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		string		- $name: the name of the property to get
	 * @param		mixed		- $default: the default value to return if not set
	 * 
	 * @return		mixed value of property or default value if unset
	 * @since		3.0.0
	 */
	public function get( $name, $default = null )
	{
		$isset = $this->$name;
		return ( $isset == null ? $default : $isset );
	}
	
	
	/**
	 * Retrieves the output to respond with
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		array of data or empty array if disabled / empty
	 * @since		3.0.0
	 */
	public function get_output()
	{
		if ( $this->enabled == false ) return array();
		$data = $this->get( 'data', array() );
		$this->data = array();
		return $data;
	}
}