<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.2 ( $Id: langmap_lang.php 373 2012-01-26 18:44:16Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the pagemap controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * LANGMAP PAGE
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['langmap.index']			= "Language Mapping";
		$lang['langmap.index.desc']		= "Map the available languages from your applications to your sites so the proper translations are loaded by the Integrator.";
		
		$lang['langmap.hdr.page']			= "Language";
		$lang['langmap.hdr.defaultlang']	= "Default Language";
		
		$lang['option.pagemap.default'] 	= "use default language";
		
		$lang['msg.success.langmapsaved']	= "Language Mapping Saved";
		
		