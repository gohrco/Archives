<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.2 ( $Id: regex_helper.php 274 2011-08-31 20:10:44Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file is the "goto" file for loading necessary objects
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * Regex  Class
 * 
 * @since  3.0.0
 */
class IntRegex
{
	/**
	 * Contains the regular expression for this object
	 * @var  string
	 */
	var $regex		= null;
	
	/**
	 * Contains the content to use in place of found "link" in regular expression
	 * @var  string
	 */
	var $replace	= null;
	
	/**
	 * If we need to find the replacement value within the regular expression, then set this to true
	 * @var	 boolean
	 */
	var $replacewithregex = false;
	
	/**
	 * True to replace the entire "link", false to actually parse it as a url
	 * @var  boolean
	 */
	var $noparse	= false;
	
	/**
	 * True to replace the entire schem and host of url, false to just prepend the url
	 * @var  boolean
	 */
	var $host		= false;
	
	/**
	 * True to replace the scheme for ssl purposes, false to do nothing to scheme
	 * @var  boolean
	 */
	var $scheme		= false;
	
	
	/**
	 * Constructor
	 * @access public
	 * @param  string		If set contains the regular expression for the object
	 * @param  string		Sets the type of regular expression being run (image, base, href, title...)
	 * @param  string		If set contains the replacement value
	 * @param  boolean		True to replace the entire "link" found, false to parse it out
	 * @param  boolean		True to replace host and scheme of found link, false to only prepend it
	 * @param  boolean		True to replace scheme for ssl purposes, false to not
	 * 
	 * @since  3.0.0
	 */
	function __construct( $regex = null, $type = "default", $replace = null, $noparse = false, $host = false, $scheme = false )
	{
		if ( $regex != null ) $this->set( "regex", $regex );
		if ( $replace != null ) $this->set( "replace", $replace );
		
		$this->set( "type",		$type );
		$this->set( "noparse",	$noparse );
		$this->set( "host",		$host );
		$this->set( "scheme",	$scheme );
		
	}
	
	
	/**
	 * Runs the set regular expression against provided content
	 * @access public
	 * @param  string		Contains the site content
	 * 
	 * @return String containing scrubbed content
	 * @since  3.0.0
	 */
	public function applyRegex( $content )
	{
		
		$regex		= $this->get( "regex" );
		$replace	= $this->get( "replace" );
		$noparse	= $this->get( "noparse" );
		$replhost	= $this->get( "host" );
		$replscheme	= $this->get( "scheme" );
		
		$cnt		= 0;
		$items		= array();
		
		// If we can find the replacement in the regex then use it
		$replacewithregex	= $this->get( "replacewithregex", false );
		$replaceoriginal	= $replace;
		
		preg_match_all( $regex, $content, $matches, PREG_SET_ORDER );
		$this->set( "matches", $matches );
		
		foreach ( $matches as $match ):
			
			// Allow for finding the replacement in the regex
			if ( $replacewithregex === true ) {
				$match["back"] .= $match["replace"];
				$replace = sprintf( $replaceoriginal, $match['replace'] );
			}
			
			$cnt++;
			$items[$cnt]['find']	= $match[0];
			
			/**
			 * Catch full replacements first and continue to next one
			 */
			if ( $noparse ):
				$items[$cnt]['replace']	= $match['front'] . $replace . $match['back'];
				continue;
			endif;
			
			/** 
			 * Parse the match and the replacement into pieces
			 */
			$furl = & Uri::getInstance($match['link'], true);
			$nurl = & Uri::getInstance($replace, true);
			
			/**
			 * Test to see if we only found a fragment and do nothing
			 */
			if ($furl->isFragment()):
				$items[$cnt]['replace'] = $match[0];
				continue;
			endif;
			
			/**
			 * If we found a path, we need to prepend a slash now
			 */
			if ($furl->getPath()) {
				$furl->setPath( '/' . $furl->getPath() );
			}
			
			/**
			 * Check to see if we replace the entire host and scheme for css, js, imgs
			 */
			if ( $replhost )
			{	
				/**
				 * Test to see if the found url has a host
				 */
				if ($furl->getHost())
				{	
					/**
					 * We now pull the original url to test against and see if there is a match
					 */
					$turl = & Uri::getInstance( $this->get( "_getSiteUrl" ), true );
					if ( $turl->getHost() == $furl->getHost() )
					{
						/**
						 * The found url matches the original, so we must replace it
						 */
						$nurl->setPath( $this->_checkDuplicatePaths( $furl->getPath(), $nurl->getPath() ) );
						$furl->setHost( $nurl->getHost() );
					}
				}
				/**
				 * No host found, so check paths to ensure we don't get /path1/path1/path2 issues
				 */
				else
				{
					$furl->setPath( $this->_checkDuplicatePaths( $furl->getPath(), $nurl->getPath() ) );
					$furl->setHost( $nurl->getHost() );
				}
				
				$furl->setScheme( $nurl->getScheme() );
				$filler	= $this->_buildUrl($furl); 
				$items[$cnt]['replace'] = $match['front'].$filler.$match['back'];
				continue;
			}
			
			
			/**
			 * Check to see if the found item has a scheme / host. 
			 */
			if ($furl->getScheme())
			{
				/**
				 * Check and see if we replace the scheme (ssl purposes)
				 */
				if ( $replscheme )
				{
					$furl->setScheme( $nurl->getScheme() );
				}
				
				$filler = $this->_buildUrl($furl);
				$items[$cnt]['replace'] = $match['front'].$filler.$match['back'];
				continue;
			}
			
			/**
			 * We force absolute paths since there is no scheme set to avoid issues with subdomains
			 */
			else {
				$furl->setScheme( $nurl->getScheme() );
				$furl->setHost( $nurl->getHost() );
			}
			
			/**
			 * Check for duplicate paths
			 */
			if (($nurl->getPath()) && ($furl->getPath())) {
				$furl->setPath( $this->_checkDuplicatePaths( $furl->getPath(), $nurl->getPath() ) );
			}
			
			$filler = $this->_buildUrl($furl);
			$items[$cnt]['replace'] = $match['front'].$filler.$match['back'];
		endforeach;
		
		foreach ( $items as $item ) {
			$content	= str_replace( $item['find'], $item['replace'], $content );
		}
		
		return $content;
	}
	
	
	/**
	 * Define a property of the object if not already set
	 * 
	 * @param  string		Contains the property to define
	 * @param  string		Contains the default value or null if not provided
	 * 
	 * @return Returns the value of the property
	 * @since  3.0.0
	 */
	public function def( $property, $default = null )
	{
		$value = $this->get( $property, $default );
		return $this->set( $property, $value );
	}
	
	
	/**
	 * Get a property from the object
	 * 
	 * @param  string		Contains the property to retrieve
	 * @param  varies		Contains a default value or null if not provided
	 * 
	 * @return Returns value of property or value of default if not set
	 * @since  3.0.0
	 */
	public function get($property, $default=null)
	{
		if(isset($this->$property)) {
			return $this->$property;
		}
		return $default;
	}
	
	
	/**
	 * Sets a property for the object to the given value
	 * 
	 * @param  string		Contains the name of the property to set
	 * @param  varies		Contains the value of the property to set
	 * 
	 * @return Sends back the previous value or null if this is new
	 * @since  3.0.0
	 */
	function set( $property, $value = null )
	{
		$previous = isset($this->$property) ? $this->$property : null;
		$this->$property = $value;
		return $previous;
	}
	
	
	/**
	 * Single place to build a url, checking for javascript
	 * @access private
	 * @param  object		Contains a Uri object
	 * 
	 * @return String of output object
	 * @since  3.0.0
	 */
	private function _buildUrl($url)
	{
		$scheme = $url->getScheme();
		
		if (! is_null( $scheme ) ) {
			if ( ($scheme == 'javascript') && ( ( $url->getPath() == "/;" )  || ( $url->getPath() == ";" ) ) ) return 'javascript:;';
			if ( ( $scheme == 'javascript' ) && (! is_null( $url->getPath() ) ) ) return 'javascript:' . ltrim($url->getPath(),'/');
		}
		
		return $url->toString();
	}
	
	
	/**
	 * Checks two url paths comparing to see if they are duplicates
	 * @access private
	 * @param  string		Original path
	 * @param  string		New path
	 * 
	 * @return String containing new path
	 * @since  3.0.0
	 */
	private function _checkDuplicatePaths($orig, $new)
	{
		// The original path is coming out of the template
		// The new path is held in the needle
		
		$npath = explode('/', trim($new, '/'));
		$upath = explode('/', trim($orig, '/'));
		
		$start = false;
		// Take the first path item from original and check for existance in new path
		if (in_array($upath[0], $npath) ) {
			$start = array_search($upath[0], $npath);
		}
		
		// We know that we found the first item in the new path, now compare the rest of the path to see if it matches
		if ($start !== false) {
			$chop = true;
			for ($i=0; $i<count($npath); $i++) {
				if ($npath[$start+$i] != $upath[$i]) {
					$chop = false;
					break;
				}
			}
			if ($chop) {
				array_splice($npath, $start);
			}
		}
		
		// Reassemble the needle now and return
		return '/' . implode('/', $npath).'/'.ltrim($orig, '/');
	}
}
?>