<?php

/* SECURITY CHECKPOINT */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Loads common elements for all sub controllers (front and backend)
 * @version		3.0.0.0.2
 * 
 * @since		3.0.0
 * @author		Steven
 */
class MY_Controller extends CI_Controller
{
	/**
	 * Collection of data passed to the view
	 * @access		protected
	 * @since		3.0.0
	 * @var 		array
	 */
	protected $data		= array(	'error_message' => null,
									'success_message' => null,
									'alert_message'	=> null,
									'info_message' => null,
									'notice_message' => null 
						);
	
	/**
	 * If we are debugging then store it here
	 * @access		protected
	 * @since		3.0.0
	 * @var 		boolean
	 */
	protected $debug	= false;
	
	/**
	 * Constructor
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
		
		// Start Benchmark Point
		$this->benchmark->mark('my_controller_start');
		
		// Grab the hook global and make friendly
		$this->hooks = & $GLOBALS['EXT'];
		
		// Grab the database just in case
		$this->load->database();
		
		// Initialize the Session
		$params = & Params::getInstance();
		$stime	=   $params->get( "SessionTimeout", $this->config->item( "sess_time_to_update" ) );
		$session_init = array( "sess_time_to_update" => $stime, "sess_cookie_name" => "int_session" );
		$this->load->library( 'session', $session_init );
		log_message('debug', 'Session Loaded in My Controller' );
		
		// Initialize the Email Settings
		$this->load->library( 'email' );
		$this->email->initialize( $this->_get_email_settings() );
		$this->load->library( 'notify' );
		
		// Set Debug settings
		$options	= array( 'enabled' => $params->get( 'Debug', false ) );
		$this->load->library( 'Debug_library', $options );
		
		// Grab the user
		$this->user = $this->auth->get_user();
		
		// Autoload the connections
		$this->load->model( "cnxns_m" );
		$this->load->library( "cnxns_library" );
		
		// Cache driver
		$this->load->driver('cache', array( 'adapter' => 'apc', 'backup' => 'file' ) );
		$this->cache->apc->is_supported();
		
		// End Benchmark Point
		$this->benchmark->mark('my_controller_end');
	}
	
	
	/**
	 * Test to see if we can add connections
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		bool
	 * @since		3.0.0
	 */
	public function can_add_cnxns()
	{
		global $license;
		$count	= $license->cnxns;
		return ( count( get_cnxns() ) < $count ? true : false );
	}
	
	
	/**
	 * Checks for csrf forgeries - callback from form_validation
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function csrfcheck()
	{
		//_e( $this->session->flashdata( 'csrfkey' ) ); _e( $this->session->flashdata( 'csrfvalue' ) );
		//_e( $this->session ); _e( $this->input->post(),1 );
		if ( $this->input->post( $this->session->flashdata( 'csrfkey' ) ) === false ) return false;
		if ( $this->input->post( $this->session->flashdata( 'csrfkey' ) ) == $this->session->flashdata( 'csrfvalue' ) ) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
	/**
	 * Debug wrapper
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function debug()
	{
		return (bool) $this->debug;
	}

	
	/**
	 * Getter for reading data from SESSION only!
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		string		- $name: name of session variable to get without "int_"
	 * @param		varies		- $default: the default value to use or null
	 * 
	 * @return		varies if set returns value or default value
	 * @since		3.0.0
	 */
	public function get ( $name, $default = null )
	{
		$prefix	= "int_";
		$gname	= $prefix . $name;
		return ( ( $result = $this->session->userdata( $gname ) ) ? $result : $default );
	}
	
	
	/**
	 * Grab a reference to the model object
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		string		- $model: model name or null to retrieve called model
	 * @param		string		- $suffix: allows custom specified suffix (like _m or _model
	 * 
	 * @return		called model object
	 * @since		3.0.0
	 */
	public function get_model( $model = NULL, $suffix = "_model" )
	{
		if ( $model == NULL ) {
			$model	= strtolower( get_class( $this ) ) . $suffix;
			$suffix	= null;
		}
		
		$this->load->model( $model . $suffix );
		return $this->$model;
	}
	
	
	/**
	 * Used to retrieve the correct _v value for rendering site around Integrator
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		mixed		- $_v: if set then integer else false
	 * 
	 * @return		integer containing a value for $_v
	 * @since		3.0.0 (0.1)
	 */
	public function get_visual_cnxn( $_v = false )
	{
		$CI		= & get_instance();
		$params	= & Params :: getInstance();
		
		// Try to find the site to wrap with
		if ( $_v ) {
			get_application_session( '0', $CI->session->userdata( 'session_id' ), $_v );
		}
		else {
			$_v = get_application_session( '0', $CI->session->userdata( 'session_id' ) )->params['_v'];
		}
		
		// Error trapping for non-existant cnxns
		$isvisual = false;
		if ( ( $cnxn_lib = get_cnxn_library( $_v ) ) ) {
			$isvisual = $cnxn_lib->get( 'isvisual' );
		}
		
		// If not visual, then reset $_v
		if (! $isvisual ) $_v = false;
		
		// Nope, how about the default?
		if (! $_v ) {
			$_v	=   $params->get( 'DefaultVisualreg', false );
		}
		
		// Return regardless, let caller deal with it
		return $_v;
	}
	
	
	/**
	 * Checks to see if the call is for ajax
	 * @access		protected
	 * @version		3.0.0.0.2
	 * 
	 * @return		boolean true if ajax call, false otherwise
	 * @since		3.0.0
	 */
	protected function is_ajax()
	{
		return $this->input->server('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest';
	}
	
	
	/**
	 * Checks to see if a setting is enabled
	 * @access		protected
	 * @version		3.0.0.0.2
	 * @param		mixed		- $type: string containing type or true for global
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	protected function is_enabled( $type = true, $cnxnid = null )
	{
		$params	= & Params :: getInstance();
		
		if ( $type === true ) {
			return (bool) $params->get( 'Enable', false );
		}
		
		switch ( $type ):
		case 'user':
			
			if (! $params->get( 'EnableUser', false ) ) {
				return false;
			}
			
			// No cnxnid so return
			if ( $cnxnid == null ) return true;
			
			// Grab the cnxn
			$cnxn = cnxn( $cnxnid );
			
			// See if cnxn is active
			if (! $cnxn->get( 'active', false ) ) {
				return false;
			} 
			
			return (bool) $cnxn->get( "userenable", true, "users" );
			
			break;
		case 'visual':
			
			if (! $params->get( 'EnableVisual', false ) ) {
				return false;
			}
			
			// No cnxnid so return
			if ( $cnxnid == null ) return true;
			
			// Grab the cnxn
			$cnxn = cnxn( $cnxnid );
			
			// See if cnxn is active
			if (! $cnxn->get( 'active', false ) ) {
				return false;
			} 
			
			return (bool) $cnxn->get( 'visualenable', true, 'visuals' );
			
			break;
		endswitch;
	}
	
	
	protected function is_multisite( $_v = false, $language = null )
	{
		// if we didn't get a _v return false
		if ( $_v === false ) return false;
		
		// grab cnxn and check
		$cnxn = cnxn( $_v );
		if ( $cnxn === false ) return false;
		
		// If not multisite
		if ( $cnxn->is_multisite() === false ) return false;
		
		return true;
	}
	
	
	/**
	 * Checks for item checks - callback from form_validation
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function isitemcheck()
	{
		$item	= $this->input->post( 'item' );
		$items	= array( 'email', 'username', 'password' );
		
		if ( in_array( $item, $items ) ) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
	/**
	 * Renders the integrated site for local use
	 * @access		protected
	 * @version		3.0.0.0.2
	 * @param		string		- $page: the page to render for
	 * @param		integer		- $_v: a specific visual cnxn to pull or false for default
	 * 
	 * @return		bool true if okay
	 * @since		3.0.0
	 */
	protected function local_render( $page = 'register', $_v = false )
	{
		$params	= & Params :: getInstance();
		$CI		= & get_instance();
		$lang	=   $CI->config->item( 'language' );
		
		if ( $_v ) {
			$CI->load->model( "session_model" );
			
			$model	= & $CI->session_model;
			$model->set( "_v", $_v, 'params' );
			$model->save();
			$sess	= get_application_session( '0', $CI->session->userdata( 'session_id' ) );
		}
		else {
			$_v = get_application_session( '0', $CI->session->userdata( 'session_id' ) )->params['_v'];
		}
		
		// Determine SSL method
		$visSsl = $params->get( 'SystemSSL' );
		if ( $visSsl == '0' ) {
			$usessl = false;
		}
		else if ( $visSsl == '1' ) {
			$usessl = true;
		}
		else {
			$usessl = (bool) cnxn( $_v )->get( 'sslenabled', '0', 'visuals' );
		}
		
		$options	= array(
						'page'			=> $page,
						'language'		=> $lang,
						'characterset'	=> 'utf8',
						'session_id'	=> get_application_session()->remote,
						'isssl'			=> $usessl,
						'_a'			=> '0',
						'_v'			=> $_v,
						'_encode'		=> false
		);
		
		// Verify we can use SSL if we are going to...
		$version = curl_version();
		if (! ( $version['features'] & CURL_VERSION_SSL ) ) {
			$options['isssl'] = false;
		}
		
		$render		= new Render_library( $options );
		
		if ( $render->get( '_enabled', false ) === false ) {
			debug_error( 'Problem with rendering library' );
			return false;
		}
		
		$response	= $render->retrieve_site()->response;
		
		extract( $response );
		
		$title	= lang( 'title.' . $page );
		$regex	= '`(?P<front><title>)(?P<link>INTEGRATOR_TITLE)(?P<back><\/title>)`';
		$header	= preg_replace( $regex, "\${1}$title\${3}", $header );
		
		$base	= rtrim( base_url(), '/' ) . '/register';
		$regex	= ( $base == false ? '`(?P<front>)(?P<link><base[^>]*>)(?P<back>)`' : '`(?P<front><base[^>]*)(?P<link>INTEGRATOR_BASETAG)(?P<back>[^>]*>)`' );
		$header	= preg_replace( $regex, "\${1}$base\${3}", $header );
		
		$this->data += compact( 'header', 'body', 'footer' );
		
		return true;
	}
	
	
	/**
	 * Checks recaptcha validation - callback from form_validation
	 * @access		public
	 * @version		3.0.0.0.2
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function recaptcha()
	{
		$params	= & Params :: getInstance();
		
		// If we have disabled recaptcha, don't let it cause a failure
		if (! $params->get( 'RecaptchaEnable', false ) ) return true;
		
		$resp = recaptcha_check_answer (
					$params->get( 'RecaptchaPrivatekey' ),
					$_SERVER["REMOTE_ADDR"],
					$this->input->post( 'recaptcha_challenge_field' ),
					$this->input->post( 'recaptcha_response_field' )
		);
		
		if (! $resp->is_valid ) {
			$this->form_validation->set_message( 'recaptcha', $resp->error );
			return false;
		}
		return true;
	}
	
	
	/**
	 * Tests the signature hash for authenticity
	 * @access		private
	 * @version		3.0.0.0.2
	 * @param		string		- $salt: the salt passed to us
	 * @param		string		- $signature: the signature to test
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	protected function secret_hash_valid( $salt, $signature )
	{
		$params		= & Params :: getInstance();
		$secret		=   $params->get( 'Secret' );
		$calcsig	=   base64_encode( hash_hmac( 'sha256', $salt, $secret, true ) );
		return $signature == $calcsig;
	}
	
	
	/**
	 * Setter method for SESSION variables only
	 * @access		public
	 * @version		3.0.0.0.2
	 * @param		string		- $name: the variable name without "int_" on it
	 * @param		varies		- $value: can be any value desired
	 * @param		boolean		- $ow: true to overwrite if the variable exists already
	 * 
	 * @return		varies either the value to set it to or the original if previously set
	 * @since		3.0.0
	 */
	public function set ( $name, $value, $ow = true )
	{
		$prefix	= "int_";
		$orig	= $this->get( $name, false );
		$sname	= $prefix . $name;
		if ( $value == NULL ) {
			$this->session->unset_userdata( $sname );
			return true;
		}
		if ( ( $orig === false ) OR ( $ow ) ) {
			$this->session->set_userdata( $sname, $value );
			return ( $orig === false ? $value : $orig );
		}
		else {
			return $orig;
		}
	}
	
	
	/**
	 * Checks the global license object to ensure it is valid
	 * @access		private
	 * @version		3.0.0.0.2
	 * 
	 * @return		boolean true if valid, false otherwise
	 * @since		3.0.0
	 */
	protected function _check_license()
	{
		if ( $this->_is_public() ) {
			return true;
		}
		else {
			$current_page = $this->uri->segment(1, '') . '/' . $this->uri->segment(2, 'index');
			if ( $current_page == 'license/index' ) return true;
			global $license;
			return $license->is_valid;
		}
	}
	
	
	/**
	 * Create the email initialization array
	 * @access		private
	 * @version		3.0.0.0.2
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	private function _get_email_settings()
	{
		$params	= & Params::getInstance();
		$data	=   array();
		$auth	=   $this->config->item( 'ion_auth' );
			$auth['site_title']		= $params->get( 'Emailfromname', 'Integrator' );
			$auth['admin_email']	= $params->get( 'Emailaddress', 'admin@gohigheris.com' );
		$this->config->set_item( 'ion_auth', $auth );
		
		$data['useragent']	= 'Integrator';
		$data['protocol']	= $params->get( 'Emailprotocol', 'smtp' );
		$data['mailtype']	= 'html';
		$data['newline']	= '\r\n';
		
		if ( $data['protocol'] == 'mail' ) return $data;
		
		$data['smtp_port']	= $params->get( 'Emailsmtpport', 25 );
		$data['smtp_host']	= $params->get( 'Emailsmtphost', null );
		$data['smtp_user']	= $params->get( 'Emailsmtpuser', null );
		$data['smtp_pass']	= $params->get( 'Emailsmtppass', null );
		
		return $data;
	}
	
	
	/**
	 * Tests the current page to see if it is publicly accessible
	 * @access		private
	 * @version		3.0.0.0.2
	 * 
	 * @return		boolean true if public
	 * @since		3.0.0
	 */
	protected function _is_public()
	{
		// These pages get past permission checks
		$ignored_pages = array( 'admin/login', 'admin/logout', 'admin/forgot_password', 'admin/reset_password', 'admin/complete' );
		
		// Check if the current page is to be ignored
		$current_page = $this->uri->segment(1, '') . '/' . $this->uri->segment(2, 'index');
		
		// Dont need to log in, this is an open page
		if ( in_array( $current_page, $ignored_pages ) ) {
			return true;
		}
		
		return false;
	}
}


if ( ! class_exists('Admin_Controller')) {
	require_once "Admin_Controller.php";
}

if ( ! class_exists('Cnxns_library') ) {
	require_once APPPATH . "/libraries/Cnxns_library.php";
}

if ( ! class_exists('API_Library') ) {
	require_once APPPATH . "/libraries/API_Library.php";
}

if ( ! class_exists('Render_library') ) {
	require_once APPPATH . "/libraries/Render_library.php";
}
