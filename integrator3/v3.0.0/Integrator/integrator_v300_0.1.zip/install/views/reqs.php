<?php echo form_open( $action ); ?>

<div class="append-bottom border-bottom">
	<div class="span-20 push-2 last">
	
		<?php foreach( $items as $key => $item ) : ?>
		
		<div class="span-16 append-bottom border-bottom">
			<h2><?php echo lang( 'title.' . $key ); ?></h2>
			<?php if ( is_array( $item ) ) : foreach ( $item as $sub ): ?>
			<div class="span-2 txtctr append-bottom">
				<?php echo img( 'assets/img/icon32-' . ( $sub->use ? 'success' : 'error' ) . '.png' ); ?>
			</div>
			<div class="span-13 append-bottom" style="font-size: 115%; font-weight: bold; ">
				<?php echo $sub->msg; ?>
			</div>
			<div class="clear"> </div>
			<?php endforeach; else: ?>
			<div class="span-2 txtctr">
				<?php echo img( 'assets/img/icon32-' . ( $item->use ? 'success' : 'error' ) . '.png' ); ?>
			</div>
			<div class="span-13" style="font-size: 115%; font-weight: bold; ">
				<?php echo $item->msg; ?>
			</div>
			<div class="clear"> </div>
			<?php endif; ?>
		</div>
		<div class="clear"> </div>
		
		<?php endforeach; ?>
		
	</div>
	<div class="clear"> </div>
</div>

<?php foreach( $hidden as $hide ) : ?>
<?php echo $hide->field; ?>
<?php endforeach; ?>

<div class="push-9 append-bottom clear">
	<?php echo form_button( array( 'name' => 'submit', 'id' => 'submit', 'value' => true, 'type' => 'submit', 'content' => lang( $submit ) ) );?>
</div>

<?php echo form_close(); ?>