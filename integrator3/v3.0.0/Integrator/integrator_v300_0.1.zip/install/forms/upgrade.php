<?php

$form['backup']	= array(
	'verify'	=> array(
		'value'			=> null,
		'order'			=> 10,
		'type'			=> 'checkbox',
		'validation'	=> 'required'
	)
);

$form['tos']	= array(
	'submit'	=> array(
		'value'			=> null,
		'order' 		=> 10,
		'type'			=> 'checkbox',
		'validation'	=> 'required'
	),
);
