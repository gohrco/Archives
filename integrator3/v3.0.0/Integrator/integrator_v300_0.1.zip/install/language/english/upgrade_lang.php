<?php

$lang['upgrade']				= 'Upgrade';
$lang['upgrade.index']			= 'Checking your installation...';
$lang['upgrade.step1']			= 'Step 1:  Verify Database Backup';
$lang['upgrade.step2']			= 'Step 2:  Terms of Service';
$lang['upgrade.step3']			= 'Step 3:  Upgrading';

$lang['menu.step1']				= 'Step 1:  Verify Backup';
$lang['menu.step2']				= 'Step 2:  TOS';
$lang['menu.step3']				= 'Step 3:  Upgrade';
$lang['menu.step4']				= 'Complete';

$lang['button.agree']			= 'I Agree';
$lang['button.disagree']		= 'I Disagree';
$lang['button.tryagain']		= 'Try Again';
$lang['button.step1']			= 'CONFIRM BACKUP PERFORMED';

$lang['verify']					= "Database Backup Performed";
$lang['verify.desc']			= "Before upgrading your application, it is highly recommended that you perform a backup of your database.";
