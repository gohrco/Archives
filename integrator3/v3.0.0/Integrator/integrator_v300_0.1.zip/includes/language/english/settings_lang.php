<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.1 ( $Id: settings_lang.php 409 2012-02-28 01:37:52Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the admin controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * ALL PAGES
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['btn.saveandclose']			= 'Save and Return to Dashboard';
		$lang['btn.updatesettings']			= "Save Settings";
		
		$lang['msg.success.savedsettings']	= "Settings Saved";
		$lang['msg.error.savedsettings']	= "An unknown error occurred saving your settings.";
		
		
/**
 * **********************************************************************
 * GENERAL SETTINGS PAGE
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['settings.index']				= 'General Settings';
		$lang['settings.index.desc']		= 'Make changes to the settings below.';
		
		
/**
 * **********************************************************************
 * GENERAL SETTINGS - GLOBAL TAB
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['global.tab']		= "Global Settings";
		
		$lang['label.global.Sitename']		= "Sitename";
		$lang['label.global.Enable']		= "Enable Integrator";
		$lang['label.global.Debug']			= "Debug";
		
		$lang['desc.global.Sitename']		= "A reference name for your Integrator application.";
		$lang['desc.global.Enable']			= "This setting turns the entire Integrator on or off and acts as a master switch.";
		$lang['desc.global.Debug']			= "Turn this setting on if you encounter issues and need to debug the application.";
		
		
/**
 * **********************************************************************
 * GENERAL SETTINGS - SYSTEM TAB
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['system.tab']		= 'System Settings';
		
		$lang['label.system.SystemURL']		= 'System URL';
		$lang['label.system.TmpDir']		= 'Temp Directory';
		$lang['label.system.LogDir']		= 'Log Directory';
		$lang['label.system.LogCount']		= 'Log Records';
		
		$lang['desc.system.SystemURL']		= 'Enter the URL to this application.';
		$lang['desc.system.TmpDir']			= 'This directory stores session sensitive information for customers.  It is highly recommended that this directory be moved below the public_html folder to prevent unwanted or accidental access.';
		$lang['desc.system.LogDir']			= 'This directory stores diagnostic information for the Integrator 3 application; the default directory should be fine.';
		$lang['desc.system.LogCount']		= 'Indicates the number of log records that should be stored in the database; note this is different from the diagnostic files stored in the directory above.';
		
		
/**
 * **********************************************************************
 * GENERAL SETTINGS - EMAIL TAB
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['email.tab']		= "Email Settings";
		
		$lang['label.email.Emailprotocol']		= "Email Protocol";
		$lang['label.email.Emailsmtpport']		= "SMTP Port";
		$lang['label.email.Emailsmtphost']		= 'SMTP Host';
		$lang['label.email.Emailsmtpuser']		= 'SMTP Username';
		$lang['label.email.Emailsmtppass']		= 'SMTP Password';
		$lang['label.email.Emailfromname']		= 'Admin From Name';
		$lang['label.email.Emailaddress']		= 'Admin Email Address';
		
		$lang['desc.email.Emailprotocol']		= "Select how to send email to administrators.";
		$lang['desc.email.Emailsmtpport']		= "If using SMTP above, enter the port number for your SMTP server";
		$lang['desc.email.Emailsmtphost']		= 'If using SMTP above, enter the hostname for your SMTP server.';
		$lang['desc.email.Emailsmtpuser']		= 'If using SMTP above and your server requires authentication, enter the username for your SMTP server.';
		$lang['desc.email.Emailsmtppass']		= 'If using SMTP above and your server requires authentication, enter the password for your SMTP server.';
		$lang['desc.email.Emailfromname']		= 'Enter the name you would like to appear as the from name (not the from email address) for all system messages.';
		$lang['desc.email.Emailaddress']		= 'Enter the email address to appear as the from email address for all system messages.';
		
		$lang['options.email.Emailprotocol']	= array( 'smtp' => "SMTP ", 'mail' => "PHP Mail" );
		
		
/**
 * **********************************************************************
 * API SETTINGS PAGE
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['settings.api']			= 'API Settings';
		$lang['settings.api.desc']		= 'Make changes to the settings below.';
		
		
/**
 * **********************************************************************
 * API SETTINGS - GENERAL TAB
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['api.tab']			= "API Settings";
		
		$lang['label.api.Secret']		= "API Secret Key";
		$lang['desc.api.Secret']		= "For security purposes, a random code is set here and should be used as your other integrated applications to securely connect to the Integrator API.  This setting cannot be changed, and is randomly generated.  You can change that setting here.  <strong><u>Never give out your API Secret Key!</u></strong>";
		
		
/**
 * **********************************************************************
 * API SETTINGS PAGE
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['settings.user']			= 'User Bridging Settings';
		$lang['settings.user.desc']		= 'Make changes to the settings below.';
		
		
/**
 * **********************************************************************
 * USER SETTINGS - GENERAL SETTINGS TAB
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['users.tab']		= "General Settings";
		
		$lang['label.users.EnableUser']		= "Enable User Integration";
		$lang['label.users.SessionTimeout']	= "Session Timeout";
		$lang['label.users.Defaultuser']	= "Default Account Site";
		
		$lang['desc.users.EnableUser']		= "Turn this setting on to allow users to be bridged across all your applications.";
		$lang['desc.users.SessionTimeout']	= "Set the session timeout level for your users on this application.  Note that for best results, all your session timeouts should matchup across all your applications.";
		$lang['desc.users.Defaultuser']		= "When a user is logged in, this connection will act as the 'goto' connection for displaying their information to them from another connection.";
		
		$lang['options.users.UseSSL']	= array( 0 => "Never Use", 1 => "Always Use (Force)", 2 => "Use When Present (Ignore)" );
		
		
/**
 * **********************************************************************
 * USER SETTINGS - LOG IN DISPLAY SETTINGS TAB
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['display.tab']		= "Display Settings";
		
		$lang['label.display.DisplayLogin']	= "Display Log In / Out Message";
		$lang['label.display.LoginMsg']		= "Login Message";
		$lang['label.display.LogoutMsg']	= "Logout Message";
		
		$lang['desc.display.DisplayLogin']	= "This setting allows the use of a wrapped iFrame to log a user in, thereby displaying a message to the user indicating that they are logging in or logging out.  This also 'hides' to an extent the page jumps when logging in or out";
		$lang['desc.display.LoginMsg']		= "If you are using the iframe version of the log in / out procedure, you can set a custom message to display to your users here.";
		$lang['desc.display.LogoutMsg']		= "If you are using the iframe version of the log in / out procedure, you can set a custom message to display to your users here.";
		
		
/**
 * **********************************************************************
 * VISUAL SETTINGS PAGE
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['settings.visual']			= 'Visual Setup Settings';
		$lang['settings.visual.desc']		= 'Make changes to the settings below.';
		
		
/**
 * **********************************************************************
 * VISUAL SETTINGS - GENERAL SETTINGS TAB
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['visual.tab']		= "General Settings";
		
		$lang['label.visual.EnableVisual']		= "Enable Visual Integration";
		$lang['label.visual.Defaultvisual']		= "Default Visual Site";
		$lang['label.visual.SystemSSL']			= "Use SSL on Log In / Out";
		$lang['label.visual.UnicodeMatching']	= "Unicode Matches";
		
		$lang['desc.visual.EnableVisual']		= "Turn this setting on to wrap your applications with your selected sites.";
		$lang['desc.visual.Defaultvisual']		= "If a user is accessing an application directly without having first gone to a site to set the appropriate id, select which site should wrap your application by default.";
		$lang['desc.visual.SystemSSL']			= "If you have a valid security certificate for the domain that the Integrator is used on and the domains your applications are used on, you can enable this to protect sensitive information for customers when logging in or out.";
		$lang['desc.visual.UnicodeMatching']	= "<i>Advanced!</i> If you encounter issues wrapping your site properly, you can try disabling the unicode matching to see if it rectifies the situation";
		
		$lang['options.visual.SystemSSL']		= array( 0 => "Never Use", 1 => "Always Use (Force)", 2 => "Use When Present (Ignore)" );

/**
 * **********************************************************************
 * VISUAL SETTINGS - CACHE SETTINGS TAB
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['cache.tab']		= "Caching";
		
		$lang['label.cache.Cache']				= "Enable Caching";
		$lang['label.cache.CacheTTL']			= "Cache TTL";
		$lang['label.cache.Clearcache']		= 'Clear Cache';
		
		$lang['desc.cache.Cache']				= "Enabling the cache system will speed up rendering of your sites around your applications.";
		$lang['desc.cache.CacheTTL']	= "Time to live for the cache (in minutes)";
		$lang['desc.cache.Clearcache']	= 'Clear the cache in the application.';
		
		
/**
 * **********************************************************************
 * REGISTRATION SETTINGS PAGE
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['settings.registrations']			= 'Registration Settings';
		$lang['settings.registrations.desc']	= 'Make changes to the settings below.';
		
		
/**
 * **********************************************************************
 * REGISTRATION SETTINGS - REGISTRATION SETTINGS TAB
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['reggeneral.tab']		= "General Settings";
		
		$lang['reggeneral.EnableRegistration']	= "Enable Registration";
		$lang['reggeneral.EnableCSValidation']	= "Enable AJAX";
		$lang['reggeneral.DefaultVisualreg']		= "Registration Site";
		$lang['reggeneral.RegRedirectionUrl']		= "URL Upon Success";
		
		$lang['desc.reggeneral.EnableRegistration']	= "You can choose to use the Integrator's built in registration form which will create a registration form requesting any necessary fields for your various connections and provide a single point of registration for your site.";
		$lang['desc.reggeneral.EnableCSValidation']	= "This permits the Integrated Registration form to use javascript and AJAX calls to validate data before the user creates their new account.";
		$lang['desc.reggeneral.DefaultVisualreg']		= "You can specify a connection here to retrieve for wrapping your registration form with, unless it is overridden by a direct call from another connection.";
		$lang['desc.reggeneral.RegRedirectionUrl']	= "Enter a URL to redirect your new user to upon successful registration.";
		
		
/**
 * **********************************************************************
 * REGISTRATION SETTINGS - RECAPTCHA SETTINGS TAB
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['recaptcha.tab']		= "reCaptcha Settings";
		
		$lang['recaptcha.RecaptchaEnable']		= "Enable reCaptcha";
		$lang['recaptcha.RecaptchaPublickey']	= "reCaptcha Public Key";
		$lang['recaptcha.RecaptchaPrivatekey']	= "reCaptcha Private Key";
		$lang['recaptcha.RecaptchaTheme']		= "reCaptcha Theme";
		$lang['recaptcha.RecaptchaLang']			= "reCaptcha Language";
		
		$lang['desc.recaptcha.RecaptchaEnable']		= "If you want to use reCaptcha for user registration, you can enable it here.";
		$lang['desc.recaptcha.RecaptchaPublickey']	= "Enter your reCaptcha Public Key";
		$lang['desc.recaptcha.RecaptchaPrivatekey']	= "Enter your reCaptcha Private Key";
		$lang['desc.recaptcha.RecaptchaTheme']		= "Select the reCaptcha theme you want to use";
		$lang['desc.recaptcha.RecaptchaLang']		= "Select the reCaptcha language you want to use";
		
		$lang['recaptcha.RecaptchaTheme_options']	= array( 'blackglass' => 'Black Glass', 'clean' => 'Clean', 'red' => 'Red', 'white' => 'White' );
		$lang['recaptcha.RecaptchaLang_options']	= array( 'en' => "English", 'nl' => "Dutch", 'fr' => 'French', 'de' => 'German', 'pt' => 'Portuguese', 'ru' => 'Russian', 'es' => 'Spanish', 'tr' => 'Turkish' );
		
		
/**
 * **********************************************************************
 * REGISTRATION SETTINGS - FIELD ORDERING SETTINGS TAB
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['fieldorder.tab']		= "Field Order";

		$lang['fieldorder.FieldOrder']			= "Field Order";
		
		$lang['desc.fieldorder.FieldOrder']		= "Arrange the order of the fields as they appear on your registration form by clicking and dragging the field name into the desired order.  Some fields may not be used for all connections, and some fields are redundant, for example if one connection asks only for a full name, and another asks for a first and last name, the first and last name will be requested and the full name assembled from those fields.";
		