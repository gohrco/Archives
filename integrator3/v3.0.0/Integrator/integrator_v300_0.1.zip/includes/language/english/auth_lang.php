<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.1 ( $Id: auth_lang.php 373 2012-01-26 18:44:16Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the authentication library for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * MESSAGES
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['msg.success.activate']		= "Account Activated";
		$lang['msg.success.deactivate']		= "Account De-Activated";
		$lang['msg.success.pwchange']		= "Password Successfully Changed";
		$lang['msg.success.pwforgot']		= "Password Reset Email Sent";
		$lang['msg.success.acctcreated']	= "Account Successfully Created";
		$lang['msg.success.login']			= "Logged In Successfully";
		$lang['msg.success.logout']			= "Logged Out Successfully";
		$lang['msg.success.update']			= "Account Information Successfully Updated";
		$lang['msg.success.delete']			= "User Deleted";
		
		$lang['msg.error.activate']			= "Unable to Activate Account";
		$lang['msg.error.deactivate']		= "Unable to De-Activate Account";
		$lang['msg.error.pwchange']			= "Unable to Change Password";
		$lang['msg.error.pwforgot']			= "Unable to Reset Password";
		$lang['msg.error.acctcreated']		= "Unable to Create Account";
		$lang['msg.error.login']			= "In-Correct Login";
		$lang['msg.error.update']			= "Unable to Update Account Information";
		$lang['msg.error.delete']			= "Unable to Delete User";
		