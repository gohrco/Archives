<?php

$form['reggeneral']	= array(
	'EnableRegistration' => array(
			'value'			=> true,
			'order'			=> 10,
			'type'			=> 'yesno',
			'validation'	=> 'required|is_natural'
		),
	'EnableCSValidation' => array(
			'value'			=> true,
			'order'			=> 20,
			'type'			=> 'yesno',
			'validation'	=> 'required|is_natural'
		),
	'DefaultVisualreg' => array(
			'value'			=> null,
			'order'			=> 30,
			'type'			=> 'dropdown-cnxnvisual',
			'validation'	=> ''
		),
	'RegRedirectionUrl' 	=> array(
			'value'			=> "http://",
			'order'			=> 40,
			'type'			=> 'text',
			'validation'	=> 'xss_clean'
		),
);

$form['recaptcha']	= array(
	'RecaptchaEnable' => array(
			'value'			=> true,
			'order'			=> 80,
			'type'			=> 'yesno',
			'validation'	=> 'required|is_natural'
		),
	'RecaptchaPublickey' 	=> array(
			'value'			=> "",
			'order'			=> 90,
			'type'			=> 'text',
			'validation'	=> ''
		),
	'RecaptchaPrivatekey' 	=> array(
			'value'			=> "",
			'order'			=> 100,
			'type'			=> 'text',
			'validation'	=> ''
		),
	'RecaptchaTheme' 	=> array(
			'value'			=> 'red',
			'order'			=> 110,
			'type'			=> 'dropdown',
			'validation'	=> ''
		),
	'RecaptchaLang' 	=> array(
			'value'			=> 'en',
			'order'			=> 120,
			'type'			=> 'dropdown',
			'validation'	=> ''
		),
);

$form['fieldorder']	= array(
	'FieldOrder'		=> array(
			'array'			=> true,
			'value'			=> null,
			'order'			=> 130,
			'type'			=> 'sortfields',
			'validation'	=> 'required'
		),
);
