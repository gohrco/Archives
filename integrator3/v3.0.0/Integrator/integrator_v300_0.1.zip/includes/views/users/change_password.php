<?php echo form_open("users/change_password/" . $user_id['value'] );?>

<div class="append-bottom clear"><label class="span-4" for="new_password"><?php echo lang( 'users.change_password.newpw' ); ?></label>
<?php echo form_input($new_password);?>
</div>

<div class="append-bottom clear"><label class="span-4" for="new_password_confirm"><?php echo lang( 'users.change_password.confpw' ); ?></label>
<?php echo form_input($new_password_confirm);?>
</div>

<div class="push-4 append-bottom clear"><?php echo form_button( array( 'name' => 'submit', 'id' => 'submit', 'value' => true, 'type' => 'submit', 'content' => lang( 'users.change_password' ) ) );?></div>      

<?php echo form_close();?>