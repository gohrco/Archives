<?php echo form_open("admin/login", array( 'id' => 'loginForm' ) );?>

<?php foreach ( $fields as $item ) : ?>
<div class="append-bottom border-bottom">
	<?php if ( $item->desc != 'remember' ): ?>
	<div class="span-10 left">
		<div class="span-4"><?php echo $item->label; ?></div>
		<div class="span-6 last"><?php echo $item->field; ?></div>
	</div>
	<?php else: ?>
	<div class='span-10 last'>
		<div class="span-4">&nbsp;</div>
		<div class="span-6 last">
			<?php echo $item->field; ?>&nbsp;<?php echo $item->label; ?>
		</div>
	</div>
	<?php endif; ?>
	<div class="clear"> </div>
</div>
<?php endforeach; ?>

<?php foreach( $hidden as $hide ) : ?>
<?php echo $hide->field; ?>
<?php endforeach; ?>

<div class="push-4 append-bottom clear">
	<?php echo form_button( array( 'name' => 'submit', 'id' => 'submit', 'value' => true, 'type' => 'submit', 'content' => lang( 'btn.login' ) ) );?>
</div>
<?php echo form_close();?>
<div class="clear"> </div>
<div class="span-10 prepend-top append-bottom clear txtctr">
	<?php echo anchor( 'admin/forgot_password', lang( 'forgot.password' ) ); ?>
</div>

<script language="javascript">
$(function (){ $('#username').focus(); });
</script>