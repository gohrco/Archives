<?php 

foreach ( $results as $result ) :
	$userlink = ( $result->username != $user ? $result->link_user : '&nbsp;' );
	$uservolume = 'loud';
	if ( ( empty( $result->username ) && $result->isfound ) ) {
		$uservolume = "quiet";
		$result->username = "unused";
	}
	else if ( empty( $result->username ) ) {
		$uservolume = "quiet"; 
		$result->username = "not found";
	}
	
	$emaillink = ( $result->email != $user ? $result->link_email : '&nbsp;' );
	if ( $result->isfound === false ) $result->email = "not found";
?>

<div class="append-bottom border-bottom">
	<div class="span-23 last">
		<div class="span-4 border">
			<div class="span-1" style="margin-top: 0.5em; "><?php echo image( "icon16-" . ( $result->isfound ? "success" : "error" ) . ".png" ); ?></div>
			<div class="span-1" style="margin-top: 0.5em; "><?php echo ( $result->isfound ? $result->edit_user : $result->add_user ); ?></div>
			<div class="span-1" style="margin-top: 0.5em; "><?php echo ( $result->isfound ? $result->del_user : '&nbsp;' ); ?></div>
			<div class="span-1 last" style="margin-top: 0.5em; "><?php echo ( $result->isfound ? $result->user_log : '&nbsp;' ); ?></div>
			<div class="span-4 loud last txtctr">
				<?php if ( $result->isfound ) : ?>
					<span style="color: <?php echo $result->active ? "Green" : "Red" ?>"><?php echo $result->active ? "A" : "Ina"; ?>ctive user</span>
				<?php else : ?>
					<span class= "quiet"><?php echo $result->error; ?></span>
				<?php endif; ?>
			</div>
		</div>
		<div class="span-3 border">
			<span class="span-3 loud last" style="font-size: 1.2em; "><?php echo $result->cnxn_name; ?></span>
			<span class="span-3 quiet last" style="font-size: 0.75em; ">connection name</span>
		</div>
		<div class="span-6 border">
			<span class="span-1" style="margin-top: 0.5em; "><?php echo $userlink; ?></span>
			<span class="span-5 <?php echo $uservolume; ?> last" style="font-size: 1.2em; "><?php echo $result->username; ?></span>
			<span class="span-5 quiet last" style="font-size: 0.75em; margin-left: 40px; ">username</span>
		</div>
		<div class="span-6 last">
			<span class="span-1" style="margin-top: 0.5em; "><?php echo $emaillink; ?></span>
			<span class="span-5 <?php echo ( $result->isfound ? "loud" : "quiet" ) ?> last" style="font-size: 1.2em; "><?php echo $result->email; ?></span>
			<span class="span-5 quiet last" style="font-size: 0.75em; margin-left: 40px; ">email address</span>
		</div>
	</div>
	<div class="clear"> </div>
</div>
<?php endforeach; ?>
