<?php if (! empty( $debug ) ) : 		// Check for Debug array ?>
	<div id="debug">
		
		<h3>Debug Information</h3>
		
		<ol>
		
		<?php foreach ( $debug as $d ) : ?>
			
			<li class="debug_item debug_<?php echo $d['type']; ?>">
				<div class="debug_message">[<?php echo $d['type']; ?>] <?php echo $d['message']; ?></div>
				<div class="debug_details"><?php echo $d['filename']; ?> @ line <?php echo $d['line']; ?></div>
			</li>
	
		<?php endforeach; ?>
		
		</ol>
		
		<div style="clear: both; line-height: 1px; ">&nbsp;</div>
		
	</div>
	
<?php endif;							// End Check for Debug array ?>