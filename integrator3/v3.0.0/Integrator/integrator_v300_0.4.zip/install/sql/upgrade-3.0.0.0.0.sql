INSERT INTO `__DBPREFIX__settings` (`key`, `value`) VALUES
('DisplayLogin', '0'),
('SystemURL', '__SYSTEMURL__'),
('SystemSSL', '0'),
('TmpDir', '__TMPDIR__'),
('LogCount', '1000'),
('LoginMsg', 'msg.redirectingnow'),
('LogoutMsg', 'msg.redirectingnow');

-- command split --

UPDATE `__DBPREFIX__settings` SET `value`='3.0.0.0.1' WHERE `key` = 'Version';