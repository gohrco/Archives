<?php

$CI = & get_instance();
$CI->load->helper( 'assets' );

$includes	= array();
$includes[]	= blueprint( 'screen.css' );
$includes[] = blueprint( 'print.css', 'media' );
$includes[] = "<!--[if lt IE 9]>" . blueprint( "ie.css" ) . "<![endif]-->";
$includes[] = blueprint( 'plugins/buttons/screen.css' );
$includes[] = blueprint( 'plugins/fancy-type/screen.css' );
$includes[] = js( "jquery-1.5.1.min.js" );
$includes[] = js( "jquery-ui-1.8.13.custom.min.js" );
$includes[] = js( 'functions.js' );
$includes[] = css( "jquery-ui-1.8.13.custom.css" );
$includes[] = css( "admin.css" );
$includes[] = css( "login.css" );

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<!-- Always force latest IE rendering engine & Chrome Frame -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	
	<title>404 Page Not Found</title>
	<base href="<?php echo base_url(); ?>" />
	<?php foreach ( $includes as $i ): ?>
	<?php echo $i . "\n"; ?>
	<?php endforeach; ?>
					
	<!-- Mobile Viewport Fix -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
	
	<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
	
</head>
<body>

<div id="login-wrap">
	<div id="side-hdr">
		<?php echo image( 'new-logo.png', null, array( 'id' => 'logo' ) ); ?>
		<h3>Integrator <small>v</small>3.0</h3>
	</div>
	<div id="loginBox">
		<div class="clear">&nbsp;</div>
		<div class="append-bottom txtctr"><h1><?php echo $heading; ?></h1></div>
		<div class="txtctr"><?php echo $message; ?></div>
	</div>
</div>
</body>
</html>