<?php if (! empty( $steps ) ) : ?>

<div class="boxer" id="rsswrap">
	
	<h2 style="margin-bottom: 0 !important">
	
	<?php echo lang( 'stepbystep.title' ); ?>
	
	<?php echo anchor( 'admin/turn_off/stepbystep', image( 'icon16-error.png' ), 'class="btn"' ); ?>
	
	</h2>
	
	<ul id="rss-feed">
		
		<?php foreach ( $steps as $i => $step ) :?>
		<li>
			
			<div class="star">
				<?php echo lang( 'stepbystep.num.' . $i ); ?>
			</div>
			
			<div class="itemwrap">
				<span class="title"><?php echo lang( 'stepbystep.title.' . $i ); ?></span>
				<p><?php echo sprintf( lang( 'stepbystep.desc.' . $i ), $step ); ?></p>
			</div>
			
		</li>
		
		<?php endforeach; ?>
		
	</ul>
	
</div>

<?php endif; ?>