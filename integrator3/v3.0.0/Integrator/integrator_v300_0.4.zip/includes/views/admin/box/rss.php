<div class="boxer" id="rsswrap">
	
	<h2>
	
	<?php echo lang( 'rssfeed.title' ); ?>
	
	<?php echo ( is_null( $rss ) ? anchor( 'admin/turn_on/rss', image( 'icon16-up.png' ), 'class="btn"' ) : anchor( 'admin/turn_off/rss', image( 'icon16-down.png' ), 'class="btn"' ) ); ?>
	
	</h2>
	
	<?php if (! is_null( $rss ) ) : ?>
	
	<ul id="rss-feed">
		
		<?php foreach ( $rss as $item ) : ?>
		
		<li>
			<h3><?php echo anchor( $item->link, $item->title, 'target="_blank"' ); ?></h3>
			<div class="date">
				<span><?php echo date( "M", $item->pubDate ); ?></span>
				<?php echo date( "d", $item->pubDate ); ?>
			</div>
			<p><?php echo $item->description; ?></p>
		</li>
		
		<?php endforeach; ?>
		
	</ul>
	
	<?php endif; ?>
	
</div>