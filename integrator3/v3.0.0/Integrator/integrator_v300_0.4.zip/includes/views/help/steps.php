
<?php foreach( $items as $count => $item ) : ?>

<div class="append-bottom">
	
	<div class="span-19 last">
		
		<div class="title">
			
			<span class="icon step<?php echo $count; ?>">&nbsp;</span>
			
			<?php echo lang( 'help.sbs.' . $count . '.title' ); ?>
			
		</div>
		
	</div>
	
	<div class="span-19 last"><hr /></div>
	
	<div class="push-2 span-17 last clearfix">
	
	<?php foreach ( $item as $msg ) : ?>
	
	<p>
		
		<?php echo $msg; ?>
		
	</p>
	
	<?php endforeach; ?>
	
	</div>
	
</div>

<?php if ( $count != ( count( $items ) +1 ) ) : ?>
<hr />
<?php endif; ?>

<?php endforeach; ?>
