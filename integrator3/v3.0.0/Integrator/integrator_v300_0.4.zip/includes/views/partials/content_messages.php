<!--<?php if ( $alert_message ) : ?>
<div class="alert"><div class="content"><?php echo $alert_message; ?></div></div>
<?php endif; ?>
-->

<!--<?php if ( $info_message ) : ?>
<div class="info" id="info"><div class="content"><?php echo $info_message;?></div></div>
<script>jQuery("#info").delay('400000').fadeTo('slow', 0);</script>
<?php endif; ?>
-->
<!--<?php if ( $notice_message ) : ?>
<div class="notice"><div class="content"><?php echo $notice_message;?></div></div>
<?php endif; ?>
-->
<?php if ( $error_message ) : ?>
<div class="error">
	<span>An error was encountered:</span>
	<ul>
		<?php echo $error_message; ?>
	</ul>
</div>
<?php endif; ?>

<!--<?php if ( $success_message ) : ?>
<div class="success" id="successMessage"><div class="content"><?php echo $success_message;?></div></div>
<script>jQuery("#successMessage").delay('3000').fadeOut('Fast', 0);</script>
<?php endif; ?>
-->