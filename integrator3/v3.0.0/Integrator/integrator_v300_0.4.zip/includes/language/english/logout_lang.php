<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.4 ( $Id: logout_lang.php 406 2012-02-27 22:19:40Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the admin controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * **********************************************************************
 * MESSAGES
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['msg.error.credsorigin']		= "Originating Connection Information missing: Unable to proceed";
		$lang['msg.error.userdisabled']		= 'User Integration disabled in Global Configuration - returning to origin.';
		$lang['msg.error.cnxnsdisabled']	= 'No connections are active to log out of - returning to origin.';
		
		$lang['title.logout']				= "Logging Out";
		$lang['msg.redirectingnow']			= "Logging Out...";