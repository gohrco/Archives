<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.4 ( $Id: usermgr_lang.php 398 2012-02-27 03:32:14Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the user manager controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * USER FORM FIELDS
 * - Translations may be overridden in cnxn specified language file
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['label.email']			= "Email Address";
		$lang['label.username']			= "Username";
		$lang['label.name']				= "Name";
		$lang['label.password']			= "Password";
		
		$lang['desc.email']				= "Enter the email address to use for this account.";
		$lang['desc.username']			= "Enter a unique username for this account.";
		$lang['desc.name']				= "Enter a complete name for this account.";
		$lang['desc.password']			= "Enter a password for this account.";
		
		$lang['label.cnxnid']		= "Select Connection";
		$lang['desc.cnxnid']		= "Select a connection to find the user from.  Changes made to the user on this connection will only affect the selected connection.";
		
		
/**
 * **********************************************************************
 * LOG MESSAGES
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['USERMGR_LOG_AUTH']				= "User `%s` authenticated against %s";
		$lang['USERMGR_LOG_AUTH_BADPW']			= 'The password for `%s` is incorrect on `%s`';
		$lang['USERMGR_LOG_AUTH_MISSCRED']		= 'The user `%s` is missing `%s` for `%s`';
		$lang['USERMGR_LOG_AUTH_CREDFOUND']		= 'Found `%s` for `%s` using `%s` on `%s`';
		$lang['USERMGR_LOG_AUTH_RETERROR']		= "Unable to determine the return URL for a login coming from the `%s` connection!";
		$lang['USERMGR_LOG_AUTH_RETERRLOUT']	= "No return url was found for a login coming from `%s`; the logout url was used!";
		$lang['USERMGR_LOG_AUTH_CREDSMISS']		= "No credentials were passed along by the user when they logged in; sending back to `%s`";
		$lang['USERMGR_LOG_AUTH_CNXNERR']		= "Settings are preventing a user to log in from `%s`";
		$lang['USERMGR_LOG_AUTH_TYPEMIS']		= "The user passed neither a username or email to login with; sending back to `%s`";
		$lang['USERMGR_LOG_LOGINN']				= "User unable to log into %s using `%s`";
		$lang['USERMGR_LOG_LOGINY']				= "User successfully logged in on %s using `%s`";
		$lang['USERMGR_LOG_FINDN']				= 'Unable to find the user `%s` on `%s`';
		$lang['USERMGR_LOG_CREATENEW']			= 'New user created on `%s` using `%s`';
		$lang['USERMGR_LOG_APIUSERCREATEYES']	= 'User `%s` successfully created on `%s`';
		$lang['USERMGR_LOG_APIUSERCREATENO']	= 'API User Create on `%s` reports: `%s`';
		
		
/**
 * **********************************************************************
 * CREATE NEW USER
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['usermgr.create']			= "Create User";
		$lang['usermgr.create.desc']	= "Create a new user on a specific connection only.";
		
		$lang['btn.selcnxn']			= "Select Connection";
		$lang['btn.createuser']			= "Validate and Create New User";
		
		$lang['msg.success.usercreated']	= "User successfully created";
		
/**
 * **********************************************************************
 * FIND USER
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['usermgr.find']		= "Find A User";
		$lang['usermgr.find.desc']	= "Find a user across all your connections.";
		
		$lang['label.user']			= "Email or Username";
		$lang['desc.user']			= "Enter either the username or the email address of the user you are searching for.";
		
		$lang['btn.finduser']		= "Find User";
		
		$lang['usermgr.linkuser']		= "Find user by `%s`";
		$lang['usermgr.linkemail']		= "Find user by `%s`";
		$lang['usermgr.createnew']		= "Create a new user";
		$lang['usermgr.modifyuser']		= "Modify this user";
		$lang['usermgr.deleteuser']		= "Delete this user";
		$lang['usermgr.viewlog']		= "View User Log";
		
		
/**
 * **********************************************************************
 * LOG DISPLAY
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['usermgr.log']		= "User Log";
		$lang['usermgr.log.desc']	= "A log of user activity across your applications.";
		
		$lang['btn.first']			= "|<< First";
		$lang['btn.previous']		= "<< Previous";
		$lang['btn.next']			= "Next >>";
		$lang['btn.end']			= "Last >>|";
		
		$lang['hdr.task']			= "Task";
		$lang['hdr.user']			= "User";
		$lang['hdr.ipaddress']		= "IP Address";
		$lang['hdr.date']			= "Date";
		
		
/**
 * **********************************************************************
 * MODIFY USER
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['usermgr.modify']				= "Modify A User";
		$lang['usermgr.modify.desc']		= "Select the connection and find the user to modify information for.  This allows you to make direct changes to a user's account on any connection.";
		
		$lang['label.modifyuser']			= "Email or Username";
		$lang['desc.modifyuser']			= "Type in either the current username or the current email address for the user you are searching for.  If the connection you selected does not support usernames, be sure to enter a valid email address.";
		
		$lang['msg.success.userupdated']	= "User successfully updated!";
		$lang['msg.error.userupdate']		= "An error occurred: %s";
		
		$lang['btn.updateuser']				= "Update User Information";
		
		
/**
 * **********************************************************************
 * REMOVE USER
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['usermgr.removeconfirm']	= "Confirm User Removal / Deactivation";
		$lang['usermgr.removeconfirm.desc']	= "Confirm that you want this user removed or inactivated on this connection.";
		
		$lang['label.confirm']		= "Are you sure?";
		$lang['desc.confirm']		= "If you confirm that you want this user removed from this connection, the user account will be either removed completely or inactivated or closed.  This may be irreversible, are you sure?";
		
		$lang['btn.removeuser']		= "Confirm Removal";
		
		