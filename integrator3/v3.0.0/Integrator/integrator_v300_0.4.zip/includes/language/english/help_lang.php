<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.4 ( $Id: globals_lang.php 373 2012-01-26 18:44:16Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the language translations for the help controler of the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * GLOBAL VARIABLES - Used across most / all controllers
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------


/**
* **********************************************************************
* HELP - STEP BY STEP
* **********************************************************************
*/
		//     v3.0.0
		// ---------------
		$lang['help.stepbystep']		= "Step By Step Setup Guide";
		$lang['help.stepbystep.desc']	= "Follow these steps to begin the setup of your Integrator 3 application.";
		
		$lang['help.sbs.1.title']		= 'Configure Global Settings';
		$lang['help.sbs.1.msg.1']		= 'The very first step is to go to the %s to configure the base line settings for the application.';
		$lang['help.sbs.1.msg.2']		= 'Once you are there, you can easily change the following settings:<ul><li><strong>Site Name</strong> - this should be set to the reference name you will use when emails are sent or client level actions take place from Integrator 3.  Some ideas include `accounts`, `integrator` or `manage`.</li><li><strong>System URL</strong> - be sure this matches the URL for the URL to reach Integrator 3 on your server (it probably does).</li><li><strong>Temp Directory</strong> - this is important! Be sure the path indicated here is readable and writable by Integrator 3. Session cookies will be stored here, so you may want to bury this below your public_html folder so it cannot be accessed from the outside inadvertantly. There is an .htaccess file inside the folder to help prevent unwanted access, but if your server doesn\'t recognize the file, you may be exposing session cookies without knowing it!</li></ul>';
		$lang['help.sbs.1.msg.3']		= 'The rest of the settings in the Global Settings are self explanatory and are optional at this point.';
		
		$lang['help.sbs.1.anchor.a']	= 'Global Settings';
		
		$lang['help.sbs.2.title']		= 'Add an API User to Integrator 3';
		$lang['help.sbs.2.msg.1']		= 'Now that you have configured your global settings, go to the %s to add a new API administrator.';
		$lang['help.sbs.2.msg.2']		= '<ul><li>Click `Create A New User`</li><li>Complete the form for the new api user. Be sure to write down the username and password you use for future reference.</li><li>Select the API Users group - only this group has access to the Integrator 3 API interface.</li><li>Click Create New User</li></ul>';
		$lang['help.sbs.2.msg.3']		= 'You have successfully created a new API User! This user will be used on your various connections to communicate with Integrator 3 to create new accounts and route the user through the site.';
		$lang['help.sbs.2.msg.4']		= 'Now retrieve the API Secret Key that is in your %s area. You will need this key to configure the additional connections in the next steps.';
		
		$lang['help.sbs.2.anchor.a']	= 'Admin Management';
		$lang['help.sbs.2.anchor.b']	= 'API Settings';
		
		$lang['help.sbs.3.title']		= 'Create Your First Connection';
		$lang['help.sbs.3.msg.1']		= 'With your API setup for Integrator 3, you are now ready to create your first connection. To do this you will need to install the extension in the framework you want to create a connection for. Available extensions are included in the main archive download for Integrator 3. To install, follow the instructions for the appropriate framework on our website. For example, the Joomla framework requires the installation of the component, a couple of plugins as well as a login module (optional), while the WHMCS framework you simply FTP the files into place and enable the extension in the backend. Follow the instructions for the connection type on our website.';
		$lang['help.sbs.3.msg.2']		= 'Regardless of the connection type you are setting up, you should have setup an API username and password for the connection. If you haven\'t, you will need to and you will also need that information for this step.';
		$lang['help.sbs.3.msg.3']		= 'With the external framework setup (Joomla, WHMCS, Fusion etc), click on %s to setup a new connection in Integrator 3. Select the type of connection (Joomla, WHMCS, Fusion, etc) and click Add New Connection and Continue.';
		$lang['help.sbs.3.msg.4']		= 'Regardless of the type of connection, you will want to setup the following:<ul><li>Connection Name - make it easy to find (for internal use only)</li><li>Connection URL - this should be the actual URL to the front end of your connection (not the administrator backend or an api interface)</li><li>API Url - initially set this to the same as your Connection URL (it gets changed automatically)</li><li>API Credentials - you may need to provide a secret key / api key or an API username and password, either way, provide them in the API Settings tab.</li></ul>';
		$lang['help.sbs.3.msg.5']		= 'The rest of the settings are straight forward; any settings requesting URLs just set to the connection URL for the time being, you can update them later.  Click Save Changes, and the Integrator 3 application will test your connection and verify your settings. If it runs into any problems, it will disable the connection and alert you. Return to the settings to correct any problems until the connection checks out.';
		
		$lang['help.sbs.3.anchor.a']	= 'Add New Connection';
		
		$lang['help.sbs.4.title']		= 'Create Your Second Connection';
		$lang['help.sbs.4.msg.1']		= 'To configure your second connection, follow the same steps you did to create your first connection above.';
		
		$lang['help.sbs.5.title']		= 'Map Your Pages';
		$lang['help.sbs.5.msg.1']		= 'Page mapping is the process of telling Integrator 3 which page from one connection should be called to wrap around another application. For instance, in WHMCS there is a page called the Client Area. If you have a Joomla connection tied to Integrator 3, you can create a cnxn page in Joomla (follow the instructions in our documentation on doing that) and indicate in Integrator 3 that when a client visits the Client Area page, Integrator 3 should retrieve the specific page from Joomla. This permits you to assign custom content per page, thereby customizing your users\' experience.';
		$lang['help.sbs.5.msg.2']		= 'This step is very important, as you must at the very least define a default page to retrieve. Failure to configure this step will result in errors and a non-functional wrapped site.';
		$lang['help.sbs.5.msg.3']		= 'Start by clicking on %s. You will see a page that has in the tabbed section the applications connected to your Integrator 3 (such as WHMCS and Fusion) and inside those tabs the sites that are connected to Integrator 3 (such as Joomla or Wordpress). The first line is the default line for the given application type, and must be set to something. Select a page from each of the drop downs for the default page map. The rest of the drop downs are optional, and if left unset will revert to the default drop down you select at the top.';
		
		$lang['help.sbs.5.anchor.a']	= 'Page Maps';
		
		$lang['help.sbs.6.msg.1']		= 'Language mapping is essentially the same process as page mapping, except it applies to telling Integrator 3 which languages map to each other from your various connections.';
		$lang['help.sbs.6.msg.2']		= 'This step is very important, as you must at the very least define a default language to retrieve. Failure to configure this step will result in errors and a non-functional wrapped site.';
		$lang['help.sbs.6.msg.3']		= 'Start by clicking on %s. You will see a page that has in the tabbed section the applications connected to your Integrator 3 (such as WHMCS and Fusion) and inside those tabs the sites that are connected to Integrator 3 (such as Joomla or Wordpress). The first line is the default line for the given application type, and must be set to something. Select a default language to use at the top of each column, and if you are using multiple languages on your site, select those as well.';
		
		$lang['help.sbs.6.title']		= 'Map Your Languages';
		
		$lang['help.sbs.6.anchor.a']	= 'Language Maps';
		
		$lang['help.sbs.7.title']		= 'Test Your Application';
		
		$lang['help.sbs.7.msg.1']		= 'With the first two connections set, go ahead and test and configure the application. If you have any questions, please consult our %s and %s for further assistance.';
		
		$lang['help.sbs.7.anchor.a']	= 'Documentation';
		$lang['help.sbs.7.anchor.b']	= 'Product Support Forums';