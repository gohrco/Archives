<?php
/*
|--------------------------------------------------------------------------
| Language Translations for the Connections Edit page
|--------------------------------------------------------------------------
| version 3.0.0
|--------------------------------------------------------------------------
*/

$lang['joomla15_users.storename']				= "Account Name Creation";
$lang['joomla15_users.storename.desc']			= "When a new user is created on this connection from another connection, this setting controls this connection assembles the `name` field if there isn't a specific field called `name` from the originating connection.";
$lang['joomla15_users.storename_options']		= array( 'firstlast' => "First Last", 'firstlastco' => "First Last (Company)", 'lastfirst' => "Last, First", 'lastfirstco' => "Last, First (Company)" );

$lang['joomla15_users.storeusername']			= "Username Creation";
$lang['joomla15_users.storeusername.desc']		= "When a new user is created on another connection that doesn't utilize a `username` field, this setting will control how a new username is generated for the user on this connection.";
$lang['joomla15_users.storeusername_options']	= array( 'first.last' => "first.last style", 'last.first' => "last.first style", 'random' => "Random username generation", 'flastname' => "flastname style", 'firstnamel' => "firstnamel style", 'firstname' => "Firstname Only", 'lastname' => "Lastname Only" );

/*
|--------------------------------------------------------------------------
| Language Translations for User Management / Modify
|--------------------------------------------------------------------------
| version 3.0.0
|--------------------------------------------------------------------------
*/

$lang['joomla15_userinfo.email.desc']	= 'The email address is required by Joomla and is the single identifier across all connections.  Changing this may prevent the user from logging in across all your applications.';
$lang['joomla15_userinfo.username.desc']	= 'The username field is required by Joomla and can be modified here directly.';

