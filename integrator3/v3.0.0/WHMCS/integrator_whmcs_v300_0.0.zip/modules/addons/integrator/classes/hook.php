<?php
/**
 * Integrator
 * WHMCS - Hook File
 * 
 * @package    Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.0.0.0 ( $Id: hook.php 396 2012-02-24 21:08:15Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file handles hook calls from the WHMCS hook system
 * 
 */

/*-- Security Protocols --*/
defined( 'WHMCS' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Hook Class
 * @version		3.0.0.0.0
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntHook extends IntObject
{
	/**
	 * Holds the API variables
	 * @access		private
	 * @version		3.0.0.0.0
	 * @var 		array
	 */
	private $api			= array();
	
	/**
	 * Holds a reference to the curl object
	 * @access		private
	 * @version		3.0.0.0.0
	 * @var			object
	 */
	private $curl			= null;
	
	/**
	 * Indicates if we should output debug info
	 * @access		private
	 * @version		3.0.0.0.0
	 * @var			boolean
	 */
	private $debug			= false;
	
	/**
	 * Provides a means to shut down login if adding client at order
	 * @access		private
	 * @version		3.0.0.0.0
	 * @var			boolean
	 */
	private $enable_login	= true;
	
	/**
	 * `output_*` ensures we don't loop through output filter
	 * @access		public
	 * @version		3.0.0.0.0
	 * @var			boolean
	 */
	public	$output_footer	= false;
	public	$output_header	= false;
	public	$output_login	= false;
	
	/**
	 * Holds the user variables
	 * @access		private
	 * @version		3.0.0.0.0
	 * @var 		array
	 */
	private $user			= array();
	
	/**
	 * Holds the visual variables
	 * @access		private
	 * @version		3.0.0.0.0
	 * @var 		array
	 */
	private $visual			= array();
	
	/**
	 * Constructor
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		$debug		= & IntFactory::getDebug();
		$this->curl	=   IntFactory::getCurl();
		$this->_check_activation();
		
		$this->_load_apisettings();
		$this->_load_usersettings();
		
		$this->die = false;
		
		$config			= IntFactory::getConfig();
		$this->cnxnid	= $config->cnxnid;
		$this->debug	= $config->Debug;
		
		// We must be sure not to recursively do things so check for $IntAPI variable
		if ( isset( $GLOBALS['IntAPI'] ) ) {
			define( "INTEGRATORAPI", true );
			$debug->info( "Hook called by API" );
		}
		
	}
	
	
	/**
	 * Destructor method
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	public function __destruct()
	{
		if ( $this->die ) {
			echo "<pre>"
				.print_r($this,1)
				.print_r($GLOBALS,1);
			die( "DEAD" );
		}
	}
	
	
	/**
	 * Adds the hooks used by the Integrator to the WHMCS framework
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @static
	 * @since		3.0.0
	 */
	public static function addHooks()
	{
		$config = & IntFactory :: getConfig();
		
		// If we are disabling globally then don't bother hooking
		if ( $config->get( 'Enabled', 'Yes' ) == 'No' ) return;
		
		$hooks = array(
			'ClientAreaPage'		=>	'integrator_clientarea',
			'ClientAdd'				=>	'integrator_clientadd',
			'ClientEdit'			=>	'integrator_clientedit',
			'ClientLogin'			=>	'integrator_login',
			'ClientLogout'			=>	'integrator_logout',
			'ClientChangePassword'	=>	'integrator_changepw',
			'ContactAdd'			=>	'integrator_contactadd',
			'ContactEdit'			=>	'integrator_contactedit',
			'AdminHomepage'			=>	'integrator_adminhomepage'
		);
		
		// Add the hooks to the WHMCS framework
		foreach ( $hooks as $point => $fnxn ) {
			add_hook( $point, 20, $fnxn );
		}
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE CALLED DIRECTLY BY HOOK POINT
	 * **********************************************************************
	 */
	
	
	/**
	 * Handles changing password calls
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $vars: contains variables passed by WHMCS hook point
	 * 
	 * @since		3.0.0
	 */
	public function changepw( $vars )
	{
		if ( $this->user['enabled'] == false ) return false;
		
		if (! isset( $vars['userid'] ) ) return;
		if ( $this->is_admin() ) return; // We've already updated the password elsewhere
		
		$user	= $this->_get_user_from_db( $vars['userid'] );
		$post	= array( 'email' => $user['email'], 'update' => array( 'password' => $vars['password'] ) );
		
		$url		= $this->api['uri']->toString() . 'user_update';
		$response	= $this->_call_api( $url, $post );
		
		return;
	}
	
	
	/**
	 * Called when a client is added to WHMCS
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $vars: the variables passed by the hook point
	 * 
	 * @since		3.0.0
	 */
	public function clientadd( $vars )
	{
		if ( $this->user['enabled'] == false ) return false;
		
		$debug		= & IntFactory::getDebug( "Client Add" );
		$user		=   $this->_build_user_array( $vars, array(), true );
		
		$url		= $this->api['uri']->toString() . 'user_create';
		$response	= $this->_call_api( $url, $user );
		
		if ( ( $response['result'] != 'success' ) && ( isset( $response['data'] ) ) ) {
			$debug->data( $response['data'] );
		}
		
		// Must set global username to email for login redirection
		$GLOBALS['username'] = $GLOBALS['email'];
		
		// See if we are creating the account at checkout
		if ( $GLOBALS['filename'] == 'cart.php' ) {
			$this->enable_login = false;
		}
	}
	
	
	/**
	 * Handles all the clientarea actions to perform
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $vars: contains variables passed by WHMCS hook point
	 * 
	 * @since		3.0.0
	 */
	public function clientarea( $vars )
	{
		global $smarty;
		
		$this->_load_visualsettings();
		$this->_set_languagetranslation();
		$this->_set_formaction();
		$this->_set_filename();
		
		$url		= $this->visual['uri']->toString();
		$response	= $this->_call_visual( $url );
		
		$this->_process_response( $response );
		
		// Register an output filter to replace templates
		$smarty->register_outputfilter( array( &$this, 'output_filter' ) );
	}
	
	
	/**
	 * Handles the editing of client details from front / back ends
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $vars: contains variables passed by WHMCS hook point
	 * 
	 * @since		3.0.0
	 */
	public function clientedit( $vars )
	{
		if ( $this->user['enabled'] == false ) return false;
		
		$debug		= & IntFactory::getDebug( "Client Add" );
		$olduser	=   $this->_get_user_information( 'validation', 'client' );
		
		// Catch false returns
		if ( ( $user = $this->_build_user_array( $vars, $vars['olddata'], false, 'to' ) ) === false ) return;
		
		$url		= $this->api['uri']->toString() . 'user_update';
		$response	= $this->_call_api( $url, $user );
		
		if ( ( $response['result'] != 'success' ) && ( isset( $response['data'] ) ) ) {
			$debug->data( $response['data'] );
		}
	}
	
	
	/**
	 * Handles client validation checks
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $vars: contains variables passed by WHMCS hook point
	 * 
	 * @since		3.0.0
	 */
	public function clientvalidation( $vars )
	{
		if ( $this->user['enabled'] == false ) return false;
		
		$debug		= & IntFactory::getDebug( array( 'script' => "Client Validation" ) );
		$debug->persist();	// Need to keep old messages for redirect
		
		// For frontend:  Validation occurs at registration and editing
		// For backend:   Validation only occurs at editing
		// We know only client information get validated for some reason
		$type		= 'client';
		$olduser	= $this->_get_user_information( 'validation', $type );
		$isnew		= ( $olduser === false ? true : false );
		$changes	= $this->_build_user_array( $vars, $olduser, $isnew, 'to' );
		
// 		echo "<h4>clientedit</h4><pre>".print_r($vars,1).print_r($olduser,1).print_r($changes,1)."</pre>";
		// No changes made that we care about so send back
		if (! $changes['update'] ) {
			$debug->info( "No changes made to information for connection validation" );
			return;
		}
		
		$url		= $this->api['uri']->toString() . 'user_validation_on_' . ( $isnew ? 'create' : 'update' );
		$response	= $this->_call_api( $url, $changes );
		
		// All is well
		if ( $response['result'] == 'success' ) {
			$debug->info( "Connection validation successful" );
			return;
		}
		else 
		{	// Not so good revert data
			global $errormessage;
			$errormessage .= $response['data'];
			$debug->data( "{$response['data']}" );
			
			if (! $isnew ) {
				foreach ( $changes as $k => $v ) {
					$_POST[$k] = $olduser[$k];
					$_REQUEST[$k] = $olduser[$k];
					$GLOBALS[$k] = $olduser[$k];
					if (! empty( $olduser[$k] ) ) $debug->data( "{$k} reverted to {$olduser[$k]}" );
				}
			}
			return;
		}
	}
	
	
	/**
	 * Handles client login events - must pass 'integrator' variable as true to return to integrator
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $vars: contains variables passed by WHMCS hook point
	 * 
	 * @since		3.0.0
	 */
	public function login( $vars )
	{
		global $action;
		
		// If we aren't enabled at all do nothing
		if ( $this->user['enabled'] == false ) return false;
		
		// If we are coming through the API - do nothing
		if ( $action != null ) return false;
		//if ( $action == "validatelogin" ) return false;
		
		$session	= $this->_session_encode( $vars['userid'], session_id() );
		
		// Create fields
		$fields	= array( '_c' => $this->cnxnid, 'session' => $session );
		
		// Check to see if we are coming from the admin!
		$admincp = $GLOBALS['customadminpath'];
		$referer = ( isset( $_ENV['HTTP_REFERER'] ) ? $_ENV['HTTP_REFERER'] : ( isset( $_SERVER['HTTP_REFERER'] ) ? $_SERVER['HTTP_REFERER'] : null ) );
		$request = ( isset( $_ENV['REQUEST_URI'] ) ? $_ENV['REQUEST_URI'] : ( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : null ) );
		if ( strpos( $referer, $admincp ) !== false && strpos( $request, 'dologin' ) !== false ) {
			return false;
		}
		
		// Check to see if we are ordering
		if (! $this->enable_login ) return false;
		
		// If we are coming from the Integrator...
		if (  $_REQUEST['integrator'] == "1" )
		{
			$uri = $this->user['uri']->toString() . 'login/succeed';
			$this->_form_redirect( $uri, $fields );
		}
		else {
			if ( isset( $GLOBALS['_SESSION']['loginurlredirect'] ) ) {
				$returi	= new IntUri( $GLOBALS['CONFIG']['Domain'] );
				$returi->setPath( rtrim( $returi->getPath(), "/" ) . $GLOBALS['_SESSION']['loginurlredirect'] );
				$return	= base64_encode( $returi->toString() );
			} else {
				$returi = new IntUri( ( isset( $GLOBALS['CONFIG']['SystemSSLURL'] ) ? $GLOBALS['CONFIG']['SystemSSLURL'] : $GLOBALS['CONFIG']['SystemURL'] ) );
				$returi->setPath( rtrim( $returi->getPath(), "/" ) . "/clientarea.php" );
				$return = base64_encode( $returi->toString() );
			}
			
			$uri = $this->user['uri']->toString()."login/index/{$this->cnxnid}/{$sid}/{$sname}";
			
			global $username, $password, $rememberme;
			
			$fields['username'] = $username;
			$fields['password'] = $password;
			$fields['return']	= $return;
			
			if ( $rememberme == "on" ) $fields['rememberme'] = 'on';
			
			$this->_form_redirect( $uri, $fields );
		}
		exit;
	}
	
	
	/**
	 * Handles client logout events by making changes to object and redirecting in header.tpl file
	 * 		Important to note that the actual log out takes place after the hook point is called by WHMCS
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		array		- $vars: contains variables passed by WHMCS logout hook
	 * 
	 * @since		3.0.0
	 */
	public function logout( $vars )
	{
		if ( $this->user['enabled'] == false ) return false;
		
		$this->redirect	= $this->user['enabled'];
		$sid		= base64_encode( session_id() );
		
		if ( $_REQUEST['integrator'] == 'true' ) {
			$this->user['uri']->setScheme( 'http' . ( $_SERVER['HTTPS'] ? 's' : '' ) );
			$uri = $this->user['uri']->toString() . "logout/complete/{$this->cnxnid}/";
		}
		else if ( $_REQUEST['integrator'] == 'false' ) {
			$this->redirect = false;
			$uri = null;
		}
		else {
			$this->user['uri']->setScheme( 'http' . ( $_SERVER['HTTPS'] ? 's' : '' ) );
			$uri = $this->user['uri']->toString() . "logout/index/{$this->cnxnid}/{$sid}?_c={$this->cnxnid}";
		}
		
		$this->location	= $uri;
		return;
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE API RELATED
	 * **********************************************************************
	 */
	
	/**
	 * Pings the Integrator API to see if it is alive
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @return		boolean true on connection
	 * @since		3.0.0
	 */
	public function ping()
	{
		$debug		= & IntFactory::getDebug( array( 'script' => "Ping[hook]" ) );
		$url		= $this->api['uri']->toString() . "ping/";
		$response	= $this->_call_api( $url );
		
		if ( $response['result'] == 'success' ) {
			return true;
		}
		
		$debug->data( $response['data'] );
		return $response['data'];
	}
	
	
	/**
	 * Sends an update settings call to pull the cnxnid from Integrator
	 * @access		public
	 * @version		3.0.0.0.0
	 * 
	 * @return		true upon successful completion or an error message
	 * @since		3.0.0
	 */
	public function update_settings()
	{
		$debug		= & IntFactory::getDebug( array( 'script' => "Update Settings[hook]" ) );
		$config		= IntFactory::getConfig();
		$post		= array();
		
		if (! empty( $config->cnxnid ) ) {
			$post['cnxnid']	= $config->cnxnid;
		}
		
		$post['cnxnurl']	= $GLOBALS['CONFIG']['SystemURL'];
		
		$url		= $this->api['uri']->toString() . "update_settings/";
		$response	= $this->_call_api( $url, $post );
		
		if ( $response['result'] != 'success' ) {
			$debug->data( $response['data'] );
			return $response['data'];
		}
		
		$data	= $response['data'];
		$config->bind( $data );
		$config->save();
		return true;
	}
	
	
	/**
	 * Wrapper for calling up the API interface
	 * @access		private
	 * @version		3.0.0.0.0
	 * @param		string		- $url: the url to connect to
	 * @param		array		- $post: any additional post variables to send
	 * @param 		array		- $options: any options to set
	 * 
	 * @return		json_decoded response
	 * @since		3.0.0
	 */
	private function _call_api( $url, $post = array(), $options = array() )
	{
		$post		= array_merge( $this->api['post'], $post );
		$options	= array_merge( $this->api['options'], $options );
		
		if ( (! isset( $post['cnxnid'] ) ) && (! isset( $post['_c'] ) ) ) {
			$config		= IntFactory::getConfig();
			$post['_c'] = $config->cnxnid;
		}
		
		$result		= $this->curl->simple_post( $url, $post, $options );
// 		echo "<pre>".print_r($post,1)."</pre>";
		if ( $result === false ) {
			// error trapping for debug purposes
			return array( 'result' => 'error', 'data' => $this->curl->has_errors() );
		}
		
		if ( $options['HEADER'] == TRUE ) {
			list( $header, $response ) = explode( "\r\n\r\n", $result, 2 );
		}
		else {
			$response = $result;
		}
		
		$return	= json_decode( $response, true );
		
		if (! isset( $return['result'] ) ) {
			return $response;
		}
		else {
			if ( isset( $return['debug'] ) ) {
				$debug = & IntFactory :: getDebug();
				$debug->add_array( $return['debug'] );
			}
			
			return $return;
		}
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE VISUAL RENDERING RELATED
	 * **********************************************************************
	 */
	
	
	/**
	 * Filters the template output from the smarty object
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		string		- $tpl_output: contains the output from the rendered smarty tpl file
	 * @param		Smarty object
	 * 
	 * @return		string containing filtered output
	 * @since		3.0.0
	 */
	public function output_filter( $tpl_output, &$smarty )
	{
		if (! $this->visual['enabled'] ) return $tpl_output;
		
		if ( preg_match( '#<html[^>]*>#im', $tpl_output ) ) {
			if ( $this->output_header ) return $tpl_output;
			else $this->output_header = true;
			//echo INT_TEMP; die();
			$tpl_output = $smarty->fetch( 'file:' . TEMPLATE_PATH . 'header.tpl' );
		}
		
		if ( preg_match( '#</html[^>]*>#im', $tpl_output ) ) {
			if ( $this->output_footer ) return $tpl_output;
			else $this->output_footer = true;
			$tpl_output = $smarty->fetch( 'file:' . TEMPLATE_PATH . 'footer.tpl' );
		}
		
		if ( preg_match( '#<form[^>]+dologin\.php[^>]*>#im', $tpl_output ) ) {
			if ( $this->output_login ) return $tpl_output;
			else $this->output_login = true;
			$tpl_output = $smarty->fetch( 'file:' . TEMPLATE_PATH . 'login.tpl' );
		}
		
		$tpl_output = preg_replace( '#(<link[^>]+href=")([^>]+/orderforms/)#im', '$1' . TEMPLATE_OURL, $tpl_output );
		
		if ( WHMCS_VERS == '4' ) {
			$tpl_output = preg_replace( '#(<script[^>]+src=")([^>]+/orderforms/ajaxcart/js/main\.js)#im', '$1' . TEMPLATE_OURL . '/ajaxcart/js/main.js', $tpl_output );
		}
		
		return $tpl_output;
	}
	
	
	/**
	 * Retrieves the actual site to use around WHMCS
	 * @access		private
	 * @version		3.0.0.0.0
	 * @param		string		- $url: the url to go to
	 * @param		array		- $post: any post variables to send
	 * @param		array		- $options: any additional or modified CURLOPT to set
	 * 
	 * @return		SimpleXMLElement object
	 * @since		3.0.0
	 */
	private function _call_visual( $url, $post = array(), $options = array() )
	{
		if (! $this->visual['enabled'] ) return $tpl_output;
		
		$post		= array_merge( $this->visual['post'], $post );
		$options	= array_merge( $this->visual['options'], $options );
		
		$result		= $this->curl->simple_post( $url, $post, $options );
		
		if ( $result === false ) {
			if ( $GLOBALS['debug'] == true ) { echo var_dump( $url ); var_dump( $post ); echo base64_decode( $post['session_id'] ); $this->curl->has_errors(); die(); }
			// error trapping for debug purposes
			return array( 'result' => 'error', 'data' => $this->curl->has_errors() );
		}
		
		if ( $options['HEADER'] == TRUE ) {
			list( $header, $response ) = explode( "\r\n\r\n", $result, 2 );
		}
		else {
			$response = $result;
		}
		
		// Convert response to XML object
		try {
			$xml = new SimpleXMLElement( $response );
		}
		catch ( Exception $e ) {
			if ( ( $this->debug ) || ( $GLOBALS['debug'] == true ) ) {
				echo "<h2>Problem Parsing XML Response from the Integrator</h2>";
				echo "=============================================<br/>\n";
				echo $url . "<br/>\n<pre>";
				echo $e->getLine();
				echo print_r( $e->getTrace(), 1);
				echo "=============================================<br/>\n";
				echo "<h3>Info</h3><pre>";
				echo print_r( $this->curl->info, 1 );
				echo "</pre>=============================================<br/>\n";
				echo "<h3>Posted Variables and Options</h3><pre>";
				echo print_r( $post, 1 );
				echo print_r( $options, 1 );
				echo "</pre>=============================================<br/>\n";
				echo "<h3>Header</h3><pre>";
				echo $header;
				echo "</pre>=============================================<br/>\n";
				echo "<h3>Response</h3><pre>";
				echo print_r( $response, 1 );
				echo "</pre>";
			}
			$xml = false;
		}
		
		return $xml;
	}
	
	
	/**
	 * Handles the debug information to render back to client on WHMCS side
	 * @access		private
	 * @version		3.0.0.0.0
	 * @param		array		- $debugs: the debug information to add
	 * 
	 * @return		string containing debug html
	 * @since		3.0.0
	 */
	private function _process_debug( $debugs )
	{
		$debug	= & IntFactory :: getDebug();
		$data	=   null;
		
		foreach ( $debugs->children() as $msg ) {
			$debug->add( (string) $msg->message, (string) $msg->filename, (string) $msg->line, (string) $msg->type, false );
		}
		
		$lines	= $debug->get_output();
		$close	= null;
		
		if (! empty( $lines ) ) {
			$data	= '<div style="width: 100%; clear: both; position: relative; color: #000; ">'
					. '<fieldset style="padding: 5px 17px 17px; background-color: #fff; border: 1px solid #CCCCCC; ">'
					. '<legend style="color: #146295; font-size: 1.15em; font-weight: bold; margin: 0; padding: 0; ">'
					. 'Integrator Debug Information'
					. '</legend>'
					. '<ul class="list-style: none outside none; margin: 0; padding: 0; ">';
			$close	= '</ul></fieldset></div>';
		}
		
		foreach ( $lines as $line ) {
			$data  .= '<li style="list-style: none outside none; border-bottom: 1px solid #666666; padding: 5px; ">'
					. '<div style="float: left; font-weight: bold; text-align: left; ' . ( $line['type'] == 'error' ? 'color: DarkRed; ' : '' ) . '">[' . $line['type'] . '] ' . $line['message'] . '</div>'
					. '<div style="float: right; font-size: smaller; ' . ( $line['type'] == 'error' ? 'color: DarkRed; ' : '' ) . '">' . $line['filename'] . '  @ line ' . $line['line'] . '</div>'
					. '<div style="clear: both; line-height: 1px; ">&nbsp;</div>'
					. '</li>';
		}
		
		return $data . $close;
		
		
	}
	
	
	/**
	 * Processes the response sent back by the Integrator for final modifications
	 * @access		private
	 * @version		3.0.0.0.0
	 * @param		SimpleXML object	- $site: the XML response from the Integrator
	 * 
	 * @since		3.0.0
	 */
	private function _process_response( $site )
	{
		if (! $this->visual['enabled'] ) return $tpl_output;
		
		$header	= base64_decode( $site->header );
		$footer = base64_decode( $site->footer );
		$debug	= ( isset( $site->debugs ) ? $this->_process_debug( $site->debugs ) : null );
		
		global $smarty;
		
		// Handle title first
		$title	= $smarty->_tpl_vars['companyname'] . " - " . $smarty->_tpl_vars['pagetitle'] . ( isset( $smarty->_tpl_vars['kbarticle']['title'] ) ? $smarty->_tpl_vars['kbarticle']['title'] : "" );
		$regex	= '`(?P<front><title>)(?P<link>INTEGRATOR_TITLE)(?P<back><\/title>)`';
		$header	= preg_replace( $regex, "\${1}$title\${3}", $header );
		
		// Handle base href
		$base	= ( isset( $smarty->_tpl_vars['systemurl'] ) ? $smarty->_tpl_vars['systemurl'] : false );
		$regex	= ( $base == false ? '`(?P<front>)(?P<link><base[^>]*>)(?P<back>)`' : '`(?P<front><base[^>]*)(?P<link>INTEGRATOR_BASETAG)(?P<back>[^>]*>)`' );
		$header	= preg_replace( $regex, "\${1}$base\${3}", $header );
		
		$smarty->assign( 'htmlheader',	$header );
		$smarty->assign( 'htmlfooter',	$footer );
		$smarty->assign( 'htmldebug',	$debug );
	}
	
	
	/**
	 * Sets the filename for sending to the Integrator for page determination
	 * @access		private
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	private function _set_filename()
	{
		if (! $this->visual['enabled'] ) return $tpl_output;
		
		global $smarty;
		
		if ( isset( $_REQUEST['action'] ) )
			$this->visual['post']['filename'] = $smarty->_tpl_vars['filename'] . '-x-' . $_REQUEST['action'];
		
		elseif ( isset( $_REQUEST['a'] ) )
			$this->visual['post']['filename'] = $smarty->_tpl_vars['filename'] . '-a-' . $_REQUEST['a'];
		
		else
			$this->visual['post']['filename'] = $smarty->_tpl_vars['filename'];
		
	}
	
	
	/**
	 * Sets the form action for logging in purposes
	 * @access		private
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	private function _set_formaction()
	{
		if (! $this->visual['enabled'] ) return $tpl_output;
		
		global $smarty;
		
		if ( ( isset ( $_REQUEST['incorrect'] ) ) && ( isset ( $_REQUEST['msg'] ) ) )
		{
			//$debug = ( $smarty->_tpl_vars['JWHMCS']['Debug'] ? " ({$_REQUEST['msg']})" : "" );
			$smarty->_tpl_vars['LANG']['loginincorrect'] = $smarty->_tpl_vars['LANG'][$_REQUEST['msg']];
		}
		
		$smarty->_tpl_vars['Integrator'] = array(	"userenable"	=> $this->user['enabled'],
													"formaction"	=> $this->user['formaction'],
													"cnxnid"		=> $this->cnxnid
		);
	}
	
	
	/**
	 * Sets the language for sending to the Integrator for language translation purposes
	 * @access		private
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	private function _set_languagetranslation()
	{
		if (! $this->visual['enabled'] ) return $tpl_output;
		
		global $smarty;
		$default	= 'English';
		$language	= $smarty->_tpl_vars['language'];
		$path		= dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'lang' . DIRECTORY_SEPARATOR;
		$file		= ( is_readable( $path . $language . '.php' ) ? $path . $language . '.php' : ( is_readable( $path . $default . '.php' )  ? $path . $default . '.php' : false ) );
		if ( $file === false ) {
			// Add Debug issue
			return;
		}
		include_once( $file );
		foreach( $intlang as $k => $v ) $smarty->_tpl_vars['LANG'][$k] = $v;
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE PRIVATE FOR THIS OBJECT
	 * **********************************************************************
	 */
	
	
	/**
	 * Common method for creating a consistant user array to send to the Integrator
	 * @access		private
	 * @version		3.0.0.0.0
	 * @param		array		- $newuser: new user data to send to Integrator
	 * @param		array		- $olduser: if an edit, the original data
	 * @param		boolean		- $is_new: is new or not
	 * @param		string		- $direction: to => going to Integrator, from => coming from (not used yet)
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	private function _build_user_array( $newuser, $olduser, $is_new, $direction = 'to' )
	{
		$data	= array();
		$check	= array( 'email', 'firstname', 'lastname', 'active', 'subaccount' );
		
		if ( $is_new ) {
			
			$check[] = 'password';
			
			foreach ( $check as $c ) {
				if ( empty( $newuser[$c] ) || (! isset( $newuser[$c] ) ) ) continue;
				$data[$c] = $newuser[$c];
			}
			
			// If we are creating a contact we must pull the raw pw
			if ( $this->contact ) {
				$data['password'] = $GLOBALS['_POST']['password'];
			}
		}
		// Existing User
		else {
			
			// If on the front end we can pull the original contact info from the database
			if ( $this->contact && (! $this->is_admin() ) ) {
				$olduser = $this->_get_user_from_db( $newuser['contactid'], 'contact' );
			}
			// No way to update contacts without risking damage to other connections so return false
			else if ( $this->contact && $this->is_admin() ) {
				return false;
			}
			
			foreach ( $check as $c ) {
				if ( empty( $newuser[$c] ) || (! isset( $newuser[$c] ) ) ) continue;
				$data['update'][$c] = $newuser[$c];
			}
			
			// If we are updating a contact, we must grab it from the password from the post array
			if ( ( $this->contact ) && (! empty( $GLOBALS['_POST']['password'] ) ) ) {
				$data['update']['password'] = $GLOBALS['_POST']['password'];
			}
			// Catch password updates for clients on the back end
			else if ( $this->is_admin() ) {
				$newpass	= ( isset( $newuser['password'] ) ? $newuser['password'] : $GLOBALS['_POST']['password'] );
				
				if ( ( $newpass != 'Enter to Change' ) && (! empty( $newpass ) ) ) {
					$data['update']['password'] = $newpass;
				}
			}
			// Password updates for front end are handled separately
			
			$data['email']	= $olduser['email'];
		}
		
		// We must convert the data from the native characterset to utf-8 so Integrator can handle it.
		foreach ( $data as $k => $v ) {
			$data[$k] = iconv( strtoupper( $GLOBALS['CONFIG']['Charset'] ), 'UTF-8', $v );
		}
		
		return $data;
	}
	
	
	/**
	 * Checks the activation of the product from the settings
	 * @access		private
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	private function _check_activation()
	{
		$config	= & IntFactory::getConfig();
		
		if ( $config->Enabled == "No" ) {
			$this->user['enabled']		= false;
			$this->visual['enabled']	= false;
			return;
		}
		
		$this->user['enabled']		= ( $config->UserEnabled == "Yes" ? true : false );
		$this->visual['enabled']	= ( $config->VisualEnabled == "Yes" ? true : false );
		
		return;
	}
	
	
	/**
	 * Form redirection
	 * @access		private
	 * @version		3.0.0.0.0
	 * @param		string		- $url: the url to go to
	 * @param		array		- $fields: an array of fields to include
	 * 
	 * @since		3.0.0
	 */
	private function _form_redirect( $url, $fields = array() )
	{
		$fields = (array) $fields;
		$input	= null;
		
		foreach ( $fields as $name => $field ) {
			$input .= '<input type="hidden" name="' . $name . '" value="' . $field . '" />';
		}
					$output = <<< OUTPUT
<form action="{$url}" method="post" name="frmlogin" id="frmlogin">
		{$input}
</form>
<script language="javascript"><!--
setTimeout ( "autoForward()", 0 );
function autoForward() {
	document.forms['frmlogin'].submit()
}
//--></script>
OUTPUT;
			exit ( $output );
		
	}
	
	
	/**
	 * Gets the user info from the database
	 * @access		private
	 * @version		3.0.0.0.0
	 * @param		integer		$userid: the user id to pull
	 * 
	 * @return		array or false on not found
	 * @since		3.0.0
	 */
	private function _get_user_from_db( $userid, $type = 'client' )
	{
		$db		= & IntFactory::getDbo();
		$db->setQuery( 'SELECT * FROM tbl' . $type . 's WHERE `id` = ' . $userid );
		$user	=   $db->loadAssoc();
		return ( empty( $user ) ? false : $user );
	}
	
	
	/**
	 * Retrieves user info based upon the request and what type
	 * @access		private
	 * @version		3.0.0.0.0
	 * @param		string		- $request: what to do
	 * @param		string		- $type: client, contact or a request specific string
	 * 
	 * @return		array or false on empty
	 * @since		3.0.0
	 */
	private function _get_user_information( $request, $type = null )
	{
		$backend	= & $this->_is_backend();
		
		switch ( $request )
		{
			case 'passwordchange':
				$user = $this->_get_user_from_db( $type['userid'] );
				break;
				
			case 'validation':
				// Switch on contact / client
				switch ( $type )
				{
					// Contacts dont run through validation
					case 'contact':
						
						break;
						
					// Client data validation
					case 'client':	
					default:
						
						if ( $backend ) {
							// We must load the user info from the database
							global $userid;
							$user	= $this->_get_user_from_db( $userid );
						}
						else {
							$user	= $GLOBALS['existingclientsdetails'];
							if ( empty( $user ) ) $user = false;
						}
						
					break;
				}
			break; // Validation
		}	// Request
		
		return $user;
	}
	
	
	/**
	 * Wrapper for checking to see if we are in the backend
	 * @access		private
	 * @version		3.0.0.0.0
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	private function _is_backend()
	{
		return ( defined( "CLIENTAREA" ) == true ? false : true );
	}
	
	
	/**
	 * Loads the API settings
	 * @access		private
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	private function _load_apisettings()
	{
		$config			= IntFactory::getConfig();
		
		// Set the API Uri object
		$uri		= new IntUri( $config->IntegratorUrl );
		$uri->setPath( rtrim( $uri->getPath(), "/" ) . "/index.php/api/" );
		$this->api['uri']	= $uri;
		
		// Build secret code
		$salt		= mt_rand();
		$secret		= $config->IntegratorApisecret;
		$signature	= base64_encode( hash_hmac( 'sha256', $salt, $secret, true ) );
		
		// Set the default API post variables
		$post		= array	(	"apiusername"	=> $config->IntegratorUsername,
								"apipassword"	=> $config->IntegratorPassword,
								'apisignature'	=> $signature,
								'apisalt'		=> $salt
		);
		$this->api['post'] = $post;
		
		$options	= array(	'POST'				=> true,
								'TIMEOUT'			=> 30,
								'RETURNTRANSFER'	=> true,
								'POSTFIELDS'		=> array(),
								'FOLLOWLOCATION'	=> true,
								'HEADER'			=> true,
								'HTTPHEADER'		=> array( 'Expect:' ),
								'MAXREDIRS'			=> 5,
								'SSL_VERIFYHOST'	=> false,
								'SSL_VERIFYPEER'	=> false
		);
		
		$this->api['options']	= $options;
		
		return;
	}
	
	
	/**
	 * Loads user integration related settings
	 * @access		private
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	private function _load_usersettings()
	{
		$config			= IntFactory::getConfig();
		$isSsl			= ( $config->UseSSL == 'Always' ? true : ( $config->UseSSL == 'Never' ? false : $this->_using_ssl() ) );
		
		// Set the User Log in / out object
		$uri		= new IntUri( $config->IntegratorUrl );
		$uri->setScheme( "http" . ( $isSsl ? "s" : "" ) );
		$uri->setPath( rtrim( $uri->getPath(), "/" ) . "/index.php/" );
		$this->user['uri']	= $uri;
		$this->user['formaction']	= $uri->toString() . "login";
	}
	
	
	/**
	 * Loads visual integration related settings
	 * @access		private
	 * @version		3.0.0.0.0
	 * 
	 * @since		3.0.0
	 */
	private function _load_visualsettings()
	{
		global $smarty;
		
		$config			= IntFactory::getConfig();
		
		// Set the Visual Uri object
		$uri		= new IntUri( $config->IntegratorUrl );
		$uri->setPath( rtrim( $uri->getPath(), "/" ) . "/index.php/render/" );
		$this->visual['uri']	= $uri;
		
		// Build secret code
		$salt		= mt_rand();
		$secret		= $config->IntegratorApisecret;
		$signature	= base64_encode( hash_hmac( 'sha256', $salt, $secret, true ) );
		
		$post	= array(	'filename'		=> $smarty->_tpl_vars['filename'],
							'language'		=> $smarty->_tpl_vars['language'],
							'characterset'	=> $GLOBALS['CONFIG']['Charset'],
							'session_id'	=> session_id(),
							'isssl'			=> $this->_using_ssl(),
							'_a'			=> $this->cnxnid,
							'signature'		=> $signature,
							'salt'			=> $salt );
		
		if ( isset( $GLOBALS['_v'] ) ) {
			$post['_v'] = $GLOBALS['_v'];
		}
		
		$this->visual['post'] = $post;
		
		$options	= array(	'POST'				=> true,
								'TIMEOUT'			=> 30,
								'RETURNTRANSFER'	=> true,
								'POSTFIELDS'		=> array(),
								'FOLLOWLOCATION'	=> false,
								'HEADER'			=> true,
								'HTTPHEADER'		=> array( 'Expect:' ),
								'MAXREDIRS'			=> 5,
								'SSL_VERIFYHOST'	=> false,
								'SSL_VERIFYPEER'	=> false
		);
		
		$this->visual['options']	= $options;
	}
	
	
	/**
	 * Creates an encoded session hash for transmittal
	 * @access		public
	 * @version		3.0.0.0.0
	 * @param		string		- $name: the session name
	 * @param		string		- $id: the session id
	 * 
	 * @return		string containing hashed array
	 * @since		3.0.0
	 */
	private function _session_encode( $name, $id )
	{
		// Initialize items
		$params			= & IntFactory :: getConfig();
		$salt			=   mt_rand();
		$secret			=   $params->IntegratorApisecret;
		$string			=   null;
		$data			=   null;
		$encode			=   null;
		
		// Create base array
		$serial	= serialize( array( 'id' => $id, 'name' => $name ) );
		$key	= md5( $secret . $salt );
		
		for ( $i = 0; $i < strlen( $serial ); $i++ ) {
			$string .= substr( $key, ( $i % strlen( $key ) ), 1 ) . ( substr( $key, ( $i % strlen( $key ) ), 1 ) ^ substr( $serial, $i, 1 ) );
		}
		
		for ( $i = 0; $i < strlen( $string ); $i++ ) {
			$data .= substr( $string, $i, 1 ) ^ substr( $key, ( $i % strlen( $key ) ), 1 );
		}
		
		// Create array and encode
		$encode	= array( 'data' => base64_encode( $data ), 'salt' => $salt );
		$encode = serialize( $encode );
		$encode = base64_encode( $encode );
		$encode = md5( $salt . $secret ) . $encode;
		$encode = strrev( $encode );
		
		return $encode;
	}
	
	
	/**
	 * Shortcut for determining the scheme used on the current page
	 * @access		private
	 * @version		3.0.0.0.0
	 * 
	 * @return		boolean true if ssl
	 * @since		3.0.0
	 */
	private function _using_ssl()
	{
		if ( $_POST['integrator'] == 'true' ) {
			if ( isset( $GLOBALS['_SERVER']['HTTPS'] ) ) {
				if ( $GLOBALS['_SERVER']['HTTPS'] == "on" ) {
					return true;
				}
			}
		}
		
		if ( (! isset( $GLOBALS['filename'] ) ) || (! isset( $GLOBALS['files'] ) ) || (! isset( $GLOBALS['nonsslfiles'] ) ) ) return false;
		
		if ( empty( $GLOBALS['files'] ) ) {
			return ( in_array( $GLOBALS['filename'], $GLOBALS['nonsslfiles'] ) ? false : true );
		}
		else {
			return in_array($GLOBALS['filename'], $GLOBALS['files'] );
		}
	}
	
}