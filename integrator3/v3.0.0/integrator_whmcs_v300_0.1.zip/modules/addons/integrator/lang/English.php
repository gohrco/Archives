<?php

// Handles the admin translations
$intlang = array(
	'admin_outputhdr'	=> 'Health Check',
	'admin_labelcnxn'	=> 'Connection Made',
	'admin_labelsets'	=> 'Settings Updated',
	'admin_msg01'		=> 'Connection made successfully!',
	'admin_msg02'		=> 'Settings have been updated!',
	'admin_err01'		=> '.  Please check your settings and try again',
	'admin_err02'		=> 'Connection settings must be valid',
	'admin_err03'		=> 'Message received: %s',
	
	// Configuration area translations
	'cfg_name'			=> 'Integrator 3.0',
	'cfg_desc'			=> 'This module integrates your WHMCS application with other 3rd party CMS sites and applications such as Joomla.',
	
	'cfg_enablelabel'	=> 'Globally Enabled',
	'cfg_enabledesc'	=> 'This is a global override setting.  Setting this to disabled will disable all aspects of the Integrator on this application.',
	
	'cfg_debuglabel'	=> 'Debug Enabled',
	'cfg_debugdesc'		=> 'Turning debug on is useful for figuring out why the integration isn\'t working.',
	
	'cfg_userenlabel'	=> 'User Integration Enabled',
	'cfg_userendesc'	=> 'If you want your users to be able to log in throughout your whole site set this to Yes.  This setting will not affect the visual rendering portion of the application.',
	
	'cfg_visenlabel'	=> 'Visual Rendering Enabled',
	'cfg_visendesc'		=> 'If you want to visually integrate your application with your CMS, (wrap WHMCS) then set this to Yes.  This setting will not affect the user integration portion of the application.',
	
	'cfg_inturllabel'	=> 'Integrator URL',
	'cfg_inturldesc'	=> 'Please enter the URL to your installation of the Integrator application.  Only include the base path, such as `http://yourdomain.com/integrator`, do not include filenames.',
	
	'cfg_apiuserlabel'	=> 'Integrator Username',
	'cfg_apiuserdesc'	=> 'Enter the API Username for the Integrator (set in the Integrator).',
	
	'cfg_apipasslabel'	=> 'Integrator Password',
	'cfg_apipassdesc'	=> 'Enter the API Password for the Integrator (set in the Integrator)',
	
	'cfg_apisecretlabel'	=> 'API Secret Key',
	'cfg_apisecretdesc'		=> 'Enter the API Secret Key you have in your Integrator application.  This is used for security purposes between these two connections, and it is highly advisable to be unique.  <strong>Never give out the API Secret Key!</strong>.',
	
	'cfg_cnxnlabel'		=> 'Connection ID',
	'cfg_cnxndesc'		=> 'If you happen to know what the connection ID is that you set in the Integrator, you can set it here.  Otherwise, when you check your settings it will update it for you, so nothing is required to be entered here.',
	
	'cfg_usessllabel'	=> 'Use SSL',
	'cfg_usessldesc'	=> 'If you have an SSL certificate on the domain your Integrator is located, you can use SSL here.  To not use SSL, specify `Never`, to force SSL always, select `Force Always` and to defer to the current scheme, select `Ignore`.',
	
	'cfg_regmethodlabel'	=> 'Registration Method',
	'cfg_regmethoddesc'		=> 'Select the method of registration you want to use.  You can use the Integrated method found in the Integrator 3 application, or the WHMCS registration method (if enabled).',
	
);

$intlang["err01"] = "Login Details Incorrect. Please try again.";
?>