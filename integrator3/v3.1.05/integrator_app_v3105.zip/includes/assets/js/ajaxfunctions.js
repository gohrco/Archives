function ajaxvalidate( item ) {
	var myurl		= document.getElementById( 'myurl' ).value;
	var valid		= jQuery( '#validate' + item.name );
	var field		= jQuery( '#field' + item.name );
	
	valid.html( 'Checking ' + item.name ).addClass( 'checking' ).removeClass( 'success' ).removeClass( 'error' );
	field.addClass( 'checking' ).removeClass( 'success' ).removeClass( 'error' );
	
	jQuery.ajax({
		type: 'POST',
		url: myurl + '/register/verify',
		data: 'item=' + item.name + '&value=' + item.value,
	}).success( function ( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		field.removeClass( 'checking' );
		
		if ( obj.result == true ) {
			valid.html( 'Validated!' ).addClass( 'success' );
			field.addClass( 'success' );
		}
		else {
			valid.html( obj.msg ).addClass( 'error' );
			field.addClass( 'error' );
		}
		
	});
	
}


/**
 * Performs an ajax call from within a modal
 */
function modalajax( call, target ) {
	var caller		= jQuery( '#' + target + ' .modal-body' );
	var updateurl	= ajaxurl + '/' + call;
	
	jQuery.ajax({
		type: 'POST',
		url: updateurl,
	}).success( function( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		if ( obj == null ) {
			caller.html( '<p>An error occurred and the response was not readable</p>' );
		}
		else if ( obj.result == 'success' ) {
			if ( obj.data == true ) {
				caller.html( '<div class="alert alert-info">' + obj.msg + '</div>' );
				if ( obj.call != false ) {
					modalajax( obj.call, target );
				}
				else if ( obj.return != false ) {
					jQuery( location ).attr( 'href',obj.return );
				}
			}
			else {
				caller.html( '<div class="alert alert-danger"><strong>' + obj.hdr + '</strong><br/>' + obj.msg + '</div>' );
			}
		}
		else {
			caller.html( '<div class="alert alert-danger"><strong>' + obj.hdr + '</strong><br/>' + obj.msg + '</div>' );
		}
	});
	return false;
}


function updatecheck() {
	var myurl		= document.getElementById( 'updurl' ).value;
	var updtxt		= jQuery( '#version_results' );
	
	jQuery.ajax({
		type: 'POST',
		url: myurl,
	}).success( function( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		updtxt.html( obj.msg );
		if ( obj.result == 'success' ) {
			if ( obj.data == true ) {
				updtxt.removeClass( 'version_checking' ).addClass( 'version_outdated' );
			}
			else {
				updtxt.removeClass( 'version_checking' ).addClass( 'version_uptodate' );
			}
		}
	});
}