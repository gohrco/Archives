<?php 
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.05 ( $Id: admin_lang.php 406 2015-07-17 02:14:46Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the admin controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * This file contains all translations used in the ADMIN area of the site that isn't already in GLOBALS.  Connection
 * specific translations may be provided elsewhere
 */


// ===================================================================
// 	Dashboard (admin/index)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['admin.index']		= "Integrator Dashboard";
$lang['admin.index.desc']	= "View the status of your application here.";

// ----- Step By Step Box
$lang['stepbystep.title']	= 'Step by Step Setup';

$lang['stepbystep.num.1']	= "1";
$lang['stepbystep.num.2']	= "2";
$lang['stepbystep.num.3']	= "3";
$lang['stepbystep.num.4']	= "4";
$lang['stepbystep.num.5']	= "5";
$lang['stepbystep.num.6']	= "6";
$lang['stepbystep.num.7']	= "7";

$lang['stepbystep.title.1']	= "Configure Global Settings";
$lang['stepbystep.title.2']	= "Setup your Integrator API Account";
$lang['stepbystep.title.3']	= "Create Your First Connection";
$lang['stepbystep.title.4']	= "Create Your Second Connection";
$lang['stepbystep.title.5']	= "Map Your Pages";
$lang['stepbystep.title.6']	= "Map Your Languages";
$lang['stepbystep.title.7']	= "Test Your Application";

$lang['stepbystep.desc.1']	= "The first step is to configure your settings in the %s area.";
$lang['stepbystep.desc.2']	= "Before adding connections, you will need to setup an %s in this application for your other applications to use to connect with.";
$lang['stepbystep.desc.3']	= "Create your first connection by installing the necessary plugins for that application and then %s here.";
$lang['stepbystep.desc.4']	= "Install the necessary plugins for your second connection and then %s here.";
$lang['stepbystep.desc.5']	= "Now that you have your first two connections setup, and you have all green lights on the dashboard, you can proceed to %s.";
$lang['stepbystep.desc.6']	= "If you are using multi-lingual applications, you will want to %s as well.";
$lang['stepbystep.desc.7']	= "With the basic setup complete, proceed to test your applications by logging in and logging out, and checking your visual rendering.";

$lang['stepbystep.lang.1']	= "Global Settings";
$lang['stepbystep.lang.2']	= "API Account";
$lang['stepbystep.lang.3']	= "add that connection";
$lang['stepbystep.lang.4']	= "add that connection";
$lang['stepbystep.lang.5']	= "mapping pages";
$lang['stepbystep.lang.6']	= "map your languages";

// ----- User Log Box
$lang['userlog.title']			= 'Recent Log Activity';
$lang['logbox.hdr.link']		= 'Find';
$lang['logbox.hdr.task']		= 'Task';
$lang['logbox.hdr.email']		= 'User Email';
$lang['logbox.hdr.timestamp']	= 'Date / Time';

// ----- RSS Feed Box
$lang['rssfeed.title']		= "Latest News and Updates";

// ----- Connection Status Box
$lang['cbox.title']			= "Connection Statuses";
$lang['cbox.hdr.cnxn']		= "Connection";
$lang['cbox.hdr.type']		= "Type";
$lang['cbox.hdr.active']	= "Active";
$lang['cbox.hdr.user']		= "User";
$lang['cbox.hdr.visual']	= "Visual";
$lang['cbox.hdr.api']		= "API";

// ----- Update Box 
$lang['update.title']		= "Integrator Version";
$lang['update.okay']		= "You are running the most recent version of the Integrator, no need to update.";
$lang['update.needed']		= "Version %s is available for the Integrator.  Please visit %s to download the latest version.";


// ===================================================================
// 	Forgot Password (admin/forgot_password)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['admin.forgot_password']		= 'Forgot Your Password?';
$lang['admin.forgot_password.desc']	= 'Enter the email address associated with your account and a new password will be sent to you.';
$lang['label.email']				= 'Email Address';
$lang['desc.email']					= 'The email address associated with your account.';
$lang['btn.sendreminder']			= 'Send Reminder';



// ===================================================================
// 	Login Form (admin/login)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['admin.login']		= 'Log in';
$lang['label.username']		= 'Username';
$lang['label.password']		= 'Password';
$lang['label.remember']		= 'Remember Me';
$lang['btn.login']			= 'Log In';



// ===================================================================
// 	Manage License (license/index)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['licensing.error']		= "There is a problem with your license.  Please double check and ensure it is valid.";
$lang['button.license.manage']	= 'Manage';
//		v 3.0.6
// -------------------------------------------------------------------
$lang['label.Licensedata']		= 'Licensed To';
$lang['label.Cnxncount']		= 'Connection Count';
$lang['label.Branding']			= 'Product Branded';
$lang['label.Licensedue']		= 'Next Due Date';
//
//		v 3.0.8
// -------------------------------------------------------------------
$lang['licensing.error.cnxncount']	= 'The application has detected that there are too many connections in the database for the license.  Please correct the database table that was modified in order to continue using the product.';


// ===================================================================
// 	About Page (help/about)
// ===================================================================
//		v 3.0.2
// -------------------------------------------------------------------
$lang['help.about']			= 'About Integrator 3';
$lang['help.about.hdr.i3']	= 'Integrator <small><small>v%s</small></small>';
$lang['help.about.body.1']	= 'Copyright &copy; 2011-2012 Go Higher Information Systems, LLC';
$lang['help.about.body.2']	= 'License provided as a `Commercial End-User License`.  All Rights Reserved.';
$lang['help.about.body.3']	= 'For more information about our licensing, please visit our web site at <a href="https://www.gohigheris.com/" target="blank">https://www.gohigheris.com/</a>';

$lang['help.about.hdr.att']	= 'Attributions';
$lang['help.about.att.0']	= 'A special thanks goes out to the following developers, software platforms and designers without which Integrator 3 would not look or function as well as it does.';
$lang['help.about.att.1']	= 'Integrator 3 utilizes the PHP framework `CodeIgniter` by EllisLab, Inc. - <a href="http://codeigniter.com/user_guide/license.html" target="blank">http://codeigniter.com/</a>';
$lang['help.about.att.2']	= 'Menu icon for Integrator 3 designed primarily by Icons8 - <a href="http://icons8.com/license/">http://icons8.com/license/</a>';
$lang['help.about.att.3']	= 'CSS styling and design for Integrator 3 utilizes Bootstrap by Twitter - <a href="http://twitter.github.com/bootstrap/" target="blank">http://twitter.github.com/bootstrap/</a>';
$lang['help.about.att.4']	= 'FamFamFam iconset - <a href="http://www.famfamfam.com/lab/icons/silk/" target="blank">http://www.famfamfam.com/lab/icons/silk/</a>';
$lang['help.about.att.5']	= 'Bootstrap toggle - <a href="http://github.com/Nijikokun/bootstrap-toggle/" target="blank">http://github.com/Nijikokun/bootstrap-toggle/</a>';


// ===================================================================
// 	API Log (help/apilog)
// ===================================================================
//		v 3.0.2
// -------------------------------------------------------------------
$lang['tblhdr.id']			= '#';
$lang['tblhdr.timestamp']	= 'Timestamp';
$lang['tblhdr.cnxn']		= 'Originating Connection';
$lang['tblhdr.destcnxn']	= 'Destination Connection';
$lang['tblhdr.action']		= 'Action Performed';
$lang['tblhdr.data']		= 'Data Set';
$lang['tblhdr.remote']		= 'Remote<br/>Call';
$lang['apirequest']			= 'API Request';
$lang['apiresponse']		= 'API Response Headers';
$lang['dataresult']			= 'Data Returned';
//
//		v 3.0.2
// -------------------------------------------------------------------
$lang['filter.all']					= '- No Filter Selected -';
$lang['filter.heading.cnxn']		= 'Originating Connection';
$lang['filter.heading.destcnxn']	= 'Destination Connection';
$lang['filter.heading.action']		= 'Action Performed';
//
//		v 3.0.7
// -------------------------------------------------------------------
$lang['help.apilog']			= 'API Log';


// ===================================================================
// 	Step By Step (help/stepbystep)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['help.stepbystep']		= "Step By Step Setup Guide";
$lang['help.stepbystep.desc']	= "Follow these steps to begin the setup of your Integrator 3 application.";
$lang['help.sbs.1.title']		= 'Configure Global Settings <small>Step 1</small>';
$lang['help.sbs.1.msg.1']		= 'The very first step is to go to the %s to configure the base line settings for the application.';
$lang['help.sbs.1.msg.2']		= 'Once you are there, you can easily change the following settings:<ul><li><strong>Site Name</strong> - this should be set to the reference name you will use when emails are sent or client level actions take place from Integrator 3.  Some ideas include `accounts`, `integrator` or `manage`.</li><li><strong>System URL</strong> - be sure this matches the URL for the URL to reach Integrator 3 on your server (it probably does).</li><li><strong>Temp Directory</strong> - this is important! Be sure the path indicated here is readable and writable by Integrator 3. Session cookies will be stored here, so you may want to bury this below your public_html folder so it cannot be accessed from the outside inadvertantly. There is an .htaccess file inside the folder to help prevent unwanted access, but if your server doesn\'t recognize the file, you may be exposing session cookies without knowing it!</li></ul>';
$lang['help.sbs.1.msg.3']		= 'The rest of the settings in the Global Settings are self explanatory and are optional at this point.';
$lang['help.sbs.1.anchor.a']	= 'Global Settings';
$lang['help.sbs.2.title']		= 'Add an API User to Integrator 3 <small>Step 2</small>';
$lang['help.sbs.2.msg.1']		= 'Now that you have configured your global settings, go to the %s to add a new API administrator.';
$lang['help.sbs.2.msg.2']		= '<ul><li>Click `Create A New User`</li><li>Complete the form for the new api user. Be sure to write down the username and password you use for future reference.</li><li>Select the API Users group - only this group has access to the Integrator 3 API interface.</li><li>Click Create New User</li></ul>';
$lang['help.sbs.2.msg.3']		= 'You have successfully created a new API User! This user will be used on your various connections to communicate with Integrator 3 to create new accounts and route the user through the site.';
$lang['help.sbs.2.msg.4']		= 'Now retrieve the API Secret Key that is in your %s area. You will need this key to configure the additional connections in the next steps.';
$lang['help.sbs.2.anchor.a']	= 'Admin Management';
$lang['help.sbs.2.anchor.b']	= 'API Settings';
$lang['help.sbs.3.title']		= 'Create Your First Connection <small>Step 3</small>';
$lang['help.sbs.3.msg.1']		= 'With your API setup for Integrator 3, you are now ready to create your first connection. To do this you will need to install the extension in the framework you want to create a connection for. Available extensions are included in the main archive download for Integrator 3. To install, follow the instructions for the appropriate framework on our website. For example, the Joomla framework requires the installation of the component, a couple of plugins as well as a login module (optional), while the WHMCS framework you simply FTP the files into place and enable the extension in the backend. Follow the instructions for the connection type on our website.';
$lang['help.sbs.3.msg.2']		= 'Regardless of the connection type you are setting up, you should have setup an API username and password for the connection. If you haven\'t, you will need to and you will also need that information for this step.';
$lang['help.sbs.3.msg.3']		= 'With the external framework setup (Joomla, WHMCS, Fusion etc), click on %s to setup a new connection in Integrator 3. Select the type of connection (Joomla, WHMCS, Fusion, etc) and click Add New Connection and Continue.';
$lang['help.sbs.3.msg.4']		= 'Regardless of the type of connection, you will want to setup the following:<ul><li>Connection Name - make it easy to find (for internal use only)</li><li>Connection URL - this should be the actual URL to the front end of your connection (not the administrator backend or an api interface)</li><li>API Url - initially set this to the same as your Connection URL (it gets changed automatically)</li><li>API Credentials - you may need to provide a secret key / api key or an API username and password, either way, provide them in the API Settings tab.</li></ul>';
$lang['help.sbs.3.msg.5']		= 'The rest of the settings are straight forward; any settings requesting URLs just set to the connection URL for the time being, you can update them later.  Click Save Changes, and the Integrator 3 application will test your connection and verify your settings. If it runs into any problems, it will disable the connection and alert you. Return to the settings to correct any problems until the connection checks out.';
$lang['help.sbs.3.anchor.a']	= 'Add New Connection';
$lang['help.sbs.4.title']		= 'Create Your Second Connection <small>Step 4</small>';
$lang['help.sbs.4.msg.1']		= 'To configure your second connection, follow the same steps you did to create your first connection above.';
$lang['help.sbs.5.title']		= 'Map Your Pages <small>Step 5</small>';
$lang['help.sbs.5.msg.1']		= 'Page mapping is the process of telling Integrator 3 which page from one connection should be called to wrap around another application. For instance, in WHMCS there is a page called the Client Area. If you have a Joomla connection tied to Integrator 3, you can create a cnxn page in Joomla (follow the instructions in our documentation on doing that) and indicate in Integrator 3 that when a client visits the Client Area page, Integrator 3 should retrieve the specific page from Joomla. This permits you to assign custom content per page, thereby customizing your users\' experience.';
$lang['help.sbs.5.msg.2']		= 'This step is very important, as you must at the very least define a default page to retrieve. Failure to configure this step will result in errors and a non-functional wrapped site.';
$lang['help.sbs.5.msg.3']		= 'Start by clicking on %s. You will see a page that has in the tabbed section the applications connected to your Integrator 3 (such as WHMCS and Fusion) and inside those tabs the sites that are connected to Integrator 3 (such as Joomla or Wordpress). The first line is the default line for the given application type, and must be set to something. Select a page from each of the drop downs for the default page map. The rest of the drop downs are optional, and if left unset will revert to the default drop down you select at the top.';
$lang['help.sbs.5.anchor.a']	= 'Page Maps';
$lang['help.sbs.6.msg.1']		= 'Language mapping is essentially the same process as page mapping, except it applies to telling Integrator 3 which languages map to each other from your various connections.';
$lang['help.sbs.6.msg.2']		= 'This step is very important, as you must at the very least define a default language to retrieve. Failure to configure this step will result in errors and a non-functional wrapped site.';
$lang['help.sbs.6.msg.3']		= 'Start by clicking on %s. You will see a page that has in the tabbed section the applications connected to your Integrator 3 (such as WHMCS and Fusion) and inside those tabs the sites that are connected to Integrator 3 (such as Joomla or Wordpress). The first line is the default line for the given application type, and must be set to something. Select a default language to use at the top of each column, and if you are using multiple languages on your site, select those as well.';
$lang['help.sbs.6.title']		= 'Map Your Languages <small>Step 6</small>';
$lang['help.sbs.6.anchor.a']	= 'Language Maps';
$lang['help.sbs.7.title']		= 'Test Your Application <small>Step 7</small>';
$lang['help.sbs.7.msg.1']		= 'With the first two connections set, go ahead and test and configure the application. If you have any questions, please consult our %s and %s for further assistance.';
$lang['help.sbs.7.anchor.a']	= 'Documentation';
$lang['help.sbs.7.anchor.b']	= 'Product Support Forums';
//
//		v 3.0.1
// -------------------------------------------------------------------
$lang['help.systemstatus']			= "System Status View";
$lang['help.systemstatus.desc']		= "Check on the status of your application and connections here";
$lang['help.systemstatus.loading']	= "Your connection statuses are loading...";
//
//		v 3.0.2
// -------------------------------------------------------------------
$lang['tblhdr.help.cnxnname']		= 'Connection Name (type)';
$lang['tblhdr.help.active']			= 'Active';
$lang['tblhdr.help.user']			= 'User Integration<br/>Enabled';
$lang['tblhdr.help.visual']			= 'Visual Integration<br/>Enabled';
$lang['tblhdr.help.api']			= 'API Interface<br/>Enabled';
$lang['tblhdr.help.software']		= 'Software<br/>Up To Date';


// ===================================================================
// 	System Status Screen (help/systemstatus)
// ===================================================================
//		v 3.0.8
// -------------------------------------------------------------------
$lang['maintenance.tab']		= 'System Maintenance';
$lang['maintenance.header']		= 'These functions permit you to handle common tasks in one place rather than hunting them down in the settings.';

$lang['maintenance.apilog.legend']		= 'API Log Maintenance';
$lang['maintenance.rendercache.legend']	= 'Rendering Cache';
$lang['maintenance.sessions.legend']	= 'User Session Maintenance';

$lang['label.maintenance.ClearAPILog']		= 'Clear API Log';
$lang['label.maintenance.ClearCache']		= 'Clear Cache';
$lang['label.maintenance.ClearSessions']	= 'Clear Sessions';

$lang['btn.maintenance.ClearAPILog.init']		= 'Clear API Log';
$lang['btn.maintenance.ClearAPILog.loading']	= 'Clearing...';
$lang['btn.maintenance.ClearAPILog.complete']	= 'API Log Cleared!';
$lang['btn.maintenance.ClearAPILog.error']		= 'An error occurred!';

$lang['btn.maintenance.ClearCache.init']		= 'Clear Cache';
$lang['btn.maintenance.ClearCache.loading']		= 'Clearing...';
$lang['btn.maintenance.ClearCache.complete']	= 'Rendering Cache Cleared!';
$lang['btn.maintenance.ClearCache.error']		= 'An error occurred!';

$lang['btn.maintenance.ClearSessions.init']		= 'Clear User Sessions';
$lang['btn.maintenance.ClearSessions.loading']	= 'Clearing...';
$lang['btn.maintenance.ClearSessions.complete']	= 'User Sessions Cleared!';
$lang['btn.maintenance.ClearSessions.error']	= 'An error occurred!';

$lang['updates.tab']			= 'Updates';
$lang['updates.header']			= 'View any updates below and take action on connections that need to be updated.';

$lang['updates.update.legend']	= 'Available Updates';

$lang['tblhdr.help.updates.cnxn']				= '%s ( %s )';
$lang['tblhdr.help.updates.hasupdate']			= 'Update Now';
$lang['tbl.help.updates.version.notfound']		= 'N/A';
$lang['tbl.help.updates.status.notinstalled']	= 'Not found or installed';
$lang['tbl.help.updates.status.current']		= 'Current';
$lang['tbl.help.updates.status.update']			= 'Update Needed';

// ----- Dialog content
$lang['dialog.application.update.content']	= '<p>You will now be updating the Integrator 3 core application - be sure you have backed up your data and system files to prevent any unwanted results.</p><p>The updater will take a few moments to log in and download the latest package, extract the files and copy them in place.  During this time please DO NOT press any keys or refresh the screen or your application may not be updated or worse.</p>';
$lang['dialog.application.update.header']	= 'Perform Updates';
$lang['dialog.application.button.redirect']	= 'Update';

$lang['updates.refresh']		= 'Refresh Updates';
$lang['updates.refresh.link']	= 'Refresh';

// ===================================================================
// 	Debug Screen (admin/debug)
// ===================================================================
//		v 3.0.4
// -------------------------------------------------------------------
$lang['admin.debug']		= "Debug Information";
$lang['admin.debug.desc']	= "Below is the relevant settings and configuration for your system.  If requested for support purposes, you will need to provide this information to help diagnose any issues with your system.";

$lang['admin.debug.settings']	= 'Settings';
$lang['admin.debug.config']		= 'Config File Information';
$lang['admin.debug.cnxns']		= 'Connection Settings';
$lang['admin.debug.updates']	= 'Connection Update Statuses';
$lang['admin.debug.ssl']		= 'SSL Configuration';
$lang['admin.debug.phpinfo']	= 'Relevant PHP Information';

$lang['tblhdr.settings.name']	= 'Setting Name';
$lang['tblhdr.settings.value']	= 'Value Set';
$lang['tblhdr.settings.msg']	= 'Note';

$lang['tblhdr.config.name']		= 'Setting Name';
$lang['tblhdr.config.value']	= 'Value Set';
$lang['tblhdr.config.msg']		= 'Note';

$lang['tblhdr.cnxns.name']		= 'Connection Name (Type)';
$lang['tblhdr.cnxns.cnxnid']	= 'Connection ID';
$lang['tblhdr.cnxns.active']	= 'Active';
$lang['tblhdr.cnxns.user']		= 'User Enabled';
$lang['tblhdr.cnxns.visual']	= 'Visual Enabled';
$lang['tblhdr.cnxns.ping']		= 'Ping Result';

$lang['tblhdr.updates.name']	= 'Connection Name (Type)';
$lang['tblhdr.updates.status']	= 'Up To Date';
$lang['tblhdr.updates.msg']		= 'Note';

$lang['tblhdr.ssl.name']		= 'Setting Name';
$lang['tblhdr.ssl.value']		= 'Value Set';
$lang['tblhdr.ssl.msg']			= 'Note';

$lang['tblhdr.phpinfo.name']	= 'Setting Name';
$lang['tblhdr.phpinfo.value']	= 'Value Set';
$lang['tblhdr.phpinfo.msg']		= 'Note';

$lang['admin.debug.tmppath']	= 'Temp Directory';
$lang['admin.debug.logpath']	= 'Log Path';
$lang['admin.debug.htaccess']	= '.htaccess Enabled';

$lang['admin.debug.enable.msg'] 		= 'This setting is the global Enable setting found under Configuration > Globals and indicates the status of the application.';
$lang['admin.debug.debug.msg']			= 'This setting indicates you have debug enabled on Integrator 3.  This should not cause problems but may be sending unwanted data to the front end when your applications are wrapped.';
$lang['admin.debug.systemurl.msg']		= 'This is the System URL for your Integrator 3 and should be completely functional and match the URL above (without the index filename, admin or debug path).';
$lang['admin.debug.userenable.msg']		= 'This setting controls the use of the user integration on the entire Integrator 3 application and overrides your individual settings in the connections.';
$lang['admin.debug.visualenable.msg']	= 'This setting controls the use ot the visual integration on the entire Integrator 3 application and overrides your individual settings in the connections.';
$lang['admin.debug.unicode.msg']		= 'This tells Integrator 3 to use unicode character matching when performing regular expressions as it parses your connections to wrap around your applications.  This setting may cause problems if you are using non-UTF8 characters on any site that must be wrapped around an application.';
$lang['admin.debug.caching.msg']		= 'This indicates you have selected to cache requests to help speed up the delivery of the site to your users.';
$lang['admin.debug.registration.msg']	= 'This indicates that you wish to use the registration form on the Integrator 3 application.';

$lang['admin.debug.tmpdir.msg']			= 'This is the temporary directory set in your configuration file.  This should be a full system path, not relative.';
$lang['admin.debug.logdir.msg']			= 'This is the log directory set in your configuration file.  This should be a full system path, not relative.';
$lang['admin.debug.htaccess.msg']		= 'This is found in your configuration file and indicates that you wish to remove the index.php file from your URLs.';

$lang['admin.debug.updatecurrent.msg']	= 'This connection is up to date';
$lang['admin.debug.updatefound.msg']	= '<h4 class="alert-heading">%s <span class="badge badge-inverse"> %s</span></h4><em>%s as of %s</em><br/><br/>';

$lang['admin.debug.sslactive.msg']		= 'This indicates whether you have an active SSL certificate on this connection';
$lang['admin.debug.ssltask.msg']		= 'This indicates whether you are using SSL on the given task.';
$lang['admin.debug.ssltask.login']		= 'Task:  Logging In';
$lang['admin.debug.ssltask.logout']		= 'Task:  Logging Out';
$lang['admin.debug.ssltask.register']	= 'Task:  Registration';
$lang['admin.debug.ssltask.user']		= 'Task:  User Management';
$lang['admin.debug.ssltask.api']		= 'Task:  API Interface';

$lang['admin.debug.phpversion']			= 'PHP Version';
$lang['admin.debug.curlinit']			= 'CURL Installed';
$lang['admin.debug.iconv']				= 'iconv';
$lang['admin.debug.xmlrpc']				= 'XML-RPC';

$lang['admin.debug.phpvers.msg']		= 'This is the version of PHP you are running.';
$lang['admin.debug.curlinit.msg']		= 'This indicates you have the CURL library installed and functioning in PHP.';
$lang['admin.debug.iconv.msg']			= 'If you need to do translation and conversion from other character sets, the iconv function is required.';
$lang['admin.debug.xmlrpc.msg']			= 'Some connections require the XML-RPC library to be installed in order to communicate through the API interface.';

$lang['btn.debugfile']		= 'Download File';


// ===================================================================
// 	Navigation Menu
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['menu.home']				= "Dashboard";
$lang['menu.settings']			= "Configuration";
$lang['menu.globalsettings']	=	"Global Settings";
$lang['menu.apisettings']		=	"API Settings";
$lang['menu.sslsettings']		=   "SSL Settings";
$lang['menu.userbridging']		=	"User Bridging";
$lang['menu.visualsetup']		=	"Visual Setup";
$lang['menu.registrations']		=	"Registration Settings";
$lang['menu.notifications']		=	"Notifications";
$lang['menu.connections']		= "Connections";
$lang['menu.addnewcnxn']		=	 "Add New Connection";
$lang['menu.rendering']			= "Rendering";
$lang['menu.pagemaps'] 			=	"Page Maps";
$lang['menu.langmaps']			=	"Language Maps";
$lang['menu.usermgr']			= "Site Users";
$lang['menu.finduser'] 			=	"Find User";
$lang['menu.createuser']		=	"Create User";
$lang['menu.modifyuser']		=	"Modify User";
$lang['menu.userlog']			=	"User Log";
$lang['menu.manageadmins']		= "Admins";
$lang['menu.help']				= "Help";
$lang['menu.stepbystep']		=	"Step by Step Setup";
$lang['menu.documentation']		=	"Documentation";
$lang['menu.systemstatus']		=	"System Status";
$lang['menu.apilog']			=	"API Log";
$lang['menu.about']				=	"About Integrator 3";

$lang['menu.greeting']			= 'Welcome back %1$s %2$s';
$lang['menu.editprofile']		=	"My Profile";
$lang['menu.licensemgr']		=	"Manage License";
$lang['menu.logout']			=	"Logout";


// ===================================================================
// 	Ajax Calls (ajax/*)
// ===================================================================
//		v 3.0.1
// -------------------------------------------------------------------
$lang['ajax.isuptodate']		= 'Application Current!';
$lang['ajax.updateavail']		= 'Update Available!';

//
//		v 3.1.05
// -------------------------------------------------------------------
$lang['ajax.updatecnxn.hdr.error']				=	'An Error Occurred!';
$lang['ajax.updatecnxn.msg.defaultstate']		=	'The state `%s` is not defined';
$lang['ajax.updatecnxn.msg.nodownloadid']		=	'You don\'t have a download id set in your configuration.  Please navigate to Configuration > Global Settings > Go Higher and add your Download ID before proceeding.';
$lang['ajax.updatecnxn.msg.unabletoconnect']	=	'Unable to connect to `%s`.  Please check the API connection before attempting to update.';
$lang['ajax.updatecnxn.msg.errorupdating']		=	'There was an error updating `%s`: %s';
$lang['ajax.updatecnxn.msg.connecting']			=	'Connecting to `%s`... please wait';
$lang['ajax.updatecnxn.msg.updating']			=	'Updating `%s`... please wait';
$lang['ajax.updatecnxn.msg.updatecomplete']		=	'Update complete for `%s`.  Reloading connection statuses';


// ===================================================================
// 	Admin User List (users/index)
// ===================================================================
//		v 3.0.2
// -------------------------------------------------------------------
$lang['users.index']				= 'Manage Users';
$lang['users.index.desc']			= 'Manage the users with access to this application.';
$lang['tblhdr.users.username']		= 'Username';
$lang['tblhdr.users.group']			= 'Group';
$lang['tblhdr.users.contact']		= 'Contact Info';
$lang['tblhdr.users.active']		= 'Active';
$lang['tblhdr.users.actions']		= 'Actions';



// ===================================================================
// 	Admin User Creation (users/create_user)
// ===================================================================
//		v 3.0.2
// -------------------------------------------------------------------
$lang['users.create_user']			= "Create User";
$lang['users.create_user.desc']		= "Enter the information completely and press `Create User`.";
$lang['btn.createnewuser']			= 'Add User';
$lang['button.create_user']			= "Create New User";
$lang['button.edit_user']			= "Save Changes To User";

// ----- Form Labels
$lang['username']					= "Username";
$lang['first_name']					= "First Name";
$lang['last_name']					= "Last Name";
$lang['email']						= "Email Address";
$lang['group_id']					= "Permissions Group";
$lang['company']					= "Department Name";
$lang['password']					= "Password";
$lang['password-confirm']			= "Confirm Password";

// ----- Form Descriptions
$lang['username.desc']				= "Enter a unique username for this user.  This will be separate from any others used on other connections.";
$lang['first_name.desc']			= "Enter the first name of the user.";
$lang['last_name.desc']				= "Enter the last name of the user.";
$lang['email.desc']					= "Enter a unique email address for this user.";
$lang['group_id.desc']				= "Select which permissions group this user belongs to.  Choices are <ul><li><strong>Administrator</strong> - Backend access to the Integrator.</li><li><strong>API Users</strong> - API access to the Integrator only.</li>";
$lang['company.desc']				= "Enter the department name for this user.";
$lang['password.desc']				= "Enter a password for this user.";
$lang['edit.password.desc']			= "(leave blank for no change) Enter a password for this user.";
$lang['password-confirm.desc']		= "Confirm the password";



// ===================================================================
// 	Admin User Editing (users/edit_user)
// ===================================================================
//		v 3.0.2
// -------------------------------------------------------------------
$lang['users.edit_user']		= "Edit User";
$lang['users.edit_user.desc']	= "Make changes to the information for this user below and press `Save Changes`";

$lang['btn.deleteuser']			= 'Delete User';
$lang['btn.canceledit']			= 'Cancel';
$lang['btn.makechange']			= 'Save Changes';

$lang['users.firstname']		= "First Name";
$lang['users.lastname']			= "Last Name";
$lang['users.username']			= "Username";
$lang['users.email']			= "Email Address";
$lang['users.group']			= "Permissions Group";
$lang['users.company']			= "Company Name";
$lang['users.password']			= "Password";
$lang['users.pwconfirm']		= "Confirm Password";

$lang['btn.create_user']		= 'Create New User';
$lang['users.edit_user']		= 'Edit User';
$lang['users.delete_user']		= 'Delete User';
$lang['users.edit_activate']	= 'Activate User';
$lang['users.edit_deactivate']	= 'Deactivate User';

// ----- Delete user modal
$lang['dialog.delete.userswarn']		= "Deleting this admin user if it is still being used may have unwanted results such as failure of your connections to log into Integrator 3 (if an API user) or failure to log into the Integrator 3 application as an administrator.  This cannot be undone without recreating the connection from scratch.";
$lang['dialog.delete.userstitle']		= "Delete `%s`";
$lang['btn.deluser']				= "Confirm Delete";



// ===================================================================
// 	Create New User (usermgr/create)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['usermgr.create']			= "Create User";
$lang['usermgr.create.desc']	= "Create a new user on a specific connection only.";
$lang['btn.selcnxn']			= "Select Connection";
$lang['btn.createuser']			= "Validate and Create New User";

// ----- Form Labels (used for both create and modify)
$lang['label.email']			= "Email Address";
$lang['label.username']			= "Username";
$lang['label.name']				= "Name";
$lang['label.password']			= "Password";
$lang['label.language']			= 'Default Language';

// ----- Form Description (used for both create and modify)
$lang['desc.email']				= "Enter the email address to use for this account.";
$lang['desc.username']			= "Enter a unique username for this account.";
$lang['desc.name']				= "Enter a complete name for this account.";
$lang['desc.password']			= "Enter a password for this account.";
$lang['desc.language']			= 'Select the language this administrator will use.  The Default Language will defer to the System Default Language as set in your Configuration > Global Settings.';


// ===================================================================
// 	Find User (usermgr/find)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['usermgr.find']			= "Find A User";
$lang['usermgr.find.desc']		= "Find a user across all your connections.";

$lang['label.user']				= "Email or Username";
$lang['desc.user']				= "Enter either the username or the email address of the user you are searching for.";
$lang['usermgr.linkuser']		= "Find user by `%s`";
$lang['usermgr.linkemail']		= "Find user by `%s`";
$lang['usermgr.createnew']		= "Create a new user";
$lang['usermgr.modifyuser']		= "Edit";
$lang['usermgr.deleteuser']		= "Delete";
$lang['usermgr.viewlog']		= "View User Log";
$lang['usermgr.notfound']		= 'No user found on this connection.';

$lang['btn.finduser']		= "Find User";
$lang['btn.createnew']			= 'Create';
//
//		v 3.0.1
// -------------------------------------------------------------------
$lang['label.exact']				= "Exact Name";
$lang['desc.exact']					= 'You can search for the exact user you are looking for by checking the box above.  Leave this disabled to do a search through your connections for a user that matches your entry.';
$lang['usermgr.notsupported']		= 'Usernames are not supported by this connection';
//
//		v 3.0.2
// -------------------------------------------------------------------
$lang['usermgr.find.results']			= 'Exact User Search Results';
$lang['usermgr.modify.cnxn_id']			= 'Enter Email or Username';
$lang['usermgr.modify.user']			= 'Edit User';
$lang['usermgr.find.results.desc']		= 'Below are the results for your search.  If you searched by a username, some connections may not support the username field and will not result in a found result, though there may be an account with a matching email address.  To verify, you can click the black button at the bottom to search by email address for the found users.';
$lang['usermgr.modify.cnxn_id.desc']	= 'Enter the username or the email address of the user you want to modify.  Note that this is an exact search, so if you aren\'t sure about the account, you should do a search first to verify you modify the correct account.';
$lang['usermgr.modify.user.desc']		= 'Edit the information below for the user below.  You can change the password by filling in a new password, or leave the password blank to make no changes to the password.  When completed, ';
$lang['btn.viewlog']					= 'View Log';
$lang['cuser.fullname']					= '%1$s %2$s'; // Provides a way to create a fullname from firstname lastname in cuser object
$lang['cuser.address']					= '%1$s %2$s :: %3$s, %4$s  %5$s'; // Provides a way to create an address block in cuser object
$lang['usermgr.username2']				= '<strong>%1$s</strong>';
$lang['usermgr.notsupported2']			= '<em>Usernames are not supported by this connection</em>';
$lang['usermgr.search.cnxnname']		= '<h4>%1$s</h4>';
$lang['usermgr.search.userblock']		= '<h3 style="margin-top: -10px; ">%1$s</h3><h6>%2$s</h6><em>Email:</em> <strong>%3$s</strong><br/><em>Username:</em> %4$s'; // Found on search page
$lang['usermgr.search.usernotfound']	= '<h6>No user found on this connection matching `%s`</h6>';

// ----- Delete Modal
$lang['modal.header.deleteconfirm']		= 'Delete `%s`?';
$lang['modal.content.deleteconfirm']	= 'Are you sure you want to delete this user from this connection?  You will not be able to restore a deleted user without recreating them completely.  Note that some connection types disable or deactivate the account rather than delete entirely.';



// ===================================================================
// 	User Log (usermgr/log)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['usermgr.log']		= "User Log";
$lang['usermgr.log.desc']	= "A log of user activity across your applications.";
$lang['btn.first']			= "|<< First";
$lang['btn.previous']		= "<< Previous";
$lang['btn.next']			= "Next >>";
$lang['btn.end']			= "Last >>|";
// $lang['hdr.task']			= "Task";
// $lang['hdr.user']			= "User";
// $lang['hdr.ipaddress']		= "IP Address";
// $lang['hdr.date']			= "Date";
//
//		v 3.0.2
// -------------------------------------------------------------------
$lang['tblhdr.task']				= 'Task';
$lang['tblhdr.ip']					= 'IP Address';
$lang['tblhdr.email']				= 'Email Address';
$lang['tblhdr.data']				= 'Dataset';
$lang['tblhdr.time']				= 'Time';
$lang['tblhdr.log']					= 'Logged Data';
$lang['tblhdr.usermgr.cnxnname']	= 'Connection';
$lang['tblhdr.usermgr.userdetails']	= 'User Details';
$lang['tblhdr.usermgr.actions']		= 'Actions';



// ===================================================================
// 	Modify User (usermgr/modify)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['label.cnxnid']				= "Select Connection";
$lang['usermgr.modify']				= "Modify A User";
$lang['label.modifyuser']			= "Email or Username";

$lang['desc.cnxnid']				= "Select a connection to find the user from.  Changes made to the user on this connection will only affect the selected connection.";
$lang['usermgr.modify.desc']		= "Select the connection and find the user to modify information for.  This allows you to make direct changes to a user's account on any connection.";
$lang['desc.modifyuser']			= "Type in either the current username or the current email address for the user you are searching for.  If the connection you selected does not support usernames, be sure to enter a valid email address.";
$lang['btn.updateuser']				= "Update User Information";



// ===================================================================
// 	Search User (usermgr/search)
// ===================================================================
//		v 3.0.1
// -------------------------------------------------------------------
$lang['usermgr.search']			= "User Search";
$lang['usermgr.search.desc']	= "Find who you are looking for here.";
$lang['usermgr.emailaddr']		= "Email Address";
$lang['usermgr.username']		= "Username";
$lang['usermgr.cnxn']			= "Connection";
$lang['btn.edituser']			= "Edit User";
$lang['usermgr.search.header']	= 'Search Results';
//		v 3.0.4
// -------------------------------------------------------------------
$lang['btn.isolateuser']		= 'Isolate This User';


// ===================================================================
// 	General Settings (settings/index)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['settings.index']				= 'General Settings';
$lang['settings.index.desc']		= 'Make changes to the settings below.';
$lang['btn.saveandclose']			= 'Save and Return to Dashboard';
$lang['btn.updatesettings']			= "Save Settings";

// ----- Global Tab
$lang['global.tab']		= "Global Settings";
$lang['global.header']	= 'These settings are completely global and affect the product in its entirety.  Please note that disabling Integrator 3 here will not disable Integrator 3 throughout the rest of your applications, you will need to go into each connection and disable it there as well.';
// ----- Global Tab: Form Lables
$lang['label.global.Sitename']		= "Sitename";
$lang['label.global.Enable']		= "Enable Integrator";
$lang['label.global.Debug']			= "Debug";
// ----- Global Tab: Form Descriptiongs
$lang['desc.global.Sitename']		= "A reference name for your Integrator application.";
$lang['desc.global.Enable']			= "This setting turns the entire Integrator on or off and acts as a master switch.";
$lang['desc.global.Debug']			= "Turn this setting on if you encounter issues and need to debug the application.";

// ----- System Tab
$lang['system.tab']		= 'System Settings';
$lang['system.header']	= 'These settings are global and affect the functionality of the Integrator 3 system itself.';
// ----- System Tab: Form Lables
$lang['label.system.SystemURL']			= 'System URL';
$lang['label.system.DefaultLanguage']	= 'Default Language';
$lang['label.system.LogDir']			= 'Log Directory';
$lang['label.system.LogCount']			= 'Log Records';
// ----- System Tab: Form Description
$lang['desc.system.SystemURL']			= 'Enter the URL to this application.';
$lang['desc.system.DefaultLanguage']	= 'Select the default language for your Integrator 3 application.  This can be changed and overridden during login for a given session or set on the admin profile page for a given administrator.';
$lang['desc.system.LogDir']				= 'This directory stores diagnostic information for the Integrator 3 application; the default directory should be fine.';
$lang['desc.system.LogCount']			= 'Indicates the number of log records that should be stored in the database; note this is different from the diagnostic files stored in the directory above.';

// ----- Email Tab
$lang['email.tab']		= "Email Settings";
$lang['email.header']	= 'The settings on this page affect the use of email by your Integrator 3 system.  There are times when you will need to send emails to admins notifying you of failed attemps, or emails to be sent to users that forget their credentials.';
// ----- Email Tab: Form Lables
$lang['label.email.Emailprotocol']		= "Email Protocol";
$lang['label.email.Emailsmtpport']		= "SMTP Port";
$lang['label.email.Emailsmtphost']		= 'SMTP Host';
$lang['label.email.Emailsmtpuser']		= 'SMTP Username';
$lang['label.email.Emailsmtppass']		= 'SMTP Password';
$lang['label.email.Emailfromname']		= 'Admin From Name';
$lang['label.email.Emailaddress']		= 'Admin Email Address';
// ----- Email Tab: Form Description
$lang['desc.email.Emailprotocol']		= "Select how to send email to administrators.";
$lang['desc.email.Emailsmtpport']		= "If using SMTP above, enter the port number for your SMTP server";
$lang['desc.email.Emailsmtphost']		= 'If using SMTP above, enter the hostname for your SMTP server.';
$lang['desc.email.Emailsmtpuser']		= 'If using SMTP above and your server requires authentication, enter the username for your SMTP server.';
$lang['desc.email.Emailsmtppass']		= 'If using SMTP above and your server requires authentication, enter the password for your SMTP server.';
$lang['desc.email.Emailfromname']		= 'Enter the name you would like to appear as the from name (not the from email address) for all system messages.';
$lang['desc.email.Emailaddress']		= 'Enter the email address to appear as the from email address for all system messages.';
// ----- Email Tab: Form Field Options
$lang['options.email.Emailprotocol']	= array( 'smtp' => "SMTP ", 'mail' => "PHP Mail" );

// ----- Global Tab
$lang['gohigher.tab']		= "Go Higher Settings";
$lang['gohigher.header']	= 'These settings relate to the interaction of Integrator 3 with our site.';
// ----- Global Tab: Form Lables
$lang['label.gohigher.downloadid']			=	'Download ID';
//$lang['label.gohigher.GoHigherUsername']	= "Go Higher Username";
//$lang['label.gohigher.GoHigherPassword']	= "Go Higher Password";
// ----- Global Tab: Form Descriptiongs
$lang['desc.gohigher.downloadid']			=	'This is a unique code that can be found on our web site by navigating to https://www.gohigheris.com and logging in.  The Download ID can be found on the right side after logging in.';
//$lang['desc.gohigher.GoHigherUsername']		= "This is either your email address or username you use on the Go Higher web site to log in with.";
//$lang['desc.gohigher.GoHigherPassword']		= "This is the password for your account on the Go Higher web site.";



// ===================================================================
// 	API Settings (settings/api)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['api.tab']				= "API Settings";
$lang['api.header']				= 'Below you will find the API settings related to the Integrator 3.  You will need to keep track of the API Secret Key below, as you will need it on your other applications that connect to Integrator 3.  If you are experiencing any issues with data transfer, user logins or connectivity in general, you can enable the API logging feature below.  Beware that it will fill your database up very quickly!';

// ----- Form Labels
$lang['label.api.Secret']		= "API Secret Key";
$lang['label.api.APILogging']	= "API Logging";
$lang['label.api.ClearAPILog']	= 'Clear API Log';

// ----- Form Descriptions
$lang['desc.api.Secret']		= "For security purposes, a random code is set here and must be used with your other integrated applications to ensure communications between Integrator 3 and those applications are kept secure.  The default setting here is randomly generated when you first installed Integrator 3, and can be modified above to something else you may prefer.  Never give out your API Secret Key as this will open up your data to serious security risks!";
$lang['desc.api.APILogging']	= "To help debug your system, you can enable logging of API calls here.  Please note that this will result in filling up your database with a lot of data and should not be left on indefinitely.";
$lang['desc.api.ClearAPILog']	= 'You can use this to clear the API log in the event your database gets filled up or you just want to purge it.';

// ----- Button Messages
$lang['btn.api.ClearAPILog.init']		= 'Clear API Log';
$lang['btn.api.ClearAPILog.loading']	= 'Clearing...';
$lang['btn.api.ClearAPILog.complete']	= 'API Log Cleared!';
$lang['btn.api.ClearAPILog.error']		= 'An error occurred!';
//
//		v 3.0.7
// -------------------------------------------------------------------
$lang['settings.api']			= 'API Settings';


// ===================================================================
// 	User Settings (settings/user)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------

// ----- User Settings
$lang['users.tab']		= "User Settings";
$lang['users.header']	= 'The settings here allow you to control in a general sense the user integration done through Integrator 3.  These are global controls and may be overridden by connection specific settings that you may be available to you.';
// ----- User Settings: Form Labels
$lang['label.users.EnableUser']		= "Enable User Integration";
$lang['label.users.SessionTimeout']	= "Session Timeout";
$lang['label.users.Defaultuser']	= "Default Account Site";
// ----- User Settings: Form Description
$lang['desc.users.EnableUser']		= "Turn this setting on to allow users to be bridged across all your applications.";
$lang['desc.users.SessionTimeout']	= "Set the session timeout level for your users on this application.  Note that for best results, all your session timeouts should matchup across all your applications.";
$lang['desc.users.Defaultuser']		= "When a user is logged in, this connection will act as the 'goto' connection for displaying their information to them from another connection.";
// ----- User Settings: Form Field Options
$lang['options.users.UseSSL']	= array( 0 => "Never Use", 1 => "Always Use (Force)", 2 => "Use When Present (Ignore)" );

// ----- User Display Settings
$lang['display.tab']		= "User Display Settings";
$lang['display.header']		= 'These settings allow you to activate and control the Redirecting overlay that is displayed when a user logs into your sites using Integrator 3.  Enabling the overlay permits you to provide a cleaner and nicer interface for your clients; disabling it may assist you in troubleshooting any errors that crop up.';
// ----- User Display Settings:  Form Lables
$lang['label.display.DisplayLogin']	= "Display Overlay";
$lang['label.display.LoginMsg']		= "Login Message";
$lang['label.display.LogoutMsg']	= "Logout Message";
// ----- User Display Settings:  Form Descriptions
$lang['desc.display.DisplayLogin']	= "This setting allows the use of a wrapped iFrame to log a user in, thereby displaying a message to the user indicating that they are logging in or logging out.  This also 'hides' to an extent the page jumps when logging in or out";
$lang['desc.display.LoginMsg']		= "If you are using the iframe version of the log in / out procedure, you can set a custom message to display to your users here.";
$lang['desc.display.LogoutMsg']		= "If you are using the iframe version of the log in / out procedure, you can set a custom message to display to your users here.";
//
//		v 3.0.7
// -------------------------------------------------------------------
$lang['settings.user']			= 'User Settings';
//
//		v 3.0.8
// -------------------------------------------------------------------
$lang['label.users.WipeSessions']		= 'Clear Sessions';
$lang['desc.users.WipeSessions']		= 'This permits you to wipe the table containing your users sessions in the event it gets too large or any errors occur.';

// ----- Button Messages
$lang['btn.users.WipeSessions.init']		= 'Clear User Sessions';
$lang['btn.users.WipeSessions.loading']		= 'Clearing...';
$lang['btn.users.WipeSessions.complete']	= 'Sessions Cleared!';
$lang['btn.users.WipeSessions.error']		= 'An error occurred!';


// ===================================================================
// 	Visual Settings (settings/visual)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------

// ----- Visual Settings
$lang['visual.tab']		= "Visual Settings";
$lang['visual.header']	= 'The settings here allow you to control in a general sense the visual integration done through Integrator 3.  These are global controls and may be overridden by connection specific settings that you may be available to you.';
// ----- Visual Settings: Form Labels
$lang['label.visual.EnableVisual']		= "Enable Visual Integration";
$lang['label.visual.Defaultvisual']		= "Default Visual Site";
$lang['label.visual.SystemSSL']			= "Use SSL for Integrator3";
$lang['label.visual.UnicodeMatching']	= "Unicode Matches";
// ----- Visual Settings: Form Descriptions
$lang['desc.visual.EnableVisual']		= "Turn this setting on to wrap your applications with your selected sites.";
$lang['desc.visual.Defaultvisual']		= "If a user is accessing an application directly without having first gone to a site to set the appropriate id, select which site should wrap your application by default.";
$lang['desc.visual.SystemSSL']			= "If you have a valid security certificate for the domain that the Integrator is used on and the domains your applications are used on, you can enable this to protect sensitive information for customers when registering or logging in and out.";
$lang['desc.visual.UnicodeMatching']	= "<i>Advanced!</i> If you encounter issues wrapping your site properly, you can try disabling the unicode matching to see if it rectifies the situation";
// ----- Visual Settings: Form Field Options
$lang['options.visual.SystemSSL']		= array( 0 => "Never Use", 1 => "Always Use (Force)", 2 => "Use When Present (Ignore)" );

// ----- Caching
$lang['cache.tab']		= "Caching";
$lang['cache.header']	= 'These settings control the use of caching by the visual integration in Integrator 3 and are global in nature, only available here.';
// ----- Caching: Form Labels
$lang['label.cache.Cache']				= "Enable Caching";
$lang['label.cache.CacheTTL']			= "Cache TTL";
// ----- Caching: Form Descriptions
$lang['desc.cache.Cache']				= "Enabling the cache system will speed up rendering of your sites around your applications.";
$lang['desc.cache.CacheTTL']	= "Time to live for the cache (in minutes)";
//
//		v 3.0.7
// -------------------------------------------------------------------
$lang['settings.visual']			= 'Visual Settings';
//
//		v 3.0.8
// -------------------------------------------------------------------
$lang['label.cache.ClearCache']		= 'Clear Cache';
$lang['desc.cache.ClearCache']		= 'Clear the cache in the application.';

// ----- Button Messages
$lang['btn.cache.ClearCache.init']		= 'Clear Session Cache';
$lang['btn.cache.ClearCache.loading']	= 'Clearing...';
$lang['btn.cache.ClearCache.complete']	= 'Session Cache Cleared!';
$lang['btn.cache.ClearCache.error']		= 'An error occurred!';


// ===================================================================
// 	Registration Settings (settings/registrations)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------

// ----- Registration Settings
$lang['reggeneral.tab']		= "Registration Settings";
$lang['reggeneral.header']	= 'These settings manage the registration of your users on the front end of your Integrator 3 application.  If allowed to do so, your various connections can all be registered at the same time through the Integrator 3 registration form.';
// ----- Registration Settings: Form Labels
$lang['reggeneral.EnableRegistration']	= "Enable Registration";
$lang['reggeneral.EnableCSValidation']	= "Enable AJAX";
$lang['reggeneral.DefaultVisualreg']	= "Registration Site";
$lang['reggeneral.RegRedirectionUrl']	= "URL Upon Success";
$lang['reggeneral.DefaultCountry']		= "Default Country";
$lang['reggeneral.BanFreebies']			= 'Ban Freebie Emails';
// ----- Registration Settings: Form Decsriptions
$lang['desc.reggeneral.EnableRegistration']	= "You can choose to use the Integrator's built in registration form which will create a registration form requesting any necessary fields for your various connections and provide a single point of registration for your site.";
$lang['desc.reggeneral.EnableCSValidation']	= "This permits the Integrated Registration form to use javascript and AJAX calls to validate data before the user creates their new account.";
$lang['desc.reggeneral.DefaultVisualreg']	= "You can specify a connection here to retrieve for wrapping your registration form with, unless it is overridden by a direct call from another connection.";
$lang['desc.reggeneral.RegRedirectionUrl']	= "Enter a URL to redirect your new user to upon successful registration.";
$lang['desc.reggeneral.DefaultCountry']		= "Select the default country to use on your registration form.";
$lang['desc.reggeneral.BanFreebies']		= 'You can elect to ban free email addresses from being registered on your site by enabling this feature.  Note that some applications permit you to ban free email addresses, and if the setting here is set to Disabled but the connection is set to filter those addresses, your users may not be completely registered.';

// ----- Password Settings
$lang['password.tab']						= "Password Settings";
$lang['password.header']					= 'This page has settings that control how you want to handle customer password requirements.  You can enable the password strength indicator and customize the message that is displayed back to your customers if they supply an insufficiently strong password.';
// ----- Password Settings: Form Labels
$lang['password.PasswordText']				= "Failed Message";
$lang['password.PasswordStrength']			= "Strength Indicator";
// ----- Password Settings: Form Descriptions
$lang['desc.password.PasswordText']			= "You can customize the message that is displayed to users when their password strength is not sufficient for registration to be completed.";
$lang['desc.password.PasswordStrength']		= "You can elect to render a 'password strength' meter beneath the password fields by setting this field to Yes.";

// ----- reCaptcha Settings
$lang['recaptcha.tab']						= "reCaptcha Settings";
$lang['recaptcha.header']					= 'This page contains settings relating to the use of reCaptcha on the Integrator 3 application.  It is highly recommended that you enable and use reCaptcha in order to avoid spam registrations from being placed through all your system applications.';
// ----- reCaptcha Settings: Form Labels
$lang['recaptcha.RecaptchaEnable']			= "Enable reCaptcha";
$lang['recaptcha.RecaptchaPublickey']		= "reCaptcha Public Key";
$lang['recaptcha.RecaptchaPrivatekey']		= "reCaptcha Private Key";
$lang['recaptcha.RecaptchaTheme']			= "reCaptcha Theme";
$lang['recaptcha.RecaptchaLang']			= "reCaptcha Language";
// ----- reCaptcha Settings: Form Descriptions
$lang['desc.recaptcha.RecaptchaEnable']		= "If you want to use reCaptcha for user registration, you can enable it here.";
$lang['desc.recaptcha.RecaptchaPublickey']	= "Enter your reCaptcha Public Key";
$lang['desc.recaptcha.RecaptchaPrivatekey']	= "Enter your reCaptcha Private Key";
$lang['desc.recaptcha.RecaptchaTheme']		= "Select the reCaptcha theme you want to use";
$lang['desc.recaptcha.RecaptchaLang']		= "Select the reCaptcha language you want to use";
// ----- reCaptcha Settings: Form Field Options
$lang['recaptcha.RecaptchaTheme_options']	= array( 'blackglass' => 'Black Glass', 'clean' => 'Clean', 'red' => 'Red', 'white' => 'White' );
$lang['recaptcha.RecaptchaLang_options']	= array( 'en' => "English", 'nl' => "Dutch", 'fr' => 'French', 'de' => 'German', 'pt' => 'Portuguese', 'ru' => 'Russian', 'es' => 'Spanish', 'tr' => 'Turkish' );

// ----- Field Order
$lang['fieldorder.tab']					= "Field Order";
$lang['fieldorder.header']				= 'The field labels below can be sorted into any order to display in the order you select back to your user when they register.  This permits you to indicate when certain fields should be requested from the user.  Note that not all of these fields will be used, if you have connections that do not require some fields, they will not be requested from your users.';
$lang['fieldorder.FieldOrder']			= "Field Order";
$lang['desc.fieldorder.FieldOrder']		= "Arrange the order of the fields as they appear on your registration form by clicking and dragging the field name into the desired order.  Some fields may not be used for all connections, and some fields are redundant, for example if one connection asks only for a full name, and another asks for a first and last name, the first and last name will be requested and the full name assembled from those fields.";
//
//		v 3.0.1
// -------------------------------------------------------------------
$lang['settings.fullname']		= "Full Name";
$lang['settings.firstname']		= "First Name";
$lang['settings.lastname']		= "Last Name";
$lang['settings.username']		= "Username";
$lang['settings.email']			= "Email Address";
$lang['settings.password']		= "Password";
$lang['settings.address1']		= "Address 1";
$lang['settings.address2']		= "Address 2";
$lang['settings.city']			= "City";
$lang['settings.state']			= "State";
$lang['settings.postal']		= "Postal Code";
$lang['settings.country']		= "Country";
$lang['settings.phone']			= "Phone Number";
$lang['settings.companyname']	= "Company Name";
//
//		v 3.0.7
// -------------------------------------------------------------------
$lang['settings.registrations']			= 'Registration Settings';

// ===================================================================
// 	SSL Settings (settings/ssl)
// ===================================================================
//		v 3.0.1
// -------------------------------------------------------------------
$lang['sslactive.tab']			= 'Certificates Active';
$lang['sslactive.header']		= 'Indicate below whether or not you are using an SSL certificate on the given connection.  If you have configured each connection to use SSL, you can mark the matching connection below as "On".  If you don\'t have an SSL certificate installed, be sure to set it to "Off" below or you will get SSL errors for any tasks that you have SSL enabled for.';

// ----- Task Settings
$lang['tasks.tab']				= "Task Settings";
$lang['tasks.header']			= "This is an advanced area that permits you to enable or disable SSL during specific client related functions.  To disable SSL use on a certain function, simply set it to 'Off'.  If you enable SSL for a certain function, the use of SSL will also be dependant upon the availability of SSL for a certain connection.";
// ----- Task Settings: Form Labels
$lang['tasks.login']			= "Log In";
$lang['tasks.logout']			= "Log Out";
$lang['tasks.register']			= "Client Registration";
$lang['tasks.user']				= "User Info / Edit";
$lang['tasks.api']				= "API Interface";
// ----- Task Settings: Form Descriptions
$lang['desc.tasks.login']		= 'This enables the use of SSL when logging in across all connections that have SSL available for use.';
$lang['desc.tasks.logout']		= 'This enables the use of SSL when logging out across all connections that have SSL available for use.';
$lang['desc.tasks.register']	= 'This enables the use of SSL when a new client registers through the Integrated registration form but only when SSL is enabled on both the Integrator 3 application AND the visual connection being called to wrap the form.';
$lang['desc.tasks.user']		= 'This enables the use of SSL when viewing information or editing a user information.';
$lang['desc.tasks.api']			= 'This enables the use of SSL when connecting across the API interfaces for your various connections.';
//
//		v 3.0.7
// -------------------------------------------------------------------
$lang['settings.ssl']			= 'SSL Settings';
//
//		v 3.0.8
// -------------------------------------------------------------------
$lang['tasks.render']			= 'Rendering';


// ===================================================================
// 	License Management (license/index)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['license.index']			= "Integrator Licensing";
$lang['license.index.desc']		= "Here you can manage your Integrator license directly.";

$lang['label.License']			= "Integrator License";
$lang['desc.License']			= "Enter the license associated with your product purchase from Go Higher.  Please note that a valid license is required for product usage.  For more information, please visit the Go Higher website at " . anchor( "https://www.gohigheris.com", "https://www.gohigheris.com", array( 'target' => '_blank' ) );

$lang['btn.license']			= "Update License";
$lang['btn.licensereload']		= 'Reload License';


// ===================================================================
// 	Pagemapping (pagemap/index)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['pagemap.index']			= "Page Mappings";
$lang['pagemap.index.desc']		= "Map the available pages from your applications to your sites so the proper pages are loaded by the Integrator.";
$lang['pagemap.hdr.page']			= "Page";
$lang['pagemap.hdr.defaultpage']	= "Default Page";
$lang['option.pagemap.default'] 	= "-- use default page --";
$lang['integrator.page.header']		= 'The settings below indicate which pages on the Integrator 3 application are mapped to which pages from the selected site pages.  A default page must be set (at the top) and you can choose to have certain pages retrieved when the user is on the associated Integrator 3 page.';



// ===================================================================
// 	Language Mapping (langmap/index)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['langmap.index']				= "Language Mapping";
$lang['langmap.index.desc']			= "Map the available languages from your applications to your sites so the proper translations are loaded by the Integrator.";
$lang['langmap.hdr.page']			= "Language";
$lang['langmap.hdr.defaultlang']	= "Default Language";
$lang['option.langmap.default'] 	= "use default language";





$lang['integrator.lang.header']		= 'The settings below indicate which languages on the Integrator 3 application are mapped to which languages from the selected site languages.  A default language must be set (at the top) and you can choose to have certain languages retrieved when the user is using the associated Integrator 3 language.';



// ===================================================================
// 	Add Connection (cnxns/add)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['cnxns.add']				= "Add Connection";
$lang['cnxns.add.desc']			= "Select what type of connection you wish to add to the Integrator and press `Add Connection` to continue.";
$lang['label.type']				= "Connection Type";
$lang['desc.type']				= "Select one of these types of connections to add to your Integrator application.";
$lang['btn.addcnxn']			= "Add Connection and Continue";



// ===================================================================
// 	Delete Connection (cnxns/edit - modal)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['dialog.delete.warning']		= "Deleting this connection if it is still being used will have unwanted results such as failure to log users in completely or failure to wrap your site.  This cannot be undone without recreating the connection from scratch.";
$lang['dialog.delete.cnxntitle']	= "Delete `%s`";



// ===================================================================
// 	Edit Connection (cnxns/edit)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['cnxns.edit']					= "Edit Connection";
$lang['cnxns.edit.desc']			= "Make changes to this connection and press 'Save Changes' at the bottom.  To delete the connection, press 'Delete Connection' at the bottom.";
$lang['btn.editcnxn']				= "Save Changes";
$lang['btn.delcnxn']				= "Delete Connection";

// ----- Global Tab
$lang['globals.tab']		= "Connection Basics";
$lang['globals.header']		=	'These settings relate to the connection that you are editing and are general in nature.  Enabling the connection does not necessary permit user and visual integration to be done through this connection, as there are other settings throughout the system that can affect these features.';
// ----- Global Tab: Form Labels
$lang['label.globals.name']		= "Connection Name";
$lang['label.globals.url']		= "Connection URL";
$lang['label.globals.active']	= "Connection Active";
$lang['label.globals.id']		= 'Connection ID';
// ----- Global Tab: Form Descriptions
$lang['desc.globals.name']		= "Assign a friendly usable name to this connection.  Be sure it is unique from any other connection names.";
$lang['desc.globals.url']		= "Enter the URL for your connection here.";
$lang['desc.globals.active']	= "This acts as a global switch for the connection; setting this to no will prevent visual and user integration.  If your settings are incorrect, this setting may be set to no for you to prevent unwanted integration errors.";
$lang['desc.globals.id']		= 'This is the identifier for your connection within Integrator 3.  It may not be changed, however it is provided here as some connections require you to know the Connection ID in order to connect properly to Integrator 3.';

// ----- API Tab
$lang['api.tab']		= "API Settings";
$lang['api.header']		= 'These settings control how your connection interacts with Integrator 3.  These settings must be correct in order to permit access to your remote connection from Integrator 3.';
// ----- API Tab: Form Labels
$lang['label.api.apiurl']		= "API URL";
$lang['label.api.sslverify']	= "Force SSL for API";
$lang['label.api.username']		= "API Username";
$lang['label.api.password']		= "API Password";
// ----- API Tab: Form Description
$lang['desc.api.apiurl']		= "Enter the URL to directly reach your API interface.  Typically it will be the same as your Connection URL, however in the event you are using redirects this will need to be set to the final redirected URL.  Once saved, the Integrator will attempt to connect to your API and modify your settings if redirects are encountered.";
$lang['desc.api.sslverify']		= "If you have a valid SSL certificate on the domain this application is located on, you can set this to force ssl to ensure more secure communication.";
$lang['desc.api.username']		= "Enter the username to use for connecting to your API";
$lang['desc.api.password']		= "Enter the password to use for connecting to your API";

// ----- User Tab
$lang['users.tab']		= "User Settings";
$lang['users.header']	= 'These settings are related to the integration of the user accounts through Integrator 3 to this connection.  There are instances where Integrator 3 must create missing information when the user registers, and the settings below will assist Integrator 3 in doing so.';
// ----- User Tab: Form Labels
$lang['label.users.userenable']		= "Enable User Integration";
$lang['label.users.loginurl']		= "Login URL";
$lang['label.users.logouturl']		= "Logout URL";
$lang['label.users.processlogin']	= "User Log Ins";
$lang['label.users.forceadd']		= "Force Add Users";
$lang['label.users.forcepwupdate']	= 'Force Password Update';
$lang['label.users.usernametype']	= "Username Storage";
$lang['label.users.storename']		= "Account Name Creation";
$lang['label.users.storeusername']	= "Username Creation";
// ----- User Tab: Form Description
$lang['desc.users.userenable']		= "This enables user integration across this connection.  To disable user integration for this connection only, set this to no.";
$lang['desc.users.loginurl']		= "When originating from this connection, and when no return url is specified through the login form, the Login URL is the final destination after completing a log in process.";
$lang['desc.users.logouturl']		= "When a request to log out has been received from this connection, the Integrator will send the user to this URL upon completion.  Be sure the URL is a publicly accessible URL that does not require a logged in user.";
$lang['desc.users.processlogin']	= "This option allows you to control when a user should be logged into this connection.  By default, if User Integration is enabled, this should be set to `Always` to allow the user to log in on this connection regardless of where they come from.  You can set this to `Only If Originating Here` to have the user log in here only when they are originating from this connection, or you can set it to Never to not allow the user to log in here.  Note that setting this to Never but allowing User Integration to remain active will not log the user in but will keep any matching accounts in sync with changes made elsewhere (passwords, email changes, usernames etc).";
$lang['desc.users.forceadd']		= "If a user logs in from another connection, but there isn't a matching account (by email address) on this connection, this setting will forcibly add a matching user account silently so that the user logs in across all your connections.  Setting this to `No` will prohibit a user that authenticates and logs in against another connection from appearing logged in on this connection.";
$lang['desc.users.forcepwupdate']	= 'This setting allows Integrator 3 to update an incorrect password on this connection if the user logging in has already authenticated against another connection.  This permits your users to remain in sync when logging.';
$lang['desc.users.usernametype']	= "This controls what form the primary username takes on this connection.  This setting for most will remain at the default setting of `Usrename`.";
$lang['desc.users.storename']		= "When a new user is created on this connection from another connection, this setting controls this connection assembles the `name` field if there isn't a specific field called `name` from the originating connection.";
$lang['desc.users.storeusername']	= "When a new user is created on another connection that doesn't utilize a `username` field, this setting will control how a new username is generated for the user on this connection.";
// ----- User Tab: Form Field Options
$lang['options.users.processlogin']		= array( 'always' => "Always", 'whenconnected' => "Only If Originating Here", 'never' => "Never" );
$lang['options.users.usernametype']		= array( 'username' => "Username", 'email' => "Email Address" );
$lang['options.users.storename']		= array( 'firstlast' => "First Last", 'firstlastco' => "First Last (Company)", 'lastfirst' => "Last, First", 'lastfirstco' => "Last, First (Company)" );
$lang['options.users.storeusername']	= array( 'first.last' => "first.last style", 'last.first' => "last.first style", 'random' => "Random username generation", 'flastname' => "flastname style", 'firstnamel' => "firstnamel style", 'firstname' => "Firstname Only", 'lastname' => "Lastname Only" );
$lang['options.users.usessl']			= array( 'none' => "Do Not Use", 'force' => "Always Use (Force)", 'ignore' => "Defer to Global Setting (Ignore)" );

// ----- Visual Tab
$lang['visuals.tab']	= "Visual Settings";
$lang['visuals.header']	= 'These settings affect the visual integration of your connection with other connections through Integrator 3.  Enabling features here may not necessarily cause the visual integration to work on this connection as other settings in the global configuration area may affect this as well.';
// ----- Visual Tab: Form Labels
$lang['label.visuals.visualenable']			= "Enable Visual Integration";
$lang['label.visuals.sslenabled']			= "SSL Enabled";
$lang['label.visuals.imgurl']				= "Image URL";
$lang['label.visuals.convertcharacterset']	= "Convert Characterset";
// ----- Visual Tab: Form Description
$lang['desc.visuals.visualenable']			= "This enables the visual integration to be performed using this connection. To disable the visual integration for this connection only, set this to no.";
$lang['desc.visuals.sslenabled']			= "If this connection has a valid SSL certificate <u>AND</u> the application this is being rendered around also has a valid SSL certificate, you can set this to yes to enable an SSL page to be rendered.  If you encounter errors or invalid certificates, set this to no.";
$lang['desc.visuals.imgurl']				= "This will typically be the same as the main connection URL.  If you don't have a valid SSL certificate on the site this connection is located, but it is being wrapped around an application that does, you can change this URL to point to a location that has a valid SSL certificate so that your pages are secure (not appearing broken).  Note that you will need to have copies of any javascript, css and images in this alternative location to utilize this ability.";
$lang['desc.visuals.convertcharacterset']	= "If the characterset from the site you are pulling from does not match the destination characterset, this setting will let the Integrator attempt to convert the site to match the destinateion application.";

// ----- Client Area Tab
$lang['clientarea.tab']	= "Clientarea Settings";
$lang['clientarea.header']	= 'These settings indicate what features from this connection you want to make visible on the clients Integrator 3 landing page.  You can disable the feature entirely or choose to display certain features.';

//
//		v 3.0.5
// -------------------------------------------------------------------
$lang['globals.multilingual']		=	'Multilingual';
$lang['desc.globals.multilingual']	=	'If this site is multilingual, you can enable this to specify different pages to be retrieved based on the user\'s selected language.  Note that if you enable or disable this after setting up your page mapping, you will need to redo your page mapping settings.';

//
//		v 3.0.8
// -------------------------------------------------------------------
$lang['globals.sslenabled']			=	'Connection Uses SSL';
$lang['globals.sslenabled.desc']	=	'If your site does not use an SSL certificate on this connection, it is best to set this to Disabled to prevent the server from hanging or causing other connectivity issues.  This setting may also be set in the Configuration > SSL Settings menu.';


// ===================================================================
// 	Connection Manager (cnxns/index)
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['cnxns.index']		= "Connection Manager";
$lang['cnxns.index.desc']	= "Add a new connection or click on an existing connection to edit or remove it entirely.";
