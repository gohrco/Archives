<?php if (! is_null( $log ) ): ?>

<div class="box">
	
	<?php echo heading ( lang( 'userlog.title' ), '2' ); ?>
	
	<table class="table table-striped table-bordered table-condensed">
		<thead>
	 		<tr>
	 			<th class="center"><i class="icon-search hasTip" data-original-title="<?php echo lang( 'logbox.hdr.link' ); ?>"></i></th>
	 			<th class="center"><i class="icon-tasks hasTip" data-original-title="<?php echo lang( 'logbox.hdr.task' ); ?>"></i></th>
	 			<th class="center"><i class="icon-envelope"></i> <?php echo lang( 'logbox.hdr.email' ); ?></th>
	 			<th class="center"><i class="icon-time"></i> <?php echo lang( 'logbox.hdr.timestamp' ); ?></th>
	 		</tr>
	 	</thead>
	 	<tbody>
	 		<?php foreach ( $log as $item ) : ?>
	 		<tr>
	 			<td rowspan="2" class="center">
	 				<?php echo ( $item->email != 'not found' ? anchor( 'usermgr/log/' . base64_encode( $item->email ), image( 'icon16-userlog.png' ), array( 'class' => 'hasTip', 'data-original-title' => "View User Log" ) ) : '' ); ?>
	 			</td>
	 			<td class="center">
	 				<span class="label label-info"><?php echo $item->task; ?></span>
	 			</td>
	 			<td class="center">
	 				<?php echo $item->email; ?>
	 			</td>
	 			<td class="center">
					<?php echo date( "M d Y  H:i T", $item->timestamp ); ?>
				</td>
			</tr>
			<tr>
				<td colspan="4">
					<?php if (! empty( $item->data ) ) :  ?>
					<ul style="font-size: 8pt; ">
					<?php foreach ( $item->data as $data ) : ?>
					<li>
						<?php echo $data; ?>
					</li>
					<?php endforeach; ?>
					</ul>
					<?php endif; ?>
				</td>
			</tr>
	 		<?php endforeach; ?>
	 	</tbody>
	</table>
	
</div>

<?php endif; ?>