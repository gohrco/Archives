<div class="span6" id="c-one">

	<?php echo $template['partials']['admin-cnxnhealth']; ?>
	
	<?php echo $template['partials']['admin-rss']; ?>
	
</div>
<div class="span6" id="c-two">
	
	<?php echo $template['partials']['admin-log']; ?>
	
	<?php echo $template['partials']['admin-stepbystep']; ?>
	
</div>