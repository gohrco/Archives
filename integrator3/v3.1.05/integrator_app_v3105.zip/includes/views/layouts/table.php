<div class="row-fluid">
	<div class="span1"> </div>
	<div class="span11">
		<?php 
		$header	= ( isset( $header ) ? $header : $action );
		
		echo heading( lang( str_replace( '/', '.', $header ) ), '3', 'class="header"' );
		
		if ( lang( str_replace( '/', '.', $header ) . '.desc' ) ) : ?>
			<div class="header-text"><?php echo lang( str_replace( '/', '.', $header ) . '.desc' ); ?></div>
		<?php endif; ?>
	</div>
</div>

<table id="dataTable" class="table table-striped">
	<thead>
		<tr>
			<?php foreach ( $cols as $col ) : ?>
			<th<?php echo isset( $col['class'] ) ? ' class="'.$col['class'].'"' : '' ?>>
				<?php echo lang( 'tblhdr.' . $col['text'] ); ?>
			</th>
			<?php endforeach; ?>
		</tr>
	</thead>
	<tbody>
		<?php foreach ( $rows as $row ) : ?>
		<tr>
			<?php foreach ( $row as $item ) : ?>
			<td<?php echo isset( $item['class'] ) ? ' class="' . $item['class'] .'"' : '' ?>>
				<?php echo $item['data']; ?>
			</td>
			<?php endforeach; ?>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>

<?php if ( isset( $buttons ) ) : ?>

<div class="row-fluid form-horizontal">
	<div class="form-actions">
		
		<?php 
		foreach ( $buttons as $button )
		{
			$type = $button->btntype; 
			unset( $button->btntype );
			
			if ( $type == 'anchor' )
			{
				$uri	= $button->uri;
				$title	= $button->title;
				unset ( $button->uri, $button->title );
				echo anchor( $uri, $title, (array) $button );
			}
			else
			{
				echo form_button( (array) $button );
			}
			echo '   ';
		}	
		?>
	</div>
</div>

<?php endif; ?>