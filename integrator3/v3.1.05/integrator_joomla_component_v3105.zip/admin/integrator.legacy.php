<?php
/**
 * Integrator 3
 * Joomla! - Legacy Handler
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.05 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This file permits Integrator 3 to operate across Joomla! versions
 *
 */


if ( version_compare( JVERSION, '3.0', 'ge' ) )
{
	if (! class_exists( 'IntegratorControllerExt' ) ) {
		class IntegratorControllerExt extends JControllerLegacy {}
	}
	if (! class_exists( 'IntegratorControllerForm' ) ) {
		class IntegratorControllerForm extends JControllerForm {}
	}
	if (! class_exists( 'IntegratorModelExt' ) ) {
		class IntegratorModelExt extends JModelLegacy {}
	}
	if (! class_exists( 'IntegratorViewExt' ) ) {
		class IntegratorViewExt extends JViewLegacy {}
	}
}
else if ( version_compare( JVERSION, '1.6', 'ge' ) )
{
	jimport('joomla.application.component.controller');
	jimport('joomla.application.component.controllerform');
	jimport('joomla.application.component.model');
	jimport('joomla.application.component.view');

	// Good ol' Joomla changing things up mid-stream
	if ( version_compare( JVERSION, '2.5.5', 'ge' ) ) {
		// For some reason this doesnt work anylonger..?
		//jimport( 'cms.view.legacy' );
		if (! class_exists( 'IntegratorViewExt' ) ) {
			// We ditched the use of the legacy view
			//class IntegratorViewExt extends JViewLegacy {}
			class IntegratorViewExt extends JView {}
		}
	} else {
		if (! class_exists( 'IntegratorViewExt' ) ) {
			class IntegratorViewExt extends JView {}
		}
	}

	if (! class_exists( 'IntegratorControllerExt' ) ) {
		class IntegratorControllerExt extends JController {}
	}
	if (! class_exists( 'IntegratorControllerForm' ) ) {
		class IntegratorControllerForm extends JControllerForm {}
	}
	if (! class_exists( 'IntegratorModelExt' ) ) {
		class IntegratorModelExt extends JModel {}
	}
}
else
{
	jimport('joomla.application.component.controller');
	jimport('joomla.application.component.model');
	jimport( 'joomla.application.component.view' );

	if (! class_exists( 'IntegratorControllerExt' ) ) {
		class IntegratorControllerExt extends JController {}
	}
	if (! class_exists( 'IntegratorControllerForm' ) ) {
		class IntegratorControllerForm extends JController {}
	}
	if (! class_exists( 'IntegratorModelExt' ) ) {
		class IntegratorModelExt extends JModel {}
	}
	if (! class_exists( 'IntegratorViewExt' ) ) {
		class IntegratorViewExt extends JView {}
	}
}