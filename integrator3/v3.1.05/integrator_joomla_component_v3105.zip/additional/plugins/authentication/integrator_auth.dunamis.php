<?php

defined('_JEXEC') or die( 'Restricted access' );

/**
 * Define the Integrator3 version here
 */
if (! defined( 'DUN_MOD_INTEGRATOR' ) ) define( 'DUN_MOD_INTEGRATOR', "3.1.05" );
if (! defined( 'DUN_MOD_INTEGRATOR_AUTH' ) ) define( 'DUN_MOD_INTEGRATOR_AUTH', "3.1.05" );


class Integrator_authDunModule extends DunModule
{
	public function initialise()
	{
		
	}
}