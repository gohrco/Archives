<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.05 ( $Id: default.php 382 2015-07-08 03:48:24Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This file contains the default controller class allowing the system to intereact with the data based upon actions
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Default controller is used to handle tasks to perform for the user by the system
 * @version		3.1.05
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntegratorControllerDefault extends IntegratorControllerExt
{
	/**
	 * Constructor
	 * @access		public
	 * @version		3.1.05
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		// Ensure our view is set properly
		IntegratorHelper :: set( 'view', 'default' );
		
		parent::__construct();
	}
	
	
	/**
	 * Login controller for allowing a user to log into Joomla from the Integrator
	 * @access		public
	 * @version		3.1.05
	 * 
	 * @since		3.0.0
	 */
	public function login()
	{
		dunloader( 'helpers', 'com_integrator' );
		$app	=	JFactory::getApplication();
		$input	=	dunloader( 'input', true );
		$model	=	$this->getModel( 'default' );
		
		$input->setVar( 'view', 'default' );
		$input->setVar( 'layout', 'default' );
		
		$remember	= $input->getVar( 'rememberme', false, 'bool' );
		$return		= $input->getVar( 'return', null );
		$username	= $input->getVar( 'username', '', 'username', 'post' );
		$password	= $input->getVar( 'passwd', $input->getVar( 'password', '', 'string', 'post', JREQUEST_ALLOWRAW ), 'string', 'post', JREQUEST_ALLOWRAW );
		
		if ( is_email( $username ) ) {
			$username	= $model->get_username( $username );
		}
		
		$options			= array('remember' => $remember, 'return' => $return, 'silent' => true, );
		$credentials		= array('username' => $username, 'password' => $password);
		
		//preform the login action
		$success	=	$app->login($credentials, $options);
		$config		=	dunloader( 'config', 'com_integrator' );
		
		jimport( "joomla.session.session" );
		$session	=   JSession::getInstance( null, array() );
		$session	=   encode_session( $session->getName(), $session->getId() );
		
		// Set Form Action
		$uri	=	DunUri :: getInstance( $config->get( "IntegratorUrl" ) );
		$usessl	=   $config->get( 'UseSSL', 'ignore' );
		$isSsl	=   ( $usessl == 'force' ? true : ( $usessl == 'none' ? false : Juri::getInstance()->isSsl() ) );
		$uri->setScheme( "http" . ( $isSsl ? "s" : "" ) );
		$uri->setPath( $uri->getPath() . "/index.php/login/" . ( $success ? "succeed" : "failed" ) . '/' );
		$action	= $uri->toString();
		
		// Create Form Fields
		$fields	= array( '_c' => $config->get( 'cnxnid' ), 'session' => $session );
		
		// Redirect
		form_redirect( $action, $fields );
	}
	
	
	/**
	 * Login Error controller when there is a problem
	 * @access		public
	 * @version		3.1.05
	 * 
	 * @since		3.0.0
	 */
	public function loginerror()
	{
		dunloader( 'input', true )->setVar( 'layout', 'loginerror' );
		return parent::display();
	}
	
	
	/**
	 * Logs a user out from the Integrator
	 * @access		public
	 * @version		3.1.05
	 * 
	 * @since		3.0.0
	 */
	public function logout()
	{
		$app		=	JFactory::getApplication();
		$app->logout();
	}
}