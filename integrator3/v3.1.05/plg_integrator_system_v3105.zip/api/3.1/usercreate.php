<?php
/**
 * Integrator 3 - System Plugin
 * 		Updateuser File
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.05 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This is the Updateuser Task which will update a given user in our Joomla site from I3
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * User Create API Class
 * @version		3.1.05
 *
 * @since		3.1.00
 * @author		Steven
 */
class UsercreateIntegratorAPI extends IntegratorAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		3.1.05
	 * 
	 * @since		3.1.00
	 * @see			IntegratorAPI :: execute()
	 */
	public function execute()
	{
		$helper	=	dunloader( 'helpers', 'com_integrator' );
		$input	=	dunloader( 'input', true );
		$config	=	dunloader( 'config', 'com_integrator' );
		$data	=	$input->getVar( 'data', array(), 'array' );
		
		
		// Create the user
		$acl			=	JFactory::getACL();
		$user			=   new JUser();
		$usersConfig	=	JComponentHelper::getParams( 'com_users' );
		
		$newUsertype = $usersConfig->get( 'new_usertype' );
		if (! $newUsertype) $newUsertype = 'Registered';
		
		// We handle groups differently in J1.6+
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$data['groups'][] = $newUsertype;
		}
		else {
			$data['gid'] = $acl->get_group_id( '', $newUsertype, 'ARO' );
		}
		
		if (! $user->bind( $data ) ) {
			return $this->error( 'USERCREATE_ERRORBIND' );
		}
		
		$date =	JFactory::getDate();
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			$user->set( 'registerDate', $date->toSql() );
		}
		else {
			$user->set('registerDate', $date->toMySQL());
		}
		
		if (! $user->save() ) {
			return $this->error( 'USERCREATE_ERRORSAVE' );
		}
		
		return $this->success( true );
	}
}