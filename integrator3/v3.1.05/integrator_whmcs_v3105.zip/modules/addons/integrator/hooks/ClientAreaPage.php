<?php

// Bail if we are in the API
if ( is_api() ) return;

// Grab the Post variables
if (! isset( $vars ) || empty( $vars ) ) {
	$vars = $_POST;
}


// If we are logging out, catch the final render to go to our desired destination
if ( get_filename() == 'logout' ) {
 	dunmodule( 'integrator.login' )->logoutredirect();
}


// Check username field to ensure we have it set
// ------------------------------------------------------------------------------
if (! is_admin() && is_loggedin() ) {
	dunloader( 'user', 'integrator', array( 'uid' => $_SESSION['uid'] ) );
}


// If we don't want to wrap our invoices then dont
if ( get_filename() == 'viewinvoice' ) {
	if ( is_loggedin() && ! dunloader( 'config', 'integrator' )->get( 'wrapinvoice', true ) ) return;
}

// See if we are logging in and if so should we redirect out?
if ( get_template_var( 'templatefile' ) == 'login' && ! is_admin() ) {
	dunmodule( 'integrator.login' )->loginredirectcheck();
}

$response	=	dunmodule( 'integrator.render' )->execute( $vars );
