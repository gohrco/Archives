<?php


$form	= array(
		'loginenable'		=> array(
				'order'			=> 10,
				'type'			=> 'toggleyn',
				'value'			=> true,
				'validation'	=> '',
				'labelon'		=> 'integrator.form.toggleyn.enabled',
				'labeloff'		=> 'integrator.form.toggleyn.disabled',
				'label'			=> 'integrator.admin.form.settings.label.loginenable',
				'description'	=> 'integrator.admin.form.settings.description.loginenable',
				),
		'loginmethod'		=> array(
				'order'			=> 20,
				'type'			=> 'togglebtn',
				'value'			=> '',
				'validation'	=> '',
				'options'		=> array(
						array( 'id' => 0, 'name' => 'integrator.loginmethod.0.integrator' ),
						array( 'id' => 1, 'name' => 'integrator.loginmethod.1.whmcs' ),
						array( 'id' => 2, 'name' => 'integrator.loginmethod.2.customurl' ),
				),
				'label'			=> 'integrator.admin.form.settings.label.loginmethod',
				'description'	=> 'integrator.admin.form.settings.description.loginmethod'
		),
		'loginmethodoptn0'	=> array(	'order'	=> 21, 'class'	=> 'well well-small', 'type'	=> 'wrapo' ),
		'loginmethod_cnxn_id'	=> array(	'order'	=> 22, 'type'	=> 'cnxnlist',
				'value'			=> '',
				'label'			=> 'integrator.loginmethod_cnxn_id.label',
				'description'	=> 'integrator.loginmethod_cnxn_id.desc',
				'target'		=> 'loginmethod_page',
		),
		'loginmethod_page'		=> array(	'order'	=> 23, 'type'	=> 'dropdown',
				'value'			=> '',
				'label'			=> 'integrator.loginmethod_page.label',
				'description'	=> 'integrator.loginmethod_page.desc'
		),
		'loginmethodoptn0c'	=> array(	'order'	=> 24,	'type'	=> 'wrapc' ),
		'loginmethodoptn2'	=> array(	'order'	=> 27, 'class'	=> 'well well-small', 'type'	=> 'wrapo' ),
		'loginmethod_customurl'=> array(	'order'	=> 28,	'type'	=> 'text',
				'value'			=> null,
				'label'			=> 'integrator.loginmethod_customurl.label',
				'description'	=> 'integrator.loginmethod_customurl.desc',
		),
		'loginmethodoptn2c'	=> array(	'order'	=> 29, 'type'	=> 'wrapc' ),
		'loginhandlessl'		=> array(
				'order'			=> 30,
				'type'			=> 'togglebtn',
				'value'			=> '',
				'validation'	=> '',
				'options'		=> array(
						array( 'id' => 0, 'name' => 'integrator.loginhandlessl.none' ),
						array( 'id' => 1, 'name' => 'integrator.loginhandlessl.force' ),
						array( 'id' => 2, 'name' => 'integrator.loginhandlessl.defer' ),
				),
				'label'			=> 'integrator.loginhandlessl.label',
				'description'	=> 'integrator.loginhandlessl.desc'
		),
		'logouturl'		=> array(
				'order'			=> 30,
				'type'			=> 'text',
				'value'			=> null,
				'validation'	=> '',
				'label'			=> 'integrator.admin.form.settings.label.logouturlfield',
				'description'	=> 'integrator.admin.form.settings.description.logouturlfield',
		),
		
	);
