<?php


/* ========================================================================= *\
 * GENERAL TRANSLATION STRINGS
\* ========================================================================= */

// -------------------------------------------------------------------------
// Alert Titles
// v3.1.00
$lang['alert.success']		= 'Success!';
$lang['alert.error']		= 'An Error Occurred!';
$lang['alert.info']			= 'Reminder:';
$lang['alert.block']		= 'Warning!';

// v3.1.00
$lang['alert.dunamis.compatible']	=	'The version of Dunamis you are using is not compatible with this version of Integrator 3.  Please upgrade Dunamis before proceeding.';


// -------------------------------------------------------------------------
// Alert Messages
// v3.1.00
$lang['alert.settings.saved']					=	'Settings have been saved!';
$lang['alert.settings.autoautkeynotwritable']	=	'Integrator 3 was unable to write the autoauthkey to your configuration file!  You will need to manually update your WHMCS configuration file to include the value for the AutoAuth key.  For more information, please visit our forum.';


// -------------------------------------------------------------------------
// Error Messages
// v3.1.00
$lang['error.apicnxn.nourl']		=	'You must set the URL to Integrator 3!';
$lang['error.apicnxn.notoken']		=	'You must set the API Token to connect to Integrator 3!';

// -------------------------------------------------------------------------
// Form Buttons
// v3.1.00
$lang['form.submit']				= 'Submit';
$lang['form.close']					= 'Close';
$lang['form.cancel']				= 'Cancel';
$lang['form.edit']					= 'Edit';
$lang['form.delete']				= 'Delete';
$lang['form.toggleyn.enabled']		= 'Enabled';
$lang['form.toggleyn.disabled']		= 'Disabled';
$lang['form.toggleyn.on']			= 'On';
$lang['form.toggleyn.off']			= 'Off';
$lang['form.button.addnew']			= 'Add New';


/* ========================================================================= *\
 * BACKEND TRANSLATION STRINGS - GENERAL
\* ========================================================================= */

// -------------------------------------------------------------------------
// Configuration Strings
// v3.1.00
$lang['addon.title']		= 'Integrator 3';
$lang['addon.author']		= '<div style="text-align: center; width: 100%; ">Go Higher<br/>Information Services, LLC</div>';
$lang['addon.description']	= '<div>Premium integration on demand solutions<br/> Be sure to activate the Dunamis Framework before activating Integrator 3!</div>';


/* ========================================================================= *\
 * BACKEND TRANSLATION STRINGS - ADDON AREA
\* ========================================================================= */

// -------------------------------------------------------------------------
// Default Area
// v3.1.00
$lang['admin.default.body']		=	'<h2>Integrator 3</h2>'
								.	'<p>If this is the first time you have installed version 3.1 of Integrator 3 into your WHMCS application, be sure you have completely followed the instructions found at<br /><strong><a href="https://support.gohigheris.com/docs/display/INT3/Quick+Start+Guide" target="_blank">https://support.gohigheris.com/docs/display/INT3/Quick+Start+Guide</a></strong>.</p>'
								/*.	'<p>The next steps to folow at this point are <ul>'
								.	'<li><i class="icon-hang icon-ok"></i> <a href="https://support.gohigheris.com/docs/display/J25/Create+An+API+User+in+WHMCS" target="_blank">Create An API User in WHMCS</a></li>'
								.	'<li><i class="icon-hang icon-ok"></i> <a href="https://support.gohigheris.com/docs/display/J25/Granting+API+Access+to+WHMCS" target="_blank">Granting API Access to WHMCS</a></li>'
								.	'<li><i class="icon-hang icon-ok"></i> <a href="https://support.gohigheris.com/docs/display/J25/Add+or+Change+Your+License" target="_blank">Add or Change Your J!WHMCS License</a></li>'
								.	'<li><i class="icon-hang icon-ok"></i> <a href="https://support.gohigheris.com/docs/display/J25/Setup+the+Shared+API+Token" target="_blank">Setup The Shared API Token</a></li>'
								.	'<li><i class="icon-hang icon-ok"></i> <a href="https://support.gohigheris.com/docs/display/J25/API+Connection+Manager+in+Joomla" target="_blank">API Connection Manager in Joomla</a></li>'
								.	'</ul>'
								.	'<h2>How To Guides</h2>'
								.	'<p>Some additional help in configuring J!WHMCS Integrator to work with WHMCS and Joomla is available in our documentation: <ul>'
								.	'<li><i class="icon-hang icon-ok"></i> <a href="https://support.gohigheris.com/docs/display/J25/Add+or+Change+Your+License" target="_blank">Add or Change Your License</a></li>'
								.	'<li><i class="icon-hang icon-ok"></i> <a href="https://support.gohigheris.com/docs/display/J25/Create+An+API+User+in+WHMCS" target="_blank">Create An API User in WHMCS</a></li>'
								.	'<li><i class="icon-hang icon-ok"></i> <a href="https://support.gohigheris.com/docs/display/J25/Granting+API+Access+to+WHMCS" target="_blank">Granting API Access to WHMCS</a></li>'
								.	'<li><i class="icon-hang icon-ok"></i> <a href="https://support.gohigheris.com/docs/display/J25/Setup+the+Shared+API+Token" target="_blank">Setup the Shared API Token</a></li>'
								.	'<li><i class="icon-hang icon-ok"></i> <a href="https://support.gohigheris.com/docs/display/J25/Use+a+custom+template+directory" target="_blank">Use a custom template directory</a></li>'
								.	'</ul>'*/
								.	'';


// -------------------------------------------------------------------------
// Addon Titles
// v3.1.00
$lang['admin.title']						=	'Integrator 3 <small>%s</small>';
$lang['admin.subtitle.default.default']		=	'Dashboard';
$lang['admin.subtitle.settings.default']	=	'Settings';
$lang['admin.subtitle.settings.save']		=	'Settings :: Save Settings';
$lang['admin.subtitle.updates.default']		=	'Update Manager';
$lang['admin.subtitle.syscheck.default']	=	'System Check';


// -------------------------------------------------------------------------
// Navigation Strings
// v3.1.00
$lang['admin.navbar.default']	=	'Dashboard';
$lang['admin.navbar.syscheck']	=	'System Check';
$lang['admin.navbar.settings']	=	'Settings';
$lang['admin.navbar.updates']	=	'Updates';


// -------------------------------------------------------------------------
// Widget Strings - API Cnxn
// v3.1.00
$lang['admin.widget.apicnxn.header']		=	'API Connection Status';
$lang['admin.widget.apicnxn.body.error']	=	'<p>An error was encountered attempting to connect to Integrator 3!  The error returned was:</p><p>%s</p>';
$lang['admin.widget.apicnxn.body.success']	=	'The API interface tested successfully!';

// Widget Strings - Updates
// v3.1.00
$lang['admin.widget.updates.header']		= 'Software Updates v%s';
$lang['admin.widget.updates.body.none']		=	'<p>You are running the latest version of Integrator 3!</p>';
$lang['admin.widget.updates.body.error']	=	'<p>An error occurred checking for the latest updates:</p><pre>%s</pre>';
$lang['admin.widget.updates.body.exist']	=	'<p><strong>Integrator 3 version %s</strong> is available for download.  Please visit our web site at https://www.gohigheris.com to download the latest product.</p>';

// Widget Strings - File Check
$lang['admin.widget.filecheck.header']		= 'Template File Status';
$lang['admin.widget.filecheck.body.success']	=	'<p>Files are current!</p>';
$lang['admin.widget.filecheck.body.alert']		=	'<p>One or more of your template files is out of date - please correct this by going to the System Check screen</p>';

// Widget Strings - Like Us
// v3.1.00
// $lang['admin.widget.likeus.header']			=	'';
// $lang['admin.widget.likeus.body']				=	'<p>If you find Integrator 3 useful please tell others about it by visiting the <a href="http://www.whmcs.com/appstore/145/JWHMCS-Integrator.html" target="_blank">WHMCS App Store</a> and <a href="http://www.whmcs.com/members/communityaddons.php?action=viewmod&id=145&vote=true&token=f67e6d896ec5c21bd0248570ac3671ebe6480106" target="_blank">liking</a> the product!</p>';

// -------------------------------------------------------------------------
// Settings Strings
// v3.1.00
//-------------------------------------------------------------------------[ GENERAL SETTINGS ]
$lang['admin.settings.subnav.general']	=	'<i class="icon-off"> </i> <strong>General Settings</strong>';
$lang['admin.settings.subnav.user']		=	'<i class="icon-user"> </i> <strong>User Integration</strong>';
$lang['admin.settings.subnav.visual']	=	'<i class="icon-eye-open"> </i> <strong>Visual Integration</strong>';
$lang['admin.settings.subnav.login']	=	'<i class="icon-retweet"> </i> <strong>Log In Settings</strong>';
$lang['admin.settings.subnav.language']	=	'<i class="icon-globe"> </i> <strong>Language Map</strong>';
$lang['admin.settings.subnav.pages']	=	'<i class="icon-file"> </i> <strong>Page / CSS Settings</strong>';
$lang['admin.settings.subnav.advanced']	=	'<i class="icon-wrench"> </i> <strong>Advanced Settings</strong>';

$lang['admin.form.settings.label.enable']			=	'Enabled';
$lang['admin.form.settings.label.debug']			=	'Debug';
$lang['admin.form.settings.label.integratorurl']	=	'Integrator URL';
$lang['admin.form.settings.label.apitoken']			=	'Secret Token';
$lang['admin.form.settings.label.cnxnid']			=	'Connection ID';

$lang['admin.form.settings.description.enable']		=	'This is the global enable configuration setting.  Turning the product off here turns off both user and visual integration regardless of their settings.';
$lang['admin.form.settings.description.debug']		=	'Use this setting to enable or disable debugging for the module.';
$lang['admin.form.settings.description.integratorurl']	=	'Enter the URL to the frontend of your Integrator 3 application.';
$lang['admin.form.settings.description.apitoken']	=	'<p>The Secret Token is used by Integrator 3 to communicate between WHMCS and the Integrator 3 application.  To find what the secret token is, log into your Integrator 3 application, then click on the Settings drop down menu and select API Settings.  You will see a value for the `API Secret Key`; enter that value in the Secret Token field.</p><p><strong>NOTE: If you have previously used an autoauth key in your configuration file for WHMCS, then THIS WILL BE THE SAME VALUE!  Changing this value will update your configuration.php file as well to reflect the change.</strong></p>';
$lang['admin.form.settings.description.cnxnid']		=	'<p>The Connection ID corresponds to the ID assigned to this connection within your Integrator 3 application.  To find it, log into your Integrator 3 application, then click on the Connections drop down menu and select this connection.  At the bottom of the general settings section you will see a greyed out field corresponding to the Connection ID.  Enter that value here.</p>';


//-------------------------------------------------------------------------[ USER SETTINGS ]
$lang['admin.form.settings.label.userenable']			=	'Enable User Integration';
$lang['admin.form.settings.description.userenable']		=	'This setting will enable or disable user integration from the WHMCS side of the product.';

$lang['admin.form.settings.label.useraddmethod']		=	'Add Missing Users To';
$lang['admin.form.settings.description.useraddmethod']	=	'This setting controls the behavior of J!WHMCS Integrator when dealing with users that don\'t have a matching account already in both systems when logging in and editing accounts.  When editing an account in Joomla and adding a matching account in WHMCS, the user will still need to log in with their Joomla username for the first time in order to synchronize the passwords properly.';
$lang['useraddmethod.0.none']		=	'Neither System';
$lang['useraddmethod.1.jonly']		=	'Joomla! only but not WHMCS';
$lang['useraddmethod.2.wonly']		=	'WHMCS only but not Joomla!';
$lang['useraddmethod.4.both']		=	'Both Joomla! and WHMCS';

$lang['admin.form.settings.label.regmethod']			=	'Registration Method';
$lang['admin.form.settings.description.regmethod']		=	'<p>Select the method of registration you want to use on your site.  You may select to use the native WHMCS registration form or to send new registrants over to Integrator 3 to decide</p>';
$lang['register_page.label']							=	'Integrated Page';

$lang['register_cnxn_id.label']		=	'Select Connection';
$lang['register_page.label']		=	'Select Page';
$lang['register_customurl.label']	=	'Enter URL';
$lang['register_cnxn_id.desc']		=
$lang['register_page.desc']			=	'';
$lang['register_customurl.desc']	=	'Be sure the URL you enter is Fully Qualified (ie includes http)';

$lang['regmethod.0.integrator']	=	'Use Integrated Page for Registration';
$lang['regmethod.1.whmcs']		=	'Use WHMCS';
$lang['regmethod.2.customurl']	=	'Use Custom URL';

$lang['userfield.label']								=	'Username Field';
$lang['userfield.desc']									=	'<p>WHMCS does not by design utilize usernames separate from email addresses, however many applications do use a username in addition to the email address.  You may select a custom client field here to pass along when user updates are done and to store usernames set by other systems, permitting your customers to edit their username within the WHMCS interface.  Note that the username in WHMCS may not be used to log into WHMCS, as WHMCS still requires an email address and password to log into the WHMCS application itself.</p>';

$lang['clientclose.label']		=	'Client Closure';
$lang['clientclose.desc']		=	'When a client\'s account is closed in WHMCS (closed not deleted), this setting dictates how any integrated accounts on other applications are treated.  Should they simply be disabled or deleted?';
$lang['clientclose.delete']		=	'Delete';
$lang['clientclose.disable']	=	'Disable';


//-------------------------------------------------------------------------[ VISUAL SETTINGS ]
$lang['admin.form.settings.label.visualenable']				=	'Enable Visual Integration';
$lang['admin.form.settings.label.imageurl']					=	'Custom URL';
$lang['admin.form.settings.label.menuitem']					=	'Menu Item';
$lang['admin.form.settings.label.resetcss']					=	'Reset CSS';
$lang['admin.form.settings.label.shownavbar']				=	'Show Navigation Bar';
$lang['admin.form.settings.label.showfooter']				=	'Show Footer';

$lang['admin.form.settings.description.visualenable']		=	'This setting will enable or disable the visual integration from the WHMCS side of the product.';
$lang['admin.form.settings.description.imageurl']			=	'Enter a full URL to repoint all images, css and javascript to.  This is useful in the event you have an SSL certificate on WHMCS, but not on Joomla, you can enter an URL that would be on the WHMCS location and copy the files into place.';
$lang['admin.form.settings.description.menuitem']			=	'Select a menu item from the drop down list to retrieve from Joomla.';
$lang['admin.form.settings.description.resetcss']			=	'Enable the reset.css to revert any template changes made by your Joomla template so the WHMCS css work as expected.';
$lang['admin.form.settings.description.shownavbar']			=	'Enable this setting to allow for the navigation bar that is included in the `default` template to be displayed when wrapping the default template.  Note this only applies to the default template, not the portal or classic templates.';
$lang['admin.form.settings.description.showfooter']			=	'Enable this setting to display the footer bar at the bottom of your templates.  The footer includes the language selection dropdown box as well as the `copyright` notice.';

$lang['customimageurl.label']	=	"URL for Images / CSS / JS";
$lang['customimageurl.optn.joomla']	=	"Use Joomla URL";
$lang['customimageurl.optn.custom']	=	"Use Custom URL";

$lang['admin.form.settings.label.jqueryenable']				=	'Enable jQuery';
$lang['admin.form.settings.description.jqueryenable']		=	'Turn this on to enable the inclusion of the jQuery library from WHMCS.  By default WHMCS needs jQuery and does include it, however your Joomla template may already include a jQuery library in it which can cause javascript problems.  Typically you would disable this if you are running Joomla! 3 or a YooTheme template which includes jQuery by default.';

$lang['admin.form.settings.label.passalonguseragent']		=	'Pass User Agent';
$lang['admin.form.settings.description.passalonguseragent']	=	'Some systems require the user agent to be passed along to identify the client properly.  Set this to enable in order to pass your clients reported user agent along to your Joomla installation for visual rendering purposes.  If the client isn\'t reporting a user agent for some reason, then `Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13` will be used as the default.';

$lang['admin.form.settings.label.wrapinvoice']			=	'Wrap Invoice';
$lang['admin.form.settings.description.wrapinvoice']	=	'Enable this option to wrap your invoices with your Joomla site.';

$lang['admin.form.settings.label.bootstrapenable']	=	'Bootstrap Usage (v6)';
$lang['admin.form.settings.description.bootstrapenable']	=	'Since two bootstrap javascript libraries can conflict with one another, this option permits you to choose to use the bootstrap library in Joomla (if loaded by Joomla), the library used by WHMCS, or to do nothing and allow both to run simultaneously.  It is recommended to use the library out of WHMCS to ensure your application will work properly.';
$lang['bootstrapenable.optn.none']						=	'Do Nothing';
$lang['bootstrapenable.optn.joomla']					=	'Use Bootstrap from Wrapper';
$lang['bootstrapenable.optn.whmcs']						=	'Use WHMCS\'s Bootstrap';

$lang['enableresizejs.label']							=	'Enable Responsive Resize';
$lang['enableresizejs.desc']							=	'<p>Integrator 3 is using a javascript routine that dynamically adjusts the css for WHMCS elements based on the available width of the container.  This javascript however may cause unnecessary jumps or may not look properly in some situations.  You can disable the resize capability be disabling this option and to reverting to standard media query css calls for responsiveness in WHMCS.</p>';

//-------------------------------------------------------------------------[ LOGIN SETTINGS ]
$lang['admin.form.settings.label.loginenable']				=	'Enable Login Integration';
$lang['admin.form.settings.label.logouturlfield']			=	'Logout Landing URL';

$lang['admin.form.settings.description.loginenable']		=	'This setting will enable or disable the capability to log the user into both Joomla and WHMCS when logging in from WHMCS.';
$lang['admin.form.settings.description.logouturlfield']		=	'Specify the URL you would like users to return to when logging out through WHMCS.';

$lang['loginhandlessl.label']	=	'Login / Logout SSL';
$lang['loginhandlessl.desc']	=	'<p>When a user is logging into or out of your WHMCS application, they will get redirected off to Integrator 3 for further processing.  This setting indicates to Integrator 3 if you want to force the rest of the login / logout process to be in SSL, or if you want to force it to not use ssl, or to defer to the current ssl state (ie if the customer is on WHMCS in SSL, then use SSL, else dont use SSL)</p>';
$lang['loginhandlessl.none']	=	'No SSL';
$lang['loginhandlessl.force']	=	'Force SSL';
$lang['loginhandlessl.defer']	=	'Defer to Current State';

// v3.1.04
$lang['admin.form.settings.label.loginmethod']			=	'Log In Method';
$lang['admin.form.settings.description.loginmethod']	=	'<p>You can select to use a login form from another Integrated page for handling all logins, use the default WHMCS log in form or push login requests to a custom URL entirely.</p>';
$lang['loginmethod_page.label']							=	'Integrated Page';

$lang['loginmethod_cnxn_id.label']		=	'Select Connection';
$lang['loginmethod_page.label']			=	'Select Page';
$lang['loginmethod_customurl.label']	=	'Enter URL';
$lang['loginmethod_cnxn_id.desc']		=
$lang['loginmethod_page.desc']			=	'';
$lang['loginmethod_customurl.desc']		=	'Be sure the URL you enter is Fully Qualified (ie includes http)';

$lang['loginmethod.0.integrator']	=	'Use Integrated Page for Logging In';
$lang['loginmethod.1.whmcs']		=	'Use WHMCS';
$lang['loginmethod.2.customurl']	=	'Use Custom URL';


//-------------------------------------------------------------------------[ PAGES SETTINGS ]
$lang['pages.label']	=	'Pages';
$lang['pages.desc']		=	'';

$lang['customcss.label']	=	'Custom CSS';
$lang['customcss.desc']		=	'<p>Enter any custom css you would like to include to correct for your wrapper.  This is useful if for instance a rule from Joomla is breaking the appearance of something in WHMCS.</p>';


//-------------------------------------------------------------------------[ ADVANCED SETTINGS ]
//--
$lang['admin.form.settings.label.preservedb']				=	'Preserve Settings';
$lang['admin.form.settings.description.preservedb']			=	'Set this to Enabled to ensure if your product is ever deactivated through the WHMCS > Addon Manager that the database settings will be preserved.  This is advised if you ever allow third party support staff to troubleshoot problems on your WHMCS application.';

// v2.5.8
$lang['admin.form.settings.label.parseheadlinebyline']			=	'Parse Head Line by Line';
$lang['admin.form.settings.description.parseheadlinebyline']	=	'Set this to parse the head of your Joomla document line by line (slightly slower but more accurate)';
$lang['admin.form.settings.label.forceapitoget']				=	'Force API to GET';
$lang['admin.form.settings.description.forceapitoget']			=	'Some servers are configured in such a way that POST, PUT and DELETE requests cannot be processed properly.  This setting will force all API calls from WHMCS to Joomla to use the GET method.  This is not ideal, as any sensitive data used is exposed via the URL, however for most users this should not be a concern.';

// v2.5.11
$lang['admin.form.settings.label.dlid']			=	'Download ID';
$lang['admin.form.settings.description.dlid']	=	'This is the Download ID available from our web site.  Simply retrieve it and enter it here for the update feature to work.  You must have an active J!WHMCS Integrator license to be able to download updates.';

// v2.5.16
$lang['admin.form.settings.label.apiuser']			=	'API Administrator';
$lang['admin.form.settings.description.apiuser']	=	'Select an API Administrator from this drop down to use for calls to the local WHMCS interface.  You can create a custom administrator for this purpose only to audit tasks done by J!WHMCS, but most simply use the default administrator account.';

// v2.6.00
$lang['admin.form.settings.label.buttonfix']		=	'Button Fix';
$lang['admin.form.settings.description.buttonfix']	=	'For some templates from Joomla, the default action of certain buttons such as the cpanel login button is disabled.  This button fix option allows you to apply a simple javascript to correct this for WHMCS rendered buttons.';
$lang['autofixfile.label']							=	'Auto Fix Files';
$lang['autofixfile.desc']							=	'<p>When upgrading your Integrator 3 module, there are usually template files that need to be corrected.  Enabling this setting will automatically fix the template files when you visit the Setup > Addon Modules menu after updating your Integrator 3 addon module.</p>';

// -------------------------------------------------------------------------
// Updates
// v2.5.0
$lang['updates.checking.title']		=	"Checking for Updates";
$lang['updates.checking.subtitle']	=	"Please wait...";

$lang['updates.none.title']		=	"Check Complete";
$lang['updates.none.subtitle']	=	"Your version %s is the latest release";

$lang['updates.exist.title']	=	"Updates Found!";
$lang['updates.exist.subtitle']	=	"Click to update";

$lang['updates.init.title']		=	"Downloading Update";
$lang['updates.init.subtitle']	=	"Downloading version %s...";

$lang['updates.download.title']		=	"Installing Update";
$lang['updates.download.subtitle']	=	"Installing version %s...";

$lang['updates.complete.title']		=	"Upgrade Complete!";
$lang['updates.complete.subtitle']	=	"Version %s installed";


// -------------------------------------------------------------------------
// System Check
// v2.5.0
$lang['install.file.error.read']	=	'There was a problem reading the %s file';
$lang['install.file.error.version']	=	'Unable to determine the version of the %s file';
$lang['install.file.error.newer']	=	'%s is newer than %s';
$lang['install.file.jwhmcs']		=	'the Integrator 3 template file';
$lang['install.file.template']		=	'the template file currently being used';

$lang['syscheck.general.supported.yes']	=	'Supported';
$lang['syscheck.general.supported.no']	=	'Not Supported';
$lang['syscheck.general.yesno.yes']		=	'Yes';
$lang['syscheck.general.yesno.no']		=	'No';
$lang['syscheck.general.attention']		=	'Attention: ';
$lang['syscheck.general.fixit']			=	'Correct';


$lang['syscheck.tblhdr.whmcs']		=	'<h4>WHMCS System Check</h4>';
$lang['syscheck.tbldata.whmcs.version']		=	'%s Version';
$lang['syscheck.tbldata.whmcs.sslenabled']	=	'%s SSL Enabled';
$lang['syscheck.tbldata.whmcs.template']	=	'%s System Template';
$lang['syscheck.tbldata.whmcs.urlproper']	=	'%s URLs Proper';

$lang['syscheck.version.help']		=	' The version of Integrator 3 you are running does not explicitly support the version of WHMCS you are running.  If you have recently upgraded WHMCS, you will need to check for an update from Go Higher for the Integrator 3 to ensure any changes in the system API will work with Integrator 3.';
$lang['syscheck.sslenabled.help']	=	' Integrator 3 has determined that you are not using SSL on your system.  If you are in fact using SSL but haven\'t changed your System URLs in the WHMCS settings to allow for the system to operate in SSL mode, then this will cause problems when wrapping your Joomla site around WHMCS.  If you don\'t have an SSL certificate';
$lang['syscheck.template.help']		=	' The template you have selected in the WHMCS settings is not a supported template.  You will need to change your settings in the WHMCS General Settings area to one of the standard template types from WHMCS - Classic, Default or Portal.';
$lang['syscheck.urlmix.help']		=	' Integrator 3 has determined that the System URL and the System SSL URL set in your WHMCS General Settings are not using the same host name.  This can pose problems for the user and log in integration tasks, as WHMCS is very specific about which hostname a user is logged in on (for example, a user logged in at www.yourdomain.com will not be seen as logged in on yourdomain.com, only www.yourdomain.com).';

// v2.5.4
$lang['syscheck.template.info']		=	'The template you have selected in the WHMCS settings is setup to be supported by Integrator 3, however you will need to keep in mind that updates to WHMCS will require additional steps to be taken to ensure your templates remain current.';


$lang['syscheck.tblhdr.env']			=	'<h4>Environment Check</h4>';
$lang['syscheck.tbldata.env.curl']			=	'%s Curl Support';
$lang['syscheck.tbldata.env.iconv']			=	'%s iconv Found';
$lang['syscheck.tbldata.env.mbdetect']		=	'%s Multibyte';
$lang['syscheck.tbldata.env.phpvers']		=	'%s PHP Version';

$lang['syscheck.curl.help']			=	' The Client URL Library (curl) could not be found in your environment.  You must compile your PHP with curl in order for Integrator 3 to operate properly.';
$lang['syscheck.iconv.help']		=	' Integrator 3 was unable to locate the iconv function which is used to transliterate a Joomla site to match your WHMCS character encoding.  This may not be a big deal if you are using ISO-8895-1 or UTF-8 in WHMCS, but for any other character encoding you will want to build php with this capability.';
$lang['syscheck.mbdetect.help']		=	' Integrator 3 was unable to locate the multibyte string functionality needed to transliterate a Joomla site to match your WHMCS character encoding.  This may not be a big deal if you are using ISO-8895-1 or UTF-8 in WHMCS, but for any other character encoding you will want to build php with this capability.';
$lang['syscheck.phpvers.help']		=	' You must use PHP version 5.2 or higher!';


$lang['syscheck.tblhdr.api']		=	'<h4>API Check</h4>';
$lang['syscheck.tbldata.api.apiurl']	=	'%s API URL';
$lang['syscheck.tbldata.api.apifound']	=	'%s URL Found';
$lang['syscheck.tbldata.api.token']		=	'%s Token Set';
$lang['syscheck.tbldata.api.tokenauth']	=	'%s Token Valid';

$lang['syscheck.apiurl.help']		=	' You haven\'t set a value for the Integrator URL yet in the settings for Integrator 3.  Please click on Settings above to do so now.';
$lang['syscheck.apifound.help']		=	' The API attempted to verify the URL you entered in your settings and received this message back: %s';
$lang['syscheck.token.help']		=	' You haven\'t set a Token yet in the settings for Integrator 3.  Please click on Settings above to do so now.';
$lang['syscheck.tokenauth.help']	=	' The API attempted to verify the token and authorize access to Joomla but received this message back from Joomla: %s';

$lang['syscheck.tblhdr.files']		=	'<h4>File Check</h4>';

// v2.5.11
$lang['syscheck.general.fixall']	=	'Correct All';


/* ========================================================================= *\
 * FRONTEND TRANSLATION STRINGS
\* ========================================================================= */
//
// -------------------------------------------------------------------------
// Control Panel Screen
// v2.5.3
$lang['client.pagetitle']		=	'J!WHMCS Integrator';

$lang['client.pagedesc.cp']		=	'Client Check Screen';
$lang['client.breadcrumb.cp']	=	'J!WHMCS Integrator: Client Check Screen';

$lang['client.pagedesc.checkinstall']	=	'Check Install';
$lang['client.breadcrumb.checkinstall']	=	'J!WHMCS Integrator: Check Install';

$lang['client.pagedesc.checkrender']	=	'Check Render';
$lang['client.breadcrumb.checkrender']	=	'J!WHMCS Integrator: Check Render';





// Handles the admin translations
$intlang = array(
	'admin_outputhdr'	=> 'Health Check',
	'admin_labelcnxn'	=> 'Connection Made',
	'admin_labelsets'	=> 'Settings Updated',
	'admin_msg01'		=> 'Connection made successfully!',
	'admin_msg02'		=> 'Settings have been updated!',
	'admin_err01'		=> '.  Please check your settings and try again',
	'admin_err02'		=> 'Connection settings must be valid',
	'admin_err03'		=> 'Message received: %s',
	
	// Configuration area translations
	'cfg_name'			=> 'Integrator 3.0',
	'cfg_desc'			=> 'This module integrates your WHMCS application with other 3rd party CMS sites and applications such as Joomla.',
	
	'cfg_enablelabel'	=> 'Globally Enabled',
	'cfg_enabledesc'	=> 'This is a global override setting.  Setting this to disabled will disable all aspects of the Integrator on this application.',
	
	'cfg_debuglabel'	=> 'Debug Enabled',
	'cfg_debugdesc'		=> 'Turning debug on is useful for figuring out why the integration isn\'t working.',
	
	'cfg_userenlabel'	=> 'User Integration Enabled',
	'cfg_userendesc'	=> 'If you want your users to be able to log in throughout your whole site set this to Yes.  This setting will not affect the visual rendering portion of the application.',
	
	'cfg_visenlabel'	=> 'Visual Rendering Enabled',
	'cfg_visendesc'		=> 'If you want to visually integrate your application with your CMS, (wrap WHMCS) then set this to Yes.  This setting will not affect the user integration portion of the application.',
	
	'cfg_inturllabel'	=> 'Integrator URL',
	'cfg_inturldesc'	=> 'Please enter the URL to your installation of the Integrator application.  Only include the base path, such as `http://yourdomain.com/integrator`, do not include filenames.',
	
	'cfg_apiuserlabel'	=> 'Integrator Username',
	'cfg_apiuserdesc'	=> 'Enter the API Username for the Integrator (set in the Integrator).',
	
	'cfg_apipasslabel'	=> 'Integrator Password',
	'cfg_apipassdesc'	=> 'Enter the API Password for the Integrator (set in the Integrator)',
	
	'cfg_apisecretlabel'	=> 'API Secret Key',
	'cfg_apisecretdesc'		=> 'Enter the API Secret Key you have in your Integrator application.  This is used for security purposes between these two connections, and it is highly advisable to be unique.  <strong>Never give out the API Secret Key!</strong>.',
	
	'cfg_cnxnlabel'		=> 'Connection ID',
	'cfg_cnxndesc'		=> 'If you happen to know what the connection ID is that you set in the Integrator, you can set it here.  Otherwise, when you check your settings it will update it for you, so nothing is required to be entered here.',
	
	'cfg_usessllabel'	=> 'Use SSL',
	'cfg_usessldesc'	=> 'If you have an SSL certificate on the domain your Integrator is located, you can use SSL here.  To not use SSL, specify `Never`, to force SSL always, select `Force Always` and to defer to the current scheme, select `Ignore`.',
	
	'cfg_regmethodlabel'	=> 'Registration Method',
	'cfg_regmethoddesc'		=> 'Select the method of registration you want to use.  You can use the Integrated method found in the Integrator 3 application, or the WHMCS registration method (if enabled).',
	
	'cfg_wrapinvlabel'	=>	'Wrap Invoice',
	'cfg_wrapinvdesc'	=>	'Toggle this to Yes to enable I3 to wrap your invoices and quotes on the front end.',
	
);

$intlang["err01"] = "Login Details Incorrect. Please try again.";
?>