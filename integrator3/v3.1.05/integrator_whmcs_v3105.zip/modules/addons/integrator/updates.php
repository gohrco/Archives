<?php defined('DUNAMIS') OR exit('No direct script access allowed');
/**
 * Integrator 3 - Updates Module Base File
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.05 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This file handles the updates for the product
 *
 */


/**
 * Updates Module Class for Integrator 3
 * @version		3.1.05
 *
 * @author		Steven
 * @since		3.1.00
 */
class IntegratorUpdatesDunModule extends IntegratorAdminDunModule
{
	/**
	 * Provide means to check for file integrity
	 * @access		protected
	 * @var			string
	 * @since		3.1.00
	 */
	protected $checkstring	=	"@checkString@";
	
	
	/**
	 * Initialise the object
	 * @access		public
	 * @version		3.1.05
	 *
	 * @since		3.1.00
	 * @see			IntegratorAdminDunModule :: initialise()
	 */
	public function initialise()
	{
		$this->action = 'updates';
		parent :: initialise();
	}
	
	/**
	 * Method to execute tasks
	 * @access		public
	 * @version		3.1.05
	 * 
	 * @since		3.1.00
	 */
	public function execute() { }
	
	
	/**
	 * Method to render back the view
	 * @access		public
	 * @version		3.1.05
	 * 
	 * @return		string containing formatted output
	 * @since		3.1.00
	 */
	public function render( $data = null )
	{
		load_bootstrap( 'integrator' );
		
		$data	= $this->buildBody();
		
		return parent :: render( $data );
	}
	
	
	/**
	 * Builds the body of the action
	 * @access		public
	 * @version		3.1.05
	 * 
	 * @return		string containing html formatted output
	 * @since		3.1.00
	 */
	public function buildBody()
	{
		$doc	=	dunloader( 'document', true );
		$doc->addStylesheet( get_baseurl( 'integrator' ) . 'assets/css/updates.css' );
		$doc->addScript( get_baseurl( 'integrator' ) . 'assets/js/updates.js' );
		$doc->addScriptDeclaration( "jQuery.ready( checkForUpdates() );" );
		
		$data	=	array();
		$data[]	=	'<div class="span8" style="text-align: center; ">';
		$data[]	=	'<a class="btn" id="btn-updates">';
		$data[]	=	'<div class="ajaxupdate ajaxupdate-init">';
		$data[]	=	'<span id="upd-title"></span>';
		$data[]	=	'<img id="img-updates" class="" />';
		$data[]	=	'<span id="upd-subtitle"></span>';
		$data[]	=	'</div>';
		$data[]	=	'</a>';
		$data[]	=	'</div>';
		$data[]	=	'<input type="hidden" id="btntitle" value="' . t( 'integrator.updates.checking.title' ) . '" />';
		$data[]	=	'<input type="hidden" id="btnsubtitle" value="' . t( 'integrator.updates.checking.subtitle' ) . '" />';
		$data[]	=	'<input type="hidden" id="ajaxurl" value="' . get_baseurl( 'integrator' ) . '" />';
		
		return implode( "\r\n", $data );
	}
}