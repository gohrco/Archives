<?php
/**
 * Integrator 3
 *
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.21 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * API interface for application
 * @version		3.1.21
 *
 * @since		3.1.00
 * @author		Steven
*/
class UserinfoApi extends BaseApi
{
	protected $_controller	=	'userinfo';
	
	/**
	 * Method to get a user from our primary user database handler
	 * @access		public
	 * @version		3.1.21
	 *
	 * @since		3.1.00
	 */
	public function get()
	{
		$cuser	=   Cuser :: getInstance( true );
		$cuser->set( 'email', get_instance()->input->get( 'email' ) );
		
		$params	=	Params :: getInstance();
		$cnxnid	=   $params->get( 'Defaultuser' );
		$api	=   get_api( $cnxnid );
		
		$api->user_find();
		
		$cuser	=   Cuser :: getInstance();
		$data	=   $cuser->get_properties();
		
		logAPIResponse( get_var( '_c' ), '0', 'get_userinfo', array( 'email' => get_var( 'email' ), 'Default Account' => $cnxnid ), null, $data );
		$this->success( array( 'data' => $data, 'type' => 'array' ) );
	}
}