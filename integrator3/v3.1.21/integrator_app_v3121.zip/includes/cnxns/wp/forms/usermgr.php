<?php

$form['modify/userfields']	= array(
	'newuser_email' => array(
			'apiname'		=> 'user_email',
			'value'			=> null,
			'order'			=> 20,
			'type'			=> 'text',
			'validation'	=> 'required'
		),
	'newuser_login' => array(
			'apiname'		=> 'user_login',
			'value'			=> null,
			'order'			=> 30,
			'type'			=> 'text',
			'validation'	=> 'required'
		),
	'newfirst_name' => array(
			'apiname'		=> 'first_name',
			'value'			=> null,
			'order'			=> 40,
			'type'			=> 'text',
			'validation'	=> ''
		),
	'newlast_name' => array(
			'apiname'		=> 'last_name',
			'value'			=> null,
			'order'			=> 50,
			'type'			=> 'text',
			'validation'	=> ''
		),
);

$form['create/userfields']	= array(
	'user_email' => array(
			'apiname'		=> 'user_email',
			'value'			=> null,
			'order'			=> 10,
			'type'			=> 'text',
			'validation'	=> 'required|valid_email'
		),
	'user_login' => array(
			'apiname'		=> 'user_login',
			'value'			=> null,
			'order'			=> 20,
			'type'			=> 'text',
			'validation'	=> 'required'
		),
	'user_pass' => array(
			'apiname'		=> 'user_pass',
			'value'			=> null,
			'order'			=> 30,
			'type'			=> 'password',
			'validation'	=> 'required'
		),
	'first_name' => array(
			'apiname'		=> 'first_name',
			'value'			=> null,
			'order'			=> 40,
			'type'			=> 'text',
			'validation'	=> ''
		),
	'last_name' => array(
			'apiname'		=> 'last_name',
			'value'			=> null,
			'order'			=> 50,
			'type'			=> 'text',
			'validation'	=> ''
		),
);