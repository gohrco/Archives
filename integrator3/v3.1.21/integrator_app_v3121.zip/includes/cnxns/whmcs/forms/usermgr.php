<?php

$form['modify/userfields']	= array(
	'userid' => array(
			'apiname'		=> 'clientid',
			'value'			=> null,
			'order'			=> 1,
			'type'			=> 'hidden',
			'validation'	=> 'required',
			'lang'			=> null,
			'desc'			=> null
		),
	'email' => array(
			'apiname'		=> 'newemail',
			'value'			=> null,
			'order'			=> 10,
			'type'			=> 'text',
			'validation'	=> 'required|valid_email',
			'lang'			=> 'userinfo.email',
			'desc'			=> 'userinfo.email.desc'
		),
	'firstname' => array(
			'apiname'		=> 'firstname',
			'value'			=> null,
			'order'			=> 20,
			'type'			=> 'text',
			'validation'	=> 'required',
			'lang'			=> 'userinfo.firstname',
			'desc'			=> 'userinfo.firstname.desc'
		),
	'lastname' => array(
			'apiname'		=> 'lastname',
			'value'			=> null,
			'order'			=> 30,
			'type'			=> 'text',
			'validation'	=> 'required',
			'lang'			=> 'userinfo.lastname',
			'desc'			=> 'userinfo.lastname.desc'
		),
	'companyname' => array(
			'apiname'		=> 'companyname',
			'value'			=> null,
			'order'			=> 40,
			'type'			=> 'text',
			'validation'	=> '',
			'lang'			=> 'userinfo.companyname',
			'desc'			=> 'userinfo.companyname.desc'
		),
	'address1' => array(
			'apiname'		=> 'address1',
			'value'			=> null,
			'order'			=> 50,
			'type'			=> 'text',
			'validation'	=> ''
		),
	'address2' => array(
			'apiname'		=> 'address2',
			'value'			=> null,
			'order'			=> 60,
			'type'			=> 'text',
			'validation'	=> ''
		),
	'city' => array(
			'apiname'		=> 'city',
			'value'			=> null,
			'order'			=> 70,
			'type'			=> 'text',
			'validation'	=> ''
		),
	'state' => array(
			'apiname'		=> 'state',
			'value'			=> null,
			'order'			=> 80,
			'type'			=> 'text',
			'validation'	=> ''
		),
	'postcode' => array(
			'apiname'		=> 'postcode',
			'value'			=> null,
			'order'			=> 90,
			'type'			=> 'text',
			'validation'	=> ''
		),
	'country' => array(
			'apiname'		=> 'country',
			'value'			=> null,
			'order'			=> 100,
			'type'			=> 'text',
			'validation'	=> ''
		),
	'phonenumber' => array(
			'apiname'		=> 'phonenumber',
			'value'			=> null,
			'order'			=> 110,
			'type'			=> 'text',
			'validation'	=> 'required'
		),
);

$form['create/userfields']	= array(
	'email' => array(
			'apiname'		=> 'newemail',
			'value'			=> null,
			'order'			=> 10,
			'type'			=> 'text',
			'validation'	=> 'required|valid_email'
		),
	'firstname' => array(
			'apiname'		=> 'firstname',
			'value'			=> null,
			'order'			=> 20,
			'type'			=> 'text',
			'validation'	=> 'required'
		),
	'lastname' => array(
			'apiname'		=> 'lastname',
			'value'			=> null,
			'order'			=> 30,
			'type'			=> 'text',
			'validation'	=> 'required'
		),
	'companyname' => array(
			'apiname'		=> 'companyname',
			'value'			=> null,
			'order'			=> 40,
			'type'			=> 'text',
			'validation'	=> ''
		),
	'address1' => array(
			'apiname'		=> 'address1',
			'value'			=> null,
			'order'			=> 50,
			'type'			=> 'text',
			'validation'	=> 'required'
		),
	'address2' => array(
			'apiname'		=> 'address2',
			'value'			=> null,
			'order'			=> 60,
			'type'			=> 'text',
			'validation'	=> ''
		),
	'city' => array(
			'apiname'		=> 'city',
			'value'			=> null,
			'order'			=> 70,
			'type'			=> 'text',
			'validation'	=> 'required'
		),
	'state' => array(
			'apiname'		=> 'state',
			'value'			=> null,
			'order'			=> 80,
			'type'			=> 'text',
			'validation'	=> 'required'
		),
	'postcode' => array(
			'apiname'		=> 'postcode',
			'value'			=> null,
			'order'			=> 90,
			'type'			=> 'text',
			'validation'	=> 'required'
		),
	'country' => array(
			'apiname'		=> 'country',
			'value'			=> null,
			'order'			=> 100,
			'type'			=> 'text',
			'validation'	=> ''
		),
	'phonenumber' => array(
			'apiname'		=> 'phonenumber',
			'value'			=> null,
			'order'			=> 110,
			'type'			=> 'text',
			'validation'	=> 'required'
		),
	'password' => array(
			'apiname'		=> 'password2',
			'value'			=> null,
			'order'			=> 120,
			'type'			=> 'password',
			'validation'	=> 'required'
		)
);