<?php
/**
 * Integrator 3
*
* @package    Integrator 3
* @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
* @license    GNU General Public License version 2, or later
* @version    3.1.21 ( $Id$ )
* @author     Go Higher Information Services, LLC
* @since      3.1.00
*
* @desc       This is the English language file for the api controller pages for the Integrator
*
*/

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * This file contains all translations used in the API
*/


// ===================================================================
// 	GENERAL TRANSLATIONS
// ===================================================================
$lang['api.error.postheadnomatch']	=	'The signatures are not matching one another.  Please try again.';
$lang['api.error.rcvdmadenomatch']	=	'The signatures are not matching one another.  Please try again.';
$lang['api.error.timestamp']		=	'Your request is too old.  Please try again.';


// ===================================================================
// 	RENDER SPECIFIC TRANSLATIONS
// ===================================================================
$lang['msg.error.rendervalidation']		=	'The request could not be validated.';
$lang['msg.error.rendersessionfind']	=	'There was a problem locating the matched session.';
$lang['msg.error.defaultvisualunset']	=	'The default visual connection was not set in the settings and is needed to render back to the application.  Please update your Visual Integration settings in the I3 core application to clear this error.';
$lang['msg.error.cnxndisabled']			=	'Either the requesting connection or the requested connection for wrapping has been disabled or had the visual settings disabled.  Unable to render back the site requested.';
$lang['msg.error.misconfiguration']		=	'There was a misconfiguration trying to build the rendering object.';
