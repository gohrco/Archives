DROP TABLE IF EXISTS `__DBPREFIX__groups`;

-- command split --

CREATE TABLE `__DBPREFIX__groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- command split --

INSERT INTO `__DBPREFIX__groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'API Users');
			
-- command split --

DROP TABLE IF EXISTS `__DBPREFIX__users`;

-- command split --

CREATE TABLE `__DBPREFIX__users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` mediumint(8) unsigned NOT NULL,
  `ip_address` char(16) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(40) NOT NULL,
  `salt` varchar(40) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- command split --

INSERT INTO `__DBPREFIX__users` (`id`, `group_id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `remember_code`, `created_on`, `last_login`, `active`) VALUES
(1, 1, '__IPADDRESS__', '__USERNAME__', '__PASSWORD__', '__SALT__', '__EMAIL__', '', '0', 'NULL', __NOW__, __NOW__, 1);

-- command split --

DROP TABLE IF EXISTS `__DBPREFIX__cnxnmap`;

-- command split --

CREATE TABLE `__DBPREFIX__cnxnmap` (
  `type` varchar(8) NOT NULL,
  `_a` int(10) NOT NULL,
  `item` varchar(100) NOT NULL,
  `_v` text NOT NULL,
  `id` int(16) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;


-- command split --

DROP TABLE IF EXISTS `__DBPREFIX__cnxns`;

-- command split --

CREATE TABLE `__DBPREFIX__cnxns` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `active` tinyint(2) NOT NULL DEFAULT '0',
  `type` varchar(50) NOT NULL,
  `params` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- command split --

DROP TABLE IF EXISTS `__DBPREFIX__meta`;

-- command split --

CREATE TABLE `__DBPREFIX__meta` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- command split --

INSERT INTO `__DBPREFIX__meta` (`id`, `user_id`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1, 1, 'Admin', '', '', '');

-- command split --

DROP TABLE IF EXISTS `__DBPREFIX__sess`;

-- command split --

CREATE TABLE `__DBPREFIX__sess` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `user_agent` varchar(50) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- command split --

DROP TABLE IF EXISTS `__DBPREFIX__session`;

-- command split --

CREATE TABLE `__DBPREFIX__session` (
  `remote` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `local` varchar(255) DEFAULT NULL,
  `cnxnid` mediumint(20) NOT NULL,
  `timestamp` int(20) NOT NULL,
  `params` text NOT NULL,
  `id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- command split --

DROP TABLE IF EXISTS `__DBPREFIX__settings`;

-- command split --

CREATE TABLE `__DBPREFIX__settings` (
  `key` varchar(100) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- command split --

INSERT INTO `__DBPREFIX__settings` (`key`, `value`) VALUES
('Sitename', 'Integrator'),
('Enable', '1'),
('Version', '3.1.21'),
('Debug', '1'),
('Secret', 'Integr83'),
('Emailprotocol', 'mail'),
('Emailsmtpport', ''),
('Emailsmtphost', ''),
('Emailsmtpuser', ''),
('Emailsmtppass', ''),
('Emailfromname', 'Integrator'),
('Emailaddress', '__EMAIL__'),
('EnableUser', '1'),
('UseSSL', '1'),
('SessionTimeout', '36000'),
('DefaultUser', ''),
('EnableVisual', '1'),
('Defaultvisual', ''),
('UnicodeMatching', '1'),
('Cache', '1'),
('CacheTTL', '300'),
('Clearcache', '0'),
('EnableRegistration', '1'),
('EnableCSValidation', '1'),
('RegRedirectionUrl', ''),
('DefaultVisualreg', ''),
('RecaptchaEnable', ''),
('RecaptchaPublickey', ''),
('RecaptchaPrivatekey', ''),
('RecaptchaTheme', ''),
('RecaptchaLang', ''),
('FieldOrder', ''),
('License', '__LICENSE__'),
('LocalKey', ''),
('DisplayLogin', '1'),
('SystemURL', '__SYSTEMURL__'),
('SystemSSL', '0'),
('LogCount', '1000'),
('LoginMsg', 'msg.redirectingnow'),
('LogoutMsg', 'msg.redirectingoutnow'),
('PasswordText', 'This password is insufficient'),
('PasswordStrength', '0'),
('BanFreebies', '0' ),
('DefaultCountry', 'US'),
('LogPurge', ''),
('Messages', '{"stepbystep":true,"cnxnstatus":true,"userlog":true,"rss":true}'),
('DefaultLanguage', 'english'),
( 'downloadid', '' ),
( 'GoHigherUsername', '' ),
( 'GoHigherPassword', '' );

-- command split --

DROP TABLE IF EXISTS `__DBPREFIX__userlog`;

-- command split --

CREATE TABLE `__DBPREFIX__userlog` (
  `task` varchar(50) NOT NULL,
  `email` varchar(120) NOT NULL,
  `ip` varchar(16) NOT NULL,
  `timestamp` int(10) NOT NULL,
  `data` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- command split --

CREATE TABLE `__DBPREFIX__cnxnlog` (
`id`  int(100) NOT NULL AUTO_INCREMENT ,
`timestamp`  timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP ,
`cnxn`  mediumint(10) NOT NULL ,
`destcnxn`  mediumint(10) NOT NULL ,
`action`  varchar(100) NOT NULL ,
`request`  text NULL ,
`response`  text NULL ,
`data`  text NULL ,
`remote`  tinyint NOT NULL DEFAULT 0 ,
PRIMARY KEY (`id`)
);

-- command split --

ALTER TABLE `__DBPREFIX__meta`  ADD `language` VARCHAR(50) NOT NULL COMMENT 'As of 3.0.4'

-- command split --

UPDATE `__DBPREFIX__settings` SET `value`='3.1.21' WHERE `key` = 'Version';

