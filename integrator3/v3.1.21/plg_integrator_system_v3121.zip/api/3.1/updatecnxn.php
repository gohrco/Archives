<?php
/**
  * Integrator 3 - System Plugin
 * 		Update Cnxn File
 *
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.21 ( $Id$ )
 * @since      3.1.05
 *
 * @desc		This file performs a remote update from our I3 application
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

jimport( 'joomla.filesystem.folder' );
jimport( 'joomla.filesystem.file' );
jimport( 'joomla.filesystem.path' );

/**
 * Verify Jwhmcs API Class
 * @version		3.1.21
 *
 * @since		3.1.05
 * @author		Steven
 */
class UpdatecnxnIntegratorAPI extends IntegratorAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		3.1.21
	 * 
	 * @since		3.1.05
	 * @see			IntegratorAPI :: execute()
	 */
	public function execute()
	{
		$config		=	dunloader( 'config', 'com_integrator' );
		$input		=	dunloader( 'input', true );
		$settings	=	$input->getVar( 'settings', array(), 'array', 'post' );
		
		$dlid	=	$config->get( 'downloadid', false );
		
		if (! $dlid ) {
			$dlid	=	$settings['dlid'];
		}
		
		if (! $dlid ) {
			return $this->error( JText::_( 'COM_INTEGRATOR_API_NO_DOWNLOADID' ) );
		}
		
		$config->set( 'downloadid', $dlid );
		$config->save();
		
		// Grab our update handler
		$updates	=	dunloader( 'updates', 'com_integrator' );
		$result		=	$updates->download();
		
		JPluginHelper::importPlugin('installer');
		$dispatcher =	JEventDispatcher::getInstance();
		
		// Unpack with our Joomla installer
		$package	=	JInstallerHelper::unpack($updates->getUpdateTarget(), true);
		
		// Get an installer instance.
		$installer = JInstaller::getInstance();
		
		// Install the package.
		if (! $installer->install( $package['dir'] ) ) {
			return $this->error( JText :: _( 'COM_INTEGRATOR_API_ERROR_UPDATING' ) );
		}
		
		JInstallerHelper::cleanupInstall($package['packagefile'], $package['extractdir']);
		
		// We have our dlid so lets try the upgrade
		return $this->success( JText :: _( 'COM_INTEGRATOR_API_UPDATECOMPLETE' ) );
	}
}