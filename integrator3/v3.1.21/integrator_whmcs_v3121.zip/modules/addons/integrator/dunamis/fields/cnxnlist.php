<?php

dunimport( 'fields.dropdown' );

class IntegratorCnxnlistDunFields extends DropdownDunFields
{
	protected $_optid	= 'id';
	protected $_optname	= 'name';
	protected $split	= '|';
	protected $options	= array();
	protected $value	= array();
	protected $target	= null;
	
	public function __construct( $settings = array() )
	{
		foreach( array( 'split', 'value', 'target' ) as $item ) {
			if ( array_key_exists( $item, $settings ) ) {
				
				if ( $item == 'split' ) {
					$this->split = $settings['split'];
					unset( $settings['split'] );
					continue;
				}
				
				if ( strpos( $settings[$item], $this->split ) !== false ) {
					$settings[$item] = explode( $this->split, $settings[$item] );
				}
				
				$this->$item = $settings[$item];
				unset( $settings[$item] );
			}
		}
		
		parent :: __construct( $settings );
		
		foreach ( $settings as $key => $value ) {
			$this->attributes[$key] = $value;
		}
		
		$this->_loadOptions();
	}
	
	
	/**
	 * Renders a form field
	 * @access		public
	 * @version		3.1.21
	 * @param		array		- $options: any options to pass along
	 * 
	 * @return		string containing form field
	 * @since		1.0.0
	 */
	public function field( $options = array() )
	{
		$form		= null;
		$name		= $this->name;
		$value		= (array) $this->value;
		$id			= $this->id;
		
		$this->attributes['onchange']	=	'updatepages(this.options[this.selectedIndex].value, \'' . $this->target . '\')';
		$attr		= array_to_string( array_merge( $this->attributes, $options ) );
		
		$form		.=	$this->_loadJavascript();
		$optns		=	$this->options;
		
		$form		.= '<select id="' . $id . '" name="'.$name.'" '.$attr.">\n";
		$oid		= $this->_optid;
		$oname		= $this->_optname;
		
		foreach ( $optns as $optn ) {
			$optn		=	(object) $optn;
			$selected	=	( in_array( $optn->$oid, $value ) ? ' selected="selected"' : '' ); 
			$form		.=	'<option value="' . $optn->$oid . '"' . $selected . '>' . t( $optn->$oname ) . "</option>\n";
		}
		
		return $form . '</select>';
	}
	
	
	/**
	 * Method to set an array option to the field
	 * @access		public
	 * @version		3.1.21
	 * @param		array		- $options: contains array of name | id pairs
	 * 
	 * @since		1.0.0
	 */
	public function setOption( $options = array() )
	{
		$this->options = $options;
	}
	
	
	public function setValue( $value = array() )
	{
		if ( strpos( $value, $this->split ) !== false ) {
			$value = explode( $this->split, $value );
		}
		
		$this->value = $value;
	}
	
	

	protected function _getCnxnpages()
	{
		static $pages	= null;
	
		if ( $pages == null ) {
			$api	=	dunloader( 'api', 'integrator' );
			$items	=	$api->get_cnxnpages( array( 'type' => 'notme' ) );
				
			if ( $items === false ) return null;
				
			foreach ( $items as $item ) {
	
				if ( empty( $item->pages ) ) {
					$this->_excludes[]	= $item->cnxn_id;
					continue;
				}
	
				$txt	= array();
				asort( $item->pages );
				foreach( $item->pages as $val => $page ) {
					if ( is_object( $page ) ) {
						$txt[]	=	$val . '|';
						foreach ( $page as $v => $p ) {
							$txt[]	=	$p . '|' . $v;
						}
					}
					else {
						$txt[]	= $page . '|' . $val;
					}
				}
				$pages .= 'pages[' . $item->cnxn_id . '] = ["' . implode( '", "', $txt ) . '"]
';
			}
		}
		
		return $pages;
	}
	
	
	protected function _loadJavascript()
	{
		static $onetime		= true;
		static $includes	= array();
		
		$doc			=	dunloader( 'document', true );
		$pagetxt		=	$this->_getCnxnpages();
		$javascript		=   null;
		
		if ( $onetime ) {
			$onetime	=   false;
			$javascript	=   <<< JSCRIPT
var pages = new Array();
pages[''] = ["- Select A Page -|"]
{$pagetxt}
JSCRIPT;

			$baseurl	=	get_baseurl( 'integrator' );
			$doc->addScriptDeclaration( $javascript );
			$doc->addScript( $baseurl . 'assets/js/cnxnlist.js' );
		}
		
		if (! isset( $includes[$this->name] ) ) {
			$includes[$this->name] = true;
			$doc->addScriptDeclaration( "jQuery('document').ready( function() { var tmp = document.getElementById( '{$this->name}' ); updatepages( tmp.options[tmp.selectedIndex].value, '{$this->target}', '{$this->value}' ); } ); " );
		}
	}
	
	
	/**
	 * Method to load the admins from the database into the options field
	 * @access		private
	 * @version		3.1.21
	 * 
	 * @since		1.0.0
	 */
	private function _loadOptions()
	{
		$data		=	array();
		$api		=	dunloader( 'api', 'integrator' );
		$cnxns		=   $api->get_cnxnlist( array( 'type' => 'notme' ) );
		foreach ( $cnxns as $cnxn ) $data[$cnxn->name]	=	$cnxn;
		ksort($data); 
		$this->setOption( $data );
	}
}