<?php defined('DUNAMIS') OR exit('No direct script access allowed');
/**
 * Integrator 3
 * Integrator 3 - Default Module Base File
 *
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.21 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This file is the default controller
 *
 */


/**
 * Default Module Class for J!WHMCS Integrator
 * @version		3.1.21
 *
 * @author		Steven
 * @since		3.1.00
 */
class IntegratorDefaultDunModule extends IntegratorAdminDunModule
{
	/**
	 * Provide means to check for file integrity
	 * @access		protected
	 * @var			string
	 * @since		3.1.00
	 */
	protected $checkstring	=	"12345";
	
	
	/**
	 * Initialise the object
	 * @access		public
	 * @version		3.1.21
	 *
	 * @since		3.1.00
	 * @see			IntegratorAdminDunModule :: initialise()
	 */
	public function initialise()
	{
		$this->action = 'default';
		parent :: initialise();
	}
	
	/**
	 * Method to execute tasks
	 * @access		public
	 * @version		3.1.21
	 * @param		string		- $task: if we are passing a specific task to do
	 * 
	 * @since		3.1.00
	 */
	public function execute()
	{
		
	}
	
	
	/**
	 * Method to render back the view
	 * @access		public
	 * @version		3.1.21
	 * 
	 * @return		string containing formatted output
	 * @since		3.1.00
	 */
	public function render( $data = null )
	{
		$doc	= dunloader( 'document', true );
		$doc->addStyleDeclaration( "#integrator .row .well-small h3 {margin: 0; padding: 0; }" );
		$doc->addStyleDeclaration( "#integrator .icon-hang {margin-left: -20px; }" );
		
		$data	= $this->buildBody();
		
		return parent :: render( $data );
	}
	
	
	/**
	 * Builds the body of the action
	 * @access		public
	 * @version		3.1.21
	 *
	 * @return		string containing html formatted output
	 * @since		3.1.00
	 */
	public function buildBody()
	{
		$input		=	dunloader( 'input', true );
		$task		=	$input->getVar( 'task' );
		
		$widgets	=	implode( "", $this->_getWidgets() );
		$data		=	'<div class="row">'
					.	'	<div class="well span8">'
					.	'		' . t( 'integrator.admin.default.body' )
					.	'	</div>'
					.	'	<div class="span4">'
					.	'		' . $widgets
					.	'	</div>'
					.	'</div>';
		
		return $data;
	}
	
	
	
	/**
	 * Method for getting the widgets for the dashboard
	 * @access		private
	 * @version		3.1.21
	 * @param		string		- $widget: contains the widget to retrieve
	 *
	 * @return		html formatted string
	 * @since		3.1.00
	 */
	private function _getWidgets( $widget = 'all' )
	{
		// Loop through for all of them
		if ( $widget == 'all' ) {
			$data	=	array();
			
			foreach ( array( 'apicnxn', 'filecheck', 'updates', /*'license', 'likeus' /*'status', * 'updates', 'license', 'likeus'*/ ) as $widg ) {
				$data[$widg]	= $this->_getWidgets( $widg );
			}
			
			return $data;
		}
		
		// We are asking for a specific one...
		$data			=	null;
		$result			=	(object) array( 'status' => null, 'header' => null, 'body' => null );
		$result->header	=	t( 'integrator.admin.widget.' . $widget . '.header');
		
		switch ( $widget ) {
			case 'apicnxn' :
				
				$api	=	dunloader( 'api', 'integrator' );
				
				if (! $api->ping() ) {
					$result->status	=	'-danger';
					$result->body	=	t( 'integrator.admin.widget.apicnxn.body.error', $api->getError() );
				}
				else {
					$result->status	=	'-success';
					$result->body	=	t( 'integrator.admin.widget.apicnxn.body.success' );
				}
				
				break;
			case 'filecheck' :
				$wconfig	=	dunloader( 'config', true );
				$install	=	dunmodule( 'integrator.install' );
				$tpl		=	strtolower( $wconfig->get( 'Template' ) );
				$files		=	(object) $install->checkFiles( $tpl . DIRECTORY_SEPARATOR );
				
				$result->status	=	'-success';
				$result->body	=	t( 'integrator.admin.widget.filecheck.body.success' );
				
				foreach ( $files as $file ) {
					if (! $file->current && ( $file->code == 4 || $file->code == 2 ) ) {
						$result->status	=	'';
						$result->body	=	t( 'integrator.admin.widget.filecheck.body.alert' );
						break;
					}
				}
				
				break;
			case 'updates' :
				$updates	=	dunloader( 'updates', 'integrator' );
				$version	=	$updates->updatesExist();
				$error		=	$updates->hasError();
				
				$result->header	=	t( 'integrator.admin.widget.updates.header', '3.1.21' );
				
				if ( $version ) {
					$result->status = '';
					$result->body	= t( 'integrator.admin.widget.updates.body.exist', $version );
				}
				else if ( $error ) {
					$result->status = '-danger';
					$result->body	= t( 'integrator.admin.widget.updates.body.error', $updates->getError() );
				}
				else {
					$result->status = '-success';
					$result->body	= t( 'integrator.admin.widget.updates.body.none' );
				}
	
				break;
		}
	
		$data	=	'<div class="well well-small alert' . $result->status . '">'
				.	'	<h3>' . $result->header . '</h3>'
				.	'	' . $result->body
				.	'</div>';
	
		return $data;
	}
}