<?php

// Bail if we are in the API
if ( is_api() ) return;

// Bail if we are in the oauth routine
if ( is_oauth() ) return;

// Grab the Post variables
if (! isset( $vars ) || empty( $vars ) ) {
	$vars = $_POST;
}

$response	=	dunmodule( 'integrator.user' )->clientDelete( $vars );
