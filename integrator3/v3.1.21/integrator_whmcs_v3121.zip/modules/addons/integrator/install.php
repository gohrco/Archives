<?php
/**
 * Integrator 3
 * Integrator 3 - Install Module Base File
 *
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.21 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This file is the install controller
 *
 */

/**
 * Install Module Class for Integrator 3
 * @version		3.1.21
 *
 * @author		Steven
 * @since		3.1.00
 */
class IntegratorInstallDunModule extends WhmcsDunModule
{
	private $destinationpath;
	private $files				=	array();
	private $sourcepath;
	
	/**
	 * Performs module activation
	 * @access		public
	 * @version		3.1.21
	 *
	 * @since		3.1.00
	 */
	public function activate()
	{
		// Load the database handler
		$db	= dunloader( 'database', true );
		
		// Load the initial tables
		$db->handleFile( 'sql' . DIRECTORY_SEPARATOR . 'install.sql', 'integrator' );
		
		// Now we need to insert the settings
		$table = $this->_getTablevalues();
		
		foreach ( $table as $key => $value ) {
			$db->setQuery( "SELECT * FROM `mod_integrator_settings` WHERE `key`=" . $db->Quote( $key ) );
			if ( $db->loadResult() ) continue;
			
			$db->setQuery( "INSERT INTO `mod_integrator_settings` ( `key`, `value` ) VALUES (" . $db->Quote( $key ) . ", " . $db->Quote( $value ) . " )" );
			$db->query();
		}
		
		// Template time
		$files			=	$this->_getTemplatefiles();
		
		foreach ( $files as $file ) {
			// If this is an upgrade or we have already copied the files in place for some reason don't do it again
			if ( $this->_isFilesizesame( $file ) ) {
				@unlink( $this->sourcepath . $file );
				continue;
			}
			
			$this->fixFile( $file );
			
			continue;
		}
	}
	
	
	/**
	 * Method for cycling through files to check for updated / modified files
	 * @access		public
	 * @version		3.1.21 ( $id$ )
	 *
	 * @return		array of objects
	 * @since		3.1.00
	 */
	public function checkFiles( $tpl = null )
	{
		$files	=	$this->_getTemplatefiles( $tpl );
		$css	=	$this->_getTemplatefiles( $tpl, 'css' );
		$js		=	$this->_getTemplatefiles( $tpl, 'js' );
		$eot	=	$this->_getTemplatefiles( $tpl, 'eot' );
		$svg	=	$this->_getTemplatefiles( $tpl, 'svg' );
		$ttf	=	$this->_getTemplatefiles( $tpl, 'ttf' );
		$woff	=	$this->_getTemplatefiles( $tpl, 'woff' );
		$files	=	array_merge( $files, $css, $js, $eot, $svg, $ttf, $woff );
		sort( $files );
		
		foreach ( $files as $file ) {
			
			$tmp	=	(object) array(
					'current'	=>	false,
					'error'		=>	false,
					'code'		=>	0,
					);
			
			if ( $this->_isFilesizesame( $file ) ) {
				$tmp->current = true;
				$this->files[$file]	=	$tmp;
				continue;
			}
			
			// Read files
			$source	=	file_exists( $this->sourcepath . $file )		? @file( $this->sourcepath . $file ) : false;
			$dest	=	file_exists( $this->destinationpath . $file )	? @file( $this->destinationpath . $file ) : false;
			
			// Catch errors reading
			if (! $source || ! $dest ) {
				$tmp->code			=	(! $source ? 1 : 4 );
				$tmp->error			=	t( 'integrator.install.file.error.read', ( ! $source ? 'source' : 'existing template' ) );
				$this->files[$file]	=	$tmp;
				continue;
			}
			
			// Find versions of files
			$sv	=
			$dv	=	false;
			
			foreach( array( 'sv' => 'source', 'dv' => 'dest' ) as $holder => $item ) {
				foreach ( $$item as $s ) {
					if ( preg_match( '/@version\s+([0-9\.]+)/im', $s, $matches, PREG_OFFSET_CAPTURE ) ) {
						$$holder	=	$matches[1][0];
						break;
					}
				}
			}
			
			// Ensure we found versions
			if (! $dv || ! $sv ) {
				$tmp->code			=	2;
				$tmp->error			=	t( 'integrator.install.file.error.version', ( ! $sv ? 'source' : 'existing template' ) );
				$this->files[$file]	=	$tmp;
				continue;
			}
			
			// Do our comparisons
			if ( version_compare( $dv, $sv, 'lt' ) ) {
				$tmp->code			=	4;
				$tmp->error			=	t( 'integrator.install.file.error.newer', ucfirst( t( 'integrator.install.file.integrator' ) ), t( 'integrator.install.file.template' ) );
			}
			else if ( version_compare( $dv, $sv, 'gt' ) ) {
				$tmp->code			=	8;
				$tmp->error			=	t( 'integrator.install.file.error.newer', ucfirst( t( 'integrator.install.file.template' ) ), t( 'integrator.install.file.integrator' ) );
			}
			else {
				$tmp->current		=	true;
			}
			
			$this->files[$file]	=	$tmp;
		}
		
		return $this->files;
	}
	
	
	/**
	 * Method to deactivate the product
	 * @access		public
	 * @version		3.1.21 ( $id$ )
	 * 
	 * @since		3.1.00
	 */
	public function deactivate()
	{
		// Load the database handler
		$db		=	dunloader( 'database', true );
		$config	=	dunloader( 'config', 'integrator' );
		
		// Run the uninstall sql
		if (! $config->get( 'preservedb', false ) ) {
			$db->handleFile( 'sql' . DIRECTORY_SEPARATOR . 'uninstall.sql', 'integrator' );
		}
		
		// Template time
		$files			=	$this->_getTemplatefiles( null, 'bak' );
		
		foreach ( $files as $file ) {
			
			// Since we have an array of .bak files, we need to figure the actual filename
			$actualfile	=	str_replace( '.bak', '', $file );
			
			// Use the original 'bak' file as it should be our first one
			$backupfile	=	$this->sourcepath . $file;
			
			// Move the current file to the source position
			@unlink( $this->destinationpath . $actualfile );
				
			// Move the backup file to the current position
			@rename( $backupfile, $this->destinationpath . $actualfile );
		}
	}
	
	
	/**
	 * Method for moving a single file into place
	 * @access		public
	 * @version		3.1.21 ( $id$ )
	 * @param		string		- $file: subpath of the file / filename to handle
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	public function fixFile( $file )
	{
		// Watch for the first backups (original files)
		if ( file_exists( $this->sourcepath . $file . '.bak' ) ) {
			$backupfile	=	$this->sourcepath . $file . '.' . DUN_MOD_INTEGRATOR;
		
			// Be sure this isn't some sort of issue
			if ( file_exists( $backupfile ) ) {
				@unlink( $backupfile );
			}
		}
		else {
			$backupfile	=	$this->sourcepath . $file . '.bak';
		}
		
		// Recursively build our path to ensure it exists
		$parts	=	explode( DIRECTORY_SEPARATOR, $file );
		$fname	=	array_pop( $parts );
		$path	=	null;
		
		foreach ( $parts as $part ) {
			$path	.=	$part . DIRECTORY_SEPARATOR;
			if (! is_dir( $this->destinationpath . $path ) ) {
				mkdir( $this->destinationpath . $path );
			}
		}
		
		// We may be putting new files in place... so be sure the destination is there before renaming it
		if ( file_exists( $this->destinationpath . $file ) ) {
			// Move the current file into the backup position
			@rename( $this->destinationpath . $file, $backupfile );
		}
			
		// Move the new to current position
		@copy( $this->sourcepath . $file, $this->destinationpath . $file );
		
		return true;
	}
	
	
	/**
	 * Method to get the table settings for a given table
	 * @access		public
	 * @version		3.1.21 ( $id$ )
	 * @param		string		- $table: the table to get
	 *
	 * @return		array
	 * @since		3.1.00
	 */
	public function getConfiguration( $table = 'settings' )
	{
		return $this->_getTablevalues( $table );
	}
	
	
	/**
	 * Initializes the module
	 * @access		public
	 * @version		3.1.21
	 *
	 * @since		3.1.00
	 */
	public function initialise()
	{
		// Template time
		$this->sourcepath		=	dirname( __FILE__ ) . DIRECTORY_SEPARATOR
								.	'templates' . DIRECTORY_SEPARATOR
								.	get_i3_version() . DIRECTORY_SEPARATOR;
		$this->destinationpath	=	DUN_ENV_PATH
								.	'templates'	. DIRECTORY_SEPARATOR;
		
	}
	
	
	/**
	 * Method to handle a legacy upgrade
	 * @access		public
	 * @version		3.1.21 ( $id$ )
	 *
	 * @since		3.1.00
	 */
	public function legacy()
	{
		// First lets go ahead and run the activation routine
		$this->activate();
		
		// Load the database handler
		$db		=	dunloader( 'database', true );
		$config	=	dunloader( 'config', 'integrator' );
		
		$map	=	array(
				'Enabled'				=>	array( 'name'	=> 'enable',			'type'	=>	'bool' ),
				'Debug'					=>	array( 'name'	=> 'debug',				'type'	=>	'bool' ),
				'IntegratorUrl'			=>	array( 'name'	=>	'integratorurl',	'type'	=>	'text' ),
				'IntegratorApisecret'	=>	array( 'name'	=>	'apitoken',			'type'	=>	'text' ),
				'cnxnid'				=>	array( 'name'	=>	'cnxnid',			'type'	=>	'text' ),
				'UserEnabled'			=>	array( 'name'	=>	'userenable',		'type'	=>	'bool' ),
				'RegistrationMethod'	=>	array( 'name'	=>	'regmethod',		'type'	=>	'boolr' ),
				'VisualEnabled'			=>	array( 'name'	=>	'visualenable',		'type'	=>	'bool' ),
				'WrapInvoice'			=>	array( 'name'	=>	'wrapinvoice',		'type'	=>	'bool' ),
		);
		
		foreach ( $map as $old => $new ) {
			// Let's load our old settings now
			$db->setQuery( "SELECT `value` FROM `tbladdonmodules` WHERE `module`=" . $db->Quote( 'integrator' ) . ' AND `setting` = ' . $db->Quote( $old ) );
			$value	=	$db->loadResult();
			
			if ( $new['type'] == 'bool' ) {
				$value = ( $value == 'Yes' ? true : false );
			}
			if ( $new['type'] == 'boolr' ) {
				$value = ( $value == 'WHMCS' ? true : false );
			}
			
			$config->set( $new['name'], $value );
		}
		
		$config->save();
		return;
		
		
		// Now we must map old files and remove them if we can
		$files	=	$this->_getLegacyfiles();
		$dirs	=	$this->_getLegacyfiles( true );
		
		foreach ( $files as $file ) {
			@unlink( $file );
		}
		
		foreach ( $dirs as $dir ) {
			@rmdir( $dir );
		}
		
		return;
	}
	
	
	/**
	 * Method to get the legacy files for deletion
	 * @access		private
	 * @version		3.1.21 ( $id$ )
	 * @param		boolean		- $sendDirs: if we want the directories back
	 * 
	 * @return		array
	 * @since		3.1.00
	 */
	private function _getLegacyfiles( $sendDirs = false )
	{
		$ds		=	DIRECTORY_SEPARATOR;
		$jwhmcs	=	WhmcsDunModule :: locateModule( 'jwhmcs' );
		$files	=	array(
				DUN_ENV_PATH . 'images' . $ds . 'jwhmcs.css',
				DUN_ENV_PATH . 'images' . $ds . 'jwhmcs-progress-bar.gif',
				DUN_ENV_PATH . 'images' . $ds . 'jwhmcs-trans-bg.png',
				DUN_ENV_PATH . 'includes' . $ds . 'api' . $ds . 'jwhmcs.php',
				DUN_ENV_PATH . 'includes' . $ds . 'api' . $ds . 'jwhmcsconfig.php',
				DUN_ENV_PATH . 'includes' . $ds . 'api' . $ds . 'jwhmcsgetpricing.php',
				DUN_ENV_PATH . 'includes' . $ds . 'api' . $ds . 'jwhmcsgetsettings.php',
				DUN_ENV_PATH . 'includes' . $ds . 'api' . $ds . 'jwhmcssync.php',
				DUN_ENV_PATH . 'includes' . $ds . 'hooks' . $ds . 'jwhmcs.php',
				DUN_ENV_PATH . 'includes' . $ds . 'hooks' . $ds . 'jwhmcs-lang.php',
				$jwhmcs . 'classes' . $ds . 'config.php',
				$jwhmcs . 'classes' . $ds . 'hook.php',
				$jwhmcs . 'classes' . $ds . 'log.php',
				$jwhmcs . 'core' . $ds . 'curl.php',
				$jwhmcs . 'core' . $ds . 'database.php',
				$jwhmcs . 'core' . $ds . 'object.php',
				$jwhmcs . 'core' . $ds . 'uri.php',
				$jwhmcs . 'images' . $ds . 'jwhmcs-progress-bar.gif',
				$jwhmcs . 'images' . $ds . 'jwhmcs-trans-bg.png',
				$jwhmcs . 'images' . $ds . 'jwhmcs.css',
				$jwhmcs . 'defines.php',
				$jwhmcs . 'factory.php',
				);
		
		$dirs	=	array(
				$jwhmcs . 'classes',
				$jwhmcs . 'core',
				$jwhmcs . 'images',
				$jwhmcs . 'jscript'
				);
		
		return $sendDirs ? $dirs : $files;
		
	}
	
	
	/**
	 * Method to get the table values
	 * @access		private
	 * @version		3.1.21
	 * @param		string		- $config: which table to get for
	 * 
	 * @return		array
	 * @since		3.1.00
	 */
	private function _getTablevalues( $config = 'settings' )
	{
		$data	= array();
		switch ( $config ) :
		case 'settings' :
			$data	= array(
					'updates'	=> null,
					
					// General Settings
					'enable'		=>	false,
					'debug'			=>	false,
					'integratorurl'	=>	null,
					'apitoken'		=>	null,
					'cnxnid'		=>	null,
					
					// User Settings
					'userenable'	=> true,
					'useraddmethod'	=> 4,
					'regmethod'				=> 1,
					'register_cnxn_id'		=>	0,
					'register_page'			=>	null,
					'register_customurl'	=>	null,
					'userstyle'		=> 1,
					'userfield'		=>	0,
					'usernamestyle'	=> 3,
					'usernamefield'	=> null,
					'clientclose'			=>	1,
					
					// Visual Settings
					'visualenable'		=>	true,
					'jqueryenable'		=>	true,
					'enableresizejs'	=>	true,
					'bootstrapenable'	=>	0,
					'customimageurl'	=>	1,
					'imageurl'			=>	null,
					'menuitem'			=>	null,
					'resetcss'			=>	1,
					'shownavbar'		=>	false,
					'showfooter'		=>	true,
					'stripbasehref'		=>	true,
					'wrapinvoice'		=>	true,
					
					// Login Settings
					'loginenable'		=> true,
					'logouturl'			=> null,
					'loginhandlessl'	=>	'2',
					'loginmethod'		=>	'1',			// v3.1.04 - Login Method
					'loginmethod_cnxn_id'		=>	0,		// v3.1.04 - Login Method
					'loginmethod_page'			=>	null,	// v3.1.04 - Login Method
					'loginmethod_customurl'		=>	null,	// v3.1.04 - Login Method
					
					// Pages Settings
					'pages'				=>	null,
					'customcss'			=>	null,
					
					// Advanced Settings
					'preservedb'			=>	true,
					'autofixfile'			=>	true,
					'passalonguseragent'	=>	false,
					'parseheadlinebyline'	=>	false,
					'forceapitoget'			=>	false,
					'apiuser'				=>	1,
					'dlid'					=>	null,
					'buttonfix'				=>	false,
					);
		break;
		endswitch;
		
		return $data;
	}
	
	
	/**
	 * Method to gather tpl files for moving around
	 * @access		private
	 * @version		3.1.21 ( $id$ )
	 * @param		string		- $subdir: any recursive subdirs
	 * @param		string		- $type: indicates what we are looking for [tpl|bak]
	 *
	 * @return		array
	 * @since		3.1.00
	 */
	private function _getTemplatefiles( $subdir = null, $type = 'tpl' )
	{
		$files	=	array();
		$path	=	$this->sourcepath
				.	$subdir;
		
		$dh	=	scandir( $path );
		
		foreach ( $dh as $file ) {
			if ( in_array( $file, array( '.', '..', 'custom.css', 'custom.css.new' ) ) ) continue;
			if ( is_dir( $path . $file ) ) {
				$files	=	array_merge( $files, $this->_getTemplatefiles( $subdir . $file . DIRECTORY_SEPARATOR, $type ) );
				continue;
			}
			$info	=	pathinfo( $file );
			if ( $info['extension'] != $type ) continue;
			$files[]	=	$subdir . $file;
		}
		
		return $files;
	}
	
	
	/**
	 * Method for testing if the file size is the same
	 * @access		private
	 * @version		3.1.21 ( $id$ )
	 * @param		string		- $file: relative path to file
	 *
	 * @return		bool
	 * @since		3.1.00
	 */
	private function _isFilesizesame( $file = null )
	{
		// If the destination doesnt exist it cant be the same
		if (! file_exists( $this->destinationpath . $file ) ) {
			return false;
		}
		return md5_file( $this->sourcepath . $file ) == md5_file( $this->destinationpath . $file );
	}
}