<?php
/**
 * Integrator 3
 * Fusion - Object File
 * 
 * @package    Integrator 3
 * @copyright  2009-2017 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.21 ( $Id: user.php 346 2014-09-30 14:05:20Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This is the user class for integrating the users into the Integrator
 * 
 */

/*-- Security Protocols --*/
if (!defined("INTEGRATOR")) die("This file cannot be accessed directly");
/*-- Security Protocols --*/


class IntUser extends IntObject
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.1.21
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function __construct()
	{
		return true;
	}
	
	
	/**
	 * User Login method redirect to Integrator upon login
	 * @access		public
	 * @version		3.1.21
	 * 
	 * @since		3.0.0
	 */
	public function user_login()
	{
		$SWIFT = SWIFT :: GetInstance();
		
		$session	= & $SWIFT->Session;
		$apiurl		=   $SWIFT->Settings->Get( 'integrator_url' );
		$cnxn_id	=   $SWIFT->Settings->Get( 'integrator_cnxnid' );
		$sdata		=   $session->GetDataStore();
		$session	=   MY_session_encode( SWIFT_Cookie :: COOKIE_PREFIX . 'sessionid' . $sdata['sessiontype'], $sdata['sessionid'] );
		
		$SWIFT->Cookie->AddVariable( 'client', 'templategroupid', $SWIFT->TemplateGroup->GetDefaultGroupID() );
		$SWIFT->Cookie->Rebuild( 'client' );
		
		// Create Form Action
		$path	= ( ( isset( $_REQUEST['integrator'] ) && $_REQUEST['integrator'] == '1') ? '/succeed/' : '/index/' . $cnxn_id . '/' );
		$uri		= new IntUri( $apiurl );
		$usessl	=   $SWIFT->Settings->Get( 'integrator_usessl' );
		$curi	=   new IntUri( SWIFT :: Get( 'basename' ) );
		$curssl	=   $curi->isSSL();
		$isSsl	=   ( $usessl == 'always' ? true : ( $usessl == 'none' ? false : $curssl ) );
		$uri->setScheme( "http" . ( $isSsl ? "s" : "" ) );
		$uri->setPath( $uri->getPath() . '/index.php/login' . $path );
		$action	= $uri->toString();
		
		// Create Form Fields
		$fields	= array( '_c' => $cnxn_id, 'session' => $session );
		
		// Presume if integrator is set then it must be coming from it
		if (! isset( $_REQUEST['integrator'] ) ) {
			// Grab and encode the return url
			$redirect = $_POST['_redirectAction'];
			
			if ( empty( $redirect ) ) {
				if ($SWIFT->User->GetProperty('profileprompt') == '0' ) {
					$redirect = '/Integrator/Default/Index/_path=Base-UserAccount-Profile-1';
				}
				else {
					$redirect = '/Integrator/Default/Index/_path=Base-Default-Index';
				}
			}
			else {
				$redirect	= trim( $redirect, '/' );
				$redirect	= str_replace( '/', '-', $redirect );
				$redirect	= '/Integrator/Default/Index/_path=' . $redirect;
			}
			
			$fields['scemail']			= $_REQUEST['scemail'];
			$fields['scpassword']		= $_REQUEST['scpassword'];
			$fields['_redirectAction'] 	= base64_encode( SWIFT :: Get( 'basename' ) . $redirect );
			
			if ( isset( $_REQUEST['rememberme'] ) ) {
				$fields['rememberme'] = '1';
			}
		}
		
		MY_form_redirect( $action, $fields );
		
	}
	
	
	/**
	 * User logout method redirects to Integrator upon logout
	 * @access		public
	 * @version		3.1.21
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function user_logout()
	{
		$SWIFT		= SWIFT :: GetInstance();
		$apiurl		=   $SWIFT->Settings->Get( 'integrator_url' );
		$cnxn_id	=   $SWIFT->Settings->Get( 'integrator_cnxnid' );
		$uri		=   new IntUri( $apiurl );
		
		// Grab the variables passed to us
		$vars	= $SWIFT->Router->GetArguments();
		
		$SWIFT->Cookie->AddVariable( 'client', 'templategroupid', $SWIFT->TemplateGroup->GetDefaultGroupID() );
		$SWIFT->Cookie->Rebuild( 'client' );
		
		// Create Form Action
		$path	= ( isset( $vars['integrator'] ) ? '/complete/' : '/index/' . $cnxn_id . '/' );
		
		$usessl	=   $SWIFT->Settings->Get( 'integrator_usessl' );
		$curi	=   new IntUri( SWIFT :: Get( 'basename' ) );
		$curssl	=   $curi->isSSL();
		$isSsl	=   ( $usessl == 'always' ? true : ( $usessl == 'none' ? false : $curssl ) );
		$uri->setScheme( "http" . ( $isSsl ? "s" : "" ) );
		$uri->setPath( $uri->getPath() . '/index.php/logout' . $path );
		$action	= $uri->toString();
		
		// Create Form Fields
		if (! isset( $_REQUEST['integrator'] ) ) {
			$fields	= array( '_c' => $cnxn_id );
		}
		else {
			$fields = array();
		}
		
		MY_form_redirect( $action, $fields );
	}
	
	
	/**
	 * Creates a user account on the Integrator app
	 * @access		public
	 * @version		3.1.21
	 * 
	 * @since		3.0.0
	 */
	public function user_register()
	{
		static $completed = false;
		
		// Be sure we do this just once...
		if ( $completed === true ) return;
		elseif ( defined( 'INTEGRATOR_API' ) ) return;
		else $completed = true;
		
		// NOTE:  There is no way to pass a password along simultaneously with adding a user in the staff backend so no way to create user there
		$data	= array(	'fullname'	=> $_POST['fullname'],
							'email'		=> $_POST['regemail'],
							'password'	=> $_POST['regpassword']
		);
		
		$api	=   new IntApi();
		
		$api->user_create( $data );
		
	}
	
	
	/**
	 * Removes a list of users on the Integrator app
	 * @access		public
	 * @version		3.1.21
	 * @param		array		- $_userIDs:  an array of user ids to drop
	 * 
	 * @since		3.0.0
	 */
	public function user_remove( $_userIDs = array() )
	{
		static $completed = false;
		
		// Be sure we do this just once...
		if ( $completed === true ) return;
		elseif ( defined( 'INTEGRATOR_API' ) ) return;
		else $completed = true;
		
		if ( empty( $_userIDs ) ) return;
		
		$api	=   new IntApi();
		
		// We have to be able to get the user emails
		if ( version_compare( SWIFT_VERSION, '4.52', 'l' ) ) {
			SWIFT_Loader :: LoadLibrary('User:UserEmail');
		}
		
		// Loop through each user id
		foreach ( $_userIDs as $_userID ) {
			// Pull the emails belonging to this user
			$_emailList = SWIFT_UserEmail :: RetrieveList( $_userID );
			
			// If somehow they dont have any loop back
			if ( empty ( $_emailList ) ) continue;
			
			// Loop through each email and remove the integrated user
			foreach ( $_emailList as $_email ) {
				$api->user_remove( $_email );
			}
		}
	}
	
	
	/**
	 * Updates a user account on the Integrator app
	 * @access		public
	 * @version		3.1.21
	 * @param		mixed		- $_userID: if false we are on the front end, else contains userID to edit
	 * 
	 * @since		3.0.0
	 */
	public function user_update( $_userID = false )
	{
		static $completed = false;
		
		// Be sure we do this just once...
		if ( $completed === true ) return;
		elseif ( defined( 'INTEGRATOR_API' ) ) return;
		else $completed = true;
		
		$_SWIFT		= SWIFT :: GetInstance();
		
		// If we have a user ID, we are coming from the staff backend
		if ( defined( 'INT_STAFFAREA' ) && $_userID ) {
			if ( version_compare( SWIFT_VERSION, '4.52', 'ge' ) ) {
				$_SW_User = new SWIFT_User( new SWIFT_DataID( $_userID ) );
			}
			else {
				$_SW_User = new SWIFT_User( $_userID );
			}
		}
		else {
			$_SW_User = & $_SWIFT->User;
		}
		
		// Grab all the emails belonging to this user
		$emails		= $_SW_User->GetEmailList();
		$api		= new IntApi();
		
		$data		= array(	'fullname'	=> $_SW_User->GetFullName()
		);
		
		// Cycle through each email in list independantly to update across Integrator
		foreach( $emails as $email ) {
			$update	= array( 'update' => $data, 'email' => $email );
			$api->user_update( $update );
		}
	}
	
	
	/**
	 * Changes a password on the Integrator app
	 * @access		public
	 * @version		3.1.21
	 * @param		array		- $data: contains the userid and the password to update
	 * 
	 * @since		3.0.0
	 */
	public function user_changepassword( $data = array() )
	{
		static $completed = false;
		
		// Be sure we do this just once...
		if ( $completed === true ) return;
		elseif ( defined( 'INTEGRATOR_API' ) ) return;
		else $completed = true;
		
		$api	=   new IntApi();
		
		// We have to be able to get the user emails
		if ( version_compare( SWIFT_VERSION, '4.52', 'l' ) ) {
			SWIFT_Loader :: LoadLibrary('User:UserEmail');
		}
		
		// Pull the emails belonging to this user
		$_emailList = SWIFT_UserEmail :: RetrieveList( $data['_userID'] );
		
		// If somehow they dont have any email addresses then return
		if ( empty ( $_emailList ) ) return;
		
		// Loop through each email and remove the integrated user
		foreach ( $_emailList as $_email ) {
			$update	= array( 'update' => array( 'password' => $data['password'] ), 'email' => $_email );
			$api->user_update( $update );
		}
	}
	
	
	/**
	 * User validation prior to creation
	 * @access		public
	 * @version		3.1.21
	 * @param		mixed		- $_userID: if false we are on the front end, else contains userID to edit
	 * 
	 * @return		array containing result and message
	 * @since		3.0.0
	 */
	public function user_validation_on_create( $_userID = false )
	{
		static $completed = false;
		
		// Be sure we do this just once...
		if ( $completed === true ) return;
		elseif ( defined( 'INTEGRATOR_API' ) ) return;
		else $completed = true;
		
		$data	= array(	'fullname'	=> $_POST['fullname'],
							'email'		=> $_POST['regemail'],
							'password'	=> $_POST['regpassword']
		);
		
		$api	=   new IntApi();
		
		if ( ( $message = $api->user_validation_on_create( $data ) ) == 'true' ) {
			return array( 'result' => true, 'message' => null );
		}
		else {
			if ( $message == false ) $message = 'Email address exists elsewhere';
			return array( 'result' => false, 'message' => $message );
		}
	}
	
	
	public function user_validation_on_update( $data = array() )
	{
		static $completed = false;
		
		// Be sure we do this just once...
		if ( $completed === true ) return;
		elseif ( defined( 'INTEGRATOR_API' ) ) return;
		else $completed = true;
		
		extract( $data );
		
		$user	=   new SWIFT_User( $_userID );
		$api	=   new IntApi();
		$data	=   array( 	'fullname'	=> $user->GetFullName() );
		
		if ( isset( $_finalNewEmailList ) && ( is_array( $_finalNewEmailList ) || is_object( $_finalNewEmailList ) ) ) {
			foreach( $_finalNewEmailList as $_email ) {
				$data['email'] = $_email;
				
				if ( ( $message = $api->user_validation_on_create( $data ) ) != 'true' ) {
					return array( 'result' => false, 'message' => $message );
				}
			}
		}
		
		$this->user_remove( $_deleteUserEmailIDList );
		
		return array( 'result' => true, 'message' => null );
	}
}