<?php
/**
 * Integrator 3
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.03 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This is the helper file for Integrator 3
 *
 */


/**
 * Handles inclusion of media items into views
 * @version	3.1.03
 * @param	string		$media - contains filename/type
 *
 * @since	3.1.00
 */
if (! function_exists( 'add_media' ) ) {
function add_media( $media = null )
{
	if ( $media == null ) return;

	list( $filename, $type ) = explode( "/", $media );

	switch ( $type ):
	case 'css':
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			JHtml::stylesheet( "com_integrator/{$filename}.css", array(), true );
		}
		else {
			$uri	= new Juri();
			//$path	= rtrim( $uri->toString(), '/' ) . '/media/com_integrator/css/';
			$path	= 'media/com_integrator/css/';
			JHtml::stylesheet( "{$filename}.css", $path, array() );
		}
		break;
	case 'javascript':
	case 'js':
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			JHTML::script("com_integrator/{$filename}.js", array(), true );
		}
		else {
			$uri	= new Juri();
			//$path	= rtrim( $uri->toString(), '/' ) . '/media/com_integrator/js/';
			$path	= 'media/com_integrator/js/';
			JHTML::script( "{$filename}.js", $path, array() );
		}
		break;
		endswitch;
}
}


/**
 * Function for building a full name based on the WHMCS user data
 * @version		3.1.03 ( $id )
 * @param		array		- $user: the user array from WHMCS to use
 *
 * @return		string
 * @since		3.1.00
 */
if (! function_exists( 'build_fullname' ) ) {
function build_fullname( $user )
{
	$user	=	(object) $user;
	$name	=	"{$user->firstname} {$user->lastname}";
	
	return $name;
}
}


/**
 * Builds a user array
 * @version		3.1.03
 * @param		array		- $newuser: the updated user array to use
 * @param		array		- $olduser: the previous user array if applicable
 * @param		boolean		- $is_new: true if new
 * @param		string		- $direction: indicates if the user array is coming from Integrator or going to the Integrator (default = to)
 *
 * @return		array containing user array
 * @since		3.0.0
 */
if (! function_exists( 'build_user_array' ) ) {
function build_user_array( $newuser, $olduser, $is_new, $direction = 'to' )
{
	$data	= array();
	$check	= array( 'email', 'username', 'name', 'block' );

	if ( $is_new ) {
		foreach ( $check as $c ) {
			if ( empty( $newuser[$c] ) || (! isset( $newuser[$c] ) ) ) continue;
			$data[$c] = $newuser[$c];
		}
			
		if ( $newuser['password'] == $newuser['password2'] ) {
			$data['password'] = $newuser['password'];
		}
		elseif ( (! empty( $newuser['password_clear'] ) ) ) {
			$data['password'] = $newuser['password_clear'];
		}
	}
	else {
		foreach ( $check as $c ) {
			if (! isset( $newuser[$c] ) ) continue;
			if ( empty( $newuser[$c] ) && $newuser[$c] != '0' ) continue;
			$data['update'][$c] = $newuser[$c];
		}
			
		if ( (! empty( $newuser['password_clear'] ) ) ) {
			$data['update']['password'] = $newuser['password_clear'];
		}
		else if ( (! empty( $newuser['password'] ) ) && (! empty( $newuser['password2'] ) ) && ( $newuser['password'] == $newuser['password2'] ) ) {
			$data['update']['password'] = $newuser['password'];
		}
			
			
		$data['email']		= $olduser['email'];
		$data['username']	= $olduser['username'];
		$data['block']		= $olduser['block'];
	}

	return $data;
}
}


/**
 * Function for building a username based on Integrator 3 settings
 * @version		3.1.03 ( $id )
 * @param		array		- $user: the user array from WHMCS to use
 *
 * @return		string
 * @since		3.1.00
 */
if (! function_exists( 'build_username' ) ) {
	function build_username( $user )
	{
		$user	=	(object) $user;
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		$input	=	dunloader( 'input', true );
		$name	=	null;
		
		switch ( $config->get( 'useraddusernamepattern', 1 ) ) :
		// Create the username as `firstname.lastname`
		case '0' :
			$name	=	"{$user->firstname}.{$user->lastname}";
		break;
		// Create the username as `lastname.firstname`
		case '1' :
			$name	=	"{$user->lastname}.{$user->firstname}";
			break;
			// Create the username as `random`
		default :
		case '2' :
			for ($i=0; $i<12; $i++) {
				$d = rand(1,30)%2;
				$name	.=	( $d ? chr(rand(65,90)) : chr(rand(48,57)));
			}
			$name	=	ucfirst(strtolower($user));
			break;
			// Create the username as `f.lastname`
		case '4' :
			$name	=	substr($user->firstname, 0, 1).".{$user->lastname}";
			break;
			// Create the username as `firstname.l`
		case '8' :
			$name	=	"{$user->firstname}.".substr($user->lastname, 0, 1);
			break;
			// Create the username as `firstname`
		case '16' :
			$name	=	"{$user->firstname}";
			break;
			// Create the username as `lastname`
		case '32' :
			$name	=	"{$user->lastname}";
			break;
			// Create the username as their email address
		case '64' :
			$name	=	"{$user->email}";
			break;
		endswitch;
		

		return $name;
	}
}


/**
 * Gets a user from the database
 * @version		3.1.03
 * @param		string		- $search: the string to search by
 * @param		string		- $by: what to search by (email or username)
 *
 * @return		array or false on no find
 * @since		3.1.00
 */
if (! function_exists( 'get_joomlauser' ) ) {
function get_joomlauser( $search, $by = 'email' )
{
	if ( is_null( $search ) ) return null;
	
	$db		=	dunloader( 'database', true );
	$query	=	"SELECT `id`, `username`, `email`, `name`, `block` FROM #__users WHERE `" . $by . "` = " . $db->Quote( $search );
	$db->setQuery($query, 1, 0);
	return $db->loadAssoc();
}
}


/**
 * Creates an encoded session hash for transmittal
 * @version		3.1.03
 * @param		string		- $name: the session name
 * @param		string		- $id: the session id
 *
 * @return		string containing hashed array
 * @since		3.1.00
 */
if (! function_exists( 'encode_session' ) ) {
function encode_session( $name, $id )
{
	// Initialize items
	$config			=	dunloader( 'config', 'com_integrator' );
	$salt			=   mt_rand();
	$secret			=   $config->get( 'IntegratorSecret' );
	$string			=   null;
	$data			=   null;
	$encode			=   null;

	// Create base array
	$serial	= serialize( array( 'id' => $id, 'name' => $name ) );
	$key	= md5( $secret . $salt );

	for ( $i = 0; $i < strlen( $serial ); $i++ ) {
		$string .= substr( $key, ( $i % strlen( $key ) ), 1 ) . ( substr( $key, ( $i % strlen( $key ) ), 1 ) ^ substr( $serial, $i, 1 ) );
	}

	for ( $i = 0; $i < strlen( $string ); $i++ ) {
		$data .= substr( $string, $i, 1 ) ^ substr( $key, ( $i % strlen( $key ) ), 1 );
	}

	// Create array and encode
	$encode	= array( 'data' => base64_encode( $data ), 'salt' => $salt );
	$encode = serialize( $encode );
	$encode = base64_encode( $encode );
	$encode = md5( $salt . $secret ) . $encode;
	$encode = strrev( $encode );

	return $encode;
}
}


/**
 * Creates a quick form redirection to send back to the Integrator securely
 * @static
 * @access		private
 * @version		3.1.03
 * @param		string		- $url: the form action to send to
 * @param		array		- $fields: hidden fields to send
 *
 * @since		3.0.0
 */
if (! function_exists( 'form_redirect' ) ) {
function form_redirect( $url = null, $fields = array() )
{
	$field = null;
	foreach ( $fields as $name => $value ) {
		$field .= "<input type='hidden' name='{$name}' value='{$value}' />";
	}

	header("Cache-Control: no-cache, no-store, must-revalidate");
	header("Expires: -1");

	$output = <<< OUTPUT
<form action="{$url}" method="post" name="frmlogin" id="frmlogin">
		{$field}
</form>
<script language="javascript"><!--
setTimeout ( "autoForward()", 0 );
function autoForward() {
	document.forms['frmlogin'].submit()
}
//--></script>
OUTPUT;
		exit ( $output );
}
}


/**
 * Common method to get language across versions
 * @access		public
 * @version		3.1.03
 *
 * @return		string
 * @since		3.0.0
 */
if (! function_exists( 'get_language' ) ) {
function get_language()
{
	if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
		$langs		=	JLanguageHelper::getLanguages('lang_code');
		return $langs[JFactory :: getLanguage()->getTag()]->sef;
	}
	else {
		$langs		=	JFactory::getLanguage();
		return $langs->getTag();
	}
}
}

/**
 * Check for the old helper class as its still needed at times
 * @version		3.1.03 ($Id)
 * @since		3.1.00
 */
if (! class_exists( 'IntegratorHelper' ) ) {
	$path	=	JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_integrator' . DIRECTORY_SEPARATOR . 'integrator.helper.php';
	if ( @file_exists( $path ) ) {
		require_once( $path );
	}
}