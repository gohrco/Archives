<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 		API Ping File
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.00 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.5.0
 *
 * @desc       This is the Verify Task which replaces the ping task for the J!WHMCS Integrator API
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

jimport( 'joomla.filesystem.folder' );
jimport( 'joomla.filesystem.file' );
jimport( 'joomla.filesystem.path' );

/**
 * Verify Jwhmcs API Class
 * @version		3.1.00
 *
 * @since		2.5.3
 * @author		Steven
 */
class GetinfoIntegratorAPI extends IntegratorAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		3.1.00
	 * 
	 * @since		3.1.00
	 * @see			IntegratorAPI :: execute()
	 */
	public function execute()
	{
		$db			=	dunloader( 'database', true );
		$result		=
		$results	=	
		$data		=   array();
		
		$query	= array();
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$query[]	=   "SELECT * FROM #__extensions WHERE `name` LIKE '%integrator%'";
		}
		else {
			$query[]	=	"SELECT *, 'component' as `type` FROM #__components WHERE `option` LIKE '%com_integrator%'";
			$query[]	=	"SELECT *, 'module' as `type`, `module` as 'element' FROM #__modules WHERE `module` LIKE '%mod_intlogin%'";
			$query[]	=	"SELECT *, 'plugin' as `type` FROM #__plugins WHERE `element` LIKE '%integrator_%'";
		}
		
		foreach ( $query as $q ) {
			$db->setQuery( $q );
			$result	=	$db->loadObjectList();
			foreach ( $result as $res ) $results[] = $res;
		}
		
		foreach ( $results as $row ) {
			switch ( $row->type ):
			case 'component':
				$possible	= array();
				$files		= JFolder::files( JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_integrator' . DIRECTORY_SEPARATOR, '\.xml$', false, false );
				if(! empty( $files ) ) foreach ( $files as $filename ) {
					if ( strpos( $filename, 'com_integrator', 0 ) === false ) continue;
					if ( strpos( $filename, 'com_integrator', 0 ) > 0 ) continue;
					$possible[]	= $filename;
				}
				
				rsort( $possible );
				$filename	= JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_integrator' . DIRECTORY_SEPARATOR . array_shift( $possible );
				$name		= 'cnxns|joomla|component';
			break;
			case 'module':
				// Switch based on element (in case we add other modules down the road)
				switch( $row->element ):
				case 'mod_intlogin':
					$filename	= JPATH_SITE . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR . 'mod_intlogin' . DIRECTORY_SEPARATOR . 'mod_intlogin.xml';
					$name		= 'cnxns|joomla|intlogin';
				break;
				endswitch;
			break;
			case 'plugin':
				$path		= version_compare( JVERSION, '1.6.0', 'ge' ) ? $row->element . DIRECTORY_SEPARATOR : '';
				$filename	= JPATH_PLUGINS . DIRECTORY_SEPARATOR . $row->folder . DIRECTORY_SEPARATOR . $path . $row->element . '.xml';
				$name		= 'cnxns|joomla|' . $row->folder . 'plugin';
			break;
			endswitch;
				
			// ---- BEGIN INT-13
			//		Joomla 3 drops the use of the JFactory XML handler, so we will just use SimpleXML
			$xml	=	simplexml_load_file( $filename );
			$json	=	json_encode( $xml );
			$xobj	=	json_decode( $json );	// awesome trick...
			
			if ( ( $xml->getName() != 'install' ) && ( $xml->getName() != 'extension' ) ) {
				unset($xml);
				$data[$name] = null;
				continue;
			}
			
			$data[$name] = $xobj->version;
			// ---- END INT-13
		}
		
		return $this->success( $data );
	}
}