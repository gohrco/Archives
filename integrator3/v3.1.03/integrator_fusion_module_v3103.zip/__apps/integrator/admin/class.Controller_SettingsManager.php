<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.03 ( $Id: class.Controller_SettingsManager.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This file is the settings manager for the Fusion addon module
 * 
 */

/**
 * Settings Manager Controller
 * @author		Steven
 * @version		3.1.03
 * 
 * @since		3.0.0
 */
class Controller_SettingsManager extends Controller_admin
{
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.1.03
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
		$this->Load->Library('Settings:SettingsManager');
		return true;
	}
	
	
	/**
	 * Destructor method
	 * @access		public
	 * @version		3.1.03
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function __destruct()
	{
		parent::__destruct();
		return true;
	}
	
	
	/*
	public function Index()
	{
		$_SWIFT = SWIFT::GetInstance();
		
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
			return false;
		}
		
		$this->UserInterface->Header( 'Integrator - Settings', self::110, self::1);
		
		if ($_SWIFT->Staff->GetPermission('admin_canupdatesettings') == '0')
		{
			$this->UserInterface->DisplayError($this->Language->Get('titlenoperm'), $this->Language->Get('msgnoperm'));
		} else {
			$this->UserInterface->Start(get_class($this), '/integrator/SettingsManager/Index');
			$this->SettingsManager->Render($this->UserInterface, SWIFT_SettingsManager::FILTER_NAME, array('settings_integrator'));
			$this->UserInterface->End();
		}
		
		$this->UserInterface->Footer();
		
		return true;
	}*/
	
}

?>