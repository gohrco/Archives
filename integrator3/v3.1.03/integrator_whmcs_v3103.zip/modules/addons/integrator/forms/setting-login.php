<?php


$form	= array(
		'loginenable'		=> array(
				'order'			=> 10,
				'type'			=> 'toggleyn',
				'value'			=> true,
				'validation'	=> '',
				'labelon'		=> 'integrator.form.toggleyn.enabled',
				'labeloff'		=> 'integrator.form.toggleyn.disabled',
				'label'			=> 'integrator.admin.form.settings.label.loginenable',
				'description'	=> 'integrator.admin.form.settings.description.loginenable',
				),
		'logouturl'		=> array(
				'order'			=> 30,
				'type'			=> 'text',
				'value'			=> null,
				'validation'	=> '',
				'label'			=> 'integrator.admin.form.settings.label.logouturlfield',
				'description'	=> 'integrator.admin.form.settings.description.logouturlfield',
		),
		'loginhandlessl'		=> array(
				'order'			=> 40,
				'type'			=> 'togglebtn',
				'value'			=> '',
				'validation'	=> '',
				'options'		=> array(
						array( 'id' => 0, 'name' => 'integrator.loginhandlessl.none' ),
						array( 'id' => 1, 'name' => 'integrator.loginhandlessl.force' ),
						array( 'id' => 2, 'name' => 'integrator.loginhandlessl.defer' ),
				),
				'label'			=> 'integrator.loginhandlessl.label',
				'description'	=> 'integrator.loginhandlessl.desc'
		),
	);
