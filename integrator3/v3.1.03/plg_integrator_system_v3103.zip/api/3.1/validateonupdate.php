<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 		API Ping File
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.00 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.5.0
 *
 * @desc       This is the Verify Task which replaces the ping task for the J!WHMCS Integrator API
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

jimport( 'joomla.filesystem.folder' );
jimport( 'joomla.filesystem.file' );
jimport( 'joomla.filesystem.path' );

/**
 * Validateonupdate API Class
 * @version		3.1.00
 *
 * @since		3.1.00
 * @author		Steven
 */
class ValidateonupdateIntegratorAPI extends IntegratorAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		3.1.00
	 * 
	 * @since		3.1.00
	 * @see			IntegratorAPI :: execute()
	 */
	public function execute()
	{
		$db		=	dunloader( 'database', true );
		$input	=	dunloader( 'input', true );
		$data	=	$input->getVar( 'data', array(), 'array' );
		$query	=   array();
		
		extract( $data );
		
		// Lets check email updates first
		if ( isset( $update['email'] ) && isset( $email ) && $email != $update['email'] ) {
			$query['email']		= "SELECT u.id FROM `#__users` u WHERE `email` = {$db->Quote( $email )}";
		}
		
		// Lets check username updates next
		if ( isset( $update['username'] ) && isset( $username ) && $username != $update['username'] ) {
			$query['username']	=	"SELECT u.id FROM `#__users u WHERE `username` = {$db->Quote( $username )}";
		}
		
		foreach ( $query as $type => $q ) {
			$db->setQuery( $q );
			if ( $db->loadResult() ) {
				return $this->error( JText :: sprintf( 'COM_INTEGRATOR_API_USERVALIDATION_ERROR' . strtoupper( $type ), $update[$$type] ) );
			}
		}
		
		return $this->success( true );
	}
}