<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 		API Ping File
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.00 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.5.0
 *
 * @desc       This is the Verify Task which replaces the ping task for the J!WHMCS Integrator API
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

jimport( 'joomla.filesystem.folder' );
jimport( 'joomla.filesystem.file' );
jimport( 'joomla.filesystem.path' );

/**
 * Verify Jwhmcs API Class
 * @version		3.1.00
 *
 * @since		2.5.3
 * @author		Steven
 */
class GetlanguagesIntegratorAPI extends IntegratorAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		3.1.00
	 * 
	 * @since		3.1.00
	 * @see			IntegratorAPI :: execute()
	 */
	public function execute()
	{
		$db =	dunloader( 'database', true );
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$query	= "SELECT sef as 'value', title as 'name' FROM #__languages WHERE published=1";
			$db->setQuery($query);
			$data	=	array();
			foreach( $db->loadObjectList() as $lang ) {
				$data[$lang->value] = $lang->name;
			}
			
			return $this->success( $data );
		}
		
		// Joomla 1.5 below
		// Check to see if we have Joomfish installed
		if ( $this->_check_table( "languages" ) ) {
			
			$query = "SELECT `shortcode` as 'value', `name` as 'name' FROM #__languages WHERE `active` = 1";
			$db->setQuery( $query );
			
			if ( ( $rows = $db->loadAssocList() ) ) {
				$results = array();
				foreach ( $rows as $row ) {
					$results[$row->value] = $row->name;
				}
				return $this->success( $results );
			}
		}
		
		// No Joomfish, so pull the languages like Joomla does
		jimport('joomla.client.helper');
		jimport('joomla.filesystem.folder');
		
		$client		=	JApplicationHelper::getClientInfo(JRequest::getVar('client', '0', '', 'int'));
		$results	=   array();
		$ftp		=	JClientHelper::setCredentialsFromRequest('ftp');
		$path		=   JLanguage::getLanguagePath($client->path);
		$params		=   JComponentHelper::getParams( 'com_languages' );
		$dirs		=   JFolder::folders( $path );
		$rowid		= 0;
		
		foreach ($dirs as $dir) {
			$files = JFolder::files( $path . DIRECTORY_SEPARATOR . $dir, '^([-_A-Za-z]*)\.xml$' );
			foreach ($files as $file) {
				$data = JApplicationHelper::parseXMLLangMetaFile($path . DIRECTORY_SEPARATOR . $dir . DIRECTORY_SEPARATOR . $file);
				if ( $params->get( $client->name, 'en-GB' ) == $data['name'] ) {
					$results = array( substr($file,0,-4) => $data['name'] ) + $results;
				}
				else {
					$results = $results + array( substr($file,0,-4) => $data['name'] );
				}
			}
		}
		
		return $this->success( $results );
	}
}