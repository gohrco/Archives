<?php
/**
 * Integrator 3 - System Plugin
 * 		API Render File
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.03 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This is the Verify Task which replaces the ping task for the J!WHMCS Integrator API
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Render Integrator API Class
 * @version		3.1.03
 *
 * @since		3.1.00
 * @author		Steven
 */
class RenderIntegratorAPI extends IntegratorAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		3.1.03
	 * 
	 * @since		3.1.00
	 * @see			IntegratorAPI :: execute()
	 */
	public function execute()
	{
		$config		=	dunloader( 'config',	'com_integrator' );
		
		// Attach our render and route handlers to ensure we get fired last
		$dispatcher	=	JDispatcher :: getInstance();
		
		if ( $config->get( 'rendermechanism' ) == 'before' ) {
			$dispatcher->register( 'onBeforeRender', 'RenderIntegratorAPIPlugin' );
		}
		else {
			$dispatcher->register( 'onAfterRender', 'RenderIntegratorAPIPlugin' );
		}
		$dispatcher->register( 'onAfterRoute', 'RenderIntegratorAPIPlugin' );
		return false;
	}
}



/**
 * Render Plugin Class
 * @desc		This class is only attached to the disptacher object if we are called
 * 				through the API handler and have met all the requirements to do so.
 * @version		3.1.03
 *
 * @author		Steven
 * @since		3.1.0
 */
class RenderIntegratorAPIPlugin extends JPlugin
{
	/**
	 * System Event Handler: onAfterRender
	 * @desc		Intercepts the rendering prior to actually outputting to the browser
	 * 				and parses the content, encodes it into base64 code and returns a
	 * 				json formatted string
	 * @access		public
	 * @version		3.1.03
	 *
	 * @since		3.1.00
	 */
	public function onAfterRender()
	{
		$app		=	JFactory :: getApplication();
		$doc		=	JFactory :: getDocument();
		$input		=	dunloader( 'input', true );
		$config		=	dunloader( 'config', 'com_integrator' );
		
		$html	=	$app->getBody();
		
		// Perform some initial regexes on the whole data
		if ( $input->getVar( 'lang', false, 'string', 'get' ) && ( $langrev = $input->getVar( 'langrev', false, 'string', 'get' ) ) ) {
			// Find WHMCS URLs and affix the language to them
			$whmcsurl	=	$config->get( 'whmcsurl', null );
			$whmcsuri	=	DunUri :: getInstance( $whmcsurl, true );
			$whmcsurl	=	preg_quote( $whmcsuri->toString( array( 'user', 'pass', 'host', 'port', 'path', 'query', 'fragment' ) ), '#' );
			$regex		=	'#<a[^>]+([\"\']+)(?P<link>http(?:s|)\://' . $whmcsurl . '[^\1>]*)\1[^>]*>#im';
		
			preg_match_all( $regex, $html, $matches, PREG_SET_ORDER );
		
			foreach ( $matches as $match ) {
				$uri	=	DunUri :: getInstance( $match['link'], true );
				$uri->setVar( 'language', $langrev );
				$repl	=	str_replace( $match['link'], $uri->toString(), $match[0] );
				$html	=	str_replace( $match[0], $repl, $html );
			}
		}
		
		// Lets fix any login forms people insist on using
		$inturl		=	$config->get( 'IntegratorUrl', null );
		$inturi		=	DunUri :: getInstance( $inturl, true );
		$inturi->setScheme( 'http' . ( is_ssl() ? 's' : '' ) );
		
		$regex		=	'#(?><form)[^>]+?action=[\"|\']+(?P<link>[^\"|\']+)[\"|\']+[^>]*>.*?(?></form>)#ims';
		preg_match_all( $regex, $html, $matches, PREG_SET_ORDER );
		foreach ( $matches as $match )
		{
			// Replace log in actions
			if ( preg_match( '#<input[^>]+[\"|\']+com_users[^>]+>#im', $match[0] ) && preg_match( '#<input[^>]+[\"|\']+user\.login[^>]+>#im', $match[0] ) ) {
				$match['fix']	=	str_replace( 'com_users', 'com_integrator', $match[0] );
				$match['fix']	=	str_replace( 'user.login', 'login', $match['fix'] );
				$match['fix']	=	str_replace( $match['link'], DunUri :: getInstance( true )->toString( array( 'scheme', 'host', 'path' ) ), $match['fix'] );
				$html			=	str_replace( $match[0], $match['fix'], $html );
			}
		
			// Replace log out actions
			if ( preg_match( '#<input[^>]+[\"|\']+com_users[^>]+>#im', $match[0] ) && preg_match( '#<input[^>]+[\"|\']+user\.logout[^>]+>#im', $match[0] ) ) {
				$match['fix']	=	str_replace( 'com_users', 'com_integrator', $match[0] );
				$match['fix']	=	str_replace( 'user.logout', 'logout', $match['fix'] );
				$match['fix']	=	str_replace( $match['link'], DunUri :: getInstance( true )->toString( array( 'scheme', 'host', 'path' ) ), $match['fix'] );
				$html			=	str_replace( $match[0], $match['fix'], $html );
			}
		}
		
		// Blow em up
		$parts	=	explode( '<integrator />', $html );
		
		// Backup explosion
		if ( count( $parts ) < 2 ) {
			$parts	=	explode( '<!-- Integrator_Marker -->', $html );
		}
		
		// Lets see if we have a content header
		$headsig	=	(string) rawurldecode( $input->getVar( 'HTTP_INTEGRATORREQUESTSIGNATURE', false, 'STRING', 'server' ) );
		
		// If we are debugging and we aren't coming from WHMCS echo the page back out
		if ( $config->get( 'debug' ) && ! $headsig ) {
			$content	=	(string) implode( '', $parts );
			exit( $content );
		}
		
		// Encode the parts
		$hdr	=	base64_encode( array_shift( $parts ) );
		$ftr	=	base64_encode( array_pop( $parts ) );
		$string	=	json_encode( array( 'result' => 'success', 'htmlheader' => $hdr, 'htmlfooter' => $ftr, 'debug' => dunloader( 'debug', true )->renderforApi() ) );
		
		exit( $string );
	}
	
	
	/**
	 * System Event Handler: onBeforeRender
	 * @desc		Intercepts the rendering prior to actually outputing to browser
	 * 				and parses the content, encodes it into base64 code and returns
	 * 				a json formatted string
	 * @access		public
	 * @version		3.1.03 ( $id$ )
	 *
	 * @since		3.1.0
	 */
	public function onBeforeRender()
	{
		
		$app		=	JFactory :: getApplication();
		$doc		=	JFactory :: getDocument();
		$input		=	dunloader( 'input', true );
		$config		=	dunloader( 'config', 'com_integrator' );

		// Grab the template and build the parameters
		$template	=	$app->getTemplate(true);

		$params	=	array(
				'template'	=>	$app->getTemplate(),
				'file'		=>	'index.php',
				'directory'	=>	JPATH_THEMES,
				'params'	=>	$template->params
		);

		// ---- BEGIN JWHMCS-9
		//		Some templates are rendering links / js twice
		/* $doc->parse($params); */
		// ---- END JWHMCS-9

		// Render the template
		$html = $doc->render( false, $params );

		// Perform some initial regexes on the whole data
		if ( $input->getVar( 'lang', false, 'string', 'get' ) && ( $langrev = $input->getVar( 'langrev', false, 'string', 'get' ) ) ) {
			// Find WHMCS URLs and affix the language to them
			$whmcsurl	=	$config->get( 'whmcsurl', null );
			$whmcsuri	=	DunUri :: getInstance( $whmcsurl, true );
			$whmcsurl	=	preg_quote( $whmcsuri->toString( array( 'user', 'pass', 'host', 'port', 'path', 'query', 'fragment' ) ), '#' );
			$regex		=	'#<a[^>]+([\"\']+)(?P<link>http(?:s|)\://' . $whmcsurl . '[^\1>]*)\1[^>]*>#im';
				
			preg_match_all( $regex, $html, $matches, PREG_SET_ORDER );
				
			foreach ( $matches as $match ) {
				$uri	=	DunUri :: getInstance( $match['link'], true );
				$uri->setVar( 'language', $langrev );
				$repl	=	str_replace( $match['link'], $uri->toString(), $match[0] );
				$html	=	str_replace( $match[0], $repl, $html );
			}
		}
		
		// Lets fix any login forms people insist on using
		$inturl		=	$config->get( 'IntegratorUrl', null );
		$inturi		=	DunUri :: getInstance( $inturl, true );
		$inturi->setScheme( 'http' . ( is_ssl() ? 's' : '' ) );
		
		$regex		=	'#(?><form)[^>]+?action=[\"|\']+(?P<link>[^\"|\']+)[\"|\']+[^>]*>.*?(?></form>)#ims';
		preg_match_all( $regex, $html, $matches, PREG_SET_ORDER );
		foreach ( $matches as $match )
		{
			// Replace log in actions
			if ( preg_match( '#<input[^>]+[\"|\']+com_users[^>]+>#im', $match[0] ) && preg_match( '#<input[^>]+[\"|\']+user\.login[^>]+>#im', $match[0] ) ) {
				$match['fix']	=	str_replace( 'com_users', 'com_integrator', $match[0] );
				$match['fix']	=	str_replace( 'user.login', 'login', $match['fix'] );
				$match['fix']	=	str_replace( $match['link'], DunUri :: getInstance( true )->toString( array( 'scheme', 'host', 'path' ) ), $match['fix'] );
				$html			=	str_replace( $match[0], $match['fix'], $html );
			}
				
			// Replace log out actions
			if ( preg_match( '#<input[^>]+[\"|\']+com_users[^>]+>#im', $match[0] ) && preg_match( '#<input[^>]+[\"|\']+user\.logout[^>]+>#im', $match[0] ) ) {
				$match['fix']	=	str_replace( 'com_users', 'com_integrator', $match[0] );
				$match['fix']	=	str_replace( 'user.logout', 'logout', $match['fix'] );
				$match['fix']	=	str_replace( $match['link'], DunUri :: getInstance( true )->toString( array( 'scheme', 'host', 'path' ) ), $match['fix'] );
				$html			=	str_replace( $match[0], $match['fix'], $html );
			}
		}
		
		// Blow em up
		$parts	=	explode( '<integrator />', $html );

		// Backup explosion
		if ( count( $parts ) < 2 ) {
			$parts	=	explode( '<!-- Integrator_Marker -->', $html );
		}

		// Lets see if we have a content header
		$headsig	=	(string) rawurldecode( $input->getVar( 'HTTP_INTEGRATORREQUESTSIGNATURE', false, 'STRING', 'server' ) );

		// If we are debugging and we aren't coming from WHMCS echo the page back out
		if ( $config->get( 'debug' ) && ! $headsig ) {
			$content	=	(string) implode( '', $parts );
			exit( $content );
		}

		// Encode the parts
		$hdr	=	base64_encode( array_shift( $parts ) );
		$ftr	=	base64_encode( array_pop( $parts ) );
		$string	=	json_encode( array( 'result' => 'success', 'htmlheader' => $hdr, 'htmlfooter' => $ftr, 'debug' => dunloader( 'debug', true )->renderforApi() ) );
		
		exit( $string );
	}


	/**
	 * System Event Handler: onAfterRoute
	 * @desc		After the system has parsed the route, J!WHMCS goes in and forces
	 * 				it's own component items into place.  This permits us to no longer
	 * 				parse the content for the menu item and makes menu item selection
	 * 				more intuitive
	 * @access		public
	 * @version		3.1.03 ( $id$ )
	 *
	 * @since		3.1.0
	 */
	public function onAfterRoute()
	{
		$input	=	dunloader( 'input', true );
		$input->setVar( 'option', 'com_integrator', 'get', true );
		$input->setVar( 'view', 'default', 'get', true );
	}
}