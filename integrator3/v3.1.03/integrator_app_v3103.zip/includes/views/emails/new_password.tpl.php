<html>
<body>
	<h3>New Password for <?php echo $identity;?></h3>
	<p>Your password has been reset to: <?php echo $new_password;?></p>
</body>
</html>