<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.1.1.0 ( $Id: integrator.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the main file for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die('Restricted access');

// Require the base controller
require_once (JPATH_COMPONENT.DS.'controller.php');
require_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'class.api.php' );
require_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'helper.php' );

$path = JApplicationHelper::getPath( 'class', 'com_integrator' );
include_once( $path );

// Require specific controller if requested
$controller = JRequest::getWord('controller', 'default');
require_once (JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php');

// Create the controller
$classname	= 'IntegratorController'.$controller;
$controller = new $classname();

// Perform the Request task
$controller->execute( JRequest::getWord('task'));

// Redirect if set by the controller
$controller->redirect();