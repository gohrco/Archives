<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.1.1.0 ( $Id: integrator.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.5.0
 * 
 * @desc       This is the main file for the backend of the Integrator
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

// Joomla 1.6+ Access check.
if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
	if (! JFactory::getUser()->authorise( 'core.manage', 'com_integrator' ) ) return JError::raiseWarning( 404, JText::_('JERROR_ALERTNOAUTHOR' ) );
}
/*-- Security Protocols --*/

/*-- File Inclusions --*/
require_once( JPATH_COMPONENT.DS.'controller.php' );
require_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'class.api.php' );
require_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'helper.php' );
/*-- File Inclusions --*/

define( 'INT_VERS', '3.0.1.1.0' );

if ( JRequest::getWord( 'controller' ) == null ) {
	JRequest::setVar( 'controller', 'default' );
}

if($controller = JRequest::getWord('controller')) {
	$path = JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php';
	if (file_exists($path)) {
		require_once $path;
	}
	else {
		$controller = '';
	}
}

// Create the controller
$classname	= 'IntegratorController'.$controller;
$controller	= new $classname( );

// Perform the Request task
$controller->execute( JRequest::getVar( 'task' ) );

// Redirect if set by the controller
$controller->redirect();