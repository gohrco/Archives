<table id="systemstatus">
	
	<thead>
		
		<tr>
			
			<th colspan="2" class="blank">
				
				<?php echo lang( 'help.sysstatus.hdr.connection' ); ?>
				
			</th>
			
			<th colspan="3" class="blank">
				
				<?php echo lang( 'help.sysstatus.hdr.settings' ); ?>
				
			</th>
			
			<th class="blank">&nbsp;</th>
			
		</tr>
		
		<tr>
			
			<th style="width: 180px; ">
				
				<?php echo lang( 'help.sysstatus.hdr.cnxnname' ); ?>
				
				<div class="sorter"></div>
				
			</th>
			
			<th style="text-align: center; width: 40px; ">
				
				<?php echo lang( 'help.sysstatus.hdr.active' ); ?>
				
			</th>
			
			<th style="text-align: center; width: 40px; ">
				
				<?php echo lang( 'help.sysstatus.hdr.user' ); ?>
				
			</th>
			
			<th style="text-align: center; width: 40px; ">
				
				<?php echo lang( 'help.sysstatus.hdr.visual' ); ?>
				
			</th>
			
			<th style="text-align: center; width: 40px; ">
				
				<?php echo lang( 'help.sysstatus.hdr.api' ); ?>
				
			</th>
			
			<th>
				
				<?php echo lang( 'help.sysstatus.hdr.software' ); ?>
				
				<div class="sorter"></div>
				
			</th>
			
		</tr>
		
	</thead>
	
	<tbody>
		
		<tr>
			
			<td colspan="6" class="statusLoading">
				
				<p><?php echo lang( 'help.systemstatus.loading' ); ?></p>
				
				<?php echo image( 'icon32-ajax.gif' ); ?>
				
			</td>
			
		</tr>
		
	</tbody>
	
</table>

<div id="masterOnbutton" style="display: none; "><?php echo image( 'icon32_statuson.png' ); ?></div>
<div id="masterOffbutton" style="display: none; "><?php echo image( 'icon32_statusoff.png' ); ?></div>

<script type="text/javascript">
function indicateState(value) {
	if ( value == 1 || value == true ) {
		return jQuery( "#masterOnbutton" ).html();
	}
	else {
		return jQuery( "#masterOffbutton" ).html();
	}
}

jQuery(document).ready( function() {

	jQuery("#systemstatus").tablesorter({
		headers: {
			0: { sorter: false },
			1: { sorter: false },
			2: { sorter: false },
			4: { sorter: false },
			5: { sorter: false },
			6: { sorter: false },
			7: { sorter: false }
		}
	});
	
	jQuery.get("<?php echo base_url( 'index.php/ajax/systemstatus' ); ?>", function( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		var html = null;
		jQuery.each( obj.html, function( index, value ) {
			html = html + '<tr>';
			html = html + '<td>' + value.name + ' (' + value.type + ')</td>';
			html = html + '<td style="text-align: center; ">' + indicateState(value.active) + '</td>';
			html = html + '<td style="text-align: center; ">' + indicateState(value.user) + '</td>';
			html = html + '<td style="text-align: center; ">' + indicateState(value.visual) + '</td>';
			html = html + '<td style="text-align: center; ">' + indicateState(value.ping) + '</td>';

			// Checks update state
			if ( value.current == true ) {
				html = html + '<td class="current">' + value.result;
			}
			else {
				html = html + '<td class="update">';
				jQuery.each( value.result, function ( key, val ) {
					html = html + '<p><strong>' + val.name + '</strong><br/><em>' + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + val.version + ' (released ' + val.released + ')</em></p>';
				});
				
			}
			html = html + '</td>';
			html = html + '</tr>';
		});
		
		// append the "ajax'd" data to the table body
		jQuery("table#systemstatus tbody").html( html );
		
		// let the plugin know that we made a update
		jQuery("table#systemstatus").trigger("update");
		 
   }); 
});

</script>