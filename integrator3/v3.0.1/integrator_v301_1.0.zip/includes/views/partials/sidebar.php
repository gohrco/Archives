<div id="main-nav">
	<ul id="menu-nav">
		<?php if ( isset( $nav ) ) : foreach ( $nav as $n ) : ?>
		<?php if ( isset( $n->submenu ) ) : ?>
		<li>
		<?php echo anchor ( $n->anchor, $n->text, 'class="top-link ' . ( $n->current ? 'current ' : '' ) . ( $n->class ? $n->class : '' ) . '"' ); ?>
		<ul>
			<?php foreach( $n->submenu as $o ) : ?>
			<?php echo '<li' . ($o->current ? ' class = "current">' : '>');
			?>
				<?php echo anchor( $o->anchor, $o->text, 'class="' . ( $o->current ? 'currentsub ' : '' ) . ( $o->class ? $o->class : '' ) . '"' ); ?>
			</li>
			<?php endforeach; ?>
		</ul></li>
		<?php else : ?>
		<?php echo '<li' . ($n->current ? ' class = "current">' : '>');
		//echo '<li>';
		?>
			<?php echo anchor( $n->anchor, $n->text, 'class="no-submenu ' . ( $n->current ? 'current ' : '' ) . ( $n->class ? $n->class : '' ) . '"' ); ?>
		</li>
		<?php endif; ?>
		<?php endforeach; endif; ?>
	</ul>
</div>