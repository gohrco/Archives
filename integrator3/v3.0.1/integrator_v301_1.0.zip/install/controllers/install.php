<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.1.0 ( $Id: install.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the install controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Install controller 
 * @version		3.0.1.1.0
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Install extends MY_Controller
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.1.1.0
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Checks to see if this is an upgrade or an install
	 * @access		public
	 * @version		3.0.1.1.0
	 * 
	 * @since		3.0.0
	 */
	public function index()
	{
		if ( $this->_is_upgrade() ) {
			redirect( 'upgrade' );
		}
		else {
			redirect( 'install/step1' );
		}
	}
	
	
	/**
	 * First step asking for acceptance of TOS
	 * @access		public
	 * @version		3.0.1.1.0
	 * 
	 * @since		3.0.0
	 */
	public function step1()
	{
		$fields	= & $this->fields_library;
		$fields->load( 'install/tos' );
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == true ) {
			$this->session->set_userdata( 'tosaccet', time() );
			redirect('install/step2', 'refresh');
		}
		
		$this->data['action']	= 'install/step1';
		$this->data	= array_merge( $this->data, $fields->render() );
		
		$this->build_page();
		$this->template
					->set_partial( 'body', 'tos' )
					->build( 'install', $this->data );
	}
	
	
	/**
	 * Second step in installation asking for database info
	 * @access		public
	 * @version		3.0.1.1.0
	 * 
	 * @since		3.0.0
	 */
	public function step2()
	{
		$fields	= & $this->fields_library;
		$fields->load( 'install/database' );
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == true ) {
			$this->session->set_userdata( 'tosaccet', time() );
			$this->session->set_userdata( 'hostname', $this->input->post( 'db_hostname' ) );
			$this->session->set_userdata( 'username', $this->input->post( 'db_username' ) );
			$this->session->set_userdata( 'password', $this->input->post( 'db_password' ) );
			$this->session->set_userdata( 'port', $this->input->post( 'db_port' ) );
			
			if ( $this->install->test_db_connection() ) {
				redirect('install/step3', 'refresh');
			}
			else {
				$this->data['error_message'] .= lang( 'error.dbinvalid' );
			}
		}
		
		$this->data['action']	= 'install/step2';
		$this->data['submit']	= 'button.step2';
		$this->data	= array_merge( $this->data, $fields->render() );
		
		$this->data['jsfooter']	= 'Hi there';
		$this->build_page();
		$this->template
					->set_partial( 'body', 'form' )
					->build( 'install', $this->data );
	}
	
	
	/**
	 * Third step in installation checking system requirements
	 * @access		public
	 * @version		3.0.1.1.0
	 * 
	 * @since		3.0.0
	 */
	public function step3()
	{
		$fields	= & $this->fields_library;
		$fields->load( 'install/reqs' );
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == true ) {
			redirect('install/step4', 'refresh');
		}
		
		$tests	= $this->install->server_tests();
		$fields->set_values( $tests );
		
		$items	= array();
		$items['php']		= (object) array( 'use' => $tests->php,		'msg' => sprintf( lang( ( $tests->php ? 'msg' : 'error' ) . '.php' ), $this->install->php_version ) );
		$items['mysql']		= (object) array( 'use' => $tests->mysql,	'msg' => sprintf( lang( ( $tests->mysql ? 'msg' : 'error' ) . '.mysql' ), $this->install->mysql_server_version, $this->install->mysql_client_version ) );
		$items['curl']		= (object) array( 'use' => $tests->curl,	'msg' => lang( ( $tests->curl ? 'msg' : 'error' ) . '.curl' ) );
		$items['ioncube']	= (object) array( 'use' => $tests->ioncube,	'msg' => sprintf( lang( ( $tests->ioncube ? 'msg' : 'error' ) . '.ioncube' ), $this->install->ioncube_version ) );
		
		$this->data['items']	= $items;
		$this->data['action']	= 'install/step3';
		$this->data['submit']	= 'button.' . ( in_array( false, (array) $tests ) ? 'tryagain' : 'step3' );
		
		$this->data	= array_merge( $this->data, $fields->render() );
		
		$this->build_page();
		$this->template
					->set_partial( 'body', 'reqs' )
					->build( 'install', $this->data );
	}
	
	
	/**
	 * Fourth step for install checking file permisssions
	 * @access		public
	 * @version		3.0.1.1.0
	 * 
	 * @since		3.0.0
	 */
	public function step4()
	{
		$fields = & $this->fields_library;
		$fields->load( 'install/dirs' );
		
		$this->form_validation->set_message( 'required', lang( 'reqd.perms' ) );
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == true ) {
			redirect( 'install/step5', 'refresh' );
		}
		
		$files	= $this->install->config_test();
		$dirs	= $this->install->directory_tests();
		$valid	= true;
		foreach ( $dirs as $d ) {
			if ( $d->use === false ) $valid = false;
		}
		
		$fields->set_values( array( 'files' => $files, 'dirs' => $valid ) );
		
		$fmsg	= ( is_string( $files ) ? 'error.' . $files : ( $files ? 'msg' : 'error' ) ) . '.files';
		$fmsg	= sprintf( lang( $fmsg ), BASEPATH );
		
		$items	= array();
		$items['files']		= (object) array( 'use' => ( is_string( $files ) ? false : $files ),	'msg' => $fmsg );
		$items['dirs']		= $dirs;
		
		$this->data['items']	= $items;
		$this->data['action']	= 'install/step4';
		$this->data['submit']	= 'button.' . ( ( is_string ( $files ) || $files === false ) ? 'tryagain' : 'step4' );
		
		$this->data	= array_merge( $this->data, $fields->render() );
		
		$this->build_page();
		$this->template
					->set_partial( 'body', 'reqs' )
					->build( 'install', $this->data );
	}
	
	
	/**
	 * The last step requiring information for install
	 * @access		public
	 * @version		3.0.1.1.0
	 * 
	 * @since		3.0.0
	 */
	public function step5()
	{
		$fields = & $this->fields_library;
		$fields->load( 'install/install' );
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == true ) {
			// Perform installation here
			if ( $this->install->run() === true ) {
				$baseurl = rtrim( base_url(), '/' );
				$pcs = explode( '/', $baseurl );
				array_pop( $pcs );
				$baseurl = implode( '/', $pcs );
				
				redirect( $baseurl . '/index.php/admin/complete', 'refresh' );
			}
			else {
				show_error( $this->install->get_error() );
			}
		}
		
		$this->data	= array_merge( $this->data, $fields->render() );
		
		$this->data['action']	= 'install/step5';
		$this->data['submit']	= 'button.step5';
		
		$this->build_page();
		$this->template
					->set_partial( 'body', 'form' )
					->build( 'install', $this->data );
	}
	
	
	/**
	 * Checks to see if this is an upgrade or install
	 * @access		public
	 * @version		3.0.1.1.0
	 * 
	 * @return		boolean true if upgrade, false if new install, redirect if already installed
	 * @since		3.0.0
	 */
	private function _is_upgrade()
	{
		// start by checking for configuration file
		if ( file_exists( BASEPATH . 'configuration.php' ) ) {
			$version = $this->install->get_previous_version();
			
			if ( in_array( $version, array( false, null ) ) ) return false;
			
			switch( version_compare( $version, INTEGRATOR_INSTALL ) ):
			// --------------------------------
			// Upgrade in order (newer vers in install)
			case -1:
				return true;
			break;
			// --------------------------------
			// Same version as installed (0) or installed version is newer than install folder (1)
			case 0:
			case 1:
				$baseurl = rtrim( base_url(), '/' );
				$pcs = explode( '/', $baseurl );
				array_pop( $pcs );
				$baseurl = implode( '/', $pcs );
				
				redirect( $baseurl . '/admin/complete/true', 'refresh' );
			break;
			// --------------------------------
			endswitch;
		}
		
		return false;
	}
}