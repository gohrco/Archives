<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.1.0 ( $Id: upgrade.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the upgrade controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Upgrade controller 
 * @version		3.0.1.1.0
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Upgrade extends MY_Controller
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.1.1.0
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->language( 'upgrade' );
	}
	
	
	/**
	 * Placeholder
	 * @access		public
	 * @version		3.0.1.1.0
	 * 
	 * @since		3.0.0
	 */
	public function index()
	{
		redirect( 'upgrade/step1', 'refresh' );
	}
	
	
	/**
	 * First step of the upgrade procedure to verify database
	 * @access		public
	 * @version		3.0.1.1.0
	 * 
	 * @since		3.0.0
	 */
	public function step1()
	{
		$fields	= & $this->fields_library;
		$fields->load( 'upgrade/backup' );
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == true ) {
			redirect('upgrade/step2', 'refresh');
		}
		
		$this->data['action']	= 'upgrade/step1';
		$this->data['submit']	= 'button.step1';
		
		$this->data	+= $fields->render();
		
		$this->build_page();
		$this->template
					->set_partial( 'body', 'form' )
					->build( 'install', $this->data );
	}
	
	
	/**
	 * Second step of upgrade to accept TOS again
	 * @access		public
	 * @version		3.0.1.1.0
	 * 
	 * @since		3.0.0
	 */
	public function step2()
	{
		$fields	= & $this->fields_library;
		$fields->load( 'upgrade/tos' );
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == true ) {
			$this->session->set_userdata( 'tosaccet', time() );
			redirect('upgrade/step3', 'refresh');
		}
		
		$this->data['action']	= 'upgrade/step2';
		$this->data	+= $fields->render();
		
		$this->build_page();
		$this->template
					->set_partial( 'body', 'tos' )
					->build( 'install', $this->data );
	}
	
	
	/**
	 * Third step to actually upgrade database
	 * @access		public
	 * @version		3.0.1.1.0
	 * 
	 * @since		3.0.0
	 */
	public function step3()
	{
		if ( $this->install->upgrade() === true ) {
			$baseurl = rtrim( base_url(), '/' );
			$pcs = explode( '/', $baseurl );
			array_pop( $pcs );
			$baseurl = implode( '/', $pcs );
			
			redirect( $baseurl . '/index.php/admin/complete/true', 'refresh' );
		}
		else {
			show_error( $this->install->get_error() );
		}
	}
}