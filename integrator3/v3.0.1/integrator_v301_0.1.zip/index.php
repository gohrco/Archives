<?php
/**
 * @projectName@
 * 
 * @package    @packageName@
 * @copyright  @copyWrite@
 * @license    @buildLicense@
 * @version    @fileVers@ ( $Id: index.php 13 2012-04-24 15:43:22Z steven_gohigher $ )
 * @author     @buildAuthor@
 * @since      3.0.0
 * 
 * @desc       This is the primary executable for the Integrator
 *  
 */


define( 'INTEGRATOR_VERSION', '@fileVers@' );

/*-- File Inclusions --*/
if ( file_exists( dirname(__FILE__) . DIRECTORY_SEPARATOR . 'configuration.php' ) ) {
	include( dirname(__FILE__) . DIRECTORY_SEPARATOR . 'configuration.php' );
}
else if ( is_dir( dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'install' ) && is_file( dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'install' . DIRECTORY_SEPARATOR . 'index.php' ) ) {
	
	// Since we can't trust that we aren't including the index.php file we must not use it
	$host  = $_SERVER['HTTP_HOST'];
	$uris	= explode( '/', str_replace( '\\', '/', dirname( $_SERVER['PHP_SELF'] ) ) );
	$newuri	= array();
	foreach( $uris as $u ) {
		if ( $u == 'index.php' ) break;
		$newuri[] = $u;
	}
	$newuri[]	= 'install';
	$newuri[]	= 'index.php';
	$uri		= implode( '/', $newuri );
	
	header( "Location: http://$host$uri" );
	exit();
}
else {
	exit( "Your configuration file is missing!" );
}
/*-- File Inclusions --*/

/**
 * **********************************************************************
 * ENVIRONMENT / ERROR REPORTING
 * **********************************************************************
 */

// Set the environment constant - can be specified in configuration.php
define('ENVIRONMENT', ( isset( $environment ) ? $environment : 'production' ) );

if (defined('ENVIRONMENT')) {
	switch (ENVIRONMENT) :
	// -----------------------------------------
	case 'development':
		define( 'ENVIRONMENT_LOG', '4' );
		error_reporting(E_ALL);
	break;
	// -----------------------------------------
	case 'testing':
		define( 'ENVIRONMENT_LOG', '1' );
		error_reporting(E_ALL);
	break;
	// -----------------------------------------
	case 'production':
		define( 'ENVIRONMENT_LOG', '0' );
		error_reporting(E_ALL);
	break;
	// -----------------------------------------
	default:
		exit('The application environment is not set correctly.');
	break;
	// -----------------------------------------
	endswitch;
}


/**
 * **********************************************************************
 * SYSTEM AND APPLICATION FOLDER NAMES
 * **********************************************************************
 */

// Set the system folder - can be specified in configuration.php to permit
//		testing of new versions of CI
$system_path		= ( isset( $int_systempath ) ? $int_systempath : '.' );

// Application folder must always be includes
$application_folder	= 'includes';


/**
 * **********************************************************************
 * RESOLVE PATH AND DECLARE CONSTANTS
 * **********************************************************************
 */

// Set the current directory correctly for CLI requests
if (defined('STDIN')) {
	chdir(dirname(__FILE__));
}

if (realpath($system_path) !== FALSE) {
	$system_path = realpath($system_path).'/';
}

// ensure there's a trailing slash
$system_path = rtrim($system_path, '/').'/';

// Is the system path correct?
if ( ! is_dir( $system_path ) ) {
	exit( "You are attempting to override the system path with an invalid path.  Please correct your configuration.php file and try again." );
}


// The name of THIS file
define('SELF', pathinfo(__FILE__, PATHINFO_BASENAME));

// The PHP file extension
define('EXT', '.php');

// Path to the system folder
define('BASEPATH', str_replace("\\", "/", $system_path));

// Path to the front controller (this file)
define('FCPATH', str_replace(SELF, '', __FILE__));

// Name of the "system folder"
define('SYSDIR', trim(strrchr(trim(BASEPATH, '/'), '/'), '/'));


// The path to the "application" folder
if (is_dir($application_folder)) {
	define('APPPATH', $application_folder.'/');
}
else {
	if ( ! is_dir(BASEPATH.$application_folder.'/')) {
		exit( "Your includes folder is missing.  Please reinstall the application and try again." );
	}
	
	define('APPPATH', BASEPATH.$application_folder.'/');
}

/**
 * **********************************************************************
 * ALL SET - LETS LOAD
 * **********************************************************************
 */

require_once BASEPATH.'core/CodeIgniter'.EXT;
