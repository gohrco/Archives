<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.1 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      3.0.1 (0.1)
 * 
 * @desc       This is the Find Updates Hook file for the Integrator
 *  
 */


/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * This checks for updates in the system
 * @version		3.0.1.0.1
 * 
 * @since		3.0.1 (0.1)
 */
function find_updates()
{
	$ci		= & get_instance();
	$ci->load->library( 'updates' );
	
	return $ci->updates->exist();
}