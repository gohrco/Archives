<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.1 ( $Id: install_check.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the install check Hook file for the Integrator
 *  
 */


/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


function install_check()
{
	$ci	= & get_instance();
	
	// Be sure we are in the admin backend and logged in
	if (	( ! in_array( $ci->router->fetch_class(), array( 'admin', 'settings', 'cnxns', 'pagemap', 'langmap', 'usermgr', 'users', 'license' ) ) ) ||	// Not in admin
			(
				( $ci->router->fetch_class() == 'admin' ) &&										// Admin
				( in_array( $ci->router->fetch_method(), array( 'login', 'logout', 'complete' ) ) )	// but not logged in
			 )
		) {
		return;
	}
	
	// Check to see if we have a path to the install
	if ( file_exists( BASEPATH . 'install/index.php' ) ) {
		include_once( BASEPATH . 'install/index.php' );
		
		$params		= & Params::getInstance();
		$current	=   $params->get( 'Version' );
		
		// If the current version is less than the install, we must upgrade
		if ( version_compare( $current, INTEGRATOR_INSTALL ) == -1 ) {
			redirect( BASE_URL . 'install/index.php');
		}
		
		// Remove the install folder then!
		if ( ( file_exists( BASEPATH . 'install' ) ) && ( is_really_writable( BASEPATH . 'install' ) ) ) {
			$ci->load->helper( 'file' );
			
			// Error Trapping
			if (! delete_files( BASEPATH . 'install', true ) ) {
				$ci->data['error_message'] = sprintf( lang( 'msg.error.installdir' ), BASEPATH . 'install' );
				return;
			}
			
			if (! @rmdir( BASEPATH . 'install' ) ) {
				$ci->data['error_message'] = sprintf( lang( 'msg.error.installdir' ), BASEPATH . 'install' );
				return;
			}
			
		}
		else if ( ( file_exists( BASEPATH . 'install' ) ) && (! is_really_writable( BASEPATH . 'install' ) ) ) {
			$ci->data['error_message'] = sprintf( lang( 'msg.error.installdir' ), BASEPATH . 'install' );
		}
		
		// Remove new config file
		if ( file_exists( BASEPATH . 'configuration.php.new' ) ) {
			if (! @unlink( BASEPATH . 'configuration.php.new' ) ) {
				$ci->data['error_message'] = sprintf( lang( 'msg.error.installconfignew' ), BASEPATH . 'install' );
				return;
			}
		}
		
		redirect( $ci->router->fetch_class() . '/' . $ci->router->fetch_method() );
		// End result:  user should remove install folder OR upgrade
	}
}