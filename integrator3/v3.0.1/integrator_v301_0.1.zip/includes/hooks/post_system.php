<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.1 ( $Id: post_system.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the Post System Hook file for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * Purges extra records in the log record once per day
 * @version		3.0.1.0.1
 * 
 * @since		3.0.0 (0.2)
 */
function debug_cleanup()
{
	$CI = & get_instance();
	$CI->load->library( 'Debug_library' );
	
	$data	= null;
	$data	= $CI->debug_library->get_output();
	
	if ( $data ) {
		$CI->session->set_userdata( array( 'debug' => serialize( $data ) ) );
	}

	return;
}