<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.1 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      3.0.1
 * 
 * @desc       This is the Updates library for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Updates library for pulling updates from Go Higher
 * @version		3.0.1.0.1
 * 
 * @since		3.0.1 (0.1)
 * @author		Steven
 */
class Updates
{
	/**
	 * Stores the path and filename to the local cert for SSL validation
	 * @access		protected
	 * @var			string
	 * @since		3.0.1 (0.1)
	 */
	protected $cacert			= null;
	
	/**
	 * Stores the filename containing the various updates we have already checked
	 * @access		protected
	 * @var			string
	 * @since		3.0.1 (0.1)
	 */
	protected $filename			= null;
	
	/**
	 * Stores the last time this object was run fully
	 * @access		protected
	 * @var			string
	 * @since		3.0.1 (0.1)
	 */
	protected $lastrun			= null;
	
	/**
	 * Stores the update site URLs gathered from the configuration file
	 * @access		protected
	 * @var			array
	 * @since		3.0.1 (0.1)
	 */
	protected $update_sites		= null;
	
	/**
	 * Stores what is the most recent version for each connection if cnxn is out of date
	 * @access		protected
	 * @var			array
	 * @since		3.0.1 (0.1)
	 */
	protected $updatedversions	= array();
	
	/**
	 * Stores all the updates gathered from Go Higher from last curl run
	 * @access		protected
	 * @var			array
	 * @since		3.0.1 (0.1)
	 */
	protected $updates			= array();
	
	/**
	 * Stores the current version of the cnxn items
	 * @access		protected
	 * @var			array
	 * @since		3.0.1 (0.1)
	 */
	protected $versions			= array();
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.1 (0.1)
	 */
	public function __construct( $options = array() )
	{
		$force	= isset( $options['force'] ) ? $options['force'] : false;
		
		// STEP 1:  Initialize object
		$this->init_object();
		
		// CLEAR if requested to (force == true)
		if ( $force ) $this->_wipe_store();
		
		// STEP 2:  Read the store
		$this->read_store();
		
		// STEP 3:  Find Updates online
		$this->find_updates();
		
		// STEP 4:  Find current versions
		$this->check_versions();
		
		// STEP 5:  Compare to current
		$this->compare_versions();
		
		// STEP 6:  write to store
		$this->write_store();
	}
	
	
	/**
	 * Retrieves the current versions of the connections
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.1 (0.1)
	 */
	public function check_versions()
	{
		// If we dont need to run this then bypass
		if ( $this->_check_last_run() ) return;
		
		// First we will get the current app version
		$params				= & Params :: getInstance();
		$this->versions[0]['application']	=   $params->get( 'Version' );
		
		// Cycle through the cnxn types we have to get their versions
		$apis = get_apis();
		
		foreach ( $apis as $id => $api ) {
			if (! method_exists( $api, 'get_info' ) ) continue;
			$result	= $api->get_info();
			foreach( $this->versions[$id] as $a => $n ) {
				$this->versions[$id][$a] = $result[$a];
			}
		}
	}
	
	
	/**
	 * Method to compare versions of existing cnxns to most updated type
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.1 (0.1)
	 */
	public function compare_versions()
	{
		$versions			= $this->versions;
		$updatedversions	= array();
		
		foreach ( $versions as $id => $version ) {
			if ( is_array( $version ) ) foreach ( $version as $name => $item ) {
				if ( empty( $item ) ) continue;
				if ( version_compare( $this->updates[$name]['version'], $item, 'g' ) ) {
					$updatedversions[$id][$name] = $this->updates[$name];
				}
			}
		}
		
		$this->updatedversions	= $updatedversions;
	}
	
	
	/**
	 * Method to determine if in face there are any updates available
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		boolean
	 * @since		3.0.1 (0.1)
	 */
	public function exist()
	{
		$up2date = $this->updatedversions;
		
		return empty( $up2date ) ? false : true;
	}
	
	
	/**
	 * Finds the updates from Go Higher
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.1 (0.1)
	 */
	public function find_updates()
	{
		// If we dont need to run this then bypass
		if ( $this->_check_last_run() ) return;
		
		// Extract the download URLs
		$sites		= $this->_extract_sites();
		$updates	= array();
		
		foreach ( $sites as $name => $url )
		{
			$result		= $this->_get_updates( $url );
			$version	= null;
			$latest		= null;
			if ( isset( $result['update'] ) ) foreach ( $result['update'] as $res ) {
				if ( version_compare( $res['version'], $latest, 'g' ) ) {
					$latest		= $res['version'];
					$version	= $res;
				}
			}
			$updates[$name] = $version;
		}
		
		$this->updates	= $updates;
	}
	
	
	/**
	 * Builds and returns the update arrays for displaying to the administrator
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		array
	 * @since		3.0.1 (0.1)
	 */
	public function get_update_array()
	{
		if (! $this->exist() ) return array();
		
		$data = array();
		
		foreach ( $this->updatedversions as $id => $updates ) foreach( $updates as $update ) {
			
			if ( $id === 0 ) {
				$name	= 'Integrator 3 Application';
				$type	= 'application';
			}
			else {
				$cnxn	= cnxn( $id );
				$name	= $cnxn->get( 'name' );
				$type	= $cnxn->get( 'type' );
			}
			
			$data[]	= array(
						'name' => $name,
						'type'	=> ucfirst( $type ),
						'desc'	=> $update['description'],
						'version'	=> $update['version'],
						'release'	=> $update['release_date']
					);
		}
		
		return $data;
	}
	
	
	/**
	 * Method to retrieve the update list for a given connection
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		integer		- $id: the cnxnid to check for
	 * 
	 * @return		array
	 * @since		3.0.1 (0.1)
	 */
	public function get_update_list( $id = 0 )
	{
		$updates	= $this->updatedversions;
		
		$id = (int) $id;
		
		if (! isset( $updates[$id] ) ) return array();
		
		$updates	= $updates[$id];
		$data		= array();
		
		foreach( $updates as $update ) {
			$data[]	= array( 'name' => $update['description'], 'released' => $update['release_date'], 'version' => $update['version'] );
		}
		
		return $data;
	}
	
	
	/**
	 * Method to initialize the object
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.1 (0.1)
	 */
	public function init_object()
	{
		// Grab Global things
		$ci		= & get_instance();
		$params	= & Params :: getInstance();
		
		// Load config in case it hasnt been
		$ci->load->config( 'updates', true );
		
		// Set the filename
		$filepath		=   $params->get( 'TmpDir' ) . DIRECTORY_SEPARATOR;
		$this->filename	=   $filepath . 'updates.ini';
		
		// Set the CA file
		$this->cacert	=   BASEPATH . APPPATH . 'assets' . DIRECTORY_SEPARATOR . 'cacert.pem';
		
		// Pull the updates config to local
		$config	= $ci->config->item( 'updates' );
		
		// Set the update sites array
		$this->update_sites = $this->_extract_sites( $config['update_sites'] );
		
		// Pull the update sites and create an empty array of types to use
		$this->updates	= object_to_array( $this->update_sites, false );
		
		// Don't forget to set the I3 version
		$this->versions[0] = array( 'application' => null );
		
		// Grab the cnxns and use the ID as an identifier for the version array
		$cnxns = get_cnxns();
		foreach ( $cnxns as $id => $cnxn ) {
			$type = $cnxn->get( 'type' );
			$this->versions[$id] = $config['cnxns']["{$type}"];
		}
	}
	
	
	/**
	 * Method to determine if a given connection is current or not
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		integer		- $id: the cnxn id being checked
	 * 
	 * @return		boolean
	 * @since		3.0.1 (0.1)
	 */
	public function is_current( $id = 0 )
	{
		$updates	= $this->updatedversions;
		
		$id = (int) $id;
		
		if (! isset( $updates[$id] ) ) return true;
		else if ( empty( $updates[$id] ) ) return true;
		else return false;
	}
	
	
	/**
	 * Method to read the stored data from the file
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		array of data or false on error
	 * @since		3.0.1 (0.1)
	 */
	public function read_store()
	{
		// If the store doesn't exist return false
		if(! ( $data = read_file( $this->filename ) ) )
		{
			return false;
		}
		
		// json decode store and place in object
		$data	= json_decode( $data, true );
		
		// If we have the last run variable
		if ( isset( $data['lastrun'] ) )
		{
			// If the last run wasn't today then delete file and return false
			if (! $this->_check_last_run( $data['lastrun'] ) )
			{
				$this->wipe_store();
				return false;
			}
		}
		
		// Grab the store and stick it here
		if ( is_array( $data ) ) foreach ( $data as $key => $value ) {
			$this->$key = $value;
		}
		
		return $data;
	}
	
	
	/**
	 * Method to write the data to the file store
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		boolean
	 * @since		3.0.1 (0.1)
	 */
	public function write_store()
	{
		if ( file_exists( $this->filename ) ) {
			@unlink( $this->filename );
		}
		
		$data	= array(	'updates'			=> $this->updates,				// Most recent updates from Go Higher for cnxn types
							'versions'			=> $this->versions,				// Last check of current versions
							'lastrun'			=> date( "Y-m-d" ),				// Last time check was performed
							'updatedversions'	=> $this->updatedversions );	// Array of cnxnid => recent update from Go Higher
		
		$data	= json_encode( $data );
		
		return write_file( $this->filename, $data );
	}
	
	
	/**
	 * Common method to check the last time we ran this
	 * @access		private
	 * @version		3.0.1.0.1
	 * @param		string		- $lastrun: contains a date in format Y-m-d or null (defaults to $this->lastrun if null)
	 * 
	 * @return		boolean
	 * @since		3.0.1 (0.1)
	 */
	private function _check_last_run( $lastrun = null )
	{
		if ( $lastrun == null ) $lastrun = $this->lastrun;
		return $lastrun == date( "Y-m-d" );
	}
	
	
	/**
	 * Method to pull the site URLs from the update_sites object for calling
	 * @access		private
	 * @version		3.0.1.0.1
	 * @param		mixed		- $array: contains either the object or an array
	 * @param		string		- $path: the key name to create for recursion purposes
	 * 
	 * @return		array of download URLs
	 * @since		3.0.1 (0.1)
	 */
	private function _extract_sites( $array = array(), $path = null )
	{
		if ( empty( $array ) ) $array = $this->update_sites;
		$data = array();
		
		foreach( $array as $k => $v )
		{
			$path = $k;
			if ( is_string( $v ) ) {
				$data[$path] = $v;
				continue;
			}
			
			if ( (! is_object( $v ) ) && (! is_array( $v ) ) ) continue;
			
			$callup	= $this->_extract_sites( $v, $path );
			
			if ( empty( $callup ) ) continue;
			
			foreach ( $callup as $k2 => $v2 ) {
				$data[$path.'|'.$k2] = $v2;
			}
			
			
		}
		
		return $data;
	}
	
	
	/**
	 * Method to retrieve the updates given a url
	 * @access		private
	 * @version		3.0.1.0.1
	 * @param		string		- $url:  the url to retrieve the updates from
	 * 
	 * @return		array of updates from site
	 * @since		3.0.1 (0.1)
	 */
	private function _get_updates( $url )
	{
		$ci		= & get_instance();
		$curl	= & $ci->curl;
		
		$options	= array(	'CAINFO'			=> $this->cacert,
								'HEADER'			=> false,
								'RETURNTRANSFER'	=> true
		);
		
		$response	= $curl->simple_post( $url, array(), $options );
		
		$xml		= simplexml_load_string( $response );
		
		if ( $xml === false ) return array();
		
		$data		= simpleXMLToArray( $xml );
		
		return $data;
	}
	
	
	/**
	 * Method to wipe the store from the tmp folder
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @return		boolean
	 * @since		3.0.1 (0.1)
	 */
	private function _wipe_store()
	{
		return @unlink( $this->filename );
	}
}