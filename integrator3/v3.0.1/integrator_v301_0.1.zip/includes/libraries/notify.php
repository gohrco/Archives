<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Notification class for sending emails out
 * @version		3.0.1.0.1
 * 
 * @since		3.0.0
 * @author		Steven
 */
class Notify
{
	/**
	 * Reference to CI email class
	 * @access		private
	 * @since		3.0.0
	 * @var			object
	 */
	private	$email			= null;
	
	/**
	 * Properties holder
	 * @access		public
	 * @since		3.0.0
	 * @var			array
	 */
	public	$_properties	= array();
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		$ci = & get_instance();
		$this->email = & $ci->email;
	}
	
	
	/**
	 * Sends an email message
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		$msg: a message type to send
	 * @param		array		$data: array of data items to embed in the email message
	 * @param		varies		$email: who to send the message to
	 * 
	 * @since		3.0.0
	 */
	public function send( $msg, $data = array(), $email = 'all' )
	{
		$ci			= & get_instance();
		$tpl		=   null;
		$subject	=   null;
		$config		=   array();
		$return		=   false;
		
		// Build the user array to cycle through
		$users	= $this->_clean_email( $email );
		
		// Retrieve the email template
		switch ( $msg ) {
			case 'failed_login':
				$subject			= 'Failed Login Attempt';
				$config['priority']	= 1;
				break;
			case 'forgot_password':
				$subject			= 'Forgotten Password Verification - ';
				break;
			case 'new_password':
				$subject			= 'New Password - ';
				$config['priority']	= 2;
				break;
		}
		
		// Do some sort of error here
		if ( $subject == null ) return false;
		$tpl	.= $msg . '.tpl.php';
		
		// Grab the from fields
		$params	= & Params::getInstance();
		
		// Build the body
		$message = $ci->load->view( 'emails/' . $tpl, $data, true);
		
		// Build the subject
		if ( strpos( $subject, ' - ' ) !== false ) {
			$subject .= $params->get( 'Sitename', 'Integrator', 'global' );
		}
		
		// Cycle through emails and send out
		foreach ( $users as $user ) {
			$ci->email->clear();
			$ci->email->initialize($config);
			$ci->email->to( $user->email );
			$ci->email->from( $params->get( 'Emailaddress', 'admin@domain.com' ), $params->get( 'Emailfromname', 'Integrator' ) );
			$ci->email->subject( $subject );
			$ci->email->message( $message );
			$return	= $ci->email->send();
		}
		
		return $return;
	}
	
	
	/**
	 * Handles the email variable passed to the library
	 * @access		private
	 * @version		3.0.1.0.1
	 * @param		varies		$email: 'all' => all admin emails, string or array of email addresses
	 * 
	 * @return		array of user objects
	 * @since		3.0.0
	 */
	private function _clean_email( $email )
	{
		$emails = array();
		if ( $email == 'all' ) {
			$emails = $this->_get_admin_emails();
		}
		else if ( is_string( $email ) ) {
			if ( strpos( $email, ',' ) !== false ) {
				$email	= explode( ',', $email );
			}
			else {
				$email	= array( $email );
			}
			$emails	= $this->_clean_email( $email );
		}
		else if ( is_array( $email ) ) {
			foreach( $email as $e ) {
				$emails[]	= $this->_get_email_info( $e );
			}
		}
		return $emails;
	}
	
	
	/**
	 * Single place to create a user object for emailing purposes
	 * @access		private
	 * @version		3.0.1.0.1
	 * @param		array		$user: contains a row of user data from the database
	 * 
	 * @return		array of assembled data
	 * @since		3.0.0
	 */
	private function _clean_user_array( $user )
	{
		$data	= array();
		$data['name']	= $user->first_name . ' ' . $user->last_name;
		$data['email']	= $user->email;
		return $data;
	}
	
	
	/**
	 * Gets all admin email addresses and assembles their data
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @return		array of admin user objects
	 * @since		3.0.0
	 */
	private function _get_admin_emails()
	{
		$ci		= & get_instance();
		$users	=   $ci->auth_model->get_active_users( 'admin' );
		$data	=   array();
		
		foreach( $users->result() as $user ) {
			$data[]	= (object) $this->_clean_user_array( $user );
		}
		
		return $data;
	}
	
	
	/**
	 * Gets the user information for a specific email address
	 * @access		private
	 * @version		3.0.1.0.1
	 * @param		string		$email: an email address
	 * 
	 * @return		object containing user data
	 * @since		3.0.0
	 */
	private function _get_email_info( $email )
	{
		$ci		= & get_instance();
		$users	=   $ci->auth_model->get_user_by_email( $email );
		$data	=   false;
		
		foreach ( $users->result() as $user ) {
			$data	= (object) $this->_clean_user_array( $user );
		}
		
		return $data;
	}
	
	
	/**
	 * Gets a variable from the object
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $name: the name of the property to get
	 * @param		mixed		- $default: the default value to return if not set
	 * @param		string		- $type: if a parameter, then send the parameter type
	 * 
	 * @return		the value of the property or false on not set
	 * @since		3.0.0
	 */
	public function get( $name, $default = false, $type = 'local' )
	{
		switch( $type ) {
			case 'local':
				return (isset( $this->$name ) ? $this->$name : $default );
				break;
			case 'params':
			default:
				return ( isset( $this->params[$type][$name] ) ? $this->params[$type][$name] : $default );
				break;
		}
	}
	
	
	/**
	 * Gets the properties from the object
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		boolean		- $public: if true only returns public properties
	 * 
	 * @return		array of properties from object
	 * @since		3.0.0
	 */
	public function get_properties( $public = true )
	{
		$vars	= get_object_vars( $this );
		if ( $public ) {
			foreach ( $vars as $key => $value ) {
				if ( in_array( $key, array( 'app_obj', 'site_obj' ) ) ) {
					unset( $vars[$key] );
					continue;
				}
				if ( '_' == substr( $key, 0, 2 ) ) {
					unset( $vars[$key] );
				}
			}
		}
		return $vars;
	}
	
	
	/**
	 * Handles settings specific values to the object
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $name: the property to set
	 * @param		mixed		- $value: the value to set property to
	 * 
	 * @return		instance of object
	 * @since		3.0.0
	 */
	public function set( $name, $value, $type = 'local' )
	{
		switch( $type ) {
			case 'local':
				$this->$name = $value;
				break;
			case 'params':
			default:
				$this->params[$type][$name] = $value;
				break;
		}
		return $this;
	}
	
	
	/**
	 * Sets properties for the object in one fell swoop
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		array		- $data: contains assoc array of the properties to set
	 * 
	 * @return		instance of object
	 * @since		3.0.0
	 */
	public function set_properties( $data )
	{
		if (! is_array( $data ) ) return false;
		ksort( $data );
		foreach ( $data as $k => $v ) {
			$this->$k = $v;
		}
		return $this;
	}
	
	
	/**
	 * Getter method
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $name: the name of the property to get
	 * 
	 * @return		mixed the value of the property or null if not set
	 * @since		3.0.0
	 */
	public function __get( $name )
	{
		return ( isset( $this->__properties[$name] ) ? $this->__properties[$name] : null );
	}
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $name: the name of the property to set
	 * @param		mixed		- $value: the value to set the property to
	 * 
	 * @since		3.0.0
	 */
	public function __set( $name, $value )
	{
		$this->__properties[$name] = $value;
	}
}