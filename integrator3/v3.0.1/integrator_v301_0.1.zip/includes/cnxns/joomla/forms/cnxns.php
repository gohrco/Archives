<?php

$form['globals']	= array(
	'name'	=> array(
		'value'			=> "",
		'order'			=> 5,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'url' => array(
		'value'			=> "http://",
		'order'			=> 10,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'active' => array(
		'value'			=> null,
		'order'			=> 20,
		'type'			=> 'yesno',
		'validation'	=> ''
	),
	'ismultisite' => array(
		'value'			=> 0,
		'order'			=> 30,
		'type'			=> 'yesno',
		'validation'	=> 'required'
	),
	'type' => array(
		'value'			=> null,
		'order'			=> 100,
		'type'			=> 'hidden',
		'validation'	=> ''
	),
	'id' => array(
		'value'			=> null,
		'order'			=> 110,
		'type'			=> 'hidden',
		'validation'	=> ''
	),
);

$form['api']	= array(
	'apiurl' => array(
		'value'			=> "http://",
		'order'			=> 10,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'sslverify' => array(
		'value'			=> 0,
		'order'			=> 20,
		'type'			=> 'yesno',
		'validation'	=> 'required'
	),
	'username' => array(
		'value'			=> null,
		'order'			=> 30,
		'type'			=> 'text',
		'validation'	=> 'required'
	),
	'password' => array(
		'value'			=> null,
		'order'			=> 40,
		'type'			=> 'password',
		'validation'	=> 'required'
	)
);

$form['users'] = array (
	'userenable' => array(
		'value'			=> 0,
		'order'			=> 10,
		'type'			=> 'yesno',
		'validation'	=> 'required'
	),
	'processlogin' => array(
		'value'			=> 0,
		'order'			=> 20,
		'type'			=> 'dropdown',
		'validation'	=> 'required',
		'list'			=> array( 'always', 'whenconnected', 'never' )
	),
	'usessl' => array(
		'value'			=> 'ignore',
		'order'			=> 22,
		'type'			=> 'dropdown',
		'validation'	=> 'required',
		'list'			=> array( 'none', 'force', 'ignore' )
	),
	'loginurl'	=> array(
		'value'			=> 'http://',
		'order'			=> 25,
		'type'			=> 'text',
		'validation'	=> ''
	),
	'logouturl' => array(
		'value'			=> 'http://',
		'order'			=> 30,
		'type'			=> 'text',
		'validation'	=> ''
	),
	'storeusername' => array(
		'value'			=> 'random',
		'order'			=> 40,
		'type'			=> 'dropdown',
		'validation'	=> 'required',
		'list'			=> array( 'first.last', 'last.first', 'random', 'flastname','firstnamel', 'firstname', 'lastname' )
	),
	'storename' => array(
		'value'			=> 'firstlast',
		'order'			=> 50,
		'type'			=> 'dropdown',
		'validation'	=> 'required',
		'list'			=> array( 'firstlast', 'firstlastco', 'lastfirst', 'lastfirstco' )
	),
	'usernametype' => array(
		'value'			=> 'username',
		'order'			=> 60,
		'type'			=> 'dropdown',
		'validation'	=> 'required',
		'list'			=> array( 'username', 'email' )
	),
	'forceadd' => array(
		'value'			=> 1,
		'order'			=> 70,
		'type'			=> 'yesno',
		'validation'	=> 'required'
	),
	'forcepwupdate' => array(
		'value'			=> 1,
		'order'			=> 80,
		'type'			=> 'yesno',
		'validation'	=> 'required'
	),
);

$form['visuals'] = array(
	'visualenable' => array(
		'value'			=> 0,
		'order'			=> 10,
		'type'			=> 'yesno',
		'validation'	=> 'required'
	),
	'sslenabled' => array(
		'value'			=> 0,
		'order'			=> 20,
		'type'			=> 'yesno',
		'validation'	=> 'required'
	),
	'imgurl' => array(
		'value'			=> null,
		'order'			=> 30,
		'type'			=> 'text',
		'validation'	=> ''
	)
);