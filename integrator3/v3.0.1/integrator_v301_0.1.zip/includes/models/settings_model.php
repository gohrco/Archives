<?php
/* SECURITY CHECKPOINT */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Settings model
 * @access		public
 * @author		Steven
 * 
 * @since		3.0.0
 */
class Settings_Model
{
	/* GLOBAL SETTINGS */
	public	$Sitename			= null;						/* Site name */
	public	$Enable				= false;					/* Global Enable */
	public	$Version			= null;						/* Version of Integrator */
	public	$Debug				= false;					/* Enable Debug */
	
	/* SYSTEM SETTINGS */
	public	$SystemURL			= '';						/* System URL for Integrator 3 */
	public	$SystemSSL			= false;					/* Enable use of SSL on I3 */
	public	$TmpDir				= '';						/* Temporary directory to store cookies in */
	public	$LogCount			= 1000;						/* Maximum number of log records to store in database */
	
	/* EMAIL SETTINGS */
	public	$Emailprotocol		= null;						/* Email Protocol used */
	public	$Emailsmtpport		= 25;						/* Email SMTP port */
	public	$Emailsmtphost		= null;						/* Email SMTP hostname */
	public	$Emailsmtpuser		= null;						/* Email SMTP username */
	public	$Emailsmtppass		= null;						/* Email SMTP password */
	public	$Emailfromname		= null;						/* Email Admin from name */
	public	$Emailaddress		= 'admin@gohigheris.com';	/* Email Admin from address */
	
	/* USER SETTINGS */
	public	$EnableUser			= false;					/* Enable User Integration */
	public	$DisplayLogin		= true;						/* Turns on the "Logging In" screen when logging in and out */
	public	$LoginMsg			= '';						/* Login Message for iframe version */
	public	$LogoutMsg			= '';						/* Log out Message for iframe version */
	public	$UseSSL				= false;					/* Use SSL on Login / Logout */
	public	$SessionTimeout		= 7200;						/* User Session Timeout (in seconds) */
	public	$Defaultuser		= null;						/* Primary User Database */
	
	/* VISUAL SETTINGS */
	public	$EnableVisual		= false;					/* Enable Visual Integration */
	public	$Defaultvisual		= null;						/* Default Visual Site */
	public	$UnicodeMatching	= false;					/* Use Unicode Matching in regular expressions */
	public	$Cache				= false;					/* Enable Caching for Visual Integration */
	public	$CacheTTL			= 300;						/* Set the Time To Live for caching (in seconds) */
	public	$Clearcache			= false;					/* Clear the cache */
	
	/* REGISTRATION SETTINGS */
	public	$EnableRegistration	= true;						/* Enable Integrated Registration */
	public	$EnableCSValidation = true;						/* Enable AJAX Use */
	public	$RegRedirectionUrl	= null;						/* Redirect User to this URL when complete */
	public	$DefaultVisualreg	= null;						/* Default visually integrated page to use */
	public	$DefaultCountry		= 'US';						/* Default Country Code */
	public	$RecaptchaEnable	= null;						/* Enable use of reCaptcha */
	public	$RecaptchaPublickey	= null;						/* reCaptcha public key */
	public	$RecaptchaPrivatekey= null;						/* reCaptcha private key */
	public	$RecaptchaTheme		= null;						/* reCaptcha theme */
	public	$RecaptchaLang		= null;						/* reCaptcha language */
	public	$PasswordText		= "This password is insufficient"; /* Password Strength text */
	public	$PasswordStrength	= false;					/* Display Password Strength Field */
	public	$BanFreebies		= false;					/* Ban free email accounts */
	public	$EmailfreeText		= "Our system does not permit emails from that domain"; /* Ban Freebies Error text */
	public	$FieldOrder			= null;						/* Registration field order */
	
	/* API SETTINGS */
	public	$Secret				= null;						/* API Secret Key */
	
	/* HIDDEN SETTINGS */
	public	$License			= null;						/* Integrator License */
	public	$LocalKey			= null;						/* Local copy of License Key */
	public	$Messages			= null;						/* Stores the display of the boxes in the admin area */
	public	$LogPurge			= null;						/* Stores the last time the log file was purged */
	
	
	/**
	 * Stores data to bind to the database
	 * @access		private
	 * @since		3.0.0
	 * @var			array
	 */
	private $_data			= array();
	
	/**
	 * Stores undeclared settings for this object here
	 * @access		private
	 * @since		3.0.0
	 * @var			array
	 */
	private $_properties	= array();
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		$CI = & get_instance();
		$CI->load->database();
		
		// Initialize from database
		$this->load();
	}
	
	
	/**
	 * Binder method
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		array		- $data: contains an associative array of data to bind ( array ( key => value ) )
	 * 
	 * @return		boolean true on success
	 * @since		3.0.0
	 */
	public function bind( $data = array() )
	{
		if ( empty( $data ) ) return false;
		
		$this->set( "_data", null );
		$bind	= array();
		
		foreach ( $data as $k => $v ) {
			if ( $k == "Messages" ) $v = (! is_string( $v ) ? json_encode( $v ) : $v );
			$bind[]	= (object) array( 'key' => $k, 'value' => $v );
		}
		
		if ( $this->Clearcache == '1' ) {
			$CI = & get_instance();
			$CI->load->driver('cache', array( 'adapter' => 'apc', 'backup' => 'file' ) );
			$CI->cache->apc->is_supported();
			if ( is_object( $CI->cache ) ) {
				$CI->cache->clean();
			}
		}
		
		$this->Clearcache = false;
		
		$this->set( "_data", $bind );
		return true;
	}
	
	
	/**
	 * Check method to ensure data is consistant
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		boolean true on success
	 * @since		3.0.0
	 */
	public function check()
	{
		$data = $this->get( "_data", array() );
		
		if ( empty( $data ) ) return false;
		
		for ( $i=0; $i<count( $data ); $i++ ) {
			if ( in_array( $data[$i]->key, array( 'SessionTimeout', 'CacheTTL' ) ) ) {
				$data[$i]->value = $data[$i]->value * 60;
			}
			if ( in_array( $data[$i]->key, array( 'Messages', 'FieldOrder' ) ) ) {
				if (! is_string( $data[$i]->value ) ) $data[$i]->value = json_encode( $data[$i]->value );
			}
		}
		
		$this->set( "_data", $data );
		return true;
	}
	
	
	/**
	 * Retrieve settings from the model - reinitializing if set
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $name: string containing setting to get or NULL to get all
	 * 
	 * @return		value of requested setting or array of all settings or false if non-existant
	 * @since		3.0.0
	 */
	public function get( $name = NULL, $default = null )
	{
		return ( isset( $this->$name ) ? $this->$name : $default );
	}
	
	
	/**
	 * Gets all properties or just public ones
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		boolean		- $public: if true just public properties or else everything
	 * 
	 * @return		array containing object properties
	 * @since		3.0.0
	 */
	public function get_properties( $public = true )
	{
		$vars = get_object_vars( $this );
		
		if ( $public ) {
			foreach ($vars as $key => $value) {
				if ( in_array( $key, array( 'SessionTimeout', 'CacheTTL' ) ) ) {
					$vars[$key] = ( $value / 60 );
				}
				
				if ('_' == substr($key, 0, 1)) {
					unset($vars[$key]);
				}
			}
		}
		
		return $vars;
	}
	
	
	/**
	 * Loads values from the database
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function load( $key = null )
	{
		$CI		= & get_instance();
		
		$result	=   $CI->db->select( 'key, value')->from( 'settings' )->get();
		$data	=   array();
		
		if ( $result->num_rows() > 0 ) {
			foreach( $result->result() as $row ) {
				if ( in_array( $row->key, array( 'SessionTimeout', 'CacheTTL' ) ) ) {
					$row->value = ( $row->value / 60 );
				}
				if ( in_array( $row->key, array( 'Messages', 'FieldOrder' ) ) ) {
					$row->value = json_decode( $row->value, true );
				}
				$data[$row->key] = $row->value;
			}
		}
		
		$this->set_properties( $data );
	}
	
	
	/**
	 * Save method to save data to the database
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		array		- $data: an associative array of data ie array( key1 => value1, key2 => value2 )
	 * 
	 * @return		boolean true on success
	 * @since		3.0.0
	 */
	public function save( $data = null )
	{
		if ( $data == null ) {
			$data	= $this->get_properties();
		}
		
		if (! $this->bind( $data ) ) {
			$this->set( "_data", null );
			return false;
		}
		
		if (! $this->check() ) {
			$this->set( "_data", null );
			return false;
		}
		
		if (! $this->store() ) {
			return false;
		}
		
		// Reload data to object
		$this->load();
		
		return true;
	}
	
	
	/**
	 * Setter method for setting an item to object
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $name: the name of the property to set
	 * @param		varies		- $value: the value to set
	 * 
	 * @since		3.0.0
	 */
	public function set( $name, $value )
	{
		$previous = isset( $this->$name ) ? $this->$name : null;
		$this->$name = $value;
		return $previous;
	}
	
	
	/**
	 * Sets an array of properties to the object all at once
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		array		- $data: an associative array of properties to set (array( k1 => v1, k2 ... ))
	 * 
	 * @since		3.0.0
	 */
	public function set_properties( $data = array() )
	{
		foreach ( $data as $k => $v ) {
			if ( in_array( $k, array( 'SessionTimeout', 'CacheTTL' ) ) ) {
				$v = ( $v * 60 );
			}
			
			$this->set( $k, $v );
		}
	}
	
	
	/**
	 * Stores the bound and checked data to the database
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		boolean true on success
	 * @since		3.0.0
	 */
	public function store()
	{
		$CI		= & get_instance();
		$data	=   $this->get( "_data", array() );
		if ( empty( $data ) ) return false;
		$this->set( "_data", null );
		foreach ( $data as $d ) {
			$exist = $CI->db->get_where( 'settings', array( 'key' => $d->key ) );
			if ( $exist->num_rows() > 0 ) {
				$CI->db->update( 'settings', $d, array( 'key' => $d->key ) );
			}
			else {
				$CI->db->insert( 'settings', $d );
			}
		}
		
		return true;
	}
	
	/**
	 * Getter method
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $name: the name of the property to get
	 * 
	 * @return		mixed the value of the property or null if not set
	 * @since		3.0.0
	 */
	public function __get( $name )
	{
		return ( isset( $this->_properties[$name] ) ? $this->_properties[$name] : null );
	}
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $name: the name of the property to set
	 * @param		mixed		- $value: the value to set the property to
	 * 
	 * @since		3.0.0
	 */
	public function __set( $name, $value )
	{
		$this->_properties[$name] = $value;
	}
}