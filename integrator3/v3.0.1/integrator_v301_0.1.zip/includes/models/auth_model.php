<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.1 ( $Id: auth_model.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the authentication model for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Auth Model
 * @version		3.0.1.0.1
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Auth_model extends CI_Model
{
	/**
	 * Stores the activation code if generated
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public $activation_code;
	
	/**
	 * Stores the column names used in the database
	 * @access		public
	 * @since		3.0.0
	 * @var			array
	 */
	public $columns	= array('first_name', 'last_name', 'company', 'phone');
	
	/**
	 * Stores the forgotten password code if set
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public $forgotten_password_code;
	
	/**
	 * Stores the identity of a user
	 * @access		public
	 * @since		3.0.0
	 * @var			array
	 */
	public $identity;
	
	/**
	 * The column that identifies a user
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public $identity_column	= 'username';
	
	/**
	 * Indicates which field to join the meta table by
	 * @access		public
	 * @since		3.0.0
	 * @var			string
	 */
	public $meta_join		= 'user_id';
	
	/**
	 * Stores the new password when generated
	 * @access		public
	 * @since		3.0.0
	 * @var			array
	 */
	public $new_password;
	
	/**
	 * Indicates the length of the salt to use
	 * @access		public
	 * @since		3.0.0
	 * @var			integer
	 */
	public $salt_length		= 10;
	
	/**
	 * Should we store the salt in the database
	 * @access		public
	 * @since		3.0.0
	 * @var			boolean
	 */
	public $store_salt		= false;
	
	/**
	 * Stores the table names used in the database
	 * @access		public
	 * @since		3.0.0
	 * @var			array
	 */
	public $tables = array( 'groups' => 'groups', 'users' => 'users', 'meta' => 'meta' );
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->helper('cookie');
		$this->load->helper('date');
		$this->load->library('session');
	}
	
	
	/**
	 * Hashes a password for storage in the database
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $password: contains the password to hash
	 * @param		string		- $salt: an existing salt to use or false
	 * 
	 * @return		string containing hashed password or false on error
	 * @since		3.0.0
	 */
	public function hash_password($password, $salt=false)
	{
		if ( empty( $password ) ) {
			return false;
		}
	
		if ( $this->store_salt && $salt ) {
			return  sha1( $password . $salt );
		}
		else {
			$salt = $this->salt();
			return  $salt . substr( sha1( $salt . $password ), 0, - $this->salt_length );
		}
	}
	
	
	/**
	 * Retrieves the salt from the DB and generates the hashed password
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $identity: the username/email identifying the user
	 * @param		string		- $password: the entered password
	 * 
	 * @return		string containing hashed password or false on error
	 * @since		3.0.0
	 */
	public function hash_password_db($identity, $password)
	{
		if ( empty( $identity ) || empty( $password ) ) {
			return false;
		}
		
		$query = $this->db->select( 'password' )
							->select( 'salt' )
							->where( $this->identity_column, $identity )
							->limit(1)
							->get( $this->tables['users'] );
		
		$result = $query->row();
		
		if ( $query->num_rows() !== 1 ) {
			return false;
		}
		
		if ($this->store_salt) {
			return $this->hash_password( $password, $result->salt );
		}
		else {
			$salt = substr( $result->password, 0, $this->salt_length );
			return $salt . substr(sha1($salt . $password), 0, - $this->salt_length);
		}
	}
	
	
	/**
	 * Generates a random salt value
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		string containing random salt
	 * @since		3.0.0
	 */
	public function salt()
	{
		return substr(md5(uniqid(rand(), true)), 0, $this->salt_length);
	}
	
	
	
	/**
	 * Validates and removes the activation code for a user
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		integer		- $id: the id of the user in the users table
	 * @param		string		- $code: the activation code 
	 * 
	 * @return		boolean true on success false on failure
	 * @since		3.0.0
	 */
	public function activate($id, $code = false)
	{
		if ($code !== false) {
			$query = $this->db->select($this->identity_column)
								->where('activation_code', $code)
								->limit(1)
								->get($this->tables['users']);
		
			$result = $query->row();
			
			if ($query->num_rows() !== 1) {
				return false;
			}
			
			$identity = $result->{$this->identity_column};
			
			$data = array(
					'activation_code' => '',
					'active'	  => 1
					 );
			
			$this->db->update($this->tables['users'], $data, array($this->identity_column => $identity));
	    }
	    else {
			$data = array(
					'activation_code' => '',
					'active' => 1
					 );
			
			$this->db->update($this->tables['users'], $data, array('id' => $id));
	    }
		
	    return $this->db->affected_rows() == 1;
	}
	
	
	/**
	 * Deactivates a user and creates an activation code for them
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		integer		- $id: the user id of the user to deactivate
	 * 
	 * @return		boolean true on success false on error
	 * @since		3.0.0
	 */
	public function deactivate($id = 0)
	{
		if ( empty( $id ) ) {
			return false;
		}
		
		$activation_code       = sha1( md5( microtime() ) );
		$this->activation_code = $activation_code;
		
		$data = array(
					'activation_code' => $activation_code,
					'active'	  => 0
		);
		
		$this->db->update( $this->tables['users'], $data, array( 'id' => $id ) );
		
		return $this->db->affected_rows() == 1;
	}
	
	
	/**
	 * Changes a password for a user
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $identity: contains the username/email of the user to change
	 * @param		string		- $old: the old password
	 * @param		string		- $new: the new password
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function change_password($identity, $old, $new)
	{
		$query = $this->db->select('password, salt')
							->where($this->identity_column, $identity)
							->limit(1)
							->get($this->tables['users']);
		
		$result		= $query->row();
		$new		= $this->hash_password($new, $result->salt);
		
	    //store the new password and reset the remember code so all remembered instances have to re-login
		$data = array(
					'password' => $new,
					'remember_code' => '',
		);
		
		$this->db->update( $this->tables['users'], $data, array( $this->identity_column => $identity ) );
		
		return $this->db->affected_rows() == 1;
	}
	
	
	/**
	 * Checks to see if a username is in use
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $username: contains the username to check
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function username_check($username = '')
	{
		if ( empty( $username ) ) {
			return false;
		}
		
		return $this->db->where( 'username', $username )
	    				->count_all_results( $this->tables['users'] ) > 0;
	}
	
	
	/**
	 * Checks to see if an email is in use
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $email: contains the email address to check
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function email_check($email = '')
	{
		if ( empty( $email ) ) {
			return false;
		}
		
		return $this->db->where( 'email', $email )
						->count_all_results( $this->tables['users'] ) > 0;
	}
	
	
	/**
	 * Checks an identity
	 * @access		protected
	 * @version		3.0.1.0.1
	 * @param		string		- $identity: the identity t check for
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	protected function identity_check( $identity = '' )
	{
		if ( empty( $identity ) ) {
			return false;
		}
		
		return $this->db->where( $this->identity_column, $identity )
						->count_all_results( $this->tables['users'] ) > 0;
	}
	
	
	/**
	 * Inserts a forgotten password key
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $email: contains the email to insert forgotten password key for
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function forgotten_password($email = '')
	{
		if ( empty( $email ) ) {
			return false;
		}
		
		$key = $this->hash_password( microtime().$email );
		$this->forgotten_password_code = $key;
		$this->db->update( $this->tables['users'], array( 'forgotten_password_code' => $key ), array('email' => $email ) );
		
		return $this->db->affected_rows() == 1;
	}
	
	
	/**
	 * Completes a forgotten password request if code provided
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $code: the forgotten password code
	 * @param		mixed		- $salt: can contain a salt or false for default
	 * 
	 * @return		string containing new password or false on error
	 * @since		3.0.0
	 */
	public function forgotten_password_complete($code, $salt=FALSE)
	{
		if ( empty( $code ) ) {
			return false;
		}
		
		$this->db->where( 'forgotten_password_code', $code );
		
		if ( $this->db->count_all_results( $this->tables['users'] ) > 0 ) {
			$password = $this->salt();
			$data = array(
						'password'			=> $this->hash_password( $password, $salt ),
						'forgotten_password_code'   => '0',
						'active'			=> 1,
			);
		
			$this->db->update( $this->tables['users'], $data, array( 'forgotten_password_code' => $code ) );
			
			return $password;
	    }
		
	    return false;
	}
	
	
	/**
	 * Builds the user profile from database
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $identity: the username/email to pull profile for
	 * @param		boolean		- $is_code: if the user is a forgotten password user
	 * 
	 * @return		array of fields or false on error
	 * @since		3.0.0
	 */
	public function profile( $identity = '', $is_code = false )
	{
		if ( empty( $identity ) ) {
			return false;
		}
		
		$this->db->select( array(
							$this->tables['users'].'.*',
							$this->tables['groups'].'.name AS '. $this->db->protect_identifiers('group'),
							$this->tables['groups'].'.description AS '. $this->db->protect_identifiers('group_description')
				   		)
		);
		
		if (! empty( $this->columns ) ) {
			foreach ($this->columns as $field) {
				$this->db->select( $this->tables['meta'] .'.' . $field );
			}
		}
		
		$this->db->join( $this->tables['meta'], $this->tables['users'].'.id = '.$this->tables['meta'].'.'.$this->meta_join, 'left' );
		$this->db->join( $this->tables['groups'], $this->tables['users'].'.group_id = '.$this->tables['groups'].'.id', 'left' );
		
		if ($is_code) {
			$this->db->where( $this->tables['users'].'.forgotten_password_code', $identity );
		}
		else {
			$this->db->where( $this->tables['users'].'.'.$this->identity_column, $identity );
		}
		
		$this->db->limit(1);
		$i = $this->db->get($this->tables['users']);
		
		return ($i->num_rows > 0) ? $i->row() : FALSE;
	}
	
	
	/**
	 * Registers a user
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $username: the username to register
	 * @param		string		- $password: the password to use
	 * @param		string		- $email: the email to register
	 * @param		array		- $additional_data: array of other data or false
	 * @param		string		- $group_name: if known, or false to find it
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function register( $username, $password, $email, $additional_data = false, $group_name = false )
	{
		if ( $this->identity_column == 'email' && $this->email_check( $email ) ) {
			// @TODO:  ERROR CODES
			$this->ion_auth->set_error('account_creation_duplicate_email');
			return false;
		}
		else if ( $this->identity_column == 'username' && $this->username_check( $username ) ) {
			// @TODO:  ERROR CODES
			$this->ion_auth->set_error('account_creation_duplicate_username');
			return false;
		}
		
		// If username is taken, use username1 or username2, etc.
		if ( $this->identity_column != 'username' ) {
			for( $i = 0; $this->username_check($username); $i++ ) {
				if( $i > 0) {
					$username .= $i;
				}
			}
		}
		
		// If a group ID was passed, use it
		if( isset( $additional_data['group_id'] ) ) {
			$group_id = $additional_data['group_id'];
			unset( $additional_data['group_id'] );
		}
		// Otherwise use the group name if it exists
		else {
			// Group ID
			if(! $group_name ) {
				$group_name = 'members';
			}
			
			$group_id = $this->db->select( 'id' )
									->where( 'name', $group_name )
									->get( $this->tables['groups'] )
									->row()->id;
		}
		
		// IP Address
		$ip_address = $this->input->ip_address();
		$salt	= $this->store_salt ? $this->salt() : FALSE;
		$password	= $this->hash_password($password, $salt);
		
		// Users table.
		$data = array(
						'username'   => $username,
						'password'   => $password,
						'email'      => $email,
						'group_id'   => $group_id,
						'ip_address' => $ip_address,
						'created_on' => now(),
						'last_login' => now(),
						'active'     => 1
		);
		
		if ($this->store_salt) {
			$data['salt'] = $salt;
		}
		
		$this->db->insert( $this->tables['users'], $data );
		
	    // Meta table.
		$id		= $this->db->insert_id();
		$data	= array( $this->meta_join => $id );
		
		if (! empty( $this->columns ) ) {
			foreach ( $this->columns as $input ) {
				if ( is_array( $additional_data ) && isset( $additional_data[$input] ) ) {
					$data[$input] = $additional_data[$input];
				}
				elseif ( $this->input->post( $input ) ) {
					$data[$input] = $this->input->post($input);
				}
			}
		}
		
		$this->db->insert( $this->tables['meta'], $data );
		
		return $this->db->affected_rows() > 0 ? $id : false;
	}

	
	/**
	 * Logs a user into the system
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $identity: the username or email of the user
	 * @param		string		- $password: the entered password
	 * @param		boolean		- $remember: should we set the remember cookie
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function login( $identity, $password, $remember=false )
	{
		if ( empty( $identity ) || empty( $password ) || !$this->identity_check( $identity ) ) {
			return false;
		}
		
		$query = $this->db->select( $this->identity_column.', id, password, group_id' )
								->where( $this->identity_column, $identity )
								->where( 'active', 1 )
								->limit(1)
								->get( $this->tables['users'] );
		
		$result = $query->row();
		
		if ( $query->num_rows() == 1 ) {
			$password = $this->hash_password_db($identity, $password);
			
			if ( $result->password === $password ) {
				$this->update_last_login($result->id);
				
				$group_row = $this->db->select('name')->where('id', $result->group_id)->get($this->tables['groups'])->row();
				$session_data = array(
									$this->identity_column => $result->{$this->identity_column},
									'id'                   => $result->id, //kept for backwards compatibility
									'user_id'              => $result->id, //everyone likes to overwrite id so we'll use user_id
									'group_id'             => $result->group_id,
									'group'                => $group_row->name
				);
				
				$this->session->set_userdata( $session_data );
				
				if ( $remember ) {
					$this->remember_user($result->id);
				}
				
				return true;
			}
		}
		
		return false;
	}

	/**
	 * Gets users from the database
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		mixed		- $group: false default, string by name, array if searching by multiple groups
	 * @param		integer		- $limit: if set the limit of records
	 * @param		integer		- $offset: if set the offset value
	 * 
	 * @return		array of records from database
	 * @since		3.0.0
	 */
	public function get_users( $group = false, $limit = null, $offset = null )
	{
		$this->db->select( array(
							$this->tables['users'].'.*',
							$this->tables['groups'].'.name AS '. $this->db->protect_identifiers('group'),
							$this->tables['groups'].'.description AS '. $this->db->protect_identifiers('group_description')
							)
		);
		
		if (! empty( $this->columns ) ) {
			foreach ($this->columns as $field) {
		    	$this->db->select( $this->tables['meta'].'.'. $field );
			}
		}
		
		$this->db->join( $this->tables['meta'], $this->tables['users'].'.id = '.$this->tables['meta'].'.'.$this->meta_join, 'left' );
		$this->db->join( $this->tables['groups'], $this->tables['users'].'.group_id = '.$this->tables['groups'].'.id', 'left' );
		
		if ( is_string( $group ) ) {
			$this->db->where( $this->tables['groups'].'.name', $group );
		}
		else if ( is_array( $group ) ) {
			$this->db->where_in( $this->tables['groups'].'.name', $group );
		}
		
		if ( isset( $limit ) && isset( $offset ) ) {
			$this->db->limit($limit, $offset);
		}
		
		return $this->db->get( $this->tables['users'] );
	}

	
	/**
	 * Gets the count of users
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		mixed		- $group: false default, string by name, array if searching by multiple groups
	 * 
	 * @return		integer containing number of Users
	 * @since		3.0.0
	 */
	public function get_users_count( $group = false )
	{
		if ( is_string( $group ) ) {
			$this->db->where($this->tables['groups'].'.name', $group);
		}
		else if ( is_array( $group ) ) {
			$this->db->where_in($this->tables['groups'].'.name', $group);
		}
		
		$this->db->from( $this->tables['users'] );
		return $this->db->count_all_results();
	}
	
	
	/**
	 * Gets the active users
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		mixed		- $group: false default, string by name, array if searching by multiple groups
	 * 
	 * @return 		object
	 * @since		3.0.0
	 */
	public function get_active_users( $group_name = false )
	{
		$this->db->where( $this->tables['users'].'.active', 1 );
		
		return $this->get_users($group_name);
	}
	
	
	/**
	 * Gets the inactive users
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		mixed		- $group: false default, string by name, array if searching by multiple groups
	 * 
	 * @return		object
	 * @since		3.0.0
	 */
	public function get_inactive_users( $group_name = false )
	{
		$this->db->where($this->tables['users'].'.active', 0);
		return $this->get_users( $group_name );
	}
	
	
	/**
	 * Gets a specific user
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		integer		- $id: the user id of the user to get
	 * 
	 * @return		object
	 * @since		3.0.0
	 */
	public function get_user($id = false)
	{
		if ( empty( $id ) ) {
			$id = $this->session->userdata( 'user_id' );
		}
		
		$this->db->where( $this->tables['users'].'.id', $id );
		$this->db->limit(1);
		
		return $this->get_users();
	}
	
	
	/**
	 * Gets a user by email address
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $email: the user email to find by
	 * 
	 * @return		object
	 * @since		3.0.0
	 */
	public function get_user_by_email( $email )
	{
		$this->db->limit(1);
		return $this->get_users_by_email( $email );
	}
	
	
	/**
	 * Gets users by email address
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $email: the email to find by
	 * 
	 * @return		object
	 * @since		3.0.0
	 */
	public function get_users_by_email( $email )
	{
		$this->db->where($this->tables['users'].'.email', $email);
		
		return $this->get_users();
	}
	
	
	/**
	 * Gets a user by username
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $username: the username to search by
	 * 
	 * @return		object
	 * @since		3.0.0
	 */
	public function get_user_by_username( $username )
	{
		$this->db->limit(1);
		
		return $this->get_users_by_username($username);
	}
	
	
	/**
	 * Gets users by username
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $username: the username to search by
	 * 
	 * @return		object
	 * @since		3.0.0
	 */
	public function get_users_by_username( $username )
	{
		$this->db->where($this->tables['users'].'.username', $username);
		
		return $this->get_users();
	}
	
	
	/**
	 * Gets users by identity
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $identity: the identity to search by
	 * 
	 * @return		object
	 * @since		3.0.0
	 */
	public function get_user_by_identity( $identity )
	{
		$this->db->where($this->tables['users'].'.'.$this->identity, $identity);
		$this->db->limit(1);
		
	    return $this->get_users();
	}
	
	
	/**
	 * Gets the newest users
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		integer		- $limit: the limit of users to get
	 * 
	 * @return		object
	 * @since		3.0.0
	 */
	public function get_newest_users( $limit = 10 )
  	{
  		$this->db->order_by($this->tables['users'].'.created_on', 'desc');
  		$this->db->limit($limit);
		
  		return $this->get_users();
  	}
	
  	
	/**
	 * Gets a users groups
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		integer		- $id: the user id of the user to find
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_users_group( $id = false )
	{
		$id || $id = $this->session->userdata('user_id');
		
		$user = $this->db->select('group_id')
							->where('id', $id)
							->get($this->tables['users'])
							->row();
		
		return $this->db->select( 'name, description' )
							->where( 'id', $user->group_id )
							->get( $this->tables['groups'] )
							->row();
	}
	
	
	/**
	 * Gets groups
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_groups()
  	{
  		return $this->db->get( $this->tables['groups'] )->result();
  	}
  	
  	

	/**
	 * Gets a specific group by id
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		integer		- $id: the group id to retrieve by
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_group( $id )
  	{
  		$this->db->where('id', $id);
		return $this->db->get( $this->tables['groups'] )->row();
  	}
  	
  	

	/**
	 * Get a group by group name
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $name: the group to find by
	 * 
	 * @return		array
	 * @since		3.0.0
	 */
	public function get_group_by_name( $name )
  	{
  		$this->db->where( 'name', $name );
  		return $this->db->get( $this->tables['groups'] )->row();
  	}
  	
  	

	/**
	 * Updates a user
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		integer		- $id: the identity of the user
	 * @param		array		- $data: the data array to set
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function update_user( $id, $data )
	{
		$user = $this->get_user( $id )->row();
		$this->db->trans_begin();
		
		if ( array_key_exists( $this->identity_column, $data ) && $this->identity_check( $data[$this->identity_column] ) && $user->{$this->identity_column} !== $data[$this->identity_column] ) {
			$this->db->trans_rollback();
			// @TODO: ERROR REPORTING
			return false;
		}
		
		if (! empty( $this->columns ) ) {
			//filter the data passed by the columns in the config
			$meta_fields = array();
			foreach ($this->columns as $field) {
				if ( is_array( $data ) && isset( $data[$field] ) ) {
					$meta_fields[$field] = $data[$field];
					unset( $data[$field] );
				}
			}
			
			//update the meta data
			if ( count( $meta_fields ) > 0 ) {
				// 'user_id' = $id
				$this->db->where( $this->meta_join, $id );
				$this->db->set( $meta_fields );
				$this->db->update( $this->tables['meta'] );
			}
		}
		
		if ( array_key_exists( 'username', $data ) || array_key_exists( 'password', $data ) || array_key_exists( 'email', $data ) || array_key_exists( 'group_id', $data ) ) {
			if ( array_key_exists( 'password', $data ) ) {
				$data['password'] = $this->hash_password( $data['password'], $user->salt );
			}
			
			$this->db->update( $this->tables['users'], $data, array( 'id' => $id ) );
		}
		
		if ( $this->db->trans_status() === false ) {
			$this->db->trans_rollback();
			return false;
		}
		
		$this->db->trans_commit();
		return true;
	}
	
	

	/**
	 * Deletes a user
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		integer		- $id: the identity to delete by
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function delete_user( $id )
	{
		$this->db->trans_begin();
		
		$this->db->delete( $this->tables['meta'], array( $this->meta_join => $id ) );
		$this->db->delete( $this->tables['users'], array( 'id' => $id ) );
		
		if ($this->db->trans_status() === false) {
			$this->db->trans_rollback();
			return false;
		}
		
		$this->db->trans_commit();
		return true;
	}
	
	

	/**
	 * Updates the last login
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		integer		- $id: the user to update
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function update_last_login( $id )
	{
		$this->load->helper( 'date' );
		
		$this->db->update( $this->tables['users'], array( 'last_login' => now() ), array( 'id' => $id ) );
		
		return $this->db->affected_rows() == 1;
	}
	
	


	/**
	 * Sets the language in the cookie
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $lang: the language to set
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function set_lang( $lang = 'en' )
	{
		set_cookie( array(
						'name'   => 'lang_code',
						'value'  => $lang,
						'expire' => $this->config->item('user_expire', 'ion_auth') + time()
					)
		);
		
		return true;
	}
	
	

	/**
	 * Logs a remembers user into the site
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function login_remembered_user()
	{
		if (! get_cookie( 'identity' ) || ! get_cookie( 'remember_code' ) || ! $this->identity_check( get_cookie( 'identity' ) ) ) {
		    return false;
		}
		
		$query = $this->db->select( $this->identity_column.', id, group_id' )
								->where( $this->identity_column, get_cookie( 'identity' ) )
								->where( 'remember_code', get_cookie( 'remember_code' ) )
								->limit(1)
								->get( $this->tables['users'] );
		
	    if ($query->num_rows() == 1) {
			$user = $query->row();
			$this->update_last_login( $user->id );
			
			$group_row = $this->db->select('name')->where('id', $user->group_id)->get($this->tables['groups'])->row();
			$session_data = array(
								$this->identity_column => $user->{$this->identity_column},
								'id'                   => $user->id, //kept for backwards compatibility
								'user_id'              => $user->id, //everyone likes to overwrite id so we'll use user_id
								'group_id'             => $user->group_id,
								'group'                => $group_row->name
			);
			
			$this->session->set_userdata( $session_data );
			
			return true;
		}
		
		return false;
	}
	
	

	/**
	 * Remembers a user
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		integer		- $id: the user to remember
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	private function remember_user($id)
	{
		if (! $id ) {
			return false;
		}
		
		$user = $this->get_user( $id )->row();
		$salt = sha1( $user->password );
		$this->db->update( $this->tables['users'], array( 'remember_code' => $salt ), array( 'id' => $id ) );
		
		if ( $this->db->affected_rows() > -1 ) {
			set_cookie( array(
							'name'   => 'identity',
							'value'  => $user->{$this->identity_column},
							'expire' => 86500,
						)
			);
			
			set_cookie( array(
							'name'   => 'remember_code',
							'value'  => $salt,
							'expire' => 86500,
						)
			);
			
			return true;
		}
		
		return false;
	}
}