<?php

/* SECURITY CHECKPOINT */
defined('BASEPATH') OR exit('No direct script access allowed');


class Langmap_Model extends CI_Model
{
	const	type	= "language";
	
	public	$_a		= null;
	public	$id		= null;
	public	$item	= null;
	public	$_v		= null;
	
	private $data	= null;
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		$CI = & get_instance();
		$this->_db = $CI->db;
	}
	
	
	/**
	 * Binds the data array to a new object and stores it to model object allowing for validation
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		array		- $data: contains name => value paired array
	 * 
	 * @return		boolean true on completion, false on error
	 * @since		3.0.0
	 */
	public function bind( $data = array() )
	{
		if ( ! is_array( $data ) ) return false;
		
		foreach ( $data as $key => $value ) {
			if ( $key == "_v" ) $value = (! is_string( $value ) ? json_encode( $value ) : $value );
			if ( $key == "type" ) $value = self::type;
			$bind[$key] = $value;
		}
		
		$this->data = (object) $bind;
		return true;
	}
	
	
	/**
	 * Checks the data prior to storage to ensure consistant with expectations
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		boolean true if ok, false otherwise
	 * @since		3.0.0
	 */
	public function check()
	{
		$data = $this->data;
		if (! isset( $data->_a ) ) return false;
		if (! is_object( $data ) ) $data = (object) $data;
		if (! is_string( $data->_v ) ) $data->_v = json_encode( $data->_v );
		if (! isset( $data->type ) ) $data->type = self::type;
		$this->data = $data;
		return true;
	}
	
	
	/**
	 * Deletes a row from the cnxnmap table
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		integer		- $id: the id of the row to delete
	 * 
	 * @return		true on success, false on error
	 * @since		3.0.0
	 */
	public function delete( $id = null, $by = 'id' )
	{
		$this->_db->where( 'type', 'language' );
		
		if ( $id ) {
			if ( $by == 'id' ) {
				$this->id = $id;
				$this->_db->where( 'id', $id );
			}
			else {
				$this->_a	= $id;
				$this->item	= $by;
				$this->_db->where( '_a', $id );
				$this->_db->where( 'item', $by );
			}
		}
		else {
			$this->_db->where( 'id', $this->id );
		}
		$this->_db->delete( 'cnxnmap' );
		
//		$where	= "WHERE `type` = 'language' AND ";
//		if ( $id ) {
//			if ( $by == 'id' ) {
//				$this->id = $id;
//				$where.= "`id` = {$this->id}";
//			}
//			else {
//				$this->_a	= $id;
//				$this->item = $by;
//				$where.= "`_a` = {$this->_a} AND `item` = '{$this->item}'";
//			}
//		}
//		else {
//			$where.= "`id` = {$this->id}";
//		}
//		
//		$sql	= "DELETE FROM `cnxnmap` ".$where;
//		$query	= $this->_db->query( $sql );
		
		return ( $this->_db->affected_rows() > 0 ? TRUE : FALSE ); 
	}
	
	
	/**
	 * Getter function
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $name: generally required (the thing we are looking for)
	 * @param		varies		- $default: the default value if $name doesn't exist
	 * @param		string		- $type: what we are getting.  Possible values include
	 * 								local:  Local variable $this->$name
	 * 								_v:   The _v setting being sought
	 * 
	 * @return		varies could be value, null or object being sought
	 * @since		3.0.0
	 */
	public function get( $name, $default = null, $type = 'local' )
	{
		$return	= null;
		switch ( $type ) {
			case 'local':
				$return = ( isset( $this->$name ) ? $this->$name : $default );
				break;
			default:
				$return	= ( isset( $this->_v[$name] ) ? $this->_v[$name] : $default );
				break;
		}
		return $return;
	}
	
	
	/**
	 * Loads a database result object onto the model
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		object		- $data: contains the data straight from the database result row
	 * @param		mixed		- $reverse: if we are going from site to application then send the _v as well in reverse
	 * 
	 * @return		true on success, false on error
	 * @since		3.0.0
	 */
	public function load( $id = null, $by = 'id', $reverse = false )
	{
		if ( $id === NULL ) return false;
		
		foreach ( array( "_a", "item", "_v", "id" ) as $item ) $this->$item = null;
		
		if ( $by == 'id' ) {
			$result	= $this->_db->get_where( 'cnxnmap', array( 'type' => 'language', 'id' => $id ) );
		}
		else if ( $reverse === false ) {
			$result	= $this->_db->get_where( 'cnxnmap', array( 'type' => 'language', '_a' => $id, 'item' => $by ) );
		}
		else {
			$this->_db->from( 'cnxnmap' )->where( '_a', $id )->where( 'type', 'language' )->like( '_v', '"' . $reverse . '":"' . ( $by == 'default' ? null : $by . '"' ) );
			
			if ( $by == 'default' ) {
				$this->_db->where( 'item', 'default' );
			}
			else {
				$this->_db->where( 'item !=', 'default' );
			}
			
			$result	= $this->_db->get();
		}
		
		if ( $result->num_rows() > 0 ) {
			foreach( $result->result_array() as $row ) {
				foreach ( $row as $item => $value ) {
					$value = ( $item == "_v" ? json_decode( $value, true ) : $value );
					$this->$item = $value;
				}
			}
			return true;
		}
		return false;
	}
	
	
	/**
	 * Shortcut for saving data to the database
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		true upon success
	 * @since		3.0.0
	 */
	public function save( $data = null )
	{
		if ( $data == null ) return false;
		
		if (! $this->bind( $data ) ) {
			$this->data = null;
			return false;
		}
		
		if (! $this->check() ) {
			$this->data = null;
			return false;
		}
		
		if (! $this->store() ) {
			$this->data = null;
			return false;
		}
		
		return true;
	}
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $name: the name to set
	 * @param		varies		- $value: the value to set
	 * @param		string		- $type: the type to set.
	 * 								local:  Local variable $this->$name
	 * 
	 * @return		varies will return the previous value
	 * @since		3.0.0
	 */
	public function set( $name, $value, $type = 'local' )
	{
		$return	= null;
		
		switch( $type ) {
			case 'local':
				$return = $this->get( $name );
				$this->$name = $value;
				break;
			default:
				$return = $this->get( $name, $value, $type );
				$this->_v[$name] = $value;
				break;
		}
		
		return $return;
	}
	
	
	/**
	 * Stores the data array to the database
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		boolean true if successful, false if not
	 * @since		3.0.0
	 */
	public function store()
	{
		$data		= $this->data;	// Grab local copy
		$this->data	= null;			// Reset so we don't keep saving it in
		
		if ( isset( $data->id ) ) {
			$this->_db->where( 'id', $data->id );
			$this->_db->update( 'cnxnmap', $data );
//			$sql = "UPDATE `cnxnmap` SET `type` = '{$data->type}', `_a` = '{$data->_a}', `item` = '{$data->item}', `_v` = '{$data->_v}' WHERE `id` = {$data->id}";
		}
		else {
			$this->_db->insert( 'cnxnmap', $data );
//			$sql = "INSERT INTO `cnxnmap` ( `type`, `_a`, `item`, `_v` ) VALUES ( '{$data->type}', '{$data->_a}', '{$data->item}', '{$data->_v}' )";
		}
		
//		$this->_db->query( $sql );
		return ( isset( $data->id ) ? ( $this->_db->affected_rows() > 0 ) : $this->_db->insert_id() );
	}
}