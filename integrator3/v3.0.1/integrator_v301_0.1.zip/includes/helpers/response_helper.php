<?php
/* SECURITY CHECKPOINT */
defined('BASEPATH') OR exit('No direct script access allowed');


/**
 * Sends output to the debug feature ( for use in development primarily )
 * @version		3.0.1.0.1
 * @param		mixed		- $array: can be any data to send to debug output
 * 
 * @since		3.0.0
 */
if (! function_exists( '_d' ) ) {
	function _d ( $array ) {
		if ( is_string( $array ) ) {
			debug( $array, 'development', false, 1 );
		}
		else {
			debug( '<pre>'.print_r($array,1 ).'</pre>', 'development', false, 1 );
		}
	}
}


/**
 * Sends an error message to the debug library
 * @version		3.0.1.0.1
 * @param		string		- $message: the debug output
 * @param		string		- $type: indicates what type of message to send
 * @param		bool		- $translate: if the msg should be translated
 * @param		integer		- $use: which backtrace level to use
 * 
 * @since		3.0.0
 */
if (! function_exists( 'debug' ) ) {
	function debug( $message = null, $type = 'info', $translate = true, $use = 0 )
	{
		$bt = debug_backtrace();
		$bt = $bt[$use];
		
		$filename	= ( isset( $bt['file'] ) ? $bt['file'] : 'file not known' );
		$line		= ( isset( $bt['line'] ) ? $bt['line'] : 'unknown' );
		
		// Depending on environmental setting, show full path or not
		if ( ENVIRONMENT_LOG != 4 ) {
			$filename = str_replace( '\\', '/', $filename );
			if (FALSE !== strpos( $filename, '/' ) ) {
				$x = explode('/', $filename );
				$filename = $x[count($x)-2].'/'.end($x);
			}
		}
		
		$CI = & get_instance();
		$CI->load->library( 'Debug_library' );
		$CI->debug_library->add( $message, $filename, $line, $type, $translate );
	}
}


if (! function_exists( 'debug_array' ) ) {
	function debug_array( $data = array() )
	{
		if ( empty( $data ) || ! is_array( $data ) ) return;
		
		$CI = & get_instance();
		$CI->load->library( 'Debug_library' );
		
		foreach( $data as $item ) {
			$CI->debug_library->add( $item['message'], $item['filename'], $item['line'], $item['type'], false );
		}
	}
}


/**
 * Sends an error message to the debug library
 * @version		3.0.1.0.1
 * @param		string		- $message: the debug output
 * @param		string		- $translate: if the msg should be translated
 * @param		integer		- $use: which backtrace level to use 
 * 
 * @since		3.0.0
 */
if (! function_exists( 'debug_error' ) ) {
	function debug_error( $message = null, $translate = true, $use = 0 )
	{
		debug( $message, 'error', $translate, ( $use + 1) );
	}
}


/**
 * Retrieves the output from the debug library and returns it
 * @version		3.0.1.0.1
 * 
 * @return		array
 * @since		3.0.0
 */
if (! function_exists( 'debug_output' ) ) {
	function debug_output()
	{
		$CI = & get_instance();
		$CI->load->library( 'Debug_library' );
		return $CI->debug_library->get_output();
	}
}


/**
 * Used for sending output straight to screen wrapped in <pre> tags or a var dump of a string
 * @version		3.0.1.0.1
 * @param		mixed		- $array: contains the data to output
 * @param		bool		- $die: to kill the application and die on the spot
 * 
 * @since		3.0.0
 */
if (! function_exists( '_e' ) ) {
	function _e( $array, $die = false )
	{
		$bt = debug_backtrace();
		$bt = $bt[0];
		
		echo '<h5>' . $bt['file'] . ' @ line ' . $bt['line'] . '</h5>';
		
		if ( is_string( $array ) ) {
			echo '<pre>'; var_dump( $array ); echo '</pre>';
		}
		else {
			echo '<pre>' . print_r($array,1) . '</pre>';
		}
		
		if ( $die ) die();
	}
}


/**
 * Creates the xml response and returns it back
 * @version		3.0.1.0.1
 * @param		varies		- $data: the data in an array or string to send back
 * @param		varies		- $first: true for first time through, else contains nested array key
 * @param		XMLWriter	- $writer: if recursion being done, pass writer to function
 * 
 * @return		xml formatted string
 * @since		3.0.0
 */
if (! function_exists( 'xml_response' ) ) {
	function xml_response( $data, $first = true, $writer = null )
	{
		if ( $first === true ) {
			$writer = new XMLWriter();
			$writer->openMemory();
			$writer->startDocument('1.0');
			$writer->setIndent(4);
			$writer->startElement( "integrator" );
				$writer->writeAttribute( "version", "3.0.1.0.1" );
		}
		
		foreach ($data as $key => $value) {
			if ( is_array ( $value ) ) {
				if ( is_numeric( $key ) ) $use = $first;
				else $use = $key . "s";
				
				$writer->startElement( $use );
					xml_response( $value, $key, $writer );
				$writer->endElement();
			}
			else {
				$writer->writeElement( $key, $value );
			}
		}
		
		if ( $first === true ) {
			$writer->endElement();	// whmcsapi element
			$writer->endDocument();	// document close
			return $writer->flush();
			//echo $writer->flush();	// flush memory to api interface
			//return;
		}
		
		return $writer;
	}
}