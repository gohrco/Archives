<?php

static $instance = false;

if (! $instance ) {
	$CI = & get_instance();
	$CI->template->append_metadata( css( "icon.css" ) );
	$instance = true;
}

if ( ! function_exists( "icon" ) ) {
	function icon( $url, $img, $attr = array() )
	{
		$CI = & get_instance();
		$CI->load->helper( "url" );
		
		$icon_name = $attr['name'];
		unset( $attr['name'] );
		
		return "<div style='float: left; '><div class='icon'>"
					. anchor(	$url,
								img( $img )
									. "<span>" . $icon_name . "</span>",
								$attr
					)
					."</div></div>";
	}
}