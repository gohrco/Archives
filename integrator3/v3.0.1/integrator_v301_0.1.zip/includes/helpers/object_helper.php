<?php


if (! function_exists( 'array_to_object' ) )
{
function array_to_object( $array = array() )
{
	if (! is_array( $array ) ) return false;
	
	$data = new stdClass();
	
	foreach ( $array as $key => $value ) {
		if ( is_array( $value ) ) {
			$data->$key = array_to_object( $value );
		}
		else {
			$data->$key = $value;
		}
	}
	
	return $data;
}
}


if (! function_exists( 'object_to_array' ) )
{
function object_to_array( $object = array(), $values = true )
{
	if ( ( ! is_object( $object ) ) && (! is_array( $object ) ) ) return false;
	
	$data	= array();
	
	foreach( $object as $key => $value ) {
		if ( is_object( $value ) ) {
			$data[$key] = object_to_array( $value, $values );
		}
		else {
			$data[$key] = ( $values ? $value : null );
		}
	}
	
	return $data;
}
}