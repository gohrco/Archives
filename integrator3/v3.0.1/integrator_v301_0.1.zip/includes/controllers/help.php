<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.1 ( $Id: help.php 19 2012-04-28 02:38:33Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the help controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Entry point for configuration and administration of application
 * @version		3.0.1.0.1
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Help extends Admin_Controller
{
	/**
	 * Constructor class
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::Admin_Controller();
		
		$this->load->language( 'help' );
	}
	
	
	
	public function documentation()
	{
		$gohigher	= config_item('gohigher');
		$uri = new Uri( $gohigher['documentation'] );
		redirect( $uri->toString(), 'redirect' );
	}
	
	
	/**
	 * Assembles control panel page
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function index()
	{
		$this->data['status']	= $this->get_box( 'cnxnstatus' );
		$this->data['log']		= $this->get_box( 'userlog' );
		$this->data['rss']		= $this->get_box( 'rss' );
		$this->data['steps']	= $this->get_box( 'stepbystep' );
		
		// Grab the latest version
		$latest_version = (string) @file_get_contents( "http://www.gohigheris.com/integrator_currentversion.txt" );
		$this->data['update']	= ( '3.0.1.0.1' < $latest_version ? $latest_version : false );
		
		$this->template
				->append_metadata( css( "help.css" ) )
				->set_partial( 'admin-cnxnhealth',	'admin/box/cnxnhealth' )
				->set_partial( 'admin-log',			'admin/box/log' )
				->set_partial( 'admin-rss',			'admin/box/rss' )
				->set_partial( 'admin-update',		'admin/box/update' )
				->set_partial( 'admin-stepbystep',	'admin/box/stepbystep' )
				->set_partial( 'body', 				'admin/index' )
				->build('admin', $this->data);
		
	}
	
	
	public function stepbystep()
	{
		$items	= array(
			1 => array(
				sprintf( lang( 'help.sbs.1.msg.1' ), anchor_popup( 'settings/index', lang( 'help.sbs.1.anchor.a' ) ) ),
				lang( 'help.sbs.1.msg.2' ),
				lang( 'help.sbs.1.msg.3' )
			),
			2 => array(
				sprintf( lang( 'help.sbs.2.msg.1' ), anchor_popup( 'users/index', lang( 'help.sbs.2.anchor.a' ) ) ),
				lang( 'help.sbs.2.msg.2' ),
				lang( 'help.sbs.2.msg.3' ),
				sprintf( lang( 'help.sbs.2.msg.4' ), anchor_popup( 'settings/api', lang( 'help.sbs.2.anchor.b' ) ) )
			),
			3 => array(
				lang( 'help.sbs.3.msg.1' ),
				lang( 'help.sbs.3.msg.2' ),
				sprintf( lang( 'help.sbs.3.msg.3' ), anchor_popup( 'cnxns/add', lang( 'help.sbs.3.anchor.a' ) ) ),
				lang( 'help.sbs.3.msg.4' ),
				lang( 'help.sbs.3.msg.5' )
			),
			4 => array(
				lang( 'help.sbs.4.msg.1' )
			),
			5 => array(
				lang( 'help.sbs.5.msg.1' ),
				lang( 'help.sbs.5.msg.2' ),
				sprintf( lang( 'help.sbs.5.msg.3' ), anchor_popup( 'pagemap/index', lang( 'help.sbs.5.anchor.a' ) ) ),
			),
			6 => array(
				lang( 'help.sbs.6.msg.1' ),
				lang( 'help.sbs.6.msg.2' ),
				sprintf( lang( 'help.sbs.6.msg.3' ), anchor_popup( 'langmap/index', lang( 'help.sbs.6.anchor.a' ) ) ),
			),
			7 => array(
				sprintf( lang( 'help.sbs.7.msg.1' ), anchor_popup( 'help/documentation', lang( 'help.sbs.7.anchor.a' ) ), anchor_popup( 'https://www.gohigheris.com/forum/', lang( 'help.sbs.7.anchor.b' ) ) )
			)
		);
		
		$this->data['items']	= $items;
		$this->template
				->append_metadata( css( "help.css" ) )
				->set_partial( 'body', 				'help/steps' )
				->build('admin', $this->data);
	}
	
	
	public function systemstatus()
	{
		
		$this->template
				->set_partial( 'body', 				'help/systemstatus' )
				->build('admin', $this->data);
	}
}

?>