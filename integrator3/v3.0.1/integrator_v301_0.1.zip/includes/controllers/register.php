<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.1 ( $Id: register.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the login controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

require_once( APPPATH . 'assets/recaptchalib.php' );
require_once( APPPATH . 'assets/freeemails.php' );

/**
 * Entry point for global registration
 * @version		3.0.1.0.1
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Register extends MY_Controller
{
	
	/**
	 * Constructor class
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
		
		$this->load->language( 'globals' );
		$this->load->language( 'register' );
		
		$this->load->library( 'form_validation' );
		$this->load->library( 'fields_library' );
		
		// Load the template library
		$this->load->library('template');
		$this->load->helper( "html" );
		$this->load->helper( "icon" );
		$this->load->helper( 'uri' );
		
		if ( ! parent::_check_license() ) {
			redirect( '', 'refresh' );
			exit;
		}
	}
	
	
	/**
	 * Callback to check email address against Integrated sites
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $email: if provided will check email else pulls from post
	 * 
	 * @return		bool
	 * @since		3.0.0
	 */
	public function checkemail( $email = null )
	{
		// Grab the email first
		$email	=   ( $email == null ? $this->input->post( 'value' ) : $email );
		
		// Set the email address into cuser
		$cuser	= & Cuser :: getInstance( true );
		$cuser->set( 'email', $email );
		
		$apis	= $this->_build_reg_cnxns( 'api' );
		$valid	= true;
		
		foreach ( $apis as $api ) {
			if ( ( $msg = $api->user_validation_on_create( true ) ) !== true ) {
				$valid = false;
				break;
			}
		}
		
		return $valid;
	}
	
	
	/**
	 * Callback to check email address against Free Email list (if set to do so)
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $email: if provided will check email else pulls from post
	 * 
	 * @return		boolean
	 * @since		3.0.0 (0.3)
	 */
	public function checkfreeemail( $email = null )
	{
		// Grab the email first
		$email	=   ( $email == null ? $this->input->post( 'value' ) : $email );
		$valid	=   true;
		
		// Check for ban freebies setting
		$params			= & Params :: getInstance();
		$checkfreebie	=   $params->get( 'BanFreebies', false, 'registration' );
		
		if ( $checkfreebie ) {
			// Pull the array and check domain
			$bfs	= new BanFreebies( $email );
			$valid	= $bfs->check();
		}
		
		return $valid;
	}
	
	
	/**
	 * Callback to check password against Integrated sites
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $passwd: if provided will check password else pulls from post
	 * 
	 * @return		bool
	 * @since		3.0.0
	 */
	public function checkpasswd( $passwd = null )
	{
		// Set the username first
		$passwd	=   ( $passwd == null ? $this->input->post( 'value' ) : $passwd );
		$cuser	= & Cuser :: getInstance( true );
		$cuser->set( 'password', $passwd );
		
		$apis	= $this->_build_reg_cnxns( 'api' );
		$valid	= true;
		
		foreach ( $apis as $api ) {
			if ( ( $msg = $api->user_validation_on_create() ) !== true ) {
				$valid = false;
				break;
			}
		}
		
		return $valid;
	}
	
	
	/**
	 * Callback to check username against Integrated sites
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $user: if provided will check user else pulls from post
	 * 
	 * @return		bool
	 * @since		3.0.0
	 */
	public function checkusername( $user = null )
	{
		// Set the username first
		$user	=   ( $user == null ? $this->input->post( 'value' ) : $user );
		$cuser	= & Cuser :: getInstance( true );
		$cuser->set( 'username', $user );
		
		$apis	= $this->_build_reg_cnxns( 'api' );
		$valid	= true;
		
		foreach ( $apis as $api ) {
			if ( ( $msg = $api->user_validation_on_create( true ) ) !== true ) {
				$valid = false;
				break;
			}
		}
		
		return $valid;
	}
	
	
	/**
	 * Default action to render and submit and verify form data
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function index( $_v = false )
	{
		// Intercept ajax calls for data verification
		if ( $this->is_ajax() ) {
			return $this->_verify();
		}
		
		// Initialize
		$CI		= & get_instance();
		$params	= & Params :: getInstance();
		
		// Retrieve the visual cnxn id (MY_Controller)
		$_v = $this->get_visual_cnxn( $_v );
		
		// No default set?  Can't do anything then
		if ( empty( $_v ) ) {
			show_error( 'Default Visual Not Set' );
			exit;
		}
		
		// If we can't render or we have disabled Integrator we don't want a bunch of errors
		// so send back to origin logout landing (why not)
		if (! $this->local_render( 'register', $_v ) 
				|| ! $params->get( 'Enable', false, 'globals' ) 
				|| ! $params->get( 'EnableRegistration', false, 'registration' ) ) {
			// We must redirect because there is a problem
			redirect( cnxn( $_v )->get( 'logoutlandingurl' ), 'redirect' );
		}
		
		// Set error holder
		$this->data['error'] = null;
		
		// Build the form fields
		$form	=   $this->_build_reg_cnxns( 'form' );
		$form	=   $this->_clean_form( $form );
		$fields	= & $this->fields_library;
		
		$fields->build( $form );
		$fields->usecsrf( false );
		
		$this->session->keep_flashdata( 'csrfkey' );
		$this->session->keep_flashdata( 'csrfvalue' );
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $params->get( 'RecaptchaEnable', false ) ) {
			$this->form_validation->set_rules( 'recaptcha_response_field', 'reCaptcha Response', 'callback_recaptcha' );
		}
		
		$this->form_validation->set_error_delimiters('', '<br/>');
		
		// Validate form ( check is from recaptcha)
		if ( $this->form_validation->run() == true ) {
			$cuser	= & Cuser :: getInstance( true );
			$cuser->set_properties( $this->input->post() );
			
			$apis	= $this->_build_reg_cnxns( 'api' );
			$valid	= true;
			foreach ( $apis as $id => $api ) {
				$cuser->complete( $api->id );
				if ( ( $msg = $api->user_validation_on_create() ) !== true ) {
					$valid = false;
					break;
				}
			}
			
			if ( $valid === true ) {
				foreach( $apis as $id => $api ) {
					if ( ( $msg = $api->user_create() ) === true ) {
						userlog( 'api-usercreated', $this->input->post(),  $api->id );
					}
					else {
						userlog( 'api-usercreatefailed', $msg, $api->id );
					}
				}
				
				userwrite( 'register' );
			}
			
			if ( $valid === true ) {
				// Redirect out
				$url	= $params->get( 'RegRedirectionUrl', null );
				redirect( $url, 'refresh' );
			}
			else {
				$this->data['error'] = $msg;
			}
		}
		
		$this->data['action']			= 'register/index';
		$this->data['submit']			= 'btn.register';
		$this->data['header_includes']	= $this->_client_header();
		$this->data['myurl']			= rtrim( base_url(), '/' ) . '/register/verify/';
		$this->data['recaptcha']		= $this->_fetch_recpatcha();
		$this->data['error']			= validation_errors();
		$this->data['_v']				= $_v;
		
		$this->data		+= $fields->render();
		
		$this->template
				->set_partial( 'body',	'client/register' )
				->build( 'client', $this->data );
	}
	
	
	/**
	 * Builds the connections for registration
	 * @access		private
	 * @version		3.0.1.0.1
	 * @param		string		- $task: form or api requested
	 * 
	 * @return		array of api cnxns or form fields
	 * @since		3.0.0
	 */
	private function _build_reg_cnxns( $task = 'form' )
	{
		$cnxns	=   get_cnxns();
		$cuser	= & Cuser :: getInstance();
		$data	=   array();
		
		foreach ( $cnxns as $id => $cnxn ) {
			if ( ! $cnxn->get( "active" ) ) continue;
			if ( ! $cnxn->get( "userenable", true, "users" ) ) continue;
			
			if ( $task == 'form' ) {
				$data += $cuser->build_form( $id, true );
			}
			else {
				$data[]	= get_api( $id );
			}
		}
		
		if ( empty( $data ) ) return false;
		else return $data;
	}
	
	
	/**
	 * Clean the form before rendering
	 * @access		private
	 * @version		3.0.1.0.1
	 * @param		array		- $form: the gathered unordered form fields
	 * 
	 * @return		array of cleaned up form
	 * @since		3.0.0
	 */
	private function _clean_form( $form )
	{
		// Reorder according to parameters
		$params	= & Params :: getInstance();
		$order	=   $params->get( 'FieldOrder', array(), 'registration' );
		$count	=   10;
		
		foreach ( $order as $o ) {
			// Catch any form items not set so we don't have errors
			if (! isset( $form[$o] ) ) continue;
			$form[$o]['order'] = $count;
			$count += 10;
		}
		
		// Don't give front end user ability to activate / deactivate their own account
		if ( isset( $form['active'] ) ) unset ( $form['active'] );
		
		// Don't ask for full name if we are asking for first and last
		if ( isset( $form['firstname'] ) && isset( $form['lastname'] ) ) {
			if ( isset( $form['fullname'] ) ) unset( $form['fullname'] );
		}
		
		// We don't have the id of anything
		if ( isset( $form['id'] ) ) unset ( $form['id'] );
		
		// Be sure we have a password2 field
		if (! isset( $form['password2'] ) ) {
			$form['password2'] = array( 'value' => null, 'order' => ( $form['password']['order'] + 5 ), 'type' => 'password', 'validation' => 'required|xss_clean' );
		}
		
		/**
		 * Call Backs Added Here
		 * ---------------------
		 */
		if ( isset( $form['email'] ) ) {
			$form['email']['validation'] .= '|callback_checkemail|callback_checkfreeemail';
		}
		
		if ( isset( $form['username'] ) ) {
			$form['username']['validation'] .= '|callback_checkusername';
		}
		
		if ( isset( $form['password'] ) ) {
			$form['password']['validation'] .= '|callback_checkpasswd';
		}
		
		// Set Callback error messages
		foreach ( array( 'checkemail' => 'msg.ajax.email.error.check', 'checkfreeemail' => 'msg.ajax.email.error.free', 'checkusername' => 'msg.ajax.username.error.check', 'checkpasswd' => 'msg.ajax.password.error.check' ) as $rule => $msg ) {
			$this->form_validation->set_message( $rule, lang( $msg ) );
		}
		/**
		 * -------------------------
		 * End Call Backs Addition
		 */
		
		foreach ( $form as $name => $defs ) {
			$vtion	= array();
			
			if ( in_array( $defs['type'], array( 'password', 'text' ) ) ) $form[$name]['arguments']['size'] = '40';
			
			// Client Side Validation Classes
			if ( strpos( $form[$name]['validation'], 'required' ) !== false ) $vtion[]	= 'required';
			if ( $name == 'email' )		$vtion[]	= 'custom[email]';
			if ( $name == 'email' )		$vtion[]	= 'ajax[ajaxCheckEmail]';
			if ( $name == 'password' )	$vtion[]	= 'ajax[ajaxCheckPasswd]';
			if ( $name == 'password2' )	$vtion[]	= 'equals[password]';
			if ( $name == 'username' )	$vtion[]	= 'ajax[ajaxCheckUsername]';
			
			if (! empty( $vtion ) ) {
				$form[$name]['arguments']['class'] = 'validate[' . implode( ',', $vtion ) . ']';
			}
			
			//if (! in_array( $name, array( 'email', 'username', 'password' ) ) ) continue;
			//$form[$name]['arguments']['onchange']	= "ajaxvalidate( this );";
		}
		
		if ( $params->get( 'PasswordStrength' ) == '1' ) {
			$form['pwstrength']	= array( 'value' => null, 'order' => ( $form['password']['order'] + 7 ), 'type' => 'pwstrength', 'validation' => null );
		}
		
		return $form;
	}
	
	
	/**
	 * Assembles additional header items for the client
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @return		string containing links and/or scripts
	 * @since		3.0.0
	 */
	private function _client_header()
	{
		$params = & Params :: getInstance();
		$data	=   null;
		
		$data	.= js( 'jquery-1.6.min.js' ) . "\n";
		$data	.= js( 'noconflict.js' ) . "\n";
		$data	.= js( 'ajaxfunctions.js' ) . "\n";
		$data	.= '<script type="text/javascript">var passtxt="' . $params->get( "PasswordText" ) . '"</script>';
		$data	.= js( 'passwordstrength.js' ) . "\n";
		$data	.= js( 'jquery.validationEngine.js' ) . "\n";
		$data	.= js( 'jquery.validationEngine-en.js' ) . "\n";
		$data	.= css( 'client.css' ) . "\n";
		$data	.= css( 'validationEngine.jquery.css' ) . "\n";
		
		return $data;
	}
	
	
	/**
	 * Retrieves the recaptcha options array
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @return		array of options
	 * @since		3.0.0
	 */
	private function _fetch_recpatcha()
	{
		$params	= & Params :: getInstance();
		$data	=   array();
		$data['enabled']	= $params->get( 'RecaptchaEnable', false );
		$data['pubkey']		= $params->get( 'RecaptchaPublickey', null );
		$data['theme']		= $params->get( 'RecaptchaTheme', null );
		$data['lang']		= $params->get( 'RecaptchaLang', null );
		$data['usessl']		= Uri :: getInstance()->isSSL();
		
		return $data;
	}
	
	
	/**
	 * For the ajax validation, we must check which field is sent to set the correct rule
	 * @access		private
	 * @version		3.0.1.0.1
	 * @param		string		- $item: the value of the item field sent
	 * 
	 * @return		array containing form rule
	 * @since		3.0.0
	 */
	private function _get_validation_form( $item )
	{
		$data	= array( 'field' => 'value', 'label' => null, 'rules' => null );
		$error	= array();
		
		switch ( $item ) :
		case 'email':
			$data['label']	= 'Email Address';
			$data['rules']	= 'required|xss_clean|valid_email|callback_checkemail|callback_checkfreeemail';
			$error[]		= array( 'checkemail', lang( 'msg.ajax.email.error.check' ) );
			$error[]		= array( 'checkfreeemail', lang( 'msg.ajax.email.error.free' ) );
			break;
		case 'password':
			$data['label']	= 'Password';
			$data['rules']	= 'required|xss_clean|min_length[4]|max_length[100]|callback_checkpasswd';
			$error[]		= array( 'checkpasswd', lang( 'msg.ajax.password.error.check' ) );
			break;
		case 'username':
			$data['label']	= 'Username';
			$data['rules']	= 'required|xss_clean|callback_checkusername';
			$error[]		= array( 'checkusername', lang( 'msg.ajax.username.error.check' ) );
			break;
		endswitch;
		
		foreach ( $error as $err ) $this->form_validation->set_message( $err[0], $err[1] );
		return $data;
	}
	
	
	/**
	 * Ajax verification method
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	private function _verify()
	{
		// Be sure we are called by an ajax request
		if (! $this->is_ajax() ) {
			exit( 'You are not allowed to view this page directly!' );
		}
		
		// Grab the field
		$field	= $this->input->get( 'fieldId' );
		$value	= $this->input->get( 'fieldValue' );
		$result	= false;
		$msg	= lang( 'msg.ajax.' . $field . '.good' );
		
		switch ( $field ) :
		case 'email':
			if ( ( $result = $this->checkfreeemail( $value ) ) === true ) {
				if ( ( $result = $this->checkemail( $value ) ) !== true ) {
					$msg = lang( 'msg.ajax.email.error.check' );
				}
			}
			else {
				$msg = lang( 'msg.ajax.email.error.free' );
			}
			
			break;
		case 'password':
			if ( ( $result = $this->checkpasswd( $value ) ) !== true ) {
				$msg = lang( 'msg.ajax.password.error.check' );
			}
			break;
		case 'username':
			if ( ( $result = $this->checkusername( $value ) ) !== true ) {
				$msg = lang( 'msg.ajax.username.error.check' );
			}
			break;
		endswitch;
		
		exit ( json_encode( array( $field, $result, $msg ) ) );
	}
}