<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.1 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      3.0.1 (0.1)
 * 
 * @desc       This is the ajax controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Entry point for configuration and administration of application
 * @version		3.0.1.0.1
 *  
 * @since		3.0.1 (0.1)
 * @author		Steven
 */
class Ajax extends Admin_Controller
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.1 (0.1)
	 */
	public function __construct()
	{
		parent::Admin_Controller();
		
		$this->load->language( 'ajax' );
		
	}
	
	
	/**
	 * Task to check on the status of the system
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		json encoded array
	 * @since		3.0.1 (0.1)
	 */
	public function systemstatus()
	{
		if (! $this->is_ajax() ) return;
		
		$this->load->library( 'updates', array( 'force' => true ) );
		$data	= array();
		
		// Start with the I3 core
		$params		= & Params :: getInstance();
		$current	= $this->updates->is_current( 0 );
		$result		= ( $current ? lang( 'ajax.isuptodate' ) : $this->updates->get_update_list( 0 ) );
		$data[]		= array( 'id' => 0, 'name' => 'I3 Application', 'type' => 'core', 'user' => (bool) $params->get( 'EnableUser' ), 'visual' => (bool) $params->get( 'EnableVisual' ), 'ping' => (bool) $params->get( 'Enable' ), 'active' => (bool) $params->get( 'Enable' ), 'current' => $current, 'result' => ( $current ? lang( 'ajax.isuptodate' ) : $result ) );
		
		// Proceed with connections
		$cnxns	= get_cnxns();
		foreach ( $cnxns as $id => $cnxn ) {
			$current	= $this->updates->is_current( $id );
			$result		= ( $current ? lang( 'ajax.isuptodate' ) : $this->updates->get_update_list( $id ) );
			$data[]	= array_merge( (array) $cnxn->status_check(), array( 'current' => $current, 'result' => $result ) );;
		}
		
		$html	= $data;
		
		exit ( json_encode( array( 'result' => 'success', 'html' => $html ) ) );
	}
	
	
	/**
	 * Performs a check to see if there are any updates available to apply to the integration
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		json encoded array
	 * @since		3.0.1 (0.1)
	 */
	public function updatecheck()
	{
		if (! $this->is_ajax() ) return;
		
		$this->load->library( 'updates' );
		$updates	= $this->updates->exist();
		$msg		= $updates ? '<a href="' . base_url( 'index.php/help/systemstatus' ) . '">' . lang( 'ajax.updateavail' ) . '</a>' : lang( 'ajax.isuptodate' );
		
		exit ( json_encode( array( 'result' => 'success', 'data' => $updates, 'msg' => $msg ) ) );
	}
}