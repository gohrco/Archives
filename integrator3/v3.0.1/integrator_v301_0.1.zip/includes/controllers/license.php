<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.1 ( $Id: license.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the license controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * Settings controller of application
 * @version		3.0.1.0.1
 *  
 * @since		3.0.0
 * @author		Steven
 */
class License extends Admin_Controller
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::Admin_Controller();
		$this->load->language( 'license' );
	}
	
	
	/**
	 * Allows for modification of the settings for the Integrator
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function index()
	{
		$model		= & $this->get_model( 'settings_model', '' );
		$fields		= & $this->fields_library;
		$settings	=   $model->get_properties();
		
		$fields->load( 'license/index' );
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == TRUE ) {
			$model->set_properties( $this->input->post() );
			$model->set( 'LocalKey', '' );
		}
		
		if ( ( $this->form_validation->run() == TRUE ) AND ( $model->save() ) ) {
			$this->session->set_flashdata('success_message', lang( 'msg.success.licsaved' ) );
			redirect("license", 'refresh');
		}
		
		$fields->set_values( $model->get_properties() );
		
		$this->data	+= $fields->render();
		
		$this->data['action']	= 'license/index';
		$this->data['submit']	= 'btn.license';
		
		$this->template
				->set_partial( "body", 'form' )
				->build( "admin", $this->data );
	}
}