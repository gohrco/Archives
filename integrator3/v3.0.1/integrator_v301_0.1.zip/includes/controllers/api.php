<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.1 ( $Id: api.php 11 2012-04-24 00:06:50Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the api controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * API interface for application
 * @version		3.0.1.0.1
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Api extends MY_Controller
{
	/**
	 * If everything checks out this is true
	 * @access		private
	 * @since		3.0.0
	 * @var			bool
	 */
	private	$process		= false;
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
		
		// Load required libraries
		$this->load->language( 'api' );
		$this->load->library( 'form_validation' );
		
		// First validate we received an apiusername / apipassword
		$this->form_validation->set_rules( 'apiusername', 'API Username', 'required' );
		$this->form_validation->set_rules( 'apipassword', 'API Password', 'required' );
		$this->form_validation->set_rules( 'apisignature', 'Signature', 'required' );
		$this->form_validation->set_rules( 'apisalt', 'Salt', 'required' );
		
		// See if Integrator is Enabled
		if ( $this->is_enabled( true ) === false ) {
			return $this->failed( lang( 'msg.error.disabled' ), false );
		}
		
		// Test received credential validations
		if ($this->form_validation->run() == true)
		{	// Log the user in if possible
			if ( $this->auth->login( $this->input->post( 'apiusername' ), $this->input->post( 'apipassword' ), false ) ) {
				define( 'INTEGRATOR_API', true );	
			}
			else {
				// Log in failed, respond
				return $this->failed( lang( "msg.error.credsincorrect" ), false );
			}
		}
		else {
			// No valid credentials provided
			return $this->failed( lang( "msg.error.credsmissing" ), false );
		}
		
		// Test the secret / hash generated
		if ( $this->secret_hash_valid( get_var( 'apisalt', 'post' ), get_var( 'apisignature', 'post' ) ) ) {
			$this->process	= true;
			return;
		}
		else {
			$this->failed( lang( "msg.error.secrethashinvalid" ), false );
		}
	}
	
	
	/**
	 * Retrieves all the available pages for the various cnxns
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function get_allcnxn_pages()
	{
		// Do nothing if process is to fail
		if (! $this->process ) return;
		
		if (! $this->process ) exit;
		
		$this->form_validation->set_rules('_c', 'Connection ID', 'numeric|xss_clean|required');
		
		if ( $this->form_validation->run() != TRUE ) {
			return $this->failed( "msg.error.invaliddata" );
		}
		
		$cnxns	= $this->get_wrapped_cnxns( true );
		
		foreach ( $cnxns as $cnxn ) {
			$pages[]	= array( 'cnxn_id' => $cnxn['id'], 'pages' => get_api( $cnxn['id'] )->get_pages() );
		}
		
		return $this->success( $pages );
	}
	
	
	/**
	 * Retrieves a route given a cnxn_id, page and perhaps a language
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function get_route()
	{
		// Do nothing if process is to fail
		if (! $this->process ) return;
		
		$this->form_validation->set_rules('_c', 'Connection ID', 'numeric|xss_clean|required');
		$this->form_validation->set_rules('cnxn_id', 'Redirection Connection ID', 'numeric|xss_clean|required');
		$this->form_validation->set_rules('page', 'Page', 'xss_clean|required');
		
		if ( $this->form_validation->run() != TRUE ) {
			return $this->failed( lang( 'msg.error.formvalidation' ) );
		}
		
		$cnxn_lib	= get_cnxn_library( get_var( 'cnxn_id' ) );
		
		// Catch misconfigurations (they happen)
		if ( $cnxn_lib === false ) {
			return $this->failed( lang( 'msg.error.getroute.cnxnlib' ) );
		}
		
		// Grab the route
		$route		= $cnxn_lib->get_route();
		
		if ( $route ) {
			return $this->success( array( 'route' => $route ) );
		}
	}
	
	
	public function get_user_info()
	{
		// Do nothing if process is to fail
		if (! $this->process ) return;
		
		$this->form_validation->set_rules('_c', 'Connection ID', 'numeric|xss_clean|required');
		$this->form_validation->set_rules('email', 'Email Address', 'xss_clean|required');
		
		if ( $this->form_validation->run() != TRUE ) {
			return $this->failed( "msg.error.invaliddata" );
		}
		
		$cuser	=   Cuser :: getInstance( true );
		$cuser->set( 'email', $this->input->post( 'email' ) );
		
		$params	= & Params :: getInstance();
		$cnxnid	=   $params->get( 'Defaultuser' );
		$api	=   get_api( $cnxnid );
		
		$api->user_find();
		
		$cuser	=   Cuser :: getInstance();
		$data	=   array();
		
		return $this->success( $cuser->get_properties() );
	}
	
	
	/**
	 * Retrieves the connections that get wrapped
	 * @access		public
	 * @version		3.0.1.0.1
	 * $param		bool		- $internal: we can call internally if we set to true
	 * 
	 * @return		array or response
	 * @since		3.0.0
	 */
	public function get_wrapped_cnxns( $internal = false )
	{
		// Do nothing if process is to fail
		if (! $this->process ) return;
		
		$this->form_validation->set_rules('_c', 'Connection ID', 'numeric|xss_clean|required');
		
		if ( $this->form_validation->run() != TRUE ) {
			return $this->failed( "msg.error.invaliddata" );
		}
		
		$ci		= & get_instance();
		$data	=   array();
		$cnxns	=   get_cnxns();
		
		// Add the Integrator to the mix
		$cnxns['0'] = $ci->cnxns_library;
		
		foreach ( $cnxns as $id => $cnxn ) {
			
			// Find Integrator and catch
			if ( $id == 0 ) {
				$data[] = array( 'id' => 0, 'name' => 'Integrator3' );
				continue;
			}
			
			if ( get_cnxn_library( $id )->get( 'isvisual' ) === true ) continue;
			$data[]	= array( 'id' => $cnxn->get( 'id' ), 'name' => $cnxn->get( 'name' ) . ( $cnxn->get( 'active' ) != '1' ? ' (inactive)' : '' ) );
		}
		
		if ( $internal ) return $data;
		
		return $this->success( $data );
	}
	
	
	/**
	 * Tests the connection to verify the username / password are correct and the connection is valid
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function ping()
	{
		// Do nothing if process is to fail
		if (! $this->process ) return;
		
		// See if User Integration is Enabled
		if ( $this->is_enabled( 'user' ) === false ) {
			return $this->failed( lang( 'msg.error.userdisabled' ) );
		}
		
		return $this->success( "pong" );
	}
	
	
	/**
	 * Updates local settings from remote site
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function update_settings()
	{
		// Do nothing if process is to fail
		if (! $this->process ) return;
		
		// Validate data first
		$this->form_validation->set_rules( 'cnxnid', 'Connection ID', 'numeric|xss_clean' );
		$this->form_validation->set_rules( 'cnxnurl', 'Connection URL', 'xss_clean' );
		
		if ( $this->form_validation->run() != TRUE ) {
			return $this->failed( "msg.error.invaliddata" );
		}
		
		$this->load->helper( "cnxn" );
		
		$cnxnid	= set_value( 'cnxnid' );
		
		if ( ( cnxn( $cnxnid ) ) === false ) {
			$cnxnid = null;
		}
		
		if ( empty( $cnxnid ) ) {
			$cnxns = get_cnxns();
			foreach ( $cnxns as $id => $cnxn ) {
				$params	= strtolower( rtrim( $cnxn->get( "url", null, "globals" ), "/" ) );
				$check	= strtolower( rtrim( set_value( 'cnxnurl' ), "/" ) );
				
				if ( $params == $check ) {
					$cnxnid = $id;
				}
			}
		}
		
		$data	= array( 'cnxnid' => $cnxnid );
		return $this->success( $data );
	}
	
	
	/**
	 * Authenticates a user from a remote connection
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		if no errors, result = success and data = result of authentication
	 * @since		3.0.1 (0.1)
	 */
	public function user_authenticate()
	{
		// Do nothing if process is to fail
		if (! $this->process ) return;
		
		// See if User Integration is Enabled
		if ( $this->is_enabled( 'user' ) === false ) {
			return $this->failed( lang( 'msg.error.userdisabled' ) );
		}
		
		$this->form_validation->set_rules('_c', 'Connection ID', 'numeric|xss_clean|required');
		
		if ( $this->form_validation->run() != TRUE ) {
			return $this->failed( "msg.error.invaliddata" );
		}
		
		$_c		= get_var( '_c', 'post' );
		$cnxn	= get_cnxn_library( $_c );
		$cnxn->cuser_place( $this->input->post() );
		$cuser  = Cuser::getInstance();
		
		// Standardize the credentials
		$creds	= standardize_credentials( array( 'cnxnid' => $_c ) );
		
		// Figure out which type we have if nothing then invalid creds sent
		if ( ( $type = ( empty( $creds['username'] ) ? ( empty( $creds['email'] ) ? false : 'email' ) : 'username' ) ) === false ) {
			return $this->failed( "msg.error.invalidcredentials" );
		}
		
		// Build the authentication stack
		$stack	= build_authentication_stack( array( 'excludes' => array( $_c ), 'type' => $type ) );
		$auth	= false;
		
		// Loop through stack
		foreach ( $stack as $s ) {
			$api		= get_api( $s->get( 'id' ) );
			
			// Try to authenticate
			if ( $auth	= $api->authenticate( $creds ) ) {
				$auth	= $s->get( "id" );
				break;
			}
		}
		
		return $this->success( $auth !== false ? 'msg.success.valid' : 'msg.error.invalid' );
	}
	
	
	/**
	 * Creates a user across all connections
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function user_create()
	{
		// Do nothing if process is to fail
		if (! $this->process ) return;
		
		// See if User Integration is Enabled
		if ( $this->is_enabled( 'user' ) === false ) {
			return $this->failed( lang( 'msg.error.userdisabled' ) );
		}
		
		$this->form_validation->set_rules('_c', 'Connection ID', 'numeric|xss_clean|required');
		
		if ( $this->form_validation->run() != TRUE ) {
			return $this->failed( "msg.error.invaliddata" );
		}
		
		$cnxn	= get_cnxn_library( get_var( "_c", 'post' ) );
		$cnxn->cuser_place( $this->input->post() );
		
		$stack	= $this->_build_api_stack( get_var( "_c", 'post' ) );
		
		foreach ( $stack as $s ) {
			if ( ( $msg = $s->user_create() ) === true ) {
				userlog( 'api-usercreated', $this->input->post(),  $s->id );
			}
			else {
				userlog( 'api-usercreatefailed', $msg, $s->id );
			}
		}
		
		userwrite( 'API: ' . cnxn( get_var( '_c' ) )->get( 'name' ) . ' (origin)' );
		
		return $this->success( "msg.success.valid" );
	}
	
	
	/**
	 * Removes a user across all connections
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function user_remove()
	{
		// Do nothing if process is to fail
		if (! $this->process ) return;
		
		// See if User Integration is Enabled
		if ( $this->is_enabled( 'user' ) === false ) {
			return $this->failed( lang( 'msg.error.userdisabled' ) );
		}
		
		$this->form_validation->set_rules('_c', 'Connection ID', 'numeric|xss_clean|required');
		
		if ( $this->form_validation->run() != TRUE ) {
			return $this->failed( "msg.error.invaliddata" );
		}
		
		$cnxn	= get_cnxn_library( get_var( "_c", 'post' ) );
		$cnxn->cuser_place( $this->input->post() );
		
		//$email	= get_var( 'email', 'post' );
		$stack	= $this->_build_api_stack( get_var( "_c", 'post' ) );
		
		foreach ( $stack as $s ) {
			$s->user_remove();
		}
		
		return $this->success( "msg.success.valid" );
	}
	
	
	/**
	 * Updates a user across all connections
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function user_update()
	{
		// Do nothing if process is to fail
		if (! $this->process ) return;
		
		// See if User Integration is Enabled
		if ( $this->is_enabled( 'user' ) === false ) {
			return $this->failed( lang( 'msg.error.userdisabled' ) );
		}
		
		$this->form_validation->set_rules('_c', 'Connection ID', 'numeric|xss_clean|required');
		
		if ( $this->form_validation->run() != TRUE ) {
			return $this->failed( "msg.error.invaliddata" );
		}
		
		$cnxn	= get_cnxn_library( get_var( "_c", 'post' ) );
		$cnxn->cuser_place( $this->input->post() );
		
		$stack	= $this->_build_api_stack( get_var( "_c", 'post' ) );
		
		foreach ( $stack as $s ) {
			$s->user_update();
		}
		
		return $this->success( "msg.success.valid" );
	}
	
	
	/**
	 * Checks a set of user information to ensure it is valid across all applications
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function user_validation_on_create()
	{
		// Do nothing if process is to fail
		if (! $this->process ) return;
		
		// See if User Integration is Enabled
		if ( $this->is_enabled( 'user' ) === false ) {
			return $this->failed( lang( 'msg.error.userdisabled' ) );
		}
		
		$this->form_validation->set_rules('_c', 'Connection ID', 'numeric|xss_clean|required');
		
		if ( $this->form_validation->run() != TRUE ) {
			return $this->failed( "msg.error.invaliddata" );
		}
		
		$cnxn	= get_cnxn_library( get_var( "_c", 'post' ) );
		$cnxn->cuser_place( $this->input->post() );
		$cuser  = Cuser::getInstance();
		
		$stack	= $this->_build_api_stack( get_var( "_c", 'post' ) );
		
		$valid	= true;
		foreach ( $stack as $clib ) {
			if ( ( $msg = $clib->user_validation_on_create() ) !== true ) {
				$valid = false;
				break;
			}
		}
		
		if ( $valid ) {
			return $this->success( "msg.success.valid" );
		}
		else {
			return $this->failed( $msg );
		}
	}
	
	
	/**
	 * Checks a set of user information to ensure it is valid across all applications
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function user_validation_on_update()
	{
		// Do nothing if process is to fail
		if (! $this->process ) return;
		
		// See if User Integration is Enabled
		if ( $this->is_enabled( 'user' ) === false ) {
			return $this->failed( lang( 'msg.error.userdisabled' ) );
		}
		
		$this->form_validation->set_rules('_c', 'Connection ID', 'numeric|xss_clean|required');
		
		if ( $this->form_validation->run() != TRUE ) {
			return $this->failed( "msg.error.invaliddata" );
		}
		
		$cnxn	= get_cnxn_library( get_var( "_c", 'post' ) );
		$cnxn->cuser_place( $this->input->post() );
		
		$stack	= $this->_build_api_stack( get_var( "_c", 'post' ) );
		
		$valid	= true;
		foreach ( $stack as $clib ) {
			if ( ( $msg = $clib->user_validation_on_update() ) !== true ) {
				$valid = false;
				break;
			}
		}
		
		if ( $valid ) {
			return $this->success( "msg.success.valid" );
		}
		else {
			return $this->failed( $msg );
		}
	}
	
	
	/**
	 * Creates a failed message wrapper
	 * @access		private
	 * @version		3.0.1.0.1
	 * @param 		string		- $message: untranslated language string
	 * 
	 * @since		3.0.0
	 */
	private function failed ( $message = null, $debug = true )
	{
		if ( $debug ) debug_error( $message, false, 1 );
		$this->_close( array( 'result' => "error", "data" => $message ) );
	}
	
	
	/**
	 * Creates a successful message wrapper
	 * @access		private
	 * @version		3.0.1.0.1
	 * @param 		string		- $message: untranslated language string
	 * 
	 * @since		3.0.0
	 */
	private function success( $message = null )
	{
		$data	= (! is_array( $message ) ? $this->lang->line( $message ) : $message );
		$this->_close( array( 'result' => "success", "data" => $data ) );
	}
	
	
	/**
	 * Builds a stack of API connections to call if user enabled is set on
	 * @access		private
	 * @version		3.0.1.0.1
	 * @param		integer		- $c: the originating cnxnid
	 * 
	 * @return		array containing connection libraries to use
	 * @since		3.0.0
	 */
	private function _build_api_stack( $c = false )
	{
		if ( $c === FALSE ) return false;
		if ( $this->is_enabled( 'user' ) === false ) return false;
		
		$cnxns	= get_cnxns();
		$data	= array();
		
		foreach ( $cnxns as $id => $cnxn ) {
			if ( ! $cnxn->get( "active" ) ) continue;
			if ( ! $cnxn->get( "userenable", true, "users" ) ) continue;
			if ( $c == $id ) continue;
			$data[] = get_api( $id );
		}
		
		if ( empty( $data ) ) return false;
		else return $data;
	}
	
	
	/**
	 * Closes the application with the response
	 * @access		private
	 * @version		3.0.1.0.1
	 * @param		array		- $message: contains the response array
	 * 
	 * @since		3.0.0
	 */
	private function _close( $message = array() )
	{
		$debug = debug_output();
		
		if (! empty( $debug ) ) {
			$message += array( 'debug' => $debug );
		}
		$CI = & get_instance();
		$CI->output->set_header( 'Cache-Control: no-cache, must-revalidate' );
		$CI->output->set_header( 'Expires: Fri, 7 Mar 1997 05:00:00 GMT' );
		$CI->output->set_content_type( 'application/json' );
		$CI->output->set_output( json_encode( $message ) );
		return;
	}
}

?>