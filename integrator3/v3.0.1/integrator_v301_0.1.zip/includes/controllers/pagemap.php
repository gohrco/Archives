<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.1 ( $Id: pagemap.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the page mapping controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Page Map controller
 * @version		3.0.1.0.1
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Pagemap extends Admin_Controller
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::Admin_Controller();
		$this->load->language( 'pagemap' );
		$this->load->model( 'pagemap_model' );
		$this->load->helper( 'cnxn' );
	}
	
	
	/**
	 * Renders the main page to map pages from application to site
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function index()
	{
		$model	= & $this->get_model();
		
		$validation	= $this->_create_page_validation_rules();
		
		$this->form_validation->set_rules( $validation );
		
		if ( $this->form_validation->run() == TRUE ) {
			$this->_save_page_array();
			$this->data['success_message'] = lang( 'msg.success.pagemapsaved' );
		}
		
		//list the users
		$this->data['users'] = $this->auth->get_users_array();
		
		$this->data['pages']	= $this->_create_cnxn_page_array();
		$this->data['page']		= $this->_load_from_database();
		
		$this->template
				->set_partial( "body", 'partials/pagemap' )
				->build( "admin", $this->data );
	}
	
	
	/**
	 * Creates the connection language arrays
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @return		array of connections sorted by site/app with languages
	 * @since		3.0.0
	 */
	private function _create_cnxn_page_array()
	{
		static $data	= null;
		
		if (! is_array( $data ) ) {
			$params	= & Params::getInstance();
			$cnxns	=   get_cnxns();
			$data	=   array( "site" => array(), "app" => array() );
			
			// Add in Integrator pages first
			$data['app'][0] = array( 'name' => $params->get( 'Sitename', 'Integrator' ), 'pages' => array( 'register/index' => 'Integrated Registration' ) );
			
			if (! empty( $cnxns ) ) {
				foreach ( $cnxns as $cnxn ) {
					$type	= ( get_cnxn_library( $cnxn->get( "id" ) )->get( "isvisual" ) ? "site" : "app" );
					$row	= array( "name" => $cnxn->get( "name" ), "pages" => get_api( $cnxn->get( 'id' ) )->get_pages() );
					$data[$type][$cnxn->get( "id" )]	= $row;
				}
			}
		}
		
		return $data;
	}
	
	
	/**
	 * Create the validation rules for the form submission
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @return		array of rules for the form
	 * @since		3.0.0
	 */
	private function _create_page_validation_rules()
	{
		$pages		= $this->_create_cnxn_page_array();
		$config		= array();
		foreach ( $pages['app'] as $app_id => $app ) {
			foreach ( $pages['site'] as $site_id => $site ) {
				$config[] = array( 'field' => 'page['.$app_id.'][default]['.$site_id.']', 'label' => 'something', 'rules' => 'required' );
				foreach ( $app['pages'] as $page_id => $page ) {
					$config[] = array( 'field' => 'page['.$app_id.']['.$page_id.']['.$site_id.']', 'label' => 'something', 'rules' => 'required' );
				}
			}
		}
		return $config;
	}
	
	
	/**
	 * Loads the values already stored in the database
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @return		array containing already set language values
	 * @since		3.0.0
	 */
	private function _load_from_database()
	{
		$model		= $this->get_model();
		$pages		= $this->_create_cnxn_page_array();
		$default	= array();
		$check		= array();
		
		foreach ( $pages['site'] as $site_id => $trash ) {
			$check[]	= $site_id;
		}
		
		foreach ( $pages['app'] as $app_id => $app ) {
			$default[$app_id]['default'] = ( $model->load( $app_id, 'default' ) ? $model->_v : null );
			
			// Ensure we have something for each site id
			foreach( $check as $cid ) {
				if (! isset( $default[$app_id]['default'][$cid] ) ) $default[$app_id]['default'][$cid] = null;
			}
			
			// Cycle through each app site and set languages
			foreach ( $app['pages'] as $page_id => $page_name ) {
				$default[$app_id][$page_id] = ( $model->load( $app_id, $page_id ) ? $model->_v : null );
				
				// Ensure we have something for each site id
				foreach( $check as $cid ) {
					if (! isset( $default[$app_id][$page_id][$cid] ) ) $default[$app_id][$page_id][$cid] = null;
				}
			}
		}
		return $default;
	}
	
	
	/**
	 * Saves the form posted to the page
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	private function _save_page_array()
	{
		$model	= & $this->get_model();
		$form	=   $this->input->post( "page" );
		
		foreach ( $form as $_a => $item_array ) {
			foreach( $item_array as $item => $_v ) {
				$data			= array();
				$data['_a'] 	= $_a;
				$data['item']	= $item;
				$data['_v'] 	= $_v;
				
				if ( $cnxnmap_id = $model->load( $_a, $item ) ) {
					$data['id'] = $model->id;
				}
				$model->save( $data );
			}
		}
	}
}
?>