<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.1 ( $Id: login.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the login controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Entry point for configuration and administration of application
 * @version		3.0.1.0.1
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Login extends MY_Controller
{
	/**
	 * Constructor class
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->language( 'login' );
		
		// --- BEGIN: ORIGIN
		// Grab origin array, determine origin, show error if missing and set origin back to session
		$origin			= $this->get( "origin" );
		if (! is_array( $origin ) ) $origin = array( 'c' => $origin );
		
		$origin['c']	= find_origin( "creds" );
		
		if ( ! $origin['c'] ) {
			show_error( $this->lang->line( 'msg.error.credsorigin' ) );
			exit;
		}
		
		$this->set( "origin", $origin );
		// --- END:   ORIGIN
	}
	
	
	/**
	 * Handles failed log in events
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function failed()
	{
		$login_stack	= $this->get( "login" );
		userlog( 'login-failed', $this->get( "credentials" ), $login_stack['next'] );
		// @TODO: Not sure what to do if it fails debug wise
		cnxn_redirect('login/redirect', 'refresh');
	}
	
	
	/**
	 * Handles the initial log in encounter with the Integrator
	 * 	1)	If $sending_id is set, will redirect to succeed to process a logged in user
	 * 	2)	ALWAYS authenticates user regardless if user logged in already
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param 		integer		- $sending_id: if set, contains the id of a connection already logged in
	 * 
	 * @since		3.0.0
	 */
	public function index( $sending_id = null )
	{
		$params	= & Params :: getInstance();
		
		// If we are sending an ID, overwrite the origin just in case they dont match
		if ( $sending_id != null ) {
			if ( cnxn ( $sending_id ) ) {
				$origin = $this->get( 'origin' );
				$origin['c'] = $sending_id;
				$this->set( 'origin', $origin );
			}
		}
		
		$standard_credentials	= $this->_standardize_credentials();
		
		// Determine where we should return to 
		if (! $this->_determine_return_url( $standard_credentials ) )
		{	// NO RETURN URL WAS DETERMINED - MAJOR ISSUE CANNOT PROCEDE
			$cnxn_id	= $this->_get_cnxnid_from_session();
			$cnxn_lib	= get_cnxn_library( $cnxn_id );
			$returnurl	= $cnxn_lib->get_login_error_url( "ERR01" );
			
			userlog( 'auth-returnerror', $standard_credentials, $cnxn_id );
			
			// Wipe session data
			$this->_kill_session();
			redirect( $returnurl, 'redirect' );
		}
		
		// Check the credentials
		if ( $standard_credentials === FALSE )
		{	// NO CREDENTIALS FOUND - send back to origin
			$cnxn_id	= $this->_get_cnxnid_from_session();
			$cnxn_lib	= get_cnxn_library( $cnxn_id );
			$returnurl	= $cnxn_lib->get_login_error_url( "ERR02" );
			
			userlog( 'auth-credsmissing', $standard_credentials, $cnxn_id );
			
			// Wipe session data
			$this->_kill_session();
			redirect( $returnurl, 'redirect' );
		}
		
		// Check connection stacks - all possible connections that are active
		if ( ! ( $connection_stack = $this->_build_authentication_stack() ) )
		{	// NO CONNECTION STACK - settings prohibiting authentication so send back
			$cnxn_id	= $this->_get_cnxnid_from_session();
			$cnxn_lib	= get_cnxn_library( $cnxn_id );
			$returnurl	= $cnxn_lib->get_login_error_url( "ERR03" );
			
			userlog( 'auth-cnxnstackerror', $standard_credentials, $cnxn_id );
			
			// Wipe session data
			$this->_kill_session();
			redirect( $returnurl, 'redirect' );
		}
		
		// Check credentials to ensure a type can be found
		if (! ( $type = $this->_get_credentials_type() ) )
		{	// CREDENTIALS DONT MATCH TYPE - somehow user provided neither username or email (unlikely but never know)
			$cnxn_id	= $this->_get_cnxnid_from_session();
			$cnxn_lib	= get_cnxn_library( $cnxn_id );
			$returnurl	= $cnxn_lib->get_login_error_url( "ERR11" );
			
			userlog( 'auth-typemismatch', $standard_credentials, $cnxn_id );
			
			// Wipe session data
			$this->_kill_session();
			redirect( $returnurl, 'redirect' );
		}
		
		// Isolate the authentication stack we want to try
		$authentication_stack	= $connection_stack[$type];
		$authenticated			= FALSE;
		$tried					= array();
		
		foreach ( $authentication_stack as $authobj )
		{
			$tried[]	= $authobj->get( "id" );
			$api		= get_api( $authobj->get( 'id' ) );
			
			if ( $authenticated = $api->authenticate() ) {
				$authenticated = $authobj->get( "id" );
				break;
			}
			else {
				userlog( 'auth-badpw', $standard_credentials, $authobj->get( "id" ) );
			}
		}
		
		if ( $authenticated === FALSE ) {
			$cnxn_id	= $this->_get_cnxnid_from_session();
			$cnxn_lib	= get_cnxn_library( $cnxn_id );
			$returnurl	= $cnxn_lib->get_login_error_url( "ERR12" );
			
			userwrite( 'login' );
			
			// Wipe session data
			$this->_kill_session();
			
			// Redirect back to originating site for
			redirect( $returnurl, 'redirect' );
		}
		else {
			$authentication_session	= array(	"tried" 	=> $tried,
												"cnxnid"	=> $authenticated
			);
			$this->set( "authentication", $authentication_session );
			userlog( 'auth', $standard_credentials, $authenticated );
		}
		
		// @TODO:  If no login stack return error somehow
		if (! ($login_stack = $this->_build_login_stack( $connection_stack ) ) ) {
			// Grab origin info
			$cnxn_id	= $this->_get_cnxnid_from_session();
			$cnxn_lib	= get_cnxn_library( $cnxn_id );
			$returnurl	= $cnxn_lib->get_login_error_url( "ERR04" );
			
			// Wipe session data
			$this->_kill_session();
			
			// Redirect back to originating site for
			redirect( $returnurl, 'redirect' );
		}
		
		// Cycle through connection ids and drop sessions from database in case they are already there
		foreach( $login_stack as $l ) {
			remove_session_id( $l, false );
		}
		
		// See what method to use (displaylogin uses iframe, otherwise up to sending_id existing)
		$redirect_method	= ( $params->get( 'DisplayLogin' ) ? 'iframe' : ( $sending_id != null ? 'form' : 'refresh' ) );
		
		// Build the embed page
		if ( $redirect_method == 'iframe' ) {
			// Retrieve the visual cnxn id (MY_Controller)
			$_v = $this->get_visual_cnxn( $sending_id );
			
			$this->local_render( 'login', $_v );
			
			$msg	= lang( $params->get( 'LoginMsg' ) );
			$msg	= ( empty( $msg ) ? $params->get( 'LoginMsg' ) : $msg );
			
			// Set empty holders
			$this->data['error']			= '';
			$this->data['header_includes']	= '';
			$this->data['redirectmessage']	= $msg;
			
		}
		
		// The Sending Id indicates we have logged in at the sending id location already
		//		Redirect to success method with sid and sname passed to register completed login
		if ( $sending_id != null ) {
			$redirect_url		= "login/succeed";
			$fields				= array( '_c' => get_var( '_c', 'post' ), 'session' => get_var( 'session', 'post' ) );
			
			// Pull the sending id off the todo list (not necessarily the origin id - first in line)
			foreach( $login_stack as $k => $item ) {
				if ( $item == $sending_id ) unset( $login_stack[$k] );
				break;
			}
		}
		else {
			$redirect_url		= 'login/redirect';
			$fields				= 302;
		}
		
		$this->set( "login", array( "todo" => $login_stack, "done" => array(), "next" => ( $sending_id != null ? $sending_id : null ) ) );
		
		$output = cnxn_redirect( $redirect_url, $redirect_method, $fields );
		
		if ( $redirect_method == 'iframe' ) {
			
			// Set the output to the output class
			$this->data['iframe'] = $output;
			$this->template
					->set_partial( 'body',	'client/iframe' )
					->build( 'client', $this->data );
		}
	}
	
	
	/**
	 * Redirects the user to the next connection to log in with
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function redirect()
	{
		$params	= & Params :: getInstance();
		
		// We are pulling the next connection to redirect to - if FALSE we return to origin
		if ( ( $cnxnid = $this->_get_login_connection_id() ) === FALSE ) {
			$return_url = $this->get( "return_url" );
			userwrite( 'login' );
			
			// Wipe session data
			$this->_kill_session();
			
			// Accomodate login display
			if ( $params->get( 'DisplayLogin' ) ) {
				return redirect( $return_url, 'oframe' );
			}
			else {
				redirect( $return_url, 'redirect' );
			}
		}
		
		// Pull the appropriate connection library
		if ( ( $cnxn_lib = get_cnxn_library( $cnxnid ) ) === FALSE ) {
			// @TODO:  log error
			show_error( "CANT FIND LIBRARY", 200 );
//			redirect('login/redirect', 'refresh');
		}
		
		// Verify we have all the credentials we need to log in with
		if (! $cnxn_lib->verify_login_requirements() ) {
			
			redirect( 'login/redirect', 'refresh' );
		}
		
		cnxn_redirect( $cnxn_lib->get_login_action(), 'form', $cnxn_lib->get_login_fields() );
		
	}
	
	
	/**
	 * Handles successful log in events
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function succeed()
	{
		$login_stack			= $this->get( "login" );
		$cnxnid					= $login_stack['next'];
		$login_stack['done'][]	= $cnxnid;
		$this->set( "login", $login_stack );
		
		$session		= sess_decode( get_var( 'session', 'post' ) );
		
		$cnxn_lib		= get_cnxn_library( $cnxnid );
		$cnxn_lib->handle_session_cookies( $session['id'], $session['name'] );
		
		userlog( 'login-success', $this->get( "credentials" ), $cnxnid );
		cnxn_redirect('login/redirect', 'refresh');
	}
	
	
	/**
	 * Builds the stack of connections to cycle through for authentication purposes
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @return		array of either email or username connections with origin in front of appropriate stack or false if no stack found
	 * @since		3.0.0
	 */
	private function _build_authentication_stack()
	{
		$origin	= $this->get( "origin" );
		$oid	= $origin['c'];
		$cnxns	= get_cnxns();
		$auth	= array( 'email' => array(), 'username' => array() );
		
		foreach ( $cnxns as $id => $cnxn ) {
			if ( ! $cnxn->get( "userenable", true, "users" ) ) continue;
			if (   $cnxn->get( "processlogin", "always", "users" ) == "never" ) continue;
			if ( ( $cnxn->get( "processlogin", "always", "users" ) == "whenconnected" ) AND ( $authentication_object->get( "id" ) != $origin_credentials ) ) continue;
			
			if ( $oid == $id ) {
				array_unshift( $auth[$cnxn->get( "usernametype", "email", "users" )], $cnxn );
			}
			else {
				array_push( $auth[$cnxn->get( "usernametype", "email", "users" )], $cnxn );
			}
		}
		
		if ( empty( $auth ) ) return false;
		else return $auth;
	}
	
	
	/**
	 * Creates the login stack from the connection stack, setting the authenticated connection as first
	 * @access		private
	 * @version		3.0.1.0.1
	 * @param		array		- $connection_stack: contains the assembled connection stack
	 * 
	 * @return		array of integers referencing the cnxn ids to log in to
	 * @since		3.0.0
	 */
	private function _build_login_stack( $connection_stack = false )
	{
		if ( $connection_stack === FALSE ) return false;
		
		$type			= $this->_get_credentials_type();
		$auth			= $this->_get_cnxnid_from_session( "authentication" );
		$login_stack	= array();
		
		$use			= $connection_stack[$type];
		foreach( $use as $item ) {
			if ( $auth == $item->get( "id" ) ) {
				array_unshift( $login_stack, $item->get( "id" ) );
			}
			else {
				array_push( $login_stack, $item->get( "id" ) );
			}
		}
		
		unset( $connection_stack[$type] );
		
		foreach( $connection_stack as $type ) {
			foreach( $type as $item ) {
				if ( $item->get( "active" ) != 1 ) continue;
				$login_stack[] = $item->get( "id" );
			}
		}
		
		return $login_stack;
	}
	
	
	/**
	 * Attempts to locate the return URL for failure and completion purposes
	 * @access		private
	 * @version		3.0.1.0.1
	 * @param		array		- $standard_credentials: the assembled standard credentials array
	 * 
	 * @return		boolean true on find false on missing
	 * @since		3.0.0
	 */
	private function _determine_return_url( $standard_credentials = array() )
	{
		// Be sure we have an array
		if ( $standard_credentials === false ) { 
			$standard_credentials = array( 'return' => null );
		}
		
		$origin_id	= $this->_get_cnxnid_from_session();
		$cnxn_lib	= get_cnxn_library( $origin_id );
		
		// See if we passed the return url via log in form
		if ( $standard_credentials['return'] != null ) {
			$return_url = $cnxn_lib->decode_return_url( $standard_credentials['return'] );
			
			if ( ( $return_url != null ) || ( $return_url != false ) ) {
				$this->set( "return_url", $return_url );
				return true;
			}
		}
		
		// See if we have a return url set in the connection
		if ( $return_url = $cnxn_lib->get_login_landing_url() ) {
			$this->set( "return_url", $return_url );
			return true;
		}
		
		// Use the logout landing URL but throw a error in the log
		if ( $return_url = $cnxn_lib->get_logout_landing_url() ) {
			$this->set( "return_url", $return_url );
			userlog( 'auth-returnlogout', $standard_credentials, $this->_get_cnxnid_from_session() );
			return true;
		}
		
		// We have NOTHING to send back to!!
		return false;
	}
	
	
	/**
	 * Takes the next connection off the stack, setting the new stack and returning shifted cnxn id
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @return		integer containing 
	 * Enter description here ...
	 */
	private function _get_login_connection_id()
	{
		$login_stack	= $this->get( "login" );
		if ( $login_stack["todo"] == NULL ) return false;
		$nextid			= array_shift($login_stack["todo"]);
		$login_stack["next"] = $nextid;
		$this->set( "login", $login_stack );
		return $nextid;
	}
	
	
	/**
	 * Common method for determining what type of connection we have based on session credentials
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @return		string or false on none (email|username|false)
	 * @since		3.0.0
	 */
	private function _get_credentials_type()
	{
		static $type = null;
		
		if ( $type == NULL ) {
			$standard_credentials = $this->get( "credentials" );
			
			if ( ( $standard_credentials['username'] == NULL ) AND 
				 ( $standard_credentials['email'] != NULL ) ) {
				$type	= "email";
			}
			else
			if ( ( $standard_credentials['username'] != NULL ) AND 
				 ( $standard_credentials['email'] == NULL ) ) {
				$type	= "username";
			}
			else {
				$type	= false;
			}
		}
		
		return $type;
	}
	
	
	/**
	 * Common method for retrieving the a connection id from the session array
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @return		integer containing cnxn id sought or false on missing
	 * @since		3.0.0
	 */
	private function _get_cnxnid_from_session( $type = "origin" )
	{
		switch( $type ) {
			case 'authentication':
				$auth	= $this->get( "authentication" );
				$value	= ( isset( $auth['cnxnid'] ) ? $auth['cnxnid'] : false );
				break;
			case 'origin':
			default:
				$origin = $this->get( "origin" );
				$value	= ( isset( $origin['c'] ) ? $origin['c'] : false );
				break;
		}
		
		return $value;
	}
	
	
	/**
	 * Wipes session data before sending back on error or completion of login routine
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	private function _kill_session()
	{
		$origin = $this->get( "origin" );
		unset( $origin['c'] );
		$this->set( "origin", $origin );
		$this->set( "credentials", null );
		$this->set( "authentication", null );
		$this->set( "return_url", null );
	}
	
	
	/**
	 * Grabs the credentials and standardizes them for the Integrator to use
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @return		array containing standardized credentials
	 * @since		3.0.0
	 */
	private function _standardize_credentials()
	{
		$std		= array( 'username' => null, 'password' => null, 'email' => null, 'remember' => null, 'return' => null );
		$ocnxn		= cnxn( $this->_get_cnxnid_from_session() );
		$types		= types();
		$cnxn_libs	= array();
		
		// Accommodate the possibility that a user is logging in from a connection form not mapped by the origin
		foreach ( $types as $type => $toss ) {
			if ( $type == $ocnxn->get( "type" ) ) array_unshift( $cnxn_libs, $type );
			else array_push( $cnxn_libs, $type );
		}
		
		foreach( $cnxn_libs as $type ) {
			$cnxn_lib	= cnxn_library( $type );
			$creds		= $cnxn_lib->get_authentication_credentials();
			
			foreach ( $creds['received'] as $k => $v ) {
				// Be sure we dont overwrite any credentials that are defined by the origin cnxn
				if ( $std[$k] != null ) continue;
				
				// Grab the credential
				if (! ( $tmp = get_var( $v, $creds['source'] ) ) ) continue;
				
				// Test username to be sure it isn't an email
				if ( ( $k == 'username' ) && ( is_email( $tmp ) ) ) {
					$std['email'] = $tmp;
					continue;
				}
				
				// Test email to be sure it is an email
				if ( ( $k == 'email' ) && (! is_email( $tmp ) ) ) {
					$std['username'] = $tmp;
					continue;
				}
				
				// Set the credential to appropriate key
				$std[$k] = get_var( $v, $creds['source'] );
			}
		}
		
		$this->set( "credentials", $std );
		
		if ( empty( $std ) ) return false;
		else  return $std;
	}
}

?>