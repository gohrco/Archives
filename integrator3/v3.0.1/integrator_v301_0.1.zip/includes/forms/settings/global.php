<?php

$form['global']	= array(
	'Sitename' => array(
			'value'			=> 'Integrator',
			'order'			=> 10,
			'type'			=> 'text',
			'validation'	=> 'required|xss_clean'
		),
	'Enable' => array(
			'apiname'		=> null,
			'value'			=> false,
			'order'			=> 20,
			'type'			=> 'yesno',
			'validation'	=> 'required|is_natural'
		),
	'Debug' => array(
			'apiname'		=> null,
			'value'			=> false,
			'order'			=> 30,
			'type'			=> 'yesno',
			'validation'	=> 'required|is_natural'
		),
);

$form['system'] = array(
	'SystemURL'	=> array(
			'value'			=> 'http://',
			'order'			=> 10,
			'type'			=> 'text',
			'validation'	=> 'required|xss_clean'
	),
	'TmpDir'	=> array(
			'value'			=> '',
			'order'			=> 30,
			'type'			=> 'text',
			'validation'	=> 'required'
	),
	'LogCount' => array(
		'value'				=> 1000,
		'order'				=> 50,
		'type'				=> 'text',
		'validation'		=> 'required|is_numeric'
	),
);

$form['email'] = array(
	'Emailprotocol'	=> array(
			'value'			=> 'sendmail',
			'order'			=> 10,
			'type'			=> 'dropdown',
			'validation'	=> 'required'
	),
	'Emailsmtpport'	=> array(
			'value'			=> '25',
			'order'			=> 20,
			'type'			=> 'text',
			'validation'	=> ''
	),
	'Emailsmtphost'	=> array(
			'value'			=> null,
			'order'			=> 30,
			'type'			=> 'text',
			'validation'	=> 'xss_clean'
	),
	'Emailsmtpuser'	=> array(
			'value'			=> null,
			'order'			=> 40,
			'type'			=> 'text',
			'validation'	=> 'xss_clean'
	),
	'Emailsmtppass'	=> array(
			'value'			=> null,
			'order'			=> 50,
			'type'			=> 'password',
			'validation'	=> 'xss_clean'
	),
	'Emailfromname'	=> array(
			'value'			=> 'Integrator Administrator',
			'order'			=> 60,
			'type'			=> 'text',
			'validation'	=> 'required|xss_clean'
	),
	'Emailaddress'	=> array(
			'value'			=> 'admin@yourdomain.com',
			'order'			=> 70,
			'type'			=> 'text',
			'validation'	=> 'required|valid_email'
	)
);
