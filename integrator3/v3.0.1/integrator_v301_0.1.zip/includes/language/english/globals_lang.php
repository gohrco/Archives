<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.1 ( $Id: globals_lang.php 19 2012-04-28 02:38:33Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the global language translations for the admin backend of the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * GLOBAL VARIABLES - Used across most / all controllers
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['cancel']			= "Cancel";
		$lang['no']				= "No";
		
		$lang['savechanges']	= "Save Changes";
		$lang['submit']			= "Submit";
		$lang['updatesettings']	= "Update Settings";
		$lang['yes']			= "Yes";
		$lang['csrfcheck']		= "Invalid token!";
		$lang['forgot.password']	= "Forgot your password?";
		
		
/**
 * **********************************************************************
 * SIDEBAR
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['side.greeting']		= 'Welcome back %1$s %2$s';
		$lang['side.license']		= 'License';
		$lang['side.registeredto']	= 'Registered to';
		$lang['side.registeredon']	= 'Registered on: %s';
		$lang['side.licdue']		= 'Next due date: %s';
		$lang['side.licerror']		= 'License Error';
		$lang['side.versionchecking']	= 'Checking for updates...';
		
		
/**
 * **********************************************************************
 * MENU LINKS
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['menu.home']				= "Dashboard";
		$lang['menu.settings']			= "Configuration";
		$lang['menu.globalsettings']	=	"Global Settings";
		$lang['menu.apisettings']		=	"API Settings";
		$lang['menu.userbridging']		=	"User Bridging";
		$lang['menu.visualsetup']		=	"Visual Setup";
		$lang['menu.registrations']		=	"Registration Settings";
		$lang['menu.notifications']		=	"Notifications";
		$lang['menu.connections']		= "Connections";
		$lang['menu.addnewcnxn']			= "Add New Connection";
		$lang['menu.rendering']			= "Rendering";
		$lang['menu.pagemaps'] 				= "Page Maps";
		$lang['menu.langmaps']				= "Language Maps";
		$lang['menu.usermgr']			= "User Management";
		$lang['menu.finduser'] 				= "Find User";
		$lang['menu.createuser']			= "Create User";
		$lang['menu.modifyuser']			= "Modify User";
		$lang['menu.userlog']				= "User Log";
		$lang['menu.manageadmins']		= "Admin Management";
		$lang['menu.help']				= "Help";
		$lang['menu.stepbystep']			= "Step by Step Setup";
		$lang['menu.documentation']			= "Documentation";
		$lang['menu.systemstatus']			= "System Status";
		
		
/**
 * **********************************************************************
 * LICENSING
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['licensing.error']		= "There is a problem with your license.  Please double check and ensure it is valid.";
		$lang['button.license.manage']	= 'Manage';
		
		
/**
 * **********************************************************************
 * NOTICE MESSAGES
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['msg.notice.update']			= 'Version <span style="letter-spacing: 0em; ">%s</span> is available for Integrator 3!';
		
		
/**
 * **********************************************************************
 * ALERT MESSAGES
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['msg.alert.disabled']			= 'Integrator is completely disabled!';
		$lang['msg.alert.visualdisabled']	= 'Integrator is set not to wrap any applications at all!';
		$lang['msg.alert.debugison']		= 'Debugging is turned on!';
		