<?php

/* SECURITY CHECKPOINT */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Base Admin Controller for all configuration and administration controllers
 * @version		3.0.1.0.1
 * 
 * @since		3.0.0
 * @author		Steven
 */
class Admin_Controller extends MY_Controller
{
	/**
	 * Construtor for this class (called directly by siblings)
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @since		3.0.0
	 */
	public function Admin_Controller()
	{
		parent::__construct();
		
		// Start Benchmark Point
		$this->benchmark->mark('admin_controller_start');
		
		// Load session and form validation libraries
		$this->load->library('session');
		log_message('debug', 'Session Loaded in Admin Controller' );
		
		$this->load->library('form_validation');
		$this->load->library( 'fields_library' );
		
		$this->form_validation->set_error_delimiters( '<li>', '</li>' );
		
		//$this->form_validation->set_error_delimiters( '<p><span class="ui-icon ui-icon-alert" style="float: left; margin-right: 0.3em;"></span><strong>Alert:</strong>  ', '</p>' );
		//$this->form_validation->set_error_delimiters();
		// Load the template library
		$this->load->library('template');
		$this->load->helper( "html" );
		$this->load->helper( "icon" );
		
		$this->load->language( 'globals' );
		
		if ( ! self::_check_access()) {
			show_error($this->lang->line('admin_access_denied'));
			exit;
		}
		
		if ( ! parent::_check_license() ) {
			$this->session->set_flashdata('error_message', lang( 'licensing.error' ) );
			redirect( 'license/index', 'refresh' );
			exit;
		}
		
		$params	= & Params::getInstance();
		
		// Use $admin_user in templates to avoid collissions
		$this->data['admin_user'] = $this->user;
		$this->data['infoMsg']	= $this->session->flashdata('infoMsg');
		$this->data['error_message']	= null;
		$this->data['success_message']	= null;
		$this->data['alert_message']	= null;
		$this->data['info_message']		= null;
		$this->data['notice_message']	= null;
		$this->data['menu_cnxns']		= null;
		
		$pcs = explode( "-", $params->get( 'License' ) );
		$this->data['licensekey']		= array( 'key' => $params->get( 'License' ), 'type' => $pcs[0] );
		$this->data['license']			= $GLOBALS['license'];
		
		$version = $params->get( 'Version' );
		$pcs = explode( '.', $version );
		$sub	= array_pop( $pcs );
		$sub	= array_pop( $pcs ) . '.' . $sub;
		$main	= implode( '.', $pcs );
		
		$this->data['version']			= $main . ' (' . $sub . ')';
		
		$this->data['guest']			= $this->_is_public();
		
		// ADMIN USERS ONLY
		if (! $this->_is_public() ) {
			$this->data['menu_cnxns']	= $this->_set_connection_menu();
			$this->data['nav']			= $this->_build_menu();
			$this->data['route']		= $this->uri->segment( 1, '' );
			$this->data['updurl']		= base_url( 'index.php/ajax/updatecheck' );
			
			// Check for updates
			$update = $this->_check_for_update();
			if ( $main != $update && $update !== false ) {
				$this->data['notice_message'] = sprintf( lang( 'msg.notice.update' ), $update );
			}
		}
		else {
			$this->template->append_metadata( css( 'login.css' ) );
		}
		
		$this->template
					->append_metadata( $this->_build_header() )
					->set_partial( 'footer',			'partials/footer' )
					->set_partial( 'sidehdr',			'partials/sidehdr' )
					->set_partial( 'sidebar',			'partials/sidebar' )
					->set_partial( 'sidelic',			'partials/sidelic' )
					->set_partial( 'debug',				'partials/debug' )
					->set_partial( 'content_header',	'partials/content_header' )
					->set_partial( 'content_messages',	'partials/content_messages' );
		
		// End Benchmark Point
		$this->benchmark->mark('admin_controller_end');
	}
	
	
	/**
	 * Method to build the header for a given page
	 * @access		protected
	 * @version		3.0.1.0.1
	 * @param		string		- $data: permits overwriting and passing to parent
	 * 
	 * @return		string containing header info
	 * @since		3.0.1 (0.1)
	 */
	protected function _build_header( $data = null )
	{
		$use	= $this->uri->segment(1, '') . '|' . $this->uri->segment(2, 'index');
		$end	= "\n\t\t";
		
		switch ( $use ):
		case 'help|systemstatus':
			
			break;
		case 'admin|index':
				
			break;
		endswitch;
		
		$data	.=	blueprint( "screen.css" ) . $end
				.	blueprint( "print.css", "media" ) . $end
				.	"<!--[if lt IE 9]>" . blueprint( "ie.css" ) . "<![endif]-->" . $end
				.	blueprint( "plugins/buttons/screen.css" ) . $end
				.	blueprint( "plugins/fancy-type/screen.css" ) . $end
				.	js( "jquery-1.5.1.min.js" ) . $end
				.	js( "jquery-ui-1.8.13.custom.min.js" ) . $end
				.	js( 'jquery.tablesorter.js' ) . $end
				.	js( 'functions.js' ) . $end
				.	css( "jquery-ui-1.8.13.custom.css" ) . $end
				.	css( "admin.css" ) . $end
				.	js( "ajaxfunctions.js" ) . $end;
	
		return $data;
	}
	
	
	/**
	 * Builds the menu array for use
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @return		array of menu objects
	 * @since		3.0.0
	 */
	private function _build_menu()
	{
		$menu	= array();
		$menu[]	= (object) array( 'anchor' => 'admin/index', 'text' => lang( 'menu.home' ), 'class' => 'dashboard' );
		
		// Settings Menu
		$submenu	= array();
		$submenu[]	= (object) array( 'anchor' => 'settings/index',			'text' => lang( 'menu.globalsettings' ), 'class' => 'global' );
		$submenu[]	= (object) array( 'anchor' => 'settings/api',			'text' => lang( 'menu.apisettings' ), 'class' => 'api' );
		$submenu[]	= (object) array( 'anchor' => 'settings/user',			'text' => lang( 'menu.userbridging' ), 'class' => 'user' );
		$submenu[]	= (object) array( 'anchor' => 'settings/visual',		'text' => lang( 'menu.visualsetup' ), 'class' => 'visual' );
		$submenu[]	= (object) array( 'anchor' => 'settings/registrations',	'text' => lang( 'menu.registrations' ), 'class' => 'register' );
		//$submenu[]	= (object) array( 'anchor' => 'settings/notifications',	'text' => lang( 'menu.notifications' ) );
		$menu[]		= (object) array( 'anchor' => '#', 'text' => lang( 'menu.settings' ), 'submenu' => $submenu, 'class' => 'configuration' );
		
		// Connection menu
		$cnxns		= $this->_set_connection_menu();
		$submenu	= array();
		
		if ( empty( $cnxns ) ) {
			if ( $this->can_add_cnxns() ) {
				$submenu[]	= (object) array( 'anchor' => 'cnxns/add', 'text' => lang( 'menu.addnewcnxn' ), 'class' => 'cnxnadd' );
				$menu[]	= (object) array( 'anchor' => '#', 'text' => lang( 'menu.connections' ), 'submenu' => $submenu, 'class' => 'cnxns' );
			}
		}
		else {
			foreach ( $cnxns as $c ) {
				$submenu[] = (object) array( 'anchor' => 'cnxns/edit/' . $c->id, 'text' => $c->name, 'class' => $c->class );
			}
			
			if ( $this->can_add_cnxns() ) {
				$submenu[]	= (object) array( 'anchor' => 'cnxns/add', 'text' => lang( 'menu.addnewcnxn' ), 'class' => 'cnxnadd' );
			}
			$menu[]	= (object) array( 'anchor' => '#', 'text' => lang( 'menu.connections' ), 'submenu' => $submenu, 'class' => 'cnxns' );
		}
		
		// Rendering Menu
		$submenu	= array();
		$submenu[]	= (object) array( 'anchor' => 'pagemap/index', 'text' => lang( 'menu.pagemaps' ), 'class' => 'renpage');
		$submenu[]	= (object) array( 'anchor' => 'langmap/index', 'text' => lang( 'menu.langmaps' ), 'class' => 'renlangs' );
		$menu[]		= (object) array( 'anchor' => '#', 'text' => lang( 'menu.rendering' ), 'submenu' => $submenu, 'class' => 'maps' );
		
		// Users Menu
		$submenu	= array();
		$submenu[]	= (object) array( 'anchor' => 'usermgr/find', 'text' => lang( 'menu.finduser' ), 'class' => 'userfind' );
		$submenu[]	= (object) array( 'anchor' => 'usermgr/create', 'text' => lang( 'menu.createuser' ), 'class' => 'useradd' );
		$submenu[]	= (object) array( 'anchor' => 'usermgr/modify', 'text' => lang( 'menu.modifyuser' ), 'class' => 'useredit' );
		$submenu[]	= (object) array( 'anchor' => 'usermgr/log', 'text' => lang( 'menu.userlog' ), 'class' => 'userlog' );
		$menu[]		= (object) array( 'anchor' => '#', 'text' => lang( 'menu.usermgr' ), 'submenu' => $submenu, 'class' => 'users' );
		
		$menu[]		= (object) array( 'anchor' => 'users/index', 'text' => lang( 'menu.manageadmins' ), 'class' => 'admins' );
		
		// Help  Menu
		$submenu	= array();
		$submenu[]	= (object) array( 'anchor' => 'help/stepbystep', 'text' => lang( 'menu.stepbystep' ), 'class' => 'helpstep' );
		$submenu[]	= (object) array( 'anchor' => 'help/documentation', 'text' => lang( 'menu.documentation' ), 'class' => 'helpdox' );
		$submenu[]	= (object) array( 'anchor' => 'help/systemstatus', 'text' => lang( 'menu.systemstatus' ), 'class' => 'helpstatus' );
		$menu[]		= (object) array( 'anchor' => '#', 'text' => lang( 'menu.help' ), 'submenu' => $submenu, 'class' => 'help' );
		
		// Set the current menu item
		$current	= $this->uri->segment(1, '') . '/' . $this->uri->segment(2, 'index');
		$currentsub	= trim( $this->uri->segment(1, '') . '/' . $this->uri->segment(2, 'index') . ( in_array( $this->uri->segment( 1, '' ), array( 'cnxns') ) ?  '/' . $this->uri->segment(3, '' ) : '' ), '/' );
		foreach ( $menu as & $m ) {
			$m->current	= false;
			if ( isset( $m->submenu ) ) {
				foreach ( $m->submenu as & $sub ) {
					$sub->current = false;
					if ( $sub->anchor == $currentsub ) {
						$sub->current	= true;
						$m->current		= true;
					}
				}
			}
			else {
				if ( $m->anchor == $current ) {
					$m->current = true;
				}
			}
		} 
		
		return $menu;
	}
	
	
	/**
	 * Checks access to the configuration / backend (only admins allowed)
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @return		boolean true if access is allowed, false if denied
	 * @since		3.0.0
	 */
	private function _check_access()
	{
		// Dont need to log in, this is an open page
		if ( $this->_is_public() ) {
			return true;
		}
		else if ( ! $this->user) {
			redirect('admin/login');
		}
		
		// Admins can go straight in
		else if ( $this->auth->is_admin() === true ) {
			return true;
		}
		
		return false;
	}
	
	
	/**
	 * Checks Go Higher for updated application
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @return		string containing new primary version or false if none available / unfound
	 * @since		3.0.0 (0.4)
	 */
	private function _check_for_update()
	{
		$update	= false;
		$data	= array();
		$file	= "update_" . date("Ymd");
		
		if ( $update = $this->cache->get( $file ) ) {
			return $update;
		}
		
		if( ( $latest_version = (string) @file_get_contents( "https://www.gohigheris.com/updates/int3/feed/" ) ) === false ) {
			return false;
		}
		
		$lines = explode( "\n", $latest_version );
		foreach ( $lines as $line ) {
			$parts = explode( "=", $line );
			if( empty($parts[1] )) continue;
			$parts[1] = trim( trim( $parts[1] ), "\"" );
			$data[$parts[0]] = $parts[1];
		}
		
		if ( isset( $data['version'] ) ) {
			$update = $data['version'];
			$this->cache->save( $file, $update, 21600 );
		}
		
		return $update;
	}
	
	
	/**
	 * Creates a quick list of menu items of connections
	 * @access		private
	 * @version		3.0.1.0.1
	 * 
	 * @return		array containing available connections
	 * @since		3.0.0
	 */
	private function _set_connection_menu()
	{
		$menu	= array();
		$cnxns	= get_cnxns();
		foreach ( $cnxns as $id => $cnxn ) {
			$menu[]	= (object) array( 'id' => $id, 'name' => $cnxn->get( 'name' ), 'class' => $cnxn->get( 'type' ) );
		}
		return $menu;
	}
}