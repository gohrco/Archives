<div class="boxer">
	
	<h2>
	
	<?php echo lang( 'cbox.title' ); ?>
	
	<?php echo ( is_null( $status ) ? anchor( 'admin/turn_on/cnxnstatus', image( 'icon16-up.png' ), 'class="btn"' ) : anchor( 'admin/turn_off/cnxnstatus', image( 'icon16-down.png' ), 'class="btn"' ) ); ?>	
	
	</h2>
	
	<?php if (! is_null( $status ) ) : ?>
	 
	<table width="100%">
		<thead>
			<tr>
				<td class="txtctr"><?php echo lang( 'cbox.hdr.cnxn' ); ?></td>
				<td class="txtctr"><?php echo lang( 'cbox.hdr.type' ); ?></td>
				<td class="txtctr"><?php echo lang( 'cbox.hdr.active' ); ?></td>
				<td class="txtctr"><?php echo lang( 'cbox.hdr.user' ); ?></td>
				<td class="txtctr"><?php echo lang( 'cbox.hdr.visual' ); ?></td>
				<td class="txtctr"><?php echo lang( 'cbox.hdr.api' ); ?></td>
			</tr>
		</thead>
		<tbody>
		
			<?php foreach ( $status as $item ) : ?>
			
				<tr>
					<td>
						<?php echo anchor( 'cnxns/edit/' . $item->id, $item->name); ?>
					</td>
					<td class="txtctr">
						<?php echo $item->type; ?>
					</td>
					<td class="txtctr">
						<?php echo image( 'icon32_status' . ( $item->active ? 'on' : 'off' ) . '.png' ); ?>
					</td>
					<td class="txtctr">
						<?php echo image( 'icon32_status' . ( $item->user ? 'on' : 'off' ) . '.png' ); ?>
					</td>
					<td class="txtctr">
						<?php echo image( 'icon32_status' . ( $item->visual ? 'on' : 'off' ) . '.png' ); ?>
					</td>
					<td class="txtctr">
						<?php echo image( 'icon32_status' . ( $item->ping ? 'on' : 'off' ) . '.png' ); ?>
					</td>
				</tr>
		
			<?php endforeach; ?>
		</tbody>
	</table>
	
	<?php endif; ?>
</div>