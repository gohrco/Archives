<?php echo form_open( $action ); ?>

<?php foreach ( $fields as $item ) : ?>
<div class="append-bottom border-bottom">
	<div class="span-10 left">
		<div class="span-4"><?php echo $item->label; ?></div>
		<div class="span-6 last"><?php echo $item->field; ?></div>
	</div>
	<div class="push-1 span-17 small last""><?php echo $item->desc; ?></div>
	<div class="clear"> </div>
</div>
<?php endforeach; ?>

<?php foreach( $hidden as $hide ) : ?>
<?php echo $hide->field; ?>
<?php endforeach; ?>

<div class="push-4 append-bottom clear">
	<?php echo form_button( array( 'name' => 'submit', 'id' => 'submit', 'value' => true, 'type' => 'submit', 'content' => lang( $submit ) ) );?>
</div>
<?php echo form_close(); ?>