<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| Hooks
| -------------------------------------------------------------------------
| This file lets you define "hooks" to extend CI without hacking the core
| files.  Please see the user guide for info:
|
|	http://www.codeigniter.com/user_guide/general/hooks.html
|
*/

// POST CONTROLLER CONSTRUCTOR HOOKS
$hook['post_controller_constructor'][] = array(
	'function' => 'install_check',
	'filename' => 'install_check.php',
	'filepath' => 'hooks'
);

$hook['post_controller_constructor'][] = array(
	'function' => 'log_purge',
	'filename' => 'log_purge.php',
	'filepath' => 'hooks'
);

// POST SYSTEM HOOKS
$hook['post_system'][] = array(
		'function'	=> 'debug_cleanup',
		'filename'	=> 'post_system.php',
		'filepath'	=> 'hooks'
);