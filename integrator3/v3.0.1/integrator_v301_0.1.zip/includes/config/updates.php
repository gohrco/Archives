<?php


$config['update_sites']['application'] = 'https://www.gohigheris.com/updates/int3/application';

$config['update_sites']['cnxns']['joomla']['component']					= 'https://www.gohigheris.com/updates/int3/cnxns/joomla/component';
$config['update_sites']['cnxns']['joomla']['intlogin']					= 'https://www.gohigheris.com/updates/int3/cnxns/joomla/intlogin';
$config['update_sites']['cnxns']['joomla']['authenticationplugin']		= 'https://www.gohigheris.com/updates/int3/cnxns/joomla/plugins/authentication';
$config['update_sites']['cnxns']['joomla']['systemplugin']				= 'https://www.gohigheris.com/updates/int3/cnxns/joomla/plugins/system';
$config['update_sites']['cnxns']['joomla']['userplugin']				= 'https://www.gohigheris.com/updates/int3/cnxns/joomla/plugins/user';

$config['update_sites']['cnxns']['whmcs']	= 'https://www.gohigheris.com/updates/int3/cnxns/whmcs';
$config['update_sites']['cnxns']['fusion']	= 'https://www.gohigheris.com/updates/int3/cnxns/fusion';
$config['update_sites']['cnxns']['wp']		= 'https://www.gohigheris.com/updates/int3/cnxns/wp';

$config['cnxns']	=	array(
							'joomla'	=> array( 'cnxns|joomla|component' => null , 'cnxns|joomla|intlogin' => null , 'cnxns|joomla|authenticationplugin' => null , 'cnxns|joomla|systemplugin' => null , 'cnxns|joomla|userplugin' => null ),
							'whmcs'		=> array( 'cnxns|whmcs' => null ),
							'fusion'	=> array( 'cnxns|fusion' => null ),
							'wp'		=> array( 'cnxns|wp' => null )
						);
