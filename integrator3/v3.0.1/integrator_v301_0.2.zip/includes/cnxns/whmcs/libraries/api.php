<?php


class Whmcs_API extends API_Library
{
	protected		$apioptions	= array();
	protected		$apipost	= array();
	protected		$apiurl		= null;
	
	public function load( $options )
	{
		parent::load( $options );
		
		// =====================================
		// ---BEGIN: Set default api options
		$apioptions	= $this->get( 'apioptions' );
			$apioptions['HEADER'] =  true;
			$apioptions['RETURNTRANSFER'] = true;
		$this->set( 'apioptions', $apioptions );
		// ---END:   Set default api options
		// =====================================
		// ---BEGIN: Setting GLOBAL API curl options
		$apioptions	= $this->get( 'apioptions' );
			if ( $this->get( 'sslverify', 0, 'api' ) == 1 ) {
				$apioptions['SSL_VERIFYHOST'] = true;
				$apioptions['SSL_VERIFYPEER'] = true;
			}
		$this->set( 'apioptions', $apioptions );
		// ---END:   Setting GLOBAL API curl options
		// =====================================
		// ---BEGIN: Setting API url
		$url 	=   $this->get( "apiurl", $this->get( 'baseurl', null, 'params' ), 'api' );
		$uri	= & Uri::getInstance( $url );
		$uri->setScheme( "http" . ( ( $this->get( "sslverify", 0, 'api' ) == 1 ) ? "s" : "" ) );
		$uri->setPath( rtrim( $uri->getPath(), "/" ) . "/includes/api.php" );
		$this->set( "apiurl", $uri->toString() );
		// ---END:   Setting API url
		// =====================================
		// ---BEGIN: Setting API curl options
		$apioptions	= $this->get( 'apioptions' );
			// Do something if needed
		$this->set( 'apioptions', $apioptions );
		// ---END:   Setting API curl options
		// =====================================
		// ---BEGIN: Setting API variables
		$apipost	= $this->get( "apipost" );
		$apipost['username']	= $this->get( "username", null, 'api' );
		$apipost['password']	= md5( $this->get( "password", null, 'api' ) );
		if ( $this->get( "accesskey", null, 'api' ) ) {
			$apipost['accesskey']	= $this->get( "accesskey", null, 'api' );
		}
		$apipost['responsetype']	= 'json';
		$apipost['IntAPI']			= true;
		$this->set( "apipost", $apipost );
		// ---END:   Setting API variables
		// =====================================
		
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE API FUNCTIONS AND ARE CALLED DIRECTLY
	 * **********************************************************************
	 */

	

	/**
	 * Called to authenticate a set of user credentials
	 * @access		public
	 * @version		3.0.1.0.2
	 * @param		array		- $post: an array of variables to post (should be empty if no child library)
	 * 
	 * @return		boolean true if authenticated, false if failed
	 * @since		3.0.0
	 */
	public function authenticate( $post = array() )
	{
		$credentials	= get_var( "credentials" );
		$post			= array();
		
		$post['action']		= "validatelogin";
		$post['email']		= ( isset( $post['email'] ) ? $post['email'] : $credentials['email'] );
		$post['password2']	= ( isset( $post['password2'] ) ? $post['password2'] : $credentials['password'] );
		
		$call	= $this->_call_api( $post );
		
		if ( $call['result'] == 'success' ) {
			return true;
		}
		else {
			// Log error message ?
			return false;
		}
	}
	
	
	/**
	 * Retrieves information about the Integrator 3 cnxn
	 * @access		public
	 * @version		3.0.1.0.2
	 * 
	 * @return		array or false on error
	 * @since		3.0.1 (0.1)
	 */
	public function get_info()
	{
		$post	= array(	'action'	=> 'integrator',
							'task'		=> 'get_version'
		);
		
		$call	= $this->_call_api( $post );
		
		if ( $call['result'] == 'success' ) {
			unset ( $call['result'] );
			return $call;
		}
		else {
			// Log error message ?
			return false;
		}
	}
	
	
	/**
	 * Retrieves the languages on this connection
	 * @access		public
	 * @version		3.0.1.0.2
	 * 
	 * @return		array containing either the languages or empty array
	 * @since		3.0.0
	 */
	public function get_languages()
	{
		$post	= array(	'action'	=> "integrator",
							'task'		=> "get_languages"
		);
		
		$call	= $this->_call_api( $post );
		
		if ( $call['result'] == 'success' ) {
			unset ( $call['result'] );
			return $call;
		}
		else {
			// Log error message ?
			return false;
		}
	}
	
	
	/**
	 * Retrieves missing credentials from the connection
	 * @access		public
	 * @version		3.0.1.0.2
	 * @param		string		- $credential: the item being sought
	 * 
	 * @return		string containing the found item or false on error or nothing found
	 * @since		3.0.0
	 */
	public function get_missing_credential( $credential = 'password' )
	{
		$missing_item = false;
		switch( $credential ):
		case 'password':
		default:
			// We can't get a password from WHMCS
			$missing_item = false;
			break;
		endswitch;
		return $missing_item;
	}
	
	
	/**
	 * Retrieves the pages in this connection
	 * @access		public
	 * @version		3.0.1.0.2
	 * 
	 * @return		array containing the pages on this connection
	 * @since		3.0.0
	 */
	public function get_pages()
	{
		$post	= array(	'action'	=> "integrator",
							'task'		=> "get_pages"
		);
		
		$call	= $this->_call_api( $post );
		
		if ( $call['result'] == 'success' ) {
			unset ( $call['result'] );
			return $call;
		}
		else {
			// Log error message ?
			return false;
		}
	}
	
	
	/**
	 * Called to test a connection to ensure it responds
	 * @access		public
	 * @version		3.0.1.0.2
	 * @param		mixed		- $check: if a string, assume its an URL, if array test credentials
	 * 
	 * @return		mixed depending on need boolean true if responsive
	 * @since		3.0.0
	 */
	public function ping( $check = null )
	{
		if ( is_string( $check ) ) {
			$post	= array( 'task' => 'ping', 'action' => 'integrator' );
			$purl	= $check;
			$optns	= array( 'RETURNTRANSFER' => false );
		}
		else {
			$post	= array( 'task' => 'ping', 'action' => 'integrator' );
			$purl	= null;
			$optns	= array( 'RETURNTRANSFER' => true );
		}
		
		return $this->_call_api( $post, $purl, $optns );
	}
	
	
	/**
	 * Updates a setting on the cnxn
	 * @access		public
	 * @version		3.0.1.0.2
	 * @param		array		- $post: contains the settings array to update
	 *
	 * @return		true on success; false on error
	 * @since		3.0.0 (0.3)
	 */
	public function update_settings( $post = array() )
	{
		// Catch empties
		if ( ( $data = $this->_filter_setting_array( $post ) ) === false ) return true;
		
		// Assign task
		$send	= array(
					'settings'	=> $data,
					'action'	=> 'integrator',
					'task'		=> 'update_settings'
		);
		
		// Make the call
		$call	= $this->_call_api( $send );
		
		// Return result
		return $call['result'] == 'success';
	}
	
	
	/**
	 * Creates a new user in WHMCS
	 * @access		public
	 * @version		3.0.1.0.2
	 * @param		array		- $post: variables to post to the API
	 * 
	 * @return		true on success, false otherwise
	 * @since		3.0.0
	 */
	public function user_create()
	{
		$data	= $this->get_data();
		
		foreach( array( 'address1', 'city', 'country', 'phonenumber', 'postcode', 'state' ) as $item ) {
			$default = 'default' . $item;
			if (! isset( $data[$item] ) ) $data[$item] = null;
			if (! empty( $data[$item] ) ) continue;
			$data[$item] = $this->get_param( $default );
		}
		
		$data['action'] = 'addclient';
		$call = $this->_call_api( $data );
		
		return ( $call['result'] == 'success' ? true : $call['message'] );
	}
	
	
	/**
	 * Finds a user by email
	 * @access		public
	 * @version		3.0.1.0.2
	 * @param		boolean		- $data: if we want the data back set true, else return boolean
	 * 
	 * @return		varies can be boolean or the data result
	 * @since		3.0.0
	 */
	public function user_find( $data = false )
	{
		$post	= $this->get_data();
		
		// Intercept no email address
		if (! isset( $post['email'] ) ) {
			$this->set_error( 'This connection does not support usernames' );
			return false;
		}
		
		unset( $post['status'] );
		$post['action']	= 'getclientsdetails';
		$call = $this->_call_api( $post );
		
		if ( $call['result'] == 'success' ) {
			unset( $call['password'] );
			$this->place_data( $call );
		}
		else {
			
			$origmsg = $call['message'];
			
			// Try to grab a contact...
			$post['action'] = 'getcontacts';
			$cd		= $call;
			$call = $this->_call_api( $post );
			
			if ( ( $call['result'] == 'success' ) && ( isset( $call['contacts'] ) )  ) {
				$calldata	= $call['contacts']['contact'];
				if ( count( $calldata ) > 1 ) {
					$this->set_error( $origmsg );
				}
				else {
					unset( $calldata[0]['password'] );
					$this->place_data( $calldata[0] );
				}
			}
			else {
				$call = $cd;
				$this->set_error( $origmsg );
			}
			
		}
		
		return ( $call['result'] == 'success' ? ( $data ? $call : true ) : $call['message'] );
	}
	
	
	/**
	 * Searches for a user based on entry
	 * @access		public
	 * @version		3.0.1.0.2
	 * @param		array		- $post: contains search=>value
	 *
	 * @return		array
	 * @since		3.0.1 (0.2)
	 */
	public function user_search( $post = array() )
	{
		$post['action']			= 'getclients';
		$post['limitnumber']	= '100';
		
		$call = $this->_call_api( $post );
		
		if ( $call['result'] != 'success' ) return array();
		
		if (! isset( $call['clients']['client'] ) ) return array();
		else return $call['clients']['client'];
		
	}
	
	
	/**
	 * Updates user information on this connection
	 * @access		public
	 * @version		3.0.1.0.2
	 * @param		array		- $post: an array of variables to update
	 * 
	 * @return		boolean true if successful, error message otherwise
	 * @since		3.0.0
	 */
	public function user_update()
	{
		$data	=   $this->get_data();
		
		if (! isset( $data['update'] ) ) return false;
		$update	=   $data['update'];
		
		// If we don't have the client ID in the update array, we must get it
		if ( empty( $update['clientid'] ) ) {
			$post = array( 'action' => 'getclientsdetails', 'email' => $data['email'] );
			$call = $this->_call_api( $post );
			
			if ( ( $call['result'] == 'success' ) && isset( $call['userid'] ) ) {
				$update['clientid']	= $call['userid'];
				$update['action']	= 'updateclient';
				unset( $update['id'] );
			}
			else {
				
				$origmsg = $call['message'];
				
				// Try to grab a contact...
				$post['action'] = 'getcontacts';
				$call = $this->_call_api( $post );
				
				if ( ( $call['result'] == 'success' ) && ( isset( $call['contacts'] ) ) ) {
					
					$calldata	= $call['contacts']['contact'];
					if ( count( $calldata ) > 1 ) {
						$this->set_error( $origmsg );
					}
					else {
						$update['action'] = 'updatecontact';
						$update['contactid']	= $calldata[0]['id'];
						if ( isset( $update['active'] ) ) {
							$update['subaccount'] = $update['active'];
							unset( $update['active'] );
						}
						unset( $calldata[0]['password'] );
						$this->place_data( $calldata[0] );
					}
				}
				else {
					$this->set_error( $origmsg );
				}
			}
		}
		
		$call = $this->_call_api( $update );
		
		return ( $call['result'] == 'success' ? true : $call['message'] );
	}
	
	
	/**
	 * User removal call to this connection
	 * @access		public
	 * @version		3.0.1.0.2
	 * @param		string		- $email: contains just an email address
	 * 
	 * @return		boolean true if successful, false otherwise
	 * @since		3.0.0
	 */
	public function user_remove()
	{
		$data = $this->get_data();
		
		$post = array( 'action' => 'getclientsdetails', 'email' => $data['email'] );
		$call = $this->_call_api( $post );
		
		// Try close client
		if ( $call['result'] == 'success' ) {
			$post = array( 'action' => 'closeclient', 'clientid' => $call['userid'] );
			$call = $this->_call_api( $post );
			
			return ( $call['result'] == 'success' ) ? true : $call['message'];
		}
		
		$origmsg = $call['message'];
		
		// Try to grab a contact...
		$post['action'] = 'getcontacts';
		$call = $this->_call_api( $post );
		
		if ( ( $call['result'] == 'success' ) && ( isset( $call['contacts'] ) ) ) {
			
			$calldata	= $call['contacts']['contact'];
			if ( count( $calldata ) > 1 ) {
				$this->set_error( $origmsg );
				return $origmsg;
			}
			else {
				$update['action']		= 'updatecontact';
				$update['contactid']	= $calldata[0]['id'];
				$update['subaccount']	= '0';
				
				$call = $this->_call_api( $update );
			}
		}
		
		return ( $call['result'] == 'success' ? true : $origmsg );
	}
	

	/**
	 * Validates a set of new user credentials
	 * @access		public
	 * @version		3.0.1.0.2
	 * @param		array		- $nopasswordcheck: over ride the password check
	 * 
	 * @return		boolean true if valid, false otherwise
	 * @since		3.0.0
	 */
	public function user_validation_on_create( $nopasswordcheck = false )
	{
		$data			= $this->get_data();
		
		if (! empty( $data['email'] ) ) {
			$post = array( 'action' => 'getclientsdetails', 'email' => $data['email'] );
			$call = $this->_call_api( $post );
			
			if ( $call['result'] == 'success' ) return sprintf( 'Client already exists with email address `%s`', $data['email'] );
		}
		
		// If we ignore the pw strength when coming from the API then return
		if ( ( $this->get_param( 'ignorepwstrengthapi', 'users' ) ) || $nopasswordcheck ) return true;
		
		$data['action']		= "integrator";
		$data['task']		= "validate_password";
		
		$call	= $this->_call_api( $data );
		
		return ( $call['result'] == 'success' ) ? true: $call['data'] ;
	}
	
	
	/**
	 * Validates an updated set of user information
	 * @access		public
	 * @version		3.0.1.0.2
	 * @param		array		- $data: standard formed user data from Integrator
	 * 
	 * @return		boolean true if valid, false otherwise
	 * @since		3.0.0
	 */
	public function user_validation_on_update()
	{
		$data	=   $this->get_data();
		
		if (! isset( $data['update'] ) ) return true;
		
		$update	=   $data['update'];
		
		// Check for old / new email match
		if (! empty( $data['email'] ) && ! empty( $update['email'] ) ) {
			if ( $data['email'] != $update['email'] ) {
				$post = array( 'action' => 'getclientsdetails', 'email' => $update['email'] );
				$call = $this->_call_api( $post );
				
				if ( $call['result'] == 'success' ) return sprintf( 'Client exists with email address `%s`', $update['email'] );
			}
		}
		
		// If we ignore the pw strength when coming from the API then return
		if ( $this->get_param( 'ignorepwstrengthapi', 'users' ) ) return true;
		
		// Password check
		if (! empty( $update['password2'] ) ) {
			$post = array( 'action' => 'integrator', 'task' => 'validate_password', 'password2' => $update['password2'] );
			$call = $this->_call_api( $post );
			
			if ( $call['result'] != 'success' ) return $call['data'];
		}
		
		return true;
	}
	
	
	/**
	 * Calls the API connection through curl
	 * @access		public
	 * @version		3.0.1.0.2
	 * @param		array		- $api_post: an array of items to post to the API
	 * @param		string		- $api_url: the API url
	 * @param		array		- $api_options: any additional API CURLSETOPT to set
	 * 
	 * @return		response from API or false on error
	 * @since		3.0.0
	 * @see 		Cnxns_library::_call_api()
	 */
	protected function _call_api( $api_post = array(), $api_url = null, $api_options = array() )
	{
		if ( empty( $api_post ) ) return false;
		
		// Handle URL
		$api_url		= ( $api_url == null ? $this->get( 'apiurl' ) : $api_url );
		
		// Handle Options
		$api_options	= array_merge( $this->get( 'apioptions' ), $api_options );
		
		// Handle Post
		$api_post		= array_merge( $this->get( "apipost" ), $api_post );
		
		$result			= parent::_call_api( $api_post, $api_url, $api_options );
		
		if ( ( $response = json_decode( $result, TRUE ) ) == NULL ) {
			$CI = & get_instance();
			if ( $CI->debug() ) {
				echo $CI->curl->debug( "API Call from Joomla16 Library" );
			}
			return false;
		}
		else return $response;
	}
}