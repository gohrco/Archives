<table id="userresults">
	
	<thead>
		
		<tr>
			
			<th colspan="2" class="blank" style="text-align: left !important; ">
				
				<?php echo lang( 'usermgr.emailaddr' ); ?>
				
				<div class="sorter"></div>
				
			</th>
			
		</tr>
		
	</thead>
	
	<tbody>
	
<?php 

foreach ( $results as $email => $items ) :
	
?>
		<tr>
			
			<td>
				
				<?php echo base64_decode( $email ); ?>
				
			</td>
			
			<td width="50px"><div class="arrow"></div></td>
			
		</tr>
		
		<tr>
			
			<td colspan="2"> 
				
				<div class="details">
					
					<?php foreach ( $items as $user ): ?>
						
						<div class="row">
							
							<div class="name">
								
								<?php echo $user['firstname']; ?> <?php echo $user['lastname']; ?>
								
							</div>
							
							<div class="user">
								
								<?php echo lang( 'usermgr.username' ); ?>: <?php echo $user['username']; ?>
								
							</div>
							
							<div class="cnxn">
								
								<?php echo lang( 'usermgr.cnxn' ); ?>:  <?php echo $user['cnxn_id']; ?>
								
							</div>
							
						</div>
						
					<?php endforeach; ?>
					
				</div>
				
				<div class="actions">
							
					<?php echo anchor( 'usermgr/find/' . $email, lang( 'btn.edituser' ), 'class="button"' ); ?>
					
				</div>
				
			</td>
			
		</tr>
		
<?php endforeach; ?>

	</tbody>
	
</table>

<script type="text/javascript">
//jQuery('#userresults').tablesorter();

jQuery(document).ready(function(){
	jQuery("#userresults tr:odd").addClass("odd");
	jQuery("#userresults tr:not(.odd)").hide();
	jQuery("#userresults tr:first-child").show();
	jQuery("#userresults tr.odd").click(function(){
		jQuery(this).next("tr").toggle();
		jQuery(this).find(".arrow").toggleClass("up");
	});
	//jQuery("#userresults").jExpand();
});
</script>     