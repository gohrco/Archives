<?php echo form_open("users/deactivate/".$user['id']);?>

<div class="append-bottom clear"><label class="span-4" for="confirm"><?php echo lang( 'users.deactivate.label')?></label>
<input type="radio" name="confirm" value="yes" checked="checked" /> <?php echo lang( 'yes' ); ?>
<input type="radio" name="confirm" value="no" /> <?php echo lang( 'no' ); ?>
</div>

<?php echo form_hidden($csrf); ?>
<?php echo form_hidden(array('id'=>$user['id'])); ?>

<div class="push-4 append-bottom clear"><?php echo form_button( array( 'name' => 'submit', 'id' => 'submit', 'value' => true, 'type' => 'submit', 'content' => lang( 'submit' ) ) );?></div>
<?php echo form_close();?>