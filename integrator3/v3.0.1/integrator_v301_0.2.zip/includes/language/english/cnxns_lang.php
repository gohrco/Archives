<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.2 ( $Id: cnxns_lang.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the cnxns controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * ADD CNXNS
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['cnxns.add']				= "Add Connection";
		$lang['cnxns.add.desc']			= "Select what type of connection you wish to add to the Integrator and press `Add Connection` to continue.";
		
		$lang['msg.success.cnxnadd']	= "Selected connection added!";
		$lang['msg.error.unknown']		= 'An unknown error occurred';
		
		$lang['btn.addcnxn']			= "Add Connection and Continue";
		
		$lang['label.type']				= "Connection Type";
		$lang['desc.type']				= "Select one of these types of connections to add to your Integrator application.";
		
		
		
/**
 * **********************************************************************
 * DELETE CNXNS
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['msg.success.cnxndeleted']	= "Connection successfully deleted";
		$lang['msg.error.cnxndelete']		= "Unable to delete the connection";
		
		$lang['dialog.delete.warning']		= "Deleting this connection if it is still being used will have unwanted results such as failure to log users in completely or failure to wrap your site.  This cannot be undone without recreating the connection from scratch.";
		$lang['dialog.delete.cnxntitle']	= "Delete `%s`";
		
		
/**
 * **********************************************************************
 * EDIT CNXNS
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['cnxns.edit']					= "Edit Connection";
		$lang['cnxns.edit.desc']			= "Make changes to this connection and press 'Save Changes' at the bottom.  To delete the connection, press 'Delete Connection' at the bottom.";
		
		$lang['btn.editcnxn']				= "Save Changes";
		$lang['btn.delcnxn']				= "Delete Connection";
		
		$lang['msg.error.nocnxnselected']	= "No connection or invalid connection selected";
		
		
/**
 * **********************************************************************
 * EDIT CNXNS - GLOBAL TAB
 * - Translations may be overridden in cnxn specified language file
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['globals.tab']		= "Global Settings";
		
		$lang['label.globals.name']		= "Connection Name";
		$lang['label.globals.url']		= "Connection URL";
		$lang['label.globals.active']	= "Connection Active";
		
		$lang['desc.globals.name']		= "Assign a friendly usable name to this connection.  Be sure it is unique from any other connection names.";
		$lang['desc.globals.url']		= "Enter the URL for your connection here.";
		$lang['desc.globals.active']	= "This acts as a global switch for the connection; setting this to no will prevent visual and user integration.  If your settings are incorrect, this setting may be set to no for you to prevent unwanted integration errors.";
		
		
/**
 * **********************************************************************
 * EDIT CNXNS - API TAB
 * - Translations may be overridden in cnxn specified language file
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['api.tab']		= "API Settings";
		
		$lang['label.api.apiurl']		= "API URL";
		$lang['label.api.sslverify']	= "Force SSL for API";
		$lang['label.api.username']		= "API Username";
		$lang['label.api.password']		= "API Password";
		
		$lang['desc.api.apiurl']		= "Enter the URL to directly reach your API interface.  Typically it will be the same as your Connection URL, however in the event you are using redirects this will need to be set to the final redirected URL.  Once saved, the Integrator will attempt to connect to your API and modify your settings if redirects are encountered.";
		$lang['desc.api.sslverify']		= "If you have a valid SSL certificate on the domain this application is located on, you can set this to force ssl to ensure more secure communication.";
		$lang['desc.api.username']		= "Enter the username to use for connecting to your API";
		$lang['desc.api.password']		= "Enter the password to use for connecting to your API";
		
		
/**
 * **********************************************************************
 * EDIT CNXNS - USER TAB
 * - Translations may be overridden in cnxn specified language file
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['users.tab']		= "User Settings";
		
		$lang['label.users.userenable']		= "Enable User Integration";
		$lang['label.users.loginurl']		= "Login URL";
		$lang['label.users.logouturl']		= "Logout URL";
		$lang['label.users.processlogin']	= "User Log Ins";
		$lang['label.users.forceadd']		= "Force Add Users";
		$lang['label.users.usernametype']	= "Username Storage";
		$lang['label.users.storename']		= "Account Name Creation";
		$lang['label.users.storeusername']	= "Username Creation";
		
		$lang['desc.users.userenable']		= "This enables user integration across this connection.  To disable user integration for this connection only, set this to no.";
		$lang['desc.users.loginurl']		= "When originating from this connection, and when no return url is specified through the login form, the Login URL is the final destination after completing a log in process.";
		$lang['desc.users.logouturl']		= "When a request to log out has been received from this connection, the Integrator will send the user to this URL upon completion.  Be sure the URL is a publicly accessible URL that does not require a logged in user.";
		$lang['desc.users.processlogin']	= "This option allows you to control when a user should be logged into this connection.  By default, if User Integration is enabled, this should be set to `Always` to allow the user to log in on this connection regardless of where they come from.  You can set this to `Only If Originating Here` to have the user log in here only when they are originating from this connection, or you can set it to Never to not allow the user to log in here.  Note that setting this to Never but allowing User Integration to remain active will not log the user in but will keep any matching accounts in sync with changes made elsewhere (passwords, email changes, usernames etc).";
		$lang['desc.users.forceadd']		= "If a user logs in from another connection, but there isn't a matching account (by email address) on this connection, this setting will forcibly add a matching user account silently so that the user logs in across all your connections.  Setting this to `No` will prohibit a user that authenticates and logs in against another connection from appearing logged in on this connection.";
		$lang['desc.users.usernametype']	= "This controls what form the primary username takes on this connection.  This setting for most will remain at the default setting of `Usrename`.";
		$lang['desc.users.storename']		= "When a new user is created on this connection from another connection, this setting controls this connection assembles the `name` field if there isn't a specific field called `name` from the originating connection.";
		$lang['desc.users.storeusername']	= "When a new user is created on another connection that doesn't utilize a `username` field, this setting will control how a new username is generated for the user on this connection.";
		
		$lang['options.users.processlogin']		= array( 'always' => "Always", 'whenconnection' => "Only If Originating Here", 'never' => "Never" );
		$lang['options.users.usernametype']		= array( 'username' => "Username", 'email' => "Email Address" );
		$lang['options.users.storename']		= array( 'firstlast' => "First Last", 'firstlastco' => "First Last (Company)", 'lastfirst' => "Last, First", 'lastfirstco' => "Last, First (Company)" );
		$lang['options.users.storeusername']	= array( 'first.last' => "first.last style", 'last.first' => "last.first style", 'random' => "Random username generation", 'flastname' => "flastname style", 'firstnamel' => "firstnamel style", 'firstname' => "Firstname Only", 'lastname' => "Lastname Only" );
		$lang['options.users.usessl']			= array( 'none' => "Do Not Use", 'force' => "Always Use (Force)", 'ignore' => "Defer to Global Setting (Ignore)" );
		
/**
 * **********************************************************************
 * EDIT CNXNS - VISUAL TAB
 * - Translations may be overridden in cnxn specified language file
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['visuals.tab']	= "Visual Settings";
		
		$lang['label.visuals.visualenable']			= "Enable Visual Integration";
		$lang['label.visuals.sslenabled']			= "SSL Enabled";
		$lang['label.visuals.imgurl']				= "Image URL";
		$lang['label.visuals.convertcharacterset']	= "Convert Characterset";
		
		$lang['desc.visuals.visualenable']			= "This enables the visual integration to be performed using this connection. To disable the visual integration for this connection only, set this to no.";
		$lang['desc.visuals.sslenabled']			= "If this connection has a valid SSL certificate <u>AND</u> the application this is being rendered around also has a valid SSL certificate, you can set this to yes to enable an SSL page to be rendered.  If you encounter errors or invalid certificates, set this to no.";
		$lang['desc.visuals.imgurl']				= "This will typically be the same as the main connection URL.  If you don't have a valid SSL certificate on the site this connection is located, but it is being wrapped around an application that does, you can change this URL to point to a location that has a valid SSL certificate so that your pages are secure (not appearing broken).  Note that you will need to have copies of any javascript, css and images in this alternative location to utilize this ability.";
		$lang['desc.visuals.convertcharacterset']	= "If the characterset from the site you are pulling from does not match the destination characterset, this setting will let the Integrator attempt to convert the site to match the destinateion application.";
		
		
/**
 * **********************************************************************
 * CNXN MANAGER - Index page
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['cnxns.index']		= "Connection Manager";
		$lang['cnxns.index.desc']	= "Add a new connection or click on an existing connection to edit or remove it entirely.";
		
		
		
/**
 * **********************************************************************
 * VERIFY CNXNS
 * - Translations may be overridden in cnxn specified language file
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		
		$lang['msg.success.connectionsaved']	= "Connection Saved!";
		$lang['msg.error.noconnection']			= "Problem retrieving connection from the database";
		$lang['msg.error.cnxnping']				= "Error pinging Connection URL - Disabling the Connection";
		$lang['msg.error.cnxndeactivated']		= "<u>`%s` Deactivated</u>";
		
		$lang['msg.info.imgurlunset']			= "Image URL in visual settings was left unset - updated to match Connection URL";
		$lang['msg.info.nosslverify']			= "Error received verifying SSL - Disabling API SSL requirement";
		$lang['msg.info.apiurlcorrected']		= "API URL Corrected";
		
		
/**
 * **********************************************************************
 * DEBUG MESSAGES
 * - Translations may be overridden in cnxn specified language file
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['cnxns.handlecookie.error']	= 'There was a problem writing to the temporary directory.';
		$lang['cnxns.removecookie.error']	= 'Unable to remove the cookie from the temporary directory.';
		$lang['cnxns.removecookie.nofile']	= 'Cookie file not found to remove from temporary directory.';
		