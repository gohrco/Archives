<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.2 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      3.0.1 (0.1)
 * 
 * @desc       This is the English language file for the ajax controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * UPDATE CHECK
 * **********************************************************************
 */
		//     v3.0.1
		// ---------------
		
		$lang['ajax.isuptodate']		= "You have the latest versions available.";
		$lang['ajax.updateavail']		= "An update is available!";