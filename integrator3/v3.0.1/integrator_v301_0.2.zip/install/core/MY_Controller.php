<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.2 ( $Id: MY_Controller.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the core extension of the CI controller
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Core extension of the CI controller
 * @version		3.0.1.0.2
 *  
 * @since		3.0.0
 * @author		Steven
 */
class MY_Controller extends CI_Controller
{
	/**
	 * Collection of data passed to the view
	 * @access		protected
	 * @since		3.0.0
	 * @var 		array
	 */
	protected $data		= array(	'error_message' => null,
									'success_message' => null,
									'alert_message'	=> null,
									'info_message' => null,
									'notice_message' => null 
						);
	
	/**
	 * Constructor
	 * @access		public
	 * @version		3.0.1.0.2
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		// Be sure we are loading CI!
		parent::__construct();
		
		$this->load->library( 'session' );
		
		// We want install library, form validation and our handy dandy fields library
		$this->load->library( 'form_validation' );
		$this->load->library( 'fields_library' );
		$this->load->library( 'int_install', null, 'install' );
		
		$this->load->helper( 'language' );
		$this->load->language( 'install' );
		
		// If we are making an ajax call, don't bother assembling the template
		if ( $this->is_ajax() ) {
			$this->session->keep_flashdata( 'csrfkey' );
			$this->session->keep_flashdata( 'csrfvalue' );
			return;
		}
		
		$this->load->library( 'asset' );
		$this->load->helper( 'url' );
		$this->load->helper( 'html' );
		$this->load->helper( 'asset' );
		$this->load->library( 'template' );
		
		$this->template
					->append_metadata( blueprint( "screen.css" ) )
					->append_metadata( blueprint( "print.css", "media" ) )
					->append_metadata( "<!--[if lt IE 9]>" . blueprint( "ie.css" ) . "<![endif]-->" )
					->append_metadata( blueprint( "plugins/buttons/screen.css" ) )
					->append_metadata( blueprint( "plugins/fancy-type/screen.css" ) )
					->append_metadata( js( "jquery-1.5.1.min.js" ) )
					->append_metadata( js( "jquery-ui-1.8.13.custom.min.js" ) )
					->append_metadata( js( 'functions.js' ) )
					->append_metadata( css( "jquery-ui-1.8.13.custom.css" ) )
					->append_metadata( css( "admin.css" ) )
					->set_partial( 'sidebar',	'sidebar' )
					->set_partial( 'header',	'header' )
					->set_partial( 'footer',	'footer' )
					->set_partial( 'messages',	'messages' );
		
		
	}
	
	
	/**
	 * Checks for csrf forgeries - callback from form_validation
	 * @access		public
	 * @version		3.0.1.0.2
	 * 
	 * @return		boolean
	 * @since		3.0.0
	 */
	public function csrfcheck()
	{
		if ( $this->input->post( $this->session->flashdata( 'csrfkey' ) ) === false ) return false;
		if ( $this->input->post( $this->session->flashdata( 'csrfkey' ) ) == $this->session->flashdata( 'csrfvalue' ) ) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
	/**
	 * Checks permissions for the entered user - callback from form_validation
	 * @access		public
	 * @version		3.0.1.0.2
	 * 
	 * @return		boolean true if okay
	 * @since		3.0.0
	 */
	public function db_permcheck()
	{
		if (! ( $db = $this->install->test_db_connection() ) ) return false;
		$query = "SHOW GRANTS;";
		if (! ( $res = mysql_query( $query, $db ) ) ) return false;
		$row	= mysql_fetch_row( $res );
		$perm	= false;
		foreach ( $row as $row ) {
			// Find GRANT ALL PRIVILEGES ON
			if ( ( substr( $row, 0, 23 ) == 'GRANT ALL PRIVILEGES ON' ) || ( substr( $row, 0, 18 ) == 'GRANT USAGE ON *.*' ) ) {
				$perm = true;
				continue;
			}
			
			// Find individual privs
			$tmp	= explode( " ON ", $row );
			$pcs	= explode( ",", $tmp[0] );
			foreach( $pcs as $i => $pc ) $pcs[$i] = trim( $pc );
			if ( in_array( 'CREATE', $pcs ) ) $perm = true;
		}
		return $perm;
	}
	
	
	/**
	 * Checks to see if this is an ajax call
	 * @access		public
	 * @version		3.0.1.0.2
	 * 
	 * @return		boolean if ajax
	 * @since		3.0.0
	 */
	public function is_ajax()
	{
		return ! ( ( isset( $_SERVER['HTTP_X_REQUESTED_WITH' ] ) && strtolower( $_SERVER['HTTP_X_REQUESTED_WITH'] ) == 'xmlhttprequest' ) === FALSE);
	}
	
	
	/**
	 * Common location to build the page from
	 * @access		protected
	 * @version		3.0.1.0.2
	 * 
	 * @since		3.0.0
	 */
	protected function build_page()
	{
		// --------- Menu Items ---------
		$menu	= array();
		$menu[]	= (object) array( 'text' => 'menu.step1', 'class' => 'step1' );
		$menu[]	= (object) array( 'text' => 'menu.step2', 'class' => 'step2' );
		$menu[]	= (object) array( 'text' => 'menu.step3', 'class' => 'step3' );
		$menu[]	= (object) array( 'text' => 'menu.step4', 'class' => 'step4' );
		
		if ( $this->router->fetch_class() == 'install' ) {
			$menu[]	= (object) array( 'text' => 'menu.step5', 'class' => 'step5' );
			$menu[]	= (object) array( 'text' => 'menu.step6', 'class' => 'step6' );
		}
		
		foreach ( $menu as $m ) {
			$m->current = false;
			$t = explode( '.', $m->text );
			if ( $t[1] == $this->router->fetch_method() ) {
				$m->current = true;
			}
		}
		
		$this->data['nav'] = $menu;
		
		// --------- Header Items ---------
		$this->data['content_header']		= $this->router->fetch_class();
		$this->data['content_subheader']	= $this->router->fetch_class() . "." . $this->router->fetch_method();
		$this->data['content_description']	= 'desc.' . $this->data['content_subheader'];
		
		// --------- Message Items ---------
		$this->data['error_message']	.= $this->session->flashdata( 'error_message' );
		$this->data['success_message']	.= $this->session->flashdata( 'success_message' );
		$this->data['alert_message']	.= $this->session->flashdata( 'alert_message' );
		$this->data['info_message']		.= $this->session->flashdata( 'info_message' );
		$this->data['notice_message']	.= $this->session->flashdata( 'notice_message' );
		
		if ( validation_errors() ) {
			$this->data['error_message'] .= validation_errors();
		}
		
		// --------- Title Item ---------
		$this->template->title( "Integrator 3.0", lang( $this->router->fetch_class() . "." . $this->router->fetch_method() ) );
		
		// --------- JS Footer Items ---------
		$this->data['jsfooter']	= $this->fetch_javascript( $this->router->fetch_class() . '/' . $this->router->fetch_method() );
	}
	
	
	/**
	 * Retrieves the javascript to stick at the bottom of the page
	 * @access		protected
	 * @version		3.0.1.0.2
	 * @param		string		- $page: contains the class / method being called for
	 * 
	 * @return		string containing javascript
	 * @since		3.0.0
	 */
	protected function fetch_javascript( $page = 'install/step1' )
	{
		$data		= null;
		
		switch ( $page ):
		// -- Step 2: Database check
		case 'install/step2':
			$siteurl	= site_url( 'ajax/check_db' );
			$data		= <<< JS
$(document).ready( function () {
	var ajaxWrap = $('#ajax-wrap');
	var ajaxMsg = $('#ajax-msg');
	var valid	= $('input[name=db_valid]');
	$('input[name=db_password]').bind( 'keyup focus', function() {
		var t = this;
		var dbhost = $('#db_hostname').val();
		var dbuser = $('#db_username').val();
		var dbport = $('#db_port').val(); 
		if ( ( this.value != this.lastValue ) || ( dbhost != this.lastDbhost ) || ( dbuser != this.lastDbuser ) || ( dbport != this.lastDbport ) ) {
			if (! dbhost ) return;
			if (! dbuser ) return;
			if (this.timer) clearTimeout(this.timer);
			ajaxWrap.removeClass('error').removeClass('success').addClass('ajax');
			ajaxMsg.html('Checking your settings');
			
			this.timer = setTimeout(function () {
				$.ajax({
					url: '{$siteurl}',
					data: 'dbhost=' + dbhost + '&dbuser=' + dbuser + '&dbpass=' + t.value + '&dbport=' +dbport,
					dataType: 'json',
					type: 'post',
					success: function (j) {
						ajaxWrap.removeClass('ajax');
						ajaxMsg.html(j.message);
						if ( j.success == 'true' ) {
							ajaxWrap.addClass( 'success' );
							valid.val(true);
						} else {
							ajaxWrap.addClass( 'error' );
							valid.val(null);
						}
					}
				});
			}, 200);
			this.lastValue = this.value;
			this.lastDbhost = dbhost;
			this.lastDbuser = dbuser;
			this.lastDbport = dbport;
		}
	});
});
JS;
			break;
		// -- Step 5: Installation
		case 'install/step5':
			$siteurl	= site_url( 'ajax/validate_db' );
			$data		= <<< JS
$(document).ready( function () {
	var ajaxWrap = $('#ajax-wrap');
	var ajaxMsg = $('#ajax-msg');
	var valid	= $('input[name=db_valid]');
	$('input[name=db_database], input[name=db_dbprefix], input[name=db_create]').bind( 'keyup focus blur change', function() {
		var t = this;
		var dbname = $('#db_database').val();
		var dbpref = $('#db_dbprefix').val();
		var dbmake = $('input[name=db_create]').attr( 'checked' ); 
		if ( ( dbname != this.lastDbname ) || ( dbpref != this.lastDbpref ) || ( dbmake != this.lastDbmake ) ) {
			if (! dbpref ) return;
			if ( dbname == '' ) {
				ajaxWrap.removeClass('error').removeClass('success');
				ajaxMsg.html('');
				valid.val(null);
				return;
			}
			if (this.timer) clearTimeout(this.timer);
			ajaxWrap.removeClass('error').removeClass('success').addClass('ajax');
			ajaxMsg.html('Checking your settings');
			
			this.timer = setTimeout(function () {
				$.ajax({
					url: '{$siteurl}',
					data: 'dbname=' + dbname + '&dbpref=' + dbpref + '&dbmake=' + dbmake,
					dataType: 'json',
					type: 'post',
					success: function (j) {
						ajaxWrap.removeClass('ajax');
						ajaxMsg.html(j.message);
						if ( j.success == 'true' ) {
							ajaxWrap.addClass( 'success' );
							valid.val(true);
						} else {
							ajaxWrap.addClass( 'error' );
							valid.val(null);
						}
					}
				});
			}, 200);
			this.lastDbname = dbname;
			this.lastDbpref = dbpref;
			this.lastDbmake = dbmake;
		}
	});
});
JS;
			break;
		endswitch;
		
		return $data;
	}
}