<?php echo form_open( $action ); ?>

<div>
<textarea readonly="true" rows="25" style="color: #666666; font-family: Tahoma; font-size: 10px; width: 700px; ">
Go Higher Information Solutions Commercial End User Licensing Agreement
version 2.0
last updated 2012 February 9

THIS "END USER LICENSE AGREEMENT" (THE "EULA") IS A LEGAL AGREEMENT BETWEEN THE INDIVIDUAL OR LEGAL ENTITY OR ASSOCIATION INTENDING TO USE THE SOFTWARE ("YOU" OR "CUSTOMER") AND GO HIGHER INFORMATION SERVICES. BY REGISTERING FOR THE SOFTWARE OR BY USING THE SOFTWARE, YOU REPRESENT, WARRANT, AND AGREE THAT YOU HAVE READ, UNDERSTOOD, AND AGREE TO BE BOUND TO THE TERMS OF THE EULA. IF YOU DO NOT AGREE TO BE BOUND BY THE EULA, OR YOU DO NOT HAVE AUTHORITY TO BIND CUSTOMER TO THE EULA, YOU MAY NOT USE THE SOFTWARE.
DEFINITIONS

"Active Client Account" means a client account that is active in the context of Go Higher's web site, meaning that the Client Account is fully functional and can be used to authenticate to the Software.

"Client Account" means a client account in the context of Go Higher's web site.

"Data" means the data stored in your database used by the Software.

"Go Higher", "We" and "Us" means Go Higher Information Services, LLC, its employees, representatives and contractors.

"License Key" means the key that is used to activate software for use by the Customer.

"Site" means Go Higher's web site, https://www.gohigheris.com.

"Software" means the software that this EULA accompanies.
1. TERMS OF LICENSE

1.1 License.  Subject to the EULA and provided you have a valid License Key, Go Higher grants You the revocable, non-exclusive, non-transferrable, and non-sublicensable license to the Software through Your Active Client Accounts.

1.2 Third Party Software.  The Software may contain or be accompanied by Third Party Software that requires notices and/or additional terms and conditions.   Such required Third Party Software notices and/or additional terms and conditions may be requested from Go Higher and are made a part of and incorporated by reference into the EULA.  By accepting the EULA, You are also accepting the additional terms and conditions, if any, set forth therein.

1.3 New Releases and Updates.  You are entitled to use new releases of and updates to the Software only (i) if you elect to purchase a Support and Upgrade Pack  subscription and (ii) while your Support and Upgrade Pack subscription remains active and in good standing.  A Support and Upgrade Pack subscription is optional and, subject to the terms of the EULA, You may use the Software without such a subscription and/or continue to use the Software after such subscription has expired.  Any new releases of and updates to the Software you receive and are entitled to use pursuant to this Section 1.3 shall be included in the definition of "Software" hereunder and shall be governed by the terms of this EULA unless such new release or update is accompanied by a separate license, in which case the terms of that license will govern the Software and/or such new release or update.  You may obtain new releases of and/or updates to the Software only from Go Higher or other sources authorized by Go Higher. Any releases and updates applied after the expiration of Your Support and Upgrade Pack subscription are not authorized and will result in the Software ceasing to function.
2. Conditions and Limitations

2.1 Number of Installations. You are permitted only (i) one live, accessible installation of the Software and (ii) one private installation that is available for use only by Customer for internal testing purposes. Each live installation of the Software can be accessed through one Domain Name only.  If access to the installation is required through multiple Domain Names, additional license(s) are required. 

2.2 No Reselling, Time-Sharing, or Sub-Licensing. You shall not license, sublicense, sell, resell, rent, lease, transfer, assign, distribute, time share or otherwise commercially exploit or make the Software available to any third party, other than as expressly permitted by the EULA.

2.3 No Unlawful Use or Objectionable Content. You shall not use the Software in any unlawful manner or in any manner that interferes with or disrupts the integrity or performance of the Software and its components or infringes on the rights of another party. You shall not modify, adapt or hack the Software, or otherwise attempt to gain unauthorized access to the Software or its related systems or networks. You undertake not to promote any material that is unlawful, threatening, abusive, malicious, defamatory, false, materially inaccurate, or otherwise objectionable. You will not reproduce, publish, or distribute content in connection with the Software that infringes any third party's trademark, copyright, patent, trade secret, publicity, privacy, or other personal or proprietary right. Go Higher offers no assurance that Your use of the Software under the terms of the EULA will not violate any law or regulation applicable to You.

2.4 Responsibility for Use. You must only install the Software and make the Software available for use on systems owned, leased, or controlled by You in such a way that You can guarantee compliance with the terms of the EULA. You assume all responsibility for any and all use of the Software, including but not limited to content and media that is created, uploaded to, downloaded from, transmitted and edited using the Service. You are responsible for any accesses made to the Service. 

2.5 Attribution. With respect to any use of the Software, You shall keep the attribution and hyperlink to Go Higher and its website intact unless a branding removal option (at a cost) is obtained from Go Higher to do so.

2.6 Software Backup. You may make one copy the Software for back-up and archival purposes, provided that the original and the copy are kept in Your possession and that Your installation and use of the Software does not exceed that allowed in the EULA.

2.7 Data Backups. You assume all responsibility for all of Your Data and any backups thereof.

2.8 Unsolicited Email. You may not use the Software to send unsolicited email ("spam") to anyone, including mailing lists which You have purchased.

2.9 Securing Your Authentication Details. You will ensure that all passwords and login credentials remain secure at all times for You and each of Your Client Accounts. If in the case that You suspect a security violation You also undertake to notify Go Higher immediately.

2.10 Handling Software. You shall not (a) reverse engineer, decompile, disassemble, or decrypt any portion of compiled and/or source code, in whole or in part, or otherwise attempt to discover the source code to the software used in the Software, (b) use any Third Party Software independently of the Software, (c) copy, modify, or combine any part of the software included in the Software for use in software or applications outside of the Software or (d) make any attempt to circumvent parts of the Software designed to enforce the maximum number of Client Accounts for which You have paid. You obtain no rights to the Software except for the limited rights to use the Software expressly granted by the EULA.

2.12 Limited License. You acknowledge and agree that (i) the Software is the property of Go Higher and is licensed and not sold to You under the EULA and (ii) the Software uses, embodies, and contains confidential and proprietary information and technology of Go Higher and/or its licensors and embodies trade secrets and intellectual property of Go Higher and/or its licensors protected under United States copyright and other laws, and by international treaty provisions (collectively referred to as "Go Highers's Intellectual Property Rights").  Your rights in the Software are strictly limited to those license rights expressly granted under Section 1.1 above, and Go Higher retains all rights not expressly granted herein.  Without limiting the foregoing, Go Higher and/or its licensors retain all right, title, and interest in and to Go Highers Intellectual Property Rights, including but not limited to: (i) all software code (source and object), functionality, technology, system or network architecture and user interfaces and all modifications thereto and (ii) all trade secrets, patents, copyrights and other intellectual property rights with respect to the Software. You further acknowledge that there are no implied licenses granted under the EULA.

2.13 Obtaining the Software. You shall not obtain copies of the Software though any means other than directly through the Site using your Go Higher Client Account credentials. Go Higher does not guarantee that the Software will be available for download from the Site for a period longer than 90 days following Your purchase.

2.14 Disrepute. You shall not commit any act likely to result in the disrepute or harming of interests of Go Higher's name or the name of its third party suppliers, whether through explicit act or omission.
3. Liabilities, Warranties and Indemnification

3.1 Disclaimer of Warranties. No Warranties. THE SOFTWARE AND THE SITE ARE PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT ANY WARRANTY OF ANY KIND, EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT. GO HIGHER MAKES NO WARRANTY THAT (i) THE SOFTWARE WILL MEET YOUR REQUIREMENTS, (ii) THE SOFTWARE WILL BE UNINTERRUPTED, TIMELY, SECURE, ERROR-FREE, OR VIRUS-FREE, (iii) THE RESULTS THAT MAY BE OBTAINED FROM THE USE OF THE SOFTWARE WILL BE ACCURATE OR RELIABLE, (iv) THE QUALITY OF ANY PRODUCTS, SERVICES, INFORMATION, OR OTHER MATERIAL PURCHASED OR OBTAINED BY YOU THROUGH THE SERVICE WILL MEET YOUR EXPECTATIONS, AND (v) ANY ERRORS IN THE SERVICE WILL BE CORRECTED. NO ADVICE OR INFORMATION, WHETHER ORAL OR WRITTEN, OBTAINED BY YOU FROM GO HIGHER OR THROUGH OR FROM THE SOFTWARE SHALL CREATE ANY WARRANTY NOT EXPRESSLY STATED HEREIN.

3.2 Carrier Lines. YOU ACKNOWLEDGE THAT ACCESS TO THE SOFTWARE WILL BE PROVIDED OVER VARIOUS FACILITIES AND COMMUNICATIONS LINES, AND INFORMATION WILL BE TRANSMITTED OVER LOCAL EXCHANGE AND INTERNET BACKBONE CARRIER LINES AND THROUGH ROUTERS, SWITCHES, AND OTHER DEVICES (COLLECTIVELY, "CARRIER LINES") OWNED, MAINTAINED, AND SERVICED BY THIRD-PARTY CARRIERS, UTILITIES, INTERNET SERVICE PROVIDERS, ALL OF WHICH ARE BEYOND GO HIGHER'S CONTROL. GO HIGHER ASSUMES NO LIABILITY FOR OR RELATING TO THE INTEGRITY, PRIVACY, SECURITY, CONFIDENTIALITY, OR USE OF ANY INFORMATION WHILE IT IS TRANSMITTED ON THE CARRIER LINES, OR ANY DELAY, FAILURE, INTERRUPTION, INTERCEPTION, LOSS, TRANSMISSION, OR CORRUPTION OF ANY DATA OR OTHER INFORMATION ATTRIBUTABLE TO TRANSMISSION ON THE CARRIER LINES. USE OF THE CARRIER LINES IS SOLELY AT YOUR RISK AND IS SUBJECT TO ALL APPLICABLE LOCAL, STATE, NATIONAL, AND INTERNATIONAL LAWS.

3.3 Unauthorized Access; Lost or Corrupt Data. GO HIGHER IS NOT RESPONSIBLE FOR UNAUTHORIZED ACCESS TO ANY DATA, FACILITIES, OR EQUIPMENT BY ANYONE USING THE SOFTWARE OR FOR UNAUTHORIZED ACCESS TO OR ALTERATION, THEFT, CORRUPTION, LOSS, OR DESTRUCTION OF ANY DATA FILES, PROGRAMS, PROCEDURES, OR INFORMATION THROUGH THE SOFTWARE, WHETHER BY ACCIDENT, FRAUDULENT MEANS OR DEVICES, OR ANY OTHER MEANS. YOU ARE SOLELY RESPONSIBLE FOR VALIDATING THE ACCURACY OF ALL OUTPUT AND REPORTS. YOU HEREBY WAIVE ANY DAMAGES OCCASIONED BY LOST OR CORRUPT DATA, INCORRECT REPORTS, OR INCORRECT DATA FILES RESULTING FROM PROGRAMMING ERROR, OPERATOR ERROR, EQUIPMENT OR SOFTWARE MALFUNCTION, SECURITY VIOLATIONS, OR THE USE OF THIRD-PARTY SOFTWARE. GO HIGHER IS NOT RESPONSIBLE FOR THE CONTENT OF ANY INFORMATION TRANSMITTED OR RECEIVED THROUGH GO HIGHER'S PROVISION OF THE SOFTWARE. ANY MATERIAL DOWNLOADED OR OTHERWISE OBTAINED THROUGH THE USE OF THE SOFTWARE IS DONE AT YOUR OWN DISCRETION AND RISK AND THAT YOU WILL BE SOLELY RESPONSIBLE FOR ANY DAMAGE TO YOUR COMPUTER SERVICE OR LOSS OF DATA THAT RESULTS FROM THE DOWNLOAD OF ANY SUCH MATERIAL. Go Higher shall not be held responsible for data hosted on its servers AND YOU ARE SOLELY responsibility FOR maintaining local copies of YOUR data and maintaining proper and sufficient insurance if coverage is required with respect to data loss.

3.4 Third-Party Sites and Service Providers. The Software may contain hyperlinks (including hyperlinked advertisements) to Internet web sites operated by third parties, or to materials or information made available by third parties. Such third parties may offer goods or services for sale to you. Such links do not constitute or imply Go Higher's endorsement of such third parties, or of the content of their sites, the quality or efficacy of their goods or services, or their information privacy or security practices, and Go Higher has no responsibility for information, goods, or services offered or provided by such third parties, or for the manner in which they conduct their operations. Your use of third-party sites and the materials, goods, and services offered by them is entirely at your own risk, and is subject to the terms of use of the third parties operating or providing them. You should assume that any Internet page or other material that does not bear the Go Higher logo is provided by a third party.

3.5 Warranties Required By Applicable Law. IF APPLICABLE LAW REQUIRES ANY WARRANTIES WITH RESPECT TO THE SOFTWARE, ALL SUCH WARRANTIES ARE LIMITED IN DURATION TO NINETY (90) DAYS FROM THE DATE YOU REGISTERED FOR THE SOFTWARE.

3.6 Limitation of Liability. IN NO EVENT SHALL GO HIGHER BE LIABLE TO YOU OR ANY THIRD PARTY FOR ANY INDIRECT, SPECIAL, INCIDENTAL, EXEMPLARY, PUNITIVE, COVER, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, DAMAGES FOR THE INABILITY TO USE EQUIPMENT OR ACCESS DATA, LOSS OF BUSINESS, LOSS OF PROFITS, BUSINESS INTERRUPTION OR THE LIKE), ARISING OUT OF THE USE OF, OR INABILITY TO USE, THE SOFTWARE AND BASED ON ANY THEORY OF LIABILITY INCLUDING WITHOUT LIMITATION BREACH OF CONTRACT, BREACH OF WARRANTY, TORT (INCLUDING WITHOUT LIMITATION NEGLIGENCE), PRODUCT LIABILITY OR OTHERWISE, EVEN IF GO HIGHER OR ITS REPRESENTATIVES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES AND EVEN IF A REMEDY SET FORTH HEREIN IS FOUND TO HAVE FAILED OF ITS ESSENTIAL PURPOSE. GO HIGHER'S TOTAL LIABILITY TO YOU FOR ACTUAL DAMAGES FOR ANY CAUSE WHATSOEVER WILL BE LIMITED TO THE AMOUNT PAID BY YOU FOR THE SOFTWARE.   The provisions of this section allocate the risks under the EULA between the parties, and the parties have relied on these limitations in determining whether to enter into the EULA AND HOW TO PRICE THE SOFTWARE. SOME JURISDICTIONS MAY NOT ALLOW THE LIMITATION OR EXCLUSION OF LIABILITY FOR INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY NOT APPLY TO YOU AND YOU MAY ALSO HAVE OTHER LEGAL RIGHTS THAT VARY FROM JURISDICTION TO JURISDICTION. THE FOREGOING LIMITATIONS ON LIABILITY ARE INTENDED TO APPLY TO THE WARRANTIES AND DISCLAIMERS ABOVE AND ALL OTHER ASPECTS OF THE SOFTWARE AND THE EULA.

3.7 Indemnification. You agree to indemnify, defend, and hold harmless Go Higher and other users of Go Higher products and services, and Go Higher's affiliates, officers, directors, and agents, from and against any claim, cost or liability, including reasonable attorneys' fees, arising out of or relating to: (a) Your use of the Software; (b) any content You create, transmit, or display while using the Software; (c) any breach by You of any representations, warranties, or agreements contained in the EULA; (d) any unlicensed use of the Software using Your Client Accounts; and (e) Your negligent or willful misconduct.

3.8 Notification of Claim. In no event will a claim by brought by You unless the licensee has notified Go Higher of the claim within one year of it arising.

3.9 Infringement. If the Software becomes the subject of an infringement on another party's copyright or intellectual property where the infringement has not arisen out of Your or a third party's modification to the Software or use of the Software in combination with other products, Go Higher may remedy the infringement by (a) purchasing license to the infringing part of the Software or (b) replacing the infringing part of the Software or (c) refund any fees paid by the licensee for the Software.
4. Trademarks and publicity

4.1 Use of Names and Trademarks. While You remain licensed to use the Software, You may use Go Higher's name or logos in order to identify Yourself as a customer. You shall not otherwise use Go Higher's name or trademarks, unless written permission is obtained from Go Higher or otherwise set out in the EULA.

4.2 Disrepute. You shall not commit any act where the result of which is the likely disrepute or harming of interests of Go Higher's name or the name of its third party vendors, whether through explicit act or omission.

4.3 Promotional Materials and Publicity. You authorize Go Higher to use Your name and trademarks in Go Higher's promotional materials and for publicity purposes. You can opt-out at any time by writing to: sales [at] gohigheris [dot] com.
5. Confidentiality

5.1 Access to and Disclosure of Your Data. You grant Go Higher the right to access any or all of Your accounts in order to (a) respond to Your requests for technical support and (b) collect anonymized usage data ("Anonymized Usage Data"). Go Higher shall maintain reasonable administrative, physical and technical safeguards for protection of the security, confidentiality and integrity of Your data. Go Higher will not disclose Your data to a third party unless compelled by law or court order or if You consent in writing to the disclosure.

5.2 Anonymized Usage Data.  In consideration of Go Higher's provision of a license to access and use the Software, You hereby transfer and assign to Go Higher all right, title, and interest in and to all Anonymized Usage Data that Go Higher makes from Your data pursuant to Section 5.1. You agree that Go Higher may use, disclose, market, license, and sell such Anonymized Usage Data for any purpose without restriction, and that you have no interest in such information, or in the proceeds of any sale, license, or other commercialization thereof.

5.3. Privacy Policy. The privacy policy is available at http://www.gohigheris.com/policies/privacy-policy. By agreeing to the EULA, You accept the terms of Go Higher's privacy policy.
6. Payments, Sales, and Refunds

6.1 Payment of Fees. You must pay all fees by the due dates.

6.2 Upgrading, or Downgrading. The Software may have configurable options that permit upgrading or downgrading of your product by purchasing an upgrade or requesting a downgrade.  Upon upgrading or downgrading the Software, you must, at Go Higher's sole discretion, enter into a new license agreement for the Software on the then-current terms.

6.3 Price Changes. Go Higher reserves the right to change prices at any time.

6.4 Credit Card Billing. If You choose to pay by credit or debit card You authorize Go Higher to debit Your account renewal fees, if any, from Your card. Go Higher uses a third-party intermediary to manage credit card processing and this intermediary is not permitted to store, retain, or use Your billing information except to process Your credit card information for Go Higher.  Go Higher may use Your information in order to perform fraud screening.

6.5 Refunds. Go Higher offers a 30-day money back guarantee to You provided (i) the refund is requested through our Site by means of our support ticket system; (ii) the refund is being requested as a result of technical incompatibilites that do not permit the Software to function or operate as intended. Any refundes will be made solely at Go Higher's discretion.
7. Term and Termination

7.1 Termination. This EULA is effective until terminated. This EULA and your license and other rights under this EULA will terminate automatically without notice from Go Higher if You fail to comply with any term(s) of this EULA.  

7.2 No Refund. Go Higher will not refund any amounts to You if this EULA and your rights to use the Software are terminated due to Your failure to comply with any term(s) of this EULA.

7.3 Effect of Termination.  Upon the termination of this EULA, you must cease all use of the Software and destroy all copies, full or partial, of the Software.

7.4 Recovery of fees and costs. Should You continue to use the Software after termination of this EULA, You will be liable to pay all costs, including reasonable attorneys fees, of Go Higher to enforce this EULA, as well as any damages suffered by Go Higher.

7.5 Survival. Articles 3, 4, 5, 6, 7, and 8 of the EULA will survive termination of the EULA.
8. Interpretation

8.1 Assignment. You may not assign Your account with Go Higher or Your rights under the EULA without Go Higher's prior written consent, except in the case of a sale of all or substantially all of Your assets.  Go Higher may assign, in whole or in part, its rights, interests, and obligations hereunder without limitation.

8.2 Headings. Descriptive headings are for convenience only and shall not control or affect the meaning or construction of any provision of this Agreement.

8.3 Enforcement. The failure of Go Higher to exercise or enforce any right or provision of the EULA shall not be a waiver of that right. No provision in the EULA shall be deemed waived and no breach excused, unless such waiver or consent shall be in writing and signed by the party claimed to have waived or consented. Any consent by any party to, or waiver of a breach by the other, whether expressed or implied, shall not constitute a consent to, waiver of, or excuse for any other different or subsequent breach.

8.4 Export Controls. You agree to comply with all applicable export and reexport control laws and regulations, including without limitation the Export Administration Regulations maintained by the U.S. Department of Commerce and trade and economic sanctions maintained by the Treasury Department's Office of Foreign Assets Control. If You are in a country outside of the United States, You agree to additionally comply with any local rules regarding online conduct and acceptable content, including without limitation laws regulating the export and reexport of data to and from the United States or such other country.

8.5 Choice of Law. The interpretation of the EULA and the resolution of any disputes arising under or in connection with the EULA shall be governed by the laws of the State of Florida, USA. The United Nations Convention on Contracts for the Sale of Goods does not apply.

8.6 Dispute Resolution. In the event of a claim or dispute between You and Go Higher arising under or in connection with the EULA or the Software, the parties shall first attempt to settle the claim or dispute by direct discussions.  If discussions are not successful, the parties shall arbitrate pursuant to the Commercial Arbitration Rules administered by the American Arbitration Association, with a final judgment to be entered upon the arbitration award.  The venue for discussions and arbitration shall be Orlando, Florida.

8.7 Severability. Any provision of the EULA that shall prove to be invalid, void, or illegal, shall in no way affect, impair, or invalidate any other provision of the EULA, and such other provisions shall remain in full force and effect.

8.8 Notices. You agree that Go Higher may provide You with notices, including without limitation those regarding changes to the EULA, by e-mail, regular mail, or messages or postings through the Software.

8.9 Complete Understanding. The EULA constitutes the entire agreement between You and Go Higher and govern Your use of the Software, superseding any prior agreements between You and Go Higher for the use of the Software. You also may be subject to additional terms and conditions that may apply when You use or purchase certain other Go Higher services, affiliate services, third-party content, or third-party software.

8.10. No Third-Party Beneficiaries. Nothing express or implied in the EULA is intended to confer, nor shall confer, upon any person or entity other than the parties and their respective successors or assigns any rights, remedies, obligations, or liabilities whatsoever.</textarea>

<div class="clear"> </div>
</div>

<?php foreach( $hidden as $hide ) : ?>
<?php echo $hide->field; ?>
<?php endforeach; ?>

<div class="push-4 append-bottom clear" style="text-align: center;">
<?php echo form_button( array( 'name' => 'submit', 'id' => 'submit', 'value' => true, 'type' => 'submit', 'content' => lang( 'button.agree' ) ) );?>
<?php echo form_button( array( 'name' => 'submit', 'id' => 'submit', 'value' => true, 'type' => 'reset', 'content' => lang( 'button.disagree' ) ) );?>
</div>

<?php echo form_close(); ?>