<?php echo form_open( $action ); ?>

<?php foreach ( $fields as $item ) : ?>
<div class="append-bottom border-bottom">
	<div>
		<div><?php echo $item->label; ?></div>
		<div><i><?php echo $item->desc; ?></i></div>
		<div><?php echo $item->field; ?></div>
	</div>
	<p>
	
	</p>
	<!-- <div class="clear"> </div> -->
</div>
<?php endforeach; ?>

<?php foreach( $hidden as $hide ) : ?>
<?php echo $hide->field; ?>
<?php endforeach; ?>

<!-- <div class="push-1 span-23 prepend-top last append-bottom"> -->
<div id="ajax-wrap"><div id="ajax-msg" class="content"></div></div>
<!-- </div> -->

<div class="push-4 append-bottom clear">
	<?php echo form_button( array( 'name' => 'submit', 'id' => 'submit', 'value' => true, 'type' => 'submit', 'content' => lang( $submit ) ) );?>
</div>

<?php echo form_close(); ?>