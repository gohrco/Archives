<?php

$lang['upgrade']				= 'Upgrade';
$lang['upgrade.index']			= 'Checking your installation...';
$lang['upgrade.step1']			= 'Step 1:  Verify Database Backup';
$lang['upgrade.step2']			= 'Step 2:  Terms of Service';
$lang['upgrade.step3']			= 'Step 3:  Upgrading';

$lang['menu.step1']				= 'Verify Backup';
$lang['menu.step2']				= 'Terms of Service';
$lang['menu.step3']				= 'Upgrade';
$lang['menu.step4']				= 'Complete';

$lang['desc.upgrade.step1']		= 'Please verify that you have taken a complete backup of your database and your server prior to proceeding with the upgrade.';
$lang['desc.upgrade.step2']		= 'Please review our Terms of Service in using Integrator 3. When are done, click "I Agree" to proceed, if you do not wish to be bound by these terms, please click "I Disagree" to cancel the upgrade.';
$lang['desc.upgrade.step3']		= 'Upgrade in progress';

$lang['button.agree']			= 'I Agree';
$lang['button.disagree']		= 'I Disagree';
$lang['button.tryagain']		= 'Try Again';
$lang['button.step1']			= 'CONFIRM BACKUP PERFORMED';

$lang['verify']					= "Database Backup Performed";
$lang['verify.desc']			= "Before upgrading your application, it is highly recommended that you perform a backup of your database.";
