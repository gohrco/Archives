<div class="mod-intlogin">
	
	<form action="<?php echo $form->action; ?>" method="post" id="login-form" >
		
		<div class="pretext">
			<?php echo $params->get( 'pretext', null ); ?>
		</div>
		
		<fieldset class="userdata">
		
			<p id="form-login-username">
				<label for="modlgn-username"><?php echo JText::_( 'MOD_INTLOGIN_LBL_USERNAME' ) ?></label>
				<input id="modlgn-username" type="text" name="username" class="inputbox"  size="18" />
			</p>
			
			<p id="form-login-password">
				<label for="modlgn-passwd"><?php echo JText::_( 'MOD_INTLOGIN_LBL_PASSWORD' ) ?></label>
				<input id="modlgn-passwd" type="password" name="password" class="inputbox" size="18"  />
			</p>
			
			<?php if ( JPluginHelper::isEnabled( 'system', 'remember' ) ) : ?>
			
			<p id="form-login-remember">
				<label for="modlgn-remember"><?php echo JText::_('MOD_INTLOGIN_LBL_REMEMBER') ?></label>
				<input id="modlgn-remember" type="checkbox" name="remember" class="inputbox" value="yes"/>
			</p>
			
			<?php endif; ?>
			
			<input type="submit" name="Submit" class="button" value="<?php echo JText::_( 'MOD_INTLOGIN_BTN_SUBMIT' ) ?>" />
			<input type="hidden" name="return" value="<?php echo $form->return; ?>" />
			<input type="hidden" name="_c" value="<?php echo $form->origin; ?>" />
		</fieldset>
		
		<ul>
			<li>
				<a href="<?php echo JRoute::_( $links->reset ); ?>">
				<?php echo JText::_('MOD_INTLOGIN_FORGOT_YOUR_PASSWORD'); ?></a>
			</li>
			
			<li>
				<a href="<?php echo JRoute::_( $links->username ); ?>">
				<?php echo JText::_('MOD_INTLOGIN_FORGOT_YOUR_USERNAME'); ?></a>
			</li>
			
			<?php
			if ( $links->allowed ) : ?>
			
			<li>
				<a href="<?php echo JRoute::_( $links->register ); ?>">
					<?php echo JText::_('MOD_INTLOGIN_REGISTER'); ?></a>
			</li>
			
			<?php endif; ?>
			
		</ul>
		
		<div class="posttext">
			<?php echo $params->get( 'posttext' ); ?>
		</div>
		
	</form>
	
</div>