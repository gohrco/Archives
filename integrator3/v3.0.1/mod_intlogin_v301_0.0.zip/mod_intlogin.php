<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.1.0.0 ( $Id: mod_intlogin.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the main file for the Integrator Login module
 *  
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.helper' );
jimport( 'joomla.application.component.helper' );

// Include the syndicate functions only once
if ( $path = JApplicationHelper :: getPath( 'class', 'com_integrator' ) ) {
	require_once( $path );
}

if (! class_exists( 'intLogin' ) ) {
	
class intLogin
{
	private	$_active		= true;
	private	$_loggedin		= false;
	private $_ssl			= false;
	
	private	$api			= null;
	private $form			= array();
	private $gravatar		= array();
	private	$info			= array();
	private	$moduleparams	= null;
	private	$params			= null;
	private	$userobj		= null;
	
	public function __construct( $options )
	{
		// Set local values
		$this->api			= IntApi :: getInstance();
		$this->moduleparams	= ( isset( $options['params'] ) ? $options['params'] : null );
		$this->params		= JComponentHelper :: getParams( 'com_integrator' );
		$this->userobj		= JFactory :: getUser();
		$this->_loggedin	= ( $this->userobj->get( 'guest', true ) ? false : true );
		
		if (! $this->build() ) {
			$this->_active = false;
		}
		
		// Clean object
		$this->api = null;
	}
	
	
	public function getInstance( $options = array() )
	{
		static $instance = array();
		
		$reset	= ( isset( $options['force'] ) ? $options['force'] : false );
		
		$serial	= serialize( $options );
		
		if ( empty( $instance[$serial] ) || $reset ) {
			$instance[$serial] = new self( $options );
		}
		
		return $instance[$serial];
	}
	
	
	public function isLoggedin()
	{
		return (bool) $this->_loggedin;
	}
	
	
	public function isSsl( $setting = null )
	{
		if ( $setting != null ) {
			$this->_ssl = $setting;
			return $this->_ssl;
		}
		else return $this->_ssl;
	}
	
	
	public function render()
	{
		$content	= null;
		$params		= $this->moduleparams;
		$form		= (object) $this->form;
		$gravatar	= (object) $this->gravatar;
		$links		= $this->getLinks();
		
		if ( $this->isLoggedin() ) {
			$rows	= $this->getRows();
			$info	= (object) $this->info;
			$path	= JModuleHelper :: getLayoutPath( 'mod_intlogin', 'info' );
			
			JHtml :: stylesheet( 'info.css', $this->getCsspath() );
		}
		else {
			$info = null;
			$path = JModuleHelper :: getLayoutPath( 'mod_intlogin', 'form' );
			
			JHtml :: stylesheet( 'form.css', $this->getCsspath() );
		}
		
		ob_start();
			require $path;
			$content = ob_get_contents();
		ob_end_clean();
		
		return $content;
	}
	
	
	private function build()
	{
		/** 
		 * Reset URI first (J!1.6+)
		 */
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			JUri :: reset();
		}
		
		/**
		 * Now lets start by building the action
		 */
		if (! ( $inturl = $this->params->get( 'IntegratorUrl', false ) ) ) {
			return false;
		}
		
		if ( ( $ssl = $this->moduleparams->get( 'forcessl', false ) ) === false ) {
			return false;
		}
		else {
			$suri	= JUri :: getInstance();
			$this->isSsl( $suri->isSSL() );
			$ssl	= (bool) ( $ssl == '2' ? $this->isSsl() : $ssl );
		}
		
		$uri = new JUri( $inturl );
		$uri->setPath( rtrim( $uri->getPath(), '/' ) . '/index.php/login/index' );
		$uri->setScheme( 'http' . ( $ssl ? 's' : '' ) );
		
		$this->form['action']	= $uri->toString();
		
		/**
		 * Action complete
		 * * * * * * * *
		 * Now build the return URL
		 */
		
		if ( ( $redirect = $this->moduleparams->get( 'redirectoverride', false ) ) === false ) {
			return false;
		}
		
		// No override
		if ( $redirect == '0' ) {
			$returnuri = JUri :: getInstance();
			
			// Clear the override in case we are coming from the Integrator
			if ( $returnuri->getVar( 'override', false ) ) {
				$returnuri->delVar( 'override' );
			}
		}
		// Use an Integrated URL
		else if ( $redirect == '1' ) {
			$route		=   $this->api->get_route( array( 'cnxn_id' => $this->moduleparams->get( '_a' ), 'page' => $this->moduleparams->get( 'page' ) ) );
			$returnuri	=   new JUri( $route );
		}
		// Use a custom URL (see if its set)
		else if ( ( $returl = $this->moduleparams->get( 'redirecturl', false ) ) === false ) {
			return false;
		}
		// Use the custom URL
		else {
			$returnuri = new JUri( $returl );
		}
		
		$this->form['return'] = base64_encode( $returnuri->toString() );
		
		/**
		 * Return URL complete
		 * * * * * * * *
		 * Now set the origin
		 */
		
		if (! ( $cnxnid = $this->params->get( 'cnxnid', false ) ) ) {
			return false;
		}
		
		$this->form['origin'] = $cnxnid;
		
		/**
		 * Origin is set
		 * * * * * * * *
		 * Now retrieve the user info
		 */
		
		if ( $this->isLoggedin() && $this->moduleparams->get( 'retrieve_info', false ) ) {
			$email		= $this->userobj->get( 'email' );
			$this->info	= $this->api->get_user_info( array( 'email' => $email ) );
		}
		else if ( $this->isLoggedin() ) {
			$user = $this->userobj->getProperties();
			$this->info = array( 'fullname' => $user['name'], 'username' => $user['username'], 'email' => $user['email'] );
		}
		
		/**
		 * User info is set
		 * * * * * * * *
		 * Now set logout URL
		 */
		
		$uri = new JUri( $inturl );
		$uri->setPath( rtrim( $uri->getPath(), '/' ) . '/index.php/logout/index' );
		$uri->setScheme( 'http' . ( $ssl ? 's' : '' ) );
		
		$this->form['logout']	= $uri->toString();
		
		/**
		 * Logout URL is set
		 * * * * * * * *
		 * Build the Gravatar
		 */
		
		if ( $this->isLoggedin() ) {
			$this->gravatar	= $this->getGravatar( $this->info['email'], $this->moduleparams->get( 'grav_size', '80' ), $this->moduleparams->get( 'grav_default', 'mm' ), 'g', true );
		}
		
		return true;
	}
	
	
	private function getCsspath()
	{
		$app	= & JFactory::getApplication();
		
		// Build the template and base path for the layout
		$tPath	= JPATH_BASE.DS.'templates'.DS.$app->getTemplate().DS.'html'.DS.'mod_intlogin'.DS;
		$tUrl	= 'templates/' . $app->getTemplate() . '/html/mod_intlogin/';
		$bUrl	= 'modules/mod_intlogin/tmpl/css/';
		
		// If the template has a layout override use it
		if (file_exists($tPath)) {
			return $tUrl;
		} else {
			return $bUrl;
		}
	}
	
	
	/**
	 * Get either a Gravatar URL or complete image tag for a specified email address.
	 *
	 * @param string $email The email address
	 * @param string $s Size in pixels, defaults to 80px [ 1 - 512 ]
	 * @param string $d Default imageset to use [ 404 | mm | identicon | monsterid | wavatar ]
	 * @param string $r Maximum rating (inclusive) [ g | pg | r | x ]
	 * @param boole $img True to return a complete IMG tag False for just the URL
	 * @param array $atts Optional, additional key/value attributes to include in the IMG tag
	 * @return String containing either just a URL or a complete image tag
	 * @source http://gravatar.com/site/implement/images/php/
	 */
	private function getGravatar( $email, $s = 80, $d = 'mm', $r = 'g', $img = false, $atts = array() )
	{
		$user	= & $this->userobj;
		
		if (! is_null( $enable = IntegratorHelper :: get( 'dg' ) ) ) {
			$user->setParam( 'display_gravatar', $enable );
			$user->save();
		}
		
		if ( $user->defParam( 'display_gravatar', '2' ) == '2' ) {
			defined( 'INTEGRATOR_API' ) or define( 'INTEGRATOR_API', true );
			$user->setParam( 'display_gravatar', false );
			$user->save();
		}
		
		$uri	= JUri::getInstance();
		if ( JRequest :: getVar( 'option' ) == 'com_integrator' && JRequest :: getVar( 'override' ) == '1' ) {
			$uri->setVar( 'override', '0' );
		}
		$uri->setVar( 'dg', ( $user->getParam( 'display_gravatar', false ) ? '0' : '1' ) );
		$option	= $uri->toString();
		
		if ( $user->getParam( 'display_gravatar', true ) == false ) {
			$email = 'donotdisplay@localhost.com';
		}
		
		$mode	 = $this->isSsl();
		$url	 = 'http' . ( $mode == true ? 's://secure' : '://www' ) . '.gravatar.com/avatar/';
		$url	.= md5( strtolower( trim( $email ) ) );
		$url	.= "?s=$s&d=$d&r=$r";
		
		if ( $img ) {
			$url = '<img src="' . $url . '"';
			foreach ( $atts as $key => $val )
				$url .= ' ' . $key . '="' . $val . '"';
			$url .= ' />';
		}
		
		return array( 'url' => $url, 'option' => $option, 'enabled' => $user->getParam( 'display_gravatar', false ) );
	}
	
	
	private function getLinks()
	{
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$usersConfig = JComponentHelper::getParams('com_users');
			$links	= array(	'reset'		=> 'index.php?option=com_users&view=reset',
								'username'	=> 'index.php?option=com_users&view=remind',
								'register'	=> 'index.php?option=com_users&view=registration',
								'allowed'	=> $usersConfig->get( 'allowUserRegistration' )
			);
		}
		else {
			$userConfig = JComponentHelper::getParams('com_users');
			$links	= array(	'reset'		=> 'index.php?option=com_user&view=reset',
								'username'	=> 'index.php?option=com_user&view=remind',
								'register'	=> 'index.php?option=com_user&task=register',
								'allowed'	=> $userConfig->get( 'allowUserRegistration' )
			);
		}
		
		return (object) $links;
	}
	
	
	private function getRows()
	{
		$info	= $this->info;
		$data	= array();
		
		// Be sure we use the local userobj
		$info['username'] = empty( $info['username'] ) ? $this->userobj->get( 'username' ) : $info['username'];
		
		if ( $this->moduleparams->get( 'name', 1 ) == '0' ) {
			$data['name']	= array( 'username' );
		}
		else {
			$data['name']	= (! empty( $info['fullname'] ) ) ? array( 'fullname' ) : array( 'firstname', 'lastname' );
		}
		
		if (! empty( $info['companyname'] ) ) $data['company'] = array( 'companyname' );
		
		if ( $this->moduleparams->get( 'name', 1 ) == '0' ) {
			$data['user'] = array( 'email' );
		}
		else {
			$data['user'] = array( 'email' );
			$data['usr1'] = array( 'username' );
		}
		
		$data['add1']	= array( 'address1' );
		$data['add2']	= array( 'address2' );
		$data['add3'] = array( 'city', 'state', 'postal' );
		$data['add4'] = array( 'country' );
		
		$this->info = $info;
		return $data;
	}
}

}

$intlogin	= intLogin :: getInstance( array( 'params' => $params ) );

echo $intlogin->render();