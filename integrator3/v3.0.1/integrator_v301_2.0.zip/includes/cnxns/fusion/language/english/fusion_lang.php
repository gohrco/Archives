<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.2.0 ( $Id: fusion_lang.php 53 2012-07-20 15:23:08Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the user manager controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * USER FORM FIELDS
 * - Overrides of general language files
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['label.fullname']			= "Full Name";
		$lang['label.active']			= "Active";
		
		$lang['desc.fullname']			= "Enter a complete name for this account.";
		$lang['desc.active']			= "Indicate if this account should be active (able to log in) or not.";
		
		
/**
 * **********************************************************************
 * EDIT CNXNS - GLOBAL TAB
 * - Overrides of general language files
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		
		
/**
 * **********************************************************************
 * EDIT CNXNS - API TAB
 * - Overrides of general language files
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['fusion_label.api.apisecret']	= "API Secret Value";
		$lang['fusion_label.api.apikey']		= "API Key";
		
		$lang['fusion_desc.api.apiurl']	= "Enter the URL to reach your Kayako site.  DO NOT enter the `/api/index.php?` found at the end of your `API URL` value which is found by visiting your Kayako Admin control panel > Dashboard > REST API > API Information.  The `/api/index.php?` is appended automatically for you.";
		$lang['fusion_desc.api.apisecret']		= "Enter the value for the `Secret Key` that is in the backend of your Kayako application.  This value can be found by visiting your Kayako Admin control panel > Dashboard > REST API > API Information and is labeled `Secret Key`.";
		$lang['fusion_desc.api.apikey']		= "Enter the value for the `API Key` that is in the backend of your Kayako application.  This value can be found by visiting your Kayako Admin control panel > Dashboard > REST API > API Information and is labeled `API Key`.";
		
		
/**
 * **********************************************************************
 * EDIT CNXNS - USER TAB
 * - Overrides of general language files
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		
		
/**
 * **********************************************************************
 * EDIT CNXNS - VISUAL TAB
 * - Overrides of general language files
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		
		
/**
 * **********************************************************************
 * EDIT CNXNS - CLIENTAREA TAB
 * - Overrides of general language files
 * **********************************************************************
 */
		//     v3.0.2
		// ---------------
		$lang['clientarea.tab']		= "Clientarea";
		
		$lang['fusion_clientarea.ticketsdisplay']	= 'Display Tickets';
		$lang['fusion_clientarea.ticketsnewwin']	= 'Tickets in New Window';
		
		$lang['fusion_desc.clientarea.ticketsdisplay']	= 'Do you want the ticket summary to be included on the Client Area page for your logged in clients?';
		$lang['fusion_desc.clientarea.ticketsnewwin']	= 'Do you want the tickets to be opened in a new window or tab?';
		
		
		
$lang['fusion_api.tickets.header']			= 'Support Tickets';
$lang['fusion_api.tickets.headerlink']		= 'View All Tickets';
$lang['fusion_api.tickets.headerlink']		= 'View All Tickets';
$lang['fusion_api.tickets.column.ticketid']	= 'Ticket ID';
$lang['fusion_api.tickets.column.lastupd']	= 'Last Update';
$lang['fusion_api.tickets.column.subject']	= 'Subject';
$lang['fusion_api.tickets.column.lastrply']	= 'Last Replier';
$lang['fusion_api.tickets.column.dept']		= 'Department';
$lang['fusion_api.tickets.column.type']		= 'Type';
$lang['fusion_api.tickets.column.status']	= 'Status';
$lang['fusion_api.tickets.column.priority']	= 'Priority';
$lang['fusion_api.tickets.column.viewtkt']	= 'View Ticket';
