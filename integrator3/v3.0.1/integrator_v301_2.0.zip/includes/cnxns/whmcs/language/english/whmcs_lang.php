<?php
/*
|--------------------------------------------------------------------------
| Language Translations for the Connections Edit page
|--------------------------------------------------------------------------
| version 3.0.0
|--------------------------------------------------------------------------
*/
$lang['whmcs_globals.accesskey']				= "Access Key";

$lang['whmcs_users.ignorepwstrengthapi']		= 'Ignore API Password Strength';
$lang['whmcs_users.ignorepwstrengthapi.desc']	= 'Enabling this setting allows WHMCS to test your updated or new password against the set password strength in WHMCS to maintain a level of strength across your applications.  This only affects password checks performed through the API from another connection.';

$lang['whmcs_users.defaultaddress']				= "Default Address";
$lang['whmcs_users.defaultaddress.desc']		= "When creating a new user in WHMCS, you must supply this field.  If the connection creating the user doesn't supply the field, the Integrator will use this setting as a default.";

$lang['whmcs_users.defaultcity']				= "Default City";
$lang['whmcs_users.defaultcity.desc']			= $lang['whmcs_users.defaultaddress.desc'];

$lang['whmcs_users.defaultcountry']				= "Default Country";
$lang['whmcs_users.defaultcountry.desc']		= $lang['whmcs_users.defaultaddress.desc'];

$lang['whmcs_users.defaultphone']				= "Default Phone";
$lang['whmcs_users.defaultphone.desc']			= $lang['whmcs_users.defaultaddress.desc'];

$lang['whmcs_users.defaultpostal']				= "Default Postal Code";
$lang['whmcs_users.defaultpostal.desc']			= $lang['whmcs_users.defaultaddress.desc'];

$lang['whmcs_users.defaultstate']				= "Default State";
$lang['whmcs_users.defaultstate.desc']			= $lang['whmcs_users.defaultaddress.desc'];

$lang['whmcs_users.defaultlastname']			= "Default Last Name";
$lang['whmcs_users.defaultlastname.desc']		= $lang['whmcs_users.defaultaddress.desc'];

/*
|--------------------------------------------------------------------------
| Language Translations for User Management / Modify
|--------------------------------------------------------------------------
| version 3.0.0
|--------------------------------------------------------------------------
*/

$lang['whmcs_user.label']				= "Email Address";
$lang['whmcs_user.desc']				= "Type in the current email address for the user you are searching for.";

$lang['whmcs_userinfo.email']			= "Email Address";
$lang['whmcs_userinfo.email.desc']		= 'The email address is required by WHMCS and is the single identifier across all connections.  Changing this may prevent the user from logging in across all your applications.';

$lang['whmcs_userinfo.firstname']		= "First Name";
$lang['whmcs_userinfo.firstname.desc']	= '(required)';

$lang['whmcs_userinfo.lastname']			= "Last Name";
$lang['whmcs_userinfo.lastname.desc']		= '(required)';

$lang['whmcs_userinfo.companyname']			= "Company Name";
$lang['whmcs_userinfo.companyname.desc']	= ' ';



/**
 * **********************************************************************
 * EDIT CNXNS - CLIENTAREA TAB
 * - Overrides of general language files
 * **********************************************************************
 */
//     v3.0.2
// ---------------
$lang['clientarea.tab']		= "Clientarea";

$lang['whmcs_clientarea.invoicesdisplay']	= 'Display Invoices';
$lang['whmcs_clientarea.invoicesnewwin']	= 'Invoices in New Window';
$lang['whmcs_clientarea.ticketsdisplay']	= 'Display Tickets';
$lang['whmcs_clientarea.ticketsnewwin']		= 'Tickets in New Window';

$lang['whmcs_desc.clientarea.invoicesdisplay']	= 'Do you want the invoice summary to be included on the Client Area page for your logged in clients?';
$lang['whmcs_desc.clientarea.invoicesnewwin']	= 'Do you want the invoices to be opened in a new window or tab?';
$lang['whmcs_desc.clientarea.ticketsdisplay']	= 'Do you want the ticket summary to be included on the Client Area page for your logged in clients?';
$lang['whmcs_desc.clientarea.ticketsnewwin']	= 'Do you want the tickets to be opened in a new window or tab?';




$lang['whmcs_api.invoices.header']			= 'Invoices';
$lang['whmcs_api.invoices.headerlink']		= 'View All Invoices';
$lang['whmcs_api.invoices.column.invnum']	= 'Inv #';
$lang['whmcs_api.invoices.column.invdate']	= 'Invoice Date';
$lang['whmcs_api.invoices.column.duedate']	= 'Due Date';
$lang['whmcs_api.invoices.column.total']	= 'Total';
$lang['whmcs_api.invoices.column.status']	= 'Status';
$lang['whmcs_api.invoices.column.viewinv']	= 'View Invoice';

$lang['whmcs_api.tickets.header']			= 'Support Tickets';
$lang['whmcs_api.tickets.headerlink']		= 'View All Tickets';
$lang['whmcs_api.tickets.column.tktdate']	= 'Date';
$lang['whmcs_api.tickets.column.dept']		= 'Department';
$lang['whmcs_api.tickets.column.subject']	= 'Subject';
$lang['whmcs_api.tickets.column.status']	= 'Status';
$lang['whmcs_api.tickets.column.updated']	= 'Last Updated';
$lang['whmcs_api.tickets.column.viewtkt']	= 'View Ticket';
