<?php
/*
|--------------------------------------------------------------------------
| Language Translations for the Connections Edit page
|--------------------------------------------------------------------------
| version 3.0.0
|	- For cnxn overrides of Options:  cnxn.options.group.variable
|--------------------------------------------------------------------------
*/

$lang['joomla_users.storename']				= "Account Name Creation";
$lang['joomla_users.storename.desc']		= "When a new user is created on this connection from another connection, this setting controls this connection assembles the `name` field if there isn't a specific field called `name` from the originating connection.";
$lang['joomla_users.storename_options']		= array( 'firstlast' => "First Last", 'firstlastco' => "First Last (Company)", 'lastfirst' => "Last, First", 'lastfirstco' => "Last, First (Company)" );

$lang['joomla_users.storeusername']			= "Username Creation";
$lang['joomla_users.storeusername.desc']	= "When a new user is created on another connection that doesn't utilize a `username` field, this setting will control how a new username is generated for the user on this connection.";
$lang['joomla_users.storeusername_options']	= array( 'first.last' => "first.last style", 'last.first' => "last.first style", 'random' => "Random username generation", 'flastname' => "flastname style", 'firstnamel' => "firstnamel style", 'firstname' => "Firstname Only", 'lastname' => "Lastname Only" );

$lang['joomla_users.usessl']				= "Use SSL on Log In / Out";
$lang['joomla_users.usessl.desc']			= "If you have a valid security certificate for this connection and for the domain the Integrator is using, you can enable this to protect sensitive information for customers when logging in or out.";
$lang['joomla.options.users.usessl']		= array( 'none' => "Do Not Use", 'force' => "Always Use (Force)", 'ignore' => "Defer to Global Setting (Ignore)" );

/*
|--------------------------------------------------------------------------
| Language Translations for User Management / Modify
|--------------------------------------------------------------------------
| version 3.0.0
|--------------------------------------------------------------------------
*/

$lang['joomla_userinfo.email.desc']		= 'The email address is required by Joomla and is the single identifier across all connections.  Changing this may prevent the user from logging in across all your applications.';
$lang['joomla_userinfo.username.desc']	= 'The username field is required by Joomla and can be modified here directly.';
$lang['joomla_userinfo.name.desc']		= 'The name field is required but can be set to any value your user would like.';
