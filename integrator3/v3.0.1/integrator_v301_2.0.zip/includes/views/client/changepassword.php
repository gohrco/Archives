<?php echo heading( lang( 'title.changepassword' ), '2' ); ?>

<?php if (! empty( $error ) ) : ?>

<div class="alert alert-error">
	
	<button class="close" data-dismiss="alert">x</button>
	
	<h4 class="alert-heading"><?php echo lang( 'error.heading' ); ?></h4>
	
	<ul><?php echo $error; ?></ul>
	
</div>

<?php endif; ?>

<?php if (! empty( $success ) ) : ?>

<div class="alert alert-success">
	
	<button class="close" data-dismiss="alert">x</button>
	
	<h4 class="alert-heading"><?php echo lang( 'success.heading' ); ?></h4>
	
	<ul><?php echo $success; ?></ul>
	
</div>

<?php endif; ?>

<?php echo lang( 'page.changepassword' ); ?>

<?php echo form_open( 'user/changepassword', array( 'class' => 'intReg well', 'id' => 'intReg' ) ); ?>

<?php $row = 0; ?>

<?php foreach ( $fields as $item ) : ?>
	
	<?php if ( $item->type == 'pwstrength' ) : ?>
	
	<div class="row btn-large">
		
		<div class="span1">&nbsp;</div>
		
		<div class="span2"><?php echo $item->field; ?></div>
		
	</div>
	
	<?php continue;?>
	
	<?php endif; ?>
	
<div class="control-group<?php echo $item->error ? ' error' : ''; ?>">
	
	<?php if ( $item->type == 'checkbox' ) : ?>
		
		<label class="checkbox" for="<?php echo $item->id; ?>">
			
			<?php echo $item->field; ?>
			<?php echo $item->label; ?>
		
		</label>
		
	<?php else : ?>
		
		<?php echo $item->label; ?>
		
		<div class="input-append">
		
		<?php echo $item->field; ?><span class="add-on"><i class="<?php echo $item->required ? 'icon-star' : '' ?>" id="<?php echo $item->id ?>_ico"></i></span>
		
		</div>
		
	<?php endif; ?>
	
</div>

<?php endforeach; ?>

<?php foreach( $hidden as $hide ) : ?>
<?php echo $hide->field; ?>
<?php endforeach; ?>

<div class="row btn-large">
	
	<div class="span1">&nbsp;</div>
	
	<div class="span3" style="padding-left: 20px; ">
		
		<?php echo form_button( array( 'name' => 'submit', 'id' => 'submit', 'value' => true, 'type' => 'submit', 'content' => lang( 'btn.changepassword' ), 'class' => 'btn btn-primary' ) );?>
		
	</div>
	
</div>

<input type="hidden" id="myurl" value="<?php echo site_url( 'user/changepassword' ); ?>" />

<?php echo form_close(); ?>

<script>

jQuery(document).ready(function(){
	jQuery( "#intReg" ).validationEngine( 'attach', {ajaxFormValidation: false, promptPosition : "centerRight" })
});

</script>