<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<!-- Always force latest IE rendering engine & Chrome Frame -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	
	<title><?php echo $template['title']; ?></title>
	<base href="<?php echo base_url(); ?>" />
	<?php echo $template['metadata']; ?>
	
	<!-- Mobile Viewport Fix -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
	
	<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
	
</head>
<body class="<?php echo $route; ?>">


<div id="header">
	<div id="logoholder">
		<table><tr><td width="65"><?php echo image( 'new-logo.png', null, array( 'id' => 'newlogo' ) ); ?></td>
		<td>&nbsp;<span>Integrator <small>v</small>3.0</span></td>
		<td id="userinfo"><?php echo $template['partials']['sidehdr']; ?></td></tr></table>
		<div id="pageinfo">
			
		</div>
	</div>
	
	<?php if (! $guest ): ?>
	
	<div id="toptabs">
		<div id="tabset">
			<div class="tabend"><?php echo anchor( 'admin/logout', 'Logout ' . image( 'icon24-logout.png', null, array( 'id' => 'logout', 'alt' => 'Logout' ) ) ); ?></div>
			<div class="tabstart"><?php echo image( 'icon16-adminuser.png', null, array( 'id' => 'adminuser', 'alt' => 'Admin User' ) ); ?> <?php echo sprintf( lang( 'side.greeting' ), $admin_user->first_name, $admin_user->last_name ); ?></div>
		</div>
	</div>
	
	<?php endif; ?>
	
</div>

<?php echo $template['partials']['content_header']; ?>

<div id="superholder">

	<div id="contentwrapper">
		
		<div id="sidebar">
			<?php echo $template['partials']['sidebar']; ?>
			<?php echo $template['partials']['sidelic']; ?>
		</div>
		
		<div id="bodyholder">
			<?php echo $template['partials']['content_messages']; ?>
			<?php echo $template['partials']['body']; ?>
		</div>
		
	</div>
	
	<div id="footer">
		<?php echo $template['partials']['footer']; ?>
	</div>

</div>

</body>
</html>