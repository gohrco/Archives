<?php 

$tabs = array();

foreach ( $fields as $key => $formset ) {
	$tabs[$key] = array( "id" => $key, "name" => lang( $key . '.tab' ) );
}

?>

<script>
$(function() {
	$( "#tabs" ).tabs();
});

$(function() {
	$( "#dialog-confirm" ).dialog({
		resizable: false,
		height:140,
		modal: true,
		buttons: {
			"Delete": function() {
				$( this ).dialog( "close" );
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		}
	});
});
$(document).ready(function() {
	var $dialog = $('<div></div>')
		.html('<?php echo lang( 'dialog.delete.warning' ); ?>')
		.dialog({
			autoOpen: false,
			title: '<?php echo sprintf( lang( "dialog.delete.cnxntitle" ), $name ); ?>?',
			resizable: false,
			height:260,
			width:450,
			modal: true,
			buttons: {
				"<?php echo lang( 'btn.delcnxn' ); ?>": function() {
					$( this ).dialog( "close" );
					$('#adminForm').attr("action", '<?php echo site_url( "cnxns/delete/{$cnxn_id}" ); ?>' );
					$('#submitForm').click();
				},
				"<?php echo lang( "cancel" ); ?>": function() {
					$( this ).dialog( "close" );
				}
			}
		});

	$('#deleteForm').click(function() {
		$dialog.dialog('open');
		// prevent the default action, e.g., following a link
		return false;
	});
});
</script>

<?php echo form_open( $action, array( 'id' => 'adminForm' ) ); ?>

<div class="ui-tabs ui-widget ui-widget-content ui-corner-all" id="tabs">
	<ul class="ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all">
	<?php foreach ( $tabs as $key => $tab ) : ?>
		<li class="ui-state-default ui-corner-top ui-tabs-selected ui-state-active">
			<a href="<?php echo "#".$key ?>">
				<?php echo $tab['name']; ?>
			</a>
		</li>
	<?php endforeach; ?>
	</ul>
	
	<?php foreach( $tabs as $key => $div ) : ?>
		<div class="ui-tabs-panel ui-widget-content ui-corner-bottom" id="<?php echo $key; ?>">
		<?php $cnt	= count( $fields[$key] ); ?>
		<?php $tcnt	= 0; ?>
		<?php foreach( $fields[$key] as $item ) : ?>
			<?php $tcnt++; ?>
			<div<?php if( $tcnt != $cnt ) : ?> class="append-bottom border-bottom"<?php endif; ?>>
				<div class="span-10">
					<div class="span-4"><?php echo $item->label; ?></div>
					<div class="span-6 last"><?php echo $item->field; ?></div>
				</div>
				<div class="span-10 push-1 small last"><?php echo $item->desc; ?></div>
				<div class="clear"> </div>
			</div>
		<?php endforeach; ?>
	</div>
	<?php endforeach; ?>
	
<?php foreach( $hidden as $hide ) : ?>
<?php echo $hide->field; ?>
<?php endforeach; ?>

<div class="push-4 append-bottom clear">
	<?php echo form_button( array( 'name' => 'submit', 'id' => 'submitForm', 'value' => true, 'type' => 'submit', 'content' => lang( $submit ) ) );?>
	<?php echo form_button( array( 'name' => 'delete', 'id' => "deleteForm", 'type' => 'button', 'content' => lang( $delete ), 'onClick' =>"$(delete).dialog('open');" ) ); ?>
</div>

</div>



<?php echo form_close(); ?>