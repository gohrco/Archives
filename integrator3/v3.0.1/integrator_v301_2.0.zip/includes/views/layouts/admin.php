<!DOCTYPE HTML>
<html lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		
		<!-- Always force latest IE rendering engine & Chrome Frame -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		
		<title><?php echo $template['title']; ?></title>
		
		<base href="<?php echo base_url(); ?>" />
		
		<?php echo $header_includes; ?>
		
		<!-- Mobile Viewport Fix -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
		
		<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
	</head>
<body>

<div class="container-fluid">
	<div class="row-fluid">
		
		<div class="span2">&nbsp;</div>
		
		<div class="span8" id="content">
			<?php if (! empty( $error ) ) : ?>
				<div class="row-fluid">
					<div class="span1">&nbsp;</div>
					<div class="alert alert-error span10">
						<h4 class="alert-heading"><?php echo lang( 'error.heading' ); ?></h4>
						<ul><?php echo $error; ?></ul>
					</div>
				</div>
			<?php endif; ?>
			
			<?php if (! empty( $success ) ) : ?>
				<div class="row-fluid">
					<div class="span1">&nbsp;</div>
					<div class="alert alert-success span10">
						<h4 class="alert-heading"><?php echo lang( 'success.heading' ); ?></h4>
						<ul><?php echo $success; ?></ul>
					</div>
				</div>
			<?php endif; ?>
			
			<?php echo $template['partials']['body']; ?>
		
		</div>
		
		<div class="span2">&nbsp;</div>
		
	</div>
</div>

</body>
</html>