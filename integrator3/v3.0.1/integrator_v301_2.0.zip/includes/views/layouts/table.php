<table class="table table-striped table-bordered table-condensed">
	<thead>
		<tr>
			<?php foreach ( $cols as $col ) : ?>
			<th>
				<?php echo lang( 'tblhdr.' . $col ); ?>
			</th>
			<?php endforeach; ?>
		</tr>
	</thead>
	<tbody>
		<?php foreach ( $rows as $row ) : ?>
		<tr>
			<?php foreach ( $row as $item ) : ?>
			<td>
				<?php echo $item; ?>
			</td>
			<?php endforeach; ?>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>

<div class="row">
	<div class="offset1">
		<?php echo $pagination; ?>
	</div>
</div>