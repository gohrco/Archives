<div style="height: 100px; display: block;"></div>

<?php if (! empty( $error ) ) : ?>
	<div class="row-fluid">
		<div class="span3">&nbsp;</div>
		<div class="alert alert-error span4">
			<h4 class="alert-heading"><?php echo lang( 'error.heading' ); ?></h4>
			<ul><?php echo $error; ?></ul>
		</div>
	</div>
<?php endif; ?>

<?php if (! empty( $success ) ) : ?>
	<div class="row-fluid">
		<div class="span3">&nbsp;</div>
		<div class="alert alert-success span4">
			<h4 class="alert-heading"><?php echo lang( 'success.heading' ); ?></h4>
			<ul><?php echo $success; ?></ul>
		</div>
	</div>
<?php endif; ?>

	<div class="row-fluid">
		<div class="span3">&nbsp;</div>
		<div class="span4">
		
			<div class="well-white">
				<div id="logo" style="display: block; ">Integrator <small>v</small>3.0</div>
			</div>
			
			<?php echo form_open("admin/login", array( 'id' => 'loginForm', 'class' => 'well' ) );?>
			
			<?php foreach ( $fields as $item ) : ?>
				
				<?php if ( $item->type != 'checkbox' ): ?>
					
					<?php echo $item->label; ?>
					<?php echo $item->field; ?>
					
				<?php else: ?>
					
					<div class="row">
						<div class="span1">&nbsp;</div>
						<label class="checkbox span6" for="<?php echo $item->id; ?>">
							<?php echo $item->field; ?>
							<?php echo $item->label; ?>
						</label>
					</div>
					
				<?php endif; ?>
				
			<?php endforeach; ?>
	
			<?php foreach( $hidden as $hide ) : ?>
			<?php echo $hide->field; ?>
			<?php endforeach; ?>
			
			<div class="row">
				<div class="span1">&nbsp;</div>
				<?php echo form_button( array( 'name' => 'submit', 'id' => 'submit', 'value' => true, 'type' => 'submit', 'content' => lang( 'btn.login' ), 'class' => 'btn btn-primary span2' ) );?>
				<span class="span5">
					<?php echo anchor( 'admin/forgot_password', lang( 'forgot.password' ), array( 'class' => 'btn' ) ); ?>
				</span>
			</div>
		</div>
		
		<?php echo form_close();?>
	
	</div>
</div>

<script language="javascript">
	jQuery(function (){ jQuery('#username').focus(); });
</script>