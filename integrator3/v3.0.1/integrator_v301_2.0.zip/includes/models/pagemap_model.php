<?php //00922
/**
 * ---------------------------------------------------------------------
 * Integrator v3.0
 * ---------------------------------------------------------------------
 * 2009 - 2012 Go Higher Information Services.  All rights reserved.
 * 2012 August 1
 * version 3.0.1
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPnc5SR3PDagui5paavzEs+3qOc5hZSr4IhIiaVtDLEaVoWYDoyOpDHQsHsDhRdGd8+ngJlIN
rVc4Hf/7twoB0vR11VN8eGVOqjnlTaWUAR+wnPMcDUKiRvnkekHI8xwZTpqOhsBNO6jA+dMLvk81
ZpC/Kdi4zRL9hlQAKt5ZUeWmmf2wLl25Eb4n5yHa5E06HTRdRUEHWkOsFio7t753lh08YFY0/ZW7
/1V00sk+e4zgQ7ziIVylBbJiOCK6WM6HkrDCAW6s5QXaveKolltrzfJdTIKl3eWvOX3/0akAf+PR
S9qJ8u8at4U5yMhtw5ooL1B2vflYFjiH0FwAVwV8q9ACbkbuKDXEKzn1a1iGkh1rP9x1NFztsCo/
qRETiUJDJlLTHAAk6JxBIH3vISr5u5knbWGunwcj/WBocNaCd3BmPGzUL+pv+cyUQFY4iMoCrI17
5OcOy23bKHOlNZRWsYwkG1uzgNoAWUYN0+YvFX+FoT9Z0hs04R2E5l9DfhaJi6Yt8lLnctTNGtXV
JAw7JuIwpN1X2Vtfs0RaJNfrOEVo70E8FiRhNtH6/H7mrb3713Y6UupM3YRxIkxIzH7umCTnMnYM
sKEbNmWN6fqtHfozxxekIu5UIV6eYsd/q9pClnSWQraOA6BJIYkRFHnd7tKW+TbMVyamXLVmVGuZ
xhhNRnkjPpMhR6GIpuPLgdZwG3ucHHmaVgyFRrdqTLldP7BRwcuezKf0xMEaT5Ipg779o/BZYwuG
ozHysRz2q3WldGGV+wSqgWSPTofWvS5Uk8ERaeupOS0LTYB5bZPr3AprbTQCvU+ep4BhmHYogpNJ
HOKnKtkgwOxHz6AzgiF/lE8XpyurWAh4bSeiRv3N5V1uLPAvbaj7erw8+/7RSfYVVHLxezVVBfEY
HXNsj8/vlms+YW2vQBp7QjexQPw4AU5jERFbzpiHm4o7ZDA3ToTUEtP/H/JNF/gluJT10Ai9t2dg
SxijKNo2juLIhTHcfKT07g2ZoTh/axVvuV1qzMfvXQwUFvKbPi9K0+uVj6ztZet1azF+5LZMdPmj
hxeoivXafpcus2SIn9pjnvqm1XP8SjSp9fuN4mWZ/XiFOdpI+uatZJCps8ytyv+4Yga9HFmD4I7M
ao2Rm1SRHFZRln5ll6eKEbGZvJ4RRcY9Bg5J7RiCKYkTdc65V7kMNjx7nC89WjiO0o1fT/Q0douM
og5jXU359GMwLiXZluT8dbhNs7M0k8weVJi4XkUxMeXNr8Z5fNquqROSkAyNWyqDQHVtesU+jb+t
6N09lphiH3LDoJHzOtfqwso88E959FnkiexpNpC1urd/SVNtaefwgittpUQ3TawXhKKraIkj7jnE
FORRG2Y9jK/GNhbC7syBpUm4aCx+Z1SM5H4FBtafC8Y9vWvGkwg3cK2hRwId0GBmOWoH8yl7IrgC
QBSKRAsMoTx2NO8Cty5magN5Gea9qSEIsugzWwTdbzEOyXFOTeyeET96X4CLeqMgft/tj+TaUqvB
H7c4nRGvv3yVdNMQGT+02TD/cOZfA3QRJuLEPLHQdnGC2xd3+esoYHJcwTfywztKYFATKGmDU5Hj
3xmTdSQs6sJtOBLiY5VLl5eY36BvqqE+CP+0RKOtxBuRD13vpb/pzRyAON0hLOKQbYAzpPKlfQ8s
sV3+O//dgAaQ66uL/W7xJ8ZaAzrbDGAuriT3F/KMveiVMLe/C/uaLB14+74pVutvU2FaD1UQLw/0
Xi6W4OVx+rSN7VyuzkyJwze9Jp4s6p3wy9WQH4OTnThqlOcaRL4NgsUOw97hm/y3Kh5nzgPB+HTI
8HHcrU+41stfnmuIYhY0r2pOH/9dImNmVUVBbyWvv1zv4rYZM1ZrtshAf/W4lKVEJzp0EWSRscF8
tYoMbuyhg6Y96eRdM+aL54hLs/gx2GkRnVf8HuhD9YWQv5xV+Bf7/FUDB2OJv2Ggs0xoaPxSdwj4
bSod+gtnVNGWh/FUk1354TN3e64/6gUGJZjdZeKqDwjo/oWoKvDSw6+7qzNkCgfHEDkASy8eJHaa
tDou9dML+2++U4HlJSDyIPl6PAHJe5QwNIL/X68VMXDbn8FCvjyuatPQ7J2TneXbJ2l4uiJDxI1N
9EbMrEVASByw4u7V+9+SiEGq282P0Pa2/cJjrJuDMPKAsC1JnWM3vyry/2S00jX7hcOsDU1dfsQL
M0xw/3crAt7iGpIQH+BsC+9oUaJUd6rksj5t2+dmjc0ozG8d3EATIsx3cmkYrkODnZzhIC1D0Wsn
GEBpPXpQ3v/fUt9sHNyP92tJ2HuhKsjWO5GbcU1mrHnNn+JpdYZtbDlLW+dSzU2KRLbglWIvVo1b
wlDeCLB0diQLqhFrI8XfzMmcAgebl+RtS+rP4dIpYS0p8fP/4QgD/pEzOGHrFOT/Ts75Heul0hug
uyRgItQg820SKTYQzDoX7h+AFUJ8MQkfp5Htm7GjNbTcaoW4DSaYsqJ6gqIRGEUkq0Aq1d5v5iRy
+0IfZdszTzC6LW++3eHd3uK7YkguWdxgujbxddpofSmJ6gvGimjafulqFnhY6EBsQyMP33hKKz1f
E2giuDCubkaukMBJeKkWkxsY6ELuENCNuuAUaW5UFk7o8p+rLZGcenm6KhYnTAzstWXu1bmQLzB0
RJdJoO44kvADY0tUZ7yIzeim9r5seNe79NR5VuoxwHAiOlpoP//hNHPAzdILcu2p+UMv5nylDjmq
F+5CYTBzrgS9rhvPD/+OsQI3VfRwHPsSHuuD631DJRjcp//zNNUAaBgPnhNw4WlH7qN1qoeHNgUU
qQOGpdsobgIYCjFFxF62L0WsBtqe9SWVww3lDLbRvG1JtZeUOnOk8hRAdfer0pBctWgoHtmhqH0V
PBPoS0EMHxNthonjKXEdMdItUcZMN9zJZHUVEaxqasfpJy3r3aqcqn+miodwfyMTE9yHi+CsO+Q9
RkLoOjYo1ceNA6kOUxj3uW9dt/jKQb05bBZf6S6YC7DgsJACQnba49VaZVOxKlM6q2rpgnWFCR2g
RAIPgxdvWwKwsG1Pq+3XJwOkCJ608/ZPHTICddkT0lm68yoQs6vnDFQ/j4rLPzdSujvC0RlN+PjO
Ic7gzcCI+qP6XYhn3FOVIaZKdYOQOjIMu75sx7M+vPIRqkffW6P0CKGGp1+L8yzt+Aw0MMMPm9Dt
Acl2RqbW2WFKKdm//WRvsja7ZSnkFQ4aQf9Zsy45gcxEAYydY8YRUn7GFpW8/P81aZwZVAl7Juhc
rowvpX9CAMtshP77IPjZCFui5AP7zlkvSrGfx/sumnY06Jy7I2alzwawpDOYzlurQXZ7XxY4omoQ
NZubvK2jnOzxYlpyZtBmPS52cwPyx/w/9MsPoa5LzrHNVNtMHqyi+mh/2UEsEXCPr41TkOCtxjFv
W+0OCtQDu8EhdqhcRSEMGURtqRJdCUOYONDaqmEDAsnbBvqnbWydS113KAEOkisTNtFvcXE8w0ya
LDCs/g3JCp0JKe/jCmBCEcgeQZvjpm0qRESMHxdYfWEfbHyBbxv+C4kw59byOmNHzgTO36dWJNJ1
3RCapVUImzqnmGghopuqw1YrAnQ4ArwSmpQdTTEVA/nEBMY7MHqSiGYnUzRCrNX+b9SJSNnRd8KQ
Q3OqfAq8o78csJYK7vi1jbsL7hD5kirB6MbOZmFMTt0uUIArkJ51PKlaC7tHjjO1xArQrKviN1eK
+7famvnVsG7lDmr4IV+S9Ia6G0Z7cJRySjqIpkQRGQjWIcwV8x8w+P2g6sNGDqkD49reikEjB9nQ
6bLgUD0GNkCMMOmPKmXKshle0H0rY89+zpIybSM850qW/Tt+Le19MxMPvc2dUNNzCyQuK+FM++Vs
8xmtBJJihEKET8aNguGqJC4orlfafjop5Imni45zUZG3hQlk+ysKjrEHU3QGzjfvRvSClUtZGOVN
ztjg6dQdCrI6nXRDGpxDr+ZZ0nhV++q0qIgZ2tMm3tN6jhzIqdNgimoAEDDGgcboD1eWGJNf6mcu
j5L678ugqlGUW5kbiILlzuboTOE4e166S33zCnKM3rfGlR6I+8mph4X+1hmLmYqdRfww54DiokZw
dOSSt7jex75X0aNAaaugX7820DurqMM9hhs5UGkAB2VBJilgCizR8naXs5Hs0iQvyTmQmVqLEfUf
yJ8dQUj3bETg0JEAs2W5XRZu9F28j1Qiz3WVCzXPU6L8FTGoSZFIJSSQgE4qZSIVDYrlj9vttU6c
uFMw9h7oK8gFRlMQ9aouJKW/2e1M+uZB/C7tYmmKqDBCinesr0dTCJz+/r0JhwHbxu5hCTMLlTTd
kvcB7N89yGyhXgFvTp24JV4joizkDlW8Kml7nSHVNEGg5g22k/3STQb8NZSEhANuSNqr4vExHgsr
1B8SUJaSKq9eikfwp8r856ado3qF111qc4Dy+0Qao5CYuI7PMRrloaj5BH373lALGMuj7b/6yy+x
VSaMch9S+J0o7KMlY5xnEpuNG3b+Gv4Ua/I14DZC6XWgVhsyMN76e4OxTNj+5vZ87jZzAvDNKJ/1
g/CxfmWuc4vi/xkNP/vYUlgYr/KeD+ymqrnWmJ12jdYoXaDjy8FuMLYzhV973pdMp+T7/E5VWQ6h
v0BXxAOzf3XF1Ni85b4vPxcmomIOBMB+wbSzq1KMZZ5nRjdgCmAdQtewPD0mUpZ2vrWYU+0iKsTX
pYFbRGrO5UdVl6ggX5TgcLrYAPClIpBtZrvTZMZUWMv+wXp4pfbr8a+TfC0sbWkYSUhwepyp23Dz
Y+F1IV/Pab0AsgM0YioYy69UnUuSSR8Eg+Tdwdb09jw7I347nyYJZ1iSRq4ZHFMMcZZ1v6LRwPH5
yk/r3P9SCAd0X5OwP4aTto/CY7gvCJZ8wpsO3QU/OZb4ueGNUqpJrPcjemBMG7udDAlMHxR+9Mnl
avkzuTxRX9M6oYYV8ZKntfprkdthwUnN6R2iid73fDdKTKy2jdc8jkHGj9gGRbjCnt1P5ZhMbXid
7tgF6MbrTZxe+WsJggMNFKjdKZvIktAQj0kh6LsUMcQNfhN+ZZQCobIhBElncWNGR325zHgl7sVr
IAEZ4vnV5oJj+/3Txc1fvhXwOPv2S8buaq6hbvNRWuTYQxyWqQ/2chPm4BxQ1heWYkQwYPRWEo2B
24MzHIHgrfI9Hbubj0eY/5ABynpfiqFSDSU2UCkUiTThWwGSYjocLxDI9vYQHrHxepdbV/W0sOLW
8/cCwv32HWNh+MI12SLaJBx8VUATyueg71/8We84SMqX0Zx6XL4h5OcO033oaBeZLpLrtQoh0pK/
qtVB6iTR6H6+ycxiE4bcn7ytWwpa2wu6TciRexdSt5oDEkCY8QgdQhVDCIvuj7U2CxDeR/DTYud3
Py0P4Ccjkfq82HUxHFImC9SVscV2B9gE9p/BWItGX8Hk8Nr4cZcR2Prl9yQR1DdDXR9tYAI0V78g
7P0oKPEUjkUpLn3NYDMtffzXaHBipN2xYfu4lkc8wprvFhsKsRyC8J3fj+ud5RijMNcgGTRuOoDB
IOqFH8QkEhmEIJu8/7DRjgFxcHar+IMQlwGsPfcyrZtiDVA7NH/jx4tDtlfV3MxrKXKXJwoNVhhn
m2xqtHxo6hFhWU1ie/W+YJ7lkGYI0QPNXPqnjyXfLAwpn2Cs33Y1oK5U6VMGJvyGN4kz6gbZydix
03Sd2xx8N091011Mt9NJQtCH4exbi+P6sxNRSyqrMCdgV6QC4vcrtmG0HoaJEWctXjrCZbZqJ4IG
AIaNRQecaIkYo5nCvLaG1yhBzKY8UEsr/ah9UsSFhkWdwiX9YkASfajia3Ds3KJxXMTOVh3P78QD
ZyxA4D2MRuOW3uxeD7bn16SQFsBvclxFgVCXekEdRFmpOdIAQyDTLlgaLYEMbY01WoEn5f8ljFzJ
zetBJRhOfCMOsyBPM53YgB01Hyb/FhgUscjawihlJhV4mABBERhvme0Sgm0KvKeboEUlgdetfXOq
BscYmcZ/nemNPuNGRHfK/994n/yu3xJTK2REU31TGs+OP6Nj21yEK5j498qeuiXm6ksAvZBQMG5I
4p7klMdLAJAGgxMsYKrruEZSKG1DVJV7l4wEQ31OgZMC+H8UKwWrLaS0AcuMFQyTyVfmrsSVGoA4
Zpt6jiOHbLxxiGMcUVcTZyP6r7y4//B4OT4ZEH1KKtoHk8MNCUiWimuc9XZHtFb1JaDpnzUCsMau
qDdpE9nMlb0hY9vqJwAaS0yxWr9l5KW/1DVpKFLwzaPpWQsb2qbC5NWKX8LNTYajwwakAUG6dgve
g0akCMXlO9aHqtzOK5qdvs8TahlGrFlOLhWI2f6HcJ0hc1d0PC7weojfBtQdHJYGG2U1md5R6prG
MMCbMiHKRLs18cpK0Cz3r+l4oJwU1sXkeDwrqiUjyJGXsz+szc/2E51x7NEtNioRCfqi0JVSAGkD
/RETp02pS5+1MISQ6yqR3J/tsYyFdu42p+YnhpwOZpL6EAGTh8Lgrf1QHhxKTn2Le1q5rWi4ZdgT
1ouSKnb8I+52B++ug10l8wJ1aQwdwMZPN0llHtsk+OxJ4p9P+OVLOYXT7XqLaFaQT2bHqJ/bani9
iuefiC4pbmzbiv4PDmz/+qO6YvLU8bKmfA/D5fEY5AaVpmucJH+SVMdR7ROSAJI6acoYtMo6jZHU
7hLlfUEDlJSufEM9OMjFAQZIPfCqHOYWLmnnm1jAAhbWUd4VCeQsDX1Yrwrr9Pd3dAGdhnXnzZVr
ITzkoJViW5RwQABLkSltLaD7BLJif8Vf2FY7pBGwTjPWb+IUR5EkN27vb0OBnHTODZ463qE+AXyV
IxTpbfHqY2VqpwMzlkXoNU53OyvGNfbomytgxWEXLF+GYevIkMOpDD46YSLnc7blQMSm2dVR0R18
/PSZqOtM28+At+0dTB817ozKGFeehyyPuFEQDNtdpF3BTUzGGB19iB+IsJIdf7P0UDnEnzGfFvcA
UVGFRtHvhcC7sMlMD+zNYoc3+nrFo6766xGgG2p3zItiaLYXByYUaVz6Wq70Hrqq04EmViJplhcz
MYlWdCEJTb8ZPZAn34iVhpCWM0SggPFwOUwmg0ac/mku5yfSw/TRPDdHiwc53Ed57l3MLpl8QOPz
Wuw7paQOsu03tfYkMuD1v7qOCsAA3CkqFPwXuFycA1Sx+3Jxi7uSBdB7OI4rwU+QE2Cbq5SskljM
0p0OavjYBXptRIeSfiuwfo5em8gG3JYmiZyJBZFxIoFFjxZEbrE0cQrDUfDkV5KUTCYnvt670DKH
YeXwpyxKVKs4hqW1z23tAALw9Y2rCaTN7x5dBg+b+C8De9/qKy1VSbe8vwmQrZAgoCmZ99NoimlU
FzBTPOd7oMaBUH/wqOX8NS746rg60r6BUiYEqYNg4Zc+MudOrPWm5nqbdPHWBaTYUK9P+To9CwEu
nBhKM2v0T5ylZDF3O9TASqqLapuFi6wyCGY5zGGqOq1DWYRJ1XLZxD56ULXTaFXNij5tITqBnI/n
M00NEFdpYWyGefkCMDWrHkcYtUtWgDs/y2/AM6syTxTmGjHGGJ/FMyGam1Glw/Ob4ZTFEnGHug9y
+eaJutjkzullH79dk0V+uXIkCgYe3Wlm+jhjZODeThbLKBULrCr55QDX9bxrSFcJpe7MYCemnPhE
+LRHWD1o5/wEq+Wq2BzF/cSe2UYukFSZhEHiDhArkFiWq1m6z5PDTU8gEwjTfaZlrJcV/R7qgHhX
vi+mDLuxTIfOZ22yiAZBPp3vzYlzh963m7ymSdTchUnF8zVP/t5rrYthakSLHBdZ8vioVVYFMZuh
yyvSWKJ8yShrUqfHDMk40jo1dyWhBwd2bpY/9op5ybQfqhPPtzInGomCSDOLUJRPekKKEKKd5HoO
rqT9fc2SIPN6+khn3lyYv75reDIKQ82XFS3S1kINRjU0VCg/Sjupdx/6wbiAuHTWXQ4ddXhGIS7z
vyimSfsv0EoBvEXTt1bXBjh6JPGd0eqGyz+LII2tBTivDKOA/IsH2R4Jh2XXjd0knnPi/8mZidq+
rGj4wHCA24ZXyOlfAbikOXsPqH76p1QgL7ZIuYBE34EVbDOguIes2BQXq7wlz5h6/QQ00trCDjYA
YJig6qyika4QecVX3ohPBVstdb/m7vEWHnuiCjsFJEeJw4snz84cpYjGO7mLnMhiA6fRJDHQ97nO
2oyCenNjKP93xAZCZv2ygQ5vOrQohPCaSRJQ5tvt41YamoezrqjGfCCq/+jbkTRQ8CRVjAc6VY7y
cgPaGA7CHEJGsBlKu0qxprg3M3E1cznjY+n/hg0mGisBGveeWY4oH7F1Lg/y4PvJXOxazsv9tKiT
ldkh/m5ezSrZBuVbg36UmDIF1vo4pLLJ6s4KMvtcZffFtkh57wYfjUejDvWL5iwbZvUGwJcaUan+
zSNJIw7eTSpbwXWttCWx/lQSqhf9lCbuRwPFyHLrJk7DQeGTUeZ5I0uc1U33VkbSMEYJVH9WA77e
cAB/kqN+EvxlAs2DiTmw+Itij/tXNIeVVmwOBC7jgoDvVsSDQXNYTdhtvWSxFdb+9+6mX7Ogi0eW
bnfFsWzP6MKTlI6Oxnp/AaVnTghs1VTPOE8ZUzAr0WIT6NqZo6e5GJTF09A0JZEYyj5+8EJ8qmpc
K7wp+KZVKn73VseaJNX/XwVIFOl9hAwbuiEVwlwYXRbtidxJd3g8wtuPaXb8vawe22YFXMryUkqw
uwtm6P66LxYUedk2P8IxstumpzeCLEWj80FbJmM+qRFqr/IrmPP9SBjjsjmaDuMj4H9UglKz9Kbg
nqNeaboM3i5hNUnhl7Lg+LfAAEkGYLC6EtpctOrGzBpvpydMgKEtAvGEYk3o1+lQrQRzsqLptgeP
0kpfDifEpnKN2gkiHh7rBGLGCxx0FUoItThuCzBnva65U7wl8CvQLPrgFWXWtNnUK4R7HfuJ2lR5
lcYv2LHPPFdG7E3tOcZfSF5/kVdXVPQbZO6XbDqirqpi2PzwSK8safW7YVW72cOuXC+UFaeemUWX
oIqkWzKGjkM2WzUsl9Qi94zYiCFf5SyWXxFwNRZkVjSUC1TWl+oGkOKMWIR4lgcgWjBRjttMaTrQ
7KaaKnVSwGYntWeB5oXfpJ50h0i9Vo2qIsk3rHsIFId/PwstwVVUQL69rhnCwkl3cyUYwHb09Nd8
rBk696iA/2f+idk3RM6RT5HIXn5EkvZ2fgudppliAl1oYEBYuR/nro/VwvaYQ2s97GxGG3+4PtTB
sQAVI8CQtuIWFm7JIlHYtNHgxlLvTr88FOCMYgPssyDIqUQQgAkUfBeQlMGBFy6Vs4jObIwGSpl5
ccc8sI5QmoTl1t1JvHIaM2WV8OePgrpVilaAnFI2/5XXV4R/nCiPOGZXZ4cVMedVIxm2mKNyU3NF
w/sEDXniWzdlxdV4yTyhi+kiPC+XT4QvuhTiq4veh/ae3i02Ktjy6EgGXWngvo1b1V969sMsXDvs
D16iV4icZuT5siOhOsx7/Lf4VPTl2m1M0jDOWwLwRKN4z0wZ1SoMj1My5DCe+BCHlXrJjXw32i35
SQvFQKO6ZmWxHNMImaFI8SaTTCYqX3KWYVc7Ds+nIAnAxG==