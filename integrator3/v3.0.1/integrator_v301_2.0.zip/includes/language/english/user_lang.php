<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.2.0 ( $Id: users_lang.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the user manager controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * LOGIN FIELDS
 * **********************************************************************
 */
		//     v3.0.1
		// ---------------
		$lang['label.email']			= "Email Address";
		$lang['label.oldpassword']		= 'Old Password';
		$lang['label.password']			= "Password";
		$lang['label.remember']			= "Remember Me";
		$lang['label.newpassword']		= 'New Password';
		$lang['label.newpassword2']		= ' ';
		
		$lang['btn.edit']				= 'Make Changes';
		$lang['btn.edituser']			= 'Edit User';
		$lang['btn.changepw']			= 'Change Password';
		$lang['btn.login']				= "Login";
		$lang['btn.logout']				= 'Log Out';
		$lang['btn.changepassword']		= 'Change Password';
		$lang['btn.forgotpassword']		= 'Forgot Password?';
		
		$lang['title.edit']				= 'Edit Your Information';
		$lang['title.login']			= "Client Login";
		$lang['title.changepassword']	= 'Change Password';
		$lang['title.userinfo']			= 'Client Information';
		$lang['title.contactinfo']		= 'Contact Information';
		
		$lang['place.email']			= 'Your email address';
		$lang['place.password']			= 'Your password';
		$lang['place.oldpassword']		= 'Your current password';
		$lang['place.password']			= 'New password';
		$lang['place.password2']		= 'Retype password';
		
		$lang['success.heading']		= 'Success!';
		$lang['success.edituser']		= 'Your details have been updated successfully!';
		$lang['success.changepassword']	= 'Password updated successfully!';
		
		$lang['error.heading']			= 'Error Message';
		$lang['error.authentication']	= 'Your old password is incorrect!';
		
		$lang['tip.identifyusername']	= 'This is your username';