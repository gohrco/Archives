<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.2.0 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      3.0.1 (2.0)
 * 
 * @desc       This is the English language file for the messages displayed in the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * SUCCESS MESSAGES - Used for successful messages
 * **********************************************************************
 */
$lang['success.ajaxemail']				= 'Email address is okay!';
$lang['success.ajaxpassword']			= 'Password checks out!';
$lang['success.ajaxusername']			= 'Your username will be fine!';
$lang['success.changepassword']			= 'Password updated successfully!';
$lang['success.edituser']				= 'Your details have been updated successfully!';
$lang['success.heading']				= 'Success!';


/**
 * **********************************************************************
 * ERROR MESSAGES - Used for displaying error messages
 * **********************************************************************
 */
$lang['error.authentication']			= 'Your old password is incorrect!';
$lang['error.credsorigin']				= 'Originating Connection Information missing: Unable to proceed';
$lang['error.emailerrorcheck']			= 'That email address is already in use on our system. Please enter another email address.';
$lang['error.emailerrorfree']			= 'Our system does not permit email addresses from that domain. Please enter another email address.';
$lang['error.heading']					= 'Error Message';
$lang['error.passworderrorcheck']		= 'That password is insufficient for our system.';
$lang['error.returnurl']				= 'There was no way to determine where to send you once you had completed the login procedure.  Please contact the administrators of this site to let them know of the issue you encountered.';
$lang['error.usernameerrorcheck']		= 'That username is already in use by another user. Please enter another username.';
$lang['error.userupdate']				= 'There was a problem updating the user account: `%s`';

// This is a special one used across all controllers for XSS validation
$lang['csrfcheck']						= 'Your session token was invalidated - please try again!';
