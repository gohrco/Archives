<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.2.0 ( $Id: login_lang.php 53 2012-07-20 15:23:08Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the admin controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * MESSAGES
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['msg.error.credsorigin']		= "Originating Connection Information missing: Unable to proceed";
		$lang['msg.error.returnurl']		= "There was no way to determine where to send you once you had completed the login procedure.  Please contact the administrators of this site to let them know of the issue you encountered.";
		
		$lang['title.login']				= "Logging In";
		$lang['msg.redirectingnow']			= "Logging In...";
		
		$lang['error.login']				= 'There was a problem with your email address or password.  Please try again.';
		$lang['error.loginoncnxn']			= 'A problem was encountered and you were not logged into `%s`.  Please try logging out and logging back in.  If the problem occurs again, please contact us.';
		$lang['success.loggedin']			= 'You have logged in successfully!';