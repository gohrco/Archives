<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.2.0 ( $Id: pagemap_lang.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the pagemap controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * PAGEMAP PAGE
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['pagemap.index']			= "Page Mappings";
		$lang['pagemap.index.desc']		= "Map the available pages from your applications to your sites so the proper pages are loaded by the Integrator.";
		
		$lang['pagemap.hdr.page']			= "Page";
		$lang['pagemap.hdr.defaultpage']	= "Default Page";
		
		$lang['option.pagemap.default'] 	= "use default page";
		
		$lang['msg.success.pagemapsaved']	= "Page Mapping Saved!";