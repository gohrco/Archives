<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.2.0 ( $Id: users_lang.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the user manager controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * USER FORM FIELDS
 * - Translations may be overridden in cnxn specified language file
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
$lang['users.index']		= "Manage Users";
$lang['users.index.desc']	= "Manage the users with access to this application.";

$lang['users.change_password']		= "Change Password";
$lang['users.change_password.desc']	= "Change this users' password by filling in both fields below and clicking on `Change Password`.";
$lang['users.change_password.newpw']	= "New Password";
$lang['users.change_password.confpw']	= "Confirm New Password";


// These apply to create and edit methods
$lang['users.firstname']	= "First Name";
$lang['users.lastname']		= "Last Name";
$lang['users.username']		= "Username";
$lang['users.email']		= "Email Address";
$lang['users.group']		= "Permissions Group";
$lang['users.company']		= "Company Name";
$lang['users.password']		= "Password";
$lang['users.pwconfirm']	= "Confirm Password";

$lang['users.msg.usercreated']	= "User Created";
$lang['users.msg.userupdated']	= "User Updated";

/*
|--------------------------------------------------------------------------
| Deactivate User
|--------------------------------------------------------------------------
| version 3.0.0
|--------------------------------------------------------------------------
*/




/*
|--------------------------------------------------------------------------
| Create / Edit User
|--------------------------------------------------------------------------
| version 3.0.0
|--------------------------------------------------------------------------
*/

$lang['users.create_user']			= "Create User";
$lang['users.create_user.desc']		= "Enter the information completely and press `Create User`.";

$lang['users.edit_user']			= "Edit User";
$lang['users.edit_user.desc']		= "Make changes to the information for this user below and press `Save Changes`";

$lang['username']					= "Username";
$lang['username.desc']				= "Enter a unique username for this user.  This will be separate from any others used on other connections.";

$lang['first_name']					= "First Name";
$lang['first_name.desc']			= "Enter the first name of the user.";

$lang['last_name']					= "Last Name";
$lang['last_name.desc']				= "Enter the last name of the user.";

$lang['email']						= "Email Address";
$lang['email.desc']					= "Enter a unique email address for this user.";

$lang['group_id']					= "Permissions Group";
$lang['group_id.desc']				= "Select which permissions group this user belongs to.  Choices are <ul><li><strong>Administrator</strong> - Backend access to the Integrator.</li><li><strong>API Users</strong> - API access to the Integrator only.</li>";

$lang['company']					= "Department Name";
$lang['company.desc']				= "Enter the department name for this user.";

$lang['password']					= "Password";
$lang['password.desc']				= "Enter a password for this user.";
$lang['edit.password.desc']			= "(leave blank for no change) Enter a password for this user.";

$lang['password-confirm']			= "Confirm Password";
$lang['password-confirm.desc']		= "Confirm the password";

$lang['button.create_user']			= "Create New User";
$lang['button.edit_user']			= "Save Changes To User";

$lang['msg.create_user.success']	= "New user created successfully!";
$lang['msg.edit_user.success']		= "Changes saved to user successfully!";


/*
|--------------------------------------------------------------------------
| Verify Action
|--------------------------------------------------------------------------
| version 3.0.0
|--------------------------------------------------------------------------
*/
$lang['verify.delete_user']			= "Delete User?";
$lang['verify.delete_user.desc']	= "Are you sure you want to delete this user?  This action cannot be undone!";

$lang['verify.deactivate']			= "Deactivate User";
$lang['verify.deactivate.desc']		= "Are you sure you want to deactivate this user?";

$lang['deactivate.confirm']			= "Deactivate User?";
$lang['deactivate.confirm.desc']	= "Selecting yes will deactivate this user, selecting no will cancel the action.";

$lang['button.delete_user']	= "Confirm Delete";
$lang['button.deactivate']	= "Confirm Deactivation";