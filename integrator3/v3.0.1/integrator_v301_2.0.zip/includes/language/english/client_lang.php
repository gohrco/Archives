<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.2.0 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      3.0.1 (2.0)
 * 
 * @desc       This is the English language file for the client side of the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * LABELS - Input field labels
 * **********************************************************************
 */

$lang['label.email']			= "Email Address";
$lang['label.oldpassword']		= 'Old Password';
$lang['label.remember']			= "Remember Me";

$lang['label.firstname']		= 'First Name';
$lang['label.lastname']			= 'Last Name';
$lang['label.username']			= 'Username';
$lang['label.email']			= 'Email Address';
$lang['label.password']			= 'Password';
$lang['label.password2']		= 'Confirm Password';
$lang['label.address1']			= 'Address';
$lang['label.address2']			= 'Address 2';
$lang['label.city']				= 'City';
$lang['label.state']			= 'State';
$lang['label.postal']			= 'Postal Code';
$lang['label.country']			= 'Country';
$lang['label.phone']			= 'Phone Number';
$lang['label.companyname']		= 'Company Name';



/**
 * **********************************************************************
 * BUTTONS - Individual button languages
 * **********************************************************************
 */
$lang['btn.edit']				= 'Make Changes';
$lang['btn.edituser']			= 'Edit User';
$lang['btn.changepw']			= 'Change Password';
$lang['btn.login']				= "Login";
$lang['btn.logout']				= 'Log Out';
$lang['btn.changepassword']		= 'Change Password';
$lang['btn.forgotpassword']		= 'Forgot Password?';
$lang['btn.register']			= 'Register';


/**
 * **********************************************************************
 * TITLES - Appear at the top of the pages
 * **********************************************************************
 */
$lang['title.edit']				= 'Edit Your Information';
$lang['title.login']			= "Client Login";
$lang['title.changepassword']	= 'Change Password';
$lang['title.userinfo']			= 'Client Information';
$lang['title.contactinfo']		= 'Contact Information';
$lang['title.register']			= 'Client Registration';


/**
 * **********************************************************************
 * PAGE DATA - Used on the site to display paragraph descriptions
 * **********************************************************************
 */
$lang['page.changepassword']	= '<p>To change your password, please be sure to enter your current password below.  Then enter a new password and confirm it to continue.</p>';
$lang['page.clientarea']		= '<p>Below you will find your account information as well as other relavent data pertaining to your account.</p>';
$lang['page.login']				= '<p>Please enter your email address and password on file with us below to log into our site.</p>';
$lang['page.register']			= '<p>Thank you for registering with us!  Please complete the form below and click "Register" at the bottom to continue.  Note that fields marked with a <i class="icon-star"></i> are required to complete registration.</p>';
$lang['page.useredit']			= '<p>Please update your information below.  Note that fields marked with a <i class="icon-star"></i> are required data fields.</p>';


/**
 * **********************************************************************
 * PLACEHOLDERS - Used for blank input text fields
 * **********************************************************************
 */
$lang['place.email']			= 'Your email address';
$lang['place.password']			= 'Your password';
$lang['place.oldpassword']		= 'Your current password';
$lang['place.password']			= 'New password';
$lang['place.password2']		= 'Retype password';


/**
 * **********************************************************************
 * TIPS - Tooltip mouseover tips
 * **********************************************************************
 */


$lang['tip.identifyusername']	= 'This is your username';