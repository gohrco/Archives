<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.2.0 ( $Id: render_lang.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the rendering controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * RENDERING MESSAGES
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['msg.error.disabled']				= "The Integrator is disabled - unable to make a connection";
		$lang['msg.error.visualdisabled']		= "Visual integration has been disabled globally in the Integrator!";
		$lang['msg.error.defaultvisualunset']	= "The site administrator hasn't defined a default visual site in the global settings yet.";
		$lang['msg.error.misconfiguration']		= "Integrator encountered a misconfiguration and could not render the request.";
		$lang['msg.error.incorrectvisual']		= "The requested site cannot be retrieved due to a type conflict.";
		$lang['msg.error.nocnxnfound']			= 'No connection corresponds to the ID provided.';
		$lang['msg.error.cnxndisabled']			= 'One of the connections in Integrator is inactive or has visual capabilities disabled.';
		$lang['msg.error.secrethashinvalid']	= 'The signature and salt dont add up... bailing!';
		
		$lang['msg.error.constr.appobject']		= 'There is a problem building the app object';
		$lang['msg.error.constr.siteobject']	= 'There is a problem building the site object';
		
		$lang['render.setcookies.noread']		= 'Unable to find the cookie file for rendering the site.';
		$lang['render.setcookies.noopen']		= 'Unable to read the cookie file for rendering the site.';
		$lang['render.setcookies.empty']		= 'The rendering cookie file is empty for this connection.';
		