UPDATE IGNORE `__DBPREFIX__settings` SET `value`='3.0.1.2.0' WHERE `key` = 'Version';

-- command split --

CREATE TABLE `__DBPREFIX__cnxnlog` (
`id`  int(100) NOT NULL AUTO_INCREMENT ,
`timestamp`  timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP ,
`cnxn`  mediumint(10) NOT NULL ,
`destcnxn`  mediumint(10) NOT NULL ,
`action`  varchar(100) NOT NULL ,
`request`  text NULL ,
`response`  text NULL ,
`data`  text NULL ,
`remote`  tinyint NOT NULL DEFAULT 0 ,
PRIMARY KEY (`id`)
);

