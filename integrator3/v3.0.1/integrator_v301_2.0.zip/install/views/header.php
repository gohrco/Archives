<h2 class="header"><?php echo lang( $content_header ); ?></h2>
<h4 class="subheader"><?php echo lang( $content_subheader ); ?></h4>
<p class="desc"><?php echo lang( $content_description ); ?></p>