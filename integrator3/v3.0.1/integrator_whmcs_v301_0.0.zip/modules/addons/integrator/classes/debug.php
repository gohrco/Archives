<?php
/**
 * Integrator
 * WHMCS - Factory File
 * 
 * @package    Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.0 ( $Id: debug.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file instantiates objects as needed
 * 
 */

/*-- Security Protocols --*/
if (!defined("WHMCS")) die("This file cannot be accessed directly");
/*-- Security Protocols --*/

/**
 * Debug Class
 * @version		3.0.1.0.0
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntDebug extends IntObject
{
	/**
	 * The domain the cookie is set for
	 * @access		public
	 * @var			string
	 * @since		3.0.0
	 */
	public $c_domain	= '';
	
	/**
	 * The cookie expiration time
	 * @access		public
	 * @var			integer
	 * @since		3.0.0
	 */
	public $c_expire	= 300;
	
	/**
	 * The cookie name to use
	 * @access		public
	 * @var			string
	 * @since		3.0.0
	 */
	public $c_name		= "Int_Whmcs451_Debug";
	
	/**
	 * The cookie path to use
	 * @access		public
	 * @var			string
	 * @since		3.0.0
	 */
	public $c_path		= '';
	
	/**
	 * Contains data messages for debugging
	 * @access		public
	 * @var			array
	 * @since		3.0.0
	 */
	public $data		= array( 'new' => array(), 'persist' => array() );
	
	/**
	 * THIS IS WHAT WE ARE USING FOR API DEBUG
	 * @access		public
	 * @since		3.0.0
	 * @var			array
	 */
	public $debug		= array();
	
	/**
	 * Debug enable
	 * @access		public
	 * @var			boolean
	 * @since		3.0.0
	 */
	public $enable		= false;
	
	/**
	 * ? NEEDED ?
	 */
	public $keep		= false;
	
	/**
	 * Contains notices for debugging
	 * @access		public
	 * @var			array
	 * @since		3.0.0
	 */
	public $notice		= array( 'new' => array(), 'persist' => array() );
	
	/**
	 * The script name set that is calling the debugger
	 * @access		public
	 * @var			string
	 * @since		3.0.0
	 */
	public $script		= null;
	
	/**
	 * Switches between `new` and `persist` based on object calls
	 * @access		public
	 * @var			string
	 * @since		3.0.0
	 */
	public $use			= 'new';
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.1.0.0
	 * @param		array		- $options: optional settings to use
	 * 
	 * @since		3.0.0
	 */
	public function __construct( $options = array() )
	{
		if ( isset( $options['enable'] ) ) {
			$this->enable = $options['enable'];
		}
		
		$this->_read_cookie();
	}
	
	
	/**
	 * Destructor method
	 * @access		public
	 * @version		3.0.1.0.0
	 * 
	 * @since		3.0.0
	 */
	public function __destruct()
	{
		if (! $this->enable ) return;
		
		$this->render();
		$this->_set_cookie();
	}
	
	
	/**
	 * Adds a line for debugging purposes
	 * @access		public
	 * @version		3.0.1.0.0
	 * @param		string		- $data: contains the message to add
	 * @param		string		- $filename: the filename the debug was called from
	 * @param		integer		- $line: the line number called from
	 * @param		string		- $type: indicates what type of debug info this is
	 * @param		bool		- $translate: true to translate the string
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function add( $data = null, $filename = null, $line = 0, $type = 'info', $translate = false )
	{
		$lang	= & IntFactory :: getLang();
		$this->debug[]	= array( 'message' => ( $translate ? $lang[$data] : $data ), 'filename' => $filename, 'line' => $line, 'type' => $type );
		return true;
	}
	
	
	/**
	 * Permits adding an entire array of data from the API to the debug class
	 * @access		public
	 * @version		3.0.1.0.0
	 * @param		array		- $data: any debug errors returned by the API
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function add_array( $data = array() )
	{
		if ( empty( $data ) ) return;
		
		foreach ( $data as $d ) {
			$this->add( $d['message'], $d['filename'], $d['line'], $d['type'] );
		}
		
		return true;
	}
	
	
	/**
	 * Get method
	 * @access		public
	 * @version		3.0.1.0.0
	 * @param		string		- $name: the name of the property to get
	 * @param		mixed		- $default: the default value to return if not set
	 * 
	 * @return		mixed value of property or default value if unset
	 * @since		3.0.0
	 */
	public function get( $name, $default = null )
	{
		$isset = $this->$name;
		return ( $isset == null ? $default : $isset );
	}
	
	/**
	 * Retrieves the output to respond with
	 * @access		public
	 * @version		3.0.1.0.0
	 * 
	 * @return		array of data or empty array if disabled / empty
	 * @since		3.0.0
	 */
	public function get_output()
	{
		if ( $this->enable == false ) return array();
		$data = $this->get( 'debug', array() );
		return $data;
	}
	
	
	/**
	 * Sets a data message to the object
	 * @access		public
	 * @version		3.0.1.0.0
	 * @param		string		- $message: a data message to set
	 * @param		boolean		- $first: true to set in front of others
	 * 
	 * @since		3.0.0
	 */
	public function data( $message, $first = false )
	{
		$message = $this->script . ':  <strong>' . htmlentities( $message ) . '</strong>';
		if ( $first ) {
			array_unshift( $this->data[$this->use], $message );
		}
		else {
			$this->data[$this->use][] = $message;
		}
	}
	
	
	/**
	 * Sets an information message to the object
	 * @access		public
	 * @version		3.0.1.0.0
	 * @param		string		- $message: the message to set
	 * @param		boolean		- $first: true to set in front of others
	 * 
	 * @since		3.0.0
	 */
	public function info( $message, $first = false )
	{
		$message = $this->script . ':  <strong>' . htmlentities( $message )  . '</strong>';
		if ( $first ) {
			array_unshift( $this->notice[$this->use], $message );
		}
		else {
			$this->notice[$this->use][] = $message;
		}
	}
	
	
	/**
	 * Sets a notice message to the object
	 * @access		public
	 * @version		3.0.1.0.0
	 * @param		string		- $message: a message to set
	 * @param		boolean		- $first: true to set in front of others
	 * 
	 * @return		result of info()
	 * @since		3.0.0
	 */
	public function notice( $message, $first = false )
	{
		return $this->info( $message, $first );
	}
	
	
	/**
	 * Persists the current new messages to persist in next iteration
	 * @access		public
	 * @version		3.0.1.0.0
	 * 
	 * @since		3.0.0
	 */
	public function persist()
	{
		foreach( $this->data['new'] as $msg ) {
			array_unshift( $this->data['persist'], $msg );
		}
		
		foreach( $this->notice['new'] as $msg ) {
			array_unshift( $this->notice['persist'], $msg );
		}
		
		$this->use = 'persist';
	}
	
	
	/**
	 * Renders the debug screen to the user
	 * @access		public
	 * @version		3.0.1.0.0
	 * 
	 * @since		3.0.0
	 */
	public function render()
	{
		if (! $this->enable ) return;
		if ( defined( "INTEGRATORAPI" ) ) return;
		
		$data	= $this->data['new'];
		$notice	= $this->notice['new'];
		
		unset( $this->data['new'], $this->notice['new'] );
		
		if ( empty( $data ) && empty( $notice ) ) return;
		
		$content	= '<table width="100%" cellpadding="5" cellspacing="0" border="0">'
					. '<thead><tr><td>Integrator Debug Message Data</td></tr></thead><tbody>';
		
		foreach ( $data as $d ) {
			$content .= '<tr><td>' . $d . '</td></tr>';
		}
		
		$content	.= '</tbody></table><br/>'
					. '<table width="100%" cellpadding="5" cellspacing="0" border="1">'
					. '<thead><tr><td>Integrator Debug Notice Data</td></tr></thead><tbody>';
		
		foreach ( $notice as $d ) {
			$content .= '<tr><td>' . $d . '</td></tr>';
		}
		
		$content	.= '</tbody></table>'
					. '<style>table { font-family: Helvetica; font-size: 13px; }'
					. 'thead { background: none repeat scroll 0 0 #223344; color: #EEEEEE; font-weight: bold; }'
					. 'thead td { padding: 10px; }'
					. 'tbody { color: #444; }'
					. 'tbody td { border-bottom: 1px solid #223344; padding: 10px; }</style>';
		
		echo <<< HTML
<script type="text/javascript">
		function addEvent(obj, evType, fn){ 
 if (obj.addEventListener){ 
   obj.addEventListener(evType, fn, false); 
   return true; 
 } else if (obj.attachEvent){ 
   var r = obj.attachEvent("on"+evType, fn); 
   return r; 
 } else { 
   return false; 
 } 
}

function debug_popup() {
var w = window.open('', '', 'width=500,height=400,resizeable,scrollbars');
w.document.write('{$content}');
w.document.close(); // needed for chrome and safari
}
addEvent(window, 'load', debug_popup);
		</script>
HTML;
		
	}
	
	
	/**
	 * Sets the script name
	 * @access		public
	 * @version		3.0.1.0.0
	 * @param		string		- $name: the name to set debug to
	 * 
	 * @since		3.0.0
	 */
	public function script( $name = null )
	{
		$this->script = $name;
	}
	
	
	/**
	 * Sets an array of options to object
	 * @access		public
	 * @version		3.0.1.0.0
	 * @param		array		- $options: contains array of options
	 * 
	 * @since		3.0.0
	 */
	public function set_options( $options = array() )
	{
		foreach ( $options as $k => $v ) {
			$this->$k = $v;
		}
	}
	
	
	/**
	 * Reads the stored cookie and sets data
	 * @access		private
	 * @version		3.0.1.0.0
	 * 
	 * @return		boolean true on success
	 * @since		3.0.0
	 */
	private function _read_cookie()
	{
		$data = $_COOKIE["{$this->c_name}"];
		
		if ( $data == null ) {
			return false;
		}
		
		$data = $this->_unserialize( $data );
		$this->data['new'] = $data['data'];
		$this->notice['new'] = $data['notice'];
		return true;
	}
	
	
	/**
	 * Serializes data
	 * @access		private
	 * @version		3.0.1.0.0
	 * @param		mixed		- $data: can be array or string of data
	 * 
	 * @return		serialized base64 encoded string
	 * @since		3.0.0
	 */
	private function _serialize( $data )
	{
		if ( is_array( $data ) ) {
			foreach ( $data as $key => $val ) {
				if ( is_string( $val ) ) {
					$data[$key] = str_replace('\\', '{{slash}}', $val);
				}
			}
		}
		else {
			if ( is_string( $data ) ) {
				$data = str_replace('\\', '{{slash}}', $data);
			}
		}
		
		return base64_encode( serialize($data) );
	}
	
	
	/**
	 * Sets a temporary cookie until next load
	 * @access		private
	 * @version		3.0.1.0.0
	 * 
	 * @since		3.0.0
	 */
	private function _set_cookie()
	{
		$data = array( 'data' => $this->data['persist'], 'notice' => $this->notice['persist'] );
		
		$data	= $this->_serialize( $data );
		$expire = ( $this->c_expire + time() );
		
		setcookie(
			$this->c_name,
			$data,
			$expire,
			$this->cpath,
			$this->cdomain,
			false
		);
	}
	
	
	/**
	 * Unserializes a set of data
	 * @access		private
	 * @version		3.0.1.0.0
	 * @param		string		- $data: base64 encoded and serialized string
	 * 
	 * @return		mixed array of unserialized data or string of data
	 * @since		3.0.0
	 */
	private function _unserialize( $data )
	{
		$data = unserialize( base64_decode( $data ) );
		
		if ( is_array( $data ) ) {
			foreach ( $data as $key => $val ) {
				if ( is_string( $val ) ) {
					$data[$key] = str_replace('{{slash}}', '\\', $val);
				}
			}
			
			return $data;
		}
		
		return ( is_string( $data ) ) ? str_replace( '{{slash}}', '\\', $data ) : $data;
	}
}