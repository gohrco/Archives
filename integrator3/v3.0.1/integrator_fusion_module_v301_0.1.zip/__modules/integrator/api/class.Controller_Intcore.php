<?php
/**
 * Integrator
 * 
 * @package    Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.1 ( $Id: class.Controller_Intcore.php 15 2012-04-28 02:33:07Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file handles api calls to the Integrator within Fusion
 * 
 */

require_once( SWIFT_BASEPATH . DIRECTORY_SEPARATOR . SWIFT_MODULESDIRECTORY . DIRECTORY_SEPARATOR . 'integrator' . DIRECTORY_SEPARATOR . 'library' . DIRECTORY_SEPARATOR . 'defines.php' );

/**
 * Integrator Core API Controller
 * @author		Steven
 * @version		3.0.1.0.1
 * 
 * @since		3.0.0
 */
class Controller_Intcore extends Controller_api implements SWIFT_REST_Interface
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
		$this->Load->Library('XML:XML');
		$this->Language->Load( 'api' );
		
		define( 'INTEGRATOR_API', true );
		return true;
	}
	
	
	/**
	 * Destructor method
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function __destruct()
	{
		parent::__destruct();
		return true;
	}
	
	
	/**
	 * Returns information about the cnxn
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		array
	 * @since		3.0.1 (0.1)
	 * @throws		SWIFT_Exception
	 */
	public function GetInfo()
	{
		if (! $this->GetIsClassLoaded() ) {
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
			return false;
		}
		
		$version = $this->Settings->GetKey( 'moduleversions', 'integrator' );
		
		$this->XML->AddParentTag('info');
		
		$this->XML->AddTag('version', $version );
		
		$this->XML->EndParentTag('info');
		$this->XML->EchoXML();
		return true;
	}
	
	
	/**
	 * Retrieves available languages for selection in the Integrator
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function GetLanguages()
	{
		if (! $this->GetIsClassLoaded() ) {
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
			return false;
		}
		
		$query	= 'SELECT `title` as name, `languagecode` as value from `swlanguages` ORDER BY `title`';
		$this->Database->QueryLimit( $query );
		
		$this->XML->AddParentTag('languages');
		
		while ( $this->Database->NextRecord() ) {
			$this->XML->AddParentTag('language');
			$this->XML->AddTag('name', "{$this->Database->Record['name']}" );
			$this->XML->AddTag('value', $this->Database->Record['value'] );
			$this->XML->EndParentTag('language');
		}
		$this->XML->EndParentTag('languages');
		$this->XML->EchoXML();
		return true;
	}
	
	
	/**
	 * Gets a list of methods (not used in Integrator)
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		false
	 * @since		3.0.0
	 */
	public function GetList()
	{
		if (!$this->GetIsClassLoaded()) {
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
			return false;
		}
		$this->RESTServer->DispatchStatus(SWIFT_RESTServer::HTTP_BADREQUEST, 'Not Implemented.');
		return false;
	}
	
	
	/**
	 * Retrieves a list of pages for selection of user actions
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function GetPages()
	{
		if (! $this->GetIsClassLoaded() ) {
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
			return false;
		}
		
		$pages	= array(	'Core/Default/Index'	=> 'getpages_home',
							'Tickets/Submit'		=> 'getpages_ticketsubmit',
							'Knowledgebase/List'	=> 'getpages_knowledgebase',
							'News/List'				=> 'getpages_news',
							'Troubleshooter/List'	=> 'getpages_troubleshooter'
		);
		
		foreach( $pages as $link => $page ) $pages[$link] = $this->Language->Get( "{$page}" );
		
		$spages	= $this->Settings->Get( 'integrator_custompages' );
		$sets	= explode( "\n", trim( $spages ) );
		foreach ( $sets as $set ) {
			if (! strstr($set, '|') ) continue;
			$parts	= explode( "|", $set );
			$pages[$parts[0]] = $parts[1];
		}
		
		asort( $pages );
		
		$this->XML->AddParentTag( 'pages' );
		foreach ( $pages as $link => $page ) {
			$this->XML->AddParentTag('page');
			$this->XML->AddTag('name', $page );
			$this->XML->AddTag('value', $link );
			$this->XML->EndParentTag('page');
		}
		
		$this->XML->EndParentTag( 'pages' );
		$this->XML->EchoXML();
		return true;
	}
}
?>