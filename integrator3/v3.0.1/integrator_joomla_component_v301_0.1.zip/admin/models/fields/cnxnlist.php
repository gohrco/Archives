<?php

defined('JPATH_BASE') or die;

jimport('joomla.html.html');
jimport('joomla.form.formfield');
jimport('joomla.form.helper');

include_once( JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_integrator' . DS . 'class.api.php' );

if(! class_exists( 'IntElementBase' ) )
{
	// Create a Joomla 1.6 compatible base first
	if( version_compare( JVERSION,'1.6.0', 'ge' ) )
	{
		class IntElementBase extends JFormFieldList {
			public function getInput() {
				return parent::getInput();
			}
		}
	}
	// If not 1.6 then create a Joomla 1.5 base first
	else {
		class IntElementBase extends JElement {}
	}
}


class IntElement extends IntElementBase
{
	var $_name = 'CnxnList';
	
	
	public function fetchElement( $name, $value, &$node, $control_name )
	{
		$options	= $this->getOptions();
		$class		= ( $node->attributes('class') ? 'class="'.$node->attributes('class').'"' : 'class="inputbox"' );
		$class		.= ' onChange="updatepages(this.options[this.selectedIndex].value)"';
		
		$pagetxt	= $this->getCnxnpages();
		$selpage	= $this->_parent->get( 'page' );
		
		$javascript	= $this->_buildJavascript( $pagetxt, $selpage );
		
		return $javascript . JHtml::_('select.genericlist',  $options, ''.$control_name.'['.$name.']', $class, 'value', 'text', $value, $control_name.$name);
	}
	
	
	public function getInput()
	{
		$selpage	= $this->form->getValue( 'page', 'params', 0 );
		$pagetxt	= $this->getCnxnpages();
		$javascript	= $this->_buildJavascript( $pagetxt, $selpage );
		
		return $javascript . parent::getInput();
	}
	
	
	protected function getOptions()
	{
		$options = array();
		
		$api		= & IntApi :: getInstance();
		$cnxns		=   $api->get_wrapped_cnxns();
		$options[]	=   (object) array( 'value' => '', 'text' => '- Select a Connection -');
		
		if ( $cnxns === false ) return $options;
		
		foreach ( $cnxns as $cnxn )
		{
			$options[]	= (object) array( 'value' => $cnxn['id'], 'text' => $cnxn['name'] );
		}
		
		return $options;
	}
	
	
	protected function getCnxnpages()
	{
		static $pages	= null;
		
		if ( $pages == null ) {
			$api	= & IntApi :: getInstance();
			$items	=   $api->get_allcnxn_pages();
			
			if ( $items === false ) return null;
			
			foreach ( $items as $item ) {
				$txt	= array();
				asort( $item['pages'] );
				foreach( $item['pages'] as $val => $page ) {
					$txt[]	= $page . '|' . $val;
				}
				$pages .= 'pages[' . $item['cnxn_id'] . '] = ["' . implode( '", "', $txt ) . '"]
';
			}
			
		}
		return $pages;
	}
	
	
	private function _buildJavascript( $pagetxt, $selpage = null )
	{
		
		$javascript = <<< JSCRIPT
<script type="text/javascript">
var cnxnlist = document.getElementById( 'params_a' );

var pages = new Array()
pages[0] = ["- Select A Page -|"]
{$pagetxt}

function updatepages( selectedpagegroup, selectedpage )
{
JSCRIPT;

		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$javascript .= "
	var pagelist = document.getElementById('jform_params_page');";
		}
		else {
			$javascript .= "
	var pagelist = document.getElementById('paramspage');";
		}
		
		$javascript .= <<< JSCRIPT
	pagelist.options.length=0
	
	for ( i=0; i < pages[selectedpagegroup].length; i++ ) {
		var value = pages[selectedpagegroup][i].split("|")[1]
		
		if ( value == selectedpage ) {
			pagelist.options[pagelist.options.length] = new Option( pages[selectedpagegroup][i].split("|")[0], value, true )
		}
		else { 
			pagelist.options[pagelist.options.length] = new Option( pages[selectedpagegroup][i].split("|")[0], value )
		}
	}
}

window.addEvent('domready', function() {
JSCRIPT;

		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$javascript .= "
	var tmp = document.getElementById( 'jform_params__a' );";
			}
			else {
				$javascript .= "
	var tmp = document.getElementById( 'params_a' );";
			}
			
			$javascript .= <<< JSCRIPT
	updatepages( tmp.options[tmp.selectedIndex].value, '$selpage' );
});
</script>
JSCRIPT;

		return $javascript;
	}
}

if ( version_compare( JVERSION,'1.6.0','ge' ) ) {
	class JFormFieldCnxnList extends IntElement {}
}
else {
	class JElementCnxnList extends IntElement {}                
}