<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.0 ( $Id: register_lang.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the admin controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * REGISTRATION FORM
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['btn.register']				= "Register";
		$lang['title.register']				= "Integrated Registration";
		
		$lang['firstname']		= 'First Name';
		$lang['lastname']		= 'Last Name';
		$lang['username']		= 'Username';
		$lang['email']			= 'Email Address';
		$lang['password']		= 'Password';
		$lang['password2']		= 'Confirm Password';
		$lang['address1']		= 'Address';
		$lang['address2']		= 'Address 2';
		$lang['city']			= 'City';
		$lang['state']			= 'State';
		$lang['postal']			= 'Postal Code';
		$lang['country']		= 'Country';
		$lang['phone']			= 'Phone Number';
		$lang['companyname']	= 'Company Name';
		
		$lang['desc.firstname']		= 'Enter your first name';
		$lang['desc.lastname']		= 'Enter your last name';
		$lang['desc.username']		= 'Enter a username to register on our site with';
		$lang['desc.email']			= 'Enter your email address';
		$lang['desc.password']		= 'Enter the password you want to use on our site';
		$lang['desc.password2']		= 'Please re-enter the password to be sure you typed it correctly.';
		$lang['desc.address1']		= 'Enter your street address';
		$lang['desc.address2']		= '(optional)';
		$lang['desc.city']			= 'Enter your city';
		$lang['desc.state']			= 'Enter your state';
		$lang['desc.postal']		= 'Enter your postal code';
		$lang['desc.country']		= 'Enter your country name or country code';
		$lang['desc.phone']			= 'Enter your phone number';
		$lang['desc.companyname']	= 'Enter your company name if you have one';
		
		$lang['pwtxtstrong']		= "Strong";
		$lang['pwtxtmod']			= "Moderate";
		$lang['pwtxtweak']			= "Weak";
		
/**
 * **********************************************************************
 * RESULT MESSAGES
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['msg.error.credsorigin']		= "Originating Connection Information missing: Unable to proceed";
		$lang['msg.error.returnurl']		= "There was no way to determine where to send you once you had completed the login procedure.  Please contact the administrators of this site to let them know of the issue you encountered.";
		
		$lang['msg.ajax.email.good']		= 'Email address is okay!';
		$lang['msg.ajax.email.error.free']	= 'Our system does not permit email addresses from that domain. Please enter another email address.';
		$lang['msg.ajax.email.error.check']	= 'That email address is already in use on our system. Please enter another email address.';
		
		$lang['msg.ajax.password.good']			= 'Password checks out!';
		$lang['msg.ajax.password.error.check']	= 'That password is insufficient for our system.';
		
		$lang['msg.ajax.username.good']			= 'Your username will be fine!';
		$lang['msg.ajax.username.error.check']	= 'That username is already in use by another user. Please enter another username.';