<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.0 ( $Id: api_lang.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the admin controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * GENERAL API MSGS
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['ping']							= "pong";
		
		$lang['msg.success.valid']				= "true";
		$lang['msg.error.invalid']				= "false";
		
		$lang['msg.error.disabled']				= "The Integrator is disabled - unable to make a connection";
		$lang['msg.error.userdisabled']			= "User integration has been disabled globally in the Integrator!";
		$lang['msg.error.cnxndisabled']			= "User integration on this connection is disabled in the Integrator!";
		$lang['msg.error.credsincorrect']		= "The API username or password you supplied are incorrect";
		$lang['msg.error.credsmissing']			= "The API username, password or secret key are missing";
		$lang['msg.error.invaliddata']			= "No originating connection id passed along";
		$lang['msg.error.formvalidation']		= 'The data passed did not validate - check your configuration.';
		$lang['msg.error.secrethashinvalid']	= "There is a problem with the secret / hash generated code.";
		
		$lang['msg.error.getroute.cnxnlib']		= "Unable to retrieve the requested route.";
		
		$lang['api.findapicookie.nocookie']		= 'Unable to find the cookie for the api in the header stack.';
		$lang['api.grabcookies.noread']			= 'Unable to read the API cookie file.';
		$lang['api.grabcookies.noopen']			= 'API cookie file exists but cant be opened.';
		$lang['api.grabcookies.empty']			= 'The API cookie file is empty for this connection.';
		$lang['api.writecookies.error']			= 'There was a problem writing to the temporary directory.';
		
		
/**
 * **********************************************************************
 * INTEGRATOR 3 PAGES - called from get_pages()
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['api.registration']				= 'Integrated Registration Page';