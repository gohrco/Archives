<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.0 ( $Id: login_lang.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the admin controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * MESSAGES
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['msg.error.credsorigin']		= "Originating Connection Information missing: Unable to proceed";
		$lang['msg.error.returnurl']		= "There was no way to determine where to send you once you had completed the login procedure.  Please contact the administrators of this site to let them know of the issue you encountered.";
		
		$lang['title.login']				= "Logging In";
		$lang['msg.redirectingnow']			= "Logging In...";