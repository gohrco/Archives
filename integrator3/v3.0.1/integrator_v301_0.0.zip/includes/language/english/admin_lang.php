<?php 
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.0 ( $Id: admin_lang.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the admin controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


/**
 * **********************************************************************
 * DASHBOARD
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['admin.index']		= "Integrator Dashboard";
		$lang['admin.index.desc']	= "View the status of your application here.";
		
		
/**
 * **********************************************************************
 * COMPLETED INSTALL / UPGRADE
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['msg.success.installcomplete']	= 'Installation complete - install folder deleted';
		$lang['msg.success.upgradecomplete']	= 'Upgrade complete - install folder deleted';
		
		$lang['msg.error.installcomplete']		= 'Installation complete - please delete the `%s` folder';
		$lang['msg.error.upgradecomplete']		= 'Upgrade complete - please delete the `%s` folder';
		
		$lang['msg.error.installdir']			= 'You should remove the `%s` folder!';
		$lang['msg.error.installconfignew']		= 'You should remove the `%s` file!';
		
		
/**
 * **********************************************************************
 * FORGOT PASSWORD
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['admin.forgot_password']		= 'Forgot Your Password?';
		$lang['admin.forgot_password.desc']	= 'Enter the email address associated with your account and a new password will be sent to you.';
		
		$lang['label.email']				= 'Email Address';
		$lang['desc.email']					= 'The email address associated with your account.';
		
		$lang['btn.sendreminder']			= 'Send Reminder';
		
		$lang['msg.success.forgotpwsent']	= 'Password reset email sent';
		$lang['msg.error.forgotpwsent']		= 'Unable to reset password';
		
		
/**
 * **********************************************************************
 * RESET PASSWORD
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['msg.success.passwordreset']	= 'Password successfully reset';
		$lang['msg.error.passwordreset']	= 'Unable to reset password';
		
		
/**
 * **********************************************************************
 * LOGIN FORM
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['admin.login']		= 'Log in';
		
		$lang['msg.success.login']	= "Successfully Logged In";
		$lang['msg.error.login']	= "Login Incorrect";
		
		$lang['label.username']		= 'Username';
		$lang['label.password']		= 'Password';
		$lang['label.remember']		= 'Remember Me';
		
		$lang['btn.login']			= 'Log In';
		
		
/**
 * **********************************************************************
 * BOXES:  STEP BY STEP BOX
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['stepbystep.title']	= 'Step by Step Setup';
		
		$lang['stepbystep.num.1']	= "1";
		$lang['stepbystep.num.2']	= "2";
		$lang['stepbystep.num.3']	= "3";
		$lang['stepbystep.num.4']	= "4";
		$lang['stepbystep.num.5']	= "5";
		$lang['stepbystep.num.6']	= "6";
		$lang['stepbystep.num.7']	= "7";
		
		$lang['stepbystep.title.1']	= "Configure Global Settings";
		$lang['stepbystep.title.2']	= "Setup your Integrator API Account";
		$lang['stepbystep.title.3']	= "Create Your First Connection";
		$lang['stepbystep.title.4']	= "Create Your Second Connection";
		$lang['stepbystep.title.5']	= "Map Your Pages";
		$lang['stepbystep.title.6']	= "Map Your Languages";
		$lang['stepbystep.title.7']	= "Test Your Application";
		
		$lang['stepbystep.desc.1']	= "The first step is to configure your settings in the %s area.";
		$lang['stepbystep.desc.2']	= "Before adding connections, you will need to setup an %s in this application for your other applications to use to connect with.";
		$lang['stepbystep.desc.3']	= "Create your first connection by installing the necessary plugins for that application and then %s here.";
		$lang['stepbystep.desc.4']	= "Install the necessary plugins for your second connection and then %s here.";
		$lang['stepbystep.desc.5']	= "Now that you have your first two connections setup, and you have all green lights on the dashboard, you can proceed to %s.";
		$lang['stepbystep.desc.6']	= "If you are using multi-lingual applications, you will want to %s as well.";
		$lang['stepbystep.desc.7']	= "With the basic setup complete, proceed to test your applications by logging in and logging out, and checking your visual rendering.";
		
		$lang['stepbystep.lang.1']	= "Global Settings";
		$lang['stepbystep.lang.2']	= "API Account";
		$lang['stepbystep.lang.3']	= "add that connection";
		$lang['stepbystep.lang.4']	= "add that connection";
		$lang['stepbystep.lang.5']	= "mapping pages";
		$lang['stepbystep.lang.6']	= "map your languages";
		// No need for #7 link
		
		
/**
 * **********************************************************************
 * BOXES:  USER LOG BOX
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['userlog.title']		= "Recent Log Activity";
		
		
/**
 * **********************************************************************
 * BOXES:  RSS FEED BOX
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['rssfeed.title']		= "Latest News and Updates";
		
		
/**
 * **********************************************************************
 * BOXES:  CONNECTION STATUS BOX
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['cbox.title']			= "Connection Statuses";
		
		$lang['cbox.hdr.cnxn']		= "Connection";
		$lang['cbox.hdr.type']		= "Type";
		$lang['cbox.hdr.active']	= "Active";
		$lang['cbox.hdr.user']		= "User";
		$lang['cbox.hdr.visual']	= "Visual";
		$lang['cbox.hdr.api']		= "API";
		
		
/**
 * **********************************************************************
 * BOXES:  UPDATE BOX
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['update.title']		= "Integrator Version";
		
		$lang['update.okay']		= "You are running the most recent version of the Integrator, no need to update.";
		$lang['update.needed']		= "Version %s is available for the Integrator.  Please visit %s to download the latest version.";
		
		
