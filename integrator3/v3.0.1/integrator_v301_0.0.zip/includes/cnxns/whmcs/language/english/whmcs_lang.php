<?php
/*
|--------------------------------------------------------------------------
| Language Translations for the Connections Edit page
|--------------------------------------------------------------------------
| version 3.0.0
|--------------------------------------------------------------------------
*/
$lang['whmcs_globals.accesskey']				= "Access Key";

$lang['whmcs_users.ignorepwstrengthapi']		= 'Ignore API Password Strength';
$lang['whmcs_users.ignorepwstrengthapi.desc']	= 'Enabling this setting allows WHMCS to test your updated or new password against the set password strength in WHMCS to maintain a level of strength across your applications.  This only affects password checks performed through the API from another connection.';

$lang['whmcs_users.defaultaddress']				= "Default Address";
$lang['whmcs_users.defaultaddress.desc']		= "When creating a new user in WHMCS, you must supply this field.  If the connection creating the user doesn't supply the field, the Integrator will use this setting as a default.";

$lang['whmcs_users.defaultcity']				= "Default City";
$lang['whmcs_users.defaultcity.desc']			= $lang['whmcs_users.defaultaddress.desc'];

$lang['whmcs_users.defaultcountry']				= "Default Country";
$lang['whmcs_users.defaultcountry.desc']		= $lang['whmcs_users.defaultaddress.desc'];

$lang['whmcs_users.defaultphone']				= "Default Phone";
$lang['whmcs_users.defaultphone.desc']			= $lang['whmcs_users.defaultaddress.desc'];

$lang['whmcs_users.defaultpostal']				= "Default Postal Code";
$lang['whmcs_users.defaultpostal.desc']			= $lang['whmcs_users.defaultaddress.desc'];

$lang['whmcs_users.defaultstate']				= "Default State";
$lang['whmcs_users.defaultstate.desc']			= $lang['whmcs_users.defaultaddress.desc'];

$lang['whmcs_users.defaultlastname']			= "Default Last Name";
$lang['whmcs_users.defaultlastname.desc']		= $lang['whmcs_users.defaultaddress.desc'];

/*
|--------------------------------------------------------------------------
| Language Translations for User Management / Modify
|--------------------------------------------------------------------------
| version 3.0.0
|--------------------------------------------------------------------------
*/

$lang['whmcs_user.label']				= "Email Address";
$lang['whmcs_user.desc']				= "Type in the current email address for the user you are searching for.";

$lang['whmcs_userinfo.email']			= "Email Address";
$lang['whmcs_userinfo.email.desc']		= 'The email address is required by WHMCS and is the single identifier across all connections.  Changing this may prevent the user from logging in across all your applications.';

$lang['whmcs_userinfo.firstname']		= "First Name";
$lang['whmcs_userinfo.firstname.desc']	= '(required)';

$lang['whmcs_userinfo.lastname']			= "Last Name";
$lang['whmcs_userinfo.lastname.desc']		= '(required)';

$lang['whmcs_userinfo.companyname']			= "Company Name";
$lang['whmcs_userinfo.companyname.desc']	= ' ';