<?php //00922
/**
 * ---------------------------------------------------------------------
 * Integrator v3.0
 * ---------------------------------------------------------------------
 * 2009 - 2012 Go Higher Information Services.  All rights reserved.
 * 2012 April 20
 * version 3.0.1
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPvqBv7K+pDnwqz9nLZOchLBXFVANjbaPZzc7J1MI41QcQ0j5kMjy5slGAf6cZVl/UCVrvdwA
/mckDdUGhnPcv8gOk91j3Ta4dy6sZtCLPJvEija4RzOtTQf36CD/yl+r7+3NaeINR1cMVC93T4Os
jxrZHPlpGFa9rHwIWPuRt61Y2KPPpS+QeSAnN/VqyFRcNumkKU6E4fwby1bgjJHYaSVzcIHmq53f
VEvMu7pNH3QwKuVQ76mec9wzCRv2Kj6kEvD0cNKmVWVWPjSW/k2lY7824DRTJA2/2h+vqilfQgVz
uwZtti1n2fgXnPAlYtyO9MyRjZX3WYcm9ov62iXRLNvKU587ncyC6dvWA1PyyrqVpvCSCyx8x+cq
fFk0kcAvR3ufanEPfRaIUt7hqnxnzMmD6BN8XhbqQhQdckx5RhF1b5EcMSLxYQZTJm6jC7x+g3I7
WJan+5g7egE5JMVx4rG+y0tn/4xkTKpAAA+yZehXmI9k9YhXH5iRXkRvnWP71Ojs5qptB9EJhII5
yxq3y/d/V31YERnlu8eG5Z+eOUQjJwXdVn3CSK/B8+71715xHCDz2uj5CT9qTOUSExhZrIdX0en7
Pm0lrHYFtG59rN2DleRyCWqOo6Qrfz8/5IfHqwfkWUCLXbsVkltjNKKNlT71cf/m5we2DKSVvs76
Ok5mRr8D6ENxgyp1q4Og25ATPkpZFYKbg8lh50KoX8qWj7RqSQNIZNHt/Lf4PPJ54aIQQG/fnFAS
2MYhCBJRIhnXtCaGCBnSo/1FmY3NRefF0LXe+geT1HUkNFBTXLGpNKw9Kv8Bpu6Vl9/u/Ca0pHPc
/EmqAe35oo97a682H6K7T/irKVtganWITXe6buQ7b3+gNcvExUSZ6/Qm0630M6l+UfVH1ZuedrBK
GgfUGk0AkuXI8D4tXn0V2msLag21d3FmvZFE0otOBBg+jnOCgPqxJ+x2ZvcF5GHosBrLhnNez772
MZc0gAYmMIH3NZsByO4lGztZeOSAZsUjJzSZlAKWLhrljGy5cDjRdHSn8Hz2R46UX52k8NVMh4zu
iPVVcwhBRXeRHoGVwiCR8IboFGN/lPAIHCU2/Kd4TW88sszdJ32lKtLkVqq65BydIrMvQvwJtzT5
Q8xgMItgGABOOZq+0B5AguYPPXn+53lZejcHJxPSFwuoZZ/NvJ9ihlC913DDdixGgGUyb32p/sHN
E8jmtqWgORsgHF5/MGQjTmGYh2JU7sb4Ez9g5RBJva5PvX/gd2XVXGKfJJ1Gl97YlTvut5EwuuoV
uAu3X0B1pTw4fwjaeSGa5CFlrQhqqYvGk2+cOt/Mfu5KVn+dSQw4MCov6aYue7j1Op9gwsxCcyIF
96jNWpgnasyidwzr2B9P3gNRy3VMbR1Af8KOSvWm9WiptMnZImt/5oSeKxyzuZrIwP1ARIC7sFtQ
LIxWByDLjZfQApYhxA4lQcd6rb4X2RY9GyxTQd+nYS8VIyL9Czx04X1cbG/QhLMLFvzi3Xoim+7p
Z4Tbx+XZcnfLAezhAA6tmGIEkvCqXkOjVudVvYDmBjw+4DqZMX/yQPWTKWskYMuHQ9Zbqz/HhtLE
jWTXHwf7k/HAABV0LlqJR+WEYb0FCLk2XFMwFwwGhj9Hzye3E3s+VNU7ZDJN3YGiyZcVLalzur4V
pBhDMI2BhE/pw6t89sXD/uhwObMRFIHqc9egnUHmbDw46cPebesHlI4G4dDSRAea9dyh4gP9LAx7
8v91N/3KXk2PdjmKDet8LeelrZhHVVZvbIg5Z5l96zOwyhjJRXVuY4QbFpsO4Zq00cAe0ydR1S8K
iLgZ9OWzvfggqu/rdKwLqfw7iWPFwVUrqXXQh+YwSqJW5KBirtHd492WKNSjYGV4W4agh0teCzTV
yfSvOH1rmw2rFybBTHBbJmnRGwRgudue3zolKIYgkrnkJo083t4ZmKP7TYm/idbloCLFELFjtnlq
Eb4Zes4hjFrNCxwaWkyVGEeKfrGZSMAKgkR1Bm9mmkPap7ViLdBh1MXdGWewLPbwonYRuO0zKTIK
3BXZxQIxBhMyFra+yH6w5vsb5Keg6E9ep7xdygp8YLWKBWc/XI/Ly3N4iV8e8Oe+O4kb44SpKxuP
2KYwR8iX2T9qEG4AhZYhreUtmNyz2yZTtKPlJggJt9sK4M58h4DhMNEqxV1DgXHz7HhgtSKQ5rQF
SA1NBbY2U3q06Kw0TMWxDOtvN0pO/o9uQAN8q8KqsC5TLuI+hCmHM7KM+82WfQuINfAT6lN/PKFs
/QNCt/nDhFIajwF4bw6YirQ8zd8lBrtfdjoHsuWAeA0v7GuVDAk1PAJMJS8dQwcdMQJgu//PpePd
7d0PhL7NBmPgP2sIqamCv/KbHMNu9NId0kfSV/z6GgYRsZWC7X3rrmzjkllVAIhdn3E0Gu3mZgsT
FtYEw4brtCJtJOs2/8ExpTfrSbE8XfPCZph7iOdK5M8f7AoDz9tCvX/gkxWGPBicTHDlUis95U+4
h1gfzp8RMvXCJ7EfPNL4yAQcSNmugfhZilLzQsYdaymovyL+gnoMyCuSYEp3Cj584hW68Ob32FIP
LUPdU4iC7qAd7xmRBjIQhMgp+taLms5ZO5jMiRdDY5472/m41JeO6bIMl3YHribqez3L7MqPRl6E
i6dNYHNPihxYHmwK3AabHL6aa4YdwHM/kL3sVihJp04mgzluzwIOkFW2SEhnk2rTafxW+i16Rlvc
/woclHhf5yLkY+2ZyJ5JU/4OYsHRQ+P1J8J50/C8wXW5cjviz6J4p5IZGclOo8A8xRphZuXXJDrF
/DDTJs3hCSfWwr0GaVzMJc56QaDAHt8qpj8sPc6bwKFcvCLlEll1tSzI9jOIieUaLuYk1sqoRXdz
+7WR6QxCKMS9biy4PHK4EZGiMDkfW1ewy7yUJC6h/Vzh+ouPHj1AR7uG+/72x1hcCoR6vGXqbFo4
cDQkWYXZcV6c/hlPum1xDtYdM3ex2X/uwwoLixrtLwmA0Cpnf2vqmM/WjsmhX00trdVQNX7tBnUa
DycTeabQQSFiBc6dv6n9lfCFrndefMsncySXZX3/HLFF1qEXY+iz8oxC3iXznVSMmldObn/6LaqA
VUxpNqOFOXbG4v1Dt7qi24iflGa2spZpLSgl27r0wnVx8VdFULC2yHexq0K5oNbVOfjYmogqZAYn
yZc2q0kZPEDjEqO6YNCRFNQE89ylPbpUyXmOfJzARm815wqKth7eeJttdKXeevns7TOlu1juZub0
IPJWrp4ka7JiDJ9gpQEVTTp7rTsFFwAIbvcvb4VHQXvp/B25+Ydjn02mTZ2ZqI70P7SC8UTPZEq5
fot0Px9rTdMQA3fmA6LfGuaGdVLmm8LnXx035yv2cb4hkHF+zVPdaU3VudL16XqPbz1LdTJ+hMU9
E4+89+C8OFJ9iR1l+seHv0nGHCc4IGdtG/L+C4wyXn2mNhxchHLI1jZqG7T4tnUTs6T5GLzNjgti
SgsS/wd3MlsWUo1u9MKtP5A0EZIfCdwMc1CchpH7W7oQ6t2qOPd2r4l6beR6WfAHfj4jfdCLYWqS
8GgsfUojKmfucaMqjtu5IGubtlyG+iuQPfOk0QhfaABxEkuoVHK7HElR+JCe8IlFQhB6Yio91cpF
+83+/vfXLo8Nhkg7xR5Ch849cjan+ucAPqCQoB0kfzKbLP8JZfK8QVUHWB9NFQM1JOioeF+wQ6vV
leP6n+KuVPqDwuHlytc2+F70e3WQK6qsKCkm32JN0nL430PcxpTtZiAxHRTyEOGrH/AKZF7bxoes
17n6NxtduVdIkndNFXi08hOSl5uWyWQhb1ezmf144UCGt9ZBdslwCp/ta2hsdHc66b+9+dxhyESJ
7MLBAnIaE5/I8zxWnwqC3CYxBhUEEdmSFrY7NRd8UypisgU5/li6bf3bo0u49BZKAbGh9WyM7XBw
pF4NJIfo1osslqqS7KZC14QY9TztmNv6P4lYN3klpvgj4VWaRSrqp98WQOqOTvyJjc2gLNETVyx4
akd3w0Jz/uyucgrFqkJ+HZ11Qf2Qlo7br8OAMbUPwv0s6JOZmU5JxuKAvT090+hq4eq1CNqOpEHG
W/YnqmobWdrdps1kkCPiHRqMnJNiu0wLEJcnQrqJAx71D4Xuwuu1NlJ3ngWEEcbOQDszBiHTI9pC
tgqMKZ55BZNxIgl/LBqQy+CLzIy18nd3GWmVyA89tQfNlpQAvgAbwPL8qK8tMFV0fDIfw+HAePrb
U9S5ZZroYJZnZVSLK/6SGsMnexIPk8rgXs553szuuo1/ipFZxaSvEnffP4RyqaucPVKjJj5y9u6A
hltMzUF6YYm5K1ZWBgsVUUs3IzQKLGwwS2fUdlH4bieZ1sMV3llO//8dVHwYuwJcAqKVjRuObD2R
rLCwBsqbV2fOz1s5hl3nEZM8Nv8772tvk3FKb+tlsVFEcIVLZvapFVzskMOCCpvkVqZgoM3YM0D/
2n+wsIj2UlXejGR0KiqYATXC7XXZI93rkoq7NTfKGxmZ8V0PT+fUnqfgyrlSSFtshSEQQG6q06Hy
ZHkexw0N1O0zyIN5nvS32g8vIATXETsmcx6ieYnpdOhfI6KCCBIJ6vxeXbGP4SzS6llfI4L/uf8N
Fld8vIPOIxEJTw+VBw1JKAw5WwXt5SNVc1hLX0tuywnT8451exAW6z+2P9IecvxC922SaAK7XzAQ
dJ8LB1Nkr+mqfep9I5UIIQare4m9gj7avbTZrgZKa+L/cmrG+Y6QK9EgpxM5Y5gQNjo5S3e1905x
Xr0F4HhxMcyrMgKQRYP8wC4i+y6LrgoOiIyR0ZflZjabPMSkUTGMItdk2UKnp7MaIHFSKYPi3wIO
pMsS7xRdNcRtfKLkCi04i5E+jgMzNJAKU3XGxLQaS7XhnvcC4dP8BJSTJifdui96w1I0M5yTPGJg
0Z0374Y5dwOgcgvMJ7VlNnUz1fQxciVZBKOpFolGm+hH8ywMVduAyBVc1p7z7D9VeflxKRqYoSHQ
XGk/GyusP3s1iMHuKeTxR6ok0FsPt4pO2tfjdix91+sM25D3BTe35xBl3Z7qba4nm42XWAMSOnEe
EtLsn/SSXOGj87F+2cU2ssoN4+VXiXSAtvpM0yhTp2cckPJMSHcOYgc9YOTWMsF/fuTFT9jUDDyx
+l8lvUZMuCssbdn2RJq3SrubPsQeiuHnk2vfAnJXmWr39rR44coUtSgmg7/opAH3CLx8j1n07MzS
LsEkFQz0NwAN8ZEGV7TSVsrWyYHPXMcko8tuZe92s/fZHffCwLKYTpN7iR5LG9fUuqqB5jB7zXU1
69HOXy0viILB7oXK+mQnTn+29cUjo6KYFi2ASYAGRZt6+fTE8wOhSY0UfVB/idQ3zXwFjI2+IQHk
YQ00ptnVXK8KdVQ5Zzk2dQ89dOknALgDYjYt0yA0zRSu3uxG9CEfTEKOFZ5Twu6WaoJKQkLg4FSi
NzUv8OEdlvvCoGrqZQTNtjig0aP7MmY/CRHyT6VYRkBk5vSLHFVVxdSBFiNd8j1kCa8TKKydARbE
Yop8+vRitorrBFdPFTDjOUN9CtUoENhNVj4spcc2nsZYWdSlk8fzxideJQZnnQitDWDo/+CTQ/8c
LZewL4CLi2yUJzClACvBS0pber+rqc98YsyCHCEojJ1J6oRBs70FSXup6oHBORh/L7OW6ExDLEca
NsOxheA+gix3bxHVGGP6/Amwc/+5297XbbMWQro5cc3SrQbn3JEq+lnvyVNncFqwR3F4Rw1NmtH1
U58k7S/7+6cKwgXc7IzRtbOqUPu77W+2QkPY5IPpoTjdfwmKkyuFZthndcJBNcYryhKejPAv6Q89
9QL+Vjq2wxlaMcnUML+Lry5ZJxH0sp59iYeH0BTzidiGjuX4D6zmEykvR0c0+C6fa6J9/9XVFgHS
cv5zXa67SgLez11l2mlpPZfiKd7lERztuzyC3nkQUeBnJiFuFP7+e78rP0ofgnCbMhrIcGJIL2tp
+jbsGRIbo0EIZUlwcqIuq4d8YojKIR7lhnb09PWqBm2spK2VTEHX35y8q36WX3twvXleT4QcpgpO
iSCv3cQ8epqJzowWuZtbzRolYPb+cW5apOw0yvqFQZLSQWu2/EOn4ry+5QCs2A7XGA5RhdKz3Ki6
ZRWLtJghFZP3tx2dH7xRlF7BN9VaodY0GpXyQ7uEokEtgs2DxRLkDXblAMoU4LkVXYMWNkFzicGQ
ReQJPQOSdag9ZEL8jZw5nhaX7pBzkO+fqjot4vgutxgeVdWeEAnqgfTHFbOiTNghEE4o/aC095lJ
hhi8wiWS3pLd0XZh98/JwVx71EjahQXHLqNazN74soBxdUAgMoXuBWqoTh5MPXKuY+RFCcj+/2uP
qGsg1opG9IXI55Y+kmlLjeGAoxuUo6ZwfLb9a1RB/QSq1NdhcryeK19eySSR12QXyoxciqMe9E1B
hQQcFNKDB8mnmDgfXGXr6qN7UXe2p21apG2zunrNFWGYVICDl69yV/x1sw524KZL6HFSjRxE1aMv
yH3oLGB19DIX2hGrt/xTNKw43eujgWN1srY9OB6lHXl5QYQVC2Wu4OaVT2TH985qw7iOyWNCGNMv
fdn5peN9mUPXWfbBo/ZZR3aHtplzVQ+IKedz9qPNzP8eG8OC0kNfdSyJ7bRMbcl1iq1I7yYrGeua
zc6LgUXGC82i07GRsHsNusZ9LtqgJcJx3V32IZdz74h09GPA/cs3KJAcgvd0+ZFEROHbUv1ahCjX
F+HEPIcgLyAqUOpfsUASBGS9B9N+blhtqCgXhTX4LkwrjvF0DDj+NXkmH/RF6lQnleIWKYe2EsZr
61sAscQumdbO8fxFH+6mQC6DTXUKiplEZn13S2pkN4dTxQsKHPyH5Vm9/9iCcYVaiMrPz/l2zC15
hel6W97/GEce8LwFQlHxqFTUl867+iKk8wvifBA8N+9KI7lIrvwStO1XvIMDOq/P/OiW4qjeQcj6
G43wxeg6+OVdzjiOwBSZo+MqDge5k49cbi0tMYiJtsKC10/fA7iDVjhY3LtalE2aPH4Pp7GayWTM
1rq3p9+yDVfEuNYzyic06dz14/YTQuP8x2Q1g4btuRYnHkWlpw8chfXTU0TuV45f/ufI1uHtr0Df
NzqebFGWbj3dXq7uKda/WRGlB89rrV8tGcVBYgk0VKINol9vRrnJnVvPNBpqgCc1m0FJ0OUpOIS0
EuqUNsvj5bIMVYZ73nN/JtUsS9M/VZZiolUVutdiVTsEWbwi72aURE2oB/C6IWT3+SS5vzVYlK/j
s/s4/M0LjvU752+1Oz9QXvAcCFiDZn1TnWU41+02TEHGI44RtioEMAsquoFR4gcJP85nD1Z7tXU8
HKJVVJhs+V5HA8MLIAyl8BPt+X1MWZ70u9XD2oHK8hEYxDSOjLzu39+o/XkgRU2V0Og4CxopSfj/
IsRwMkLahnvqfs10WcxCB1CQMq3wt96dUyEmHX/gXtNENg1/0r0ddkSG1dLjsWDbN3+rFl5v8aw8
CAP3rOSpQlPqpN12qs7Z6L4GFQjWUCvrJkNYTpubz+8rEsovkErnGbCGAb/AxvWbqaD4nftf3WwO
je/smJ0cQxK++rzJwnL/cXeFFpOJwA42T7JH/C7YP8g9vCJW1wWXHI1mKMHVbcGqVHgJgYLI5xsp
cSIQdO5YlTQVYpGCJaRfCquARX0+mFNlAehQPG/0Y/NWhuCz1x1HANsNKIo58sa3Qm6gYVGHYqsH
uAIxss4UcX1+yQxP5aBxydJxKoAaTiN59cyD3cU+yC5tqB5enZvaB6c1o29xVOhfb2luwVEWZTAK
7+j3d5vwRTZsfRCWwpL8Jfz7gRQ1GVyn3fMdsJI+yaEsGa10VkGaUQuDHI1ET/zg+/9x31+IKqUB
q5YTulIyRFCCrDhI9267yW5mYlK/KJ4n/6ZdvxJtghabiiPKU7G6o3lJovSdIEOvGQpITGRSk1RD
3So2SNdz4i/Z0Ed12j9/+0vgU1mo5mGFtQ5KqH2bVb4H8B7MlprWCRdXv6TQ0VstgFE5IfO2hDaD
q6LGz3zYdaRTSKVF1YOLeF7ZFUPLrhUYxDpADNPXCZanfin6dNvhZTS7uG00OTq+PNRpFhUUY7aB
rW2pamquJu8QspV888WbQoK3FImKTfbSzl0ozsSigG5O6obt+Y+Trh8qP0p8GTcie2XroyiwXUt6
3neGvbdBmdpFoN3ukWd1BIS0QcEYuNX0xhMzOkp09LujZzKXFK8V9j4WNwrr/c/RGf5lDG808bJ/
r4Y5YK+87w02PyGU/wVRz7HMqFJ506POOOI3JrqFg2xqkrzDTG5UAGbyOLcJWTg97Q+XWe6yoN9N
TVbD/Q32fKmbLJWmZo6PybtYCq5hzR/WdfEluisQYPzd7Rb62no+bvZUqc9JY2AuAVkB88OGE98p
v+akI0Wen5nUp4cnYEhWrBUCtYxCRdIjIKl1PPSLReC4pm1rugU3A1Di1X+V1HOFumTwSgY1Z2Dh
GaZDbBpp7EXlv4cd3qXF3+XXPrHd/6ktKjOHQGPc9l/K4a/N492asbV/FgbvM2R09EQGJV5HcJ7K
Ny+C0S4qkoSomQdPayjT3ZWKu2k/v5W+JPoJJXEkMpwEbA3vqXRo1qAVBPX+ph39ZcCF6uXlBb9a
4MkGsaFxWd0BNJqhm7W3ebQuJHkSEuzZTf7dNTI7EqQiy8OKo+NvwfbUz/FRpkQX3eJuZDd6NoE7
VL0A4nWRfbx1WkensZ+ZH+WbrgAdOIPCs0EQRaqgkEpQN5DrWL0LgXCn7wKat73MWfBBoKU81TaP
85ZZOZjQUtoVlSwAEcXDGPTUz02PDDqD8t/aU3af82emhl6V2x6RyvIKw8uiZpCYHsJ2tuSQAdGF
bXi5FOGa1cYb/nyJ8ODbnS1gg8weC11ajV5XJwFXjesK7Cz8RnOnhHAB4kBdecvE/URuB9BpTcUd
DOMINa0/5X4d/pGFivwMiv3V3+sBffQFhlZeBZhjsD3O+atovMVJfhZOyCwno28uLPDo93HvZy0G
IG+iJAQy8yR/+emOUjJBqUpcQBPURBMMbwqwGUHqLiTFFI0lGYe3x9XO+TM+q8gElS9xTtryhBpS
6sAhVWfBIu2C3rpi4WHLXJZOwh4/uLq6XLf1+naqYue6bYXg28vs3fbt5Hfa6m9pjOKtxXXOcN4W
C0LzuSWuRESY9glaRivz9iCYrNBE89rYixLDnHtxUtlqTzcWimHP7CrUU/u9bkljLlgV64+ki9fa
PBUmDPRzf8pvfEseBTos/N9grtKm8gxskz+AC297E4kCBoqe9pgECuENq6isZ9W+K3fbZNYIt1Gv
GysJ/dAT6KxTpEnUoAE8XAXjv9EATbT7ZwybiuSDbqS8xlKkbSkDhaCfPi8YHu8GCdt9AVRYd9BE
1d1GIYGh69O5ovSAtnO4agErb74IwycZOOdCfNwvfOiCVocB6YE+cFWPWCbJ0xmkIZv8BwT9IDZW
jHAi8gvA3QHS09eSO67See3H70FBub6aE9WAqqNfHAz9Artw7fxVz4DOVjWi05740ewwWkjNrZ5E
1kfwkViKvhk/oQeEd+hEvgFPeIlXDn3mQdwVkQ1+uRQS2eufTHrpn8NcQ7wyX3Ds1u3z9Wkbh/U2
aDW=