<div id="side-lic">

<?php if (! $guest ): ?>

	<h4><?php echo lang( 'side.license' ); ?></h4>
	<span>
	<?php echo $licensekey['key']; ?><br/>
	<?php echo anchor( 'license/index', lang( 'button.license.manage' ) ); ?>
	</span>
	
	<?php if ( $license->is_valid ) : ?>
	
	<h5><?php echo lang( 'side.registeredto' ); ?></h5>
	<span>
	<?php echo $license->name; ?><br/>
	<?php echo $license->company; ?><br/>
	<?php echo sprintf( lang( 'side.registeredon' ), $license->registered ); ?><br/>
	<?php if ( $license->duedate != '0000-00-00' ) : ?><?php echo sprintf( lang( 'side.licedue' ), $license->duedate ); ?><br/><?php endif; ?>
	</span>
	
	<?php else: ?>
	
	<h5><?php echo lang( 'side.licerror' ); ?></h5>
	<span>
	<?php echo $license->error; ?>
	</span>
	
	<?php endif; ?>
	
	<span>version <?php echo $version; ?></span>
	
<?php endif; ?>

</div>
