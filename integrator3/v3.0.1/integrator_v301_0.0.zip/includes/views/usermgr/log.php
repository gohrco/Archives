<table cellspacing="10" cellpadding="0">
	<thead>
		<tr>
			<th class="span-2 txtctr"><?php echo lang( 'hdr.task' ); ?></th>
			<th class="span-3 txtctr"><?php echo lang( 'hdr.user' ); ?></th>
			<th class="span-3 txtctr"><?php echo lang( 'hdr.ipaddress' ); ?></th>
			<th class="span-11 last"><?php echo lang( 'hdr.date' ); ?></th>
		</tr>
	</thead>
	<tbody>
		<?php foreach( $logs as $log ) : ?>
		<tr>
			<td class="span-2 txtctr"><?php echo $log->task; ?></td>
			<td class="span-3 txtctr<?php echo ( $log->email == 'not found' ? ' quiet' : '' ); ?>"><?php echo $log->email; ?></td>
			<td class="span-3 txtctr"><?php echo $log->ip; ?></td>
			<td class="span-10 last"><?php echo date( "d / m / Y  H:i T", $log->timestamp ); ?></td>
		</tr>
		<tr>
			<td colspan="2" >&nbsp;</td>
			<td colspan="2" style="padding-bottom: 1.0em; ">
				<?php foreach( $log->data as $data ): ?>
				<div class="quiet" style="border-bottom: 1px solid #dddddd; "><?php echo $data; ?></div>
				<?php endforeach; ?>
			</td>
		</tr>
		<?php endforeach; ?>
	</tbody>
	<tfoot>
		<tr>
			<td colspan="4">
				<?php echo $page; ?>
			</td>
		</tr>
	</tfoot>
</table>