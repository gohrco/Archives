<?php if (! is_null( $log ) ): ?>

<div class="boxer">
	
	<h2>
	
	<?php echo lang( 'userlog.title' ); ?>
	
	<?php echo ( is_null( $log ) ? anchor( 'admin/turn_on/userlog', image( 'icon16-up.png' ), 'class="btn"' ) : anchor( 'admin/turn_off/userlog', image( 'icon16-down.png' ), 'class="btn"' ) ); ?>
	
	</h2>
	
	<table width="100%">
		
		<?php foreach ( $log as $item ) : ?>
			<tr>
				<td>
					<?php echo ( $item->email != 'not found' ? anchor( 'usermgr/log/1/20/' . base64_encode( $item->email ), image( 'icon16-userlog.png' ), array( 'title' => "View User Log" ) ) : '' ); ?>
				</td>
				<td>
					<?php echo $item->task; ?>
				</td>
				<td>
					<?php echo $item->email; ?>
				</td>
				<td>
					<?php echo date( "d / m / Y  H:i T", $item->timestamp ); ?>
				</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td colspan="3">
					<?php foreach( $item->data as $data ): ?>
						<div class="quiet" style="border-bottom: 1px solid #dddddd; "><?php echo $data; ?></div>
					<?php endforeach; ?>
				</td>
			</tr>
		<?php endforeach; ?>
		
	</table>

	
</div>

<?php endif; ?>