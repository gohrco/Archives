<?php echo form_open("users/edit_user/".$this->uri->segment(3));?>

<div class="append-bottom clear"><label class="span-4" for="username"><?php echo lang( 'users.username' ); ?></label>
<?php echo form_input($username);?>
</div>

<div class="append-bottom clear"><label class="span-4" for="first_name"><?php echo lang( 'users.firstname' ); ?></label>
<?php echo form_input($first_name);?>
</div>

<div class="append-bottom clear"><label class="span-4" for="last_name"><?php echo lang( 'users.lastname' ); ?></label>
<?php echo form_input($last_name);?>
</div>

<div class="append-bottom clear"><label class="span-4" for="company"><?php echo lang( 'users.company' ); ?></label>
<?php echo form_input($company);?>
</div>

<div class="append-bottom clear"><label class="span-4" for="email"><?php echo lang( 'users.email' ); ?></label>
<?php echo form_input($email);?>
</div>

<div class="append-bottom clear"><label class="span-4" for="group_id"><?php echo lang( 'users.group' ); ?></label>
<?php echo form_dropdown( $groups['name'], $groups['options'], $groups['selected'] ); ?>
</div>

<?php echo form_input($user_id);?>

<div class="push-4 append-bottom clear"><?php echo form_button( array( 'name' => 'submit', 'id' => 'submit', 'value' => true, 'type' => 'submit', 'content' => lang( 'savechanges' ) ) );?></div>

<?php echo form_close();?>