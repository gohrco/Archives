<div id="column-left">
	
	<?php echo $template['partials']['admin-cnxnhealth']; ?>
	
	<?php echo $template['partials']['admin-rss']; ?>
	
	<?php echo $template['partials']['admin-update']; ?>
	
</div>

<div id="column-right">

	<?php echo $template['partials']['admin-log']; ?>
	
	<?php echo $template['partials']['admin-stepbystep']; ?>
	
</div>