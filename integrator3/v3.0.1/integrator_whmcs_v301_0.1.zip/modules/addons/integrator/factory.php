<?php
/**
 * Integrator
 * WHMCS - Factory File
 * 
 * @package    Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.1.0.1 ( $Id: factory.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file instantiates objects as needed
 * 
 */

/*-- Security Protocols --*/
if (!defined("WHMCS")) die("This file cannot be accessed directly");
/*-- Security Protocols --*/

/*-- File Inclusions --*/
require_once( "defines.php" );
require_once( "core/object.php" );
require_once( "core/uri.php" );
/*-- File Inclusions --*/

/**
 * Factory Class
 * @version		3.0.1.0.1
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntFactory
{
	/**
	 * Retrieves an instance of the configuration class
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		instance of IntConfig object
	 * @since		3.0.0
	 */
	public function &getConfig()
	{
		static $instance;
		
		if (! is_object( $instance ) ) {
			require_once( "classes/config.php" );
			$instance	= new IntConfig();
		}
		
		return $instance;
	}
	
	
	/**
	 * Retrieves a singular instance of the curl class
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		instance of IntCurl object
	 * @since		3.0.0
	 */
	public function &getCurl()
	{
		static $instance;
		
		if (! is_object( $instance ) ) {
			require_once( "core/curl.php" );
			$instance = new IntCurl();
		}
		
		return $instance;
	}
	
	
	/**
	 * Retrieves a singular instance of the database object
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		instance of IntDatabase object
	 * @since		3.0.0
	 */
	public function &getDbo()
	{
		static $instance;
		
		if (! is_object( $instance ) ) {
			require_once( "core/database.php" );
			$instance = new IntDatabase();
		}
		
		return $instance;
	}
	
	
	/**
	 * Retrieves a singular instance of the debug object, passing parameters if sent
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		mixed		- $options: can be an array, boolean or string
	 * 
	 * @return		instance of IntDebug object
	 * @since		3.0.0
	 */
	public function &getDebug( $options = array() )
	{
		static $instance;
		
		if ( is_bool( $options ) )		$options = array( 'enable' => $options );
		if ( is_string( $options ) )	$options = array( 'script' => $options );
		
		if (! is_object( $instance ) ) {
			if (! isset( $options['enable'] ) ) {
				$config = IntFactory::getConfig();
				$options['enable'] = $config->Debug;
			}
			require_once( "classes/debug.php" );
			$instance = new IntDebug( $options );
		}
		else {
			if (! empty( $options ) ) {
				$instance->set_options( $options );
			}
		}
		
		return $instance;
	}
	
	
	/**
	 * Retrieves a singular instance of the hook class object
	 * @access		public
	 * @version		3.0.1.0.1
	 * 
	 * @return		instance of IntHook object
	 * @since		3.0.0
	 */
	public function &getHook()
	{
		static $instance;
		
		if (! is_object( $instance ) ) {
			require_once( "classes/hook.php" );
			$instance	= new IntHook();
		}
		
		return $instance;
	}
	
	
	/**
	 * Retrieves the language file when in WHMCS backend
	 * @access		public
	 * @version		3.0.1.0.1
	 * @param		string		- $language: in the event $aInt hasn't been instantiated yet
	 * 
	 * @return		array containing language translations
	 * @since		3.0.0
	 */
	public function &getLang( $language = 'english' )
	{
		static $intlang;
		
		if (! is_array( $intlang ) ) {
			global $aInt;
			$language = (! is_object( $aInt ) ) ? $language : $aInt->language;
			$lang_file	= dirname(__FILE__) . DIRECTORY_SEPARATOR . 'lang' . DIRECTORY_SEPARATOR . ucfirst( $language ) . '.php';
			$lang_file	= file_exists( $lang_file ) ? $lang_file : dirname(__FILE__) . DIRECTORY_SEPARATOR . 'lang' . DIRECTORY_SEPARATOR . 'English.php';
			require_once( $lang_file );
		}
		
		return $intlang;
	}
	
	
	/**
	* Retrieves a singular instance of the log class object
	* @access		public
	* @version		3.0.1.0.1
	*
	* @return		instance of BLog object
	* @since		1.0.4
	*/
	public function &getLog()
	{
		static $instance;
	
		if (! is_object( $instance ) ) {
			require_once( "classes/log.php" );
			$instance	= new IntLog();
		}
	
		return $instance;
	}
}