<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.9 ( $Id: admin_lang.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the Joomla admin controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


// ===================================================================
// 	Client Area (user/info)
// ===================================================================
//		v 3.0.1
// -------------------------------------------------------------------
$lang['fusion_api.tickets.header']			= 'Support Tickets';
$lang['fusion_api.tickets.headerlink']		= 'View All Tickets';
$lang['fusion_api.tickets.headerlink']		= 'View All Tickets';
$lang['fusion_api.tickets.column.ticketid']	= 'Ticket ID';
$lang['fusion_api.tickets.column.lastupd']	= 'Last Update';
$lang['fusion_api.tickets.column.subject']	= 'Subject';
$lang['fusion_api.tickets.column.lastrply']	= 'Last Replier';
$lang['fusion_api.tickets.column.dept']		= 'Department';
$lang['fusion_api.tickets.column.type']		= 'Type';
$lang['fusion_api.tickets.column.status']	= 'Status';
$lang['fusion_api.tickets.column.priority']	= 'Priority';
$lang['fusion_api.tickets.column.viewtkt']	= 'View Ticket';



// ===================================================================
// 	User Edit (user/edit)
// ===================================================================
//		v 3.0.1
// -------------------------------------------------------------------
$lang['label.fullname']			= "Full Name";
$lang['label.active']			= "Active";

$lang['desc.fullname']			= "Enter a complete name for this account.";
$lang['desc.active']			= "Indicate if this account should be active (able to log in) or not.";

