<?php


class BanFreebies
{
	public $domains = array();
	public $email	= null;
	
	public function __construct( $email = null )
	{
		if ( $this->_setdomains() === false ) return false;
		if ( $email != null ) $this->email = $email; 
	}
	
	
	public function check( $email = null )
	{
		// Be sure we sent an email address
		if ( $email == null && $this->email == null ) return false;
		if ( $email == null ) $email = $this->email;
		if ( is_email( $email ) === false ) return false;
		
		$parts	= explode( '@', $email );
		
		if ( isset( $this->domains[$parts[1]] ) ) return false;
		else return true;
	}
	
	
	private function _setdomains()
	{
		if ( ( $raw = read_file( dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'freeemails.txt' ) ) === false ) {
			return false;
		}
		
		$emails = explode( "\n", $raw );
		foreach( $emails as $email ) {
			$email = trim( $email );
			$this->domains[$email] = true;
		}
		
		return true;
	}
}