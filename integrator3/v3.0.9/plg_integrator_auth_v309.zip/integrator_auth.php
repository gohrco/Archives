<?php
/**
 * Integrator
 * User - Integrator Plugin
 * 
 * @package    Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.9 ( $Id: integrator_user.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.1
 * 
 * @desc       This is the file executed by the Authentication - Integrator plugin for handling calls to the Integrator and authentication users against various cnxns
 * 
 */


/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.router' );
jimport( 'joomla.environment.uri' );
jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.application.component.helper' );
require_once( JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_integrator' . DIRECTORY_SEPARATOR . 'integrator.class.php' );
/*-- File Inclusions --*/

/**
 * Authentication - Integrator plugin
 * @version		3.0.9
 * 
 * @since		3.0.1 (0.1)
 * @author		Steven
 */
class plgAuthenticationIntegrator_auth extends JPlugin
{
	
	/**
	 * Local enable
	 * @access		public
	 * @since		3.0.0
	 * @var			bool
	 */
	public $enabled	= true;
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.9
	 * @param		unknown_type $subject
	 * @param		unknown_type $config
	 * 
	 * @since		3.0.0
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		$this->params->merge( JComponentHelper::getParams( "com_integrator" ) );
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$this->loadLanguage();
		}
		
		// Catch in case helper missing or disabled
		if ( ( $this->params->get( 'UserEnabled', 'No' ) == 'No' ) ||
			 ( $this->params->get( 'Enabled', 'No' ) == 'No' ) ||
			 (! class_exists( 'IntegratorHelper' ) ) ||
			 ( defined( 'INTEGRATOR_API' ) ) )
		{
		 	$this->enabled = false;
		}
	
 	    return true;
	}
	
	
	/**
	 * onUserAuthenticate Event Trigger
	 * @access		public
	 * @version		3.0.9
	 * @param		array		- $credentials: contains the passed along credentials
	 * @param		array		- $options: contains passed along credentials
	 * @param		JError		- $response: response object
	 *
	 * @return		result of authentication routine
	 * @since		3.0.1 (0.1)
	 */
	public function onUserAuthenticate(  $credentials, &$options, &$response )
	{
		$app	= & JFactory::getApplication();
		$params	= & $this->params;
		
		// Ensure we do nothing if we are disabled
		if (! $this->enabled ) return true;
		
		// Be sure we send it back if we are authenticating as the API!
		if ( isset( $options['integrator'] ) ) return;
		
		// Be sure we have a password available to use
		if ( empty( $credentials["password"] ) ) return;
		
		$response->type	= 'integrator_auth';
		
		$api 			= & IntApi::getInstance();
		$intresp		=   $api->user_authenticate( $credentials );
		
		// If the user authenticated somewhere else
		if ( $intresp ) {
			// Grab the Database
			$db		= JFactory::getDbo();
			$query	= $db->getQuery(true);
			
			if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
				$query->select( 'id' );
				$query->from( '#__users' );
				
				if ( is_email ( $credentials['username'] ) ) {
					$query->where( 'email=' . $db->Quote( $credentials['username'] ) );
				}
				else {
					$query->where( 'username=' . $db->Quote( $credentials['username'] ) );
				}
			}
			else {
				$query = "SELECT `id` FROM #__users WHERE " . ( is_email( $credentials['username'] ) ? "email" : "username" ) . "=" . $db->Quote( $credentials['username'] );
			}
			
			$db->setQuery($query);
			$result = $db->loadObject();
			
			// If the user even exists here then we go ahead and bring them up
			if ( $result ) {
				$user = JUser :: getInstance( $result->id );
				$response->name				= $user->name;
				$response->username			= $user->username;
				$response->email			= $user->email;
				$response->password			= $credentials["password"];
				$response->fullname			= $user->name;
				$response->language			= $user->getParam('language');
				$response->status			= 1;
				$response->error_message	= '';
			}
			else {
				$response->status = 4;
				$response->error_message = JText::_('JGLOBAL_AUTH_NO_USER');
			}
		}
		else {
			$response->status = 4;
			$response->error_message = JText::_('JGLOBAL_AUTH_INVALID_PASS');
		}
		//echo '<pre>'.print_r($credentials,1).print_r($user,1).print_r($response,1); die();
	}
	
	
	/**
	 * onAuthenticate - Joomla 1.5 compatibility
	 * @access		public
	 * @version		3.0.9
	 * @param		array		- $credentials: contains the passed along credentials
	 * @param		array		- $options: contains passed along credentials
	 * @param		JError		- $response: response object
	 * 
	 * @return		result of authentication routine
	 * @since		3.0.1 (0.1)
	 */
	public function onAuthenticate(  $credentials, &$options, &$response )
	{
		$result	= $this->onUserAuthenticate(  $credentials, $options, $response );
		return $result;
	}
}