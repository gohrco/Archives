<?php
/**
 * Integrator
 * 
 * @package    Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.9 ( $Id: class.Controller_SettingsManager.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file is the settings manager for the Fusion addon module
 * 
 */

/**
 * Settings Manager Controller
 * @author		Steven
 * @version		3.0.9
 * 
 * @since		3.0.0
 */
class Controller_SettingsManager extends Controller_admin
{
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.9
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
		$this->Load->Library('Settings:SettingsManager');
		return true;
	}
	
	
	/**
	 * Destructor method
	 * @access		public
	 * @version		3.0.9
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function __destruct()
	{
		parent::__destruct();
		return true;
	}
	
	
	/*
	public function Index()
	{
		$_SWIFT = SWIFT::GetInstance();
		
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
			return false;
		}
		
		$this->UserInterface->Header( 'Integrator - Settings', self::110, self::1);
		
		if ($_SWIFT->Staff->GetPermission('admin_canupdatesettings') == '0')
		{
			$this->UserInterface->DisplayError($this->Language->Get('titlenoperm'), $this->Language->Get('msgnoperm'));
		} else {
			$this->UserInterface->Start(get_class($this), '/integrator/SettingsManager/Index');
			$this->SettingsManager->Render($this->UserInterface, SWIFT_SettingsManager::FILTER_NAME, array('settings_integrator'));
			$this->UserInterface->End();
		}
		
		$this->UserInterface->Footer();
		
		return true;
	}*/
	
}

?>