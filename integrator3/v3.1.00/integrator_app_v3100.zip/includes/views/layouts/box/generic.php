<?php
/**
 * Integrator 3
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.00 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.4
 *
 * @desc       This is the generic box builder for Integrator 3 backend
 *
 */

/**
 * This file requires:
 *  - $type:     what type of box we are creating (used for language purposes)
 * 	- $headings: an array of headings
 *  - $source:   the actual source
 *  
 *  headings should be in same order as source items
 */
?>

<table class="table table-striped table-bordered">
	<thead>
		<tr>
			<?php foreach ( $headings as $heading ) : ?>
			
			<th><?php echo lang( 'tblhdr.' . $type . '.' . $heading ); ?></th>
			
			<?php endforeach; ?>
		</tr>
	</thead>
	<tbody>
		<?php foreach ( $source as $items ) : ?>
		
		<tr>
			<?php foreach ( $items as $item ) : ?>
			
			<td><?php echo $item; ?></td>
			
			<?php endforeach; ?>
		</tr>
		
		<?php endforeach; ?>
	</tbody>
</table>