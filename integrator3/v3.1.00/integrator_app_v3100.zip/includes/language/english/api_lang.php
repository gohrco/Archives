<?php
/**
 * Integrator 3
*
* @package    Integrator 3
* @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
* @license    GNU General Public License version 2, or later
* @version    3.1.00 ( $Id$ )
* @author     Go Higher Information Services, LLC
* @since      3.1.00
*
* @desc       This is the English language file for the api controller pages for the Integrator
*
*/

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * This file contains all translations used in the API
*/


// ===================================================================
// 	GENERAL TRANSLATIONS
// ===================================================================
$lang['api.error.postheadnomatch']	=	'The signatures are not matching one another.  Please try again.';
$lang['api.error.rcvdmadenomatch']	=	'The signatures are not matching one another.  Please try again.';
$lang['api.error.timestamp']		=	'Your request is too old.  Please try again.';
