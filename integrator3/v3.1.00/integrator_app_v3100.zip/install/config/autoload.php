<?php  

if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$autoload['packages'] = array(); //array( APPPATH.'cnxns' );
$autoload['libraries'] = array(); //array( 'asset', 'curl', 'ion_auth', 'parser', 'template' );
$autoload['helper'] = array(); //array( 'asset', 'language', 'settings', 'uri', 'url', 'userlog' );
$autoload['config'] = array();
$autoload['language'] = array();
$autoload['model'] = array();
