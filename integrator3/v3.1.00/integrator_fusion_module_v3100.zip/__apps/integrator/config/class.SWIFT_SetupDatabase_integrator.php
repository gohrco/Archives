<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.00 ( $Id: class.SWIFT_SetupDatabase_integrator.php 288 2013-10-04 20:26:32Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This is the setup file for the Integrator within Fusion
 * 
 */

/**
 * Setup Database Controller
 * @author		Steven
 * @version		3.1.00
 * 
 * @since		3.0.0
 */
class SWIFT_SetupDatabase_integrator extends SWIFT_SetupDatabase
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.1.00
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct("integrator");
		return true;
	}
	
	
	/**
	 * Destructor method
	 * @access		public
	 * @version		3.1.00
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function __destruct()
	{
		parent::__destruct();
		return true;
	}
	
	
	/**
	 * Installation method
	 * @access		public
	 * @version		3.1.00
	 * @param		unknown		- $_pageIndex: passed to parent install
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function Install($_pageIndex)
	{
		parent::Install($_pageIndex);
		$this->ImportSettings();
		
		// Create the template and update
		$tID = $this->TemplateCreate();
		$this->TemplateUpdate( $tID );
		
		return true;
	}
	
	
	/**
	 * Upgrade method
	 * @access		public
	 * @version		3.1.00
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function Upgrade()
	{
		// Grab the Integrator template ID
		if ( ( $tID = $this->TemplateFind() ) === false ) {
			// If we can't find it, recreate so we don't fail
			$tID = $this->TemplateCreate();
		}
		
		$this->TemplateUpdate( $tID );
		
		$this->ImportSettings();
		return parent::Upgrade();
	}
	
	
	/**
	 * Uninstallation method
	 * @access		public
	 * @version		3.1.00
	 * 
	 * @return		true
	 * @since		3.0.0
	 */
	public function Uninstall()
	{
		if ( ( $tID = $this->TemplateFind() ) !== false ) {
			$this->TeamplateDelete( $tID );
		}
		
		parent::Uninstall();
		return true;
	}
	
	
	/**
	 * Imports the settings from the xml manifest
	 * @access		public
	 * @version		3.1.00
	 * 
	 * @since		3.0.0
	 */
	private function ImportSettings()
	{
		$this->Load->Library('Settings:SettingsManager');
		
		if ( version_compare( SWIFT_VERSION, '4.50', 'ge' ) ) {
			$this->SettingsManager->Import('./'.SWIFT_APPSDIRECTORY.'/integrator/config/settings.xml');
		}
		else {
			$this->SettingsManager->Import('./'.SWIFT_MODULESDIRECTORY.'/integrator/config/settings.xml');
		}
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE FOR TEMPLATE HANDLING
	 * **********************************************************************
	 */
	
	
	/**
	 * Creates a new template for the Integrator
	 * @access		private
	 * @version		3.1.00
	 * 
	 * @return		int containing the new template ID
	 * @since		3.0.0
	 */
	private function TemplateCreate()
	{
		// Legacy code
		if ( version_compare( SWIFT_VERSION, '4.50', 'l' ) ) {
			SWIFT_Loader :: LoadLibrary( 'Template:TemplateGroup' );
			SWIFT_Loader :: LoadLibrary( 'Template:Template' );
			SWIFT_Loader :: LoadLibrary( 'User:UserGroup' );
			SWIFT_Loader :: LoadLibrary( 'Language:Language' );
		}
		
		// Grab Default Template ID
		$_defaultTemplID	= SWIFT_TemplateGroup :: GetMasterGroupID();
		
		// Grab User Group IDs
		$_defaultGuestID	= SWIFT_UserGroup :: RetrieveDefaultUserGroupID( 0 );
		$_defaultRegID		= SWIFT_UserGroup :: RetrieveDefaultUserGroupID( 1 );
		
		// Grab default Language ID
		$_defaultLangID		= SWIFT_Language :: GetMasterLanguageIDList();
		$_defaultLangID		= array_shift( $_defaultLangID );
		
		// Grab the default ticket status
		$_defaultStatusID	= (int) $this->TemplateGetStatus();
		
		// Create a new Template Group
		if ( version_compare( SWIFT_VERSION, '4.52', 'ge' ) ) {
			$newTempObject	=	SWIFT_TemplateGroup::Create( 'IntegratorTpls', 'This group is created by the Integrator module', 'Go Higher Information Services',
															false, null, null, $_defaultLangID, true, false, $_defaultGuestID, $_defaultRegID,
															false, $_defaultTemplID, 0, $_defaultStatusID, 0, 0, false, true
															);
		}
		else {
			$newTempObject		= $this->TemplateGroup->Create( 'IntegratorTpls', 'This group is created by the Integrator module', 'Go Higher Information Services',
																false, null, null, $_defaultLangID, true, false, $_defaultGuestID, $_defaultRegID,
																false, $_defaultTemplID, 0, $_defaultStatusID, 0, 0, false, true
																);
		}
		
		return $newTempObject->GetTemplateGroupID();
	}
	
	
	/**
	 * Gathers the current templates from the templates folder
	 * @access		private
	 * @version		3.1.00
	 * 
	 * @return		array of template contents for storage or updating
	 * @since		3.0.0
	 */
	private function TemplatesCurrent()
	{
		$data	= array( 'header' => null, 'footer' => null, 'clientcss' => null, 'integratorlogin' => null );
		
		if ( version_compare( SWIFT_VERSION, '4.50', 'ge' ) ) {
			$path	= SWIFT_BASEPATH . DIRECTORY_SEPARATOR . SWIFT_APPSDIRECTORY . DIRECTORY_SEPARATOR . 'integrator' . DIRECTORY_SEPARATOR . 'templates'. DIRECTORY_SEPARATOR;
		}
		else {
			$path	= SWIFT_BASEPATH . DIRECTORY_SEPARATOR . SWIFT_MODULESDIRECTORY . DIRECTORY_SEPARATOR . 'integrator' . DIRECTORY_SEPARATOR . 'templates'. DIRECTORY_SEPARATOR;
		}
		
		foreach ( $data as $key => $empty ) {
			$contents	= file_get_contents( $path . $key . '.tpl' );
			if ( $contents === false ) continue;
			$data[$key]	= $contents;
		}
		return $data;
	}
	
	
	/**
	 * Deletes the given template ID
	 * @access		private
	 * @version		3.1.00
	 * @param		integer		- $_tgID: contains the template ID of the template to delete
	 * 
	 * @since		3.0.0
	 */
	private function TeamplateDelete( $_tgID )
	{
		$tGroup	= new SWIFT_TemplateGroup( $_tgID );
		$tGroup->Delete();
	}

	
	/**
	 * Finds the template that is used for the Integrator
	 * @access		private
	 * @version		3.1.00
	 * 
	 * @return		varies integer if found, false if not
	 * @since		3.0.0
	 */
	private function TemplateFind( $title = 'IntegratorTpls' )
	{
		$tID	= $this->Database->QueryFetch( "SELECT `tgroupid` FROM " . TABLE_PREFIX . "templategroups WHERE `title` = '{$title}'" );
		
		if ( $tID === false ) return false;
		else return $tID['tgroupid'];
	}
	
	
	/**
	 * Query to retrieve the master ticket stataus ID for template group creation
	 * @access		private
	 * @version		3.1.00
	 * 
	 * @return		integer if found, false if not
	 * @since		3.0.0
	 */
	private function TemplateGetStatus()
	{
		$tID	= $this->Database->QueryFetch( "SELECT `ticketstatusid` FROM " . TABLE_PREFIX . "ticketstatus WHERE `ismaster` = 1" );
		
		if ( $tID === false ) return false;
		else return $tID['ticketstatusid'];
	}
	
	
	/**
	 * Updates a template with a given ID
	 * @access		private
	 * @version		3.1.00
	 * @param		integer		- $templateID: the template ID of the template to update
	 * 
	 * @since		3.0.0
	 */
	private function TemplateUpdate( $templateID )
	{
		if ( version_compare( SWIFT_VERSION, '4.50', 'l' ) ) {
			SWIFT_Loader :: LoadLibrary( 'Template:Template' );
		}
		
		// Grab the templates from the group and update the appropriate ones
		$templates	= SWIFT_Template :: GetTemplateData( $templateID );
		$_integratorTemplates	= $this->TemplatesCurrent();
		
		// Create an array to cycle through
		$toRun = array();
		foreach( $_integratorTemplates as $key => $toss ) {
			$toRun[$key] = $key;
		}
		
		// Cycle through templates and update any that already exist
		foreach ( $templates as $tempID => $template ) {
			if (! in_array( $template['name'], $toRun ) ) continue;
			
			$templateObject	= new SWIFT_Template( $tempID );
			$templateObject->Update( $_integratorTemplates[$template['name']], false );
			
			unset( $toRun[$template['name']] );
		}
		
		// If we are out of templates, nothing to create
		if ( empty( $toRun ) ) return;
		
		// If we are still here, we must add the remaining templates to the group
		// Grab the core (general) category id
		$tdefID		= $this->TemplateFind( 'Default' );
		
		// In case the user is using some template not called Default in there
		if ( $tdefID === false ) {
			$tdefID = SWIFT_TemplateGroup :: GetMasterGroupID();
		}
		
		$defcateID	= $this->TemplateCategoryFind( $tdefID );
		$categoryID	= $this->TemplateCategoryFind( $templateID );
		
		// Run through remaining and add them to the group
		foreach ( $toRun as $template ) {
			SWIFT_Template :: Create( $tdefID, $defcateID, $template, $_integratorTemplates[$template] );
			SWIFT_Template :: Create( $templateID, $categoryID, $template, $_integratorTemplates[$template] );
		}
	}
	
	
	/**
	 * Finds the core (general) template category for the Integrator template group
	 * @access		private
	 * @version		3.1.00
	 * @param		int		- $templateID: the template group ID
	 * 
	 * @return		int on success or false on error
	 * @since		3.0.0
	 */
	private function TemplateCategoryFind( $templateID )
	{
		SWIFT_Loader :: LoadLibrary( 'Template:TemplateCategory' );
		$categories	= SWIFT_TemplateCategory :: GetCategoryData( $templateID );
		
		$categoryID = false;
		foreach ( $categories as $cat ) {
			if ( version_compare( SWIFT_VERSION, '4.50', 'ge' ) ) {
				$lookfor = 'app';
			}
			else {
				$lookfor = 'module';
			}
			
			if ( $cat[$lookfor] != 'core' ) continue;
			 $categoryID = $cat['tcategoryid'];
			 break;
		}
		
		return $categoryID;
	}
}

?>