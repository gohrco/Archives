<?php
/**
 * Integrator 3
 * Integrator 3 - Render Module File
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.00 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This file is the render controller
 *
 */

/**
 * Render Module Class for Integrator 3
 * @version		3.1.00
 *
 * @author		Steven
 * @since		3.1.00
 */
class IntegratorRenderDunModule extends IntegratorClientDunModule
{
	private $debugcurl		=	null;		// Contains the info array from the curl call for debugging
	private $debugregex		=	array();
	private $headoutput;
	private $htmlfooter;
	private $htmlheader;
	private $integratoruri;
	private $unicode		=	'u';
	private $usetemplate;
	protected $checkstring	=	"@checkString@";
	
	public function execute( $vars = array() )
	{
		// Provide instantiation
		static $integrator = array();
		
		if (! empty( $integrator ) ) {
			return array( 'integrator' => $integrator );
		}
		
		// Lets establish our default to return just in case
		$integrator	=	array(
				'enabled'	=>	false,
				'template'	=>	'templates/' . ( isset( $vars['template'] ) ? $vars['template'] : 'default' )
				);
		
		// If we are disabled don't run ;-)
		if (! ensure_active( 'visual' ) ) {
			return array( 'integrator' => $integrator );
		}
		
		$config	=	dunloader( 'config', 'integrator' );
		$api	=	dunloader( 'api', 'integrator' );
		$wapi	=	dunloader( 'whmcsapi', 'integrator' );
		$params	=	$this->_assembleCall( $vars );
		$task	=	'Render';
		
		// Make the call
		$call = $api->render( $params );
		
		// Grab for debugging purposes
		$this->debugcurl	=	$api->debug;
		
		if (! $call ) {
			$error	=	$wapi->log( $task, 'Rendering Client', $api->hasErrors() );
			
			return array( 'integrator' => $integrator );
		}
		
		$call->header	=	$this->_utf8convert( base64_decode( $call->header ) );
		$call->footer	=	$this->_utf8convert( base64_decode( $call->footer ) );
		
		// Set pieces into place
		$this->setHead( $call );
		$this->setFooter( $call );
		$this->setHeader( $call );
		
		// Do cleanup work
		$regexes	=	$this->_gatherRegex();
		
		foreach( $regexes as $type => $regex ) {
			$this->_cleanup( $regex, $type );
		}
		
		
		// -------------------------------------------
		// Handle miscellaneous tasks
		// -------------------------------------------
		// Determine template path
		// ---- BEGIN JWHMCS-20
		//		The original call was always resulting in default
		if (! isset( $vars['template'] ) ) {
			$this->usetemplate	=	'default';
		}
		else {
			$this->usetemplate	=	$vars['template'];
		}
		// ---- END JWHMCS-20
		
		// -------------------------------------------
		// Build the JWHMCS template path
		$jwhmcstemplate	=	rtrim( get_systemurl(), '/' ) . '/modules/addons/integrator/templates/' . get_version() . '/' . $this->usetemplate;
		
		// -------------------------------------------
		// Reset CSS
		if ( $config->get( 'resetcss', 0 ) ) {
			
			$this->headoutput	.=	"\r\n"
								.	'<link rel="stylesheet" href="' . rtrim( get_systemurl(), '/' ) . '/modules/addons/integrator/assets/css/reset.css' . '" type="text/css" />';
			
			DunUri :: getInstance( 'SERVER', true );
		}
		
		
		// -------------------------------------------
		// Gather variables to return to template
		// -------------------------------------------
		$integrator['enabled']		=	true;															// Are we enabled?
		$integrator['shownavbar']	=	(bool) $config->get( 'shownavbar', false );						// Show navbar?
		$integrator['showfooter']	=	(bool) $config->get( 'showfooter', false ); 					// Show footer?
		$integrator['template']		=	$jwhmcstemplate;
		$integrator['headoutput']	=	$this->getItem( 'head' );										// Grab the head data?
		$integrator['usejquery']	=	(bool) $config->get( 'jqueryenable', true );					// Enable WHMCS' jQuery library? (JWHMCS-18)
		$integrator['usebootstrap']	=	$config->get( 'bootstrapenable', '0' ) == '1' ? false : true;	// Use WHMCS' bootstrap library
		$integrator['enableresizejs']	=	(bool) $config->get( 'enableresizejs', false );
		
		return array( 'integrator' => $integrator );
	}
	
	
	/**
	 * Initializes the module
	 * @access		public
	 * @version		3.1.00
	 *
	 * @since		3.1.00
	 */
	public function initialise()
	{
		$config	=	dunloader( 'config', 'integrator' );
		
		$this->integratoruri	=	DunUri :: getInstance( $config->get( 'integratorurl' ), true );
	}
	
	
	/**
	 * Method to get an item for output
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 * @param		string		- $item: gets the item we want [head|customcss|footer|header|debug]	
	 * @param		array		- $vars: contains already assembled data from hooks 
	 * 
	 * @return		string
	 * @since		3.1.00
	 */
	public function getItem( $item = 'head', $vars = array() )
	{
		
		switch( $item ) :
		case 'customcss' :
			
			// If we are disabled don't do it
			if (! ensure_active( 'visual' ) ) {
				return null;
			}
			
			$config		=	dunloader( 'config', 'integrator' );
			$customcss	=	$config->get( 'customcss', null );
			
			if ( $customcss ) {
				$customcss	=	'<style type="text/css">' . $customcss . '</style>';
			}
			
			
			$path		=	dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'templates' . DIRECTORY_SEPARATOR . get_version() . DIRECTORY_SEPARATOR . $this->usetemplate . DIRECTORY_SEPARATOR;
			
			if ( file_exists( $path . 'custom.css' ) ) {
				$customcss	=	'<link rel="stylesheet" href="' . rtrim( get_systemurl(), '/' ) . '/modules/addons/integrator/templates/' . get_version() . '/' . $this->usetemplate . '/custom.css" type="text/css" />' . $customcss;
			}
			
			return $customcss;
		case 'head' :
			return $this->headoutput;
		case 'footer' :
			
			// Lets check our license
			if (! ensure_active( 'license' ) ) {
				return dunloader( 'license', 'integrator' )->getErrorMsg();
			}
			
			return $this->htmlfooter;
		case 'header' :
			return $this->htmlheader;
		case 'debug' :
			return $this->debugcurl;
		endswitch;
	}
	
	
	/**
	 * Method to set the html footer into place
	 * @access		public
	 * @version		3.1.00 ( $id$ )
	 * @param		object		- $call: our html
	 *
	 * @since		3.1.00
	 */
	public function setFooter( $call )
	{
		$config	=	dunloader( 'config', 'integrator' );
		
		// Lets see if we add our button hook here
		$script = null;
		
		if ( $config->get( 'buttonfix', true ) ) {
			$script	=	<<< SCRIPT
<script type="text/javascript">
	jQuery( '#integratorwrapper input[type="submit"]' ).on('click', function() { jQuery(this).closest('form').submit(); });
</script>
SCRIPT;
		}
		
		$parts	=	explode( '</body>', $call->footer );
		$footer	=	array_shift( $parts );
		$footer	=	"\r\n"
				.	'</div>'
				.	"<!-- End setFooter -->"
				.	$footer
				.	$script;
		$this->htmlfooter	=	$footer;
	}
	
	
	/**
	 * Method to set the head in place for later retrieval
	 * @access		public
	 * @version		3.1.00
	 * @version		2.5.8		Added advanced method for parsing the head area.
	 * @param		object		- $call: contains the htmlheader / footer
	 * 
	 * @since		3.1.00
	 */
	public function setHead( $call )
	{
		$config		=	dunloader( 'config', 'integrator' );
		$linebyline	=	$config->get( 'parseheadlinebyline', false );
		$parts		=	explode( '</head>', $call->header );
		$head		=	array_shift( $parts );
		$newhead	=	array();
		
		// Advanced method - line by line
		if ( $linebyline ) {
			
			$fndhead	=
			$fndhtml	=	false;
			$lines		=	preg_split( '#\n|\r\n#', $head );
			
			foreach( $lines as $line ) {
				if ( strpos( $line, '<head' ) !== false ) {
					$fndhead = true;
					continue;
				}
			
				if ( strpos( $line, '<html' ) !== false ) {
					$fndhtml = true;
					continue;
				}
			
				if (! $fndhtml && ! $fndhead ) continue;
				if ( strpos( $line, '<base' ) !== false ) continue;
				if ( strpos( $line, 'charset' ) !== false ) continue;
				if ( strpos( $line, 'generator' ) !== false ) continue;
				if ( strpos( $line, '</title>' ) !== false ) continue;
				$newhead[]	=	$line;
			}
		}
		else {
			// Lets handle meta tags first
			preg_match_all( '#<meta[^>]*/>#u', $head, $matches );
			
			if ( isset( $matches[0] ) ) {
				foreach ( $matches[0] as $match ) {
					if ( strpos( $match, 'charset' ) !== false ) continue;
					if ( strpos( $match, 'generator' ) !== false ) continue;
			
					$newhead[]	=	$match;
				}
			}
			
			$parts		=	explode( '</title>', $head );
			$newhead[]	=	array_pop( $parts );
		}
		
		$this->headoutput	=	implode( "\r\n", $newhead );
	}
	
	
	/**
	 * Method to set the head in place for later retrieval
	 * @access		public
	 * @version		3.1.00
	 * @param		object		- $call: contains the htmlheader / footer
	 *
	 * @since		3.1.00
	 */
	public function setHeader( $call )
	{
		// Find the end head tag first
		$parts		=	explode( '</head>', $call->header );
		$body		=	array_pop( $parts );
		$body		.=	"\r\n"
					.	'<!-- Begin setHeader -->'
					.	'<div id="integratorwrapper">';
		$this->htmlheader =	$body;
	}
	
	
	/**
	 * Method to assemble the parameters for the render call
	 * @access		private
	 * @version		3.1.00 ( $id$ )
	 * @param		array		- $vars: contains the variables we were passed in the ClientAreaPage hook
	 *
	 * @return		array
	 * @since		3.1.00
	 */
	private function _assembleCall( $vars = array() )
	{
		// Initialize
		$config	=	dunloader( 'config', 'integrator' );
		$email	=	$this->_extract_email( $vars );
		
		$salt		= mt_rand();
		$secret		= $config->get( 'apitoken' );
		$signature	= base64_encode( hash_hmac( 'sha256', $salt, $secret, true ) );
		
		$data	= array(
				'filename'		=> $this->_getvar( 'filename' ),
				'language'		=> $this->_getvar( 'language' ),
				'characterset'	=> $GLOBALS['CONFIG']['Charset'],
				'session_id'	=> session_id(),
				'isssl'			=> ( is_ssl() ? '1' : '0' ),
				'_a'			=> $config->get( 'cnxnid' ),
				'signature'		=> $signature,
				'salt'			=> $salt
		);
		
		if ( isset( $GLOBALS['_v'] ) ) {
			$data['_v'] = $GLOBALS['_v'];
		}
		
		// If we have a logged in client then grab the variables there
		if ( $email ) {
			$data['useremail']	=	$email;
			$data['isloggedin']	=	true;
		}
		
		// Language time
		if ( false == true && $config->get( 'languageenable', false ) ) {
			
			// Determine which language to get
			if ( isset( $vars['language'] ) ) {
				// If we have a language set, then lets tell Joomla
				$language			=	$vars['language'];
				$data['langrev']	=	$language;	// Used by Joomla regexes to indicate WHMCS language for links / actions
			}
			else {
				$language			=	'default';
			}
			
			$ls				=	dunloader( 'languagesettings', 'integrator' );
			$data['lang']	=	$ls->getLanguagesetting( $language );
		}
		
		return $data;
	}
	
	
	private function _buildUrl( $uri )
	{
		$scheme = $uri->getScheme();
	
		if (! is_null( $scheme ) ) {
			if ( ( $scheme == 'javascript' ) && ( ( $uri->getPath() == "/;" )  || ( $uri->getPath() == ";" ) ) ) return 'javascript:;';
			if ( ( $scheme == 'javascript' ) && (! is_null( $uri->getPath() ) ) ) return 'javascript:' . ltrim( $uri->getPath(),'/' );
		}
	
		return $uri->toString();
	}
	
	
	private function _checkDuplicatePaths( $orig, $new )
	{
		// The original path is coming out of the template
		// The new path is held in the needle
	
		$npath = explode('/', trim($new, '/'));
		$upath = explode('/', trim($orig, '/'));
		
		$start = false;
		// Take the first path item from original and check for existance in new path
		if (in_array($upath[0], $npath) ) {
			$start = array_search($upath[0], $npath);
		}
	
		// We know that we found the first item in the new path, now compare the rest of the path to see if it matches
		if ($start !== false) {
			$chop = true;
			for ($i=0; $i<count($npath); $i++) {
				if ($npath[$start+$i] != $upath[$i]) {
					$chop = false;
					break;
				}
			}
			if ($chop) {
				array_splice($npath, $start);
			}
		}
	
		// Reassemble the needle now and return
		return '/' . implode('/', $npath).'/'.ltrim($orig, '/');
	}
	
	
	private function _cleanup( $regex, $type )
	{
		$check		=	array( 'headoutput', 'htmlheader', 'htmlfooter' );
		
		foreach ( $check as $item ) {
			
			$actions	=	array();
			$matches	=	array();
			
			preg_match_all( $regex->search, $this->$item, $matches, PREG_SET_ORDER);
			
			foreach( $matches as $match ) {
				$actions[]	=	$this->_parsedata( $match, $regex->replace, $regex->replaceall, $regex->noprepend, $regex->scheme );
			}
			
			foreach ( $actions as $action ) {
				$this->$item = str_replace( $action->find, $action->replace, $this->$item );
			}
		}
	}
	
	
	/**
	 * Method for extracting the correct email address for a logged in user
	 * @access		private
	 * @version		3.1.00 ( $id$ )
	 * @param		array		- $vars: variables we are passed
	 *
	 * @return		string or false on not loggedin
	 * @since		3.1.00
	 */
	private function _extract_email( $vars )
	{
		$vars	=	(object) $vars;
		$data	=	false;
		
		if ( isset( $vars->loggedin ) && $vars->loggedin && isset( $vars->loggedinuser ) && $vars->loggedinuser && is_array( $vars->loggedinuser ) ) {
			$data	=	$vars->loggedinuser['email'];
		}
		
		return $data;
	}
	
	
	/**
	 * Gather the regular expressions
	 * @access		private
	 * @version		3.1.00 ( $id$ )
	 *
	 * @return		array of objects
	 * @since		3.1.00
	 */
	private function _gatherRegex()
	{
		$config		=	dunloader( 'config', 'integrator' );
		$data		=	array();
		
		/* Bootstrap Check */
		$checkforbootstrap	=	$config->get( 'bootstrapenable', '0' );
		// Strip out bootstrap from wrapper
		if ( $checkforbootstrap == '2' ) {
			
			$regex	=	'/(?P<front><script[^>]+?src=[\"\'])\/?(?!\/)(?P<link>[^\/]+[^>\"\']+(bootstrap\.js|bootstrap\.min\.js))(?P<back>\'?\"?.*?>)/sm' . $this->unicode;
			
			// First see if we have bootstrap in our source code
			foreach ( array( 'headoutput', 'htmlheader', 'htmlfooter' ) as $item ) {
				$count	=	preg_match_all( $regex, $this->$item, $matches, PREG_SET_ORDER);
				
				if ( $count ) {
					$uri	=	DunUri :: getInstance( get_systemurl(), 1 );
					$uri->setPath( rtrim( $uri->getPath(), '/' ) . '/assets/js/bootstrap.min.js' );
					
					// Lets add to our stack
					$data['bootstrap']	=	(object) array(
							'search'		=>	$regex,
							'replace'		=>	$uri->toString(),
							'replaceall'	=>	true,
							'noprepend'		=>	true,
							'scheme'		=>	true
					);
					$config->set( 'bootstrapenable', '1' );
				}
				
			}
			
		}
		
		return $data;
	}
	
	
	/**
	 * Method for getting our WHMCS character set
	 * @access		private
	 * @version		3.1.00
	 * 
	 * @return		string
	 * @since		2.5.11
	 */
	private function _getCharset()
	{
		$wconfig	=	dunloader( 'config', true );
		$using		=	strtoupper( $wconfig->get( 'Charset' ) );
		$list		=	array(
				'7BIT', '8BIT', 'ASCII', 'BASE64', 'BIG-5', 'BYTE2BE', 'BYTE2LE', 'BYTE4BE', 'BYTE4LE', 'CP50220', 'CP50220RAW', 'CP50221', 'CP50222', 'CP51932', 'CP866', 'IBM866', 'CP932', 'CP936', 'CP950', 'EUC-CN', 'EUC-JP', 'EUCJP-WIN', 'EUC-KR', 'EUC-TW', 'GB18030', 'HTML-ENTITIES', 'HZ', 'ISO-2022-JP', 'ISO-2022-JP-MS', 'ISO-2022-KR', 'ISO-8859-1', 'ISO-8859-10', 'ISO-8859-13', 'ISO-8859-14', 'ISO-8859-15', 'ISO-8859-2', 'ISO-8859-3', 'ISO-8859-4', 'ISO-8859-5', 'ISO-8859-6', 'ISO-8859-7', 'ISO-8859-8', 'ISO-8859-9', 'JIS', 'JIS-MS', 'KOI8-R', 'SJIS', 'SJIS-WIN', 'UCS-2', 'UCS-2BE', 'UCS-2LE', 'UCS-4', 'UCS-4BE', 'UCS-4LE', 'UHC', 'CP949', 'UTF-16', 'UTF-16BE', 'UTF-16LE', 'UTF-32', 'UTF-32BE', 'UTF-32LE', 'UTF-7', 'UTF7-IMAP', 'UTF-8', 'WINDOWS-1251', 'CP1251', 'WINDOWS-1252', 'CP1252'
		);
		
		return in_array( $using, $list ) ? $using : false;
	}
	
	
	/**
	 * Method for getting a replacement URL for use in regexes
	 * @access		private
	 * @version		3.1.00 ( $id$ )
	 * @param		string		- $type: what we want [imgurl|joomlaurl]
	 *
	 * @return		string of URL
	 * @since		3.1.00
	 */
	private function _getReplacementurl( $type )
	{
		$config	=	dunloader( 'config', 'integrator' );
		$ssl	=	is_ssl();
		$url	=	null;
		
		switch ( $type ) :
		case 'imgurl' :
			$tmp	=	$config->get( 'customimageurl', '0' ) == '1' ? $config->get( 'integratorurl' ) : $config->get( 'imageurl' );
			$uri	=	DunUri :: getInstance( $tmp, true );
			$uri->setScheme( 'http' . ( $ssl ? 's' : '' ) );
			$url	=	$uri->toString();
			break;
		case 'integratorurl' :
			$url	=	$config->get( 'integratorurl' );
			break;
		endswitch;
		
		return $url;
	}
	
	
	/**
	 * Method for getting a variable from smarty
	 * @access		private
	 * @version		3.1.00 ( $id$ )
	 * @param		string		- $setting: what we need
	 * @param		mixed		- $default: if not set we can return a default state
	 *
	 * @return		mixed value of setting sought
	 * @since		3.0.10
	 */
	private function _getvar( $setting, $default = false )
	{
		global $smarty;
	
		// See if smarty is an object
		if (! is_object( $smarty ) || ! is_a( $smarty, 'Smarty' ) ) {
			/*$ca	= $GLOBALS['ca'];
	
			$reflect	=	new ReflectionObject( $ca );
			$property	=	$reflect->getProperty( 'templatevars' );
	
			$property->setAccessible( true );
			$tpl_vars	=	$property->getValue( $ca );
			*/
			$tpl_vars	=	array();
		}
		else {
			$tpl_vars	=	$smarty->_tpl_vars;
		}
	
	
		return isset( $tpl_vars[$setting] ) ? $tpl_vars[$setting] : $default;
	}
	
	
	private function _parsedata( $match, $replace, $replaceall = false, $noprepend = false, $scheme = false )
	{
		$data	=	new stdClass();
		$data->find		=	$match[0];
		$data->replace	=	null;
		
		if ( $replaceall ) {
			$data->replace	=	$match['front'] . $replace . $match['back'];
			return $data;
		}
		
		$founduri	=	DunUri :: getInstance( $match['link'], true );
		$replaceuri	=	DunUri :: getInstance( $replace, true );
		
		if ( $founduri->isFragment() ) {
			$data->replace	=	$match[0];
			return $data;
		}
		
		if ( $founduri->getPath() ) {
			$founduri->setPath( '/' . ltrim( $founduri->getPath(), '/' ) );
		}
		
		// If we must replace the scheme 
		if ( $noprepend ) {
			
			// Host found
			if ( $founduri->getHost() ) {
				
				// See if the found host is the same as our joomla host 
				if ( $this->integratoruri->getHost() == $founduri->getHost() ) {
					$founduri->setPath( $this->_checkDuplicatePaths( $founduri->getPath(), $replaceuri->getPath() ) );
					$founduri->setHost( $replaceuri->getHost() );
				}
			}
			// No host found
			else {
				$founduri->setPath( $this->_checkDuplicatePaths( $founduri->getPath(), $replaceuri->getPath() ) );
				$founduri->setHost( $replaceuri->getHost() );
			}
			
			// Be sure the scheme is set
			$founduri->setScheme( $replaceuri->getScheme() );
			$fullurl	=	$this->_buildUrl( $founduri );
			$data->replace	=	$match['front'] . $fullurl . $match['back'];
			return $data;
		}
		
		if ( $founduri->getScheme() ) {
			if ( $scheme && $founduri->getScheme() != 'javascript' ) {
				$founduri->setScheme( $replaceuri->getScheme() );
			}
			
			$fullurl	=	$this->_buildUrl( $founduri );
			$data->replace	=	$match['front'] . $fullurl . $match['back'];
			return $data;
		}
		else {
			$founduri->setScheme( $replaceuri->getScheme() );
			$founduri->setHost( $replaceuri->getHost() );
		}
		
		if ( ( $replaceuri->getPath() ) && ( $founduri->getPath() ) ) {
			$founduri->setPath( $this->_checkDuplicatePaths( $founduri->getPath(), $replaceuri->getPath() ) );
		}
		
		$fullurl	=	$this->_buildUrl( $founduri );
		$data->replace	=	$match['front'] . $fullurl . $match['back'];
		return $data;
	}
	
	
	/**
	 * Method to check for utf8 encoding (faster than regex)
	 * @access		private
	 * @version		3.1.00 ( $id$ )
	 * @param		string		- $Str: what we are checking
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	private function _utf8check( $Str )
	{
		for ($i=0; $i<strlen($Str); $i++)
		{
		if ( ord($Str[$i]) < 0x80 ) continue; # 0bbbbbbb
		elseif ( (ord($Str[$i]) & 0xE0) == 0xC0 ) $n=1; # 110bbbbb
		elseif ( (ord($Str[$i]) & 0xF0) == 0xE0 ) $n=2; # 1110bbbb
		elseif ( (ord($Str[$i]) & 0xF8) == 0xF0 ) $n=3; # 11110bbb
		elseif ( (ord($Str[$i]) & 0xFC) == 0xF8 ) $n=4; # 111110bb
		elseif ( (ord($Str[$i]) & 0xFE) == 0xFC ) $n=5; # 1111110b
		else return false; # Does not match any model
		
		for ( $j=0; $j<$n; $j++ )
		{ # n bytes matching 10bbbbbb follow ?
			if ( (++$i == strlen($Str)) || ((ord($Str[$i]) & 0xC0) != 0x80) )
			return false;
		}
		}
		return true;
	}
	
	
	/**
	 * Method to convert a string to UTF-8
	 * @access		private
	 * @version		3.1.00 ( $id$ )
	 * @param		string		- $string: what we want to convert
	 *
	 * @return		string
	 * @since		3.1.00
	 */
	private function _utf8convert( $string )
	{
		// Test first - if we dont have these we can do nothing
		if (! function_exists( 'iconv' ) || ! function_exists( 'mb_detect_encoding' ) ) {
			$this->unicode = null;
			return $string;
		}
		
		// Get WHMCS characterset
		$nativeset	=	$this->_getCharset();
		$native		=	$nativeset == 'UTF-8';
		$ourstring	=	$this->_utf8check( $string );
		
		// Test to see if we are already UTF8
		if ( $native && $ourstring ) {
			return $string;
		}
		
		// Determine the string encoding
		if (! $ourstring ) {
			// Detect our string encoding
			$encoding	=	mb_detect_encoding( $string, 'auto', true );
			
			if (! $encoding ) {
				$this->unicode = null;
				return $string;
			}
		}
		else {
			$encoding = 'UTF-8';
		}
		
		// Convert our string
		$result	=	iconv( strtoupper( $encoding ), $nativeset . '//TRANSLIT', $string );
		
		if (! $result ) {
			$this->unicode = null;
			return $string;
		}
		
		return $result;
	}
}