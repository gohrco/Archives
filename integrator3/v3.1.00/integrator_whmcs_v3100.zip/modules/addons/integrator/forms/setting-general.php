<?php


$form	= array(
		'enable'		=> array(
				'order'			=> 10,
				'type'			=> 'toggleyn',
				'value'			=> true,
				'validation'	=> '',
				'labelon'		=> 'integrator.form.toggleyn.enabled',
				'labeloff'		=> 'integrator.form.toggleyn.disabled',
				'label'			=> 'integrator.admin.form.settings.label.enable',
				'description'	=> 'integrator.admin.form.settings.description.enable',
				),
 		'debug'		=> array(
 				'order'			=> 20,
 				'type'			=> 'toggleyn',
 				'value'			=> true,
 				'validation'	=> '',
 				'labelon'		=> 'integrator.form.toggleyn.enabled',
 				'labeloff'		=> 'integrator.form.toggleyn.disabled',
 				'label'			=> 'integrator.admin.form.settings.label.debug',
 				'description'	=> 'integrator.admin.form.settings.description.debug',
 		),
		'integratorurl'	=> array(
				'order'			=> 30,
				'type'			=> 'text',
				'value'			=> null,
				'validation'	=> '',
				'label'			=> 'integrator.admin.form.settings.label.integratorurl',
				'description'	=> 'integrator.admin.form.settings.description.integratorurl',
		),
		'apitoken'	=> array(
				'order'			=> 40,
				'type'			=> 'password',
				'value'			=> null,
				'validation'	=> '',
				'label'			=> 'integrator.admin.form.settings.label.apitoken',
				'description'	=> 'integrator.admin.form.settings.description.apitoken',
		),
		'cnxnid'	=> array(
				'order'			=> 50,
				'type'			=> 'text',
				'value'			=> null,
				'validation'	=> '',
				'label'			=> 'integrator.admin.form.settings.label.cnxnid',
				'description'	=> 'integrator.admin.form.settings.description.cnxnid',
		),
	);