<?php defined('_JEXEC') or die('Restricted access'); ?>

<div class="width-60 fltlft">
	<fieldset class="adminform">
		
		<?php if (! empty( $this->debug ) ) : ?>
		
		<legend><?php echo JText::_( "INTEGRATOR_DEFAULT_DEBUG_HEAD" ); ?></legend>
		
		<span><?php echo JText::_( "INTEGRATOR_DEFAULT_DEBUG_DESC" ); ?></span>
		
		<ul class="adminformlist">
		
		<?php $cnt = 0; ?>
		<?php foreach ( $this->debug as $debug ) : ?>
		
		<li class="debug_item debug_<?php echo $debug['type']; ?>">
			<div class="debug_message">[<?php echo $debug['type']; ?>] <?php echo $debug['message']; ?></div>
			<div class="debug_details"><?php echo $debug['filename']; ?> @ line <?php echo $debug['line']; ?></div>
			<div style="clear: both; line-height: 1px; ">&nbsp;</div>
		</li>
		
		<?php endforeach; ?>
		
		</ul>
		
		<?php endif; ?>
		
	</fieldset>
</div>

<div class="width-40 fltrt">
	<fieldset class="adminform">
		<legend><?php echo JText::_( "INTEGRATOR_DEFAULT_API_HEAD" ); ?></legend>
		<ul class="adminformlist">
		<li>
			<span><?php echo JText::_( "INTEGRATOR_DEFAULT_API_DESC" ); ?></span><br/>
			<textarea rows="10" cols="40" id="apiresult" class="readonly" readonly="readonly" style="color: <?php echo ( $this->status === true ? "DarkGreen" : "DarkRed" ) ?>;">
				<?php echo ( $this->status === true ? "Successfully Connected" : $this->status ); ?>
			</textarea>
		</li>
		</ul>
	</fieldset>
</div>

<form action="index.php" method="post" name="adminForm">
<input type="hidden" name="option" value="com_integrator" />
<input type="hidden" name="controller" value="default" />
<input type="hidden" name="task" value="" />
</form>