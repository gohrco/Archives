<?php
/**
 * Integrator 3
 * Authentication - Integrator Plugin Script
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.00 ( $Id: integrator_user.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.9
 *
 * @desc       This is the installation script executed by Joomla! 2.5+
 *
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( "joomla.filesystem.file" );


/**
 * plgauthenticationjwhmcs_auth installation Script
 * @version		3.1.00
 *
 * @since		3.0.9
 * @author		Steven
 */
if (! class_exists( 'plgauthenticationintegrator_authInstallerScript' ) ) {	// Workaround for Installation purposes
	class plgauthenticationintegrator_authInstallerScript
	{
		/**
		 * Run at the time of upgrade only
		 * @access		public
		 * @version		3.1.00
		 * @param		JApplication object	- $parent: calls this function
		 *
		 * @since		3.0.9
		 */
		public function install( $parent )
		{
			return;
		}


		/**
		 * Run at the time of uninstallation only
		 * @access		public
		 * @version		3.1.00
		 * @param		JApplication object	- $parent: calls this function
		 *
		 * @since		3.0.9
		 */
		public function uninstall( $parent )
		{
			return;
		}


		/**
		 * Run at the time of upgrade only
		 * @access		public
		 * @version		3.1.00
		 * @param		JApplication object	- $parent: calls this function
		 *
		 * @since		3.0.9
		 */
		public function update( $parent )
		{
			return;
		}


		/**
		 * Runs prior to installation, upgrade or uninstallation
		 * @access		public
		 * @version		3.1.00
		 * @param		string				- $type: the task being performed (install, upgrade etc)
		 * @param		JApplication object	- $parent: calls this function
		 *
		 * @since		3.0.9
		 */
		public function preflight( $type, $parent )
		{
			return;
		}


		/**
		 * Runs after installation, upgrade
		 * @access		public
		 * @version		3.1.00
		 * @param		string				- $type: the task being performed (install, upgrade etc)
		 * @param		JApplication object	- $parent: calls this function
		 *
		 * @since		3.0.9
		 */
		public function postflight( $type, $parent )
		{
			$path			=	JPATH_PLUGINS		. DIRECTORY_SEPARATOR
			.	'authentication'		. DIRECTORY_SEPARATOR
			.	'integrator_auth'		. DIRECTORY_SEPARATOR;

			JFile :: move( 'integrator_auth_30.xml', 'integrator_auth.xml', $path );
			return;
		}
	}
}