<?php

$form['modify/userfields']	= array(
	'email' => array(
			'apiname'		=> 'newemail',
			'value'			=> null,
			'order'			=> 10,
			'type'			=> 'text',
			'validation'	=> 'required|valid_email',
			'lang'			=> 'userinfo.email',
			'desc'			=> 'userinfo.email.desc'
		),
	'username' => array(
			'apiname'		=> 'newusername',
			'value'			=> null,
			'order'			=> 20,
			'type'			=> 'text',
			'validation'	=> 'required',
			'lang'			=> 'userinfo.username',
			'desc'			=> 'userinfo.username.desc',
		),
	'name' => array(
			'apiname'		=> 'newname',
			'value'			=> null,
			'order'			=> 30,
			'type'			=> 'text',
			'validation'	=> 'required',
			'lang'			=> 'userinfo.name',
			'desc'			=> 'userinfo.name.desc'
		),
);

$form['create/userfields']	= array(
	'email' => array(
			'apiname'		=> 'newemail',
			'value'			=> null,
			'order'			=> 10,
			'type'			=> 'text',
			'validation'	=> 'required|valid_email'
		),
	'username' => array(
			'apiname'		=> 'newusername',
			'value'			=> null,
			'order'			=> 20,
			'type'			=> 'text',
			'validation'	=> 'required'
		),
	'password' => array(
			'apiname'		=> 'password',
			'value'			=> null,
			'order'			=> 30,
			'type'			=> 'password',
			'validation'	=> 'required'
	),
	'name' => array(
			'apiname'		=> 'newname',
			'value'			=> null,
			'order'			=> 40,
			'type'			=> 'text',
			'validation'	=> 'required'
		),
);