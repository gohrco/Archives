<div id="subheader">
	<strong><?php echo lang( $content_header ); ?></strong> :: <?php echo lang( $content_subheader ); ?>
</div>

<?php if ( $info_message ) : ?>
<div id="infomsg">
	<?php echo $info_message;?>
</div>
<?php endif; ?>

<?php if ( $alert_message ) : ?>
<div id="alertmsg">
	<?php echo $alert_message; ?>
</div>
<?php endif; ?>

<?php if ( $notice_message ) : ?>
<div id="noticemsg">
	<?php echo $notice_message;?>
</div>
<?php endif; ?>

<?php if ( $success_message ) : ?>
<div id="successmsg">
	<span>
		<?php echo $success_message;?>
	</span>
</div>
<script>jQuery("#successmsg").delay('4000').slideToggle('3000');</script>
<?php endif; ?>

