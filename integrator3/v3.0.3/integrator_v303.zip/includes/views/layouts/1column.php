<div class="span12">
	
	<?php foreach ( $data as $item ) : ?>
	
	<div class="box">
	
	<?php echo heading ( $item->heading, '2' ); ?>
	
	<?php echo $item->body; ?>
	
	</div>
	
	<?php endforeach; ?>
	
</div>