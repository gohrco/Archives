
<?php if ( isset( $menu ) ) : ?>

<div class="navbar">
	<div class="navbar-inner">
		<div class="navbar-container">
			<ul class="nav">
				
				<?php foreach ( $menu as $item ) : ?>
				
				<?php if ( isset( $item->submenu ) ) : ?>
				
				<li class="dropdown<?php echo ( $item->current ? ' active' : '' ); ?>">
					
					<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
						<i class="icon-<?php echo $item->class; ?>"></i>
						<span class="hidden-phone"><?php echo $item->text; ?></span>
						<b class="caret"></b>
					</a>
					
					<ul class="dropdown-menu">
						
						<?php foreach ( $item->submenu as $subitem ) : ?>
							
							<li class="<?php echo ( $subitem->current ? 'active' : '' ); ?>">
								
								<a href="<?php echo site_url( $subitem->anchor ); ?>">
									<i class="icon-<?php echo $subitem->class; ?>"></i>
									<span><?php echo $subitem->text; ?></span>
								</a>
								
							</li>
							
						<?php endforeach; ?>
						
					</ul>
					
				</li>
				
				<?php else : ?>
				
				<li class="<?php echo ( $item->current ? 'active' : '' ); ?>">
				
					<a href="<?php echo site_url( $item->anchor ); ?>">
						<i class="icon-<?php echo $item->class; ?>"></i>
						<span class="hidden-phone"><?php echo $item->text; ?></span>
					</a>
				
				<?php endif; ?>
				
				<?php endforeach; ?>
				
			</ul>
		</div>
	</div>
</div>

<?php endif; ?>
