<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.3 ( $Id: prefs.php 3 2012-04-19 14:16:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file is a custom button for the preferences button allowing javascript to run upon closure of the window
 *             Joomla 1.5 specific - not used for Joomla 1.6+
 */


/*-- Security Protocols --*/
defined('JPATH_BASE') or die();
/*-- Security Protocols --*/


/**
 * JButtonPrefs class object
 * @desc		Renders a popup window with javascript execution possible on closing (similar to J1.6+) 
 * @version		3.0.3
 * 
 * @since		3.0.0
 * @author		Steven
 */
class JButtonPrefs extends JButton
{
	/**
	 * Button type
	 * @access		protected
	 * @var			string
	 * @since		3.0.0
	 */
	var $_name = 'Prefs';
	
	
	/**
	 * Retrieves the button to render for the button bar
	 * @access		public
	 * @version		3.0.3
	 * @param		string		- $type: string containing the type of button to render
	 * @param		string		- $name: the name of the button
	 * @param		string		- $text: the text name used for the button
	 * @param		string		- $url: the url of the window to popup
	 * @param		integer		- $width: the width of the window
	 * @param		integer		- $height: the height of the window
	 * @param		integer		- $top: space from the top
	 * @param		integer		- $left: space from the left
	 * @param		string		- $onClose: JavaScript function to perform on closure
	 * 
	 * @return		string containing HTML for button
	 * @since		3.0.0
	 */
	public function fetchButton( $type = 'Prefs', $name = '', $text = '', $url = '', $width = 640, $height = 480, $top = 0, $left = 0, $onClose = '' )
	{
		JHtml::_('behavior.modal');

		$text	= JText::_($text);
		$class	= $this->fetchIconClass($name);
		$doTask	= $this->_getCommand($name, $url, $width, $height, $top, $left);

		$html	= "<a class=\"modal\" href=\"$doTask\" rel=\"{handler: 'iframe', size: {x: $width, y: $height}, onClose: function() {".$onClose."}}\">\n";
		$html .= "<span class=\"$class\">\n";
		$html .= "</span>\n";
		$html	.= "$text\n";
		$html	.= "</a>\n";

		return $html;
	}

	/**
	 * Retrieves the button id
	 * @access		public
	 * @version		3.0.3
	 * @param		string		- $name: the name of the button clicked
	 * 
	 * @return		string containing the button css id
	 * @since		3.0.0
	 */
	public function fetchId($name)
	{
		return $this->_parent->_name.'-'."popup-$name";
	}
	
	
	/**
	 * Get the JavaScript command for the button
	 * @access		private
	 * @version		3.0.3
	 * @param		object		- $definition: Button definition
	 * 
	 * @return		string containing JavaScript command string
	 * @since		3.0.0
	 */
	private function _getCommand($name, $url, $width, $height, $top, $left)
	{
		if (substr($url, 0, 4) !== 'http') {
			$url = JURI::base().$url;
		}

		return $url;
	}
}
