<div class="mod-intlogin">
	
	<?php if ( $params->get( 'enable_gravatar', false ) ) : ?>
	
		<div class="grav-wrap" style="width: <?php echo $params->get( 'grav_size', '80' ); ?>px; " >
			
			<?php echo $gravatar->url; ?><br/>
			
			<small><small><a href="<?php echo $gravatar->option; ?>" title="<?php echo JText::sprintf( 'MOD_INTLOGIN_GRAVATAR_TITLE', ( $gravatar->enabled ? JText::_( 'MOD_INTLOGIN_GRAVATAR_DISABLE' ) : JText::_( 'MOD_INTLOGIN_GRAVATAR_ENABLE' ) ) ) ; ?>">
									<?php echo strtolower( ( $gravatar->enabled ? JText::_( 'MOD_INTLOGIN_GRAVATAR_DISABLE' ) : JText::_( 'MOD_INTLOGIN_GRAVATAR_ENABLE' ) ) ); ?></a></small></small>
			
		</div>
	
	<?php endif; ?>
	
	<ul>
		
		<?php foreach( $rows as $class => $items ) : ?>
		
		<?php if ( ! $params->get( 'display_address', true ) && in_array( $class, array( 'company', 'add1', 'add2', 'add3', 'add4' ) ) ) continue; ?>
		
		<li class="<?php echo $class; ?>">
			
			<?php foreach ( $items as $item ) : ?>
				
				<?php if ( $params->get( 'greeting', false ) && $class == 'usr1' ) : ?>
					
					<span class="greeting"><?php echo JText :: _( 'MOD_INTLOGIN_USERNAMEGREETING' ); ?></span>
					
				<?php endif; ?>
				
				<span class="<?php echo $item; ?>" id="mod-intlogin-<?php echo $item; ?>"><?php echo $info->$item; ?></span>
				
				<?php if ( $params->get( 'greeting', false ) && $class == 'name' && ( $item == 'lastname' || ( $item == 'fullname' && ! empty( $info->fullname ) ) || $item == 'username' ) ) : ?>
					
					<span class="greeting"><?php echo JText :: _( 'MOD_INTLOGIN_GREETING' ); ?></span>
					
				<?php endif; ?>
				
			<?php endforeach; ?>
			
		</li>
		
		<?php endforeach; ?>
		
	</ul>
	
	<form action="<?php echo $form->logout; ?>" method="post" name="login" id="login-form">
		
		<div class="logout-button">
			
			<input type="submit" name="Submit" class="button" value="<?php echo JText::_( "MOD_INTLOGIN_BTN_LOGOUT" ); ?>" />
			
		</div>
		
		<input type="hidden" name="_c" value="<?php echo $form->origin; ?>" />
		
	</form>

</div>