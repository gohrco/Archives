<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.11 ( $Id: process.php 192 2013-02-01 15:26:04Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the install controller for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Install controller 
 * @version		3.0.11
 *  
 * @since		3.0.0
 * @author		Steven
 */
class Process extends MY_Controller
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.11
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Checks to see if this is an upgrade or an install
	 * @access		public
	 * @version		3.0.11
	 * 
	 * @since		3.0.0
	 */
	public function index()
	{
		if ( $this->_is_upgrade() ) {
			redirect( 'upgrade' );
		}
		else {
			redirect( 'process/step1' );
		}
	}
	
	
	/**
	 * First step asking for acceptance of TOS
	 * @access		public
	 * @version		3.0.11
	 * 
	 * @since		3.0.0
	 */
	public function step1()
	{
		$fields	= & $this->fields_library;
		$fields->load( 'install/tos' );
		
		$this->form_validation->set_rules( $fields->validation() );
		
		$valid	= $this->form_validation->run();
		
		if ( $valid == true ) {
			$this->session->set_userdata( 'tosaccet', time() );
			redirect('process/step2', 'refresh');
		}
		else if ( validation_errors() ) {
			error_message( 'error.tosaccept' );
		}
		
		$data				= $fields->render();
		$data['action']		= 'process/step1';
		$data['header']		= 'process.step1.hdr';
		$data['buttons']	= $this->build_buttons();
		
		//$this->build_page();
		$this->template
					->set_partial( 'body', 'layouts/tos' )
					->build( 'install', $data );
	}
	
	
	/**
	 * Second step in installation asking for database info
	 * @access		public
	 * @version		3.0.11
	 * 
	 * @since		3.0.0
	 */
	public function step2()
	{
		$fields	= & $this->fields_library;
		$fields->load( 'install/database' );
		
		if ( isset( $_POST['db_username'] ) ) {
			$_POST['db_username'] = base64_decode( $_POST['db_username'] );
		}
		
		if ( isset( $_POST['db_password'] ) ) {
			$_POST['db_password'] = base64_decode( $_POST['db_password'] );
		}
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == true ) {
			$this->session->set_userdata( 'tosaccet', time() );
			$this->session->set_userdata( 'hostname', $this->input->post( 'db_hostname' ) );
			$this->session->set_userdata( 'username', base64_encode( $this->input->post( 'db_username' ) ) );
			$this->session->set_userdata( 'password', base64_encode( $this->input->post( 'db_password' ) ) );
			$this->session->set_userdata( 'port', $this->input->post( 'db_port' ) );
			
			if ( $this->install->test_db_connection() ) {
				redirect( 'process/step3', 'refresh' );
			}
			else {
				error_message( 'error.dbinvalid' );
			}
		}
		
		$data				= $fields->render();
		$data['action']		= 'process/step2';
		$data['header']		= 'process/step2.hdr';
		$data['buttons']	= $this->build_buttons();
		
		$js	= <<< JS
<script type="text/javascript">
jQuery('#adminForm').submit( function() {
	jQuery('#db_username').val( jQuery.base64.encode( jQuery('#db_username').val()));
	jQuery('#db_password').val( jQuery.base64.encode( jQuery('#db_password').val()));
});
</script>
JS;
		
		$this->template
					->append_javascript( bootstrap( 'functions.js', 'js' ) )
					->append_javascript( bootstrap( 'jquery.base64.min.js', 'js' ) )
					->append_javascript( '<script type="text/javascript">jQuery( document ).ready( validateDatabase() );</script>' )
					->append_javascript( $js )
					->set_partial( 'body', 'layouts/installform' )
					->build( 'install', $data );
	}
	
	
	/**
	 * Third step in installation checking system requirements
	 * @access		public
	 * @version		3.0.11
	 * 
	 * @since		3.0.0
	 */
	public function step3()
	{
		$fields	= & $this->fields_library;
		$fields->load( 'install/reqs' );
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == true ) {
			redirect('process/step4', 'refresh');
		}
		
		$tests	= $this->install->server_tests();
		$fields->set_values( $tests );
		
		$items	= array();
		$items['php']		= (object) array( 'use' => $tests->php,		'msg' => sprintf( lang( ( $tests->php ? 'msg' : 'error' ) . '.php' ), $this->install->php_version ) );
		$items['mysql']		= (object) array( 'use' => $tests->mysql,	'msg' => sprintf( lang( ( $tests->mysql ? 'msg' : 'error' ) . '.mysql' ), $this->install->mysql_server_version, $this->install->mysql_client_version ) );
		$items['curl']		= (object) array( 'use' => $tests->curl,	'msg' => lang( ( $tests->curl ? 'msg' : 'error' ) . '.curl' ) );
		$items['ioncube']	= (object) array( 'use' => $tests->ioncube,	'msg' => sprintf( lang( ( $tests->ioncube ? 'msg' : 'error' ) . '.ioncube' ), $this->install->ioncube_version ) );
		
		$data				= $fields->render();
		$data['items']		= $items;
		$data['action']		= 'process/step3';
		$data['header']		= 'process/step3.hdr';
		$data['buttons']	= $this->build_buttons();
		
		$this->template
					->set_partial( 'body', 'layouts/installreqs' )
					->build( 'install', $data );
	}
	
	
	/**
	 * Fourth step for install checking file permisssions
	 * @access		public
	 * @version		3.0.11
	 * 
	 * @since		3.0.0
	 */
	public function step4()
	{
		$fields = & $this->fields_library;
		$fields->load( 'install/dirs' );
		
		$this->form_validation->set_message( 'required', lang( 'reqd.perms' ) );
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == true ) {
			redirect( 'process/step5', 'refresh' );
		}
		
		$files	= $this->install->config_test();
		$dirs	= $this->install->directory_tests();
		$valid	= true;
		foreach ( $dirs as $d ) {
			if ( $d->use === false ) $valid = false;
		}
		
		$fields->set_values( array( 'files' => $files, 'dirs' => $valid ) );
		
		$fmsg	= ( is_string( $files ) ? 'error.' . $files : ( $files ? 'msg' : 'error' ) ) . '.files';
		$fmsg	= sprintf( lang( $fmsg ), BASEPATH );
		
		$items	= array();
		$items['files']		= (object) array( 'use' => ( is_string( $files ) ? false : $files ),	'msg' => $fmsg );
		$items['dirs']		= $dirs;
		
		$data				= $fields->render();
		$data['items']		= $items;
		$data['action']		= 'process/step4';
		$data['header']		= 'process/step4.hdr';
		$data['buttons']	= $this->build_buttons();
		
		$this->template
					->set_partial( 'body', 'layouts/installreqs' )
					->build( 'install', $data );
	}
	
	
	/**
	 * The last step requiring information for install
	 * @access		public
	 * @version		3.0.11
	 * 
	 * @since		3.0.0
	 */
	public function step5()
	{
		$fields = & $this->fields_library;
		$fields->load( 'install/install' );
		
		$this->form_validation->set_rules( $fields->validation() );
		
		if ( $this->form_validation->run() == true ) {
			// Perform installation here
			if ( $this->install->run() === true ) {
				$baseurl = rtrim( base_url(), '/' );
				$pcs = explode( '/', $baseurl );
				array_pop( $pcs );
				$baseurl = implode( '/', $pcs );
				
				redirect( $baseurl . '/index.php/admin/complete', 'refresh' );
			}
			else {
				show_error( $this->install->get_error() );
			}
		}
		
		$data				= $fields->render();
		$data['action']		= 'process/step5';
		$data['header']		= 'process/step5.hdr';
		$data['buttons']	= $this->build_buttons();
		
		$this->build_page();
		$this->template
					->append_javascript( bootstrap( 'functions.js', 'js' ) )
					->append_javascript( '<script type="text/javascript">jQuery( document ).ready( verifyDatabase() );</script>' )
					->set_partial( 'body', 'layouts/installform' )
					->build( 'install', $data );
	}
	
	
	/**
	 * Checks to see if this is an upgrade or install
	 * @access		public
	 * @version		3.0.11
	 * 
	 * @return		boolean true if upgrade, false if new install, redirect if already installed
	 * @since		3.0.0
	 */
	private function _is_upgrade()
	{
		// start by checking for configuration file
		if ( file_exists( BASEPATH . 'configuration.php' ) ) {
			$version = $this->install->get_previous_version();
			
			// Catch 5 digit versions and break
			if ( strlen( $version ) > 5 ) {
				$version = substr( $version, 0, 5 );
			}
			
			if ( in_array( $version, array( false, null ) ) ) return false;
			
			switch( version_compare( $version, INTEGRATOR_INSTALL ) ):
			// --------------------------------
			// Upgrade in order (newer vers in install)
			case -1:
				return true;
			break;
			// --------------------------------
			// Same version as installed (0) or installed version is newer than install folder (1)
			case 0:
			case 1:
				$baseurl = rtrim( base_url(), '/' );
				$pcs = explode( '/', $baseurl );
				array_pop( $pcs );
				$baseurl = implode( '/', $pcs );
				
				redirect( $baseurl . '/index.php/admin/complete/true', 'refresh' );
			break;
			// --------------------------------
			endswitch;
		}
		
		return false;
	}
}