
UPDATE IGNORE `__DBPREFIX__settings` SET `value`='3.0.10' WHERE `key` = 'Version';
