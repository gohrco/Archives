<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class to generate an opening fieldset tag
 * @version		3.0.11
 * 
 * @since		3.0.8
 * @author		Steven
 */
class FieldsetField extends form_definition
{
	/**
	 * Indicates which type of fieldset (open == true, close == false)
	 * @access		public
	 * @since		3.0.8
	 * @var			boolean
	 */
	public	$state	= true;
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.0.11
	 * @param		array		- $options: contruction options
	 * 
	 * @since		3.0.8
	 */
	public function __construct( $options = array() )
	{
		parent::__construct( $options );
	}
	
	
	/**
	 * Method to generate a description
	 * @access		protected
	 * @version		3.0.11
	 * 
	 * @return		null
	 * @since		3.0.8
	 * @see			form_definition :: description()
	 */
	protected function description()
	{
		return null;
	}
	
	
	/**
	 * Method to generate a form field
	 * @access		protected
	 * @version		3.0.11
	 * 
	 * @return		string
	 * @since		3.0.2
	 * @see			form_definition::field()
	 */
	protected function field()
	{
		$field	= ( $this->state ? '<fieldset>' : '</fieldset>' );
		
		return $field;
	}
	
	
	/**
	 * Method to generate a label
	 * @access		public
	 * @version		3.0.11
	 *
	 * @return		null
	 * @since		3.0.8
	 * @see			form_definition :: label()
	 */
	public function label()
	{
		return null;
	}
	
	
	/**
	 * Sets the arguments for the form field
	 * @access		public
	 * @version		3.0.11
	 * @param		array		- $data: contains arguments set by the loaded form
	 *
	 * @return		array containing unused arguments
	 * @since		3.0.2
	 * @see			form_definition :: set_arguments()
	 */
	public function set_arguments( $data = array() )
	{
		if ( isset( $data['state'] ) ) {
			$this->state = ( $data['state'] == 'open' ? true : false );
			unset( $data['state'] );
		}
		
		return $data;
	}
}