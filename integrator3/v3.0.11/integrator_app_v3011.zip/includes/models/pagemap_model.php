<?php //00923
/**
 * ---------------------------------------------------------------------
 * Integrator v3.0
 * ---------------------------------------------------------------------
 * 2009 - 2012 Go Higher Information Services.  All rights reserved.
 * 2013 March 11
 * version 3.0.11
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cP/5juqcFwTTkGhHsQd2J4UT2ubo4pxtOGiaglL/dKy0irFMqeDxwIZzthDC98tPvqTEQC/eS
wu+KG5dW4yCBnHfsma1Mae77zz/WLLLlMBE6BwaUDdQ2kAAJikYyJdQYcwqoEi7cyBc1Pz5T3+sS
M5ySAnXcQjOHAVyOj+B2+bFPW4FdKSjKwGhQ6qIVeOwUjSfmehnpCl1n6FvXpP+vUUlK7f6+J0kK
3Y5Wt46q+/X+pgcgEUhjZ4djqwwNiadnULhLP1RprwG3RdIgGumku5xYZD8klJ342Vy7oINHW7T4
UohqA1S/MDm6TK5CntsEygkZ3NUZPIqxqjiRThEgI/ONqjLRmr9Y/bEk4yjHZh8iDm+TXYYkgOPO
ATKC4UMr1hFBRiUB30Vji/FjimJJg32DSkt+UVFrFkyf+moQwXF3AwfSQ+J+XX3ay+dbmZgNyrmB
9S1/xKsCMoYydgwMQ0hRodIevx6uZfXNFRoLmAoV33Q2GbRxth46ZNl+7jYsXXNpkdgf6DaswcdS
ENZdCOzPeqT2hepTULf22qt8LVjp7c8PsX/b9N1gtTQdXkxpUpcyNm++7tRMUMZkbxSBMvwzaJ4V
cU8kr6RF6fOznlYUZRqR1COLxWW73WU4hosdwhzK7lC6CunlXq5P7vcm1JxVWaYlfA/Q5GpIOi3m
zYHsyvF6cwLwKOvDIgMPZqdGHWBVGMlPLKOOkGIkH2vCIH6t4vAvCyu1dSjhdqirv832NVxUwZBi
63k2DoUEpTmJ42sIWRwhWpSNpTYhpVfFJICMyabXEW2bZ+4XYN3/Xa3Ae0wwNqwb68hh+IlUcs02
+rrmH//eEoj+LXGdggXSX7aeqx5j3hg0FgcrTcBBPJyWtyYIIEOsuYtP4aKQXrHazgYNPPEbxoYC
KIau+K5RELpFS9DncRsYO54YvILqDZzFDTVu+NuIvbxZ9YYXQ3DIRJ/Vr4CDRaZO/D4zktL35dH9
Yhvb0aHVpRt/6x66V8P3jXrx3RQsXBP84KF4G4fY3mq2pF7UPqngFycnC+AXYqemtIu/NcdUe/1J
f0n/4Yvgnjr02A7ZtPlaT9JyH3Znpz355nxsxoNWnwR4ygH5imQZex727lHNOm0FHeJhAQW1WETF
au/H9PcCZzlkacC9qrLMjHOsiuHcSaUMoIKujwEUuc5L58YaV62aZvWtORSKXXQPoegeKwVy1bLu
6Dou7yVxog1dsdXZ9A9fQ4g1L07uuXG0nJjPX45+1yh737lA4vBWPpJZ4sBKQegMKD4kuQ39vA+k
VhxDqKPpeC90thMBYxOYJI4bSseY5BviO6jYQYuB7DvVIg0QS1h9H8R83RHzF+aqPb6Q+LfaMC6S
xd2bwScP5v0d4kH55yIDpmQSvPTPj7ZniLaYr9/6Gxke0ghM4bNdocy3urr7UEt+3oMHCSNXs1oy
uTQha3ys5QUsqUNQYsrEWYvZ0fGZKzyO2nLMJnm8JVLmxt5JrC/0E1VqkLKFRXEK5xVnt+9O5nyX
XsL0Sef5owlw21954z/RshsnXIGlhYYdbCreVbTZa6e+5hhXqJdaXNRzWOHfeCxCO2H3i+d8+rS2
XDMWlIrkb1tve85984UBetPDhNcrU99/DJ0zdesxsBjBi+hx8omnlFepHbd48T0LmkWQuwTOFNJt
pq+37CYs8XzlJHqZoj/GbkREnlk5RwsOuYWiReuc8qM1WOUCHzcba2rE7+eHMvuiS1BeMEBYl1z7
6GV2H5ruKYW0arvH7Xoaw+z/DUb7sn2Ieh7Jb8W2DHbXePKRhv1Q3vRU/AcMKXm/N5UvYogpljrx
EhcrP1PsXgqiHYSU72V6vJFnwaM3XU/5bN5D8JPI8UwjplsZpkKTxzY+ghUUvWBaAcd8i4gOg7e8
j8aAu4TedPSQk40bT60jzyvAGYbaQA8F+PgKNcv6MRXfma6NzUOM5ISux7o3z6iq+3CAI4/zcz3i
/A3B2odVlPytz0GDCankZ/v7EyLo56U0HI6UNpEyhgPFAv6zyojpYZJFA7S/Qt2AIrcibR9eWZMs
yALnUpCmeARBjn5/yC5jrH8CbEtjyYFI2ZaawmqHlXtoeVUrDcKn8FMOwTzIDXgnCZklb+Hkloub
vrE8pmgvt4S/SYfH1ec4K+/YwWKgUMtE6JFioJVdA/93TudGaaUtlz+jhr2hiDEidzviZfXNsEzN
gbnI697gjLhDdRG/KcK7GKyn6O3yKmSnyO5l64T6aCFeJ6UuLBfRCjdFXmpwg2g83hKX2cy+XC1k
U9S9fWYuYc2FrthrQZBLAGEPMHAws65+/xygOhOT+Xwe7AK1Z5+MA5dOrgEJvtMMlNvzFqSqPQgk
QcyhxZYOcmjKtWyuFTXLZP3qMMKBkEPJ9RbYkDFoGl3izeBxSyiDadoJHeAJ78RxwlUtDVXt8MKr
9FDHjK+mzU4TPnNdrAnru77YGEIcYA7l1ScARehfvOGqV1BzdiDHfo0P1xpKP/CWKB34EPqHYtc6
6vGi1xxoOfdpRPax8Q0KQRstOnzmQgX+RxqqKiPHQLNQMGNJCqnPEVn+yBmAKgAqx9YQspUcCHXC
HgXSagvwv1nN3IiFMna2w4hUfg1RoL6nApG5BpYLoI8lWa+bZBVO0wqAZfsCTu47jqzI3N16lhEk
to9M7QlRyJL2zBmX1WD7ijWTU/6PQ/9NzDG/O/C3fN1YJbqqgBrOVhzSDOGjJbOtYKOFZc9sGd2C
KHf1wKaxym9Xu0wnBJIeN8J2hQVSuW3e/YKluvwU/d0g89tHkwtghsMC+vMvBvgmijFYh+ANPXx9
+zO8KunRN959Jqi7CfdmomGioBrVt6rHo1Oryaex9EH982ewPR+lM5GLTCEjFukKpTKsjEWN7vP3
y17mykZM8tL6eTxTfy+ZszIyNRwUNKYFg15moCnISrS+qH4aERDeK/KOXJ9FNXRHVLioKd3hp/yr
mJjaECdDIqgprI+jKdDIFbCRLF8+L95KQAzz9WHYKCtd6VHE494HkNviwEk/Fq5IzmqlkFJZGnxQ
nx+bN6DUYcX2N+SZtQvUxtV/S1FXiOAuLnSYh2S0nQcy7ucCw2ZNRI0TiDlBHNGzg7SMysWioIa3
bwciKPU3BznpB9kiuMswAtWDJtU/e8j/T+5Ej3LJh2PwEjfVKB7zUxw2pV0XaUvwFQpyPvGLt3QN
nMoL4n5zUMWBeqxtZ3W5sHY3by3q+BaCl6ygQ2wB0XicA3EOoDsp6tP4e/ZrB0AFOMx5u8R3hX1Z
VQpDnB1OiZGd3WJrBsGdwadF6kW9glxId6LH+S2wjrICExZDkAtoihYEsV1u+B8rU5FG8q8S1n7I
kTcuFqHJOmd0v6WaVf84Drnl3DR5hMd6zO1Y7K65tasYj2TiYQRG1jkqugYsutMl1EN1mz0l7Q/Z
MFydpwnzRx14gsAWDR7xYgRaUkgff1P118BDaCHIHVBHMXBEAKJT79Ib+a+gmK41FYIIEioMN9/i
vPT9Yfg4ocg7Xm9TuMuOn4yC3DFzyJjE2d4cBpuM0Gvde4NKthkn5LhupvdCEuMZKOzKh4wScAl8
p/IfJajvMZlb4lkGszoU516dWNwBV2fEf/q9ArF1jB4pbb1+CQ/QUQ6aZFn4MzR0RUHlkaPiKioT
v6/TIxGjWq0+Js2+CE9nQHo5ITwTL4jLZ6saOvD2/qndU1HqQtSVrN5c8GpMrFRUiICdzr9uHD7K
ZTbG++4DycDLsCTFIaKEUpHt6YOfEiap4IVmOLTaOgjH2UyGGcKFlb3QjdiKegpQZdinQ6vVX31Q
moc45Q7w7EjP9zPH3ZhnUnVIA6FMT1Ev9DiGVG+D+icum4Tr3GSnILZY65SVCf98iRWxwHXIqdy6
jAkwEPJuLrtFrVfrtoknXAOBYRO20ylEUAzRjVVmqqSdEeMFJUstkA2clPObUDhYtegW7zErURgj
b7Fj4rPlWSjj2RW712CkFNAChlCcwQ8GoAdPdIzj8DaR84Ff++UPVHXlKEL+h53L2SngpJSbevNA
CLHUFkhUQo5gY5UZpUVPOBAWeK7I4iPG52aWWgsFf7qnDfR0IwMAnY6xY/f64axc2mKNTuIsL9A3
c7pvQDkU0JAELNg+CJBccS20dkqmSclid5Fvk5NNGCO/Yk68meGIW0X8UY5jC7ndp0krVYf1O5VN
DHhmjqJIAyL4ZwdDsL6tvJiCnX/q8yNRcdQGKt/KzvgIHePUDItbKOl3Pv53dAcZ91qCH//v6j23
TqyPyOdllWJOUISn0MiYls1AnALYnB/7YUEeEIRQaxu2S30eY9BRE73wc1on2TARUQVs0UXFawoM
2KlA9xZkSIM616O+Wl81/yaf6vQpsFLprQ3JzxrFhIRm+H8QIBY5KQ0UlFaIokJ9N+k/K+MGOURi
WdoVuRbaj/LVwdQpSEd+EI1u5uRC+0sB4cWSv9ujMazqAo3Jp3av6sNR0DrUphOjllWC7/bo/MPF
uInAcnW+E7FdlPjGy2mlp/bbpWKwTQiKSBsZ/xVN1HDjA8u3Rj3VZMc+PmEJ+VXBp+MOCNz8N0My
vzOvWF1O8RaGBerhy/UQ1597AkI03gSpbv5IhfiRDPdXq2LYgAR8ITxMWPlPQLjrBE0XUO2P2112
JQXPUswNTESwDbeeRRPk24V/0ZQFJlTTZVR89bQzGTl6N6V4ScjBnUGlf79TOjZGAw7SKQskiO4a
ELmmf1Rwa8mCmq2JLAAysq2PhbECkfYIHcNujYzJ7TAuTGo1eMKcN8KOWK0+hqf6qj2u2nb4kACk
7fNR6ewtvmxxEgh1WWaGhiDMPmBsMDBfqC5t+AeSKzm8alcXsjplLzXzBCs9+skjzMD7zm9l2XGo
JdyklSRbfE9488Ii3PwQ4Hh9v6Vn0RA8DvLON9eS0bJvgEG/7rGolOjSJarR3vf/UZGnoVuIRxHi
AEMdmNV7zQyJv5ao8lcR2Ffp6CfYHbNseoonfWuOetOxJ/s40wMkt7VqtSjlYtH/KRPhxv8X+hlZ
UCzSsBkImiNgmP6txsS1C7OtL92YDL3nZmAW+epTkJNt+Rhx87tg1qy2OoDWxoECKoN59D3wL5ah
ELkUMltjF/IFiaqoJv/J5zS0c1G+XC0uBORAJXQrsikMqx1u7JHRvXteHZVaeMN/lB/iSvAoZSnV
Xb98pooomIkVNQmjXFfZZHS6skWmTCwleVjJ4NC14YkWtShF06twgsQiQFQQFT3OwNDkV0zLOklI
MBuFHR+G43zDr8nZ6M/4CqIQXoD6DNEW/e6nyjYkQmAH35Vk29cGkFuSeDh+3MuuZTkZCYTy1mHI
58oN2zz1mUaHuabOKGwosxuleUHsLY7Xy/z1S7r1yC9LnnYkFRJdfHcMJgm9mgDPrjGuEdvg6qNg
UU74JnOu9ZIJb4DhDZVTp5QV3JKTwz48wInbvR7CpCIcHVfFlX0EBeGJwgOUZsevNiRgboJ3eSg1
0+0c5ssyRRhfGpEF9rtoLTZE3y89PypIUieYL/Ckfzm6xuufil/eK2/a4pURBDfYOo00lWFFcCHm
bvxz6R5C8/Yz9P804iBlVjrgJFSUOVhTqXBblSl60HcKFQmqtyv16Q6AQExvprexoIbC16yZ9GIo
FGo9iAVTMQ3YEq2Xqlu+hgnC5eylfNfkCHPJQKF/eoyCc4lCEvsAvfL6H0Ipuf94mZVxpWQKjJLe
esIRsCI0ZY5U7kYLfBhytIreEFgeJUOtOJt+M9y7jBCKxMe8SiPm5YUOY8/2Bn/n2NzsuBVX24CV
KEzg28ZlZBo9RCKfLP8ZqaaSQ5TwZ/OT7EjUtkpbTQSPcUNFceu2GRBl89KnhVl/myrgLTeM3SwI
f2MveKPn+5quMB+MmcSsz3VC0brrDN8DG2nDZhaAf9Bc15ucbUCHNAPhkbC6Qn896ISKhvkRPwj/
UPz8hX8Pvse8RKWnXmXuco5hpSK2lKSiuMyU1fB/+ulVo/sr389rvz+GSkK3sUwZ7+0u/2Axkp8E
vnscraBhO1RlZrj/z9ebAoup++uwV+CL39kHTE30D2aLBlYbuB2el8aYR/US4MOo3+AbxIK8FfGl
L1eSlCMRcOBMdCgjg1cIwyHcLtrnV8ba9U7ma8ljqRlyG/5Zn/XIejaJ5CyR9Tz3VdD/Wg11himU
c5rV7eyq+1qBTLVKMZbk+7bCOq4AOh/JsmrqWiRqe6PQL1Vu7j1ZZ/TyumwczkQuTT+QvrdxRT2A
S/Q+D849T0LwQPPOcRZ9imzhAoodtEM8Ea+p0yf3BtilIHeX8jlSV4j7fh8SS6CQ62PKT+hx9/MB
uTnvdhggc9y/LPrxiuyRfW2eWSvJJ7djsfxljIdSPdiMIuweOcul7VV3C/zkGDCHkLoKZ+RUqZwc
QpZMW1oLJdPG7GmGD4C0sSNRACXtVcqGS0u+675p5tKoQ7T8gb6HaSl0BDh2PW/EVVzwN/NYVHxd
AWpfLS8gbGmTt167HCljAssxoKSKMYaTbBEBbK5poY9aVbrIo7U80W7ndPSjgnT0e7mewWKcmrgN
20u6dlk+wv7OOwtLgBIPrSCEJ7ap/xfRZ0b6xax6CMonc0pPf3AnXszlR6uPt4+QAz7DjThN4Lwu
+Mt2DZ1o8PUUv9ZfaayF95En/fEQi1uQrVJSqfOZRmVY67aeCoGxO8DKDkXk1MQvrXuE7QgOh3jC
VOvMBUB643xXDl1ewJAuNlIL7VEjQ+W6JcwPttmT8/5HQDb5BJATTs8WRh/cSfhr4MBe+kikLtrI
BTAAlvJCJMp6OkGi4eEyJL6oeRLxnR6JjwQ1MQ0CSua2/CxkkHXjl8MXq5kuBib48izVCqidDZaj
4XLCWirNMWwr64DbmFfP9vb9yg9Ik+WwJ+gO0rJJjKVTv9GSRY+Bkj90/mf2gYuQ9GhqX03EWY07
/rbbL6IPs/Pq2wNeLQpbD+KLVE0jnJ3z7l+3HwoJScMetAs8TcOvnarvrwf6yJOxxGgWBsMzibko
rSp5Gk530hh+35v0L0wene1gmjkjo0b5+gzTHkbFu9+tVi8c38uCFRyo3OiUwRWTEr/lzRWnBcFM
nA/ozrEUSn2U1KGE3DKcd63MRghFEln3i4IOEUU3WIl+aei5xcqhmNqCUSyhierOuWhpkSkH0ohx
sKz9tqRYrHRafNCl1Ig9aZJknPLBw8/y5Qnp7xiDNA6jJ0TRFcC1/RislEckTNnGCj1WAbAwoAeG
w8QLaY0LlhcBpJ7d+d0beP6Ymem1sgwMu2v+cyq6tn1RMiwGGwD3v2zrvynHyAR+sRmLIv0NMDar
v0luX2Iehy+pwmRjge0m1pko64/Fad4CxRjAayHlx+nwDL6TOggsI/xTwYdqo2755zANOEkdEMH7
kVtBCG/lWpV6K3OOG/Mvgio+iRgTLMuTr3uB+NkJ+icsXa6t9PnhDoOIw4seHHZdruywz3uJm3qW
p2487294vt2LJNva/YolxdrMDBES9DO9W6lqQWW5B6k5+pb85+gH5vw7nc8Lpv/KiSWI5crQtlpx
QG8isv3TnL4dvgmWpDU3kLy4pFL7FxNWDcydrIC22J8h7EuP6xxM9uz3hljs8Lg06a5Uc+82i49v
Ep5VvHtM3AVniSh5uxzL0pkB2kWw/AxhDJEBQHcOLbhEm4RZdPdGcVZ1vYopupzL2Jg5xUQA61Fo
IeCsmUNjgVJBRdnvuXflFt+x4t9o4WY17WQI1ZBJPqilPZ9ZR5LWqpqr/9JgxVp7x4weatJyKZA4
L5+++N817QllQBlmZ/wlXclT9WslpX8xZ3/V/bC7fhc/+LznfbFLnah1ROIXbP88gCKQiEodlmGh
jyuAFXFxqYWQY+/d3Pl5Kisog2LzJE//05Z/GmKzCXd3wy1vDKYxHZOC6stluaxaDLBicBW9LO0p
+b+6mmyHsvIJ0QH3IqZqT0GjvMDasQqs//9/4MPFlPXKcc7iXLL+HbPTzT7eIAr6zkRLqwpEZCbf
f5doGxMMRQKHUCXzQ8Kr6TlB/vtE17iDoKTz9JLrQOc/Am02otU1motFGJrBgMRgKLStLRzuZ79t
4dp8McQ2f6uu58Wp0saC2WulUW2ix6R+Wmx7XtPGGZCC4DYg4Lf7Ii+AA6wtZ8W2IaC+1lKfVGi/
dMyCxcQCgeGet/tqN3S3p43M7rjTCMdMKspG6IEGhj8QZcJbwK2+3sahaRdgMqg79nghiHtTpqzE
cjMeygLQYDywJgV3G3TdUx3JRsPBw1WHh2CeIk0BpPBw+1711+3pNcZsetAuwORPHGPTldOLsEz7
u7W94n7zKCvMc6RUi1XirD7JbifrHnN4+s7bNww8mIjUyy7TfHVo8zzNpYASv8EILlFi4getSjLR
ojWCvVfJg9Wwsx/EFYt8xhp40zM4WKW1l6bC45Kxx5wK2hDgbTzH6SyPiof05qi88Oy55OQ3Mevv
SL3CrjIN9McHL5M7X4m7uG5y0FIJQktqmTSR2NP7mrRV3Z8VPKpje29iavEiiwg0t/Xs6nXcvyDH
krTXuDlqnz/O8IZHMi4OkwVRplfPpaIdhbBIAojIQEdFR5NGrM5VhTpQBGaxpK8npfzIk1ujzT5O
Bfb+VovRem6izbomhwoLoLdcCoLg5Q4xFu+iwOB7s3fp2iVdyC04MKFM/w1Y3+Wx2w1LBj6DpChc
LwuJEZQTpxio408hIzKo24WQIA/d4WJeGrDdZWNhqSGEVGs9XtY+faMzx+quxl1eltYyswDQJVBp
n4oukeLQ17YLzDWruuVfQkO9PUv0dsk6vi7ud6M0yMSHjC3AVzXdZRb5kNEglhYj2L3mDaUglYYP
7OZBbyXKc9M6LeWZdFG4yE5dzmdE1DXmWLbbc4acDudWAkgD9CbBynX5gsj/e2ivOHGJEJDY92JC
sdt7JXkiYh1EDmLyT9IqGN/ZNP0/fcl+LIdHUuFD1C9P+Pdjk2PfnTvjb0yCqeP4yNVy2u93w8x8
A6UmYP4mws1w/yeuzEKKUcEqWx4drh+vWq8dMGQa5m/XToyJAQBoQG738brN9SvbM5NV3sbfu4BT
kFg1rxa2RN8s4TaCrwUCSUDA9ikErZPb584dThqK79Fzxg4vD1Gw34LtkC9ZMcTs+1FqUTEqWLFC
JSdNrijLZcEcGWfndrfKR7sUpYFKE5pG+fRVGMFzQL5HV3DqfzKZkjBjaxswhLw0Ur3B6+IP5QFD
MXIPgiC+YSb8i8Q80fSBd2LkaUP9HC0kfp5bg3/vIy0iG6M5mII23xbCkHf3xzwNHc8ZvLz8lF0A
Gz4bkzICBqcEPCvFDqe9UewDfKdqWwafjIAx2qFN9vWEZcT3cb8dsTLrE+zBjg6POuYbmdyTMk3O
eByW+dcI2yZf4m7OxmajYvJuSsPoacOFf6Zr/HI1A4PwrJW3878WbUroGCn5a0BzxlWQywCE7BEv
olsEIGx7HjeoFcYyfpSN8p/EX9AvvjTXYreDER+Cdf5R7H3bgIsozV7EM7gv4uGda166GLDIrab8
vrFU/wK3HbCRn2Fe1iQ6DPz6B4Ygqu9pM7a3av5OooogylFVgBZOJnLQ09vtgf83OIpRoW3wbwkT
lmCEdrdTbQLLZf0Pnx843YkqghQDVyy=