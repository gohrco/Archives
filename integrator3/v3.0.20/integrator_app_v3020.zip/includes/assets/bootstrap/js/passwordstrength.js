jQuery(document).ready(function(){
	jQuery("#password").keyup(function () {
		var pwvalue = jQuery("#password").val();
		var pwstrength = getPasswordStrength(pwvalue);
		jQuery("#passwordstrength").html(jQuery("#pwtxtstrong").val());
		jQuery("#passwordstrengthpos").css("background-color","#33CC00");
		if (pwstrength<75) {
			jQuery("#passwordstrength").html(jQuery("#pwtxtmod").val());
			jQuery("#passwordstrengthpos").css("background-color","#ff6600");
		}
		if (pwstrength<30) {
			jQuery("#passwordstrength").html(jQuery("#pwtxtweak").val());
			jQuery("#passwordstrengthpos").css("background-color","#cc0000");
		}
		jQuery("#passwordstrengthpos").css("width",pwstrength);
		jQuery("#passwordstrengthneg").css("width",100-pwstrength);
    });
});

function getPasswordStrength(pw){
    var pwlength=(pw.length);
    if(pwlength>5)pwlength=5;
    var numnumeric=pw.replace(/[0-9]/g,"");
    var numeric=(pw.length-numnumeric.length);
    if(numeric>3)numeric=3;
    var symbols=pw.replace(/\W/g,"");
    var numsymbols=(pw.length-symbols.length);
    if(numsymbols>3)numsymbols=3;
    var numupper=pw.replace(/[A-Z]/g,"");
    var upper=(pw.length-numupper.length);
    if(upper>3)upper=3;
    var pwstrength=((pwlength*10)-20)+(numeric*10)+(numsymbols*15)+(upper*10);
    if(pwstrength<0){pwstrength=0}
    if(pwstrength>100){pwstrength=100}
    return pwstrength;
}

function showStrengthBarBAD() {
	jQuery("form div.control-group input#password span.add-on").html( html );
}


function comparePW() {
	var img = $("pass2Result");
	var pass1 = $('password');
	var pass2 = $('password2');
	var val = $("password2Valid");
	
	if ( pass1.value != pass2.value ) {
		val.setProperty('value', "");
		img.removeClass('imgnotice').removeClass('imgrequired').removeClass('imgvalid').addClass('imginvalid');
	} else {
		val.setProperty('value', "1");
		img.removeClass('imgnotice').removeClass('imginvalid').addClass('imgvalid');
	}
}