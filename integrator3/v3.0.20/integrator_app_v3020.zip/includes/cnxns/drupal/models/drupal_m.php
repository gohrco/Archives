<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Drupal Connections Model extended class
 * @version		3.0.20
 * 
 * @since		3.0.6
 * @author Steven
 */
class Drupal_m extends Cnxns_m
{
	/**
	 * Contains the default XML-RPC options to use for the API
	 * @access		public
	 * @since		3.0.6
	 * @var 		array
	 */
	public		$apioptions		= array();
	
	/**
	 * Contains the API URL to use for connecting
	 * @access		public
	 * @since		3.0.6
	 * @var			string
	 */
	public		$apiurl			= null;
	
	/**
	 * Contains the default post variables for the API
	 * @access		public
	 * @since		3.0.6
	 * @var			array
	 */
	public		$apivars		= array();
	
	/**
	 * The base url for the connection
	 * @access		public
	 * @since		3.0.6
	 * @var			string
	 */
	public		$baseurl		= null;
	
	/**
	 * Contains the credentials array from the configuration file for easy reference
	 * @access		public
	 * @since		3.0.6
	 * @var			array
	 */
	public		$credentials	= array();
	
	/**
	 * Data array to use when writing to the database
	 * @access		public
	 * @since		3.0.6
	 * @var			array
	 */
	public		$data			= array();
	
	/**
	 * Stores this connection's cnxnid from the database
	 * @access		public
	 * @since		3.0.6
	 * @var			integer
	 */
	public		$id				= null;	
	
	/**
	 * The determined login action url (for form redirection on logins)
	 * @access		public
	 * @since		3.0.6
	 * @var			string
	 */
	public		$loginaction	= null;
	
	/**
	 * The determined landing url after logging in (if originating from this connection)
	 * @access		public
	 * @since		3.0.6
	 * @var			string
	 */
	public		$loginlandingurl = null;
	
	/**
	 * The determined landing url after logging a user out (if originating from this connection)
	 * @access		public
	 * @since		3.0.6
	 * @var			string
	 */
	public		$logoutlandingurl = null;
	
	/**
	 * The calculated log out url for logging a user out (used to point user to for log out)
	 * @access		public
	 * @since		3.0.6
	 * @var			string
	 */
	public		$logouturl		= null;
	
	/**
	 * The parameters set for this connection in the database stored here
	 * @access		public
	 * @since		3.0.6
	 * @var			array
	 */
	public		$params			= array();
	
	/**
	 * Contains the default CURL options to use for the site rendering
	 * @access		public
	 * @since		3.0.6
	 * @var 		array
	 */
	public		$visualoptions	= array();
	
	/**
	 * The URI object used to retrieve the visual site from
	 * @access		public
	 * @since		3.0.6
	 * @var			object
	 */
	public		$visualuri		= null;
	
	
	/**
	 * Contains the default post variables for the site rendering
	 * @access		public
	 * @since		3.0.6
	 * @var			array
	 */
	public		$visualvars		= array();
	
	/**
	 * Binds the data array to a new object and stores it to model object allowing for validation
	 * @access		public
	 * @version		3.0.20
	 * @param		array		- $data: contains name => value paired array
	 * 
	 * @since		3.0.6
	 */
	public function bind( $data = array() )
	{
		$isNew	= (! isset( $data['id'] ) ? TRUE : FALSE );
		
		if ( $isNew ) {
			return parent::bind( $data );
		}
		
		return parent::bind( $data );
	}
	
	
	/**
	 * Loads a database result object onto the model
	 * @access		public
	 * @version		3.0.20
	 * @param		object		- $data: contains the data straight from the database result row
	 * 
	 * @return		true on success, false on error
	 * @see Cnxns_m::load()
	 * @since		3.0.6
	 */
	public function load( $data = array() )
	{
		if (! parent::load( $data ) ) return false;
		
		$params	= & Params::getInstance();
		
		// ---BEGIN: Setting Base url
		$url	=   $this->get( 'url', null, 'globals' );
		$uri	= & Uri::getInstance( $url, true );
		$uri->setPath( rtrim( $uri->getPath(), '/' ) . '/' );
		$this->set( 'baseurl', $uri->toString() );
		// ---END:   Setting Base url
		// =====================================
		// ---BEGIN: Setting Login Action Url
		$url	=   $this->get( 'apiurl', null, 'api' );
		$uri	= & Uri::getInstance( $url, true );
		$uri->setPath( rtrim( $uri->getPath(), '/' ) . "/wp-content/plugins/integrator/login.php" );
		$uri->setScheme( "http" . ( $params->get( "UserSSL" ) ? "s" : "" ) );
		$this->set( "loginaction", $uri->toString() );
		// ---END:   Setting Login Action Url
		// =====================================
		// ---START: Setting Logout URL
		$url	=   $this->get( 'baseurl', null );
		$uri	= & Uri::getInstance( $url, true );
		$uri->setPath( rtrim( $uri->getPath(), '/' ) . "/wp-content/plugins/integrator/logout.php" );
		$uri->setScheme( "http" . ( $params->get( "UserSSL" ) ? "s" : "" ) );
		$this->set( "logouturl", $uri->toString() );
		// ---END:   Setting Logout URL
		// =====================================
		// ---BEGIN: Setting Login Landing Url
		$loginland	= $this->get( "loginurl", null, "users" );
		
		$lin	= Uri::getInstance( $loginland, true );
		if ( trim( $lin->toString( array( 'host', 'path' ) ) ) == null ) {
			$loginland = null;
		}
		
		if ( $loginland == null ) {
			$uri	= & Uri::getInstance( $this->get( 'baseurl', null ), true );
			$loginland = $uri->toString();
		}
		$this->set( "loginlandingurl", $loginland );
		// ---END:   Setting Login Landing Url
		// =====================================
		// ---START: Setting Logout Langing URL
		$logouturl	= $this->get( "logouturl", null, "users" );
		
		// Test logout url
		$lout = Uri::getInstance( $logouturl, true );
		if ( trim( $lout->toString( array( 'host', 'path' ) ) ) == null ) {
			$logouturl = null;
		}
		
		if ( $logouturl == null ) {
			$uri	= & Uri::getInstance( $this->get( 'baseurl', null ), true );
			$logouturl = $uri->toString();
		}
		$this->set( "logoutlandingurl", $logouturl );
		// ---END:   Setting Logout Langing URL
		// =====================================
		// ---BEGIN: Setting Visual uri
		$url = $this->get( "baseurl", null );
		$uri = & Uri::getInstance( $url, true );
		$uri->setPath( rtrim( $uri->getPath(), "/" ) . "/" );
		$this->set( "visualuri", $uri );
		// ---END:   Setting API url
		
		return true;
	}
	
	
	/**
	 * Checks the status of a connection(non-PHPdoc)
	 * @access		public
	 * @version		3.0.20
	 * 
	 * @return		object containing results
	 * @since		3.0.6
	 * @see			Cnxns_m::status_check()
	 */
	public function status_check()
	{
		$data	= parent::status_check();
		$api	= get_api( $this->id );
		$data['ping']	= $api->ping();
		return (object) $data;
	}
}