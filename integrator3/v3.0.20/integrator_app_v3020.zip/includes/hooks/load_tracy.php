<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 Core Package
 * @copyright  2009 - 2014 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    3.0.20 ( $Id: install_check.php 161 2012-12-18 14:53:08Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is hook file loads Tracy up for the Integrator
 *  
 */


/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

function load_tracy()
{
	// Check Environment and PHP first
	if ( ENVIRONMENT !== 'development' ) return;
	if ( version_compare( phpversion(), '5.3.0', 'lt' ) ) return;
	
	include( APPPATH . 'helpers' . DIRECTORY_SEPARATOR . 'tracy.php' );
	
	$serverName		=	isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : "";
	$productionMode	=	php_sapi_name() === 'cli' || stripos($serverName, '.local') === false;
	
	// Permit custom location of logs
	include( BASEPATH . 'configuration.php' );
	
	if ( $logpath == null ) {
		$logpath = BASEPATH . 'logs';
	}
	
	\Tracy\Debugger :: $strictMode = true;
	\Tracy\Debugger :: $scream = true;
	\Tracy\Debugger :: $onFatalError = "\UnknownException::setFatalErrorHandler";
	\Tracy\Debugger :: enable( $productionMode, $logpath );
	
}