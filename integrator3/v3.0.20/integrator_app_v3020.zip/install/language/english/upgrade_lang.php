<?php

// =========================================
// Titles
// =========================================
$lang['upgrade.step1']				= 'Verify Backup';
$lang['upgrade.step2']				= 'Terms of Service';
$lang['upgrade.step3']				= 'Upgrade';
$lang['upgrade.step4']				= 'Complete';

// =========================================
// Headers and Descriptions
// =========================================
$lang['upgrade.step1.hdr']			= 'Verify Database Backup <small>Step 1</small>';
$lang['upgrade.step1.desc']			= 'Please verify that you have taken a complete backup of your database and your server prior to proceeding with the upgrade.';

$lang['upgrade.step2.hdr']			= 'Terms of Service <small>Step 2</small>';
$lang['upgrade.step2.desc']			= 'Please review our Terms of Service in using Integrator 3. When are done, click "I Agree" to proceed, if you do not wish to be bound by these terms, please click "I Disagree" to cancel the upgrade.';

$lang['upgrade.step3.hdr']			= 'Upgrading <small>Step 3</small>';
$lang['upgrade.step3.desc']			= 'Upgrade in progress';

// =========================================
// Error Messages
// =========================================
$lang['error.backup_not_done']		= 'You must verify that you have performed a backup prior to continuing';
$lang['error.configmissing']		= 'The configuration.php file is missing from your previous install - if you deleted it by accident please restore a backup of it or you will need to reinstall the product.';
$lang['error.nodbcnxn']				= 'The database settings found in your configuration.php file are incorrect and the upgrade cannot proceed until this is corrected.';
$lang['error.run-dbsel']			= 'Unable to select the database `%s`';


// =========================================
// Buttons
// =========================================
$lang['btn.agree']					= 'I Agree';
$lang['btn.disagree']				= 'I Disagree';
$lang['btn.tryagain']				= 'Try Again';
$lang['btn.step1']					= 'CONFIRM BACKUP PERFORMED';

// =========================================
// Menu Items
// =========================================
$lang['menu.step1']				= 'Verify Backup';
$lang['menu.step2']				= 'Terms of Service';
$lang['menu.step3']				= 'Upgrade';
$lang['menu.step4']				= 'Complete';

// =========================================
// Form Items
// =========================================
// Backup Performed Items
// -----------------------------------------
$lang['verify']					= "Database Backup Performed";
$lang['verify.desc']			= "Before upgrading your application, it is highly recommended that you perform a backup of your database.";



// $lang['upgrade']				= 'Upgrade';
// $lang['upgrade.index']			= 'Checking your installation...';
