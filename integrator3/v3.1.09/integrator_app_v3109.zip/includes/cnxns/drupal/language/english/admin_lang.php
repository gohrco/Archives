<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.09 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.6
 * 
 * @desc       This is the English language file for the Drupal admin controller pages for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/


// ===================================================================
// 	Messages
// ===================================================================
//		v 3.0.6
// -------------------------------------------------------------------
$lang['msg.info.pagemap']		= 'The connection `%s` uses the Drupal connection; menu items that point to the same content type will result in only one of the menu items appearing in the selection box.  This is based on the content item, not the menu alias.';
$lang['msg.info.langmap']		= 'The connection `%s` uses the Drupal connection and requires for language translation that the REQUEST / SESSION method of specifying a language be enabled and that you use the term `language` in the `Request/session Parameter.';



// ===================================================================
// 	System Update (help/systemstatus/updates)
// ===================================================================
//		v 3.0.8
// -------------------------------------------------------------------
$lang['dialog.joomla.update.content']	= '<p>The updates for this connection are handled in the backend of Drupal.  The button below will take you to your site where you need to log in as an administrator and will then be taken to the addon modules where you can perform the upgrade.</p>';
$lang['dialog.joomla.update.header']	= 'Redirect to Drupal Administrator';
$lang['dialog.joomla.button.redirect']	= 'Redirect';
