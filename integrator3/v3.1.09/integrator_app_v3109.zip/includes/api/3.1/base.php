<?php
/**
 * Integrator 3
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.09 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * API interface for application
 * @version		3.1.09
 *
 * @since		3.1.00
 * @author		Steven
*/
class BaseApi
{
	/**
	 * Stores the controller we are using
	 * @var string
	 */
	protected $_controller	=	'base';
	
	/**
	 * Stores our debug status for use
	 * @var boolean
	 */
	protected $_debug		=	false;
	
	/**
	 * Stores the method we are using to connect to the API with
	 * @var string [get|post|put|delete]
	 */
	protected $_method	=	null;
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.1.09
	 * @param		array
	 *
	 * @since		3.1.00
	 */
	public function __construct( $options = array() )
	{
		$this->_debug	=	Params::getInstance()->get( 'Debug' );							// Lets set debug in place
		$this->_method	=	( isset( $options['method'] ) ? $options['method'] : 'get' );	// Lets set our method in place
		$this->_origin	=	get_instance()->input->{$this->_method}( '_c' );
		
		// Pull our posted and header signatures
		$postsig	=	(string) rawurldecode( get_instance()->input->{$this->_method}( 'apisignature' ) );
		$headsig	=	(string) rawurldecode( get_instance()->input->server( 'HTTP_INTEGRATORREQUESTSIGNATURE' ) );
		
		if ( $this->_compareSignatures( $postsig, $headsig ) !== true ) {
			return $this->error( lang( 'api.error.postheadnomatch' ), 'CORE01' );
		}
		
		$rcvdsign	=	(string) ( rand( 0, 1 ) == '1' ? $headsig : $postsig );
		$madesign	=	$this->_generateSignature();
		
		$debug		=	array( 'headsignature' => $headsig, 'postedsignature' => $postsig, 'createdsignature' => $madesign, 'method' => $this->_method, 'origin' => $this->_origin, 'post' => $_POST );
		$debug = null;
		if ( $this->_compareSignatures( $rcvdsign, $madesign ) !== true ) {
			return $this->error( lang( 'api.error.rcvdmadenomatch' ), 'CORE02', $debug );
		}
		
		// Test the timestamp to ensure recent request
		$gmt		=	new DateTime( null, new DateTimeZone('GMT') );
		$current	=	$gmt->format("U");
		$timestamp	=	get_instance()->input->{$this->_method}( 'apitimestamp' );
		$timediff	=	( $this->_debug ? 300 : 45 );
		
		// Test the timestamp
		if ( ( $current - $timestamp ) > $timediff ) {
			// The request is older than 2 minutes... something isn't right
			return $this->error( lang( 'api.error.timestamp' ), 'CORE03' );
		}
		
		// At this point we should valid to proceed...
	}
	
	
	/**
	 * Respond with an error message
	 * @access		public
	 * @version		3.1.09
	 * @param		mixed			array or string
	 * @param		string			contains the code we want to use for identifying the source with
	 * @param		array			any debug data we want to pass along
	 *
	 * @since		3.1.00
	 * 
	 * COREXX	=	Core Api errors
	 * CNXNXX|Y	=	Connection error x id Y
	 */
	public function error( $data = array(), $code = null, $debug = array() )
	{
		if (! is_array( $data ) ) {
			$data	=	array( 'message' => $data );
		}
		
		$data['response']	=	'error';
		$data['code']		=	$code;
		$data['debug']		=	$data['debug']	=	\Tracy\Debugger :: getBar()->renderforApi();
		
		logAPIResponse( $this->_origin, '0', $this->_method . '_' . $this->_controller, $this->getVar(), array(), $data );
		$this->_response( $data );
	}
	
	
	/**
	 * Method for getting an input variable from our controller
	 * @access		public
	 * @version		3.1.09
	 * @param		string
	 * @param		mixed
	 * @param		boolean
	 *
	 * @return		mixed
	 * @since		3.1.00
	 */
	public function getVar( $key = null, $default = false, $clean = true )
	{
		$ci	= & get_instance();
		return $ci->getVar( $key, $default, $clean );
	}
	
	
	/**
	 * Respond with a success message
	 * @access		public
	 * @version		3.1.09
	 * @param		mixed			array or string
	 * @param		array			any debug data we want to pass along
	 *
	 * @since		3.1.00
	 */
	public function success( $data = array(), $debug = array() )
	{
		// Ensure we have an array
		if (! is_array( $data ) ) {
			$data	=	(array) $data;
		}
		
		$data['response']	=	'success';
		
		//if ( $this->_debug && ! isset( $data['debug'] ) ) $data['debug'] = $debug;
		
		$data['debug']	=	\Tracy\Debugger :: getBar()->renderforApi();
		
		logAPIResponse( $this->_origin, '0', $this->_method . '_' . $this->_controller, $this->getVar(), array(), $data );
		$this->_response( $data );
	}
	
	
	/**
	 * Method to compare signatures
	 * @desc		Used to prevent timing attacks
	 * @access		private
	 * @version		3.1.09
	 * @param		string
	 * @param		string
	 *
	 * @return		boolean
	 * @since		3.1.00
	 */
	private function _compareSignatures( $a, $b )
	{
		$diff = strlen($a) ^ strlen($b);
	
		for ( $i = 0; $i < strlen($a) && $i < strlen($b); $i++ ) {
			$diff |= ord( $a[$i] ) ^ ord( $b[$i] );
		}
	
		return $diff === 0;
	}
	
	
	/**
	 * Method for generating our signature to compare against from connections
	 * @access		private
	 * @version		3.1.09
	 *
	 * @return		string
	 * @since		3.1.00
	 */
	private function _generateSignature()
	{
		$ci		= & get_instance();
		$params	=	Params::getInstance();
		$input	= & get_instance()->input;
		
		$method	=	$this->_method;
		$token	=	$params->get( 'Secret' );
		$uri	=	clone Uri :: getInstance( 'SERVER', true );
		$append	=	null;
		
		$isSef		=	$ci->config->item( 'index_page' );
		
		if ( $isSef && strpos( $uri->getPath(), 'index.php' ) === false ) {
			$path	=	rtrim( $uri->getPath(), '/' ) . '/index.php';
			$uri->setPath( $path );
		}
		
		if ( $method == 'get' ) {
			$uri->delVar( 'apisignature' );
			$uri->delVar( '_c' );
		}
		else {
			$post		=	$input->$method();
			ksort( $post );
			$usepost	=	array();
			
			foreach ( $post as $k => $v ) {
				if (! in_array( $k, array( 'apisignature', '_c' ) ) ) {
					$usepost[$k] = $v;
				}
			}
			
			\Tracy\Debugger :: barDump( $usepost, 'Received Variables to Assemble Signature With' );
			
			$append .= $this->_generateString( $usepost );
		}
		
		\Tracy\Debugger :: barDump( $uri, 'URI Used to Assemble Signature With' );
		
		return base64_encode( hash_hmac( 'sha256', rawurldecode( $uri->toString() ) . $append, $token, true ) );
	}
	
	
	/**
	 * Method to generate string
	 * @access		public
	 * @version		3.1.09
	 * @param		array
	 *
	 * @return		string
	 * @since		3.1.00
	 */
	private function _generateString( $data = array(), $subarray = null )
	{
		$input	= & get_instance()->input;
		$string	=	null;
		
		foreach ( $data as $k => $v ) {
			if ( is_array( $v ) ) {
				$subdata	=	( $subarray ? $subarray[$k] : $input->{$this->_method}( $k, null, 'array', $this->_method ) );
				$string		.=	$this->_generateString( $v, $subdata );
			}
			else {
				$string	.=	$k . ( $subarray ? $subarray[$k] : $input->{$this->_method}( $k, null, 'string', $this->_method ) );
			}
		}
		return $string;
	}
	
	
	/**
	 * Method for responding to the API request
	 * @access		private
	 * @version		3.1.09
	 * @param		array
	 *
	 * @since		3.1.00
	 */
	private function _response( $data = array() )
	{
		get_instance()->response( $data );
	}
}