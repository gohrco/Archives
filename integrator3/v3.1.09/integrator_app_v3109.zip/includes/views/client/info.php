<?php echo heading( lang( 'title.userinfo' ), '2' ); ?>

<?php if (! empty( $error ) ) : ?>

<div class="alert alert-error">
	
	<button class="close" data-dismiss="alert">x</button>
	
	<h4 class="alert-heading"><?php echo lang( 'error.heading' ); ?></h4>
	
	<ul><?php echo $error; ?></ul>
	
</div>

<?php endif; ?>

<?php if (! empty( $success ) && empty( $error ) ) : ?>

<div class="alert alert-success">
	
	<button class="close" data-dismiss="alert">x</button>
	
	<h4 class="alert-heading"><?php echo lang( 'success.heading' ); ?></h4>
	
	<ul><?php echo $success; ?></ul>
	
</div>

<?php endif; ?>

<?php echo lang( 'page.clientarea' ); ?>

<div class="span4 well">

	<address>
		
		<strong><?php echo $user['primary']; ?></strong> <i>(<abbr title="<?php echo lang( 'tip.identifyusername' ); ?>"><?php echo $user['tertiary']['username']; ?></abbr>)</i><br/>
		
		<?php if (! empty( $user['secondary'] ) ) : ?>
		
		<?php foreach ( $user['secondary'] as $sec ) : ?>
		
		<?php echo $sec; ?><br/>
		
		<?php endforeach; ?>
		
	</address>
	
	<address>
		
		<strong><?php echo lang( 'title.contactinfo' ); ?></strong><br/>
		
		<?php endif; ?>
		
		<?php echo $user['tertiary']['email']; ?>
		
	</address>
		
</div>

<div class="span3">

	<div style="padding: 5px 0; ">
		
		<a class="btn span2" href="<?php echo site_url( 'user/edit' ); ?>"><i class="icon-user"></i>&nbsp;&nbsp;<?php echo lang( 'btn.edituser' ); ?></a>
		
		<div style="clear: both; "></div>
		
	</div>
	
	<div style="padding: 5px 0; ">
		
		<a class="btn span2" href="<?php echo site_url( 'user/changepassword' ); ?>"><i class="icon-lock"></i>&nbsp;&nbsp;<?php echo lang( 'btn.changepassword' ); ?></a>
		
		<div style="clear: both; "></div>
		
	</div>
	
	<div style="padding: 5px 0; ">
		
		<a class="btn span2 btn-danger" href="<?php echo site_url( 'user/logout/0' ); ?>"><i class="icon-off icon-white"></i>&nbsp;&nbsp;<?php echo lang( 'btn.logout' ); ?></a>
		
		<div style="clear: both; "></div>
		
	</div>

</div>

<div style="clear: both; "></div>

<?php if ( empty( $tables ) ) return; ?>

<?php foreach ( $tables as $table ) : ?>
	
	<div style="float: right; "><?php echo $table['headerlink']; ?></div>
	
	<?php echo heading( $table['header'], '3' ); ?>
	
	<div style="clear: both; "></div>
	
	<table class="table table-striped">
		
		<thead>
			
			<tr>
				
				<?php foreach ( $table['columns'] as $cnt => $column ) : ?>
				
				<?php if ( $cnt == ( count( $table['columns'] ) - 1 ) ) :  // Last Column always 60 wide ?>
				
				<td width="60px"><?php echo $column; ?></td>
				
				<?php else : // All other columns ?>
				
				<td><strong><?php echo $column; ?></strong></td>
				
				<?php endif; ?>
				
				<?php endforeach; ?>
				
			</tr>
			
		</thead>
		
		<tbody>
			
			<?php foreach ( $table['data'] as $items ) : ?>
			
			<tr>
				
				<?php foreach ( $items as $item ) : ?>
				
				<td><?php echo $item; ?>
				
				<?php endforeach; ?>
				
			</tr>
			
			<?php endforeach; ?>
			
		</tbody>
		
	</table>
	
	<div style="padding: 15px; clear: both; "></div>
	
<?php endforeach; ?>

