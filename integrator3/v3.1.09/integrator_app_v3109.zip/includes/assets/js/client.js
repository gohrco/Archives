jQuery(document).ready(function() {
	jQuery("label.inlined + input.input-text").each(function (type) {
		Event.observe(window, 'load', function () {
			setTimeout(function() {
				if (!input.value.empty()) {
					input.previous().addClassName('has-text');
				}
			}, 200);
		});
		
		jQuery(this).focus(function () {
			jQuery(this).prev("label.inlined").addClass("focus");
		});
		
		jQuery(this).keypress(function () {
			jQuery(this).prev("label.inlined").addClass("has-text").removeClass("focus");
		});
		
		jQuery(this).blur(function () {
			if(jQuery(this).val() == "") {
				jQuery(this).prev("label.inlined").removeClass("has-text").removeClass("focus");
			}
		});
	});
});