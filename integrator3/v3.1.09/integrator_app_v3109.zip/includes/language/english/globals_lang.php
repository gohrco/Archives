<?php 
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.09 ( $Id: globals_lang.php 163 2012-12-18 14:56:38Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This is the English language file for the global language translations for the admin backend of the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('BASEPATH') OR exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * This file contains the following GLOBAL information:
 * 		Global Variables	- used throughout site on all fronts
 * 		Messages			- used throughout site in specific controllers but provided centrally here
 */

// ===================================================================
// 	Global Variables
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------
$lang['yes']				= 'Yes';
$lang['no']					= 'No';
$lang['cancel']				= 'Cancel';
$lang['savechanges']		= 'Save Changes';
$lang['submit']				= 'Submit';
$lang['updatesettings']		= 'Update Settings';
$lang['csrfcheck']			= 'Invalid token!';
$lang['forgot.password']	= 'Forgot password?';

$lang['dt.license']			= 'License';
$lang['dt.version']			= 'Version';
$lang['btn.logout']			= 'Logout';

//     v 3.0.4
// -------------------------------------------------------------------
$lang['success']			= 'Success';
$lang['failed']				= 'Failed';
$lang['enabled']			= 'Enabled';
$lang['disabled']			= 'Disabled';
$lang['exists']				= 'Exists';
$lang['notfound']			= 'Not Found';


// ===================================================================
// 	Language Translation Names
// ===================================================================
//		v 3.0.4
// -------------------------------------------------------------------
$lang['default']			= 'Default Language';
$lang['english']			= 'English';


// ===================================================================
// 	Integrator 3 Page Names (moved from admin_lang)
// ===================================================================
//		v 3.0.5
// -------------------------------------------------------------------
$lang['api.registration']				= 'Integrated Registration Page';
$lang['api.useredit']					= 'Integrated User Profile Edit Page';
$lang['api.userindex']					= 'Integrated Login / Clientarea Page';
$lang['api.userinfo']					= 'Integrated User Clientarea Page';
$lang['api.userlogin']					= 'Integrated Login Page';
$lang['api.userlogout']					= 'Integrated Logout';
$lang['api.userchangepassword']			= 'Integrated User Password Change';



// ===================================================================
// 	Success Messages
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------

// ----- Unknowns
$lang['success.ajaxemail']				= 'Email address is okay!';
$lang['success.ajaxpassword']			= 'Password checks out!';
$lang['success.ajaxusername']			= 'Your username will be fine!';
$lang['success.changepassword']			= 'Password updated successfully!';
$lang['success.edituser']				= 'Your details have been updated successfully!';
$lang['success.heading']				= 'Success!';

// ----- License Messages
$lang['msg.success.licsaved']			= "License Saved!";
$lang['msg.success.licreloaded']		= 'License Reloaded!';

// ----- Admin Messages
$lang['msg.success.installcomplete']	= 'Installation complete - install folder deleted';
$lang['msg.success.upgradecomplete']	= 'Upgrade complete - install folder deleted';
$lang['msg.success.passwordreset']		= 'Password successfully reset';
$lang['msg.success.forgotpwsent']	= 'Password reset email sent';
$lang['msg.success.login']	= "Successfully Logged In";

// ----- Admin User Messages
$lang['msg.success.activate']		= "Account Activated";
$lang['msg.success.deactivate']		= "Account De-Activated";
$lang['msg.success.pwchange']		= "Password Successfully Changed";
$lang['msg.success.pwforgot']		= "Password Reset Email Sent";
$lang['msg.success.acctcreated']	= "Account Successfully Created";
$lang['msg.success.login']			= "Logged In Successfully";
$lang['msg.success.logout']			= "Logged Out Successfully";
$lang['msg.success.update']			= "Account Information Successfully Updated";
$lang['msg.success.delete']			= "User Deleted";
$lang['users.msg.usercreated']		= "User Created";
$lang['users.msg.userupdated']		= "User Updated";
$lang['msg.editcancelled']			= 'User edit cancelled successfully!';

// ----- User Manager Message
$lang['msg.success.usercreated']	= "User successfully created";
$lang['msg.success.userupdated']	= "User successfully updated!";

// ----- Client area Messages
$lang['success.heading']		= 'Success!';
$lang['success.edituser']		= 'Your details have been updated successfully!';
$lang['success.changepassword']	= 'Password updated successfully!';

// ----- Settings Messages
$lang['msg.success.savedsettings']	= "Settings Saved";

// ----- Pagemap Messages
$lang['msg.success.pagemapsaved']	= "Page Mapping Saved!";

// ----- Language Map Messages
$lang['msg.success.langmapsaved']	= "Language Mapping Saved";

// ----- Client Registration Messages
$lang['msg.ajax.email.good']		= 'Email address is okay!';
$lang['msg.ajax.password.good']			= 'Password checks out!';
$lang['msg.ajax.username.good']			= 'Your username will be fine!';

// ----- Client Logging In Messages
$lang['success.loggedin']			= 'You have logged in successfully!';

// ----- IonAuth Messages (used?)
$lang['account_creation_successful']			= 'Account Successfully Created';
$lang['password_change_successful']				= 'Password Successfully Changed';
$lang['activate_successful']					= 'Account Activated';
$lang['activation_email_successful']			= 'Activation Email Sent';
$lang['login_successful']						= 'Logged In Successfully';
$lang['update_successful']						= 'Account Information Successfully Updated';
$lang['logout_successful']						= 'Logged Out Successfully';
$lang['delete_successful']						= 'User Deleted';

// ----- Cnxns Messages
$lang['msg.success.cnxnadd']			= "Selected connection added!";
$lang['msg.success.cnxndeleted']		= "Connection successfully deleted";
$lang['msg.success.connectionsaved']	= "Connection Saved!";



// ===================================================================
// 	Error Messages
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------

// ----- Unknowns
$lang['error.authentication']			= 'Your old password is incorrect!';
$lang['error.credsorigin']				= 'Originating Connection Information missing: Unable to proceed';
$lang['error.emailerrorcheck']			= 'That email address is already in use on our system. Please enter another email address.';
$lang['error.emailerrorfree']			= 'Our system does not permit email addresses from that domain. Please enter another email address.';
$lang['error.heading']					= 'Error Message';
$lang['error.passworderrorcheck']		= 'That password is insufficient for our system.';
$lang['error.returnurl']				= 'There was no way to determine where to send you once you had completed the login procedure.  Please contact the administrators of this site to let them know of the issue you encountered.';
$lang['error.usernameerrorcheck']		= 'That username is already in use by another user. Please enter another username.';
$lang['error.userupdate']				= 'There was a problem updating the user account: `%s`';

// This is a special one used across all controllers for XSS validation
$lang['csrfcheck']						= 'Your session token was invalidated - please try again!';

// ----- Admin Messages
$lang['msg.error.installcomplete']		= 'Installation complete - please delete the `%s` folder';
$lang['msg.error.upgradecomplete']		= 'Upgrade complete - please delete the `%s` folder';
$lang['msg.error.installdir']			= 'You should remove the `%s` folder!';
$lang['msg.error.installconfignew']		= 'You should remove the `%s` file!';
$lang['msg.error.passwordreset']		= 'Unable to reset password';
$lang['msg.error.forgotpwsent']		= 'Unable to reset password';
$lang['msg.error.login']	= "Login Incorrect";

// ----- User Messages
$lang['msg.error.activate']			= "Unable to Activate Account";
$lang['msg.error.deactivate']		= "Unable to De-Activate Account";
$lang['msg.error.pwchange']			= "Unable to Change Password";
$lang['msg.error.pwforgot']			= "Unable to Reset Password";
$lang['msg.error.acctcreated']		= "Unable to Create Account";
$lang['msg.error.login']			= "In-Correct Login";
$lang['msg.error.update']			= "Unable to Update Account Information";
$lang['msg.error.delete']			= "Unable to Delete User";
$lang['msg.create_user.success']	= "New user created successfully!";
$lang['msg.edit_user.success']		= "Changes saved to user successfully!";

// ----- User Manager Message
$lang['msg.error.userupdate']		= "An error occurred: %s";

// ----- Client area Messages
$lang['error.heading']			= 'Error Message';
$lang['error.authentication']	= 'Your old password is incorrect!';

// ----- Settings Messages
$lang['msg.error.savedsettings']	= "An unknown error occurred saving your settings.";

// ----- Render Messages
$lang['msg.error.disabled']				= "The Integrator is disabled - unable to make a connection";
$lang['msg.error.visualdisabled']		= "Visual integration has been disabled globally in the Integrator!";
$lang['msg.error.defaultvisualunset']	= "The site administrator hasn't defined a default visual site in the global settings yet.";
$lang['msg.error.misconfiguration']		= "Integrator encountered a misconfiguration and could not render the request.";
$lang['msg.error.incorrectvisual']		= "The requested site cannot be retrieved due to a type conflict.";
$lang['msg.error.nocnxnfound']			= 'No connection corresponds to the ID provided.';
$lang['msg.error.visualcnxndisabled']	= 'The connection `%s` is disabled and the default connection `%s` selected for rendering.';
$lang['msg.error.secrethashinvalid']	= 'The signature and salt dont add up... bailing!';
$lang['msg.error.constr.appobject']		= 'There is a problem building the app object';
$lang['msg.error.constr.siteobject']	= 'There is a problem building the site object';

// ----- Pagemap Messages

// ----- Client Registration Messages
$lang['msg.error.credsorigin']		= "Originating Connection Information missing: Unable to proceed";
$lang['msg.error.returnurl']		= "There was no way to determine where to send you once you had completed the login procedure.  Please contact the administrators of this site to let them know of the issue you encountered.";
$lang['msg.ajax.email.error.free']	= 'Our system does not permit email addresses from that domain. Please enter another email address.';
$lang['msg.ajax.email.error.check']	= 'That email address is already in use on our system. Please enter another email address.';
$lang['msg.ajax.password.error.check']	= 'That password is insufficient for our system.';
$lang['msg.ajax.username.error.check']	= 'That username is already in use by another user. Please enter another username.';

// ----- Client Logging Out Messages
$lang['msg.error.credsorigin']		= "Originating Connection Information missing: Unable to proceed";
$lang['msg.error.userdisabled']		= 'User Integration disabled in Global Configuration - returning to origin.';
$lang['msg.error.cnxnsdisabled']	= 'No connections are active to log out of - returning to origin.';

// ----- Client Logging In Messages
$lang['msg.error.credsorigin']		= "Originating Connection Information missing: Unable to proceed";
$lang['msg.error.returnurl']		= "There was no way to determine where to send you once you had completed the login procedure.  Please contact the administrators of this site to let them know of the issue you encountered.";
$lang['error.login']				= 'There was a problem with your email address or password.  Please try again.';
$lang['error.loginoncnxn']			= 'A problem was encountered and you were not logged into `%s`.  Please try logging out and logging back in.  If the problem occurs again, please contact us.';

// ----- IonAuth Messages (used?)
$lang['account_creation_unsuccessful']			= 'Unable to Create Account';
$lang['account_creation_duplicate_email']		= 'Email Already Used or Invalid';
$lang['account_creation_duplicate_username']	= 'Username Already Used or Invalid';
$lang['password_change_unsuccessful']			= 'Unable to Change Password';
$lang['forgot_password_successful']				= 'Password Reset Email Sent';
$lang['forgot_password_unsuccessful']			= 'Unable to Reset Password';
$lang['activate_unsuccessful']					= 'Unable to Activate Account';
$lang['deactivate_successful']					= 'Account De-Activated';
$lang['deactivate_unsuccessful']				= 'Unable to De-Activate Account';
$lang['activation_email_unsuccessful']			= 'Unable to Send Activation Email';
$lang['login_unsuccessful']						= 'In-Correct Login';
$lang['update_unsuccessful']					= 'Unable to Update Account Information';
$lang['delete_unsuccessful']					= 'Unable to Delete User';

// ------ Cnxns Messages
$lang['msg.error.cantadd']				= 'Your license does not permit additional connections to be added.  Please purchase additional connections for your license.';
$lang['msg.error.unknown']				= 'An unknown error occurred';
$lang['msg.error.cnxndelete']			= "Unable to delete the connection";
$lang['msg.error.nocnxnselected']		= "No connection or invalid connection selected";
$lang['msg.error.noconnection']			= "Problem retrieving connection from the database";
$lang['msg.error.cnxnping']				= "Error pinging Connection URL - Disabling the Connection";
$lang['msg.error.cnxndeactivated']		= "<u>`%s` Deactivated</u>";
$lang['msg.error.msgreturned']			= 'Message returned: While attempting to perform %s task, %s says `%s`';

// ------ Help Messages
//		v 3.0.8
// -------------------------------------------------------------------
$lang['msg.error.updates.nocreds']		= 'You have not entered a username or password in the <a href="%s">Global Settings</a> to log in with and download the latest update.';
$lang['msg.error.updates.nodownload']	= 'No download was found to retrieve.';
$lang['msg.error.updates.downloadfail']	= 'An error occurred downloading the update.  The following message was sent back by the update handler: `%s`';
$lang['msg.error.updates.nofpresource']	= 'Unable to create a filepointer resource for update to be completed.';
$lang['msg.error.updates.extractfail']	= 'Unable to extract the archive `%s`: %s';
$lang['msg.error.updates.copyfail']		= 'Unable to copy files to `%s`';


// ===================================================================
// 	Notice Messages
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------

// ----- Admin Messages
$lang['msg.notice.update']			= 'Version <span style="letter-spacing: 0em; ">%s</span> is available for Integrator 3!';
$lang['notice.unknowncnxn']			= 'Unknown';	// This is found in cnxn_helper
$lang['info.heading']				= 'Attention:';
//		v 3.0.4
// -------------------------------------------------------------------
$lang['msg.alert.debugison']		= 'Debugging is turned on!  It is highly advised that you turn debugging off in your Global Settings if your site is live.';
$lang['msg.alert.visualdisabled']	= 'Visual integration has been completely turned off in the settings!  Any connections relying on the visual integration will not be wrapped.  This is controlled in the Visual Settings.';
$lang['msg.alert.userdisabled']		= 'User integration has been completely turned off in the settings!  Any connections relying on the user integration will not work as expected.  This is controlled in the User Settings.';
$lang['msg.alert.environment']		= 'Your environment is set to <strong>%s</strong> and may result in unnecessary error messages being displayed.  This can be changed in your configuration.php file';
$lang['msg.alert.disabled']			= 'Your entire Integrator 3 product is disabled and pages relying on the visual or user integration will fail!  This is set in the Global Configuration page.';
$lang['msg.alert.apilogging']		= 'Don\'t forget that you are logging every API call and this could quickly fill up your database if you aren\'t careful.  This setting is controlled in the API Settings.';

// ----- Cnxns Messages
$lang['msg.info.imgurlunset']			= "Image URL in visual settings was left unset - updated to match Connection URL";
$lang['msg.info.nosslverify']			= "Error received verifying SSL - Disabling API SSL requirement";
$lang['msg.info.apiurlcorrected']		= "API URL Corrected";
$lang['msg.info.defaultvisualset']		= "Your setting for the Default Visual connection has been updated to `%s`";
//		v 3.0.6
// -------------------------------------------------------------------
$lang['msg.info.chpwlogbacking']		= "Please note that if you change your password you will need to log back in with your new password for the change to be effective.";


// ===================================================================
// 	Log and Debug Messages
// ===================================================================
//		v 3.0.0
// -------------------------------------------------------------------

// ----- Usermgr Messages
$lang['USERMGR_LOG_AUTH']				= "User `%s` authenticated against %s";
$lang['USERMGR_LOG_AUTH_BADPW']			= 'The password for `%s` is incorrect on `%s`';
$lang['USERMGR_LOG_AUTH_MISSCRED']		= 'The user `%s` is missing `%s` for `%s`';
$lang['USERMGR_LOG_AUTH_CREDFOUND']		= 'Found `%s` for `%s` using `%s` on `%s`';
$lang['USERMGR_LOG_AUTH_RETERROR']		= "Unable to determine the return URL for a login coming from the `%s` connection!";
$lang['USERMGR_LOG_AUTH_RETERRLOUT']	= "No return url was found for a login coming from `%s`; the logout url was used!";
$lang['USERMGR_LOG_AUTH_CREDSMISS']		= "No credentials were passed along by the user when they logged in; sending back to `%s`";
$lang['USERMGR_LOG_AUTH_CNXNERR']		= "Settings are preventing a user to log in from `%s`";
$lang['USERMGR_LOG_AUTH_TYPEMIS']		= "The user passed neither a username or email to login with; sending back to `%s`";
$lang['USERMGR_LOG_LOGINN']				= "User unable to log into %s using `%s`";
$lang['USERMGR_LOG_LOGINY']				= "User successfully logged in on %s using `%s`";
$lang['USERMGR_LOG_FINDN']				= 'Unable to find the user `%s` on `%s`';
$lang['USERMGR_LOG_CREATENEW']			= 'New user created on `%s` using `%s`';
$lang['USERMGR_LOG_CREATENEWFAIL']		= 'Unable to create new user on `%s`: %s';
$lang['USERMGR_LOG_APIUSERCREATEYES']	= 'User `%s` successfully created on `%s`';
$lang['USERMGR_LOG_APIUSERCREATENO']	= 'API User Create on `%s` reports: `%s`';

// ----- Render Library Messages
$lang['render.setcookies.noread']		= 'Unable to find the cookie file for rendering the site.';
$lang['render.setcookies.noopen']		= 'Unable to read the cookie file for rendering the site.';
$lang['render.setcookies.empty']		= 'The rendering cookie file is empty for this connection.';

// ----- Cnxns Messages
$lang['cnxns.handlecookie.error']	= 'There was a problem writing to the temporary directory.';
$lang['cnxns.removecookie.error']	= 'Unable to remove the cookie from the temporary directory.';
$lang['cnxns.removecookie.nofile']	= 'Cookie file not found to remove from temporary directory.';



// ===========================================
// ===========================================
// EVERYTHING BELOW MAY BE DEPRECATED / UNUSED
// ===========================================
/**
 * **********************************************************************
 * SIDEBAR
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['side.greeting']		= 'Welcome back %1$s %2$s';
		$lang['side.license']		= 'License';
		$lang['side.registeredto']	= 'Registered to';
		$lang['side.registeredon']	= 'Registered on: %s';
		$lang['side.licdue']		= 'Next due date: %s';
		$lang['side.licerror']		= 'License Error';
		$lang['side.versionchecking']	= 'Checking...';
		
		
	
		
		
		
/**
 * **********************************************************************
 * DEBUG MESSAGES
 * **********************************************************************
 */
		$lang['debug.curlsslnosupport']		= 'CURL is not compiled with SSL support';
		
		
		
		
/*
|--------------------------------------------------------------------------
| Verify Action -- ADMIN USER VERIFICATIONS
|--------------------------------------------------------------------------
| version 3.0.0
|--------------------------------------------------------------------------
*/

$lang['verify.delete_user.desc']	= "Are you sure you want to delete this user?  This action cannot be undone!";

$lang['verify.deactivate']			= "Deactivate User";
$lang['verify.deactivate.desc']		= "Are you sure you want to deactivate this user?";

$lang['deactivate.confirm']			= "Deactivate User?";
$lang['deactivate.confirm.desc']	= "Selecting yes will deactivate this user, selecting no will cancel the action.";


$lang['button.deactivate']	= "Confirm Deactivation";

		
/**
 * **********************************************************************
 * REMOVE USER -- USERMGR
 * **********************************************************************
 */
		//     v3.0.0
		// ---------------
		$lang['usermgr.removeconfirm']	= "Confirm User Removal / Deactivation";
		$lang['usermgr.removeconfirm.desc']	= "Confirm that you want this user removed or inactivated on this connection.";
		
		$lang['label.confirm']		= "Are you sure?";
		$lang['desc.confirm']		= "If you confirm that you want this user removed from this connection, the user account will be either removed completely or inactivated or closed.  This may be irreversible, are you sure?";
		
		$lang['btn.removeuser']		= "Delete";
		