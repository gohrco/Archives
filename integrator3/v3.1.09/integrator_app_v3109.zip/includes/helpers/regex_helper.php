<?php //00983
/**
 * ---------------------------------------------------------------------
 * Integrator 3 v3.1.09
 * ---------------------------------------------------------------------
 * 2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2015 December 15
 * version 3.1.09
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.    Go Higher Information Services, LLC  may  terminate  this
 * license if you don't comply with any of the terms and  conditions set
 * forth in our  commercial  end user license agreement(EULA).   In such
 * event,  licensee  agrees  to  return license or destroy all copies of
 * software upon termination of the license.
 *
 * For the full End User License Agreement, please visit our web site at
 * https://www.gohigheris.com/policies/commercial-eula
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPqWeUUDQhK7LD/7imAKMN2oiGcN3jqm5OQIiXP/0Cl6ON4uRx7xE2c5/AHd1bEf+6t6J8bb+
eqdh25R7ynRPSEhuK0aCbvXixL2BloJ6wgxmcGMfGHsjpkrYamj8q+L+2MwMQZMKur6TlDnxmSst
OG9EeLGDNSO2Pb4wG+9i8q03bggj02RquUET/5QOfjWTyuOwiQuLznhEhcByUEV+VRJHhZYLJyDD
uPz6FfI4gB3EwMlFGbWAcYDBJzzQwMKFSL5fhBmOOPHaSClh7s32que08vMdfXeFTWGkQsdIxgSu
tHdvmMSi5b48T9hMgo/wwtsW8zc8AIuESt6Pj9eDhqU9WOreZT43FUvmHDgYD6oCFozBHHH/6xq2
25t9nXVAGVpW4pJSVlz4dHKnZRDKriEIEf0DrRvo7hv9AEa58fyNVfwXi7rwu9+OXofW8xIFxnQ8
7FGFd3B7MDvENRJ+BTFUxyshqAzNlTGTCBOXyoLZZKoMm6q2Sdf0XGfD4kS8ly+cyxNjEhbV/PXM
17O4U6xu0bFaDOExLQDYjgP+8+Rcd73GznaZQALBoN1A7SLX67pFp0xAtLCxUjwMgYqv42S9PAo9
btAu3xzwerULeKSYwfY9XC5tRIo412PLSXhF1JRSpOj6O1B1n4oQMoLUq/9BZpynyK0IZnfar3WR
s0tqeSAoGW+HustUYFJYzzIONJe6srP63eepxoNar0czjXgMHGCqEuerdYXoYAln1vwgSuOZLAds
IWSk3R8m/jOEXO+/xFLEGe8VZYHJrnuJSZPNo7h2bYEqt27CGK3cbWv1MCFT+JGNJTfAVs/0bqxV
a4H0zu21npz6AZqaxK3860uCPEzRoq5pTaNqMLQXwDu9yKaBFmu4tecft4qaT9whca6GQhM0K4cQ
8k7wZEYCOkktqDSQTT1MjcVwpPr9AsWkFLVL0SBJGkUAgY7hH1BKwp3mtEJ+4sQDbjL+A/2J0ZaE
1z+CZ0FiqZYU9Iyvu5zVQlzQz1rq+7ITxKOPrVEitCcAI56DFZHt9W1HvauhfQQFbah9/iPY5dk2
MXB5PyG0+FvRHQRTE/CVGu0qfnCRFuYA0QJBtAnbYooae8fb56XfgEPZxDh8RBgI0Q/qwx4UdWSA
07VqdVGuufLQ0n+B/v9O6oi7ug7wLGoONqq7zGnPDpQXChnU6OWv6shpzzy+IeB/OLH5RZYclPVK
oxFPQ6LxqL0DtoO45d4AL/8Ly7HUFXGwJ4MWbg0EK6AKYvj8WcJC4hM0FylPEg1zKvxfSXEk8SvB
vMEl/vF+PbTWO3lqC8PDZbfaOiGnP9f3jP7R94j88JELIqCDznlKoPeV4f35zh2+vyA6E5uJanXd
CyQ5p3DWmOXsIbqZL97Tgjv0BxwhjmKalubvZXRtExqxzIgMRjaXfRzyW7aZqgQyEc9j575LFsHV
9JJ7xpYFpGjRuY//pw70Yjtpoefup3gLK93u6UyqwSL1dJN9wtbCK8pTjU7jaRAA3KX/UnxRSBH9
fQGGPRlRjYUuxQCET/qNIiq/vXd5Z7EH5BwBN9Qus8MU9va/vL77gRZtAS1boRj+kjuACVZ8NetD
TRTjyT2Ks3TLTmGQIsNBLLrZwu5vx5gVsvSmqEmDXNIjB9y694oE0WRRmzdCBetpbFLLzJgBlTdB
dBvBfu0ebap/kDmcutIEm6YO5sw8eDqL79600J3aYGVB3MMyJnHOGbQmD+4Gz/qjKax2JukwBQND
EG8My5CgbgujAKOLglibfnGpjuGlxdVp3b0ZAkczWv67SS+zIRU82I8t4QV0WUwC/iJmdn1ISqSF
beCPFpd0dP3YP8LK8+OkKU4168wNMkyaJ/pGXZuGDje7YhQyWpAgmFMNqCg8LxUd72IsggzTWCVE
3LBjV++cxuYMQRg1+fTsfejjc7tu8fBWE+0B6UqaeeqGE71ODjdW6n8MpBxMCmqM+Bl0aVE26wcA
0e0lAN2EB5GDjH2QhJ92PT9CgyyKQnjw4gGbvrkMHeSUOPG9UO0tD4LeDi2TsOTh413l3BPhqJAG
iThvNUrdvwapIDfdbNTRHH1F+Hqup/3mVdVFEpI5eb9cImsLpXG0jJHGBW8chAet7/AKk0NxYjum
P6i2Wz2Qe3WnrkIzOucFEWACIaTjLxsFWgJHL2gFQwniOCPWYzDrPqt/PSamvvp/9pD/rfdf92cg
MSQ007p5QwHjncQZNKHwjdDh/D5DueMY1cJQHnbfAYbwph6oa8HSBuHWEbI2HtG53Jf7B/rJpVVI
8ywkwA04DyRygWz1Za0/zxxx7L6HDhAIzqomsyM8Tcd58ytL/nKidTtTq/svoa7ah5wt24DsjwKU
t46fU4CsjeK+QDgSRgb6/tRR3C2n09BFe923Wlhtchw2ig21sJxg3ZdHosEPgqMjJeehT5whp6Kk
mL8zcsRVc/prUE/f5uQnDuQFI3BRTVKdkjlGl4/3L6LVRHhBI86Ao8WitW8Q4aoO6aGsQmHoqhdS
kcix4W8V5oBjs+lq/p/i7hJJnz7A02C0VnqbDtridBif/B6zxd9But7EKdIlgaIMYcP6y1iEhvYd
SjyZwT7mf+tXHSZuizqZtsId2KjZSyAKRRH7XZ48qYTsO8q80f/SgUAfQQ4IsB0NULnvbIHtNchJ
kot6Pt8UtJ6Ej/wA/3IrxS0ncguaOlR3ULEQs6ZrhDaeMJsgUHq3nHs7vWuPgTiKbsH38NK/L5fP
BeQ+wDPcJbl4aeE4Y8x1HBdWu91oRaIRFUE01gmwwIkC/IpgKKnzJAazaCfd1BOomBfCv73/9CLW
Rt2r6ixdaV2CMhWz4Px29YSkifPpMgqOoxnck05InyA/kax3GH3R5fWhk1ZvoXFhCnxG9FRDoR/t
+lsrnWZ/1Npd3YiA0Cg24wknkTi7WFZA4bZGCDOMen6SBLq1lhZpt5n/n/NC2mKbnbAVqjuaKEZn
kV8TKpqEj4U/3aYBDOgaREsQV0vJDuwpdwbGLCp/x8I6JGHLCaxCZOjS9ZgiLkeSONtTBm3Wu3Wi
aHN7mfHfTa3iZT6eisz91nlty8RMwWqKIrtRxOoeMzAhz8TBhORnmbSriJO/qrneRHIbWJqisxPe
ynReuFyx09drqytM0y2ZQSA1X6VXyKj0iYt5R8HOFsEhrsAFFc9mExwyfoEtifre/71ygvG8tJzz
ETGaTbMBOou3CemOZXmEdNrwkbAQKOKcnH0CY9mOjhrg6dRgtC/O9tl5Wyk/YgicEAxcsHptRzDx
L1w2d5CeQeRSIXDHT63wtSXFRtexodFNQNfiKC0tfENMjSz6Qd4b0s6sHg1Ntw0tL28Ywo3QRPfI
F+3fAWnZhAnRfCvZlp2CeuGccwOgX8zYxVFOrlO6slezHaGwBFusQZTgouskcroSfFOrfKQvACnv
78H1EMoezM3FDI+NBBzlpiaM6kKOajaZ4OWPofJY3bUbLBudns6X+vb0AFR71ULCQDg5b2NE+scI
b2Ylne7MChlNpAL07Z+AYMWZOVm1n6c5Ym7hHLBzNm1i6h1DBm2jzxSJaGlKI1GzzkaW2weLEtj8
1yQUUp4LjG2imC29p8l8dWd9EVh03aqdpAhDeF2bK7xt7HdQQuK8avPMdmpgMurSt2wuvSuCsvhv
vFDs0yeGqH5JY+CFaOh7XEs4yK+fFcVvRjz+ctQcfL6PnzT30xjHVue5vkSdCZ+tcqGu4QCv5YlO
mdn4v6WBHn4Xame+GuA89VxwQ7Xl/vkpaZyg2T9uJITne8n6moapWmyo++gM5uttz/9ajJjfA5Aw
+lihBgyxv/40wrsSazyqjJdfCG0D0u7XlIKE4eGmyb6wYNv587ul1lSWecRYKTr8G6YDu/C7owg9
f0wYblg8ibj2jhWvXUq7gf2RT8BYpWUUkp9G2CKJOHMtrpaI8IL9s4ca1YbGJcH4zRYdGyUAS1jM
6kYwWUQ2WMdB/FzENuHTnG05R25B0rpcOhcz/6FUqhtzJohgDdD3PwzxcKE8ICPtJ17CjAD+5Y91
iwMsX6ovBgjBiUsbhkSfA7kXIhu6DH4pbNNGQws4AqVonI3xJc0L0m6yalWjC47OwYZ+nLCVXSyO
Ja/6pAZbfZfH+l+tvgrdUVzHwzA/61FGdzbWojeDtwqrdfd/PkeYNCVRakFVt1HjyFArZSWxhGc6
N+Yc76c9kQ5F7ickVE1m9VrgSTalPDw5GATHmdLjDt1MPnJ+FIzyMPEiWCe3mGg9DBlmVMwm1xLP
qNC9XIZJlfo5ZcXpLoad/9jwUgQ1om6cCDH5Uk/KuKJRFs3EZDtoTH2AxreNdTYqy8APWiGLb+TQ
lSknwyga4Qtgxv+E1xpPuZbF/b96pqLIS2mhUT+E1rQl0PULRCE63pPPkNDuXIwMlzablY0zM0gm
AenTRbl23zZeOGCfOLE44+NhrW5axtl8ujAuTo5vs9KRFLcveeVtwJHDhkHyVCr5esR7/nlsQYdw
pq+98XFZQvIHky/xAgCBlLPYesxe5S33UOFfEfv/Sz19aFv567L4dkXLNaymuwfThk+CT3Ct56et
3c+DRxRmmZachea314F7foVBjjTtmNWi8UDDZ/zhZGBfoKDf3sjztegl9rxxxRkpMbq2zTyhxAIS
gY5I3oAqQpMvnKpdDddnHCdLq5ARi+dxhvDMIiYhD+9IclOqtom/KPrkDPv72EUoNCa6XBY9AypR
QqxODwQ8HC+mueCQ4hGsHKvDHEmNt0/PgKdIUe4KTI+vLpkrlWsjNmFjfwNj3E5qDP1dLsnOKjei
am7UlPrnW+Fb4nPnwoO96fkIkg55xNyTSSBTyYkobRQ8xt3+DYEQDOwZJAyaW5Al9wpAsuwVu5IQ
QgKh4OHuwZXlWmp8DXsuqmu4hkK14x8KfRBl35ytHLuYOf20wGgNt5RClCVsdGxXLn5wc4LCIgQ8
9JZaLCNC4Qt4zWhR431gEDCJOXjwchwclpQqES3Fv20S0Jgeeova3aJpeIL/H4LQ2buhTr7y+jvq
JoYOS+T1AGHTegzlSnLXNTPTHBrWxxpm4RUzqp7TJ0h+qvdE7s1o8fHk5KQYJ+GHpcbQ2uPPGOwO
SqltkrhCqBOw0CCkBFGtzJhK3sqGEH14U2Tub4vl3yMGt6D4ulup2/Ctk41hG9WaAgqSQXN/PE8P
MFyUE89enh/8EJZTKbwF4WIazfQDTdsgV7eIdcUdyN/JmtkJqjDnKFn5W40g/c/XLeS/+0G+jyaI
I7T42uQs6nAw+WmmYs49Bn69FwUwlI+33ihuGd4H5F+OuZlXM9RSfiKMAufKDvxmCUCUFPe4o6oT
2dBTxBR4e+yvzMh8hxSb+NYCkl7X66iA0ssyTy1zev8Bc/oTTHPV2ZHtoVw1Vum4T26NEIfM8Qvv
kczNbL0+hdbJqGFfzxVSc3zcNzJPNWMlO9Bm8uOL+XqaFG+hpJN3Ve+9U3e0UObQHj4RwiSnJ/F/
hu9WLhfj2bW+llOV+VZePm/VHwDZ5DrwKTGeeY9dBzqEl9dN2S8GDUaOPqEuMesZIg4ucojl4H42
1oY0PpSiTj/mMmLNSM7j4/uAqDsKXp8l76Zp5Vpi8d3Nq69cz/f095B1rao7OPorU7vb/ZMFfMQo
Ewvp8bxTjv9Tdhi1P5wpw4crJ04aPOVCrXuGqH/6Xw6u1c8+xuY0lmr5yC7oZncQc5BRgK2Nr2qf
hh6U4uNM3whxm7uYQDQL2GXLNKoCeQJfXa1deg5qvDZm40Smw0rXLRV3XRJImUlxxos0LcBNaNTv
NBZVadQPh4GKPp02B5F8cXl0C0nEPnHn5p5KnqI9YIsPWQNuWk7gW9CTM5fxXmNdNU0LX8gCA8Ap
DjSCUVKWPmX8vo883vdteZhVR1U4QUiDXTR//jcvqOY+DwJ8KvITR5EiOM49H42mG1TXtIoIgMuE
42jA6sz3ELcG9RH7zdEXKzboOLfsP8xBY1fxMbXUAzku8/cAhI+KvV9pCyJlWyZu8z7t9ZQ0hmyl
wEhh0zB72EMO5c8FfrUZRykVq35M6U/4fhzPK7lUnNvd5F4bE9hwHsrHZGhFqcEKuAncl3RuhZgk
DYrvqvkT4Lj1GQ+XmM4eulhXGOQwtCSiO69SBCcLtJxkGQKK3v8wklBymN1bdt1r5TV9mIMSdN1q
KACNWrGMvTV26EymM04Dwd+5i6L5pnGVxLTgLmsTvQJHGNFjzTNTj6TZ2l/a/eNHt5eLl4xBsVwe
T5IZyioTvuDuu7N5Z2vcnp2ZFo1v7BdLL8IU0Ot/8KPKEK/AiB8p3GBEuWRK8+MtdJUdHeprGSa2
dUiEn++TKNTOX7XN4cpnjF8qq4fSTjGmtBsMIplJ5LoXl8NQAdZk4BIas4UNIg9/dYBwfuJ7Sb0X
HyfwYysRDS61Es7/AlXZMFMyf6QORDoHfio0zlJjjmarPB1NntxOzbAUU56leDR9Ysexi5nqi/R6
lCGUg2d/0xEkbrn2UH14pRwgq6wZTgdrZk5U2SGg2QDuvfLHC2/Z2h2W41YXvAeXJSwsTaeRpIl4
NFnNjYZl0xLcqsexRQXocUjbZG8JEEYNTKwRArPmXhYMM0bm041fq5r8Wb0KEW4GxyrzjOVjxiyM
v82LieLIY9yexwWpq2yCdrpTBGXhX7NmX7fQ6VAbRU7MfmT+lcVgUMdTj5ejAJjNvQtyPjPGJ1nt
TDXybHjiKs0YqKsagKb08UeMRhATmWKhFG2eeu2H6paq4lJb6YNhamvxnLCWhyJ4ogKMr49pwfBh
26KmGO76Ejh3KoQbM1YEEK4oMjoo1sSxYE2Ogzj845yJXzcRIN7etSt3AeBzWOSYRZ08hADds0GV
O5F8xFeh0jmmlePmIDjBCch7+79cdZtr0krVHD4DBrAHZZjTg+NLHwQ4P7cQm5fmuO+DFo13Wfx+
4tglXysTCHe8+8XpCZdaTJuTy/u/isWU0vzWYu+G08akTQ1/A1l64h+vfT1hLOyqQYZt25RF+Qje
iz88XOW+Sw9+VPH7tagbPuWqVlys04UV622lYGAsGi3w3meQ7eYV2Uc/hM5fwvhsPOvUfoaKsXsl
3rhqJw4e452SKwJ6H5q0xmdq6CZyHG2gLAzV/QhJsUqznRHaIOJfYdJv0jPJIZ8pdLekQ887n+xz
DGk9KZQUiJRnZVdFRfN4uOlR7k5AhjEtuA4uw8Qxgtaz5oeTFqAwA17GyiNMHjh5D1bNBgXSlB5b
lgXjdbxGjiM6FpwjFviWrePuKgsBL0GAlCW2b0m5+hkxu3wxp0OtnpMMGwOKqFzGUSFAlcetFoBo
IDqcpmKHYQJY5klKP/augjZ8R/NDpQH26/KNcUTIqxDUBEUaM6p4ohPJBe2aoVIhrfqLsRT4LZQs
DGy1008PzuutPsImkVN0dRntAhYtaUb8xZ4lv9CoqYdacdjGqduvMD5gkbVqCyfpRc5Vbl18OqRN
OY6cosBwHIl5+XtqE6ztEEiD3Y2dlE4qrpu5HHdXMDk7EwqsjD1/y9aHCcCFEGMHUpLiIeCLBKrr
5Dy/lGRpedzu7p1TYsEP8XFnRu2Lp8PwQGkZtScgnSVTtWogdJaFElslwv0UeL6BD1FrTYz4/w5w
iI8FbTKtZGxe8n1AVXOH0+Fh9RSYbYAgtEI/hripWKCC1T16QTtFAS9JWzViRqDW0HXJfSuP+ZJW
4Zhi2fqA3KVcWFhTAMEoQl7IRfFsysMw3e+8qtqtxs9DCVvnxFd5wQl+M1wLyloZubRp4Qrs508N
baF3xsk8J+7lVqtkuzxU+HkJNFOqDz3kgllx6A4Et8PJP0FEQjsfZsLTfgZvm7F1GphPx/l8Xp3I
l+f6a3Gs6oxokaXocog2N/aSsBzoj9YhmIuDqabuk89yq67j2I1XtDR+8/qlM61lukPAfHAHlMTh
PomLuq7fBGgYgzS2fnKdJQyYAzO9yn75Enl/d0pYMOnOW5wj/Pt1mJXp62RFqFnxhGJxcuaWxZqW
uKdXtSK5YQR6FnJ4+mFlhYwXvAzfQ7Hj2tTG3fDDaCWQLsLGtH1tH6mPb4yjaV9rc0OL1V0147Az
o2pvA47vbCmpwG83S+p2tb7HyxlC2fSBGKwVb3IsoyLxQrytCmkOWtnBnRTomUqzzlZH6BfuRots
OuoWg+/7xzfdEeefHZfq8IVuJnBG+AvJ+LyKRSLUMP7BhXdyxX4tFUwb75vDqo/89tR3WljTswQm
O6/rxhB7aI5oDXkz1XNFxRukZwIe892nKmqbU+bJ0G7vi3ZTRg/gqVNTcLlDlTdjw6G4L7O/El/i
BW3afPVSZBlw0wc9OiqUz65bE6TBR+2VeHHujmyjTN55mpv1TGu/NhdCKskpOOIkuT4koQl28BLh
nQNW+BWrYFVNV/nRbavMobMQ78VNaDFVuegaghKNPlv2ZbSe/1Eag6o3H3gQAXKofoz4smg+Os7Y
SAT1HDHsmJ3dyCRZHK9ydQ+mbTVMMT5ajf7DR5M7tKTtVBW7RvCMC3QNxzQ66QWDsEOBbF6qXE+8
oSiXQ6Z+CrGJ209lW55rI6qk+pOwvkZVOrfcpKdvgUy8OyUMY2Lm0Tv0439Y09E9oyAbOUnRuQF3
4lGJwhvIQ4bq6plNqUs8XYQazYlS1QX6cWH5/qQIdicDlAvfEFtT91Xc4EvWqz7KOieB+m+q0xyt
3gqWtMb3SNsgrd/hM4z8trHlffd0GecfHkQw21B/0DdnzoTlNpJUQKnkbWLH66hT0k4BCjfJmM44
fAcVuHPnsc2kVjoGdPa8ng4XLKvuBYxAPcG8rGOVafoSvUrr4OE+5PLXkL5Bt5ovU1KfiH2uM1We
+5xDlEw1IbrV1SVvC0Vsq6bSrSFuIwS4a0bHlu2NiTWWHnm3PNLXi3QZnXUJCR+LTlKOAs9prh4K
UQCXHmoGobQOgE1TpAncoSAUizUjhJQhWImt5l8lAJy+bZOcz1183i3YbGiqTZXFM/IRreV67aB/
FeqZO0d1fSJyNEgnRkBeV2Ub70KBGEtYf7svR8pZIuqUxenWqnC8lcdbIYbdf6I/fisE3EYp/ixB
ERwe+My++8ylah//plU0Q/xcQ712wQWAMbEmQ0SnWJfRmSKSIfkHY7UQ069GM5sTSn3JSFvYfTmh
6gb7poMvtZHkM5a86BFQ25LshzeDuJ44h0roDKWJB0Pm5K5mVDe9zWn1WqRCmLz/QCPjTBtFr5m7
5DGSnC9z3TWfQpwVfG1dgMe6AfmoYUlnDuSQdQ48K7l+KVzP5ftE1p5lH55AueN+GrXbwaP11xh4
maYFkRCU0WmLcpRjFhr1duo5f7iS8BQXKzHqUKB5JYnZpzOWusK5jFwnbmm2HdP/+UtFQs5thqwj
k1GCZfZgFGYsoeTFnMh2nf4gBRIE2/Eb6R0cyD4Z64T4LKKtX0sPw5fdmjVVyLJWxOtmHhPIYFK/
RmoZUk5adNlFIlHeyDJEIsyiqcwAAwphcWjUzCbEQiCO/5XmClb8uYpmB/53oQtnu1HFIhzq+296
kOVskU9LwLc9pMRO1QPe1oQWqM303JZGndOnpFUSBRp6W2GF