
INSERT IGNORE INTO `__DBPREFIX__settings` (`key`, `value`) VALUES
( 'GoHigherUsername', '' ),
( 'GoHigherPassword', '' );
