<?php
/**
 * @package         Integrator 3
 * @version         3.1.09
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       @copyRight@
 * @license         GNU General Public License version 2, or later
 */

defined( 'DUNAMIS' ) OR exit('No direct script access allowed');

/**
 * Dunamis Debug class for Integrator 3
 * @desc		This handles debug requests for the Dunamis Framework
 * @package		Dunamis
 * @subpackage	Joomla
 * @author		Go Higher Information Services, LLC
 * @link		https://www.gohigheris.com
 * @copyright	2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license		GNU General Public License version 2, or later
 */
class Com_integratorDunDebug extends DunObject
{
	/**
	 * Stores our debug setting
	 * @access		private
	 * @var			boolean
	 * @since		3.1.00
	 */
	private $_debugenabled	=	false;
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.1.09
	 * @param		array
	 * 
	 * @since		3.1.00
	 */
	public function __construct( $options = array() )
	{
		$config					=	dunloader( 'config', 'com_integrator' );
		$this->_debugenabled	=	( $config->get( 'IntegratorDebug', 'No' ) == 'Yes' || JDEBUG ) ? true : false;
	}
	
	
	/**
	 * Singleton
	 * @access		public
	 * @static
	 * @version		3.1.09
	 * @param		array		- $options: contains an array of arguments
	 *
	 * @return		object
	 * @since		3.1.00
	 */
	public static function getInstance( $options = array() )
	{
		static $instance = null;
	
		if (! is_object( $instance ) ) {
				
			$instance = new Com_integratorDunDebug( $options );
		}
	
		return $instance;
	}
	
	
	/**
	 * Method to store an error message to our stack
	 * @access		public
	 * @version		3.1.09
	 * @param		string
	 * @param		array
	 * @param		boolean
	 * @param		string
	 * @param		integer
	 *
	 * @since		3.1.00
	 */
	public function error( $message, $arguments = array(), $translate = false, $type = 'error', $setbt = 0 )
	{
		$bt = debug_backtrace();
		$bt = $bt[$setbt];
	
		$data	=	array(
				'message'	=>	( $translate ? t( $message, $arguments ) : $message ),
				'line'		=>	$bt['line'],
				'filename'	=>	$bt['file'],
				'type'		=>	$type
		);
	
		$this->_add( $data );
	}
	
	
	public function isEnabled()
	{
		return $this->_debugenabled;
	}
	
	
	public function log( $message, $arguments = array(), $translate = false, $type = 'debug', $setbt = 0 )
	{
		$bt = debug_backtrace();
		$bt = $bt[$setbt];
		
		$data	=	array(
			'message'	=>	( $translate ? t( $message, $arguments ) : $message ),
			'line'		=>	$bt['line'],
			'filename'	=>	$bt['file'],
			'type'		=>	$type
		);
		
		$this->_add( $data );
	}
	
	
	public function render()
	{
		// If not enabled return empty
		if ( $this->isEnabled() == false ) return array();
		
		// Grab the session and debug from the session storehouse
		$session	=	JFactory::getSession();
		$data		=   $session->get( 'debug', array(), 'integrator' );
		
		// Clear out the sesion to prevent redisplay
		$session->clear( 'debug', 'integrator' );
		
		// If we have something unserialize it
		if ( $data ) $data = unserialize( $data );
		
		// Send back
		return $data;
	}
	
	
	private function _add( $data )
	{
		$session	=	JFactory::getSession();
		$debugs		=   $session->get( 'debug', array(), 'integrator' );
		
		// If we have something in the session, unserialize it
		if ( $debugs ) $debugs = unserialize( $debugs );
		
		// Add to the debug array
		$debugs[]	= $data;
		
		// Serialize the debug array and set it into the storehouse
		$session->set( 'debug', serialize( $debugs ), 'integrator' );
		return true;
	}
}