<?php
/**
 * Integrator 3
 * User - Integrator Plugin
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.09 ( $Id: integrator_user.php 457 2015-11-17 21:03:31Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This is the file executed by the User - Integrator plugin for handling calls to the Integrator and redirecting upon log in and out
 * 
 */


/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.router' );
jimport( 'joomla.environment.uri' );
jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.application.component.helper' );

// Ensure Dunamis is loaded
jimport( 'dunamis.dunamis' );
/*-- File Inclusions --*/

/**
 * User - Integrator plugin
 * @version		3.1.09
 * 
 * @since		3.0.0
 * @author		Steven
 */
class plgUserIntegrator_user extends JPlugin
{
	/**
	 * Local enable
	 * @access		public
	 * @since		3.0.0
	 * @var			bool
	 */
	public $_enabled	= false;
	
	/**
	 * If true we are to update through the Integrator API
	 * @access		public
	 * @var			boolean
	 * @since		3.0.0
	 */
	public	$runupdate	= true;
	
	/**
	 * Stores the old user to compare new settings against
	 * @access		public
	 * @var			array
	 * @since		3.0.0
	 */
	public	$olduser	= null;
	
	/**
	 * Joomla 1.5 required
	 */
	public	$debug		= true;
	public	$revert		= false;
	public	$revertdata	= null;
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		3.1.09
	 * @param		unknown_type $subject
	 * @param		unknown_type $config
	 * 
	 * @since		3.0.0
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct( $subject, $config );
		
		$this->loadLanguage();
		
		$app		=	JFactory :: getApplication();
		$user		=	JFactory :: getUser();
		
		// Run through tests
		// -----------------
		// Ensure we have Dunamis installed
		if (! function_exists( 'get_dunamis' ) ) {
			return;
		}
		
		get_dunamis( 'com_integrator' );
		$config	=	dunloader( 'config', 'com_integrator' );
		
		if (! is_a( $config, 'Com_integratorDunConfig' ) ) {
			return;
		}
		
		// Ensure we are active...
		if (! $config->get( 'Enabled' ) ) {
			return;
		}
		
		// Ensure we have a token set
		if (! $config->get( 'IntegratorSecret' ) ) {
			return;
		}
		
		// All good, lets go
		$this->_enabled	=	true;
		
		return;
	}
	
	
	/**
	 * Checks info before saving it for validation
	 * @access		public
	 * @version		3.1.09
	 * @param		array		- $olduser: current user info
	 * @param		boolean		- $isnew: true if new
	 * @param		array		- $newuser: new user info
	 * 
	 * @since		3.0.0
	 */
	public function onUserBeforeSave( $olduser, $isnew, $newuser )
	{
		$config	=	dunloader( 'config',	'com_integrator' );
		$config	=	dunloader( 'helpers',	'com_integrator' );
		$input	=	dunloader( 'input',		true );
		
		// Ensure we do nothing if we are disabled
		if (! $this->_enabled ) return true;
		
		// If we are coming from the API, check for constant
		if ( defined( "INTEGRATOR_API" ) || defined( 'INTEGRATORAPI' ) ) {
			$this->revert		= false;
			$this->runupdate	= false;
			return true;
		}
		
		// Build the validation array and if nothing is different, then don't run the update
		$post	= $input->getVar( ( version_compare( JVERSION, '1.6.0', 'ge' ) ? 'jform' : 'post' ), array(), 'array' );
		
		if (! ( $validation_array = build_user_array( $post, $olduser, $isnew ) ) ) {
			$this->runupdate = false;
			return;
		}
		
		// Catch if there are no differences, dont bother checking against Integrator (password change for instance) to prevent looping
		if (! isset( $validation_array['update'] ) && ! $isnew ) {
			$this->runupdate = false;
			return;
		}
		
		// Work with update array if it is set
		if (! $validation_array['update'] && ! $isnew ) {
			$this->runupdate = false;
			return;
		}
		
		$api_task	= "post_validateon" . ( $isnew ? "create" : "update" );
		
		$api 			=	dunloader( 'api',	'com_integrator' );
		$response		=   $api->$api_task( $validation_array );
		
		// User validation is okay on other connections
		if ( $response ) {
			$this->olduser = $olduser;
			return true;
		}
		
		// Unable to update connections so we must fail
		$this->runupdate	= false;
		
		// Joomla 1.6 gets off here
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			JError::raiseWarning('20', 'One or more connections refused validation ('. ($isnew ? 'create' : 'update' ). '):  ' . $response );
			return;
		}
		
		// We can't stop the user from being updated in Joomla 1.5, but we can revert it after the fact
		$this->response		= $response;	// Error message received
		$this->runupdate	= false;
		$this->revert		= true;
		$this->revertdata	= (object) $olduser;
	}
	
	
	/**
	 * Handles a change to user information by calling API (or reverting info if validation failed)
	 * @access		public
	 * @version		3.1.09
	 * @param		array		- $user: current user
	 * @param		boolean		- $isnew: true if new user
	 * @param		unknown		- $success: does nothing in J1.5
	 * @param		string?		- $msg: current errors
	 * 
	 * @since		3.0.0
	 */
	public function onUserAfterSave($user, $isnew, $succes, $msg)
	{
		$config	=	dunloader( 'config',	'com_integrator' );
		$config	=	dunloader( 'helpers',	'com_integrator' );
		$input	=	dunloader( 'input',		true );
		
		// Ensure we do nothing if we are disabled
		if (! $this->_enabled ) return true;
		
		// If we are reverting, check for constant
		if ( defined( "INTEGRATOR_API" ) || defined( 'INTEGRATORAPI' ) ) {
			return;
		}
		
		// Check if we are updating anything
		if ( (! $this->runupdate ) && (! $this->revert ) ) {
			return;
		}
		// Check if we are to not update and in fact revert to the old info (Joomla 1.5 only!)
		else if ( (! $this->runupdate ) && ( $this->revert ) ) {
			// Run update to JUser object
			$olduser =	JFactory::getUser( $this->revertdata->id );
			$update		=   array( 'name', 'username', 'email' );
			foreach( $update as $p ) {
				$olduser->set( $p, $this->revertdata->$p );
			}
			
			// Ensure we don't recursively continue doing this...
			define( "INTEGRATOR_USER", true );
			define( 'INTEGRATORAPI', true );
			
			$olduser->save();
			JError::raiseWarning( '10', sprintf( 'User information for %s has been reverted (except password) and NOT updated on other connections (Integrator: %s)', $olduser->get( 'name' ), $this->response ) );
			$this->_debugger();
			return false;
		}
		
		$updateuser_array = build_user_array( $user, $this->olduser, $isnew );
		
		$api_task		=   ( $isnew ? "post" : "put" ) . '_user';
		$api 			=	dunloader( 'api',	'com_integrator' );
		$user_updated	=   $api->$api_task( $updateuser_array );
		
		if (! $user_updated ) {
			JError::raiseWarning( '20', sprintf( 'Response from Integrator: %s', $user_updated ) );
		}
		
		return;
	}
	
	
	/**
	 * Redirects user to the Integrator to complete log in
	 * @access		public
	 * @version		3.1.09
	 * @param		JUser object	- $user: current user
	 * @param		array			- $options: option array passed
	 * 
	 * @since		3.0.0
	 */
	public function onUserLogin($user, $options)
	{
		// Ensure we do nothing if we are disabled
		if (! $this->_enabled ) return true;
		
		$app	=	JFactory::getApplication();
		$config	=	dunloader( 'config',	'com_integrator' );
		$input	=	dunloader( 'input',		true );
		dunloader( 'helpers', 'com_integrator' );
		
		// We shouldn't run this if we are the administrator
		if ( is_admin() ) return;
		
		// Be sure we send it back if we are logging in ourselves!
		if ( isset( $options['integrator'] ) ) return;
		
		// Be sure we have a password available to use
		if ( empty( $user["password"] ) ) return;
		
		// Retrieve session variables to pass along
		jimport( "joomla.session.session" );
		$session	=   JSession::getInstance( null, array() );
		$session->set( "credentials", array( "password" => $user["password"], "username" => $user["username"], "email" => $user["email"] ) );
		
		$session	=   encode_session( $session->getName(), $session->getId() );
		
		// Create Form Action
		$path	= ( $input->getVar( 'integrator', false ) ? '/succeed/' : '/index/' . $config->get( 'cnxnid' ) . '/' );
		
		$uri	=	DunUri :: getInstance( $config->get( "IntegratorUrl" ) );
		$usessl	=   $config->get( 'UseSSL', 'ignore' );
		$isSsl	=   ( $usessl == 'force' ? true : ( $usessl == 'none' ? false : DunUri::getInstance()->isSsl() ) );
		$uri->setScheme( "http" . ( $isSsl ? "s" : "" ) );
		$uri->setPath( $uri->getPath() . '/index.php/login' . $path );
		$action	= $uri->toString();
		
		// Create Form Fields
		$fields	= array( '_c' => $config->get( 'cnxnid' ), 'session' => $session );
		
		if (! $input->getVar( 'integrator', false ) ) {
			
			if ( ( $return_url = $options['return'] ) == null ) {
				$ret	= clone DunUri :: getInstance();
			}
			else {
				// See if return_url is base64 encoded
				if ( preg_match('/^([A-Za-z0-9]�\+�\/�\-�\=)+$/', $return_url ) ) {
					$return_url = base64_decode( $return_url, true );
				}
				
				// Because J1.5 and J2.5 use different URI functions we must do our own tests
				$uri	= DunUri::getInstance( $return_url );
				$base	= $uri->toString( array( 'scheme', 'host', 'port', 'path' ) );
				$host	= $uri->toString( array('scheme', 'host', 'port' ) );
				
				if ( ( stripos( $base, DunUri::base() ) !== 0 || stripos( $base, DunUri::base() ) !== false ) && !empty( $host ) ) {
					$ret	= $uri;
				}
				else if ( ( stripos( $base, DunUri::base() ) !== 0 || stripos( $base, DunUri::base() ) !== false ) && empty( $host ) ) {
					$ret	= clone Juri :: getInstance();
					$ret->root( false, $return_url );
					$ret->setPath( rtrim( $ret->getPath(), '/' ) . '/' . $uri->toString() );
				}
				else {
					$ret	= clone Juri :: getInstance();
					$ret->root( false, $return_url );
				}
			}
			
			// ---- BEGIN: INT-16
			//		Invalid Token arrived at when logging into I3 from Joomla login form
			if ( stripos( $ret->toString(), 'task=user.login' ) !== false ) {
				$ret	=	DunUri :: getInstance( JUri :: base() );
				$ret->setVar( 'option', 'com_users' );
				$ret->setVar( 'view', 'profile' );
			}
			// ---- END: INT-16
			
			$return_url = base64_encode( $ret->toString() );
			
			$fields['username']	= $user['username'];
			$fields['passwd']	= $user['password'];
			$fields['return']	= $return_url;
			
			if ( $options['remember'] ) $fields['remember'] = $options['remember'];
		}
		
		// Redirect
		form_redirect( $action, $fields );
	}
	
	
	/**
	 * Sends the user to the Integrator for logging out
	 * @access		public
	 * @version		3.1.09
	 * @param		JUser object	- $user: current user
	 * @param		array			- $options: option array passed
	 * 
	 * @since		3.0.0
	 */
	public function onUserLogout( $user, $options )
	{
		// Ensure we do nothing if we are disabled
		if (! $this->_enabled ) return true;
		
		$config	=	dunloader( 'config',	'com_integrator' );
		$input	=	dunloader( 'input',		true );
		dunloader( 'helpers', 'com_integrator' );
		
		// We shouldn't run this if we are the administrator
		if ( is_admin() ) return;
		
		// Be sure we send it back if we are logging out ourselves!
		if ( isset( $options['integrator'] ) ) return;
		
		// Since we are the last user plugin to run before redirection kill cookie
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			setcookie( JApplication::getHash( 'JLOGIN_REMEMBER' ), false, time() - 86400, '/' );
		}
		else {
			setcookie( JUtility::getHash('JLOGIN_REMEMBER'), false, time() - 86400, '/' );
		}
		
		// Create Form Action
		$path	= ( $input->getVar( 'integrator', false ) ? '/complete/' : '/index/' . $config->get( 'cnxnid' ) . '/' );
		
		$uri	=	Juri::getInstance( $config->get( "IntegratorUrl" ) );
		$usessl	=   $config->get( 'UseSSL', 'ignore' );
		$isSsl	=   ( $usessl == 'force' ? true : ( $usessl == 'none' ? false : Juri::getInstance()->isSsl() ) );
		$uri->setScheme( "http" . ( $isSsl ? "s" : "" ) );
		$uri->setPath( $uri->getPath() . '/index.php/logout' . $path );
		$action	= $uri->toString();
		
		// Create Form Fields
		if (! $input->getVar( 'integrator', false ) ) {
			$fields	= array( '_c' => $config->get( 'cnxnid' ) );
		}
		else {
			$fields = array();
		}
		
		// Redirect
		form_redirect( $action, $fields );
	}
	
	
	/**
	 * Deletes a user from the rest of the Integrated applications
	 * @access		public
	 * @version		3.1.09
	 * @param		array		- $user: user being deleted
	 * @param		boolean		- $success: if deletion was successful
	 * @param		string		- $msg: error message (useless)
	 *  
	 * @since		3.0.0
	 */
	public function onUserAfterDelete($user, $success, $msg)
	{
		// Ensure we do nothing if we are disabled
		if (! $this->_enabled ) return true;
		
		// If we are using the API, check for constant so we dont keep recursively delete
		if ( defined( "INTEGRATOR_API" || defined( 'INTEGRATORAPI' )  ) ) {
			return;
		}
		
		// If user hasn't been deleted don't remove them elsewhere!
		if (! $success ) {
			return;
		}
		
		$api		=	dunloader( 'api',	'com_integrator' );
		$response	=	$api->delete_user( array( 'email' => $user['email'] ) );
		
		return;
	}
	
	
	/**
	 * onBeforeStoreUser - Joomla 1.5 compatibility
	 * @access		public
	 * @version		3.1.09
	 * 
	 * @since		3.0.0
	 */
	public function onBeforeStoreUser( $user, $isnew, $newuser = array() ) {
		$result = $this->onUserBeforeSave( $user, $isnew, $newuser );
		return $result;
	}
	
	/**
	 * onAfterStoreUser - Joomla 1.5 compatibility
	 * @access		public
	 * @version		3.1.09
	 * 
	 * @since		3.0.0
	 */
	public function onAfterStoreUser( $user, $isnew, $success, $msg ) {
		$result = $this->onUserAfterSave( $user, $isnew, $success, $msg );
		return $result;
	}
	
	/**
	 * onLoginUser - Joomla 1.5 compatibility
	 * @access		public
	 * @version		3.1.09
	 * 
	 * @since		3.0.0
	 */
	public function onLoginUser( $user, $options ) {
 	    $result = $this->onUserLogin( $user, $options );
 	    return $result;
 	}
 	
 	/**
 	 * onLogoutUser - Joomla 1.5 compatibility
 	 * @access		public
	 * @version		3.1.09
	 * 
	 * @since		3.0.0
 	 */
	public function onLogoutUser( $user, $options = array() ) {
 	    $result = $this->onUserLogout( $user, $options );
 	    return $result;
	}
	
	/**
	 * onAfterDeleteUser - Joomla 1.5 compatibility
	 * @access		public
	 * @version		3.1.09
	 * 
	 * @since		3.0.0
	 */
	public function onAfterDeleteUser( $user, $succes, $msg ) {
 	    $result = $this->onUserAfterDelete( $user, $succes, $msg );
 	    return $result;
	}
}