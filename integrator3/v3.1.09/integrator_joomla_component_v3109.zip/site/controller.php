<?php
/**
 * Integrator 3
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.09 ( $Id: controller.php 287 2013-09-25 21:32:09Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This is the main controller file for the Integrator
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or exit('No direct script access allowed');
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.controller');
require_once( JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_integrator' . DIRECTORY_SEPARATOR . 'helper.php' );
/*-- File Inclusions --*/

/**
 * Integrator Controller class object
 * @version		3.1.09
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntegratorController extends IntegratorControllerExt
{
	/**
	 * Displays the front end, setting the default view if not set.
	 * @access		public
	 * @version		3.1.09
	 * 
	 * @since		3.0.0
	 */
	public function display( $cachable = false, $urlparams = array() )
	{
		// If the view hasn't been set, set it to default
		if (is_null(JRequest::getVar( 'view'))) JRequest::setVar('view', 'default' );
		
		// Call up the parent display task
		parent::display( $cachable, $urlparams );
	}
}