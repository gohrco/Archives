<?php
/**
 * Integrator 3
 * WHMCS - Admin Module Base File
 * 
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.09 ( $Id: integrator.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      3.0.0
 * 
 * @desc       This file is the root file loaded by WHMCS upon selection of the "Integrator" addon
 * 
 */

/*-- Security Protocols --*/
if (!defined("WHMCS")) die("This file cannot be accessed directly");
/*-- Security Protocols --*/


/**
 * Configuration function called by WHMCS
 * @version		3.1.09 ( $Id: integrator.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * 
 * @return		An array of configuration variables
 * @since		3.0.0
 */
function integrator_config()
{
	if (! function_exists( 'dunmodule' ) ) {
		return defaulti3_adminConfig( 'dunamis' );
	}
	
	// Load the jwhmcs module
	$module		=	dunmodule( 'integrator' );
	
	// Test to ensure it is found
	if (! is_object( $module ) ) {
		return defaulti3_adminConfig( 'module' );
	}
	
	return $module->getAdminConfig();
}


/**
 * Activation function called by WHMCS
 * @version		3.1.09 ( $Id: integrator.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * 
 * @since		3.0.0
 */
function integrator_activate()
{
	if (! function_exists( 'dunloader' ) ) return;
	$install = dunmodule( 'integrator.install' );
	$install->activate();
}


/**
 * Deactivation function called by WHMCS
 * @version		3.1.09 ( $Id: integrator.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * 
 * @since		3.0.0
 */
function integrator_deactivate()
{
	if (! function_exists( 'dunloader' ) ) return;
	$install = dunmodule( 'integrator.install' );
	$install->deactivate();
}


/**
 * Upgrade function called by WHMCS
 * @version		3.1.09 ( $Id: integrator.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * @param		array		- Contains the variables set in the configuration function
 * 
 * @since		3.0.0
 */
function integrator_upgrade($vars)
{
	$install	=	dunmodule( 'integrator.install' );
	
	// Ensure backwards compatible to v4.41
	// Bug in WHMCS dox state to use vars['version']
	if ( isset( $vars['version'] ) ) {
		$version = $vars['version'];
	}
	else
	// But this is what is found in 441
	if ( isset( $vars['integrator']['version'] ) ) {
		$version = $vars['integrator']['version'];
	}
	
	// We must handle legacy upgrades now
	if ( version_compare( $version, '3.1', 'l' ) ) {
		$install->legacy();
	}
	
	$thisvers	= "3.1.09";
	
	while( $thisvers > $version ) {
		$filename	= 'sql' . DIRECTORY_SEPARATOR . 'upgrade-' . $version . '.sql';
		if (! file_exists( dirname( __FILE__ ) . DIRECTORY_SEPARATOR . $filename ) ) {
			$thisvers = $version;
			break;
		}
	
		$db->handleFile( $filename, 'integrator' );
		$db->setQuery( "SELECT `value` FROM `tbladdonmodules` WHERE `module` = 'integrator' AND `setting` = 'version'" );
		$version = $db->loadResult();
	}
	
	// Handle files
	$config	=	dunloader( 'config', 'integrator' );
	
	if ( $config->get( 'autofixfile', false ) ) {
		$files	=	$install->checkFiles();
		foreach ( $files as $file => $state ) {
			if ( $state->current ) continue;
			$install->fixFile( $file );
		}
	}
}


/**
 * Output function called by WHMCS
 * @version		3.1.09 ( $Id: integrator.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * @param		array		- Contains the variables set in the configuration function
 * 
 * @since		3.0.0
 */
function integrator_output($vars)
{
	if (! function_exists( 'dunmodule' ) ) return;
	echo dunmodule( 'integrator' )->renderAdminOutput();
}


/**
 * Function to generate sidebar menu called by WHMCS
 * @version		3.1.09 ( $Id: integrator.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * @param		array		- Contains the variables set in the configuration function
 * 
 * @since		3.0.0
 */
function integrator_sidebar($vars)
{
	
}


/**
 * Function to generate the front end output for the module
 * @version		3.1.09 ( $Id: integrator.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * @param		array		- Contains the variables set in the configuration function
 *
 * @return		array
 * @since		3.1.00
 */
function integrator_clientarea( $vars )
{
	if (! function_exists( 'dunmodule' ) ) return;
	return dunmodule( 'integrator' )->renderClientOutput();
}

/**
 * Function to return a generic error message in the Addon Modules area in the event of a problem with Dunamis or the module
 * @version		3.1.09 ( $Id: integrator.php 372 2015-07-02 16:14:12Z steven_gohigher $ )
 * @param		string		- $error: the nature of the error
 *
 * @return		array
 * @since		2.5.0
 */
function defaulti3_adminConfig( $error = 'dunamis' )
{
	switch ( $error ) :
	case 'dunamis' :
		$message = 'The Dunamis Framework was not detected!  Be sure it is installed fully before attempting to activate this module!';
	break;
	case 'module' :
		$message = 'Dunamis was unable to locate the module `integrator`.  Please check to ensure you don\'t have any folders in your root directory called `integrator` or any other modules elsewhere in WHMCS that are named `integrator`.';
		break;
		endswitch;

		return array(
				'name'			=>	'Integrator 3',
				'description'	=>	$message,
				'version'		=>	"3.1.09"
		);
}
?>