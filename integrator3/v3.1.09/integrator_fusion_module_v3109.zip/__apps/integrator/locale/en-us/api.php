<?php

$__LANG = array (
	'getpages_home'					=> 'Home',
	'getpages_ticketsubmit'			=> 'Submit Ticket',
	'getpages_knowledgebase'		=> 'Knowledgebase',
	'getpages_news'					=> 'News',
	'getpages_troubleshooter'		=> 'Troubleshooter',
);
?>