<?php
/**
 * Integrator 3 - System Plugin
 * 		Updateuser File
 *
 * @package    Integrator 3
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.1.09 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      3.1.00
 *
 * @desc       This is the userfind Task which will find a given task in Joomla for I3
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * User Find API Class
 * @version		3.1.09
 *
 * @since		3.1.00
 * @author		Steven
 */
class UsersearchIntegratorAPI extends IntegratorAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		3.1.09
	 * 
	 * @since		3.1.00
	 * @see			IntegratorAPI :: execute()
	 */
	public function execute()
	{
		$input		=	dunloader( 'input',		true );
		$db			=	dunloader( 'database',	true );
		$search		=	$input->getVar( 'search', null );
		
		if (! isset( $search ) ) {
			return $this->error( JText::_( 'COM_INTEGRATOR_API_USERSEARCH_ERRORNOSEND' ) );
		}
		
		$search		=	"%{$search}%";
		$query		=	"SELECT `id`, `username`, `email`, `name`, `block` FROM #__users WHERE `email` LIKE " . $db->Quote( $search ) . " OR `username` LIKE " . $db->Quote( $search ) . " OR `name` LIKE " . $db->Quote( $search );
		$db->setQuery( $query );
		return $this->success( $db->loadAssocList() );
	}
}