<?php
/**
 * Integrator
 * 
 * @package    Integrator 3.0 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    3.0.4 ( $Id: api.php 74 2012-10-01 15:55:25Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This file is the API controller for handling interaction between the Integrator and Joomla 1.6
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.helper' );
/*-- File Inclusions --*/

/**
 * API Controller Class Object
 * @version		3.0.4
 * 
 * @since		3.0.0
 * @author		Steven
 */
class IntegratorControllerApi extends JController
{
	/**
	 * Contains an array of return variables to send back to calling site
	 * @access		public
	 * @var			array
	 * @since		3.0.0
	 */
	public $_returnmsg = array();
	
	/**
	 * Constructor
	 * @access		public
	 * @version		3.0.4
	 * 
	 * @since		3.0.0
	 */
	public function __construct()
	{
		// Be sure to check for this in plugins
		if (! defined( "INTEGRATOR_API" ) ) define ( "INTEGRATOR_API", true );
		
		// Add ACL for Joomla 1.5
		if ( version_compare( JVERSION, '1.6.0', 'l' ) ) {
			$acl = & JFactory::getACL();
			$acl->addACL( 'com_integrator', 'site', 'users', 'manager' );
			$acl->addACL( 'com_integrator', 'site', 'users', 'administrator' );
			$acl->addACL( 'com_integrator', 'site', 'users', 'super administrator' );
		}
		
		// Let's login first
		if ( IntegratorHelper :: get( 'task', null ) != "ping" ) {
			$this->_login();
		}
		
		parent::__construct();
		
		$this->registerTask( 'apilogin',	'ping' );
		$this->registerTask( 'clientadd',	'clienthandler' );
		$this->registerTask( 'clientedit',	'clienthandler' );
		$this->registerTask( 'contactedit',	'clienthandler' );
	}
	
	
	/**
	 * Authenticate a user given credentials
	 * @access		public
	 * @version		3.0.4
	 * 
	 * @since		3.0.0
	 */
	public function authenticate()
	{
		$options		= array(	'remember'	=> false,
									'return'	=> null,
									'silent'	=> true
		);
		
		$data	=   IntegratorHelper :: get ( 'data', array(), 'post' );
		
		jimport( 'joomla.user.authentication');
		$authenticate = & JAuthentication::getInstance();
		$response	  = $authenticate->authenticate( $data, $options );
		
		if ($response->status === JAUTHENTICATE_STATUS_SUCCESS) {
			$this->_setMessage( 'AUTH_SUCCESS' );
		}
		else {
			$this->_setError( 'AUTH_ERRORINVALID' );
		}
		
		$this->_close();
	}
	
	
	/**
	 * Retrieves the current versions of various I3 applications on this connection
	 * @access		public
	 * @version		3.0.4
	 * 
	 * @since		3.0.1 (0.1)
	 */
	public function get_info()
	{
		$model = & $this->getModel( 'api' );
		
		if (! ( $data = $model->get_info() ) ) {
			$this->_setError( 'INFOEMPTY' );
			$this->_close();
			return;
		}
		$this->_setMessage( $data, false );
		$this->_close();
	}
	
	
	/**
	 * Retrieves the languages used in Joomla
	 * @access		public
	 * @version		3.0.4
	 * 
	 * @since		3.0.0
	 */
	public function get_languages()
	{
		$model	= & $this->getModel( 'api' );
		
		// Grab the languages and return error if empty
		if (! ( $langs = $model->get_languages() ) ) {
			$this->_setError( 'LANGSEMPTY' );
			$this->_close();
			return;
		}
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$results	= array();
			foreach ( $langs as $row ) {
				$results[$row['value']] = $row['name'];
			}
		}
		else {
			$results = $langs;
		}
		
		$this->_setMessage( $results, false );
		$this->_close();
	}
	
	
	/**
	 * Retrieves the menu tree from Joomla for selection
	 * @access		public
	 * @version		3.0.4
	 * 
	 * @since		3.0.0
	 */
	public function get_menutree()
	{
		$model	= & $this->getModel( 'api' );
		$menus	=   $model->get_menutree();
		
		if( empty( $menus ) ) {
			$this->_setError( 'MENUSEMPTY' );
			$this->_close();
			return;
		}
		
		$this->_setMessage( $menus, false );
		$this->_close();
	}
	
	
	/**
	 * Retrieves missing credential (passed through retrieve variable)
	 * @access		public
	 * @version		3.0.4
	 * 
	 * @since		3.0.0
	 */
	public function get_missing_credential()
	{
		$model	= & $this->getModel( 'api' );
		$sent	= & JRequest::getVar( 'data', array(), 'post' );
		
		switch( $sent['retrieve'] ):
		case 'username':
			
			if ( empty( $sent['email'] ) ) {
				$this->_setError( 'GETUSERNAME_ERRORNOTSENT' );
				$this->_close();
			}
			
			if (! ( $data = $model->get_username( $sent['email'] ) ) ) {
				$this->_setError( 'GETUSERNAME_ERRORNOTFOUND' );
				$this->_close();
			}
			break;
		case 'email':
			
			if ( empty( $sent['username'] ) ) {
				$this->_setError( 'GETEMAIL_ERRORNOTSENT' );
				$this->_close();
			}
			
			if (! ( $data = $model->get_email( $sent['username'] ) ) ) {
				$this->_setError( 'GETEMAIL_ERRORNOTFOUND' );
				$this->_close();
			}
			break;
		endswitch;
		
		$this->_setMessage( $data, false );
		$this->_close();
	}
	
	
	/**
	 * Simple function to check status of connection
	 * @access public
	 * 
	 * @since  3.0.0
	 */
	public function ping()
	{
		$this->_setMessage( "Pong", false );
		$this->_close();
	}
	
	
	/**
	 * Updates a corresponding set of settings in Joomla
	 * @access		public
	 * @version		3.0.4
	 * 
	 * @since		3.0.0 (0.2)
	 */
	public function update_settings()
	{
		$model	= & $this->getModel( 'api' );
		
		if ( ( $msg = $model->update_settings() ) === true ) {
			$this->_setMessage( 'UPDATE_SETTINGS_SUCCESS' );
		}
		else {
			$this->_setError( $msg );
		}
		
		$this->_close();
	}
	
	
	/**
	 * Creates a new user
	 * @access		public
	 * @version		3.0.4
	 * 
	 * @since		3.0.0
	 */
	public function user_create()
	{
		$model	= & $this->getModel( 'api' );
		
		if ( ( $msg = $model->user_create() ) === true ) {
			$this->_setMessage( 'USERCREATE_SUCCESS' );
		}
		else {
			$this->_setError( $msg );
		}
		
		$this->_close();
	}
	
	
	/**
	 * Finds user information
	 * @access		public
	 * @version		3.0.4
	 * 
	 * @since		3.0.0
	 */
	public function user_find()
	{
		$model	= & $this->getModel( 'api' );
		
		if ( is_string( $msg = $model->user_find() ) ) {
			$this->_setError( $msg, false );
		}
		else {
			$this->_setMessage( $msg, false );
		}
		
		$this->_close();
	}
	
	
	/**
	 * Finds user information
	 * @access		public
	 * @version		3.0.4
	 *
	 * @since		3.0.0
	 */
	public function user_search()
	{
		$model	= & $this->getModel( 'api' );
	
		if ( is_string( $msg = $model->user_search() ) ) {
			$this->_setError( $msg, false );
		}
		else {
			$this->_setMessage( $msg, false );
		}
	
		$this->_close();
	}
	
	
	/**
	 * Remove user from this site
	 * @access		public
	 * @version		3.0.4
	 * 
	 * @since		3.0.0
	 */
	public function user_remove()
	{
		$model	= & $this->getModel( 'api' );
		
		if ( ( $msg = $model->user_remove() ) === true ) {
			$this->_setMessage( 'USERREMOVE_SUCCESS' );
		} 
		else {
			$this->_setError( $msg, false );
		}
		
		$this->_close();
	}
	
	
	/**
	 * Updates a user with the posted info
	 * @access		public
	 * @version		3.0.4
	 * 
	 * @since		3.0.0
	 */
	public function user_update()
	{
		$model	= & $this->getModel( 'api' );
		
		if ( ( $msg = $model->user_update() ) === true ) {
			$this->_setMessage( 'USERUPDATE_SUCCESS' );
		}
		else {
			$trans	= ( strpos( $msg, 'USERFIND' ) !== false ? true : false );
			$this->_setError( $msg, $trans );
		}
		
		$this->_close();
	}
	
	
	/**
	 * Validates user information for a new user
	 * @access		public
	 * @version		3.0.4
	 * 
	 * @since		3.0.0
	 */
	public function user_validation_on_create()
	{
		$model	= & $this->getModel( 'api' );
		
		if ( ( $msg = $model->user_validation_on_create() ) === true ) {
			$this->_setMessage( 'USERVALIDATION_SUCCESS' );
		}
		else {
			$this->_setError( $msg, false );
		}
		
		$this->_close();
	}
	
	
	/**
	 * Validates user information before updating
	 * @access		public
	 * @version		3.0.4
	 * 
	 * @since		3.0.0
	 */
	public function user_validation_on_update()
	{
		$model	= & $this->getModel( 'api' );
		
		if ( ( $msg = $model->user_validation_on_update() ) === true ) {
			$this->_setMessage( 'USERVALIDATION_SUCCESS' );
		}
		else {
			$this->_setError( $msg, false );
		}
		
		$this->_close();
	}
	
	
	/**
	 * **********************************************************************
	 * PRIVATE METHODS BELOW
	 * **********************************************************************
	 */
	
	
	/**
	 * Permits authorization check for Joomla 1.5 or 1.6+
	 * @access		private
	 * @version		3.0.4
	 * @param		JUser Object
	 * 
	 * @return		bool
	 * @since		3.0.0
	 */
	private function _authorise( $user = null )
	{
		if ( $user == null ) return false;
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			return $user->authorise( "manage", "com_integrator" );
		}
		else {
			return $user->authorize( "com_integrator", "site" );
		}
	}
	
	
	/**
	 * Closes the application
	 * @access		private
	 * @version		3.0.4
	 * 
	 * @since		3.0.0
	 */
	private function _close()
	{
		$app	= JFactory::getApplication();		// Get the application
		$debug	= IntDebug::getInstance();
		$msg	= $this->get( "_returnmsg", null );	// Grab the message
		$msg['debug']	= $debug->get_output();
		echo json_encode( $msg );					// Send message
		$app->close();								// Close application
	}
	
	
	/**
	 * Logs the API user in
	 * @access		private
	 * @version		3.0.4
	 * 
	 * @return 		boolean true on success, closes application if failure
	 * @since 		3.0.0
	 */
	private function _login()
	{
		// Be sure to set the constant so we don't try to add the user to WHMCS!
		if (! defined( "INTLOGIN" ) ) define( "INTLOGIN", true );
		
		$app			=   JFactory::getApplication();
		$user			=   JFactory::getUser();
		$guest			=   $user->get( "guest", 1 );
		$credentials	=   IntegratorHelper :: get( 'credentials', array(), 'array' );
		
		if ( ( $guest != 1 ) AND (! $this->_authorise( $user ) ) ) {
			$app->logout( $user->get( "id" ), array( "integrator" => true ) );
			$guest = 1;
		}
		
		if ( $guest == 1 ) {
			$options		=   array( "silent" => false, "integrator" => true );
			
			$err = $app->login( $credentials, $options );
			
			if (! $app->login($credentials, $options) ) {
				// Login failed
				$this->_setError( 'LOGIN_ERRORLOGIN' );
				$this->_close();
			}
		}
		
		$user			=   JFactory::getUser();
		
		if (! $this->_authorise( $user ) ) {
			
			// Log this user out
			$app->logout( $user->get( "id" ), array( "integrator" => true ) );
			
			// User not authorised
			$this->_setError( 'LOGIN_ERRORAUTH' );
			$this->_close();
		}
		
		$params	= & JComponentHelper::getParams( "com_integrator" );
		
		// Test Secret / Salt
		$sentsig	= $credentials['signature'];
		$salt		= $credentials['salt'];
		$secret		= $params->get( 'IntegratorSecret' );
		$signature	= base64_encode( hash_hmac( 'sha256', $salt, $secret, true ) );
		
		if ( $sentsig != $signature ) {
			$this->_setError( 'SECRET_KEY' );
			$this->_close();
		}
		
		return true;
	}
	
	
	/**
	 * Sets an error message
	 * @access		private
	 * @version		3.0.4
	 * @param 		varies		- $msg: Contains the error message to throw back
	 * @param		boolean		- $trans: Should the message be translated ? true if so
	 * 
	 * @since		3.0.0
	 */
	private function _setError( $msg, $trans = true )
	{
		$this->set( "_returnmsg", array( "result" => "error", "data" => ( $trans ? $this->_trans( $msg ) : $msg ) ) );
	}
	
	
	/**
	 * Sets a successful message
	 * @access		private
	 * @version		3.0.4
	 * @param		varies		- $msg: Contains the data to send back
	 * @param		boolean		- $trans: Should the message be translated ? true if so
	 * 
	 * @since		3.0.0
	 */
	private function _setMessage( $msg, $trans = true )
	{
		$this->set( "_returnmsg", array( "result" => "success", "data" => ( $trans ? $this->_trans( $msg ) : $msg ) ) );
		return;
	}
	
	
	/**
	 * Translates a string
	 * @access		private
	 * @version		3.0.4
	 * @param		string		- $msg: the string to translate
	 * 
	 * @return		string containing translated message
	 * @since		3.0.0
	 */
	private function _trans( $msg )
	{
		return JText::_( 'COM_INTEGRATOR_API_' . strtoupper( $msg ) );
	}
}