function updatepages( selectedpagegroup, fieldname, selectedpage )
{
	var pagelist = document.getElementById('jform_' + fieldname + '_page');
	
	pagelist.options.length=0
	
	for ( i=0; i < pages[selectedpagegroup].length; i++ ) {
		var value = pages[selectedpagegroup][i].split("|")[1]
		
		if ( value == selectedpage ) {
			pagelist.options[pagelist.options.length] = new Option( pages[selectedpagegroup][i].split("|")[0], value, true )
		}
		else { 
			pagelist.options[pagelist.options.length] = new Option( pages[selectedpagegroup][i].split("|")[0], value )
		}
	}
}