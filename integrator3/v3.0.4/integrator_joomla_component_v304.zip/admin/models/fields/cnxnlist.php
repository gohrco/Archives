<?php

defined('JPATH_BASE') or die;

jimport('joomla.html.html');
jimport('joomla.form.formfield');
jimport('joomla.form.helper');

include_once( JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_integrator' . DS . 'class.api.php' );

if(! class_exists( 'IntElementBase' ) )
{
	// Create a Joomla 1.6 compatible base first
	if( version_compare( JVERSION,'1.6.0', 'ge' ) )
	{
		class IntElementBase extends JFormFieldList {
			public function getInput() {
				return parent::getInput();
			}
		}
	}
	// If not 1.6 then create a Joomla 1.5 base first
	else {
		class IntElementBase extends JElement {}
	}
}


class IntElement extends IntElementBase
{
	/**
	 * Provides mechanism to exclude an empty connection (upon failure)
	 * @access		public
	 * @since		3.0.2
	 * @var			array
	 */
	var $_excludes	= array();
	
	/**
	 * Used for storing a created ID when on J! 1.5
	 * @access		public
	 * @since		3.0.2
	 * @var			string
	 */
	var $_id		= null;
	
	var $_name		= 'CnxnList';
	
	public function fetchElement( $name, $value, &$node, $control_name )
	{
		if ( version_compare( JVERSION, '1.6.0', 'l' ) ) {
			$this->_id = $control_name.$name;
		}
		
		$pagetxt	= $this->getCnxnpages();
		$options	= $this->getOptions();
		$selpage	= $this->_parent->get(  $this->_buildName( false ) . '_page' );
		
		$class		= ( $node->attributes('class') ? 'class="'.$node->attributes('class').'"' : 'class="inputbox"' );
		$class		.= ' onChange="updatepages(this.options[this.selectedIndex].value, \'' . $this->_buildName() . '\')"';
		
		$this->_buildJavascript( $pagetxt, $selpage, $this->_buildName() );
		return JHtml::_('select.genericlist',  $options, ''.$control_name.'['.$name.']', $class, 'value', 'text', $value, $control_name.$name);
	}
	
	
	public function getInput()
	{
		$selpage	= $this->form->getValue( $this->_buildName( false ) . '_page', ( strpos( $this->_buildName(), 'params' ) !== false ? 'params' : null ), 0 );
		$pagetxt	= $this->getCnxnpages();
		
		$this->_buildJavascript( $pagetxt, $selpage, $this->_buildName() );
		
		return parent::getInput();
	}
	
	
	protected function getOptions()
	{
		static $options	= null;
		
		if ( $options == null ) {
			$options = array();
			$api		= & IntApi :: getInstance();
			$cnxns		=   $api->get_wrapped_cnxns();
			$options[]	=   (object) array( 'value' => '', 'text' => '- Select a Connection -');
			
			if ( $cnxns === false ) return $options;
			
			foreach ( $cnxns as $cnxn )
			{
				if ( in_array( $cnxn['id'], $this->_excludes ) ) continue;
				$options[]	= (object) array( 'value' => $cnxn['id'], 'text' => $cnxn['name'] );
			}
		}
		
		return $options;
	}
	
	
	protected function getCnxnpages()
	{
		static $pages	= null;
		
		if ( $pages == null ) {
			$api	= & IntApi :: getInstance();
			$items	=   $api->get_allcnxn_pages();
			
			if ( $items === false ) return null;
			
			foreach ( $items as $item ) {
				
				if ( empty( $item['pages'] ) ) {
					$this->_excludes[]	= $item['cnxn_id'];
					continue;
				}
				
				$txt	= array();
				asort( $item['pages'] );
				foreach( $item['pages'] as $val => $page ) {
					$txt[]	= $page . '|' . $val;
				}
				$pages .= 'pages[' . $item['cnxn_id'] . '] = ["' . implode( '", "', $txt ) . '"]
';
			}
		}
		return $pages;
	}
	
	
	private function _buildName( $full = true )
	{
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$id	= $this->id;
			$pstrip	= 'params_';
		}
		else {
			$id		= $this->_id;
			$pstrip	= 'params';
		}
		
		$data	= str_replace( '_cnxn_id', '', str_replace( 'jform_', '', $id ) );
		
		if ( $full ) {
			return $data;
		} else {
			return str_replace( $pstrip, '', $data );
		}
	}
	
	
	private function _buildJavascript( $pagetxt, $selpage = null, $fieldname = 'register' )
	{
		static $onetime		= true;
		static $includes	= array();
		
		$javascript	=   null;
		$document	= & JFactory :: getDocument();
		$v			=   ( version_compare( JVERSION, '1.6.0', 'ge' ) ? '25' : '15' );
		
		if ( $onetime ) {
			$onetime	=   false;
			$javascript	=   <<< JSCRIPT
var pages = new Array();
pages[''] = ["- Select A Page -|"]
{$pagetxt}
JSCRIPT;
			
			IntegratorHelper :: addMedia( "functions{$v}/js" );
			$document->addScriptDeclaration( $javascript );
			IntegratorHelper :: addMedia( 'cnxnlist/css' );
		}
		
		if (! isset( $includes[$fieldname] ) ) {
			$includes[$fieldname] = true;
			
			if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
				$document->addScriptDeclaration( "window.addEvent('domready', function() { var tmp = document.getElementById( 'jform_{$fieldname}_cnxn_id' ); updatepages( tmp.options[tmp.selectedIndex].value, '{$fieldname}', '{$selpage}' ); }) " );
			}
			else {
				$document->addScriptDeclaration( "window.addEvent('domready', function() { var tmp = document.getElementById( '{$fieldname}_cnxn_id' ); updatepages( tmp.options[tmp.selectedIndex].value, '{$fieldname}', '{$selpage}' ); }) " );
			}
		}
	}
}

if ( version_compare( JVERSION,'1.6.0','ge' ) ) {
	class JFormFieldCnxnList extends IntElement {}
}
else {
	class JElementCnxnList extends IntElement {}                
}