<?php 

$tabs = array();

foreach ( $fields as $key => $formset ) {
	$tabs[$key] = array( "id" => $key, "name" => lang( $key . '.tab' ) );
}

?>

<script>
jQuery(function() {
	jQuery( "#tabs" ).tabs();
});
</script>

<?php echo form_open( $action, array( 'id' => 'adminForm' ) ); ?>

<div class="ui-tabs ui-widget ui-widget-content ui-corner-all" id="tabs">
	<ul class="ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all">
	<?php foreach ( $tabs as $key => $tab ) : ?>
		<li class="ui-state-default ui-corner-top ui-tabs-selected ui-state-active">
			<a href="<?php echo "#".$key ?>">
				<?php echo $tab['name']; ?>
			</a>
		</li>
	<?php endforeach; ?>
	</ul>
	
	<?php foreach( $tabs as $key => $div ) : ?>
		<div class="ui-tabs-panel ui-widget-content ui-corner-bottom" id="<?php echo $key; ?>">
		<?php $cnt	= count( $fields[$key] ); ?>
		<?php $tcnt	= 0; ?>
		<?php foreach( $fields[$key] as $item ) : ?>
			<?php $tcnt++; ?>
			<div<?php if( $tcnt != $cnt ) : ?> class="append-bottom border-bottom"<?php endif; ?>>
				<div class="span-14">
					<div class="span-4"><?php echo $item->label; ?></div>
					<div class="span-10 last"><?php echo $item->field; ?></div>
				</div>
				<div class="push-1 span-17 small last"><?php echo $item->desc; ?></div>
				<div class="clear"> </div>
			</div>
		<?php endforeach; ?>
	</div>
	<?php endforeach; ?>
	
<?php foreach( $hidden as $hide ) : ?>
<?php echo $hide->field; ?>
<?php endforeach; ?>

<div class="push-4 append-bottom clear">
	<?php echo form_button( array( 'name' => 'submit', 'id' => 'submitForm', 'value' => true, 'type' => 'submit', 'content' => lang( 'btn.updatesettings' ) ) );?>
	<?php echo form_button( array( 'name' => 'saveclose', 'id' => 'submitForm', 'value' => true, 'type' => 'submit', 'content' => lang( 'btn.saveandclose' ) ) );?>
</div>

</div>



<?php echo form_close(); ?>