<div class="row-fluid">
	<div class="span1"> </div>
	<div class="span11">
		<?php 
		$header	= ( isset( $header ) ? $header : $action );
		
		echo heading( lang( str_replace( '/', '.', $header ) ), '3', 'class="header"' );
		
		if ( lang( str_replace( '/', '.', $header ) . '.desc' ) ) : ?>
			<div class="header-text"><?php echo lang( str_replace( '/', '.', $header ) . '.desc' ); ?></div>
		<?php endif; ?>
	</div>
</div>

<?php echo form_open( $action, array( 'id' => 'adminForm', 'class' => 'form-horizontal' ) ); ?>

<div class="row-fluid">
	
	<div class="span2"> </div>
	
	<fieldset>
	
	<?php foreach ( $fields as $item ) : ?>
		
		<div class="control-group">
			
			<?php echo $item->label; ?>
			
			<div class="controls">
				<?php echo $item->field; ?>
				
				<?php if (! empty( $item->desc ) ) : ?>
					
					<p class="help-block"><?php echo $item->desc; ?></p>
					
				<?php endif; ?>
			</div>
			
		</div>
		
	<?php endforeach; ?>
	
	</fieldset>
	
	<?php foreach( $hidden as $hide ) : ?>
		<?php echo $hide->field; ?>
	<?php endforeach; ?>

</div>

<div class="row-fluid">
	<div class="form-actions">
		<?php 
		foreach ( $buttons as $button )
		{
			$type = $button->btntype; 
			unset( $button->btntype );
			
			if ( $type == 'anchor' )
			{
				$uri	= $button->uri;
				$title	= $button->title;
				unset ( $button->uri, $button->title );
				echo anchor( $uri, $title, (array) $button );
			}
			else
			{
				echo form_button( (array) $button );
			}
		}	
		?>
	</div>
</div>

<?php echo form_close(); ?>