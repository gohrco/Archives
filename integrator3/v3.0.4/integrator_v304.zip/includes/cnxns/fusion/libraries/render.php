<?php

/**
 * Render class for Kayako Fusion application
 * @access		public
 * @author		Steven
 *
 * @since		3.0.0
 */
class Fusion_Render extends Render_library
{
	
	/**
	 * Constructor method called by parent Render_library
	 * @access		public
	 * @version		3.0.4
	 * @param		array		- $options: an array of options to set to the object at init
	 * 
	 * @since		3.0.0
	 */
	public function __construct( $options = array() )
	{
		$this->set_properties( $options );
		
		$params		= & Params::getInstance();
		
		$this->set( "params", 	cnxn( $this->get( "cnxn_id" ) )->get_param_array() );
		$this->set( "unicode",	( $params->get( "UnicodeMatching", false ) ? "u" : "" ) );
	}
	
	
	/**
	 * Gathers any regular expressions to run against the site for this application
	 * @access		public
	 * @version		3.0.4
	 * @param		array		- $regex: contains any already gathered regular expressions from site
	 * 
	 * @return		array containing more regular expression objects
	 * @since		3.0.0
	 */
	public function regex_gather( $regex )
	{
		// Grab the unicode tag if we are using it
		$u			= $this->get( "unicode" );
		
		$regex[]	= new IntRegex( '/(?P<front><title>[^<\/]+?<\/title>)(?P<link>)(?P<back>)/' . $u, "scripttitle", null, true );
		return $regex;
	}
	
	
	/**
	 * Updates the regular expression object array with data from this connection
	 * @access		public
	 * @version		3.0.4
	 * @param		array		- $regex: array of regular expression IntRegex objects
	 * 
	 * @return		array containing updated regex objects array
	 * @since		3.0.0
	 */
	public function regex_update( $regex )
	{
		foreach ( $regex as $regobj ) {
			switch( $regobj->get( "type" ) ):
			case "scripttitle":
				$url	= Uri::getInstance( $this->get( 'url', null, 'globals' ), true );
				$url->setScheme( "http" . ( $this->isssl ? "s" : "" ) );
				$url->setPath( rtrim( $url->getPath(), "/" ) );
				$regobj->set( "replace", '<script type="text/javascript" src="' . $url->toString() . '/includes/jscript/jquery.js"></script><script type="text/javascript" src="' . $url->toString() . '/modules/addons/integrator/jscript/noconflict.js"></script>' );
				break;
			endswitch;
		}
		return $regex;
	}
	
	
	/**
	 * Permits for splitting content further down beyond header and footer for this application
	 * @access		public
	 * @version		3.0.4
	 * @param		array		- $content: associative array with header and footer from site
	 * 
	 * @return		array containing final split components to return to application
	 * @since		3.0.0
	 */
	public function split_site( $content )
	{
		return $content;
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE OVERRIDES OF PARENT
	 * **********************************************************************
	 */
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		3.0.4
	 * @param		string		- $name: the name of the property to set
	 * @param		mixed		- $value: the value to set the property to
	 * 
	 * @since		3.0.0
	 * @see			Render_library::__set();
	 */
	public function __set( $name, $value )
	{
		if ( in_array($name, array( '_a', 'cnxn_id' ) ) ) {
			$this->cnxn_id = $value;
			return;
		}
		parent::__set( $name, $value );
	}
}