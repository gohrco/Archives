<?php


class Fusion_API extends API_Library
{
	protected		$apioptions	= array();
	protected		$apipost	= array();
	protected		$apiput		= array();
	protected		$apiuri		= null;
	protected		$apiurl		= null;
	
	protected		$clientarea	= array();
	
	public function __construct( $options = array() )
	{
		$CI	= & get_instance();
		$CI->load->helper( 'simplexml' );
		parent::__construct( $options );
		
	}
	
	
	public function load( $options )
	{
		parent::load( $options );
		
		// =====================================
		// ---BEGIN: Set default api options
		$apioptions	= $this->get( 'apioptions' );
			$apioptions['HEADER'] =  true;
			$apioptions['RETURNTRANSFER'] = true;
		$this->set( 'apioptions', $apioptions );
		// ---END:   Set default api options
		// =====================================
		// ---BEGIN: Determine SSL settings properly
		$usessl	=    secure_task( 'api', (bool) $this->get( "sslenabled", false, 'params' ) );
		if ( $usessl ) {
			$apioptions	= $this->get( 'apioptions' );
			//$apioptions['SSL_VERIFYHOST'] = true;
			$apioptions['SSL_VERIFYPEER'] = false;
			$apioptions['CAINFO']			= BASEPATH . APPPATH . 'assets' . DIRECTORY_SEPARATOR . 'cacert.pem';
			$this->set( 'apioptions', $apioptions );
		}
		// ---END: Determine SSL settings properly
		// =====================================
		// ---BEGIN: Setting GLOBAL API curl options
// 		$apioptions	= $this->get( 'apioptions' );
// 			if ( $this->get( 'sslverify', 0, 'api' ) == 1 ) {
// 				$apioptions['SSL_VERIFYHOST'] = true;
// 				$apioptions['SSL_VERIFYPEER'] = true;
// 			}
// 		$this->set( 'apioptions', $apioptions );
		// ---END:   Setting GLOBAL API curl options
		// =====================================
		// ---BEGIN: Setting API url
		$url 	=   $this->get( "apiurl", $this->get( 'baseurl', null, 'params' ), 'api' );
		$uri	= & Uri::getInstance( $url );
		//$usessl	=    secure_task( 'api', (bool) $this->get( "sslenabled", false, 'params' ) );
		$uri->setScheme( "http" . ( $usessl ? "s" : "" ) );
		$uri->setPath( rtrim( $uri->getPath(), "/" ) . "/api/index.php" );
		$this->set( "apiuri", $uri );
		//echo '<pre>'.print_r($uri,1); die();
		// ---END:   Setting API url
		// =====================================
		// ---BEGIN: Setting API curl options
		$apioptions	= $this->get( 'apioptions' );
			// Do something if needed
		$this->set( 'apioptions', $apioptions );
		// ---END:   Setting API curl options
		// =====================================
		// ---BEGIN: Setting API variables
		$apikey		=   $this->get( 'apikey', null, 'api' );
		$salt		=   mt_rand();
		$signature	=   base64_encode( hash_hmac( 'sha256', $salt, $this->get( 'apisecret', null, 'api' ), true ) );
		
		$apipost	= $this->get( "apipost" );
			$apipost['apikey']		= $apikey;
			$apipost['salt']		= $salt;
			$apipost['signature']	= $signature;
			$apipost['IntAPI']			= true;
		$this->set( "apipost", $apipost );
		//
		// =====================================
		//
		$apiput		= $this->get( 'apiput' );
			$apiput['apikey']		= urlencode( $apikey );
			$apiput['salt']			= urlencode( $salt );
			$apiput['signature']	= urlencode( $signature );
		$this->set( 'apiput', $apiput );
		// ---END:   Setting API variables
		// =====================================
		
		$ca	= array(	'ticketsdisplay' => ( isset( $options['params']['clientarea']['ticketsdisplay']['value'] ) ? $options['params']['clientarea']['ticketsdisplay']['value'] : false ),
						'ticketsnewwin'		=> ( isset( $options['params']['clientarea']['ticketsnewwin']['value'] ) ? $options['params']['clientarea']['ticketsnewwin']['value'] : false )
				);
		$this->set( 'clientarea', $ca );
		
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE API FUNCTIONS AND ARE CALLED DIRECTLY
	 * **********************************************************************
	 */

	

	/**
	 * Called to authenticate a set of user credentials
	 * @access		public
	 * @version		3.0.4
	 * @param		array		- $post: an array of variables to post (should be empty if no child library)
	 * 
	 * @return		boolean true if authenticated, false if failed
	 * @since		3.0.0
	 */
	public function authenticate( $post = array() )
	{
		$credentials	= get_var( "credentials" );
		
		$credentials['email']		= isset( $post['email'] ) ? $post['email'] : $credentials['email'];
		$credentials['password']	= isset( $post['password'] ) ? $post['password'] : $credentials['password'];
		
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		$post['credentials']	= $credentials;
		
		// Create URL
		$uri	=   $this->get( 'apiuri' );
			$uri->setVar( 'e', '/Integrator/Intuser/Authenticate' );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns, 'authenticate' );
		
		if ( $result === false ) {
			return false;
		}
		
		$result = simpleXMLToArray( $result );
		
		return ( $result['result'] == 'success' ? true : false );
	}
	
	
	/**
	 * Retrieves information about the Integrator 3 cnxn
	 * @access		public
	 * @version		3.0.4
	 *
	 * @return		array or false on error
	 * @since		3.0.1 (0.1)
	 */
	public function get_info()
	{
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		
		$uri	=   $this->get( 'apiuri' );
		$uri->setVar( 'e', '/Integrator/Intcore/GetInfo' );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns, 'get_info' );
		
		if ( $result === false ) return false;
		
		$result = simpleXMLToArray( $result );
		$data	= array( 'cnxns|fusion' => $result['version'] );
		return $data;
	}
	
	
	/**
	 * Retrieves the languages on this connection
	 * @access		public
	 * @version		3.0.4
	 * 
	 * @return		array containing either the languages or empty array
	 * @since		3.0.0
	 */
	public function get_languages()
	{
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		
		$uri	=   $this->get( 'apiuri' );
			$uri->setVar( 'e', '/Integrator/Intcore/GetLanguages' );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns, 'get_languages' );
		
		if ( $result === false ) return false;
		
		$data	= array();
		foreach ( $result->language as $language ) {
			$data["{$language->value}"] = "{$language->name}";
		}
		
		return $data;
	}
	
	
	/**
	 * Retrieves missing credentials from the connection
	 * @access		public
	 * @version		3.0.4
	 * @param		string		- $credential: the item being sought
	 * 
	 * @return		string containing the found item or false on error or nothing found
	 * @since		3.0.0
	 */
	public function get_missing_credential( $credential = 'password' )
	{
		$missing_item = false;
		switch( $credential ):
		case 'password':
		default:
			// We can't get a password from Fusion
			$missing_item = false;
			break;
		endswitch;
		return $missing_item;
	}
	
	
	/**
	 * Retrieves the pages in this connection
	 * @access		public
	 * @version		3.0.4
	 * 
	 * @return		array containing the pages on this connection
	 * @since		3.0.0
	 */
	public function get_pages()
	{
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		
		$uri	=   $this->get( 'apiuri' );
			$uri->setVar( 'e', '/Integrator/Intcore/GetPages' );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns, 'get_pages' );
		
		if ( $result === false ) return false;
		
		$data	= array();
		foreach ( $result->page as $page ) {
			$data["{$page->value}"] = "{$page->name}";
		}
		
		return $data;
	}
	
	
	/**
	 * Gathers the information for the client area page
	 * @access		public
	 * @version		3.0.4
	 *
	 * @return		array
	 * @since		3.0.2
	 */
	public function get_secondary_info()
	{
		$cnxn	=   get_cnxn_library( $this->id );
		$data	=   array();
		$post	=   $this->get( 'apipost' );
		$uri	=   $this->get( 'apiuri' );
		$settings	=   $this->get( 'clientarea' );
		
		if (! $settings['ticketsdisplay'] ) return array();
		
		// Lets gather departments first
		$uri->setVar( 'e', '/Base/Department/GetList' );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns, 'get_secondary_info: Get Departments' );
		
		if ( $result === false ) return false;
		
		$result = simpleXMLToArray( $result );
		$depts	= array();
		
		foreach ( $result['department'] as $department ) {
			if ( $department['module'] != 'tickets' ) continue;
			$depts[$department['id']] = $department['title'];
		}
		
		// Lets find the TicketTypes
		$uri->setVar( 'e', '/Tickets/TicketType/GetList' );
		$result	= $this->_call_api( $uri->toString(), $post, $optns, 'get_secondary_info: Get Ticket Types' );
		if ( $result === false ) return false;
		else $result = simpleXMLToArray( $result );
		$tickettypes = array();
		foreach( $result['tickettype'] as $tt ) $tickettypes[$tt['id']] = $tt['title'];
		
		// Next lets find the Priorities
		$uri->setVar( 'e', '/Tickets/TicketPriority/GetList' );
		$result	= $this->_call_api( $uri->toString(), $post, $optns, 'get_secondary_info: Get Ticket Priorities' );
		if ( $result === false ) return false;
		else $result = simpleXMLToArray( $result );
		$priorities = array();
		foreach( $result['ticketpriority'] as $tt ) $priorities[$tt['id']] = $tt['title'];
		
		// Next lets find the Statuses :-|
		$uri->setVar( 'e', '/Tickets/TicketStatus/GetList' );
		$result	= $this->_call_api( $uri->toString(), $post, $optns, 'get_secondary_info: Get Ticket Statuses' );
		if ( $result === false ) return false;
		else $result = simpleXMLToArray( $result );
		$status = array();
		foreach( $result['ticketstatus'] as $tt ) $status[$tt['id']] = array( 'title' => $tt['title'], 'resolved' => $tt['markasresolved'], 'count' => $tt['displaycount'] );
		
		// Now lets find the tickets for the user
		$user			= $this->get_data();
		$post['query']	= $user['email'];
		$post['user']	= '1';
		
		$uri->setVar( 'e', '/Tickets/TicketSearch' );
		
		$tickets	= $this->_call_api( $uri->toString(), $post, $optns, 'get_secondary_info: Ticket Search' );
		
		if ( $tickets === false ) return false;
		else $tickets = simpleXMLToArray( $tickets );
		
		$siteurl	=   Uri :: getInstance( $this->get( 'baseurl', null, 'params' ), true );
		$sitepath	=   $siteurl->getPath();
		
		$tickets	=   ( empty( $tickets['ticket'] ) ? array() : ( isset( $tickets['ticket'][0] ) ? $tickets['ticket'] : $tickets ) );
		$cnt		=   0; // Ticket count for header
		$class		=   array( 'class' => 'btn btn-info btn-mini', 'target' => null, 'style' => 'min-width: 70px; ' );
		$items		=   array();
		
		if ( $settings['ticketsnewwin'] ) $class['target'] = 'blank';
		
		foreach ( $tickets as $tkt ) {
			$siteurl->setPath( rtrim( $sitepath, '/' ) . '/index.php?/Tickets/Ticket/View/' . $tkt['id'] );
			if ( $status[$tkt['statusid']]['resolved'] ) continue;
			if ( $status[$tkt['statusid']]['count'] ) $cnt++;
			
			$items[]	= array(
					$tkt['displayid'],
					$tkt['subject'],
					date( "j F Y h:i a", $tkt['lastactivity'] ),
					$tkt['lastreplier'],
					$depts[$tkt['departmentid']],
					$tickettypes[$tkt['typeid']],
					$status[$tkt['statusid']]['title'],
					$priorities[$tkt['priorityid']],
					anchor( $siteurl->toString(), lang( 'fusion_api.tickets.column.viewtkt' ), $class ) );
		}
		
		$siteurl->setPath( rtrim( $sitepath, '/' ) . '/index.php?/Tickets/ViewList/Index' );
		
		$data[]		=   array(
				'header'		=> lang( 'fusion_api.tickets.header') . ' <span class="badge badge-' . ( $cnt != 0 ? 'important' : 'info' ) . '">'.$cnt.'</span>',
				'headerlink'	=> anchor( $siteurl->toString(), lang( 'fusion_api.tickets.headerlink' ), array( 'class' => 'btn btn-inverse' ) ),
				'columns'		=> array(
						lang( 'fusion_api.tickets.column.ticketid' ),
						lang( 'fusion_api.tickets.column.subject' ),
						lang( 'fusion_api.tickets.column.lastupd' ),
						lang( 'fusion_api.tickets.column.lastrply' ),
						lang( 'fusion_api.tickets.column.dept' ),
						lang( 'fusion_api.tickets.column.type' ),
						lang( 'fusion_api.tickets.column.status' ),
						lang( 'fusion_api.tickets.column.priority' ),
						''
				),
				'data'			=> $items
		
		);
		
		return $data;
		_e( $tickets, 1 );
	}
	
	
	/**
	 * Called to test a connection to ensure it responds
	 * @access		public
	 * @version		3.0.4
	 * @param		mixed		- $check: if a string, assume its an URL, if array test credentials
	 * 
	 * @return		mixed depending on need boolean true if responsive
	 * @since		3.0.0
	 */
	public function ping( $check = null )
	{
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		
		if ( is_string( $check ) ) {
			$purl	= $check;
			$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => false );
			
			return $this->_call_api( $purl, $post, $optns, 'ping' );
		}
		else {
			$uri	=   $this->get( 'apiuri' );
				$uri->setVar( 'e', '/Core/TestAPI' );
			$purl	= $uri->toString();
			$optns	= array( 'HEADER' => true, 'RETURNTRANSFER' => true );
			
			$result	= $this->_call_api( $purl, $post, $optns, 'ping: Core TestAPI' );
			$error	= $this->_check_for_errors( false );
			
			// Account for Fusion < 4.50
			if ( $error == 404 ) {
				$uri->setVar( 'e', '/Core/Test' );
				$purl	= $uri->toString();
				$optns	= array( 'HEADER' => true, 'RETURNTRANSFER' => true );
				$result	= $this->_call_api( $purl, $post, $optns, 'ping: Core Test' );
				$error	= $this->_check_for_errors();
			}
			return ( $error === false ? true : $error );
		}
		
		
	}
	
	
	/**
	 * Creates a new user in WHMCS
	 * @access		public
	 * @version		3.0.4
	 * @param		array		- $post: variables to post to the API
	 * 
	 * @return		true on success, false otherwise
	 * @since		3.0.0
	 */
	public function user_create()
	{
		$data	= $this->get_data();
		unset( $data['userid'] );
		
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		$post['update']	= $data;
		
		// Create URL
		$uri	=   $this->get( 'apiuri' );
			$uri->setVar( 'e', '/Integrator/Intuser/Create' );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns, 'user_create' );
		
		if ( $result !== false ) {
			$result = simpleXMLToArray( $result );
		}
		
		return ( $result['result'] == 'success' ? true : $result['message'] );
	}
	
	
	/**
	 * Finds a user by email
	 * @access		public
	 * @version		3.0.4
	 * @param		boolean		- $data: if we want the data back set true, else return boolean
	 * 
	 * @return		varies can be boolean or the data result
	 * @since		3.0.0
	 */
	public function user_find( $data = false )
	{
		// This is what we are looking for
		$find		= $this->get_data();
		
		// Check first to see if we even have an email address to use
		if ( empty( $find['email'] ) ) {
			$this->set_error( 'Email not set or username unsupported' );
			return 'No email set';
		}
		
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		
		// Grab all users to find ID with email address
		$uri	=   $this->get( 'apiuri' );
			$uri->setVar( 'e', '/Integrator/Intuser/Find' );
			$uri->setVar( 'email', $find['email'] );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns, 'user_find' );
		
		if ( $result !== false ) {
			$result = simpleXMLToArray( $result );
			$this->place_data( $result );
		}
		else {
			$this->set_error( 'No User Found' );
		}
		
		return ( $result !== false ? ( $data ? $result : true ) : 'Unknown error' );
	}
	
	
	/**
	 * Searches for a user based on entry
	 * @access		public
	 * @version		3.0.4
	 * @param		array		- $find: contains search=>value
	 *
	 * @return		array
	 * @since		3.0.1 (0.2)
	 */
	public function user_search( $find = array() )
	{
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		$post['query']	= $find['search'];
		
		// Grab all users to find ID with email address
		$uri	=   $this->get( 'apiuri' );
		$uri->setVar( 'e', '/Base/UserSearch' );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns, 'user_search' );
		
		if ( $result === false ) return array();
		
		$result = simpleXMLToArray( $result );
		
		// Correct for /Base/UserSearch - if user|id is set then only one user so correct array
		if ( isset( $result['user']['id'] ) ) $result['user'] = array( $result['user'] );
		
		if ( isset( $result['user'] ) ) return $result['user'];
		else return array();
	}
	
	
	/**
	 * Updates user information on this connection
	 * @access		public
	 * @version		3.0.4
	 * @param		array		- $post: an array of variables to update
	 * 
	 * @return		boolean true if successful, error message otherwise
	 * @since		3.0.0
	 */
	public function user_update()
	{
		// For post calls, we put the api vars in here
		$post			= $this->get( 'apipost' );
		$post['user']	= $this->get_data();
		
		// Create URL
		$uri	=   $this->get( 'apiuri' );
			$uri->setVar( 'e', '/Integrator/Intuser/Update' );
			$uri->setVar( 'email', $post['user']['email'] );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns, 'user_update' );
		
		if ( $result !== false ) {
			$result = simpleXMLToArray( $result );
		}
		
		return ( $result['result'] == 'success' ? true : 'some error' );
	}
	
	
	/**
	 * User removal call to this connection
	 * @access		public
	 * @version		3.0.4
	 * @param		string		- $email: contains just an email address
	 * 
	 * @return		boolean true if successful, false otherwise
	 * @since		3.0.0
	 */
	public function user_remove()
	{
		$data = $this->get_data();
		
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		
		// Create URL
		$uri	=   $this->get( 'apiuri' );
			$uri->setVar( 'e', '/Integrator/Intuser/Delete' );
			$uri->setVar( 'email', $data['email'] );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns, 'user_remove' );
		
		if ( $result !== false ) {
			$result = simpleXMLToArray( $result );
		}
		
		return ( $result['result'] == 'success' ? true : 'some error' );
	}
	

	/**
	 * Validates a set of new user credentials
	 * @access		public
	 * @version		3.0.4
	 * @param		array		- $data: standard formed user data from Integrator
	 * 
	 * @return		boolean true if valid, false otherwise
	 * @since		3.0.0
	 */
	public function user_validation_on_create()
	{
		$data	= $this->get_data();
		
		if (! empty( $data['fullname'] ) && ! empty( $data['email'] ) ) {
			// For post calls, we put the api vars in here
			$post	= $this->get( 'apipost' );
			$post['update']	= $data;
			
			// Create URL
			$uri	=   $this->get( 'apiuri' );
				$uri->setVar( 'e', '/Integrator/Intuser/ValidateOnCreate' );
			$purl	= $uri->toString();
			$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
			
			$result	= $this->_call_api( $purl, $post, $optns, 'user_validation_on_create' );
			
			if ( $result === false ) {
				return 'Unknown Error';
			}
			
			$result = simpleXMLToArray( $result );
		
			return ( $result['result'] == 'success' ? true : $result['message'] );
		}
		
		return true;
	}
	
	
	/**
	 * Validates an updated set of user information
	 * @access		public
	 * @version		3.0.4
	 * @param		array		- $data: standard formed user data from Integrator
	 * 
	 * @return		boolean true if valid, false otherwise
	 * @since		3.0.0
	 */
	public function user_validation_on_update()
	{
		$data	= $this->get_data();
		
		// For post calls, we put the api vars in here
		$post	= $this->get( 'apipost' );
		$post['update']	= $data;
		
		// If the email is the same do nothing more
		if ( $data['email'] == $post['update']['email'] ) return true;
		
		// Create URL
		$uri	=   $this->get( 'apiuri' );
			$uri->setVar( 'e', '/Integrator/Intuser/ValidateOnUpdate' );
			$uri->setVar( 'email', $data['email'] );
		$purl	= $uri->toString();
		$optns	= array( 'HEADER' => false, 'RETURNTRANSFER' => true );
		
		$result	= $this->_call_api( $purl, $post, $optns, 'user_validation_on_update' );
		
		if ( $result === false ) {
			return 'Unknown Error';
		}
		
		$result = simpleXMLToArray( $result );
		
		return ( $result['result'] == 'success' ? true : $result['message'] );
	}
	
	
	/**
	 * Calls the API connection through curl
	 * @access		public
	 * @version		3.0.4
	 * @param		string		- $api_url: the API url
	 * @param		array		- $api_options: any additional API CURLSETOPT to set
	 * @param		string		- $action: the requested action (for logging purposes)
	 * 
	 * @return		response from API or false on error
	 * @since		3.0.0
	 * @see 		Cnxns_library::_call_api()
	 */
	protected function _call_api( $api_url = null, $api_post = array(), $api_options = array(), $action = 'unknown' )
	{
		// Empty post vars
		if ( empty( $api_post ) ) return false;
		
		// Handle URL
		if ( $api_url == null ) return false;
		
		// Handle Options
		$api_options	= array_merge( $this->get( 'apioptions' ), $api_options );
		
		$response		= parent::_call_api( $api_post, $api_url, $api_options, $action );
		
		if (! $this->_check_for_xml( $response ) ) return $response;
		
		if ( ( $response = $this->_simple_xml( $response ) ) === false ) {
// 			var_dump( $response );
// 			$CI = & get_instance();
// 			echo $CI->curl->debug(); die();
			$CI = & get_instance();
			if ( $CI->debug_on() ) {
				echo $CI->curl->debug( "API Call from Fusion Library" );
				die();
			}
			return false;
		}
		else return $response;
	}
	
	
	/**
	 * 
	 * Enter description here ...
	 */
	protected function _check_for_errors( $context = true )
	{
		$CI		= & get_instance();
		$code	=   $CI->curl->info['http_code'];
		
		switch( $code ) :
		case 200:
			return false;
		case 400:
			return $context ? 'Bad request - cannot be fulfilled due to poor syntax' : $code;
		case 401:
			return $context ? 'Unauthorized - the API Key or Secret Key are incorrect for this interface' : $code;
		case 403:
			return $context ? 'Forbidden - the server is refusing the connection' : $code;
		case 404:
			return $context ? 'Not found - the server was not found' : $code;
		case 405:
			return $context ? 'Not allowed - the resource you are requesting does not support the method requested' : $code;
		endswitch;
	}
	
	
	protected function _check_for_xml( $response )
	{
		return preg_match('/^<[^>]*>/i', $response) ? true : false;
	}
	
	
	protected function _simple_xml( $response )
	{
		// Convert response to XML object
		try {
			$xml = simplexml_load_string( $response );
		}
		catch ( Exception $e ) {
			if ( ( $this->debug ) || ( $GLOBALS['debug'] == true ) ) {
				echo "<h2>Problem Parsing XML Response from the Integrator</h2>";
				echo "=============================================<br/>\n";
				echo $url . "<br/>\n<pre>";
				echo $e->getLine();
				echo print_r( $e->getTrace(), 1);
				echo "=============================================<br/>\n";
				echo "<h3>Info</h3><pre>";
				echo print_r( $this->curl->info, 1 );
				echo "</pre>=============================================<br/>\n";
				echo "<h3>Posted Variables and Options</h3><pre>";
				echo print_r( $post, 1 );
				echo print_r( $options, 1 );
				echo "</pre>=============================================<br/>\n";
				echo "<h3>Header</h3><pre>";
				echo $header;
				echo "</pre>=============================================<br/>\n";
				echo "<h3>Response</h3><pre>";
				echo print_r( $response, 1 );
				echo "</pre>";
			}
			$xml = false;
		}
		return $xml;
	}
}