<?php

$form['users']	= array(
	'EnableUser' => array(
		'value'			=> false,
		'order'			=> 10,
		'type'			=> 'toggleyn',
		'validation'	=> 'required|is_natural'
		),
	'SessionTimeout' => array(
		'value'			=> 7200,
		'order'			=> 20,
		'type'			=> 'text',
		'validation'	=> 'required|is_numeric'
	),
	'Defaultuser' => array(
			'order'			=> 30,
			'type'			=> 'dropdown-cnxns',
			'validation'	=> ''
		),
	'UseSSL' => array(
			'apiname'		=> null,
			'value'			=> true,
			'order'			=> 50,
			'type'			=> 'hidden',
			'validation'	=> 'required|is_numeric'
		),
);

$form['display']	= array(
	'DisplayLogin' => array(
		'value'			=> true,
		'order'			=> 10,
		'type'			=> 'toggleyn',
		'validation'	=> 'required|is_natural'
	),
	'LoginMsg' => array(
		'value'			=> 'Logging In',
		'order'			=> 20,
		'type'			=> 'text',
		'validation'	=> 'xss_clean'
	),
	'LogoutMsg' => array(
		'value'			=> 'Logging Out',
		'order'			=> 30,
		'type'			=> 'text',
		'validation'	=> 'xss_clean'
	)
);