<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    Joomla! 1.6 Package
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.3.5 ( $Id: changeusername.php 170 2011-02-04 20:58:54Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      2.1.0
 * 
 * @desc       This file contains the changeusername model which allows the user and system to interact with the data
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
jimport( 'joomla.application.component.model' );	// Import model
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/**
 * Changeusername model
 * @version	2.3.0
 * 
 * @since	2.1.0
 * @author	Steven
 */
class JwhmcsModelChangeusername extends JwhmcsModel
{
	
	/**
	 * Constructor
	 * @access	public
	 * 
	 * @since	2.1.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Retrieves the data for display to the user
	 * @access	public
	 * @version 2.3.0
	 * 
	 * @return	Array containing user variables
	 * @since	2.1.0
	 */
	public function getData()
	{
		$db		= & JFactory::getDBO();
		$user	= & JFactory::getUser();
		
		// Pull user from DB
		$query	= "SELECT `xref_a` as joomlaid, `xref_type` as type, `xref_b` as whmcsid FROM #__jwhmcs_xref xref WHERE xref.xref_a = {$user->id} AND xref.xref_type BETWEEN 8 AND 9";
		$db->setQuery($query);
		$result	= $db->loadAssocList();
		
		// Make sure we got one
		if ( ( count( $result ) > 1 ) || ( count( $result ) == 0 ) )
			return false;
		
		$result	= $result[0];
		
		// Pull password from DB
		$sarray	= $this->getSess( JRequest::getVar( 'token' ) );
		$type	= $result['type'] == '8' ? 'client' : 'contact';
		$whmcs	= JwhmcsHelper::getWhmcsUser( $result['whmcsid'], 'id', $type );
		$whmcs['password'] = $sarray['password'];
		$data	= array_merge($result,$whmcs);
		
		return $data;
	}
	
	
	/**
	 * Handles the username change for the user and calls onUserLogin
	 * @access	public
	 * @version 2.3.0
	 * 
	 * @since	2.1.0
	 */
	public function submit()
	{
		if (! defined( "JWHMCS_AUTH" ) )	// Set so we don't try to add the new user to WHMCS
			define("JWHMCS_AUTH", true);
		
		$app	= & JFactory::getApplication();
		$db		= & JFactory::getDBO();
		$user	= & JFactory::getUser( JRequest::getVar( 'joomlaid' ) );
		
		// Validate token first or fail
		JRequest::checkToken() or jexit( 'Invalid Token - CHANGEUSERNAME' );
		
		$binder	= array(	'username'	=> JRequest::getVar('username') );
		
		if (! $user->bind($binder) ) {
			JError::raiseError( 500, $user->getError());
			return false;
		}
		
		if (! $user->save() ) {
			JError::raiseWarning('', JText::_( $user->getError()));
			return false;
		}
		
		// Update xref table
		$jid = JRequest::getVar( 'joomlaid' );
		$wid = JRequest::getVar( 'whmcsid' );
		
		$query	= "UPDATE #__jwhmcs_xref x SET xref_type=2 WHERE xref_a = $jid AND xref_b = $wid AND xref_type = 8";
		$db->setQuery($query);
		$db->query();
		
		$query	= "UPDATE #__jwhmcs_xref x SET xref_type=6 WHERE xref_a = $jid AND xref_b = $wid AND xref_type = 9";
		$db->setQuery($query);
		$db->query();
		
		// Build the credentials array
		$parameters['username']	= $user->get('username');
		$parameters['id']		= $user->get('id');
		
		$credentials['fullname']	= $user->get( 'name' );
		$credentials['username']	= $user->get( 'username' );
		$credentials['email']		= $user->get( 'email' );
		$credentials['password']	= JRequest::getVar( 'password' );
		$credentials['status']		= JAUTHENTICATE_STATUS_SUCCESS;
		$credentials['type']		= 'jwhmcs_auth';
		
		// Set clientid in the options array if it hasn't been set already
		$options['clientid'][] = $app->getClientId();
		
		// Now log in with correct credentials and allow Joomla to handle the rest
		$result = $app->triggerEvent( 'onUserLogin', array( $credentials, array( "silent" => true, "action" => "core.login.site" ) ) );
	}
	
	
	/**
	 * Validates a potential username for acceptance prior to submittal
	 * @access	public
	 * @version 2.3.0
	 * @param	string		$username - candidate username
	 * @param	integer		$userid - existing user (to be sure name can remain the same)
	 * 
	 * @return	Array indicating result (t/f) and message
	 * @since	2.1.0
	 */
	public function validateUsername( $username = null, $userid = 0 )
	{
		$db	= & JFactory::getDBO();
		
		// If nothing sent return false
		if ( is_null( $username ) || ( trim( $username ) == '' ) ) return array('result' => false, 'message' => JText::_( "COM_JWHMCS_CHANGEUSERNAME_MSG_ERROR00" ) );
		
		// Check to see if username is an email address
		if ( JwhmcsHelper::isEmail( $username ) ) {
			return array( 'result' => false, 'message' => JText::_( "COM_JWHMCS_CHANGEUSERNAME_MSG_ERROR01" ) );
		}
		
		// Check to see if the username is "too short"
		if ( strlen( $username ) < 3 ) return array( 'result' => false, 'message' => sprintf( JText::_( "COM_JWHMCS_CHANGEUSERNAME_MSG_ERROR02" ), $username ) );
		
		// See if there is a user by that name
		$query	= "SELECT `id` FROM `#__users` WHERE `username` = " . $db->quote( $username );
		$db->setQuery($query);
		$result = $db->loadResult();
		
		// If we get an id back then the name is taken
		if ( $result ){
			if ($result == $userid){
				return array( 'result' => true, 'message' => sprintf( JText::_( "COM_JWHMCS_CHANGEUSERNAME_MSG_SUCCESS01" ), $username ) );
			}
			else{
				return array( 'result' => false, 'message' => sprintf( JText::_( "COM_JWHMCS_CHANGEUSERNAME_MSG_ERROR03" ), $username ) );
			}
		}
		else{
			return array( 'result' => true, 'message' => sprintf( JText::_( "COM_JWHMCS_CHANGEUSERNAME_MSG_SUCCESS00" ), $username ) );
		}
	}
}