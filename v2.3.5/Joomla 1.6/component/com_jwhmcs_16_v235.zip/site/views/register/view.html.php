<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    Joomla! 1.6 Package
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.3.5 ( $Id: view.html.php 254 2011-08-17 02:13:04Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      2.1.0
 * 
 * @desc       Register View:  Handles the view for the integrated registration
 *  
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
jimport( "joomla.html.parameter" );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * JwhmcsViewRegister View Script
 * @version		2.3.5
 * 
 * @since		2.1.0
 * @author		Steven
 */
class JwhmcsViewRegister extends JView
{
	/**
	 * Called by the task to render view to user
	 * @access		public
	 * @version		2.3.5
	 * @param		unknown		- $tpl: presumably used by Joomla
	 * 
	 * @since		2.3.1
	 */
	public function display($tpl = null)
	{
		// Load data for register layout
		$app		= & JFactory::getApplication();
		$tmplparams	=   $app->getParams();
		$pathway	= & $app->getPathway();
		$params		= & JwhmcsParams::getInstance();
		
		$orig		= & JURI::getInstance();
		$config		= & JFactory::getConfig();
		$uri		= & JURI::getInstance( $config->get('live_site') );
		$uri->setScheme( $orig->getScheme() );
		$thisurl	=   rtrim( $uri->toString( array( 'scheme', 'host', 'path' ) ), "/" ) . "/";
		
		$document	= & JFactory::getDocument();
		$model		= & $this->getModel();
		$user		= & JFactory::getUser();
		
		// Page Title
		$menus	= & JSite::getMenu();
		$menu	=   $menus->getActive();
		$menups	=   new JParameter( $menu->params );
		
		if ( $menups->get( 'page_title' ) ) $document->setTitle( $menups->get( 'page_title' ) );
		$pathway->addItem( JText::_( 'New' ));
		
		// Load the form validation behavior
		JHtml::_( 'behavior.formvalidation' );
		JHtml::_( 'behavior.mootools' );
		
		$user 	= & JFactory::getUser();
		$post	=   $this->get( "post" );
		
		// Build Country Select
		$country	= JHtml::_('select.genericlist', JwhmcsHelper::buildCountries(), 'country', null, 'value', 'text', ( isset( $post['country'] ) ? $post['country'] : $params->get( 'WhmcsDefaultcountry' ) ) );
		
		JHtml::script( "jquery.js", rtrim( $params->get( 'ApiUrl' ), "/" ).'/includes/jscript/' );
		JHtml::script( "com_jwhmcs/noconflict.js", array(), true );
		JHtml::script( "com_jwhmcs/ajax.js", array(), true );
		
		JHtml::stylesheet( "com_jwhmcs/signup.css", array(), true );
		
		$tmplparams->set( 'RecaptchaEnable',	$params->get( 'RecaptchaEnable' ));
		$tmplparams->set( 'RecaptchaTheme',		$params->get( 'RecaptchaTheme' ));
		$tmplparams->set( 'RecaptchaLang',		$params->get( 'RecaptchaLang' ));
		$tmplparams->set( 'RecaptchaPublickey',	$params->get( 'RecaptchaPublickey' ));
		
		$params->set( 'scheme', $uri->getScheme() );
		
		$this->assignRef( 'tmplparams',	$tmplparams );
		$this->assignRef( 'params',		$params );
		$this->assignRef( 'user',		$user );
		$this->assignRef( 'country',	$country );
		$this->assignRef( 'post',		$post );
		$this->assignRef( 'tmp', 		$params );
		$this->assignRef( 'thisurl',	$thisurl );
		
		parent::display($tpl);
	}
}