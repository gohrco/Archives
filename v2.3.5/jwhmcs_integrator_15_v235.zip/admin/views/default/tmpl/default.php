<?php defined('_JEXEC') or die('Restricted access');
jimport('joomla.html.pane');
JHTML::_('behavior.mootools');
JHTML::_('behavior.tooltip');

$lang	= &JFactory::getLanguage();

$tmp	= explode('-', $this->data->get( 'LicenseKey' ));
$lictype	= $tmp[0];

?>

<div id="cpanel" style="width: 98%; clear: both; ">
	<div style="width: 400px; float: left; ">
		<?php
		  foreach ($this->icondefs as $icon):
		  	$imglnk	= JRoute::_('index.php?option='.JRequest::getCmd('option','com_jwhmcs') . (is_null($icon['controller']) ? '' : '&amp;controller='.$icon['controller']) . (is_null($icon['task']) ? '' : '&amp;task='.$icon['task']) . ( is_null($icon['view']) ? '' : '&amp;view='.$icon['view'] ));
		  	$imgsrc = "../components/com_jwhmcs/media/icons/{$icon['icon']}";
		?>
		<div style="float: left; ">
			<div class="icon">
				
				<a <?php if ($this->lic['valid'] || ($icon['controller'] == 'helppage') || ($icon['controller'] == 'check') || ($icon['controller'] == 'config')): ?>href="<?php echo $imglnk; ?>"<?php endif; ?>>
					<img
						src="<?php echo $imgsrc; ?>"
						border="0" alt="<?php echo $icon['label']; ?>" />
					<span><?php echo $icon['label']; ?></span>
				</a>
			</div>
		</div>
		<?php endforeach; ?>
	</div>
	<div id="jpmodules" style="width: 450px; float: right;">
		<h1 style="text-align: center; width: 100%; margin: 0px; padding: 0px; " class="title">J!WHMCS Integrator</h1>
		<h4 style="text-align: center; width: 100%; margin: 0px; padding: 0px; " class="title">version <?php echo $this->data->get( 'Version' ); ?></h4>
		
		<table width="400px" align="center" border="0" cellpadding="5" cellspacing="0" style="margin: 0px auto; ">
			<tr>
				<td align="right" valign="top">
					Licensed To:
				</td>
				<td align="left" valign="top" style="font-weight: bold; ">
					<?php echo $this->lic['registeredname']; ?>
					<?php echo ( isset($this->lic['companyname']) ? '<br />' . $this->lic['companyname'] : '' ); ?>
					<?php echo ( isset($this->lic['email']) ? '<br />' . $this->lic['email'] : '' ); ?>
				</td>
			</tr>
			<tr>
				<td align="right" valign="top">
					Registered On:
				</td>
				<td align="left" valign="top" style="font-weight: bold; ">
					<?php echo date("F j, Y", strtotime($this->lic['regdate'])); ?>
				</td>
			</tr>
			<tr>
				<td align="right" valign="top">
					License Details:
				</td>
				<td align="left" valign="top" style="font-weight: bold; ">
					<?php echo $this->data->get( 'LicenseKey' ); ?><br />
					<span style="text-align: left; color: <?php echo ($this->lic['valid'] ? '#008800' : '#FF0000'); ?>;"><?php echo $this->lic['branded'] ? 'B' : "Unb"; ?>randed <?php echo $lictype; ?> License</span>
					<?php if ($this->lic['branded']): ?><a href="http://gohigheris.com" target="blank">Find out how to remove branding</a><?php endif; ?>
					<?php if ($this->lic['kayako']): ?>Kayako User Integration included<?php endif; ?>
				</td>
			</tr>
			<tr>
				<td align="right" valign="top">
					Last Synchronized On:
				</td>
				<td align="left" valign="top" style="font-weight: bold; ">
					<?php echo ($this->data->get( 'LastSync' ) ? date("F j, Y h:i:s a", $this->data->get( 'LastSync' ) ) : 'Not yet synced' ); ?>
				</td>
			</tr>
		</table>
	</div>
</div>
<form action="index.php" method="post" name="adminForm">
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="controller" value="default" />
<input type="hidden" name="task" value="" />
</form>