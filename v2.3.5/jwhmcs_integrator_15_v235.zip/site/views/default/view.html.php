<?php
/**
 * Default View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: view.html.php 182 2011-02-10 15:40:22Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
include_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php' );
include_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'helper.php' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsViewDefault
 * Extends:		JView
 * Purpose:		Handles the default view
 * As of:		version 1.5.0
\* ------------------------------------------------------------ */
class JwhmcsViewDefault extends JView
{
	/* ------------------------------------------------------------ *\
	 * Handler:		display
	 * Purpose:		Needed for building the class
	 * As of:		version 1.5.0
	\* ------------------------------------------------------------ */
	function display($tpl = null)
	{
		// Load data for register layout
		$app		= & JFactory::getApplication();
		$tplparams	=	$app->getParams();
		$params		= &	JwhmcsParams::getInstance();
		$uri		= &	JURI::getInstance();
		$document	= &	JFactory::getDocument();
		$layout		= &	JRequest::getVar( 'layout' );
		
		$whmcsurl	= & JUri::getInstance( $params->get( 'ApiUrl' ), true );
		$whmcsurl->setPath( rtrim( $whmcsurl->getPath(), "/" ) . "/includes/jscript/" );
		
		switch( $layout ):
		case 'default':
		default:
			if ($params->get( 'RenderJqueryenable' )) {
				JHTML::script('jquery.js', rtrim( $params->get( 'ApiUrl' ), "/" ) . '/includes/jscript/', true);
				JwhmcsHelper::addMedia( "noconflict.js/js" );
			}
			
			$base = & $document->getBase();
			if(empty($base)) {
				$document->setBase( $uri->toString( array('scheme', 'host', 'path') ) );
			}
			
			break;
		endswitch;
		
		$this->assignRef('params',	$tplparams);
		
		parent::display($tpl);
		
	}
}