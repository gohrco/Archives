<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    Joomla! 1.5 Package
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.3.5 ( $Id: changeusername.php 169 2011-02-04 05:39:14Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      2.1.0
 * 
 * @desc       This file contains the changeusername controller class allowing the system to intereact with the data based upon actions
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * Changeusername controller is used to handle tasks to perform for the user by the system
 * @version 2.3.0
 * 
 * @since	2.1.0
 * @author	Steven
 */
class JwhmcsControllerChangeusername extends JController
{
	/**
	 * Constructor
	 * @access	public
	 * 
	 * @since  2.1.0
	 */
	public function __construct() {
		parent::__construct();
	}
	
	
	/**
	 * Task to handle submitting the new username to the system
	 * @access	public
	 * @version	2.3.0
	 * 
	 * @since	2.1.0
	 */
	public function submit()
	{
		$model	= $this->getModel( 'changeusername' );
		$result	= $model->submit();
		
		parent::display();
	}
	
	
	/**
	 * Task to handle the ajax call to validate the username prior to submittal
	 * @access	public
	 * @version	2.3.0
	 * 
	 * @since	2.1.0
	 */
	public function validateUsername()
	{
		$app		= & JFactory::getApplication();
		$username	= & JRequest::getVar( 'username' );
		$userid		= & JRequest::getVar( 'joomlaid' );
		$model		= & $this->getModel( 'changeusername' );
		$result		= & $model->validateUsername( $username, $userid);
		
		foreach ($result as $k => $v) $data[$k] = $v;
		echo $model->buildResponse($data);
		$app->close();
	}
}