<?php
/**
 * Ajax Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: ajax.php 232 2011-06-01 20:05:52Z steven_gohigher $
 * @since      1.5.1
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');

include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelAjax
 * Extends:		JwhmcsModel
 * Purpose:		Used as the ajax model for ajax handling
 * As of:		version 2.0.0
\* ------------------------------------------------------------ */
class JwhmcsModelAjax extends JwhmcsModel
{
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function __construct() {
		parent::__construct();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		checkApi
	 * Purpose:		Called during install to check API connection
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function checkApi() {
		$params = JwhmcsParams::getInstance();
		$params->set( 'ApiUsername', JRequest::getVar( 'jwhmcsadminus'), false, 'global' );
		$params->set( 'ApiPassword', JRequest::getVar( 'jwhmcsadminpw'), false, 'global' );
		$params->set( 'ApiAccesskey', JRequest::getVar( 'accesskey'), false, 'global' );
		$params->saveAll();
		return $this->getApiConnection();
	}
	
	
	/**
	 * Called to check the API connection from the "API Connection" feature
	 * @access		public
	 * @version		2.3.5
	 * 
	 * @return		array containing results
	 * @since		2.0.0
	 */
	public function checkApiu()
	{
		$jwhmcsurl	= rtrim(trim( urldecode( JRequest::getVar( 'jwhmcsurl' ) ) ), '/' );
		
		// If we didn't get a URL then don't continue
		if (!$jwhmcsurl) {
			$data['result'] = 'error';
			$data['message'] = 'No URL entered';
			return $data;
		}
		
		// Be sure to urldecode the variables
		$jwhmcsus	= urldecode( JRequest::getVar( 'jwhmcsadminus' ) );
		$jwhmcspw	= urldecode( JRequest::getVar( 'jwhmcsadminpw' ) );
		$jwhmcsxs	= trim( urldecode( JRequest::getVar( 'accesskey' ) ) );
		
		// If the accesskey should be empty, set it to null
		if (! $jwhmcsxs ) $jwhmcsxs = null;
		
		// If there wasn't a username or password then don't continue
		if ((! $jwhmcsus ) || (! $jwhmcspw ) ) {
			$data['result']	= 'error';
			$data['message']	= "Please enter a " . ((! $jwhmcsus ) ? "API Username" : "API Password" );
			return $data;
		}
		
		// If the password has an & we can't authenticate (WHMCS filters them out)
		if ( strpos( $jwhmcspw, "&" ) !== false ) {
			$data['result']	= 'error';
			$data['message']	= "Your API password cannot contain an ampersand.";
			return $data;
		}
		
		// Set API settings and chceck connection
		$params = JwhmcsParams::getInstance();
		$params->set( 'ApiUrl', $this->_quickParseUrl($jwhmcsurl), false, 'global' );
		$params->set( 'ApiUsername', $jwhmcsus, false, 'global' );
		$params->set( 'ApiPassword', $jwhmcspw, false, 'global' );
		$params->set( 'ApiAccesskey', $jwhmcsxs, false, 'global' );
		$params->saveAll();
		
		return $this->getApiConnection();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		checkPath
	 * Purpose:		Called during install to check path of WHMCS
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function checkPath()
	{
		$jcurl = JwhmcsCurl::getInstance();
		$files = array( 'configuration.php', 'dbconnect.php', 'dologin.php' );
		
		$whmcsurl	= trim( urldecode( JRequest::getVar( 'whmcsurl' ) ) );
		$whmcspath	= trim( urldecode( JRequest::getVar( 'whmcspath' ) ) );
		
		$url = false;
		$path = false;
		
		if (!$whmcsurl) {
			$msg[] = 'No Url Entered';
		}
		else {
			// Test URL to see if dbconnect exists
			$url = $this->_buildUrl($whmcsurl, 'dbconnect.php');
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->setParse(false);
			$jcurl->loadResults();
			
			if ($jcurl->info['http_code'] != 200 ) {
				$msg[] = 'WHMCS Not Found at URL';
			}
			else {
				$url = true;
				$msg[] = 'WHMCS Url Valid!';
			}
		}
		
		if (!$whmcspath) {
			$msg[] = 'No Path Entered';
		}
		else {
			// Test Path to see if files exist there
			$whmcspath = JFolder::makesafe( $whmcspath );
			if (! JFolder::exists( $whmcspath ) ) {
				$msg[] = 'WHMCS Path does not exist';
			}
			else {
				$path = true;
				foreach ($files as $file) {
					if (! JFile::exists($whmcspath.DS.$file) ) {
						$path = false;
					}
				}
				if ($path) {
					$msg[] = 'WHMCS Path Valid!';
				}
				else {
					$msg[] = 'WHMCS Path not valid';
				}
			}
		}
		
		if (($url === true) && ($path === true)) {
			$data['result'] = 'success';
		}
		else {
			$data['result'] = 'error';
		}
		
		$data['message'] = implode("<br />", $msg);
		
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		checkValidLicense
	 * Purpose:		Called during install to check license
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function checkValidLicense()
	{
		$license = trim( urldecode( JRequest::getVar( 'license' ) ) );
		
		$params = JwhmcsParams::getInstance();
		$params->set( 'LicenseKey', $license, false, 'global' );
		$params->set( 'License', '', false, 'global' );
		$params->saveAll();
		
		$lic = $this->checkLicense();
		if ($lic['valid']) {
			$data['result'] = 'success';
			$data['message'] = 'License is valid';
		}
		else {
			$data['result'] = 'error';
			$data['message'] = 'License entered not valid';
		}
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_buildUrl (private)
	 * Purpose:		build a url
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	private function _buildUrl($path, $file)
	{
		$uri = JURI::getInstance( rtrim($path, '/').'/'.$file );
		return $uri->toString();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_quickParseUrl (private)
	 * Purpose:		Parse a url
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	private function _quickParseUrl($url)
	{
		$tmp = JURI::getInstance($url);
		
		return $tmp->toString();
		/*$tmp = parse_url($url);
		
		// Remove a slash if added to the end of the url and set parameter
		if ($tmp['path']=='/') unset($tmp['path']);
		return $tmp['host'].(isset($tmp['path'])?$tmp['path']:'').(isset($tmp['query'])?$tmp['query']:'').(isset($tmp['fragment'])?$tmp['fragment']:'');
		*/
	}
}

?>