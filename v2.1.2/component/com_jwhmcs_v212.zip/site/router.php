<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: router.php 9 2009-09-30 23:01:32Z Steven $
 * @since      1.5.0
 */


/**
 * Router for building SEF link
 * 
 * @param	$query (array)
 * @return	$segments (array)
 */
function JwhmcsBuildRoute(&$query)
{
	$segments = array();
	
	// Query array:  required items up front (view / layout)
	$qarray	= array(	'view'			=> 'default',
						'layout'		=> 'default',
						'controller'	=> null,
						'task'			=> null,
						'token'			=> null,
						'jwhmcs'		=> null,
						'username'		=> null,
						'joomlaid'		=> null
	);
	
	foreach ( $qarray as $q => $d )
	{
		if ( isset( $query[$q] ) )
		{
			$segments[] = $query[$q];
			unset ( $query[$q] );
		}
		elseif (! is_null( $d ) )
		{
			$segments[] = $d;
		}
	}
	
	return $segments;
}


/**
 * Router for parsing SEF link
 * 
 * @param	$segments (array)
 * @return	$vars (array)
 */
function JwhmcsParseRoute($segments)
{
	$vars = array();
	
	// Variable array:  required items up front (view / layout)
	$varray	= array(	0	=> 'view',
						1	=> 'layout',
						2	=> 'controller',
						3	=> 'task',
						4	=> 'token',
						5	=> 'jwhmcs',
						6	=> 'username',
						7	=> 'joomlaid'
	);
	
	for ( $i=0; $i<count($segments); $i++ )
	{
		if ( isset( $segments[$i] ) )
		{
			$vars[$varray[$i]] = $segments[$i];
		}
	}
	
	return $vars;
}
