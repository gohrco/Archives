<?php
/**
 * J!WHMCS Integrator - Authentication Plugin
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id$
 * @since      1.5.1
 * 
 * @desc		This plugin handles authentication of the user in case they use
 * 				their email address instead of their Joomla username.
 */


// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.application.component.helper' );

$curlfile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jwhmcs'.DS.'classes'.DS.'class.curl.php';
if (is_readable($curlfile)) include_once($curlfile);

/* ------------------------------------------------------------ *\
 * Class:		plgAuthenticationPlg_auth_jwhmcs
 * Purpose:		This plugin allows the user to login with either the
 * 				email address or their username from Joomla
\* ------------------------------------------------------------ */
class plgAuthenticationJwhmcs_auth extends JPlugin
{
	/* ------------------------------------------------------------ *\
	 * Method:		plgAuthenticationPlg_auth_jwhmcs
	 * Purpose:		Constructor function
	\* ------------------------------------------------------------ */
	function plgAuthenticationJwhmcs_auth(& $subject, $config)
	{
		parent::__construct($subject, $config);
	}

	
	/* ------------------------------------------------------------ *\
	 * Method:		onAuthenticate
	 * Purpose:		Handles user authentication procedure for customer
	 * As of:		1.5.1
	 * 
	 * Significant Updates:
	 * 	2.1.0 (Apr 2010)
	 * 		+ Added authentication of subaccounts from WHMCS
	 * 		* Completely revamped to streamline process
	 * 		* Modified parameters to reflect database change
	 *  2.0.2 (Mar 2010)
	 *  	* Modified response when getting results for email to look for array of array
	\* ------------------------------------------------------------ */
	function onAuthenticate( $credentials, &$options, &$response )
	{
		global $mainframe;
		
		if (! class_exists('JwhmcsParams') ) return;
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		if (! $params->get( 'Enable' )) {
			$response->status = JAUTHENTICATE_STATUS_FAILURE;
			$response->error_message = JText::_('AUTH_ERROR_DISABLED');
			return false;
		}
			
		if (! $params->get( 'UserEnable' )) {
			$response->status = JAUTHENTICATE_STATUS_FAILURE;
			$response->error_message = JText::_('AUTH_ERROR_USERINT_DISABLED');
			return false;
		}
		
		jimport('joomla.user.helper');
		jimport ('joomla.error.log');
		$conditions = '';
		
		// Verify password isn't empty before doing anything
		if (empty($credentials['password']))
		{
			$response->status = JAUTHENTICATE_STATUS_FAILURE;
			$response->error_message = JText::_('AUTH_ERROR_EMPTYPASS');
			return false;
		}
		
		// Find out if email being used
		$isemail = $this->_checkEmail($credentials['username']);
		
		// If this is an email and not an admin area...
		if ($isemail && (! $mainframe->isAdmin())) {
			// Run authentication against WHMCS
			if (! ($wuser = $this->_authWhmcs($credentials, $response) ) )
				return false;
		}
		// If this is a username...
		else {
			// Run authentication against Joomla
			if (! ($juser = $this->_authJoomla($credentials, $response) ) )
				return false;
			
			// Administrators get off here...
			if ($mainframe->isAdmin())
				return true;
		}
		
		/* ---------------------------------------------------------------------- *\
		 * At this point the user is authenticated against either Joomla or WHMCS
		\* ---------------------------------------------------------------------- */
		$whereby = ($isemail ? "xref_b={$wuser['id']} " : "xref_a={$juser->id} ");
		
		// If we have arrived here then user has authenticated, now we need to pull Joomla user
		$query	= "SELECT xref_a as joomlaid, xref_type as type, xref_b as clientid FROM #__jwhmcs_xref WHERE {$whereby} AND xref_type BETWEEN 1 AND 9";
		$db->setQuery($query);
		$joom	= $db->loadObjectList();
		
		$joom	= $this->_checkOrphaned($joom, ($isemail ? 'joomla' : 'whmcs') );
		
		// Check to see if the matchedup user is actually a member of a group
		if (! $isemail) {
			$isgroup = $this->_checkGroup($joom, $credentials);
		}
		
		// Test to ensure there is a joom
		if ($joom) {
			// Get matching Joomla info
			if ($isemail) {
				// No matching Joomla info found
				if (! ($juser = $this->_getJoomlaData($joom->joomlaid, 'id')) ) {
					$this->_removeXref($joom->joomlaid, $joom->type, $joom->clientid);
					unset($joom);
				}
				// We did find the matching info now should we reset the password?
				else {
					if ($params->get( 'JuserAutosync' )) {
						$this->_handlePassword('joomla', $juser, $joom, $credentials);
					}
				}
					
			}
			// Or get matching WHMCS info
			else {
				// No matching WHMCS info found
				if (! ($wuser = $this->_getWhmcsData($joom->clientid, 'id', ( $joom->type == '8' ? 'client' : 'contact' ) ) ) ) {
					$this->_removeXref($joom->joomlaid, $joom->type, $joom->clientid);
					unset($joom);
				}
				// We did find the matching info in WHMCS, so should we reset the password?
				else {
					if (($params->get( 'WuserAutosync' )) && (! $isgroup)) {
						$this->_handlePassword('whmcs', $wuser, $joom, $credentials);
					}
				}
			}
		}
		
		// Matching user doesn't exist in xref or was removed b/c it doesn't exist in Joomla
		if ((! $joom) && ($isemail)) {
			// Retrieve matching user in Joomla by email
			$juser = $this->_getJoomlaData($wuser['email'], 'email');
			
			// No matching user found
			if (! $juser) {
				// Can we add them?
				if ($params->get( 'JuserAutoadd' )) {
					$juser = $this->_addJoomlaUser($wuser, $credentials, $response);
				}
				// We aren't allowed by parameters to add new Joomla user so we fail since we must have a Joomla user to login with
				else {
					$response->status = JAUTHENTICATE_STATUS_FAILURE;
					$response->error_message = JText::_('AUTH_ERROR_INVALIDUSPW');
					return false;
				}
			}
		}
		// Matching user doesn't exist in xref or was removed b/c it doesn't exist in WHMCS
		elseif ((! $joom) && (! $isemail)) {
			// Retrieve matching user in WHMCS by email
			$wuser = $this->_getWhmcsData($juser->email, 'email', 'client');
			
			if (! $wuser )
			{
				$wuser = $this->_getWhmcsData($juser->email, 'email', 'contact' );
			}
			
			// No matching user found
			if (! $wuser) {
				// Can we add them?
				if ($params->get( 'WuserAutoadd' )) {
					$wuser = $this->_addWhmcsUser($juser, $credentials, $response);
				}
				// We aren't allowed by parameters to add a new user to WHMCS, but they are authenticated in Joomla so return true
				else {
					$user = JUser::getInstance($juser->id);
					$response->fullname 	= $user->name;
					$response->username		= $user->username;
					$response->email		= $user->email;
					$response->password		= $user->password;
					$response->status		= JAUTHENTICATE_STATUS_SUCCESS;
					$response->error_message = '';
					return true;
				}
			}
		}
		
		// Both users have been created or gathered so lets match em up
		if (! $joom) {
			$justore = ( $params->get( 'JusernameStore' ) == '8' ? true : false );  // If we want to request the username check parameter here
			$type = ($isemail ? ( $justore ? ( $wuser['xref_type'] == 2 ? 8 : 9 ) : $wuser['xref_type'] ) : 2 );
			$query = "INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) VALUES ({$juser->id}, {$type}, {$wuser['id']})";
			$db->setQuery($query);
			$db->query();
		}
		
		// Return response object true
		$user = JUser::getInstance($juser->id);
		$response->fullname 	= $user->name;
		$response->username		= $user->username;
		$response->email		= (! $isgroup ? $user->email : $credentials['username'] );
		$response->password		= $credentials['password'];
		$response->password_clear = $credentials['password'];
		$response->status		= JAUTHENTICATE_STATUS_SUCCESS;
		$response->error_message = '';
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_authWhmcs
	 * Purpose:		Authenticates against WHMCS
	 * As of:		2.1.0
	\* ------------------------------------------------------------ */
	function _authWhmcs($credentials, &$response)
	{
		// Start by getting client data
		$whmcs = $this->_getWhmcsData($credentials['username'], 'email', 'client' );
		
		if (! $whmcs ) {
			$whmcs = $this->_getWhmcsData( $credentials['username'], 'email', 'contact' );
		}
		
		// result failed - no user found by that email
		if ($whmcs['result']!='success') {
			$response->status = JAUTHENTICATE_STATUS_FAILURE;
			$response->error_message = JText::_('AUTH_ERROR_WNOTFOUND');
			return false;
		}
		
		if (! $this->_testWhmcsPassword($whmcs['password'], $credentials['password'])) {
			$response->status = JAUTHENTICATE_STATUS_FAILURE;
			$response->error_message = JText::_('AUTH_ERROR_INVALIDPW');
			return false;
		}
		
		return $whmcs;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_authJoomla
	 * Purpose:		Authenticates against Joomla
	 * As of:		2.1.0
	\* ------------------------------------------------------------ */
	function _authJoomla($credentials, &$response)
	{
		global $mainframe;
		
		$user = $this->_getJoomlaData($credentials['username'], 'username');
		
		// result failed - no user found by that username
		if (!$user) {
			$response->status = JAUTHENTICATE_STATUS_FAILURE;
			$response->error_message = JText::_('AUTH_ERROR_JNOTFOUND');
			return false;
		}
		
		if (! $this->_testJoomlaPassword($user->password, $credentials['password'])) {
			$response->status = JAUTHENTICATE_STATUS_FAILURE;
			$response->error_message = JText::_('AUTH_ERROR_INVALIDPW');
			return false;
		}
		
		if ($mainframe->isAdmin()) {
			$response->email			= $user->email;
			$response->fullname			= $user->name;
			$response->status			= JAUTHENTICATE_STATUS_SUCCESS;
			$response->error_message	= '';
		}
		
		return $user;
	}
		
	
	/* ------------------------------------------------------------ *\
	 * Method:		_getWhmcsData
	 * Purpose:		Retrieves data from WHMCS
	 * As of:		2.1.0
	\* ------------------------------------------------------------ */
	function _getWhmcsData( $method, $by = 'email', $type = 'client' )
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		switch ($type):
		case 'client':
			if ($by == 'email') {
				$jcurl->setAction('getclientsdatabyemail', array('email' => $method));
			}
			else {
				$jcurl->setAction('getclientsdata', array('clientid' => $method));
			}
			
			$whmcs	= $jcurl->loadResult();
			
			// WHMCS v421:  Now receive array of array -- need to test for it
			if ( isset($whmcs[0]['result']) ) $whmcs = $whmcs[0];
			
			if (( isset($whmcs['result'])) && ($whmcs['result'] == 'success')) {
				$whmcs['xref_type'] = 2;
				$ret = $whmcs;
			}
			else {
				$ret = false;
			}
			break;
		
		case 'contact':
			$jcurl->setAction('jwhmcsgetcontact', array("get" => "$by=$method"));
			$whmcs = $jcurl->loadResult();
			
			if ($whmcs['result'] == 'success') {
				$whmcs['userid'] = $whmcs['id'];
				$whmcs['xref_type'] = 6;
				$ret = $whmcs;
			}
			else {
				$ret = false;
			}
			
			break;
		endswitch;
		
		return $ret;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_getJoomlaData
	 * Purpose:		Retrieves data from Joomla
	 * As of:		2.1.0
	\* ------------------------------------------------------------ */
	function _getJoomlaData($method, $by = 'username')
	{
		$db = & JFactory::getDBO();
		
		$query	= "SELECT a.* FROM `#__users` AS a WHERE {$by}={$db->Quote($method)}";
		$db->setQuery($query);
		return $db->loadObject();
	}
	
	
	function _handlePassword($type, $user, &$joom, &$credentials)
	{
		$jcurl			= & JwhmcsCurl::getInstance();
		$params			= & JwhmcsParams::getInstance();
		$usepassword	=   $credentials['password'];
		
		switch ($type):
		case 'joomla':
			// Test the current password
			$testpw = $this->_testJoomlaPassword($user->password, $credentials['password']);
			
			if ($testpw)
				return; // Password is the same so send back

			$ubind = array('password' => $credentials['password'], 'password2' => $credentials['password']);
			
			$juser = JUser::getInstance($user->id);
			if (! $juser->bind($ubind, 'usertype') ) return false;
			if (! $juser->save() ) return false;
			
			break;
		case 'whmcs':
			// Test the current password 
			$testpw = $this->_testWhmcsPassword($user['password'], $credentials['password']);
			
			if ($testpw)
				return; // Password is the same so send back
			
			// If WHMCS version 4.1 or higher, return password clear text
			if (str_replace(".", "", $params->get( 'WhmcsVersion' ) ) < 410 ) {
				// We must encode the password for WHMCS < 4.1
				$jcurl->setAction('getclientpassword', array('userid' => $user['id']));
				$whmcs	= $jcurl->loadResult();
				
				// Explode password hash to get salt and resalt new password and return
				$pwexp	= explode(':', $whmcs['password']);
				$usepassword = md5($pwexp[1].$password).':'.$pwexp[1];
			}
			
			// Subaccounts
			if ($joom->type == 6) {
				$fields['set']			= "id={$user['id']};password=$usepassword";
				$action = 'jwhmcsgetcontact';
			}
			// Regular clients
			else {
				$fields['clientid']		= $user['id'];
				$fields['password2']	= $usepassword;
				$action = 'updateclient';
			}
			
			$jcurl->setAction($action, $fields);
			$whmcs	= $jcurl->loadResult();
			
			break;
		endswitch;
		
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_removeXref
	 * Purpose:		Remove an xref
	 * As of:		2.1.0
	\* ------------------------------------------------------------ */
	function _removeXref($a, $t, $b)
	{
		$db = & JFactory::getDBO();
		
		$query = "DELETE FROM #__jwhmcs_xref WHERE xref_a={$a} AND xref_type={$t} AND xref_b={$b}";
		$db->setQuery($query);
		$db->query();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_addJoomlaUser
	 * Purpose:		Add a Joomla user
	 * As of:		2.1.0
	\* ------------------------------------------------------------ */
	function _addJoomlaUser($whmcs, $credentials, &$response)
	{
		define('JWHMCS_AUTH', true); // Set so we don't try to add the new user to WHMCS
		
		// Add user to J! database
		$acl	= &JFactory::getACL();
		$user	= JFactory::getUser(0);	
		$usersConfig	=& JComponentHelper::getParams( 'com_users' );
		
		$newUsertype = $usersConfig->get( 'new_usertype' );
		if (!$newUsertype)
			$newUsertype = 'Registered';
		
		// Build the user array for binding
		$ubind['name']		= $whmcs['firstname'].' '.$whmcs['lastname'];
		$ubind['username']	= strtolower($whmcs['firstname'].'.'.$whmcs['lastname']);
		$ubind['email']		= $whmcs['email'];
		$ubind['gid']		= $acl->get_group_id( '', $newUsertype, 'ARO' );
		$ubind['password']	= $credentials['password'];
		$ubind['password2']	= $credentials['password'];
		$ubind['sendEmail']	= 0;
		$ubind['block']		= 0;
		
		// Bind the post array to the user object
		if (!$user->bind( $ubind )):
			$response->status = JAUTHENTICATE_STATUS_FAILURE;
			$response->error_message = 'Invalid Username or Password';
			return false;
		endif;
		
		$date =& JFactory::getDate();
		$user->set('registerDate', $date->toMySQL());
		
		// If there was an error with registration, set the message and display form
		if ( !$user->save() )
		{
			$response->status = JAUTHENTICATE_STATUS_FAILURE;
			$response->error_message = JText::_('AUTH_ERROR_INVALID_NEWJUSER');
			return false;
		}
		return $user;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_addWhmcsUser
	 * Purpose:		Adds a WHMCS user
	 * As of:		2.1.0
	\* ------------------------------------------------------------ */
	function _addWhmcsUser($user, $credentials, &$response)
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		$fields['firstname']	= $credentials['username'];
		$fields['lastname']		= '(web site user)';
		$fields['address1']		= $params->get( 'WuserDefaultaddress' );
		$fields['city']			= $params->get( 'WuserDefaultcity' );
		$fields['state']		= $params->get( 'WuserDefaultstate' );
		$fields['postcode']		= $params->get( 'WuserDefaultpostal' );
		$fields['country']		= $params->get( 'WuserDefaultcountry' );
		$fields['phonenumber']	= $params->get( 'WuserDefaultphone' );
		$fields['currency']		= '1';
		$fields['email']		= $user->email;
		$fields['password2']	= $credentials['password'];
		
		// 4a1b: Send to curl for adding user and get id back
		$jcurl->setAction('addclient', $fields);
		$whmcs	= $jcurl->loadResult();
		
		// 4a1c: Add new user to xref DB
		$query = 'INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) '
					.'VALUES ("'.$user->id.'", "1", '.$whmcs['clientid'].')';
		$db->setQuery($query);
		$db->query();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_parseJPassword (private)
	 * Purpose:		This function parses and returns encrypted Joomla
	 * 				password for comparison purposes.
	 * ------------------------------------------------------------ */
	private function _parseJPassword($curpass, $newpass)
	{
		$parts	= explode( ':', $curpass );
		$crypt	= $parts[0];
		
		if ( count( $parts ) > 1 )
		{
			$salt = $parts[1];
			$ret['password']	= JUserHelper::getCryptedPassword( $newpass, $salt );
			$ret['salted']		= $ret['password'].':'.$salt;
		} else {
			$ret['password']	= JUserHelper::getCryptedPassword( $newpass );
			$ret['salted']		= $ret['password'];
		}
		return $ret;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_parseWPassword (private)
	 * Purpose:		This function parses and returns encrypted WHMCS
	 * 				password for comparison purposes.
	 * ------------------------------------------------------------ */
	private function _parseWPassword($encoded, $clear)
	{
		$pwexp	= explode(':', $encoded);
		return md5($pwexp[1].$clear).':'.$pwexp[1];
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_testJoomlaPassword
	 * Purpose:		Validates a Joomla Password
	 * As of:		2.1.0
	\* ------------------------------------------------------------ */
	private function _testJoomlaPassword($encoded, $clear)
	{
		$testpw = $this->_parseJPassword($encoded, $clear);
		return ($testpw['salted'] == $encoded ? true : false);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_testWhmcsPassword (private)
	 * Purpose:		Validates a WHMCS Password
	 * 
	 * Significant Updates:
	 * 	2.1.0 (Apr 2010)
	 * 		* Modified parameters to reflect database change
	 * ------------------------------------------------------------ */
	private function _testWhmcsPassword($encoded, $clear)
	{
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		if ($params->get( 'WhmcsNomd5' )) {	// We are not using MD5
			$jcurl->setAction('decryptpassword', array('password2' => $encoded));
			$whmcs	= $jcurl->loadResult();
			
			if ($whmcs['result'] == 'success') { 
				$return = ( $whmcs['password'] == $clear ? true : false );
			}
		}
		else {	// We are using MD5 here
			$testpw = $this->_parseWPassword($encoded, $clear);
			$return = ( $testpw == $encoded ? $testpw : false );
		}
		return $return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkOrphaned (private)
	 * Purpose:		Checks xref for orphans left behind
	 * As of:		1.5.1
	 * 
	 * Significant Updates:
	 * 	2.1.0 (Apr 2010)
	 * 		* Modified parameters to reflect database change
	 * ------------------------------------------------------------ */
	private function _checkOrphaned($xref, $system)
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		
		for ($i=0; $i<count($xref); $i++):
			$x = $xref[$i];
			switch($system):
			case 'joomla':	// We are testing for a set of Joomla IDs
				// Add error testing for xref'd Joomla ID
				$query = 'SELECT a.id FROM #__users as a WHERE id='.$x->joomlaid;
				$db->setQuery($query);
				$joom	= $db->loadResult();
				
				if (!$joom):
					$query = 'DELETE FROM #__jwhmcs_xref WHERE xref_a='.$x->joomlaid.' AND xref_type='.$x->type.' AND xref_b='.$x->clientid;
					$db->setQuery($query);
					$db->query();
					unset($xref[$i]);
				else:
					$ret = $xref[$i];
				endif;
				break;
			case 'whmcs':	// We are testing for a set of WHMCS IDs
				if ($x->type==4):
					// Pull the email and password from jwhmcs_user table
					$query	= 'SELECT grp.email as email FROM #__jwhmcs_group AS grp WHERE id='.$x->clientid;
					$db->setQuery($query);
					
					if ($joom = $db->loadObject()):
						$action				= 'getclientsdatabyemail';
						$fields['email']	= $joom->email;
					else:
						// WHMCS account must not exist, so break switch and reloop
						break;
					endif;
				else:
					$action				= 'getclientsdata';
					$fields['clientid']	= $x->clientid;
				endif;
				
				$jcurl->setAction($action, $fields);
				$whmcs	= $jcurl->loadResult();
				
				if ($whmcs['result']!='success'):
					$query = 'DELETE FROM #__jwhmcs_xref WHERE xref_a='.$x->joomlaid.' AND xref_type='.$x->type.' AND xref_b='.$x->clientid;
					$db->setQuery($query);
					$db->query();
					unset($xref[$i]);
				else:
					$ret = $xref[$i];
				endif;
				break;
			endswitch;
		endfor;
		
		if (count($xref)==0)
			$ret = null;
		
		return $ret;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkGroup (private)
	 * Purpose:		This function checks the xref_type field prior to
	 * 				pulling data for authentication against WHMCS just
	 * 				in case they belong to a group.  If so, (type 4)
	 * 				then their credentials are changed to match correct
	 * 				credentials for group.
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	private function _checkGroup(&$xref, &$credentials)
	{
		// 0:  Check type to see if we need to continue
		if ($xref->type<>4)
			return false;
		
		// 1:  We need this, so lets initialize variables 
		$db	= &JFactory::getDBO();
		
		// 2:  Use clientid to pull user from jwhmcs_group table to retrieve pw
		$query	= 'SELECT grp.email, grp.password FROM #__jwhmcs_group AS grp WHERE grp.id='.$xref->clientid;
		$db->setQuery($query);
		if ($res = $db->loadObject()) {
			$credentials['password']	= $res->password;
			$credentials['username']	= $res->email;
		}
		else {
			return false;
		}
		
		$whmcs = $this->_getWhmcsData($res->email, 'email', 'client');
		$xref->clientid = $whmcs['id'];
		
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkEmail (private)
	 * Purpose:		This function checks the username for an email
	 * As of:		2.0.0
	\* ------------------------------------------------------------ */
	private function _checkEmail($username)
	{
		// This is the pattern we are using to test for
		$pattern = "/\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,5}\b/i";
		$match = preg_match($pattern, $username);
		
		if (!$match)
			return false;
		elseif ($match > 0)
			return true;
		else
			return false;
	}
}