<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id$
 * @since      1.5.3
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class JwhmcsDBO
{
	
	/**
	 * @var instance to contain object when created
	 */
	private static $instance = null;
	
	var $db;
	
    /* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Called upon initialization of object class
	 * 
	 * As of:		version 1.5.3
	 * 
	 * Significant Revisions:
	 * 	none
	\* ------------------------------------------------------------ */
	function __construct($options)
	{
		// Create DB reference
		$this->db = mysql_connect ($options['host'],$options['user'],$options['password'], true);
		if (!$this->db) die('could not connect '.mysql_error());
		
		$dbsel = mysql_select_db ($options['database']);
		if (!$dbsel) die('Can\'t use '.$options['database'].': '.mysql_error());
		mysql_query( "SET NAMES 'utf8'", $this->db );
		$this->prefix	= array_key_exists('prefix', $options) ? $options['prefix'] : 'jos_';
		
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getInstance
	 * Purpose:		Called to create an instance of the class - first
	 * 					time run requires jconfig to be passed to it
	 * 
	 * As of:		version 1.5.3
	 * 
	 * Significant Revisions:
	 * 	none
	\* ------------------------------------------------------------ */
	public static function getInstance($options = null)
	{
		
		if ((!$options) && (self::$instance == null)) {
			$options = self::_getJConfig();
		}
		if (is_a($options, 'JConfig')) {
			$options = self::_buildDbArray($options);
		}
		if ((self::$instance == null) || ($options)) {
			self::$instance = self::createInstance($options);
		}
//		echo '<pre>Instance:<Br />'.print_r(self::$instance,1).'</pre>';
		return self::$instance;
	}
	
	
	public function createInstance($options)
	{
		static $instances;
		if (!isset($instances)) {
			$instances = array();
		}
		
		$signature = serialize($options);
		
		if (empty($instances[$signature])) {
			$instances[$signature] = new self($options);
		}
		return $instances[$signature];
	}
	
	public function setQuery($query)
	{
		$this->_sql = preg_replace('/#__/', $this->prefix, $query);
		return;
	}
	
	
	public function query($query = null)
	{
		if ($query) $this->setQuery($query);
		
		$this->_cursor = mysql_query($this->_sql, $this->db);
		
		if (! $this->_cursor)
		{
			return false;
		}
		else
		{
			return $this->_cursor;
		}
	}
	
	
	public function loadResult()
	{
		if (!($cur = $this->query())) {
			return null;
		}
		$ret = null;
		if ($row = mysql_fetch_row( $cur )) {
			$ret = $row[0];
		}
		mysql_free_result( $cur );
		return $ret;
	}
	
	
	function loadResultArray($numinarray = 0)
	{
		if (!($cur = $this->query())) {
			return null;
		}
		$array = array();
		while ($row = mysql_fetch_row( $cur )) {
			$array[] = $row[$numinarray];
		}
		mysql_free_result( $cur );
		return $array;
	}
	
	
	function loadAssoc()
	{
		if (!($cur = $this->query())) {
			return null;
		}
		$ret = null;
		if ($array = mysql_fetch_assoc( $cur )) {
			$ret = $array;
		}
		mysql_free_result( $cur );
		return $ret;
	}
	
	
	function loadAssocList( $key='' )
	{
		if (!($cur = $this->query())) {
			return null;
		}
		$array = array();
		while ($row = mysql_fetch_assoc( $cur )) {
			if ($key) {
				$array[$row[$key]] = $row;
			} else {
				$array[] = $row;
			}
		}
		mysql_free_result( $cur );
		return $array;
	}
	
	
	function loadObject()
	{
		if (!($cur = $this->query())) {
			return null;
		}
		$ret = null;
		if ($array = mysql_fetch_object( $cur )) {
			$ret = $array;
		}
		mysql_free_result( $cur );
		return $ret;
	}
	
	
	function loadObjectList($key = null)
	{
		if (!($cur = $this->query())) {
			return null;
		}
		$array = array();
		while ($row = mysql_fetch_object( $cur )) {
			if ($key) {
				$array[$row[$key]] = $row;
			} else {
				$array[] = $row;
			}
		}
		mysql_free_result( $cur );
		return $array;
	}
	
	
	function loadRow()
	{
		if (!($cur = $this->query())) {
			return null;
		}
		$ret = null;
		if ($row = mysql_fetch_row( $cur )) {
			$ret = $row;
		}
		mysql_free_result( $cur );
		return $ret;
	}
	
	
	function loadRowList( $key=null )
	{
		if (!($cur = $this->query())) {
			return null;
		}
		$array = array();
		while ($row = mysql_fetch_row( $cur )) {
			if ($key !== null) {
				$array[$row[$key]] = $row;
			} else {
				$array[] = $row;
			}
		}
		mysql_free_result( $cur );
		return $array;
	}
	
	
	function getAffectedRows()
	{
		return mysql_affected_rows( $this->db );
	}
	
	
	function getEscaped( $text, $extra = false )
	{
		$result = mysql_real_escape_string( $text, $this->db );
		if ($extra) {
			$result = addcslashes( $result, '%_' );
		}
		return $result;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_buildDbArray
	 * Purpose:		Used to build the database array if no instance exists
	 * 					and if jconfig is passed to class
	 * 
	 * As of:		version 1.5.3
	 * 
	 * Significant Revisions:
	 * 	none
	\* ------------------------------------------------------------ */
	private function _buildDbArray($jconfig)
	{
		$options 				= array();
		$options['host']		= $jconfig->host;
		$options['user']		= $jconfig->user;
		$options['password']	= $jconfig->password;
		$options['database']	= $jconfig->db;
		$options['prefix']		= $jconfig->dbprefix;
		
		return $options;
	}
	
	
	private function _getJConfig()
	{
		defined('JPATH_CONFIG') or define('JPATH_CONFIG', JPATH_CONFIGURATION);
		$jpath = JPATH_CONFIG.'/configuration.php';
		if (!is_readable($jpath)) return false;
		require_once ($jpath);
		$jconfig = new JConfig();
		return $jconfig;
	}
}