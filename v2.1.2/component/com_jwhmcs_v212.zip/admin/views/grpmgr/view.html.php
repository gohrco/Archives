<?php
/**
 * Group Management View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsViewGrpmgr
 * Extends:		JView
 * Purpose:		Used as the group management view
 * 
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsViewGrpmgr extends JView
{
	/* ------------------------------------------------------------ *\
	 * Method:		display
	 * Purpose:		Assembles the page for the application to send to
	 * 				the user
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function display($tpl = null)
	{
		$model	= & $this->getModel('grpmgr');
		$user	= & JFactory::getUser();
		$task	=   JRequest::getVar( 'task' );
		$data	=   $model->getData( $task );
		
		switch ($task):
		case 'add':
		case 'edit':
			$isNew		= ($data->id < 1);
			$text		= $isNew ? JText::_( 'JWHMCS_ADMIN_TITLE_GMADDN' ) : JText::_( 'JWHMCS_ADMIN_TITLE_GMEDIT' );
			
			JToolBarHelper::title(   JText::_( 'JWHMCS_ADMIN_TITLE_GRPMGR' ).': <small><small>[ ' . $text.' ]</small></small>', 'grpmgr.png' );
			JToolBarHelper::back();
			JToolBarHelper::save();
			
			if ($isNew)
				JToolBarHelper::cancel();
			else
				JToolBarHelper::cancel( 'cancel', 'Close' );
			
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
			
			$this->assignRef('data',	$data);
			break;
		case 'userlist':
			JToolBarHelper::title( JText::_( 'JWHMCS_ADMIN_TITLE_GRPMGR' ).': <small><small>[ ' . JText::_( 'JWHMCS_ADMIN_TITLE_GRPUSL' ).' ]</small></small>', 'grpmgr.png' );
			JToolBarHelper :: custom( 'display', 'grpmgr.png', 'grpmgr.png', JText::_( 'JWHMCS_ADMIN_BUTTON_GRPMGR' ), false, false );
			JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
			JToolBarHelper::divider();
			JToolBarHelper::addNewX( 'useradd', JText::_( 'JWHMCS_ADMIN_BUTTON_GRPADD' ) );
			JToolBarHelper::divider();
			JToolBarHelper::deleteList( 'JWHMCS_ADMIN_BUTTON_DELMSG', 'userremove', JText::_( 'JWHMCS_ADMIN_BUTTON_GRPDEL' ));
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
			
			$this->assign('groupid', $model->_id);
			break;
		case 'useradd':
			$text	= JText::_( 'JWHMCS_ADMIN_TITLE_GMADDU' );
			
			JToolBarHelper::title(   JText::_( 'JWHMCS_ADMIN_TITLE_GRPMGR' ).': <small><small>[ ' . $text.' ]</small></small>', 'grpmgr.png' );
			JToolBarHelper::back();
			JToolBarHelper::save( 'usersave', 'Save' );
			JToolBarHelper::cancel();
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
			$this->assignRef('data',	$data);
			break;
		default:
			JToolBarHelper::title( JText::_( 'JWHMCS_ADMIN_TITLE_GRPMGR' ), 'grpmgr.png' );
			JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
			JToolBarHelper :: custom( 'usrmgr', 'usrmgr.png', 'usrmgr.png', JText::_( 'JWHMCS_ADMIN_BUTTON_USRMGR' ), false, false );
			JToolBarHelper::divider();
			JToolBarHelper::addNewX();
			JToolBarHelper::editListX();
			JToolBarHelper::divider();
			JToolBarHelper::deleteList();
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
		endswitch;
		
		$this->assignRef('data', $data);
		parent::display($tpl);
	}
}