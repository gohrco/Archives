<?php
/**
 * WHMCS User Synchrization View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsViewCheck
 * Extends:		JView
 * Purpose:		Used as the Check Installation view
 * 
 * As of:		version 2.0.0
\* ------------------------------------------------------------ */
class JwhmcsViewCheck extends JView
{
	/* ------------------------------------------------------------ *\
	 * Method:		display
	 * Purpose:		Assembles the page for the application to send to
	 * 				the user
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function display($tpl = null)
	{
		$params = & JwhmcsParams::getInstance();
		$model	= & $this->getModel('check');
		$data	=   $model->getData();
		
		JToolBarHelper::title( 'Check Install', 'chinst.png' );
		JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
		JToolBarHelper::divider();
		JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
		
		JHTML::script('check.js', 'administrator/components/com_jwhmcs/js/', true);
		JHTML::stylesheet( 'install.css', 'administrator/components/com_jwhmcs/assets/' );
		
		$this->assignRef('data', $data);
		$this->assignRef('params', $params);
		parent::display($tpl);
	}
}