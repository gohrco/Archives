<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: uninstall.jwhmcs.php 131 2010-12-22 14:21:11Z steven_gohigher $
 * @since      2.0.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');	

function com_uninstall() {
	return true;
}

?>