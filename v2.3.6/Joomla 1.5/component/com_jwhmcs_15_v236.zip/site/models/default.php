<?php
/**
 * Default Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: default.php 169 2011-02-04 05:39:14Z steven_gohigher $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelDefault
 * Extends:		JwhmcsModel
 * Purpose:		Used as the default model for user management
 * 
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsModelDefault extends JwhmcsModel
{
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
	}
}