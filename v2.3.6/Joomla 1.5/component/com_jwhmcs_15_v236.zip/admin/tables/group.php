<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: group.php 169 2011-02-04 05:39:14Z steven_gohigher $
 * @since      1.5.1
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class TableGroup extends JTable
{
	var $id			= null;
	var $fname		= null;
	var	$lname		= null;
	var $cname		= null;
	var $email		= null;
	var $password	= null;

	function TableGroup(& $db) {
		parent::__construct('#__jwhmcs_group', 'id', $db);
	}
}