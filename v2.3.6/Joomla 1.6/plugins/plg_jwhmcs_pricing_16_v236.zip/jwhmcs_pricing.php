<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    Joomla! 1.6 Package
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.3.6 ( $Id: jwhmcs_pricing.php 247 2011-07-05 19:43:19Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      2.1.0
 * 
 * @desc		This plugin locates tags embedded in modules and content of a
 * 				site and replaces them with the appropriate pricing from WHMCS.
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
jimport('joomla.plugin.plugin');
$curlfile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jwhmcs'.DS.'classes'.DS.'class.curl.php';
if (is_readable($curlfile)) include_once($curlfile);

/**
 * System Pricing Plugin
 * @version		2.3.0
 *
 * @since 		2.21
 * @author		Steven
 */
class plgSystemJwhmcs_pricing extends JPlugin {

	/**
	 * Constructor
	 * @access	public
	 * @version	2.3.0
	 * @param	object		$subject - the object to observe
	 * @param 	array		$config - an array that holds the plugin configuration
	 * 
	 * @since 1.5
	 */
	public function __construct(& $subject, $config)
	{
		$this->params = new JObject( $config['params'] );
		parent::__construct($subject, $config);
	}
	
	
	/**
	 * Applies pricing to modules and content
	 * @access	public
	 * @version	2.3.0
	 * 
	 * @since	2.1.0
	 */
	public function onAfterRender()
	{
		$app = JFactory::getApplication();
		if ($app->isAdmin()) return;
		
		$body		= JResponse::getBody();
		$regex = '/{whmcs\s*\|(?<type>[^\|}]*)\|(?<id>[^\|}]*)\|(?:(?<currency>[^\|}]*)\|)?(?<freq>[^\|}]*)[^}]*}/i';
		
		// If we have this plugin disabled then remove any tags so they don't appear at all
		if (! $this->params->get( 'enabled', 1 ) ) {
			$body = preg_replace( $regex, '', $body );
			JResponse::setBody( $body );
			return true;
		}
		
		$finds = preg_match_all( $regex, $body, $matches, PREG_SET_ORDER );
		
		// In the event we don't find any and customer has strict reporting on get outta there
		if ( ( count( $matches ) == 0 ) OR ( $finds === false ) ) return true;
		
		foreach ( $matches as $match ) {
			$price	= '';
			$by = ( is_numeric( $match['id'] ) ? 'id' : 'name' );
			$price	= $this->_getPrice( array( 'type' => $match['type'], 'id' => $match['id'], 'freq' => $match['freq'], 'curr' => ((! $match['currency'] ) ? false : $match['currency'] ) ), $by );
			$body = str_replace( $match[0], $price, $body );
		}
		
		JResponse::setBody( $body );
	}
	
	
	/**
	 * Performs actual price retrieval
	 * @access	protected
	 * @version	2.3.0
	 * @param	array		$options - contains the found price point options 
	 * @param	string		$by - indicates how to search for the price id || name
	 * 
	 * @return	string containing the price retrieved from WHMCS
	 * @since	2.1.1
	 */
	protected function _getPrice( $options = array(), $by = 'id' )
	{
		static $prices = array();
		
		$serialized = serialize( $options );
		
		if (! isset( $prices[$serialized] ) ) {
			$jcurl	= JwhmcsCurl::getInstance( array( 'simple' => false, 'force' => true ) );
			$params	= $this->params;
			
			$type	= $this->_getType( strtolower( $options['type'] ) );
			$id		= $options['id'];
			$freq	= $this->_getFreq( strtolower( $options['freq'] ) );
			$curr	= strtoupper( $this->_getCurr( $options['curr'] ) );
			
			$jcurl->setAction('jwhmcsgetpricing', array("price" => "$type,$id,$freq,$curr", "by" => "$by" ));
			$whmcs	= $jcurl->loadResult();
			
			$price = null;
			if( $whmcs['result'] == 'success' ) {
				$price = ( $params->get( "showprefix", false ) ? $whmcs['prefix'] : "" ) . $whmcs['price'] . ( $params->get( "showsuffix", false ) ? " " . $whmcs['suffix'] : "" );
			}
			
			$prices[$serialized] = $price;
		}
		
		return $prices[$serialized];
	}
	
	
	/**
	 * Wrapper to ensure we retrieve the correct type of price
	 * @access	protected
	 * @version	2.3.0
	 * @param	string		$type - indicating which type to get
	 * 
	 * @return	string containing the matching table ref in WHMCS
	 * @since	2.1.1
	 */
	protected function _getType( $type )
	{
		switch( $type ):
		case 'product':
			return 'product';
		case 'addon':
			return 'addon';
		case 'config':
			return 'configoptions';
		case 'domainaddon':
			return 'domainaddon';
		case 'domainreg':
			return 'domainregister';
		case 'domaintrans':
			return 'domaintransfer';
		case 'domainrenew':
			return 'domainrenew';
		endswitch;
		
		// Just in case I miss one
		return $type;
	}
	
	
	/**
	 * Wrapper to ensure we retrieve the correct price point
	 * @access	protected
	 * @version 2.3.0
	 * @param 	string		$freq - string containing found price point
	 * 
	 * @return	string containing matching tbl ref in WHMCS
	 * @since	2.1.1
	 */
	protected function _getFreq( $freq )
	{
		switch( $freq ):
		case 'monsetup':
			return 'msetupfee';
		case 'qtrsetup':
			return 'qsetupfee';
		case 'semsetup':
			return 'ssetupfee';
		case 'annsetup':
			return 'asetupfee';
		case 'biasetup':
			return 'bsetupfee';
		case 'trisetup':
			return 'tsetupfee';
		case 'monprice':
			return 'monthly';
		case 'qtrprice':
			return 'quarterly';
		case 'semprice':
			return 'semiannually';
		case 'annprice':
			return 'annually';
		case 'biaprice':
			return 'biennially';
		case 'triprice':
			return 'triennially';
		endswitch;
		
		// Just in case they add one
		return $freq;
	}
	
	
	/**
	 * Wrapper to determine which currency to retrieve from WHMCS
	 * @access	protected
	 * @version	2.3.0
	 * @param 	string		$curr - currency type to get or false for default
	 * 
	 * @return	string containing the currency short code to retrieve
	 * @since	2.2.0
	 */
	protected function _getCurr( $curr )
	{
		return ( $curr === false ? $this->params->get( "defcurrency", "USD" ) : $curr );
	}
}