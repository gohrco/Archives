

UPDATE `tbladdonmodules` SET `value` = '2.0.5' WHERE `module` = 'intouch' AND `setting` = 'version'

