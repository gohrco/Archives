

UPDATE `tbladdonmodules` SET `value` = '2.0.4' WHERE `module` = 'intouch' AND `setting` = 'version'

