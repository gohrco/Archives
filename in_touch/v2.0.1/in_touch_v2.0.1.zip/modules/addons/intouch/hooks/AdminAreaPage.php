<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.0.1
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 February 1
 * version 2.0.1
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPygbrPlZZoxSxXD0k4JotsZm2XzZXOk6B/mUJGw36eGp5BdByfpTikx7ibx9aWGNt26NyH74
f/OUdOtnUQBY8YsljFJQy3FB9JlEJs6+NONh6Zw5Lz/CZ4S0s9B+QWhIHVBNbpXdB6wy/0F59WYV
XwVrRHvA55KnsG5VK/5z0vtzwCJXHSHoV3kERk3xIlNwdWtpQqqHhCwbtsANYPHe/bDxhjdIx0I/
UOAtwyZ0QCqVJrSfkzOtvaNhCoLQlZrSV6kQ7JvsUOsXQKckXJ39sT21re3GUMLMST6WL2yxp+8+
jIfDXg5b4LJlyMnwmw/GWF7fZuUnJSWN7hgxL/xSQ6obSAOszK/zAxgNZxwEgrYl6g46zJN8tHM1
r38WwcEE5rl0tFMQ1gG/l/W3HD/+OaSP5AlYvDXAf+kXYfZYHwjCQ91vdlXQiMuD42GlXXNgIhSj
0e4Am0Y/Cfnk473ja83NbfOWrB6NnPkVdvD+i0HCi3UIiq9LvsWc0foRkun00qSFtQfzs+ZjETjW
7wQiud9PJjoUsbSdNIXd4DRamPl5NjKB0j3gCNNEWQaLRS3b