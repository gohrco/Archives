<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.0.1
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 February 1
 * version 2.0.1
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPy+5udJnQTTxc3LtLzhZTVIFqYC13o916+T0eCKcpg7sQ4oiYiY8PNlswyWY3/dYaB39Pi13
/TqLKdlbwThUT+RxDa8sax7UgCup0PHk2T9MDdRLtg0epNY5ME8AOsOawl7yVvy9gg5WuFBCsAAT
5zvmrJtoH2MAOeBQkuqk8LF/yLa7SXzLs/uELEvIEQuCvwsKXQcsTpCKLeFpqzt7khvnArT453N9
cZQeyl6I/DPEz63XJoQ++K15wpCbMhuzN7nhcXq+TdcD3cpJUv42tY3XVNoGq8dFL7l/iiKSzc3X
O1M69CYGiCDqYJ6JsDsg35GMaRZR4g6pyRSs7iQ0Yt5cXLbf3B4Ow/8YpZIxodRdgOm+TFkhF+BR
jWeoOse4313yQwIsCifWdBJMTSAn0O7nwvifch0wM0LdJAtzxD2bX/fh6iljyMGi9dgFh0/jyZOR
o2VHJ2V+KmrwnaHLjLwNjEZl6t9HjaJkV11aBMcWaBb4ktL/8zKP6f2VWK1M20SF4w9rUvP8V3Vw
NgI1SRDl2kYU4zUFb1dXRp1g6LjwE0KRAFfRlc548KJUT7/wTsPktRS4sv0nouO/2b3Q8IHlsMdW
NTW9sEpc3ac7J1uvewbog78codQ80/zwQVroetlMFaBfkgWTj7PC6xS8mlnGOAw1x9XLQB/7BWFZ
1f9qsLelgtGLnGnICYvIWCcJiS0NHEOu8HC4KDS/FZXpeHYMZSiP5ijiUCjChDj7q1zFgJrXaT0N
jcIso9l+P2aMZropzEpNO2j0LnYvSTY0qfhBy0BRdXhVA8UNPYaOzXwjz0wUYLqD4EkBYk7/emJ4
Jb/5DjKI4J+aJiE8VAr1XvWzpCwxHq+3422EvtEE/pFc7sFYZElXiZtsF+rj15w8y9tcK0H0JZls
LwVgyZzXdruCOZHtGTY70M7KLs4TWBSdNAwFAYkLhvpHmA7VPbE+piv2shytWeVp1ZO1NHkxr0i6
lUaiI459ICHSxGThhOvsgsX3C4BTu/gUN68lzvrdKBc58eITgFkSoeY7oSynhnZR4XNkHC7skrij
r+qxStTpawnqs0qcwZiEWY0ot7qTyyA6zPIe3PcAnwCnBRZ0