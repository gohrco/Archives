<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.1.0
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 October 19
 * version 2.1.0
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPxahOs1O2bX8CPZsGo3zwz5LL72Y+BzhjfMiJ1okxp9WYqcipBIYS7sEJlbTOu0IpXn5qYii
KLLY0ysX0ae2WrPs7FXs4BFxQ5ZtjSxG8L3RATKk3ktnV+nx8GVXe3gT9aLQ7jwwFjzvgd+g+5Dy
f0Uox+hj9jUiR5Ll6O+dHAknYx7i3zxVlNmw/3HsMqP5i4X24flPd0aFeKehj0C35f/f8/d9nJ1z
7dWfjXFhkkWjPbwyuNvAKPKcLA76TW5QkECLtK9jHeTWsyPgIAy7PinzHDPZZvWi1FFlmjYC6nht
Ogrp7FuWobDH9UcPPcdKsjnKU0yVWki8KUiVM0yk5LckQkV+7jffsxvDiVXaOGuLAp4ivuu0gMfk
64Lt7DR3MWmhAgFpmgJW03Gh9qEf3sMJctM/IE6ZRw3XkG8+CBxH2wjKROP5iz72j2tKzWie9ENT
OgzPcHuGecXjFJFEmpiI+fF2Nchmz6RvHz8RD1rzwAfKksvGRvyNaZ6gRggATHabAmoTV1hnc65g
GJiGZ7PY4FTbJZ2R7hyQBuD5V0tmP0/z7veURimQdD7tr8rM8CvyPe86RWosvdzq6fz6ihk/hgZz
cxFiN2j70aCaGQsF/1iYf5QRUPfYAmB/ut5QVixZ2Z/4EJMdmgzqj9AKFrnD+U5gaM7wRtgUYeuw
R/x+4+sqdOJsy/bNaNsQAZv6LSQJ9NEL/4Rw6qxZRoommKbLrWs7BF1JzJuKd6NB8z0kIXp1LTe1
VztBaO0xeL5IfM789/X/suXDdtkqybvioERko6xQOrhZa0BmcMgqDx5P3bqpTRVSjLcWx8+C/9Ys
/kg687d18wv8gP3qvAlPjttQic40S19Ju6Veu6qNQmSxdefZI9Ae4cieiUdtAIynND7tn24OS4JD
paZqpNE1+lVDtlKa9cdX0UJ4I+soAhNy83bZKIMfiX2uskWIIr00q+2doYduybnw/XmVKj7Xcy59
0W+W18E3+MxNiJYdOebbe+be2Bx4luQexkVOr4NlZ0VwmOis9Pp6CI6e39NPXSHIH0iI6b0AXEYB
/wqdVS1rP8axKgpxNEwVnfQtwn/jj06BmPvrK5tLYCZjwapAfAp9I4lxkIrJlp0ckwxdLZDJBzw4
6IKFlkTorzs0mHFfBbmLo0KPekGe5uJF3dj15dWI51V5O5IQ+kcSIv2gkDMPatrGDKsrhNo61m0M
gVQe1PZlw7TDhaSuL8/VlnNMDrujzYckGG/8VSY5Lj/SQhmGMLGXBFa64t+5yPBRCupWXSULLZfR
5/neSr8/eSDzs35eU9JLWsk66fEF/2dI2Pd36ZaNLytWn2a93bnGZNc9h5Tcxl1NzbXdYN0+GHXg
W1v++jDH9XmlxFunNtVoi78GxFimkB9zAIlARVBYIaYjHkDmdli/vL9tandc0CZLfTb617smVv3w
Pxw5Xo6Fdcf5hddlOhvt8j8HOH/0S9P/J6ccaZbmod/5WthLCXtBJnNR6ai9pTT1Xc7wrS/JMJVj
LueDwVkcHrYs06F4KjSuobcYRNHqnTc4XrCGYN1B3Qp7vtHPvV3Gq76jrud/A3xop4PWGdOiyKOd
aPUlxw3bkZJkdv5q6LTUjx2T5zJWSaKZFwKBW/HSypGzVVydW04jkfuXsJrCIO7rzatvuNY3kkIj
C1dzzL69ex6FCLjxE4d+MCXI4G5meOcpdgVKqokeky/RxCXX26xPRyOQR8mTyYo1hA1pFcQS17uZ
bxpReOGjo5M4Ly21qllsVGsgfWYRA2C7ihce/1X5tdaSQ4CN7TDZU24U0Zr0103YpVXugu5joMAi
fd0ifFp+k+91optuLDB7OHFhEbvt2bCwkJg6LaHq6Is9QiVz1JRVp6ysiV3nLs9QMPMiUVCBcB/b
aTUU0Q1xGTWqAFevcMSoPi5SVtuqqodaFKaDPKect8KZCjmqu8ZTISjMSxb1QtwGmMYV8ATMt8++
ToXKoFvHYUgnNHmAr2SRO6haGwzMiJd5ZTj8Zb8RrLolN2dCGhgG1OM9Cr4JhEb+VDQxEb5ugIsG
UmvGCTPDwxAicfrS