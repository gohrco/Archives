<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.1.0
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 October 19
 * version 2.1.0
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPywc14OnY/rfs1UHPIHI73OT++Hos7rQBeIiNq9OxgGvKwdq3he1x+V3ri7iyHMv7eBgXi58
XvLDCIGz62EFK2tYdB0I6IZsaVgTlbAKEDTD3GC/kP+Ep2DlptecLz+5FRViavx3m4WFnoudXM15
3/1SKFZeLS83OURvWY6Nd8iwVoXrFbuIPJ+PfhZjY0Ptz2EI+yFj1ZWtuBO/TVS7ksLqvvrky4AQ
tTYu9jM9r/sMtBc5EwB9KPKcLA76TW5QkECLtK9jHiXZLVclIVGx2Tm6qjORgvXjIzG5lfonGM7Z
KTgYV3IlROp4acKmSLOhYZDwXlbKcLSEDYqu5Z4b997H49Hh/EfW9peqIfLS+ofREPdPwFPA5bpm
Faah/stFFzrdqOqPHxEJ7Dg2LWz9eT0x12Ha5lrXRZzLZwozyasTem0ToJ1XwyyMyZu0ILtQB5EY
sZMF98zAZCzKzX/mv/UcCqmIRWPuUJNR70KA1BfZK9+mzjYV6uHY+zz/lYkzxBSLNXeUzBK1XabY
tQcBfVgePum1Ne+XAjN5LzvfzrzA8kbb87B7e57i7iJnsnu5mCOFMqIge1heUOUpowyClO1Q4Xpc
ugB8iBUL/wpHqIups+xdaxlHvNQ/hbgCA+R2/tAn3jNYJzY/ry1CII0HCW3xjdqa9Z0G55r2q2cj
6SUGQ7N/At/h3sdh/OBxNxfEfiwCOCgxh5HSeRLXictlkcWr1wEIb8NBrWaxK/xJE3+3vgBi+Esy
9Ey77tB6nADciK6Ph7B1Xs6HLAGSBKDCZ2ZgYv7eem2/7SIXsmKGU1sOBdZDlHgk61QQfJToPwO/
becfaGPQVQ3MmM9X2lDGBZuQ13ZX6DL0i310qJF1DwtaAumVIlq0dLcD5nVbXZGb5bXknhcT7uPb
Ea6E2oA/SN5Lo3z9EDrhV3QKsvuXKzTuQEtCAbHLDbzd44EWyIHbnoo68VVjeLR4Xo4XsvLFEV/W
1d5NX/7RWlHR80jnDzLWYQW7Wdm5Wg2KWRfdMzf4cPaA6htgMrH3d1MZB5F/IMYlpksPKNRHWUrD
i6Ue1ZSI+kjlP0JhNFdregm7GDGg3Kx8YBCbPTYgqPaYMwH/QA/F72Ve0OQRqI0PlewGzyoQ7aR5
lGjl25wy5t/Bz924IchsRNdkOef3iO0B9usFUWD1HOXmEtTXtat4ecI/Z/O0l/uaB/ymsLP0tzOu
jy9u/fOLqalWZaD+ZQMkY6LsiuUWAAY4A7bQ//0bBSTeMB++mXvgDxMCYEvToCL9yNn24x8zbRFT
+ZD+Enweue3uEK6Vl9ADCgv/O2JsRBAL4e0jTD+Ez12YT6T3t1iMFiFqHxahfJNQvgWfwbovSmIP
sjZSIzh4lTryH/Pn3ataipNOqMJcB7iTy4GRS+dzutg02oCsO1BVM7g3B080JbyJ2YVZASGuwu9R
xpusDrXfvMGbYmVdEBW0ng6FTCCBd/sKWVAG/gpWpNj+7sTXxdrAofG4NLdtburHps6aZnYQrzNW
leyEBHCkprAgDimeHW==