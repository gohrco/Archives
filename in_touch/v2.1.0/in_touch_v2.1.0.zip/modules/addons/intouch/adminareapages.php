<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.1.0
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 October 19
 * version 2.1.0
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPnMXkpA9AW05G7Sk4OYdWqnFP5D0FYRssB2iS4ewNcEFfmKATWaULkpcA2VXFsJV2Uy254Ug
8TYPwWEriPpGvgjmRVxFXgfiHC9vndW4rYtlN0lxhrDF/xKTFexPIXraDn8gSXnM5PttGvGWP3SD
ql/UfaUV0mEYLGYHz/+O0nhAg0DBc335tO6K6oPI6NwHYjau+BjpeNHqBs5LPNnqhZrjO7jS9I2o
vK4f3LDyPOOp5lJednfOKPKcLA76TW5QkECLtK9jHlXNa+k7TNxRW9sfibunGveohPSPQjzpNQc1
VqKL/4Rx3mhyZxtS1ROiyVR+UtxzWexPy7T2U0XYXVh0aPF+jqC45iGTQt+tB5bLf4sNadbO7QGa
GRC6Ub4Rnuj5kpCPIABGZFk98eUwNkIcvBM4fcooGuj4rzNGd6Ve/B6PTQAFsE7lTvRVvcXwItxQ
KfG6yrdQjke56/sb3M1AoyyzjAdmMHyU+0gTNCspsqC0vlM0y+baj+C7C9nnlI49IatCalWiKUfP
A8WQXAq+G1uriwr4GW1HqW/Zbe+OPuWBWa7cn+15nwPN/ROU7jFvBRbCYq2XJTytSh+41tgShaci
xor27RYYq7aD1JrJyt90kgMGBnR0UaiGOwpIibdOGkvzeZSkR3PjU8ijERMgFzvOp5pi9qlZodN1
b0IZ8tv6w005ZBRpbYakk4eJ5qjnJJ0xq7OOhDvTHOukI2j0x72El4csCslDag3U1fAHBGAzfm69
KSsktH30LY0mhbC1jgRY3dIUQ4CqDSOjxjYOo3iagHt9bZD/Vdxkqi/5ZjARj/6tv/IC4Y3AilDu
k4jOBiauYz05dI4cVtMchrMA+pQu7bKpimZ9DOdllS7nQrnAAUvY63BdNxT5nbd34sAKcP3AcO8R
CKJwGk8gqRuGDvB5c/nZ6eB7stko9c4MorWHdrCMnX8jwVU32lIVq/UiAC1vJAu76W6R2si66YU/
IggtBmUpQrVpYLOZZsq3c6j5u9Zwd0guzBP8dG2HvAlmDEen/Cnlhs9ue9jy/5M8GOFyxUoSmeUD
5PFTeDJ2YVT32/UD3TBRyAVx9nz5m4+fQM1yDxDbf+0sFMvazj7EJmjVWQljSklnECkYOg72XNPy
cBefIkK7wbBV0xKLuStGRowV9M2P3spjDbsXmK3ecis11xZkVNsf1RfgCN5k37wGnxlGwvHCWuPu
2CE5Yi4OCUmccDuiLP0NPnYFMqCIHSN68gFqljgW63rOFLSOqqKxZVYi/2oTFMs16LiApr+k3phm
a6WfAD7UtrK5Cl4flBvjBFHmZi+XfoxkXpQ7z7lD05wBqWw8TIPJJEPrCSRXL09UtN8J7d8I1U8k
zcsvMthJGKMhDpTEjZOz0OHAAhiQo8vs/QX9Yc/00Q9a6qMLs6LwGw/7GWMfjVnbqf+EHgv9x59P
O7eqyS9baZyQVY1nAHBmDHKVN0TOVCbnh62TfYkOY0I9qQ2ehtQQr9iniMV2IfvzbnODni67vB1/
0t46a6NSEl3dTYEih3NsY1sBXoCub+r9BCYVgeC6zTT8YCEaC5ewFrABGUcpUqs5f6jIhS1ppSr0
SWdg/+vExhAhgLbOdEr0uMDnJkrgW7GlqYHScS8hXJ+giC0lY2ETL1/ou6GD7nEHVvZoDpQMkSAA
Glq8G0m8NfR5DRhOzrC+nMtkKm7/ZNBYlKYHVUIPSNxzBYZhOAvKulT6zFfTDmD+IMHMO4xgWI+N
HMa2pu1u6+dEvuUfxlhqsUfHeKiJZgk8ZE1QXCK0HypZNfvh65zmHQoMW+F66G9HXh4EmdfmPUE3
UjeIRAHIIWnngQvGSi/BquCmyzxJWD02/RavsRdBTleXQFSjTYSX8j5d/RwKXQthJa8xEneGpCjc
Ef3/QR0Kww5CNHK7GNXezEshr2fDYixRm0a/BwCoW0AAiyXH2Jve9dZeoCqwmzcN3vGv+Gq1MWoJ
FGPFacOvzscPQZMcWTLb+36ji/Y194YE1m7jc2G6miZqlu85vPNk5ZR/gRz7vW+8MHAVte6BrxPf
zNMKvPz+lFfVRgYP46FirARzNDum+YBHJcaIUSctwlZlxsqQ9qpNXYrndmjdd9i7ZTQdNCdHdjbN
D2ZZNc0h3X25PM8N+WoVWxuYZoHYN9Pn+5XdzORtYJU5YxEG+bfgW0VgEgbUVE/YiHiwhzRjXLk5
TKeKLkRA7C/UFfFt6g5f4qnUDaUnd6iI41hLl2pDTXvyGJPfzhjV64/CE5Gm43C+hHvoKmo3daE9
tv5zcEHQzA1D87K/fRYFtKjztw2Mt2vhKDcbWz3y6ETQhEBTix0SbZuHRr1YCCERu9hp34vojWKi
IL7qV6P77IO2HxohbcWFkrsLtJT+GAnZ/mbZ4ZZHk+I77a0GtIxak93xmsuPJXxhg/9vW9ysTlLR
mKz7ptV1gZQuVZgUf2a7+2kjqWhX7DOoXNmZHf+N8rTN5RRFfJl3a4RP/uCeex1hZcIt9dANPX/V
O93Dmx9ug7ycoTHcyVVCsu/SccEmrHv3viRO/uvoMuAI232AlymkKEsD4NeS4Wmq6qRvJHbIpMlg
67qrmkCaqZSoiBDAPXnzsJe0RY4ma/om62oWw7kc5ObCsyV7+4al8Z50g2sox+c5E/+i7Plq4ciF
sW4IADkRKdAhOMOa/lgTnn+8A6tuXB8XeleV7TjF+EXWsjfegr5F4H6IEu3Dj/WE8Pgajbx/70n6
rk1lPyemvmwIkneWZWLcKQblyVHmi1nZRgFabV7Xe5Pd1mpF185vaOi84yi5A8V6ceePzX0oly1L
HnJp6RTD9dxTaktJaXpV7qZVwubmNEG6Xf+jGboqdgi+cVAxMZRsnSow6tSaO87DBXjt8IuRpCno
K9xlvjoLfljtMb4MGAlQtMaBnr8UYztx3hud1JhtJR+ntVxZ/gN8BuFiTc9hWpsjEGcrEM3RjvYm
iZN7xwUvCUt9H7m9n5kfvcSKFm/bIlS0PgR/WPHSFsRPGq5y83YmgMjgdDb9aIFJnbhYolqqWBs6
lAZYAAgvZOkP+V7p4bVMEo2y/G5L863MJV+o5WZOguErTyO3kR0IZISQvLxpj4F5/uZB6tCwai+m
Knme4wSl1HZmOzGZnPWgE577ynBudnMD5PT+mAbsn2bDRgOlHE2TuN7J3ma5i1h5khrkPt8/A8EW
7WwnXXKKlKfJzpJSZM2yRPCRaXMdrrPgcUm472cj7RKiDy8SkMo+ab61AKCP7xvWFj/ZIo48SXfk
yMjQ6HJ0FyA1QQdIahwVW0VDH7awE+igZI43A0f6+shKqYFR0qq6O9a38H9jgENFPYRFRj2FbOf3
+RqdQxhExGBZHY2NFSip++a6UTJ6UiCqAJ6sMMer1bg/nsBdQVdl2eatrAwq4nJV/1rHj75EN0B3
eU4cuZ/S1unftCP+1Ug43KyaqhXixBQkRLT2qLpQj5TQA8LzYeTVWJt/WlmFGzdbymRfbrGmkm7B
64yrgAtzpCY+bcSVRZ0d8Lsl9X3EBluIyHQ9TbLfhAZ4Zl5Z1Yny/xuq7eEoMfi+crZMLZ2ZFIA/
o4qYZboNWlVNgTFHYs9lf8zbvONLCRiLut+6i7ddFIqjj/YOpyDs0kQqXIPjQFkJ5Bhs2WYp2Q42
GnYFEaXw9v7jdRPjzqHNo5MO0lj0mItfUbm2jSmHf1Shqb26Jghp5FnRZfS8NP/jNY+JD6S2kXbH
JRx1CayWpP3lQJ76d2U+PRsZZpjdhjwVJWK3C9/b7t87mket9a3X/99EVlTVeJfGpOrefWMa2OJ/
G3La0/s/WAivYRLasDAjeLWpZSidgQH8UsxbaL7YoRjerj+k2kX+jaLg3k2NG+8zgm7ESpFvtwgZ
W5hCV9sdyMvZ4BXOP5BsDOFNanJg72xdcVASeOzKYWPL6GZi5SleeyMz48rKMlbpyakBj+6o7/d7
Olxmatl5L3b01ocEgfjY8KDLrzkeN/G5GKIU5pOSKVaX+m8dWIWfXe97VN0obNPVUG76eAeg/Dh5
TSsodITzLJ8XHjeSiX9PF+9KTLHKA24KHkxYl9oETLEzsiAqYmlvQyX8mNsx8KBg24AQJDHSXCq/
8SQtDdjs6/+5RUMPbU5VnGX8cIIh+mEt73V1hYBiuHMh/5BwozXtoj4P5DQiunCTZ9kD29pANWHn
hrJoCUmuN9rsLOeTTmkY1KV0aRlH4NnAe5VfJLJzftcVHTPXtgtCBQOnX9uVgrgrXFPbrQQ+FgN8
W4oJLX9BWUu7sFe0CCrIaCw6GLDSLCywiUi6gGwiTJ+SHUNNPwm6iz+HwJCc7/uGeqm/GLwcCeHb
RyGao6tGvjlYxDdGtyEtCbpQgNe3S1a/fqKOLV2T0hv97XlGvFIbbSowoBio2RdlKkTrLmD4iDgn
GNQPN+S7tZkpTUh50OKaYchpnQg+T/TCV3R4Q2UordTWjcfO/tRPXk0g7XgzWMrHGMnFAdzkE5P7
tpZhN3wPcRNg8Dlabr+m7ZrFYW4NfA/WMTzn1CV4+0PRm7/QkY2v/nKEgdSB2hrZ6wYPy7TxRhwf
wmJYYRN0eROi1TkUKDssyfo5D6cwEfJqgTKLXfXFtWffShSGhfa8RaEq8+k5y/l169bBU9zXkNVw
ukTiFN+4RYnP5Zr9bgt+8v2hnPw7JEjMdIdJw2BMN3CNpD4E2slheTBbY0A2jx/SsVk/qtW8NGvO
cqXSY/gUR+lCfMJPWkkO6iekuWuPT+IG9jvSebqd5ddaqlVoKQb/urldMlVT361wXj4F09cgS3h/
ICv47Kl39d9DyxJGotE5KziHAhzOTw+C/jbc8gCnT5mbFf98gFuXvU4wTGbPJe4YnkrCg+tjuQkG
fpAG8AwiWFfFqeETm/YtUmf+Vwnq0kWP/E7gHxkIicI81j1RPzBC98rHZweBLum+rULfQ45019bm
7eNfhMAIDz5IM+FtRieYUyMmtyUwgs0zK/25wBA/FJ32ul2Cfc9CdL/S1XU3AJ231+bn2EaoP3+W
LewiSS5V7gl0dVFS5Bz+DjtQ7zGxv9bx/ljvBVAS/3JGiFgYjfwqH3HEuZOgxVCl5sfT2bTvveHJ
VIWEq+PsALJIUidiuN3W2FDciaBFlEWJjQ/S3L9jsB6yxCBvZanojeSLLv8oShhTtBcgtn9xAZzO
D5cdc+zDTTF+V8l1K6HByVswk19HH5fzcc8TQO92jE2cwRq3eblOnYiAX+6XEi1zbILCanQo9xbo
R14lt6jrmMIoOrcOG4Do5H1i0CQP2QYPRzK2pwIaI0XetfITzS3NxLPsvhPBIFdNCXFYQraxUVr2
ob9xE/KUuoedqyk6KjX89FzCcfVlCWmabpTzkljowYN6xp2Ii1zV/neA6lGe1g9t6Kty+lsWVdrj
o4t5j/2gPjalkm9OZXw7xcZ/gZ/UjQhpzvQgHX/eqKehd+Ik+SjV3Zhr9XjOKJCOWsKV/wLEEMVB
Od6DRbnLwJZlGX6ZX4QOtN3qf4Ty9WGOd8oTCl5NGDIh45b9SzKBiXf0XbE+DAi999zQ+swTWTT1
Y7+Ld2nU1jEM2IQPyPw18j6w1uXwGl+4xa0naTHNRwAZQ8kPMs6uUzvdCgM3rqPFcMykAs++LSRm
d6t0mM79X3IeR0qOap1janeW2Vjdawn/yt26Hh7WCZKNrCpjowGoy/Kq05j+QONeizfd20CPQvA2
fxzEfhbT30AROBibehaKGvHOqCMOBoopUsGGOZIin+f1V7Itg7Cx9s1tlunRjmHAbhju6s1Rdrnu
yNnQWkeKN4gny9c4G/bNUjGJZ0Js8MRZ5XTJVY1c2CaaNj9lKlKQrJ6Pc2iQpJSTMaaQe426ud7/
ITlyA6W70Zzork3oHvoZGmYt6Kx9+Cj8TI0cfd8uJxULk1Xoy+cpVFBc9LueA0JwBSOVxJwaeGYH
yhM6xkLzUHqX5eIUUW8VpO4LldZMqupsTANG2auYgl94KPX79nFsBpeehqfrIKJxrFxadruxWLBj
HT7QYY081vOmBDHKxpFqkDOE1C2AB0FyOwjEwBFk8CgPwcQaxFB4BMalGSlMwVK12RxBxXdoTywE
kawIExhVtIcsAI0E/PbUOnhn7F2RTejFsU44elYMkoaAudDJZQW3RdQn87VIALMx1ALIo2sR16he
Ac/tVwBgVi+zPrBNrwFjFj6sJ+JaX/AteQhsUsr0rH1RtEYQDc0hrQHw8iykyuq6JS94U3W7auuw
UXDMyEms7THWf7XFhmOQx99bhEHhEkMTyx7XD7PszxDPDrcKknYmNGl+eUaLKbXT1qXK8FIeu51R
rUXB/+wbwDUESCDQj30wS7TdRmBdwzXcc/afVim33Ou6RhAIFqXcsUmge1AY+XAoqtFEkDK/w+2S
T87OkIT9+CZoeHDAbp3l8jCCVRSHCKSjGY1qCeAyGilE8qKwQUyWs5yR8h7ch07LDA/xkkY1ioaD
IhP+A8Vtz0I04eaifFQDLRLE3tnAH+09pE1lTiEc+GptrlGlzqdlceaFCH8XNfRzbmKfN8snblMA
J9YHGyfqR4+mpfMq9iefQ1kRV5bf5n3ttDZb5mQpRgdkofcH7fztcTwTTNrPZDMR46N6nLyhe1B4
uQ4bCkg8LJAD+FJ0EHJP/WnDW0NHyAhj15XyzcbB30f55lbyfF/cmvCjCJVQRIqtwOSFy3IUgLcM
ivIh99AnlYfNnvENFRtRhHBa0hyEqQvakK7kHgQP9gKHP6v0stOdWbSkOka3QH+w+k5N/pW38xjP
8Qt3JyvFUOXOy+mLNQ21chF95pOtSbNS0sl6H235IfE/tYcQKzKuzp+L+j09xYEtJrttECaO2Ylf
9v9Oj+c+zk/ysgbpq/0j+Oo2TPBw7MXEI8yh38ntAO0ISdDRP21jkurnHW1c+XVF8qwI7zb1xUXj
RJ7Mz6iUFS5b5iCC5y/N+EWO4HH7k/RzKVImrTDje0L6naVvR5DdFzNrpv1j74pgM2Hbg7x2VacV
6tXjiMJivZkjDYbdIVFCrs2cSJtsRBTOi+cIm3v7QRZM/e3OGaKoe/xxjFtX9ls8Y0ZXmGtGhew+
ilt/z5hXm4CKuKvxMSB2FYjw3v2L2g0ZODfIj18kjAEeRSwLwVwmkMTykIBGgpuGBkg2NpjBeXe2
AthktPcevEv0TTaBurUzQwgPJ1m/AxgY9Kcr8uCdbzXi4nxvtD1v67Nv9+6lVhwKPeddS201YFuz
cmfd/97oGEhazj0vgHWB1FyRnXHQb797XoFkNTU2HzguJQ09Ab3gSUpi/xCVTgwMoFzhjDhkMIP6
k8/DTqzVRsNW8nrs9jOxdf0mgPVDLYaiDs9wMfZBySGtFu3b4sHbCqA6fGtH+kWaZDfBAgh2jAun
7U1KO7tF+1t4N8gBRX/YpIhOGDQTlinz/Z/RrrJohEPxDY3Lbby/5Dw6P2U485SxN2DyQjj9o/7N
FmTbCfAshxT7jHIwUtr4xG2erZT76d4xSjBPqJ1EwEwAymXyOXqZAySR3IoRoTU4bRnp0RPmpal9
8pY3VJAsaP+N0LCpiaWM27Qj9Zr4HeDz7+V3WXD/5+2cKHVeqKw8MdHKo2vZsN1uNzfC0XZBYXqo
Q0xfHepNTu2hDpqV91dakKfYDd4p2g3jpcfCFf2jo9rP3OX/KlR5Yjg4ZQcYhDxQGLfMHHg7nqes
Yx5aG1J1lEAfK5zhXzqOjpCBjDelbtN46lc7PPrQc1f0QdaMUDri+Teg7sHkVwV/0w/uD4EiBFS0
M5TQshxy0Rgk18JoE7IrfMF+gjK1AA1z+sanL1Bqz3cTgyO10YjrZSa+ndXp42POo+P+DQiGaLpC
uz1iH+lIrJ/j9PNhb1KljoTLgCRsrTpe0zWzzYB031c0kho3Dt4btRAKCd7EGvsO7kw8jkner5Ah
FMTQvQvrCRWFC45wBoEcrhnpXWEA2NAYBP/HsrGfzVE7hZ2xyMsGnOMOj8zmIoO/U0kDZrKO9znF
BZvbJVrpDubCqnsDOjIqARZH5VAX3mkDNLHfs3lZ4rO6nwHY2jMimv+Vwujj6xqaqJe908CYHMSK
e3kVs1zV3xlUJsPQ5Ot0ATe2hOpsQwWPMi7T2ToiPDo3kgWfCMWZE6ENw34+Wm0P6z2h6yGoh525
UpACRHgX8F08W7cJNyEfwWFIbfauCoA6c3bg2tlxwPrVZoxe2mC3WWlygFHD3vviJ3xJBj33XYQa
asfnDRqXs98F8hgp+pCS3D0Q6Obgtjq67EkKTVjgG9RXH9kz1tMgbCEUPwdDpkra7Sq6zwQnvGcl
2nMrrL+mTQF4PUhewHfUI7ArCcJzl3IBYLRf1KnGqFqU9OEcxMiKHNDpKC5n57Qn3YN1SpReSjD3
fjIkL9lx1BZ0tqOsCTZoCBIYrc+456UPqiEZeMgJerwu05FeFyL0/TGZGLlEamedBf3QQPiBn87S
StILxKTZzcMYG9ZP2RXwsNQ55EdRQ7HbHlRnHyo1ddRuGzfHdcuVVDFXpt5ZvfW9Vb0WK19to3l2
Q21UfE5rKIiztggQqd48RfidxEZ+AEok8D7OIyArZ1/u0AlfjHDTXiLoEIoVp4RliQJcQHRF9C56
+cfUzwE2JlBLEkk+nIfgRSACaaoex70mb1zCeh0mxXnVBBceDM/laRgVTfwxVfejxIuuQ26qdU/j
IuGiy4uKEOdKwVpULNvVAsegtVKFdmeWVgjGr0k0DPKJGJteYmkyJkq+jYkPUt+FLXO3XSrIhsKk
y8w+yrEyGO+cVCkeUVHM+Sm+PhMMmJB08Ip/DpvRwhpsWR3B49+fbUaeozE/8+YfLNe8zj5pCqg8
aL2iTe13dUiP2xApTXxwaoUOICbN72m0qphtXFqDfe3RYSa4be2xEbCGbyATOL7ECaVwpSKdkOEl
6HoswNbgHCqW69e4nwKKQk9WW8zM4nRat6KxzxF/Iv9h5SbbuzjtUSRsZCqsXt9km96YkOG26awD
mg+YraiW6prxLn3JE57W/Iq86j/G6V6JlR40MC3G7JStgIpuBNdH0DrKu7fn8uba3N63v7SrPLcY
sW3PsGJmL79GM5Itv+cOcv7dKlc9gPlqu9zyEN7cTKuhL8Y/X5f4QcxAzeMse3g3R9pdNhu01R0n
2xWS/RyGfsP3vdsMfv6NqzjXvRfI5tIZzqtpdazqRyYFIEVBpqMjEgXhyGGVQ9n0qznbOX5yotj2
OUET86c1bZy5NxG/NXHhmOgJQfRThhY/+lcUI47uXim93CRlxtuObWFDUbPTk+LgHQoP8P0d32lZ
8V4+s3hx491Bip5u6FndR1kjP1pcWWNxzOt32F29TsLwfpHGDRTWmemAVUAHxp3lnGcyHsffac+V
mcSSAk6r6t6KOuAbNCwaqTJ74wXLNUaJH79NERZlWPRQMIqTXGg93U3sT3sGjtfc5UTgNw/5iszm
E/cF/hD8AJd2OdHq0IAnLQFIKwNI8wKG/CuYgMLAWctGhP/i5p+FxD8N/zbJKLXSTUaoeVD2Id3k
HC5XOw+rlope2vI7/Jg5XVQYpmbgJKtrTYyrmqngTrI/GksWNnmpS2Ft0/i/vZa/u1xsA8y5rD13
cL7dmg1h5w46Yq6DzMWbvVlU1d6/+iU8J1PqkZXK6eHv/P4QYF5DdI9NdKiz7Ex7kclGpMotCJ1F
7avpndK4YApILwW0E+AtYyX//mvgxuCDy28i/NNhJXYnIjZLlcFUcEGBuy/dKlLRaf4BuRdfmGwH
CFmcDTxlgI3P4KjDMIc+ACkHymJviGhJXJFvnwgRpbmNyNtpwHRKNI8VuEItb0++BlRfkRR0Biri
iJYGJ9ALTMhSnta1Chief3qx/d5+2HFSQMKbuhruHe3AgDfIq7Kk5ft/YsEef2PdTdf7lxPk+iIx
rDK0Ip5XufvA73uioZGwNEIERPD8RWhRgxAjdtE5V/TbBBkQ85nIIZwEkUFvR/AaoVH4EMipreQF
7XG46qHJ2DN+6r3tpflv3ML/BJR/0dg04Pf3b/LlL5PgJ+LZQ005MTGSxb9MSp7/YaSi9RjBfOhh
CgjnpC/Qmce5xENbv5LlFtpVoDtgVCcVnZ0DgUwpaSTW+Mk73CzkdJMb2ltjd8VEiXSYzM/k98oZ
gD7PZnrvfJbQhgRmBaln5ZigY8vmLkF4NaET32fai6emsYdP1m5uwGKbSULcDh6PISVy8ZvBm+nr
fPZlR3XOkvN47vVM6V5pGJLAZsi8ZZFoEwKz/niu3Ec3OzW3e9XytmrAE932JqmGGhZkBH/iHP1W
XMgsVRUgHHPbUn00XGELd+nsdplKOLFUhIilUHAdiw4pcGG8Qh4umel8Q30N/vvTFaUCazYp4oSI
bLe3c1QYinzm3jGxWgq/kzn/40u/dufA7KlFz0Na1vK/S93L5F0pbCe63h67TlY46E69zlN4J7dZ
+JSSRxD4RrmHjxR4K8G64aicoNPEQ8lHU2EBtH7tQlswgMqiQ5ETApI0vxIzmmYkVNHVG7XODG3t
qDKMCYNICZh8h1iGY20cKKUzEcWwmv1ElD0uv7EQ9p/8aDJnN9GRBOmO1a/Q1dP9HDm7SKvI+mQs
wdRB2hNzAdX96fXppgqCcbAA55JiZiBw2LEWcAE95kpZdceX2TI8qBTS/XWe+IDcb7qQH3Im1LWI
+jiXj7yHnNBTjUyJOko6v5gA8ncwpepoVDCMs9FAvRaOA3Ll/dhR+TnYPd6Tf2shOnaV/nFLsJjz
n4beQQtknYqFZN3GqdxpVD/gvuPm4BQWnfdkVf8BcgOdqHj6C9AdD9mCe3hVAoVdTpwFi+sCHhzq
hoF0uwEB4YmAjze7Cu+MeROqcWg/Fsop7OjHBxl8bIozH1wWFb8Js0CETN7fXT+vQ83+FL0KNHKF
Le1X6nbucvRTg2kIGw0+++Bdy0qWgLmuRpKVuMCLmJFAkJJanhzOJ2578ahDl3y3fNKU7v397nzT
QooFY3ZdTaUiikLOKY+gTnGXOyEHk4UmrclKMFYUoK4S4J0xG7dy5Ec6Z9qGanDSGe3N0QtTXtqW
+L8ECOn4okuZUL/26v4wHrUOzn+YhRXXncPBPzd4FjM9gENKguTPJQwFn1A50L4xDmWxUtTaBKtG
RDOWnk5zvq7AM0BY2doFRjfZu4YCVhEBvuVE4fPxBJitEI/oOFYd6yBbxxY2iZ1D2HdbATHEldja
C7GM/RMzB6BZCHooc0x1zi62Gkz9i3ESMtyqDX9xaZvN7AKvPAPMvdWtVCKB1E3L8p3fMudk85ce
QPLxyRT+II03eqg3rpI1SjFplhO4pmreyuGlsIKW8fOr+OP2BQN/eJlCznfws5J69WOca9/V5751
e0YhmZwMHS07TYTDggx5IBc4e2CmmWq=