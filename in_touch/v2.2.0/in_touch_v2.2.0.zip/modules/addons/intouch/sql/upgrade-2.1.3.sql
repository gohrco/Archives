

ALTER TABLE `mod_intouch_groups` MODIFY `group` VARCHAR(150)

