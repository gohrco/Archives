

INSERT INTO `mod_intouch_settings` (`key`, `value`) VALUES ( 'fetoenable', '0' )

