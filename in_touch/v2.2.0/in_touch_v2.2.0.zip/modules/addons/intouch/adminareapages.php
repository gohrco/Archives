<?php //00923
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.0
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2015 September 1
 * version 2.2.0
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPqRpsqhQUY1jjoXEQGwanBXFV6vYzNPhzjDG4HCUWQscXblC8slIVZxrcv6KqBO9PXave9PR
l5FIp3Q6uLc1iipNnwYWcKA7bwbwQReEMYHkIO3/6MPD1vuwAZS9yoAKSKsEmVN10eesoSV+085Q
mh9P1GIlpYW5w0NLYFbvpvfdRNeSw+uMHzip0cSwgGlueSRtK1HRswf8HKok4IQz9vuFOVrIhvxq
j43d1ZRubuT8/tmXqXnkbQl8wv5V7cEWuCkMBcn+8pSt7cBGpnKwY32FbWztJM+P2NF/9uMxcR2l
kX7bI9T8UEBrQSahAHqw4tDCFj2zVZAih+G2qMiJMjOmUPopXc7uvFWx4M2fx/IXhzWOwxMwKSMC
BBcNLOBfBfne7+ugfWpcxcbIKM7qJLEgz3qUHoBkKEWPdDhdXXFbsItIg0uE/Zy0cXzDSQKeQLJ6
cACshQHLBtxHfAD2EvZWU73XUmgVlwgrV3B7OAAB8BQhtLEbFncolp2fBcO4jYd0NIh6bmF8cLk9
3UIWUpqbUxH60IQKVx6XJPgB/NuO/VJPBHD6iKQS5UXCTmLIRU7VvW16MNEKQNSWtHTF63aQz9fi
PSHBtcWoAorUnn9jskE9+tobLKQ/AVypYNKLjQcG2FjglHkkirbk1xjCKNG1BxWWw8cuZj/ZwzhL
DUoelSyvXIYTQdAkkQSmASNVDzFCLdyC2R8ADXCZ1dMUbp9U0lJGLkzhZbUZNSqbxVkj2BFZAyGx
+UDnWhlnop1FhtFSSy9p8XM+hRcjVaIDXoVuxXSH/jRBFhc+dDOvCEcQg/WSB8iGsm3yqOPft1ao
WsUQlopWf5LhiiQgUW3faj0+YRdseOkchFrYqmv0D/+jC0flLEzxcsIGU7cXidYidGQHmBnV6ioy
SDOXxo6Q+pcu9z4Z2UtpqPbgRWvX5mzS4WDywdwvGkpgIj0mNga2fYkD46fv/+QWrd8d5S2RQ7b4
myoJlHgSID3xVnFHQmuoa8ST0Eae/aPQDNdeiBsbe9xy6RuvTM+kIoNAcKRrgErOYF5QbL0Hvudb
WGJFOlnn8U/VK8QljZ/63OAxmWE8lZ34Ggk1oaYEl4+ZYWC00/r7jFgR71r0dPi9+iiHBDEYWgRV
3Q3XEEitr4KIyHel9+TahHuXr9PBwNVezw7PgM2LwWsYzQsIIf8XVK7jWo+s0m8crgMl3Ogy3hUT
YsY9iZJAaqz8BAugZxfBiYjHkWxrBJe1NC3vtN5M+wQdiiIRkeXsko1Pna9Q8rmq9lijCupgeeEn
Cq7fc+uCO6C6kUUjNFDvxyEkKn1TTDgI77KxBtcc4C6XZjVL18gBVT+sRUp8+toqoL2QXOgPhkND
AqqQUsA0ZzspothUUNTWW9V7Wa/9W+jA7PGGYwQLdcjU9hWjMHu33AS2a1azCd3LwLk6w02vgvaY
7rkailZQiyAuGVnzM5XJBRN1POwpw+z6OYbmlBGAOumBqqOhu+s55zdVMJTBX+xVdMdWg65guUc1
T7T5JTIQdE7C3KQjn8j68cHGk4xHHlAfTLxw9r/AqEuWpTgUoTMuiE2JOiT1rz6CjFzfy84g2EPR
ZcZnI1VlTL5KZcFlIN+ADf84wXQyR/qJJXKJHOn0PqoYnEZT3Iw2eYP1+VyiVFSzEyweuoS3hFWa
xd0iGG6qWOLeG9TEWMgJH9+3xI2Tlzu9zLPOLTBNvX0pgs/C8vYcLRHC1DJ1n4bBPJH/gbjNCANO
iQI1ZT8S0ojC6fB44TxOe/U8YZrOYbdLsCSJo2cPSKKaSVoHEm6FUD566/T67rrUeLRqYlu+CC7M
N0AqleSLxczCyGagF+Senj9D3zAQqf2WXsYIIsYMmKKXKyU99QG9FaNBM5oeWw8rabREgPtuIMC8
9SDgMn4PCBR03vcqfdZrh5mRsROZhpjAPB4KR7+CxbhW0u9s/JQY6Y7S69FuliHxLD2gkO0i3ogp
glWg0tEThie9EE2JNzdeaSncDefNkWTjilZ0jEqQvSPcUAH2/fXu7Lfkgrzppi7H/yrP3o/0X9Lu
MDuTIWnC63E1qRqvRHyOHyMhFRn2R5kXbGvFzNUWntZhsV+WNnkeQQ3pStTQI6ng4lFA7OCC12Vs
9WaQls5PUTtuhyqJzN+vMcColr2eT94of6muPx5ElG3U6KaPlUiCD3IFbKmvmTK92MwoX6/RPDGb
xuGfpL7GMKFes2xxbMdPon90cXX/KD1ZUGdZpLf8z9lc8iApOdgEU61FKuw/5bDk+xpkxNG3yAaB
3SrOxFxiJXrnj36P0sUZ+/G5dHnTM+9pg/yTzhgV8it5qHGept4H8V/StwyEWrup6aY75r6p0Rwa
BiGfxfmIRzEyT0tjg7aODr7/a/xyfRi/QX2KayiQPFtLJZ+khy8lRX5i/h64s3uMpYngiyalaIOj
B7fAeAt1LxPNa7oTG0StPkZdW+IygUJtPIrgrkRAqHL4k6zuEWpRTj5RQhTCoSwMLAIBn+pYSn+g
MW7S9DBS+tS/WpsW4dh1SBQP0O3Rn6BKwdSWSo6scO522NSfydnmsYcgIlaO1B1eKBTqfakfyINq
SBFem75AIyf7lFsrtV2EVdFapof4DbAI/f/8HxiDp2QzV5J/pwp+6odrzC/ZguUUaXbCqzdewjtk
QuLug0k97KHT14yarJ6jjSrfp6GU1as6YJul4P05DDC/2hqR6yd3iL54aSAORV+HL0YVQSMBMKz/
Zwun8WdcQLFZLHAXzbsyzpEWNCHLHnWb+qfVgrGra2RtndJ8yggL8scUid5uynWw//MjEFgVi4lP
TWnE0ytybrj9caXpSWnZpa0IYds5l/S7+bKdC2+KJ9+4105K98wuymjR3bxlY2DliVjDkZL6ZvC9
gr8YO8esg8oe9+bTSn0G1HV7clOhv8KIQhLRBopr4ie1ouCNA5sgcO4SFuJQXChkpEF5wrIgUIvD
KHF4Z0AubBYwNfkNErNZYwdLIOEiqvMw/lbDa2gIqvZt1MEotKb3+0tpZQ9urR69M+QzjHVhzA6r
G3/p2TgFSneYey7rYHWdcr5B/t0Sh1r99avUb7H9UAa13MfLzrGmObntMOVI/2v/00cxaJMmuMNO
tNvak/xVCfp5VRXr5omnaCAkM1pnBO1h33DNSsxSxBVyxL8BEQjOA1Qu3t7gl6dUPif0iIevvr1K
hDlBAH8ocncqWEmJU79QKxG+DHfXLjQ6e8ZTGZji6l9mH3FXFgOV/ujt6024A/in7eLgAz9EtdKJ
9j3oMjDL/N5ddX8UiCaMV1vxuW0gX2tue8KGk6TdAs2AH9yaw8c52aVZkYeks+aJjxl8Mo7+SG+z
WcPGfbmga+Vxmccm90CfnpfhuBvdXDj3MSrh2c3Qf5C3X4/Y5g9fXyuNl7NnAX7/gzPuyVnc5uJD
L8BwNesIonkty/hS1T3SGBYdcz4zl2AyaBUyS9PvUgf7DX/Rzw+lwBUGX128dWKTzB7IVIFMfKQQ
EKGDuMX6mYbywymXsFgwt9LFKpsxpPNhhREkHtCfl2y2pb3jguBcHPS9k5TIaIwqik0Kv1QGXIXU
NY04vKIsT75jW1BLISmcRfAo7Rd6IRH7vM0oQ9B0CA4p6fhsCeEM7PddSogtYI+3HKooHGJLYXC/
ELfK9122LmjLK8um6pUZRInmDyFZQgtB2Hc+rs9CRDdIXaBtFX83+v6JTyB4Oj6FaAJG8nL6aksg
vfXTuVAUCyPROWSlI1oWL7tV4VzaB4Tv9WMROVW1d+gics2LRNpn5uunqPIrxLLFouVzYlbQRq/n
M05h6AvG+AeBU9W3jL3jUMXQelBJoF1lZDNr2z3YfovvSFCCsy1pWtdKyEXSXalrYxcHiYBIt8uE
38KaBxKbz/cHc88Ozy6IHLk1v5lKf4er6onxVokcm0xRFXhk8+ELFmViWaX2+vJuOkxReBobgd7y
6Adpk/sHgp6yOCAx86smDoXjbzTEKokARANbElBUczhsqlfLFcPNWvpZBn2se2viaHscGsChpSHd
TmvgUFwduOMZBDNC82lCicQpg2E7XVswkvF2Ei+zh9B9gbrA5K0BXIi2LyF7iPf/19uzY/AV5bVw
2CKM0LPnxAiYvLt4BdCw8daebg5NLq2Aa6bU7rvkksv4yiHtJJx7+jWwHi8edRZp2sl4DzFcyevU
igW7skTNpk0DpFMOBbEjw/3mxih6alAdnIL8vlGot+V/DMAcelQ0j0smb/STkM6LzGmhw7esV2+2
deUCgZDqlNjmZtNlBz78DOvgSYgiZdvN7Wm8QpQmLtkELJFY73q5prpxGAcBPhC2LNik8zbCujh0
T1y0RkYs+0kpc0jNMGkf7OjasMzNd2zaEHcpZKamOOD1hYAcCiVKefkT4AA/WrRpwdgNJ7MplCAi
KLuqeml+slVJ1MD/QI+urEl69Xv9c7h/Ou0Aieskf2Do+aha8wSc1Dy/hmplX14u7VkboGzQsfym
7qperz2edVugJg1om+zbxW4E9soYxeSCw4G43bLxTTz0HZVnyPmmMF6STKIep6HH1bdd61VGokIY
qhPF9s1q6FEZjlPrBPmrTd2mPKApDEv6AwX7XN6RPF2xo6JJUhauc756yxtE/PIeRm52HeupduUV
cSOoOtQEQKIoh9KJSP/Pn5i/GKWxIpVfAw1AnESI5p/AdWJ2TLtOfL4Wz3U9pD5PbifileVJpnKk
rZCp22HRHOGMxkqsUEgV3oRfNw530U2RX8f1uv0eAcfP5fDggWLwt3klUi//pVNxLyO80V62J8Qt
CVSm0I2v+wjHIcuaO/ebx2z2wBmHnGGc03C1aZY2mfuiKEskLP+pm7T9dIK6dwDq2t9fP0Hk8g/O
AfpTag9Vc517/qb7G7Q6QNiZt/UYZI9OXyUgomAhNLW6OWVNFws0E9Zd8Am3GXu2OFcutLN5xWrW
6ZInbyYy4ypeMeLI9wdYHR2EiQH/yB367V3Aj3PxCDPM8T+XaMOSZpJZjFOYG58ww51Ii4jaIzmm
W/hsFVvFIQkDEzQ6IeD7h1j/z+RQLOF1m0pWUHu+e/cA3lPAqTL0e3HTziXML3+UvoeNca1iTvK4
HUfTlUmn5GIBWIWl3U9X6g5oc8sKZ1qxUFz0/yW/8FWzKwuQetr8MIc5mu5k5et1zDh3tewS3Txo
QvcSgjb7R8bZ3IFjQYl4ZqedaPfXI/bcH+aNv/18kr8tqFW52pkNaf9Qw0sfh4Ng50rEezfm3Rzg
IRf06BC4hlCRH7Vd+yOZzD2n8a6FbeNBALRLHRbeXK4eXxqSHScLDd7g/L8UDA1tm8UvLqqfVItv
py7dNtps6aRCkn1xnFrkxw7X7lxadG8DFPkmeC2F7civEevgiNa0Pbmaezs7pqsj1K7ey94o/4dv
6SPSTws8cMf3R+yo9Zv/Q9UI/R5X8dVUnhJAiwwvZViU8VEFiGuPPb8A3kS+I1ztf+Y6z1ZLW5J/
Xe4o/xcyDNaVDNHs9HI/tEv/Zob0ZJPTaoXg362VxyfSwGFKynLQa1jsQIhrK0IRwfgI695Yeqis
AGSgC6jA9jUjVrTNW0sARd1TjJKBmALO5FZkNLeb0EAXTh6tffHDjOyIrtZybVuDK9rUBXm5PJFf
KzJDv91oKzX8U/HPMMfU/OOHTTXbjDwgKXuS+TamEX4dvXhbratzIkmhW6ggaDIS1GWfRHqvfBoz
/IBOGUZ+w8GM1WwZbOe01zB0O7x0UP0cb4EiXc1g8d9ze9qSV9nDqG6iWSjASoimto/F3yqH0zmI
rNc+DouLwWgSTmvUlnwQZNawTVEn9oaDL7eILnisOx6tJYQkpy4qc1I+BCPHA5w2FwukpUuKJ4sN
8s+I8oNI4fJbMsVg1TwY50ckTk8W8Z8F0tBBKHzuUjV1qNsKSH0z37H+D/TqbjywAmXFForG0Vhp
vYn/ToNpoxkRqArk41D5dGIscHDT24zjdeN3aJClXlt8Re5gTN/WliTJrUvwEndDN8Z/qZlJ+B5+
DxhuAelPY5lvn0M7u/scIYWdxIDlHvIdX3P2fplpeib/bHMF76nGchc1KOwDDBTOvz8bHMt5mSUN
qbWsmikW2rEeGyArYUohtVZ2sCFH1FVlsLl6lu5kWFLuOuCIt2Qc1QsRu1e0IenyB9artnCPjxuw
Js/hN4mthzMMHZP3tHNdxtV8iL16OMe3ivxHpP8T1axK2Xz2vxQ++v3dW41XByxR41HuAb7WV/uD
cmK3gSBHRIGIf6uBMVadVCVlNY/9OYGLr+LWqkrJgpuNVnZT7reqdI/g7MjGefKM4MxWHbPTfnu3
NFRbkH+I+qU5MtgHlFgJpn2Cn50iW9waBbIkE2x9TZI+WYXmtC1FAuClrtR7BFIKDzpdRrnhOR06
HlZWHzP6cV5jAEENCLzFPzSBw5SFcJYt5RwmLvk3vKv57SJdzd9TZuD/pUrUBe8nDKQJlfxwbE8A
MsX7/W0SjD1QHqZ6BrZvcjzH6Nyqhv+h/A551tK5XAISoggZAMt/0XfA58i2zTjfeBd3579y+tdk
gFCBexLdcmv3s6529dzo4zm3mqXQf+5lAqBFZOYqs9Q0yq2mdsDTTcU07SNw1xjq/Ql9aPzRgPm9
A5MZpAHYaKpxX9ENnGYjBfh01X7JBX2H4AESgn89xNxLtRPmGd7F7961efBxmcGxxulUtNleqHbx
94BXv7miqhWJwRtN1qwNLI5rdmmsm1oBsfN1QWJIgESYscAQGHZjkN3VfJ0VQj7aEaHKbu4VZOnp
YB80HJGPwDngQAhmsYfwTVnEpAq5OWGiBwedM+l3mtKQxbcJF+VRHTKCPEEF0rRgkOyEHiKNfdDq
zEX42zgbWDYXN7meLKXDeGfJcDYk5sxsBoxC5K9OarFnYWnpoo5B5fv7e83MO8KPHIWIbMaIZIXO
bEzZFXytBKmYmCtSK4vxKA3AmcTm1ONGCUBCGDQJhCMgRs6zI3tMXaWh1789jRoofgxo4rNo09ml
f90uMhxXkUQ/UrpJSrYYniOllqBld0LEWeZbYXVL2/5M9LMLEasPaGvlA+UB2N+VQwQ+a3co2e0j
2pJoEQUJzlptoLqDBjqGlsiEoFEtDe+QeIpVJRZ7Ejfz8w4fT+MLUYysSTqWPWUYqaxZIDb/fBhM
KiJnGMKp11sUMtvSyyDS+FSj06EpEHoXK+g214D606MPe0PFsb/naBuX/+YOcqwr2/k2cdtltfw4
kGE8Na/f6LKXOTQ1/pYT6CRaTXqFm+wjhRH6lKBoZ1Xi8QQtIt02DTE86ynBNO6UdcjnajEbW0jC
8olL0kPthk1i2fBw6KjYCNIZZHgdueazbjZ/H5hCrGyoTqNpYnXWnrYvY2zbjhlZ4Le4MhCEYluX
+nrntAcVGfkkSAuZm2yOSA9obVTTUa6vxPZ7P9IiO+cClOL/jATnashV255tHQOX53PhuZbfG3bq
DtPK1yA26bdn8PnngE4WD5j2+yT7IOg6aYhdwFaDMtPOCFGDwxog5f6blitBk6WeJVvnCLqmxGKl
WvA4nvaa7oTIwi18OYt/kXnBe/PmGfusIg2brTt4PbckXcHw+7oOWd6WWf8HmD4GiI7f5nSRj7uh
t8jeiiGx5w1uPcpcNIFwK2BZEwpW0E1bK525We2aHVNQRKBUVeLJSlZi2fWsD2p7KrhN57ZFaStS
rBhHXh1X6l6WdqRShUwUml88kb1CnHV+N5nYalZ5hezIfzMj6UUqmzbOP4uaUsJwrd+k4JtZmlhj
eKP66oVFluIBkW/nbo9ukAP1CzM5lMliuT+jdVF6VWQ45ufMIhOjvN4YByEP83zsDcNXUWvU8e7f
2l2HtAzAS5B3gle3LJVTTAGPRQFXtKEqYY4N/70UoyuZxW7uTMUbOA+xKInpB2Njvl7uy93+rzCO
v/Fo4QJHpl25DCabHe8S8O67oGhKGsLJAPMyfjwyBf6GM80mJLpwXiaiaaiaCijCLF05jGEZ79BI
EQmnRcQFN2uQfpLNsEGTtkleU25zL0V5kIm3etMlBPs8j/zHiaySSOfE72oobbQcpXCAQJOpcNLS
jmSf2hKc2IArHIz5QHRngIXIsTbDXDPJoO/+LvNUjArkqyBi4huuPIVhZdKEKEcgUPWo0b64aTNl
rIogmuHORwnQJJvgSjOePTMnrPrPG4xmi+jReQSEb7KvYJzwJejpjWH76ocv0dLziHauPEhb71Ar
tq6/2jOqyAm/GsMNp4WDNCkaKCChH5y/RTND+uaoSUoP1qccmpXxmajU63LGWtt/WskN6vG6KzRq
XP1+fqdJDxkF+iI3TL8bfbNUOKlx4UPvgY4MxguljSXjYpbVXmnWKTGwPfytJbu6SGuGHm1X8Mmd
h1opyvw3z9a6fV1d3Hp0BM1X/oc8xwcvJnGEpRVysyO8Wf0m3+HpZ+Fk8gO+BOjdztn+l40Krmoa
s2u1YYVonA8ZbDaBnwQUmV1ebAxpt+MET3wUrq0bgQ92zAMetBYYqSDIfZdq6hSiZA3JttZVWiq9
yPzQAJBjVDXwq0wKTrSco+heg+1xvJKrsinKVIE4Dd+Yy/hPQlvq5hH/W2xQOoIiWRVHce+Ip5//
AXOjSgK9G4YiZimq5q/0OMX7Jn74ckHDykKrsUcDZg1gKIW+6xsTden0/jb6z9xMOlKmHj57WazQ
U4SgvyJAi3TPpEmFlySP+UBB+k0kvPxIFXBrenApN2JCA/DvB7EKs46EolmLeHE6HbJjteiOkxCJ
UXdhPLM5IHwhZStAhGIBBdktGCU+DQ9hQGo039GF5p6vHgSqEnBgfHei6CXUVAdQUF+mDJyQecp5
zg/7phwbehPuqKxQOcakhPxN4CPq+o90K5vO4k2l3UGFq7eSzwd7OUchOZ/7ygvDdHzpC9wa3g5E
pBvzicZfdK0GTi9CTh4L/4YLe0aLWO8YSx8GMWZftFlKNUwiC9gM82KxeeerTNnkjqXPXh4s33zl
xTLr91s230UPDZXEYMU0D1QDM3klWEzOb1d5FuYXYhxoVVnk/CaKxLXu6MwWsaXDqKaK2IFARYZg
ITZI+OVi/MPdtQHCoka2so8u1xJIsZaNZdV/ZvH6AKcOlg32v/6/fLPGTYAeDwOiWjNbkChrNxEF
NtUlHD52/KQrhinLZnLBPPh3pwd1CLyHW7MY3aw+IcQYuS36FPgk48cJOlJ1kb6ooCuaWelLtw57
j82OCWWxGdXOMwXhbX0sni8t1DA4Btq7r9BlKlztlKnV5r27kPvGWflN1TrzWrUlqzqmoBdnBY1g
bTeO+Ripdd1Adpg65kbbQejYqwJvclug6YNqP2k1dSb7LdCXi2YdI66WjSZ28/Sqvbkl7xsnkcRj
JXXj5mHQ3iIWuzpz5G1+EsURDqsLzZZy/Env76hX1URS0bWrvje91z5xlIHTv5uxlag1rhf0LuuW
fSY+fqv8jEWdzhPQdBTtkTzRSprVHmpqKZEzu63AIUL+cF+gLmhzT42gLLfUtDD0yWBBZy6q+Ofm
FW/6p9VsoGFKsh/JDh6gmQIUQ0SvKdiaGTdz45bdHEaRNHXPaGiPD7+bbInZJgXk0vQLWGM8lYhz
rmPZXtdogZ0fwnyZkc3aUZSetvIfX+uC5H1nGZEaoJambxoahKBGFuFVnqURknecUdivZXTZJgSi
pu52seSlh09qpcO7Cd9dG9Jg6e1zAMP0t4I8snwQxJ6K+d/KlASuLNwEMs4jAp3r+61PbdKQDumu
+jmj2nv+82/wIdFHIxYjsADexS1cp/fixuL22WnpfXYc+/zz45yParSwridcOrC4Ao+oE9rTyYLi
cSty9JrOoCF+6ymTQOCmDyVvjh+cHT0k5skuo0qrLKij4sXXPnG2uznqHgu+hOPHHtyxbzzP8wGe
48rEbUSBrbPdbf5WV4C/0K3lEgVg+yQ+PZ/PCipYD/nOA50wYlDaYu63/jhvjMZd+7CetUmpN+gN
LV8g8DS31xaEnjNqQjrtA74LXbTTz+m2Fb1wqnqi5UDITyfgWNgJu+qDpWt81ahgSfM3TQPcUPRg
+lSVUW5XZhx04PSfEiSR0XkzclfiZhVCqsPBQSMOdLGqrSam0xBqxT2ExZOzZSF+m9wiMnA2kPer
4hguNQ7EcOyLArJaogIRgs4pNF5oDcMsu2M+KhHQw3I8lvjaev8djZLb/TyeJU/NmbzItO8cvKpC
TQKDPpsPAvAMmqXbiTz+u0q=