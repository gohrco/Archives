<?php //00923
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.0
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2015 September 1
 * version 2.2.0
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cP+xFVrXlZaIGOXJgUwZrELTgf4zv1qg4sSSRMgNeCjdUEZ03NpPA2yJOvkxVjko1hRRKMnLv
vJiJG70Arr3vgD4D1vIJxeD3iDi0PW+/8YkP7d7YohN4jaU2w0LZ8zqA33KpQG/MTgNZADjQT3OH
DeDFn+e6vu1mSbJacqqfzzJSvLpFKHM1kvz5yZZlglICHOBAgzigEKo2xyNNZTc5kS0oZ7r7ZNEL
YYGNhyteLxATm3M0S6JNt/UZeKTum3OSCilkh503txe40PrcIFd8bK02PYOfF7jgg6Sd/ykVEVY1
P2Pwl7mRBpg+CStVVR8gP4fkgnT7Gn/OOYMHR3FbIYGJ0dKNWnFefgmie9Ii0rfWWQ2JXZY0eCY0
GoWXgTi/q2WG3ifAUTDpO471Y/fP3HWNo7Byhv4IA7MYrX0lUOaWTKlB4qlOt1z6Lewei5iSnwHe
81dgR7W32cAz1SD9DCb4spIofiTlTHWJwOv7QQ162PcuQj4u3RBrNZYr/AvRzlkw1fkpcHrSgJBa
6ATAnLkaj3GJD5KA6ld7YQpeL7fg3cI1HWzBsy8piyUkDQ60ZH/M3Q1gjqqsU2x6bvT6nF03UEzF
CCUj4AbVPD0WEDgCv4Rz49j+hD4e5Wb1csEfR8S0bk4U7WvUzb8trM6w+QrdfaeYqkd9w9mNo8SA
bima17ti+ST/0H4uYL3Vp7zZ4DXQf9QFOa7AaImoK9A9cXi6BqzsEcQAco9POGzaLGyQ8kglX9m+
FTb4UID1e2234MmRYKUvHFk0rrroAi+p6eCmbOmt7F9rz2hKLyxjHZ2w7mKtxEW0Gznh+XbTMlap
SX+tGmERscwg4eDR6mY0eUcEnySH4utIonsYNcMPqHrKAI9KW8xj4zUIONtRuwE8sqJs5jOTg2Sv
ky2LM9nsHW59xcWtEMzBne/lH29I/m1UNFjwOE6ezTYTzSbVDq8abjOYQ13iUi62B7C9eR8HGKIR
bam4D57Jdv9ukLpPlfXJ4sArlDvw2Vf62/+cZHBLwvQau/BgjVuPZocjpHKJSQ02AEP+RRo2IzGq
GhHWSQF5aVd8l+5v9jst3vCbKB+jtVDiYQArrOcKLNMjhHrLceh3VIjUuIgfJiFubocDKxqc5+fE
yn8T955MwMhYhO+yImoIqKCc255Wb+jvQIzcFbhTgUds8AiBXRg94VT9f3Fuz4f9nqK/3Gff2GNd
QU980EBsw9vmD6q0J7sanvPCf0rnVLcTqd8kpIMDA0k+mGLamWOGeMt73SuMK+sfJvJE5hRQtqYO
DaN7wh47LbOnnyyBuMUyjvvcu0eEUUlhg/tujyBVZUP2EHiW/u6LYauxLN3d86eRUlrmHMvUaexL
Hi41bRftGuAuLiec/ffQYTqTFkRl5hON5cTbp344OY8WPr0wQaZcojtYaUSfQjJvYoTHz9qrhujo
E79Ex6Xi6am97yb+VQe9iPnvloWrpOKxXKiLCaMvWnS+ixrjMTVCSBCbrdmclhUGeBlxR2ozat81
E9vNDbK5HemTkTzcgeZ4TEjqWOUyX7vTM5urGoJLI6uXon2yEOtCtzCcrb9SozzQwg3VnsnJHtnB
05ph2v178gpqfL9f8fDln4Hu5n+NUD3WiX7ugZgm09eBj7aslfN6f7NUFva2fx8EAQXZXrsTQxhA
wD6KVAjapYDO/Pj9yPiCfOjBXQI1nTNQRkv8ZvOlrvKVASXVfMV/ABlh2pbyWt8C4bsmGekbLP86
+EbNlVaMC5TKhJu2SHtdrYwLckpmnwteIhhUuYtjfTnnmzmDxSudBeFzDmLbHR60LfSaMg2tFjq+
RvP5MyClh9+yKs4dBaUZlSLlmKfgJrlef1prld4GXpRHCclSE8xuaNRUC12Nrj8ngsmXaHKu9kkB
adViE0RVDi7jVvZgiu99B4yn9SntskBx6Ot8PttinbBdIJxX1QR+9wFnWFI2hXJFlhUMFOLlpgAs
gAiQISMDK8C80ur05G7a2KmdjqMEhhGBGurCwkGpMeue6oi360u3WoiSEF+KagtD0eAj9JYqXjLI
mWOZj7sahT2OfXxEKVFRJlhh4d5uOK7pT7X7nq9HvlZEL4gqYD4GVtsRXV0Ez4lXGguT/sp43Mpo
+N9KjI+/OrnWMo75j0xBTjHFGvkGtFvPi3FSytpR64K6ZX16YEWPmdNahwAPOVlXiGKVtVszwqSr
/XrJgyKAmUoy8XTjFsbef1NsGiu222wGva+g4r3CrApPmuaAOqlslc7W8Gf4pAep/pvHMQ/umfg6
nqSAoeFU7u0eoAWq/lngKwULbFeLbNsOLXfl5cdvlWObp5fZWkCf7TugZX3ixOVbWFAha9vm9lkS
6aYv6U9uX3jWezKFX/8zPKn8GVQgFmpdWQ45OMH2sDyQFM1Ie5SePZekC4Bo5ScCTzv0vOUh3e00
4bXh8P5NmWpkV4qT0yYvH0ax0joCS7bkediEIJlrKB6AlovFshrKFsigImUaJhR+lLwCT7jyY0mL
z9dwdH8OIDvPRmNU0O0INkj4PQ+MA0zLy80LMw2mqLXG1FPqJoJWpVVgFKa6kIMIi8sdQwpietvi
TOQai/kUJw78JNhV5yNWLJyUJhhTFPXKP51TUQUcV5fIOI0m4ZcVTZJb+HY86uNoCSk3+cYZ9yRN
XIeodoRczBFprkQmmqTpvDc7IR4o0jicYV2BNBiHvuUc1/EbSuZW97/n646LmO2uXZx7No45v9/P
JQQyDPgqs1dMnR4ihMBaH5jevwQbnlX7tw/oz3zTY7DV9uI3m6SMoEoc+5wZbY1AqLVyh3sk94Aj
E+Bb7FhoKEJCnnhmHjAvBA2+bj+VDDCS4VCbGWuvXmZfXr1FlS1x3JbM94V/fj0J3kGPT9R+LX+6
2+vgErlpTZ29A06vkYssdedKXWsBKY5uytzVqAL01L7KG+uepaRccWUCRl5omh4/UF7Upft0hAyw
Ll2sCfEwo3EWtNVQwrpFDCysdQFx2fwpOpV2wPq4c0/svpzLHkKlzAR4oJQp9gObjMuaAZbAy5fY
vXZCE0QVbW6zlokdIw5O6Yh9Zq6j5kef7hFnlHsoSnml+LDLOd/TxZ/52bhU2x4ZAL5xEX7uc79D
mQis/fuijgp60plHSbCDZofg1veJIISegSUQRmdC/RV3acM/kQhj/N2hfXUXbqNj83+cag58TdVR
cAlK3WOdZuv/dtFJKne57+ZzLzJCB7KW8u2znD9LnpK7aFEs87r93J5t+piVb9IggAzOkOF0teXc
SdVIj1j2syFgSO2mUC7B1smWXkVhv10DkV/B52KYub9AUvukBqj2SaqN/ZCXt4gBLXaAR1nDHNkr
Uro3swlvgyvLxXrr6GYyxL1mKd4XLuPbqI1oAuaTKSRHHJwhkLCIr42+Udh14Z5ewZNjvExbJzOp
/wZIAi03uz5nKz/93FjcxlPxQNUqhd9N5RdEU97J2DLY9QgHa17/rnaaRg4YYnaFukacmCpkDVnj
m2abplcz0SQCcNFNfXxDd1d7uRk4xvALDo/dj24Usxpo57wHJ9VJtGig4PlBve4ZWMeOfF4zIqMp
+hvluzdtWafMnjLkzsQCL8TrljiRIy4QYCJzHwOpAFMfPYjXKE2oYFE33VhjisHlnFzdKiGU0qQv
eXZNNQnGMZD+IPd4RJAhXX9d1xF6qCzlneC6Nwr1910Dcx0ULmeW1RQS+WixSn23/OhW5AOr0Pgj
t1emGObmkd2y/nLn9fg+mx1p/tmg/wT11F8Jx5b14sjOJ1tu99ZvWIZgDBVYP/lGp6w1dE6Edzu4
bplKodrUtgdAQwNKTbjqoVPufmEpCUfOsRXsveH7655AJ1ffgH2Po5EzGuAl5U4kJiuJ+4XUICGI
mtZJgZ6xVZGkvtPy52RqoS7zzwpGc2ubowco0Ba1odVIRgsnKqU9m1HYS2qR+BYEG45HxyGlEFwI
Srjwst1i6lQ7i1C6RS9BjNFPm1PfNA6FqD6MoF22g2YbaUhLyPx2kdXqBXzTGd/0bGHccDL2qPLn
qaGX9OSgrtQlDBj6coMlekCSfb361NqQq9AGaZ/AN3q/P6/Y0QpEp2Gw3SpBtOcXH5jZ7qo0m6eN
Beox0FyfiOMmk5aYyVjz9n0o6aOl9ZQ6avuO1yREdqhLYb/Infdz6daVrTEpcv3u4unvEOZpohpg
PMQLVQE6toc/j0ZKOnVi2ciIWFx9ugSRR3YyLHafypGnL8oy+53xc69B3lxSDUpkVzsDcK9of7/h
rtjJxd8zLCtkLhfwCsR9Zfbi+2s+tHnTqSNjfrdHDmFw0y0QNm0zWBDPcDZIHO03CzqYWqwEgy5L
gazpNq1+H169omZj2NjhqbiICfuUq6ijufW8JwTZdJTd59Rm4B5a9bmhp0Lg4uReOk6834YkowK0
h5SloVoWtpS7lhrweWqbs7EF6QC85z4VqxeeC4GBw9LA/wiCdrrHm6sgRGv4ziSLYXuIRj6rG1eH
d0AJlwP+oFq7Td14YHwfu8wAVGIfvsVnMMSj7t0Z1LHpMoFSLaTNT2kAbJahWzzWhMGOeBQ//TS2
HIvRdtRX58wPKktjR2MIZ912SeInRHFZbdt85+mMiIOG6yqPHUa5AcRok/FOt8To4B0ZRB4Bastl
AWUcb8VL+5EG4E5UyWEj2HTwK1z3T5pVa0vnHuUxYb9YpMh90b8LybUhD4nlW38lYP2RAkmnX8Lm
ZlokTUGSaPkJiVueieHNqfO28MwZ67XZrQMGaIPUOnIqgkXs0iflHnEO466Opx6j2Q6smGJEEDBK
WVSzncXbd0Mdbo91t46ibVDoVXJwnvh7rYlgu4muQ+iIBDRbLE+3aKqe7UyE8ORDsuKNqk3dPh5t
yorFtEaN+TY7comuH8gGwqaR301yRrh64v26Z+g7otmES/oYDVie5L5GB3RuNWFP0oY8EoSHIzhg
9zV2Y5/p9vJi03fDPes7k267ebjEY4pX1vTtEJ15pKaeGQI/ivT6+YY5XnxHCJGWpH1QVlKf7aqA
TgzHe+yVdzvrexfZJzQGgSuk+kgtx/LBix0SLGf/KsFVncgUG32ZKAmYgcfVSpWokuU9FORiZftM
4YB1wHHqDcCGAbbIX/YuuOgkXIStNzwFhAiMElg5628QLg1ti21sOYNBE6tiG8o9GiUAxNdnroYe
nYQ2bl6+7VSOxT6nhqsykkPcQjfpWaXFketCcqpQDAvAQ3qvNS0kmdl5UClb7yqOYroRL7BB5Icc
mRvdFT0v6iI7ViRbn81iadUWNs6SSmjbAmp5YXVAjO9jG/5RAmECIYNYz/K/HyTCgvlmZpdQr1Xs
IwNIcq1YxadRr8SYV8pIcL/UyBblb5blCa32FM3M1dbqSk+ux1/2LntaSgqjT5fjq250JDtz1o+2
6mreQEvk3XGGFg32QPzYkb45a3SDRireX3qE8nocXoauT8wS5R2f6ezuBWE4cTYEhtqQBqQzVlNl
jqWOy3lB5mOid+iYjlaaxDkkBRGvmiaRRKrdrMT59/42xugTZgAXzCqbAbg0iKC7g0B/fL3CTK4r
NEjCHBxOki+e6eqhf3BXtBKmXjkOhwV7KaVHkWYrFnhE4l9piZHMQSJdmPfnV1LcgvziWkNA88jB
cWB4qWPGB6h9z1MsG0eq3vDD5/uJyjIk1tktLPXLIWX2l5bL8vRIXfh4Bu3choQm+UtY2T6+X5Mt
3k3L/aVvgTQOYoZLBRNmORXkBkxj9QBoN0d+fjtGaGNA96Os0UYr7Bddv8x1cTzE1tP/kIRKY86E
jH0qZ4Wm3DOePyn1UpZ6wVJAbJ3cy1oHPvE/dYactBswhb2aLobeq3avzNJzUW8ekKqIvtJpG7ne
Gs6OCaLm+YslEf0Hp66BYPyPYO+2kFVhWwtZ038tpCKoE0+vfp4RwtzETURqjDUg5yJjpWNf1Phx
oOkm2+JKTdJszgriF+okVTpB6TBwbeCuqb4ukoxQiuI/jSQqg7oieivk02D6gZ2SHJGA5tgnReDu
TpAa+vJ6R1UIGHcypvVcTMuAv6dXd6W5RabOSk8NV8mt05CNEGYNte8APtF9/Zwxjvi9BxZg2jES
R1sPtMI5qX5viwAa6R2yCCdeq2URAkUggvj5GujAFuWsYMNNaCuW+qRO2XbLlhM7mGZIyH97GjdI
OOE0le1YLX+vHx5Bb0f4nzHU0YdHd11mFdZOD7iztN/Usq8GXbRUSlzXY8+UD/S9TjC85ZPHWkFW
Door9CSxWmR+M6qQpdE/KL1QwddtzgT8zS5SZ0/a7QRYnCuGviWx5QylA5CXQhaOY78cmy6mHt/C
+HaXQXzHCGvaIQ7x8Y86A2ASlYFwls/vw49s91+bZl9SKWexFRlXBV8qh6Na/BzNUwownbed/BvF
17RVDMLyAABhifqqb/Pj6vUxsUyoETh2Qt6H1iFTvIbyLGoLGMk9nG/zOABNjNbTqLslvtqpadjL
mAMZtzDZiBRKYM/m4EE2L+Igo500O3eWRMRSMI23ziVZ7W3XTXs1s4f/zimUQcc2FqQugQneTZ7V
uGgRZQykbvaVMTaF/zY1QzX/+SjAYZMVwMRz3vvaiLDGrv8dRRwoyF57Ucgkmc0Jsj9uSRDiOmEp
+eL1nKqpzFL1HSRc8PpGYxTKqn43+Js3SbZgO40mddv51mZOGqYR8g6nolhyfEpZYA5t+BJsVxdd
ws3t+NuXtUb1RD/5rclVHmNkqb1X3S3OiUbdWFid1f4R8Eu4+0FjvYnDV6M3BRXyjP4O7qsiGil3
Vb2gxHxOos2qu+c1jrCfpUDNA80UTxWKVPa6JkJmYFYGwF2drVNVPWfAcuWggoJEu4zH6P1LBHsU
JltGg4amUgeNPbLvdVdy4VXJMJhyKt6gsHLuppc4FotxvpDs46g8r9KYDdmx44byaELOAbJsC/Qi
tDndE9WPi+ugwVzGDHvi0cnEZCywoQlbWKkJclVlr1vER/XsuPd/1bFzc5JxqSQdBWzuCmCNEUdG
hqR9Bco4I6HoccHkiboWisPCTrKtdQRcBQPj22Q/BDK5k4MyZY7OBHCHmzLFgzOA0YdCA6rYbkPp
GmbHkXL+iojPBH1qBbckvbv2+UdMBA2Mux8aroCOMAqRr8wh6a5in8FEEyadoG9Scw3T7tE51rxT
HdzUNIdBq0AL7P6J6IGzZeIuw6vlTsM+WSiGTuqE/FlAkYTkmHaGuwdWmXM/mwzIez+BvvV9sMs1
f2imuyqvTFLH4m8uNRV68Aipb5l/p6nslebQ8nSCqrV7AYKPMEc8uRoDidw5hItpL2Frslh5bbIG
sfRTvoDqvwd69e0fDsLdlCNjORWgy3RdKsQJKVIYfEPxmQRDspBKlBOf39pnNP8udwzNIbV2j5pO
a+e6ZSo4HEsL5iv7qa5JgXkwZ40lc0aoRF22LdM8bLbRRdVIkx1rES9A/zDNAe6q7Nj07/BqHhZY
MFC0k1CB5ZCGU8G9WX6bpXewxU+vDv7gsgjRltJb/VOQqSZHXKxX+5oLic3Uv0boYhXbdcItvgrQ
IEsyn9q7YlvsVH3H8ZHZLU09SbLiApDutlOJ9FTBBMJ8u8jL2eanNAS8y5e7MkvfGIlvta+s5BBM
PddKrCH34GKzgOL752PW3P2DPz6Olfc+heyLDyyJY5propSAWHf2kXNYlLPNc6+h/P9SWPMAmRw6
4EN02EEWUQmdCdv2RU3CJc6wedJKSWueTX9FP8AQ8LdyhYw+zB6x3Irjv0rxOeImbrWhxZXv8g96
rIhNDcMFqCjFCbDZR0hXRovxNXQBqX+N6XcARm0UWQ0X5GW0wWvFd6ItO6BgmrQ+znKJOy/mWhZX
BcYGgcnPrMeeZPBgvqXb/+2QymOnwRDjn+k4wQMftVwSgjt8ngadIGVVLqdODoF9K1yFqBcY5uA1
9XXkPOKVJsDBEQP9cBkeDob1/rH9goSgKs5G//923EQRiE6v5NrN+alFFmMk2G/IkGMb0NPR2IIQ
VyiBBq+u+8VrZMA04CUwJr5AMedp2aYvxsGzoSD8ocwByabDkaUMKv+Fjsoo/LPqt++ElchZT0+T
4rjspRI4wm+AVRIEB6I7f/UJatJ2wIm7PMbGMahvQkETJtU0XJg+z/kx2tiEWT9gFdS5C4fwblev
g4fDdxoAqI77BJ6Ok2zsWsqlOD5mS0C1kPJCY8WS6Qy8uT2pP93/o/LALcbY5LQVcrwkCJaAZK28
f+WjVLNEJGhRS39NJk4PqR9a8ITQicwJIW9Cpi+fKpEZR9lRPs8TFQJtULmg545zZipGB53pTbbn
lXCE/MYKzL3nolmP2wtw1+SKcg72+J++rSymPYQiMzs/93Vix+1xG/rPqFhz6xnTUc66hFLNv7s3
UwW9TCb/j/438qoyV/domSidMqXbtEm6IQumUKIupEaADGwfS4aRo6mmhlF72njQ8HE/xrqOJdsP
Xp2D6meKh/nKePGGM0dOg68/ygrDvxJiYnNQuKlAnaJqIAPrKyitD/0iHX9tqChHcUxzf3X9CSKQ
NcCebgaq/E76iE4h/OeI43HrFb3m4ASJICallS/eFUh/lVUBHtPGpfHdDnwMHrVvD2r2sHqwlpaB
COfJnMYfodBUqe3FY58f5aTq1vVY8c/Bu+Y535u1K//Oe2TNesxHt3RHJz+lMxzvz+Sw9I8aE0JB
ZNLAQFsYVBix0/WRTJ0sQMD3kX1QrLFWdYD1VPouP/prCx9QruHN/2Nt6De3W02vhcPx0Ps9w3tH
VocOZMMPvR0PwUwbMH6GiNmQIvvn+YjJn/pWiSStgQ21tCqrJLT4970TB4YfXY04qtLIvU0muB9T
O9P5Bu4uY4Am17GJ37B1loElFVHbnhIL5Ib1MxVrGNBL+u4hS/kuSjZjFZ+KSglDlfUh5F7kik4u
v378pzFLxCTeU7L3G15J28l4N3hE3UFkMtfqpxiDE2DABrIn97p5AWDHQWH81PFS0vBEf3w6jTlU
t24ZEmu7ITH3Ljj+zVuM1BZWmgf7iSmYLH/nWQK/K7BVpMynpdS2mTynPF6rENSqpW1HxuSnnuVe
IgvDLxPoWo8TB2p2EYw6CKQ+Gt1Js010Q6oG/pZ13d3s7ZTI+/uK1G81agAF4eUSAg4BXC/adJTr
beHAb2IIyS8gHc6Th17wEdeNm/4ft4fMI4ozyWeoSk6RcBHF5HBuUAoEtELzmxP0o4Ah2GbltCFm
dOETmtJU4TP/Q3FB3MX9GakyHmPzE0xdwqdCtrSuDUKJr4yTfi4T7L1F0p2f1mDxGxVWG2SjRO8j
YVP55EfBMZJaSmZXb4OV+XdOW5NjGzIbV8KrTiLyOuLHlhU6o1pyhlOPywtu1w5rQb0RmUr9xd16
cD48zcCuWohMuZ14VeoaYZOzChEBlvqHU37LSgIEL+d95UF2ZxUws/ufissD0jvw6ijbhQ6qmwHo
81ZhM/HAUPQ/yc0hzloFDTmvycf0wC4n+KpxsWJ4O/7W0pe66A4wEMulxN4R9U31C32LdmFquzAz
0DJSvccvyQp/hC/o3ErQUZ5H/ftjd51VySrdhs9LnYX88139plsi3L+Y+obwCKR0DwL4KSNFsFyP
1ZXg/OIqRWF0lHuvcGQyuUsjvyXxdVEYuXPDIUVzAtGv1mzLvG0PT4EJwyEs0ib4S+hX0On7K3H6
svRqiAvWd7z00iVzDn6VUKnX54eLViTe1B/Q5KVJTfSXJ4GwIoAh0pLFd5JZXhBzwnhCTcMOCC7g
ohWEBGkzL6DJBv0Vbpvu5SDBypwdeypHEk4OHp+xjg7AA5XA9XjTd8lkTVq8repRKAYYKxTowryS
wbaixaIybo1X8wsFehuZyUMQ7FKZuHaFELn6PsD9KGqdqQwGkReQ+YtfwZ30iExngH1ssXH+XFSg
bugk3KUGJO3IHKvFn47KxxmqeP43cJ4jNWKf6Hht8jrJvMNG8/L8Yk2GMmFA5bOojRimafGFH1qE
dWG/9FWt07K8xidA9iutwJsDwu4FSh2ANEc+RJDs1xQ/KTvSHD0wAbVB4yi/4Ym4gKG6UxlrccIE
mCoUP7JiEL2D+ajJ7e4Z/RGUcOP9zUgehvXYEC4DOr/n6oUe/WdL6aLTLLAfc8/5d9QMsWogMfMa
8kejpupkaInE1P2mAg2mGCJnVYHi3KtoZiQ6CqZEa0EYp8xHOxFcwBpREI7RpbOrTPmEwBNAr9D4
TeIwQqlUWxFsEWI5S8Iq39kTgiSuFRM4HehZ2Acc4vEnR6euWp5AlUk7N+Kz54stVNEgDm==