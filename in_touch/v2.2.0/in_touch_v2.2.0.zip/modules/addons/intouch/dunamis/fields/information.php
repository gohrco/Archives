<?php //00923
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.0
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2015 September 1
 * version 2.2.0
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPvCmK+Lk7wZAOuF6nY43WTVGkkDwMo8tKBwipgvpguZSoez8LeeP7w/ZRyz2U3RSuPH+wNqR
GEYWX3AOCWbB+3bVPF4hKsZZNKtKDIVywi1fRjlZIKJXZ1uLFG7wSNcdQsouJ1bWLKAXd4YdrIsO
vPD1SZCA9JAAv3ZiVZ3NBbaHLeTFYhfu+I9uRENWoAnroUzYLobDrzE3C4WPcFBr3w6WhKhcGh3/
PBgadUtUIhpRHdvsdyIMeKTum3OSCilkh503txe40PXaw/TuiyswuxO5otk1hMSOB7HGk7DELCuR
XxsPrgGWPiEg/whU/mZTwnsjbSyqcSya6KwqmWOsxMOGqvEIc9f5qdS1UJCLGFqav/wy5Wsc+t1O
zrdCVGpYTBf3dNqZspRGtQxQJL8JEGLck4BgT/QadKvmX1HpTGzP7Tvo+2H+V1R1ViliwSLc3KVu
nWus5+Yz0HVNif3QyOf2PLyBWcV4o+fTGAEDU7Ws7gExdF12HLC76+2mepwgMSbn0aCPb9bzetzI
qcgM3u+0Xczrvj2h4ViP1/SEaCZ3L00/iICv/HmnqnlXxouPq/5s1/zvgcUOqPrSz0N4PTydpHEM
kJc8BQsitN+h2ucy+RffJLnQixLi9LWiABB87oJDMbMfuPreIdrBwi4FfX3Gdy3Rzxz3fA0UE4Uo
vHj4/Z9/wh/yUwcOVJyxuT2tACxNCT8BEHoqQonHcifDlcMVovMBjOO86QGqcW4UxgVdEdWo+yCO
KCjAJXtqkAGTOxDN6yVcEueP0O+PbWYLU2BXR9tn3YALq6o5X0v9NqlOR5QRxCA70wevsBDtCFuW
HwNkSg96A/h03sZB2EIFJHLjKEPCnBLUmKf09QIz6IaDxtQllkoTEf44GeBdMV2Bsi9pzw7BNXHY
bAQ3AVv6BsqwBy0PFm2bMWpWamcnw5Ck+2HQKarRvZs4PtY/9dMUxYPSm/FOoLQZC+XWv/EuNH9i
O2mK9f7luuughrLBpaJp0ee7z9/pPQ4bUptnMKpOksbjDCT2tRjZNY14b95MQXAFPYL0KSbWbZ0z
CwS9FKbB0pf8yEJ9EpCEsvXU8tXzZpr/nsewZsu5oAITECeFK36NZWlHVr4UsMA+gDpYBMA5QNAp
qmMTLIrlIIFqpNK9+p/et3T7ipOIJDBIZCXVE59+iUYnXXVQawoM+tHjOQvBS1gKGuxLbRa/+XVv
440B71d0Z9v+Mr9wd2svEisD/NnWCSWUPAN0l3qJhHpGA9H2QAfjTt9qNoSVwBiphL/k7iHDuc8I
FOwwKUpKcXBu4M8X6AyDETGLV0DtHhQqbDc5MyDKblSYy3S7rfUdV0DpGbcSOXB5GH/DnU55FNVm
KLp81EkaxImC0fDU0DGANxLvaaOn5QMCSkbhRxeMJkQAcbhqfYNXvEXM2k2xexhMSEjayJrq7FmY
0j39/4yqALX6je1j3edYfmjyWGhqkQatWqLLwyk1isYTGLsXvXCn/w7vkVSlHiDK+m7Cn/aUZPYV
7cfY4yE71LYOYY/aGbl5FxwohiLpYljCFPNsqjTNzVax/bzINHQYWe65qk9TDMQHtupNHUAB6rXc
3YRpcyurfcN//Ig9dYSlEvwIGLWqWCJhEeFMZ++U4qhZD+n2qr06sSNqVZERm1ZQTReTbUsv5eLb
69aMRynkOwqcSKrC/Yq5n7G9oirY8WrvHXDgb8yrt3+2GmjTS/8573O7c8Ja6gL4eRUdx28Qk7gw
anXi2KeVIm/P7LmzgVnCms3bf8SC6JQ/Zfl4pS8CBdgahDa+6c9pt/QQRSTjMEfg0U34s5woXRp1
/Ujs+vper2I43To9AtzLYz8HmyiKQ6JILqQQLDi+oxd/mJgsCrt70+x/nuGaMh9Es1d6+zQ7VCLH
osqu0ctU/12q6JIAe/ZpHjaDbEtYvCWNcxyj3i7HkdzHnyfLEse6SLboZoVyhXyK138t/5ROcxCS
CVYGBWZnvwKJEcarODZVga++oDAW1Voy9NoAb0==