<?php //00923
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.0
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2015 September 1
 * version 2.2.0
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPstNw5zhET6GPcLzVDpY0BQ2iYKZyP1XshsiSMlUiYBKMfm0XBE8ZXfErWxcfB/xilDrIKZ8
XC+/tha4XWzrj1i4BOADvIN0CA2L4iA3ixh5mQO2tWJHAQct6cORssfcHMPMtxf0H+yNLeUPYd1m
4tGkj7/9IdPNkV+PvgfgY4p6+TBDjT1/BUHBO2dP223txxo46Q78Y/nnybXiqBSryL3j9yryi8JS
Av1gELopY9IiGfzmMF9EeKTum3OSCilkh503txe40PbdUQUX5DYfd7hFytlog6S8Mc+ktsEvIo6Q
M5fMtZG92KXzUMlmuUyhJYff8U+C6nouW29eJQ/awl/EKsSKoz/bZhTMQ/bhtiyJD71MVcW7u62U
3fzn1x2mv5rpg38iZKTnYFUjBV8Ut4cLOuZi5QIeDB4lcNIdt0ngCr30vyuiAF8W29zw8rTEC0xb
3D7BLTUUMCpo5FQuUPzOmMzN1feXmpzrCLIz0HcEiK+hlmeLXxADjUZVlHM96TcphhaBEoYy/GiW
R7LEFT//iasqHF5NhaWCThPAs8Aqa/j4jTqKKO13jLLqoNDXVogUfW7aorQbCO7cYpGO76crQaQX
FLgdylXIHWu/HsN4V3SMpXT1/tJj6ZJ/4xYEoEMUECbbzCV2GLlwPdpF9a2g+x3xiYCcIKzpzmSV
tKBMQcfL43GHX8Y3jRHkaxmM47tre7P04s7uNvJbfJCvWbMocp4kWkNrF+zvCZU8bVXJ/lhjdD7R
+7BMHQY87ExaDG25VPq/Za1/+OeQAzDaRzj6u4TUj94k7hlghrJ1ap4pugWGQugMkkhxU+f6jLL+
QPEJxCoc6DByX8EAdL8NRzU1s6aSPIyp+3T1DBO6omheZ0OwmqstKBKTSZUsUEKQwVgppCGWYdoF
1XUxZz/lbe2aTtWuRA/VsFhmIak2jKQvAhvpl84Eb7rmh/CW4bUcqhZMn/fOcqrg2TuwEtSA/lfd
Tdco8G/qgggv94SKwaj0Wm+aWAErsV2X1TRJZrTJJx6Yt7qdyWmExIK/f+XrH1NOuVSCDa2Gib3h
oTqbn3Azoxmmml2yqGhE3eVx33dGC+G5IllItlQ6RPsoAdJaBTyOXNiLzfyjQXvxLqQBXBijxzII
WPjUN4/Aj2C4YSzkqDT9wsVTglC0GFU5kkf0Fuq39FcEA7wwwrMM5x6VdNlkUgidzIhZjdcZjPdf
bHBQZE8DxFo1Dy+chtZ9W44BqnNBZg0iNJD6dDzgDmcdqwCZgBg1nXTkDgklS6aCGRO0blA8leDg
9TlT4CgS4GFZxymAE6wCcrMxiK+74XAwc1RVYSeIRgh6pld6UNYA5Qyn7LPEoBDnsI32IctICHfw
kRxdWuKKfokGU493Nrskm1z9RiiVhgw96baJY/u44kZ9o+3pK+i1PV2YEiLrS/PMHavHa9nx7l+q
UFAfwG469HENMgZFAp+BxF2WG+3pjlT3jU4Aal1U12FSJKsU11IBnt8DoXtwh5/y9fiJqc9jyNLD
1jBcbpf4bYvLMhr1+W8B3q9Vgje7tP6zDMNpa6W6FIeD8E0crnfFi1B2mjZrWr+w3JuAXFzyvjRz
O13TpViK0gS+uEnbd81x3+WEL4RGyyotmGVNuc8WOU1fYH+3lREIdsJNVS5cRAOoRcJK6issTIxI
l4gutqw4xt+PDoCRq+b0SFqagLHqe0P8Q5tg3EvvPrfO70qvFb8aFOisZdYdJITguc5Jb4nKMGtD
eCXqnPl4LoPvezx9a4l/CxzN58zWCqUe2LCbfO4mGrXBR4UHTFU2UgdE4lBpPqv/svydj7a+jwmQ
isax5h0ccOQEpracKa15tAmiimMdrWlPS0IXdkF8J47EK9CqFb1DjPKRbQQTgL6AhGPOm0e=