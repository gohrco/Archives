<?php //00923
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.0
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2015 September 1
 * version 2.2.0
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPpYnlqD6dGHq2m4gO3QjGYVIA+Wpy7htRkXZTAPFuwBoD2Cn0SAqdEEYophQOVqqZAU1BAY7
L0YxPwNNd/B8hWHHs47+pKpxvgmq5pKCzjKL5g4IOfWfm0k7R3cb6F87pPYBEVErOa3OSLjmjY6/
lKGisd9+15Eg6LAUpi7ghKXoCgqn724lvWgiL4RgsCOVKdFmZaBS8/kcC3Cxhljt5s3mizdbq0GP
xeL6qQonG8OQ3oOaD6/hEw57UC0s73BBxgnG0z+w107bNrRUZfX4b9sA/nbxQgXdEP51fv7/oHa4
neQl4HAKxnot3rLV38YdTDbGzdfIoElcsOQNNFR0JOlimtTi1Ks5uqMz1dbZj7dmZ4wgSkLg4lxh
BIN8pnvI7usnC9vb8DarSebFxAy//EmDV6V3CRbSw+MTczXmkP9LtW5MS1xkz/3DTUpnRwtdMa+e
jOdbdo/20VwUuodQcrSTtC1+WzkJCIjLcPS3RK+jB4H+d7fhG60Bk3qh87IcoWKVYu1MXUradsxY
e1tJ+2TMNZ0x4FiO2slMBdhUKFYhdaJM3sUF5l503QBaQyGdXJlDVGLz4yxML3AU59SBX92LsN7q
XoEgx0THhlnZ+nXnoUQ6QbfKvxiMK8r6bW0/UJD/19z8mTWjm93jxHMZUKdHh2rT6565IqA0P5x0
ygL7/+reSIALwSDjmq5momLykuYqSDYw/uJNuzLAkEOsLSIhkQDzPZPpk09k+PIlQSbiyYa8+gxl
c5ChJ8G7M/rcZyJ6u7N4BBmY/kCxaVp8WVRzY3AXoTK2MPym0+TDbDB7+Qe1wdXaVLuxZ4YGh6Xa
1ymzLuPsCsWEa4ZFO+HDv/YlcXH7n/sth9Nt2OsEti/nnWCfxfv207Y6rcTh+HTOs1NxNCnOXk/0
bzJ+2LgQoR+cPXSazqVRhAen4PGrIc+y/lCN1ZTU00DXuQ5j0oYCoo2SQSBo6N6dknx4swVUY1fr
oWdCS5RlL5z7i/sDS0zfn0rC9JHICB7RiqQMbgX/t2uHQNsinJOwN6p5Fnz22VZ+2uZ48RRZHWNT
lHHLsQ2RQAvh3upi7vGfpjdo8RIbpKFDvirdD2nQUu2omejhclg3fhpqS3edJ53AZrssW5CQjNGd
jqkgcXqmGjG0gMSlNjs2ZtH4KEkUhMrx9OYs+tlH/qje49HH+eY/BGPl5l23u2IOenXafzslSDOh
4CREq6oayuF6IgASExKd3RGeQxoz