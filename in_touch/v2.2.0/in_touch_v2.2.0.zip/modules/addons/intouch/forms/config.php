<?php //00923
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.0
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2015 September 1
 * version 2.2.0
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPyNjyw35CyYNX5zcWyap6s5bUEJzlEhhEjfkQg/9mFtjFu14rIzR0I86+ameEHCY1BBTNq9j
Vt8MrxjxZ7v+PSYZ3zR1mOtFZd2xhhqU2QqY5erlQY6vN1CSULjZFKgVQkt9D28sWQRFusaM0RkY
bSuzqoQKxOHoAnbLQJCL1PI2l4fjz5D2YooJFLo588FrtsUBgK1qS/cI36vUAj7jL/Zml5fBXOwD
XrRjORGldM83Tm6mu3ZnnQ57UC0s73BBxgnG0z+w107SOAV7ZWYDogNCla1xWgrdQH9zyH2Ie6Gn
9R3NRVLgGZ3VcHs9dnAU1sEHiqXu7m3UgnX88hQQnAsvvMLa7tDYu9aBHqqbEuQr/HvttHFMfhKW
MLMeYY2p7ZQGnY5t1CMxDuNJnstP3p25JgybpEQWjiziA5tyD/g/xlwfNFPuiI0piFKCP0wgue8Y
pRjP1jXr+q1xIvtRD4LmiDNmUUWoFHRoiu5Vx7sQBjVPjLxtohAJW1ImFYsFoGCwWUxNXEuDOEeS
N0kIJ0GgRK7RARmc8x2fILUmRZX3yY0O7XtknzWm8+YDumZ1QNbeZQQ2VU25aXS8X4it8k3rUjRM
XAo7PGoFKvPBgSVfJk40JOTE2d5ZTfMNOD6VAoe54/H84G1JnsH4aEfTKoopkrIYghU5fJEEQPsC
U+HNUyI88bQxr24HOTI52OmlXKMTdnqrzf1eSdRc0aEGZBx7xIJNhmETPgY3AezyBa3oXHYHsdui
aOKVvmY8c8gMfGkRb/TZIrTAmYlQ+Cp9dhK8LMjytXKk8lY/7eiTH8w/QO4ilnMIRwaKWWoWL9od
TPzYUNbTx7mQUuPN1a59jzvrR72BEGfhavCOPrOIY+fOangcZbPuiCLc9jK1d8jGm2xpkMxxo6BP
H9OuFf1xeoRPN/TpiTPcYI/copNyYcvxkjeKjQI4qOwr4tqkz3Nvk/ECE65Qv0IYuv28igeL1Ej/
2OUd4mKUDKzsPK//Eyz6T2JNrvkd9LbpMpCil0itjIb/G5R8oSG/KAUrKQdwOT3Pl7CrglMasaaX
fuIggkFdFXF9DXC8oskhQYEccJrqZDnpZ9uw22yx2pwQCdIPhnbCYXUVpqhaPJPI4u9lWpF/jnCw
N2uWQ1xDhODfUdTlhW6AHYA0a46/rvIPsHKOZiFE1K82r6R9jmDl3/KMrCV5q5N4m96kj2j7dhVD
Y4baCCLvdeUOyHSpWDYybvu6sXQw6heSJcewrJGb6eQx8y4KLdmIbzV3ahDTKXV0onTUSvEXf/7X
Y44ggGJwqrdRqsuWS/uJ1gOQXqrI0OWAlfLbEahP85VDdumvM1xER983t0wGdKERIq/W3Zw+9bZG
bPoUnhWccqMZtAWnT65mxklIwRy4m8V/VFlgOFLFDQMaQfdkSNcIKQLRsLzQ5J9ESZyswEmEOWNq
8xI+ur+H+Cb7BnDXRaFKkz9EWG32Wv1sxwiQapH7ADVxPi5hdsNbjqPy3tXfU/OnAKzDUaasfyXF
lL5i1SAqDO+46SaLmsql+8nm4HmJewthT0fzCfF3cNnKJzN2dINTaK3sDKUlJbWhaPiCJug97Qn0
Nb6052qxqjpmo6HgrAEgX9pqJiNvMyz4frlg+V/ZV0eOXT7mR3qF0Y5WeqF5G64AAAsSyGhGr4he
crJ4MOQSIKFsJ69o10tSet9dMTgccUqFh5QtS16BzRYxjqoneLoRNjNUBJ7dOz4miwtw2dghHRjh
Q+ijf4CWRZrVwHRQ4E2WOrqei+nJ9x2+6HEpYQA5POhsTz6XUdgJxhTQRiQAVvpUL0i3fAOiFoa=