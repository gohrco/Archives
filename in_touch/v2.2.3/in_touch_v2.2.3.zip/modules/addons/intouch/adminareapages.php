<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.3
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2015 October 27
 * version 2.2.3
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPzMPoGyeN38W8K9SB0RbzEEXyz520fWVZwMiB/vINj8OfWsYKQfX+x2A56E8SUxyi+ZXTSmx
0BKu2AdOcsrI+sfkcISwn2pBXOWX4Q7+xgKwC+Uce92XK2yhDYEo81kovfWhH9ni2NZsZvt2n78i
EE3wiF/ZTyc4EwQh86QrPOJawjzVz9O8O/m3u+H2tZU+kurA1frahWC/3wmDmMINmLKCZa9AefMb
Dh6MkmqvRhrXWwxr1pNXjqbdi/zkteKjOlWe3tCsvAPZ7Pa2oR+4cwlbLidVzPqbWRT9PpUzQAo3
jgkqLVDDQ+FPIv+XYm9rYjBf8IIAn7FqTwhK4wlLHxaXHrpgtSLcYrKfbgIbZ/QYXp1o8X2unIZf
o7eZY0Y9yabDj0xOWTGXxx9uu9l2Nlc+XVxEPlkzK4HY0kBs4yUKLP+XJpQuRy9oOiwXJsqBVlGD
fv2+ww2PkeKlN7s2Lc3JfWP+1VLh0Qkh0uX1ynJVEvFqGQyDUkfpSmqCbrvuyspo3AUnyXLnxW/d
e2ta5fGQdDZ2dzqNBhwFOYRPJCnTwC5LphWXiHCm3RBvmgnn7C4k0CoVE11KJCe4zBWAMTb9Nsfs
ZcMET+vlNjtpNYUQxC1ghfs65PBCImJ/9EiTMYbVvI7Gwx5bKEmNwifKFGhww6hIDO/unCtNothz
WXoLpgULQLlMCYnrzqPAZb6CSYdDQSz9jEpMQ6ahP7zAt4OYjUoHi1OPsQK6mnYa54hqWKARSu+P
z15intYgWF6GjC6kjOqII+AOlibYCPZa6rw1sxt3dYTSH2vA1nnW9cfgbaDfqP6GDpXavECHGCte
NQBsKmPUcPUnFxjR0TG3YH9OPC9v9+b9pyJNXZIiuOosBiPAd+7aI8R2bzyCG81flAr+ryyUXDu2
SzqzQbuPBdlIkNJjXJxS8N0ECa02YynZmETAS5guSNOlJVZYA2jlQxoMel/pOn129MH+AgHyclF/
uLSj1pus4ZA7A+6Lg9aPs1oTkd6ODBAxIGvzFxmHuAG0TTZ3EP0QZ7fKOd12jtUryJfiFMp9TxmL
4j8dRDuoxQccwMIVOHDiqvppoV3+AwlD7qrQg0kCfHTTt5ZcxS0/D63uJQOr9yS2wt6MbdgRj8Fm
lf2hiRBPDeGo27Hdt39MYXdfanDjfw7n8NyX3L8pytuVLqrPDiHd6o670GumTegPLrg1iPjjt+z6
50d8CsZ/Zgo+spHXrlNcvgTid/Y4ijk4VFROme2l8mpzT4MjzVndjoaeukacGsPsK1lhj+tyTy8Y
STLXQXpvuML1RKcPjTidcjUAKhyYNjIPUL4K/mOjkQf/8uUJixop5pu2ysbWnsCbdjadjjMCvqnj
HdjxXZyI63LLaI6pj6Mug2lQtuH9Q3gkJPZu56oL+jhBO1N3y//IiRw5kflGZ/12CihPpj/5DASj
mALv9YI0g9kHxLhxZ9PJQO+l+DAdJFG3zjfCX8M0cMBXLxo2cYJqka4D6XibqYZRY0XAKjjqPxOz
HoNoC6q2nkyt0berJVYp7LpgUbpujinl9B1eO/MDTW8zeklD0wnefKl5+qfzg1eZ6TnyUH+196xy
V+kIJHI9XbOf5xyFMw+oyqOOg7uvKqzzkdktZT9D1ro0QsL4ZulYui9shukN6WcUUWfn/OPJ1Wt/
fRCkTaFZ7Dl9zO9/LG6mWRFIS/SVEUfvea+WSKqq+PnAX1G24lNhfEFzj9zYfbmML8KdUI5illqj
2pXJawzeOAXBOCGec9VvUuKDr+WpfllplkCHsRk4m+UYdz1l+Qr0EFMZ932eO8N70PUIJlk2ufw8
40GSI7N0yJ7MSCGLwtEIbg78zqsIbmnWPmPT1Wq/OyJO8d/E0QkdfLI2Tp83T5Dyy41nqYlxHQyV
c50AEYRG5fweJdjxiX6AeiNpynmpSl6HPEAihmYZzod9UusKPVSAvkOYgkKRLEtYG61sRNyXimLM
HuYoyWIPTN67FiywbjYsMB0j9YooPpFY7vHPRVzGnhaMYLY5OT3dFLU3sZu2/Fgo9BaEwl8SDdt0
oZhe4+DzOZQu1nZcLZBu6uDqO3QLuqEdyw1m/g8V+5eeuEw4tef64esKDbacH6lc3i0DABdq0INL
cTm2r/KawJGD5K7Bi2Ud8XN2paVEuehPUTiRi9lcvcsSiAV7gvWOPb06FV+QAELlpXyUST8ngrd7
vr91aFLpvtGcBdvgzKs4Sck206w5ZMx9dBrEWXqeC3DSqMwJr2wnSBIQeyMFwwgN97TAVFUx8brS
NrK62MHTqhk5l+FPnOD2aX2NyKaCWkto20M52D9TaOZw04YdEH/z0Ei8AhqNoFBRsYoMX1VfDenI
FqUJiBVgCODbFxTxCJJQWFuChQ7PFMZGzysY7tDHGtvp8NB+iljbKCQje0tRAjz53XRXXoJiPSmd
nfCfbtdmkvBgS8WDkGT7ZP6Uz2ig9mVZZ4Z1WiCBpHAypM9GxtzdcOhBq8/exlZIhP2zke3um2mT
T0v8eSzK78hc+Y1uw8OIXuDEmxXDW2o61FfxDaq+H0W8dz+CiOWdd6r5p9THZtyB88/tMkV2pKd4
3hE41FuH54QOiHuBA+bfqSKWYRVJ5Y2estvH5Eqvz3apaC1xDfA4MGoI33NvhmkgJ/XkymEYgs5A
sovOmbcjpyzoZBOneqLBYCG34ISh9CCApR7gTxwwmK4hrMx/eBQXHqwSPv3BVZPFGMjO71hVBYfh
YBGa+luKyd6WTq6Fz1kx2ETZD1irG5lVAad+gOieBQabhOPBSsxfluUCLt2jUF7uZp255pqTjyO/
ppQK9WY9b1m3SLOJcmReGxSrQPw5h2M2YCYPqmK9WzokXz1aIswn2prZi7fr6CJJHSKFWRI3qsoS
MYr1fG1woJfzMLy4CWxCntQPhIverMnxLlwUgexDzrkwdtSQtPD0TbPtODZeEMyEzATMD2yYos7w
7g8CAR9b0YMQOdoVr2gNN5q+QoIyeAObNClH2pyFUnUwvuzng3a9+QfmYTkEiEWli1QJxeldhuar
n8uwK4WiOa2CB1+8vqpuxJIijn4XMbu5GBNbhPkFaGmw4aypWml4767UqCoEzh7NvT0PNeYrEysm
ZyJUBUdQXFd6u5Mh7b1FWeedAbqVFPSNRuKpccdtBe0WT35so9UR2j+qACYjKASAJ/DRxof4Oav9
Y4zO8OTu29FWRJLDguYD1AQvv5+NbNH8KPF3A2yNuLkO+h+Kr+nn6HOH1h9n/NydRaG5KxD1eEs6
kMPq5UDHFZ6E7sjw2KVltRre5Ln0+AjdRiY/PGm8/o76OCJzLv8tZSksTOvqpYMLIG3zhn768OD1
kPnqLjmULPiKDDFTY8+8XB3Bvs4vXSo6ihOjjc3Dhgb9dkLvmG/h7BaP4LBn88CpqfdOEcFgvcfd
vML5cVSmKLq0yUaDBWncQMUIj8LMBJNXfNcQp1cpMjxWgUVBvN5myAauOWsKzIvBC5Okw04nsZRX
PyJ//rhRoSwIJTnXcVNt7Kd6/PP+4/2UandVbGR0/f3pStC5T0pj3oTgGpJw5wNC2rgkOk55Pivj
gN2UykBYT1oTVTGWvaVnc90JI/BOi3TGc+MPWX/2AHcboIaKY/seNyPJD4zBApG1QeyJdLV3OEU5
D9Oxndyo3OMZteMHzNipQqY847OYTDjAcXMwFfuIsmky72WNa+Tw9qXN2Gxs7cj1OR+kfEeC/cFW
C8WJQPBxq41IBhPe/MOjQn8clwZYG4p22yODSoWXTW9xJ6YsDjO0elZqr8JuntOPTuoHLc1n5eIW
Ga3dsOjzXtTsaEjl6PL0y0vuqZ+KuRZLp/TC3E3I50PsP+KHg059mnr2D4DrPCf976TfZBYAXDth
gVWlqRjo3VgjI7ww64gyGrvsW5cPHLvPTPUqPEhY5cg57xXGd2MzctFn2mo4QdQivE0P5q6zUZcn
O/eLR91+GaIHoerGNROJhyTf30Wg6HsbxuWMM2HbDzZ9GbDi01MgZIFiI+MtWZkCGWaxh7pVzyZe
tLzliGuW8vvYRA+s9PAyID73a3c3JIr+3Fm3PP2M6dLfNQ5u7ZvQv+aCi6a5k387ZQXVKcvK0PCE
UpMp/xyEyDiV32ug7gQpmZU/RDmzlGU9LnQhtHyJqYjsbaFRtNhgw7eitvsxNTv3Zv80mvH4fsnz
/LiMAg236Xt7cgpvhsXnsJWBS6cphGm8+6IMTAfMqbNJNXemZfQ23BPCh/dIYwoBs91zE/jf5ciP
VcfY6vrQshYBGOxd0sd6duH17ixzBmXaePs/pE7or2wacu9yIdzqlBKISBFO2AJXLtlIIOk95xg5
2SMjohl0dBZqNnmGyvTFPW8qmGVH+mn/YGJuIebr4e7iVon+sBOKnte3Aylap3GpvqJCquYuydWB
iPyKMqg35nuPocFxBgrC9jYtZpkLQ8PbDwnXRuiZT6a5QsNMaN+G7Dr2JsG0IkE7MTOOlVawc2AN
tUzKPgHs/hQV2eflr53m9BS0WG0LmaYQdWrV7TynczCG9TSTf740mCFtwuBQffxENbphQwAhkuRc
IKn/u31CHhfTZZ1XVAto21+2IY0ttxeZhXqxztQj2O4GNYFO5TYvbLKmhRrS/jEe4fvVOPz7HhA/
MsxVxisVWg5w+l5T+vCX+hX4GgDhE7t2DTmFP3UoRUfQZqPY+WEa0KpiJgxo3/NnUR5LYiouW9S5
u7xWh7J9EOTWpWTTBiQv7HbgSK0Bc8LbG2Wvm6nMkxSqjKBHGGcJ1Odk5a9NrfMayx+mDCLNa99j
OVNj1+lwO9qZ0/+ba/1cfzH9JYGBUMM3G/+1PFmjxaq7d1LbPJ/Hio42dnbaS6gqPtpttr4VfjlX
9r4Qdd8fmvhLXqJr6R0TtsljleYXwgxo688aySzSoFEiJsXySEyPtCLFDSH2JN12TkmGP6hNiz1A
UtOcOWG2xlURERvPOe3kPOV/m3rRhUVXoS5jKlvY67AxSElcbU0AUVV3FtRXAA5++1rLitzl8zIx
RsRzn1lyKg7K7GIijpI9hmp1d4h1m+jTIfn2kyl2gUdXE2OPAxN9E0HsHa72356O0/cDKp6sIErg
Ms/e1lRJHw7gVICTFf8QvZG0/An0CnR4wulNk2yGAYijb+2cPFK43b7EhsTEl7+k9Sn6k135XEbC
y9TWUY/+OxVdDZjd+KaZ4AvzFc4pC0pEYNEFRtghDgKL1LxR1NOuAyB6nVw/qMC3ANUL6Bav43eI
y7Z+1MwtIIkKcQ+jVYcBw7F9/OQe0c3HgvVmqWAynF2Pj2xpp5uVfp9lFYhtp16l5EjortoK48jY
S25+j9Rhf/CXfNSfTqK0qCv48qSaOsBTyzSieJl1Taw3W3995IoeQ4fwg5rS3mwaRXF1YsOYVbuE
+RejSZs4PjwUix5gdSV73/+cPLDqOb98C1wbVes+UfYL3UwX7Hv5OxOxm6X6hRy8GMSDU/Cm90Hs
ML3YbtFazb5zpHQe9M+BUOe45zvs7uPH80Vz6NlG6o5/uzql79p12CvqLSWHipq/9IuRK44it69A
GtmH57rstOZrL78q2gUG4+Mjo17+3m/+YcBMtdW/fOb0dRlaKsNQkE0YTjhOt/nAXARay4TA3V78
W380LGmcyc+06rCYI57pGskgR5sGov81r5v4BWp9ZBMG8fqAyqROv8/047DgoULbLXBRiKqWE6sL
CXeHZfKRboybr5BnMW3bRs9Q7abw2Cu1oA+7gKLDCeCli+H/sTthZ0F4zhmc+ngT3qwl2uPYWTXJ
RyrJ/jKOdSdeOhZE9xg9mCPOQktLfgB4M2pAB1wyo8aV7I03Sfl4GRLY/And0OIcCFJUBBypaHGT
SB+JyGqpBRhd4JqRG50tAN6lJZs7mLyXw7IC1DPUKpQtsxHVX4hi+ZtqPhYIGcq1wBvdrrvMEIFg
cpZw81zGO1SnCc/WvJO9F/6iDbONa4HLmEZjOkd1vTgzuNLD7T9Kenl24Bj+A2F6+lVcsi6qAe+S
Xshigi7pnyg1LcHwliqpJK29aZKKUExq4G3O0eHA4RNpuxA8LZH6NshWoHKY4DYXW/bFAZfG79ba
DE1rdncqs9Mc1f5sMloNvYI54y9O6GdVIIXXfoJNevZu1TO3gJuc3FIeM5vmjlKfh48j7yqcuxS7
AsqAuLKiBZW0KMkEVd6TeVEqvMm8Ldia4QN2vXCHu0ruz5GJo1zE7VqlbWtRMqLPk4FD6aS0jAH2
4ZYRrzsHAlnJgYPdTwrcED/EKEbZS4a6L+eVuhjDE2Rs0GsfScqkmkpWWffAQkm1x7ItY0yUIUeW
/A4Vb5EPC2ZEXUDLV69khmrTkegyiD0fIoA/FIjYxJ5u4yIDfblUMnSlGLy27C1SqIPyXYkunaoh
dA+UXs1pWaBbcdTPGh+UQYPUCReaSK+bnkjxYBcBJ1dEI+ZLJoS6T/dSsaxAh/vfldEMf5bQxQo2
kaZLeZUHvv1Vinwomr2CteJHM6/ZoSblYNNDlddp4vAy8HShN82t8EEfYF8pPA/pvj7hfY1QJGcP
YTOFOCBVE8EEtf5vbrE9vs+7jV3jA33MMVJq9hjw2aCzcCYZqq5agpIoJJZ9EZCxNDWtEXTE1MbP
dFrrUi1RJSxTw12jzAukWu3DH/DOnjQpBTgy8JUV/ao4XLzaZj7Q06ny9ikDZnSwPhqcLfWmTt+O
TeUuo3Kb4BT5nv7rd24zvFLyN+XbcejRSXD+DIYWO+19HzqZ4xHHYHjsIeaBof5S32/l1gaFZnmv
ndnS68Ltq0zbbK+P6jnH2kXUG4/0Sg5ucJg5WgPt2MK6fphs8JB9mjRsYMYATuh6wDJxvVauyLti
3CLebWeV6Ye/xfRZeQK1pQHM9YJpqBGD6LWm7DxfdXV+IF/00XDR0o42mfnMeghiBPttG40IZ3Lm
sl5hrB3g68zhbjMw8hNNvIpyDgIQaCAwdeuDVDiXtNF7HF4G2f26miaRcYpKejjXhvQgtgpo1PdT
DKh/mJ3NH7mq7fPhnEOaOzGmHFMgN9h7yzpR/a1Ru7DDnqvZxGRyNGk5bUgi8gJZKNkCb1/RDOdk
9RnJcofql4QdpgMt86WTrWatxZ7GcJDoGZO+TwvAOIA4y3jIW6vMl9hijnbpDU9jz6JxmsaRs7Xw
0cZ+7OGguIMaUt1AreGt2Ec+sVjjVM+SYyd8jT9vfcCvC9i4j7NvR382Rh2guKSzh5rSbqSPjy8p
0FMaOMGg/zNP0etPsdrNLvHi10jLcijiftmA+kZSvbxdRGPAUrcNn9oYvKV2r7/AFY1u1HVsohnE
0BqVmW0E5E/d2mkLCbiDwUfJtksqGTgm5B2GMI8c3RMFYd7OB4BvKD7LgBznzJFMcK+CQHrbybpv
c3yacUTccV+9pEYU7+2swQqCMnoKpWiQq6IwGrYSyBGdVhigyV8Le/XX1bRIpm8+hzI5cNIqGL7W
57klLlHfeR2n/dmQMellwCr3lMmDZuPrBy2UlH12rTOcRSmWdQN+5+WhHamDS9wqSd/UH4gi0Sbn
YxO1+XDGsfuQh29BI5x04wLX33x4HE60c9qqbTDQhBJuvnl/JJglppMUFNt8508umAjGZis2vRvX
rAaJPuh5QkfPbWxVXiJFwTTObmNDcjsUycW7vq0lrQUHdaiHRVuds0VP0qIkKlkjoXmrSpzRXXh3
lehgjkQm5xVeWraOu0XDpsKLIf0FpUcEhcjSqTrTko8Bj4VRp15MOd4/NytM5QvInlQlA25YfE3m
d3ZO0+m7QFpFM9MzkusUlYVPW5lBgwszfeK+i1EDIC5cS5zELx3n4OJOavHD+SbId+pW8vYrS5Wt
SlFmKYL2RXl5BlZNJaML1Epq2GuKuetBGHFJA8dnCJUdRcrrACDsr/3If4DMqvAYaNlg7gZNrf9M
mUxZ4tCzHngfjU8MKOqIcFF4vyaOO4HxD3autkiL5Zi6puT25ZJCio2qCQjyBokySL+tgb4B3Rm+
490wl3XGnNwSFPw+fMdaKAQke1jhdIXDeV0/q/fEELlPbk4r6nWkk/tcjkuQ72BJydsh6hXY5hqn
9XhtrTs3zvNhMvCNwPBqoXrYdF4Qpr3xgt8GkjPHNT+vmm4cpLxqwLhroLSW053Ggpc+n+tjR3Jy
IsQwo9czjmjXyjBfHQZ8JLYVJlo9HY54O8r08UFA9XnN8omBLMEWsGb74uv1IQvIr8z12ucO8QbE
dtkF9kefJtw40mwl4pvtKGozPry9hRxGs/B38Sy0z3J6CDmXNeVGtnlpaQDr/rsVr8bKZ1wT24FH
F//Yec6E6zutf2H3XigBbVDkjeKfeTApDJY7rtJ7Bwe+g4+evTV4gCtakFIOweG5dCXYAt681TJG
4qVT8buiGAzUEm6ds/Y7Jxylf9LmTfV35E5DfFVuuBtsu8j42Csyx4j64L8n03gqLQwQoPtprwQx
AzYnC4Nw1vkoXozNyCmrT4xMxed6D6ZWKsYcKWfTjIrxyD//Yh7zBILYekUwyaUNn9JX6ZHixGZJ
BvxpQmLpT2y/zMEWfsPw+XGocP34Ili9CNezJ+O8WtwAHbtCJq8tVIwD9h9rQyoZEh/o1mYbqnN5
559RCHsXrmUM0dkjTaoo7daZIssHYxLRFcLy3mRzogbTY7b1XxuS2Sya8ju8eM3+nD1WXRYPOpOc
c30iicMepYDTEx/o0Y06Bl0TL3RXcD/4MxbMZJF6XeWYHcZQW8sMr613dv3OJp9vDEU7LuT6E/3I
CTNpTrTjw18rDxUfuD/zSTsKEp4taOqS4MM7R8ssMXrarP7HoJ9ucwf9fchOAgLdqXbgLu3QMt3I
AOhtKHVkeawrVrOpUe9HH9aUuaN7NROruzu8lPEqpITL/hh+kbi0LjYUyx0JcYGQ2Vu83lLin7m8
/NmxaCXmfuyQbBhPPdc4EBjni05pViA8dtOi+8eLe45a39HmAAXIjtT+pGJbYhoB4NIz6NWQ5F/5
g+mRlwZtbr1q53U676jjQaZdtyS4cb3UzePxnwhTuBlWlxSPEwhDrxISYNiOVWwn7JL+ezub800m
P/LSqXH7WPvN+iC8QDkvicmPi/5nwEX88YENGIdxiTnNgN3uW/a9yVVy9EQKZ124Qq4sM7KxrPqg
uuKzh/poZzqK/y+GtDiR0O+72SblHmyfwKZ42+HMvwTsKP2XniXq7Cbfu0Upua3cZbbolc8t3cwQ
+E3s1cSJNQEUqUle3vgOSO0XzvjFN6OfiWThyJ1rxZPLXHKeP5wYX+/LKjYlXomtHxa1cU+T/028
PYGYjhVl/L0VeOTIQ8wM0QYIYz02Ojajq9n9/+1BwmKFOp8g+Q/SJYiUNjsFArazbZ9QoT0A0W1+
Qtw28i58DVQPVZ9qqYw7LyADMFZi60nWjh3wBv7WDh05JOtQleYl25HBfKjWVwJF7VMKFvYfmGOL
PbROcQ2fFPPVOpY5Ak/Pn5C1rhasEU9x7+VCfgXxEUde2FFh+qCzi2SoktdHWm9C4csGxPkoyJac
WHvUODMh3qvjEGMehenrU2PEQbXYjUvqgs61XigEXQZUHHtyGq4Drsb60TirAFlK50eJ54iMOjlv
HhkPxl/YG9+9WA0SBZ3X51ChtsTWhKl29zqeEf+y68rw1xJENGTkyh+0ivaf3dg9tFkdSYfVoNx/
qDdJW9f3mEzUcuoRz3eiP7EynaS9TluSKJ1FqKeA7zKxQ4hbyKA102GUAOE0RNKb8c+VpnlNSqOf
G9PEajRrCosbXTd3bpGHynbyGZXBnHEsk9KmRCeAbtnAXyNK3zi5329/0wZSc4VqH0bzXq2u035D
UdO+NfMKYdtmusJf0mrmUjp0ZjMshZhg5kIB81PX9Bz9RlEseDlUKrPsJgTnUz9zDqgNZanCBKMk
KvN8i6Hx/KMdZTC7NmdFFNPYTX56BeCEUbw2p6E0UxeT4Q9n08k3FWbEX6EPK6prxcm8bUSCoDsv
hGDvJKhi6W74e6kw/7GTVwZmbBu7kox5jT5P5PQqWFH6Pkiv0y58h7gxQ7YPtP1JV84iHJYhYdau
hIcOH50PmCSWPqPPTgVPniEy7ieX3Ubdr0neoWrJw7b/wEYtMVbSTcg8cY6WqU8ZcDDG2oq5ZZwq
wbx7cRB0cTvBYV24pqEQ6FY4GO/WCd42zd/w/0WU7wyb1d836WJ1N5V7pYtb9tKKJi/sO0Tr1iSw
iYsp2YB7loYsHM2rnG==