<?php //00921
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.1
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2015 October 9
 * version 2.2.1
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPyl1jrEETmnaGneYSD/jXLMXaQdyRylwof+i4DtQSeRvl4W76Gfk3fRAybNi5yf6Ni0dm3Fw
IkWz7QZm8/fviiIyg0yvI3I8fZ6SRSq0gdQ/qwB0V34qh+wLvGqoSky6345BU1BLyvXK2nDXBLor
jgpILUeSIiAy/AC2VP9M2PptJmqtEFQS3hrREzotBf/fUqsUlEWvCCfH3o4tsY7GEyE/utSvy71R
+6GnEkKhfNLxGFMaGfWMelMfFv1dL1Dd4Rer5h6OgpzYCHb3YlKHbWHO25noksPZ/pFv/MWqgOjp
8TWv8FHcyJ5hgNPYYCrWNiHUvDfJQwPTmCzrzh1NJ9gsnoFwGJjb2sumdB/OZJNk2T7ZcHXFBJUW
4dTec5PJgNGLlBNoEVXPEcYkWtWjaudW5e59p0Snu4ltELRAx9G6AtgijOLBWE56hKWbWdv01TOx
PUNHWOv56202594jVswXXdXtoUWkeOJ5xsVI8rVJyuC+pEUuA9t7/Se5V52nV2dgWPfMK+IKU9zX
+LaXlrXuKPzoDthzgsdco3ZM2d5PLQSOjbof/5Y29c7YToPd5yzmfcYsJnKY09yPEHUdNkn++qk1
3ap3B9N9sPXJo054pZa5rdnBNW/BQdVeOPcfrvK3YCxDjH1G39LgU9U2c365U8NsDicFCVKsjBu+
wNfTRFaGXGCIc7xPrH8LNnX+LG+bK2vgroieFX7drMAoCJxaiYbNMsR2xnrwP/37Kdys8SvIn0/m
sSAMRL1NTnqqJTAVaWVEjWpUogIhBJRtD/mT4cgobkHxJTUv49fl2qA1UyNpKahnwc9pIlLSwY0r
Z7X8yBudJNDLHIctvffTaV33x/zWubUI0WWOOFPQJ4xPI2dF9Rd1MamW6sWXaLrHyIrnWWcFyKmp
QcAPC//heoIs+d8ekbOjjMBKjUVk4exhYDBdEwfzwaS4HIZed6DdZ0L90FQsKk9w/3QN7cYlB4dd
ZUlb49vKTI4v7ONFFJj2MV7HTvqukGZTw3Lxv5EAO3/ULfon7uyw4QxLPZzRPu80UNmBvU6QQw4o
SqBX8Eq5z6/q+6ZD7cGiDpyXKcMpdKmPk1xsv1/zygZ8+ZXPdHfDgjiRXvxkSPRhCDKFk0FkgVLK
VjrtnPnNI3hBtY4PzwzL27K+kktZuHKvIdEaa1hKngnxwB3E6DgW2oM+UKPl5PQwZ7tRa7LLEsYI
16nCvSyRp0aTwKemlCtH1ay5O0cyR/QbMczayCq3KZiwspQKyct1UE4S5MAvXBg4SwKVCXM/tNo9
bf7IvObzGhaBDrLuHoBO0LDgfVOkmKgRVazzUidUNlDiZxQH52aOS/cvDx6Xk6ia/wzOvGthqVIz
C9qBw+i+HbMq1OEVt4+sVt6oNXdZDCNHTEdgBu0eTO/aOyYESSYsqDspHDCbtIGCi6X/otzddqzw
TC3Y9F8T5s3RjaTYUiQxfSyRPr1uO1vEqa6F5b9mmuqOMfBxdK5UX1oaIc57qhx2shzBRIF7tptJ
j11jutKUyBnNCvG1CQ752JMf02J3WODJraeHShFQrxZYCc4wEAA1+/C2K9DR55r9DB/2Phio7Bma
mItGm2mt6rSdLPFylnNTcf+6xpaqj332E1vYHVPz+xhWH77Q9VhZlqRDNw1Km5TZdZIaUZjcul8j
ltw4k16ijU1Rrs8p59+hwi3mnrM74ZtKT//W3opJRtuqS8WcmOgIhdDQPPgxMQpYgYy1htWUGI0U
WeL60OtymS2nO0m6ekJxUxglWMffq/NyYkQizxWpMZwQjbzinDOhR9bDowOvgX08mBasdrqgr6Az
kXv9/XtXzNC7W5A6PsKL7LrPGYo7ddHL91XHUEahgVAn7c6q7+or6l6uLmZ7cNEuIV3HAqeQAiM+
WRA/3fMdNHghkcbW4G28muv6vghcsHsBFmKvoBV5qOTxyvqO5pgj/07PNMnjcHeYKP8a6KrRlCjP
vKD5iGuAkQomo/WXX+MEcFUbgLHAr90mj1ZKzu9xjYosVYPxVu/2JKJ/ORk4ufkmuceN6yXBUGP9
cBct6wS/oJsoPKMc+S8pvx9m0f4O0qTvCFd43pZc/mVcH4VTvME1jQEG7FuxRLntn5AEhOrGTZk4
EcuwVkTnIdoDhR25ZKMNeFJtGPa2U80orUsxo9SRKaqCUjw4SWckPeqMS3N6dy+LhFJFgr2q/Kf+
TPPg7txIXImFI2AYgUXhMqLgOEAnU/uvv9ZJa2oMjJ5ymQFVByFafDGthNVkKUAJYt83J8OlpA/C
HR/KwW8UMYt3OKkGIB9GXN5Su60UPgr7PA1l27ESILoX+n3aForscBZ8lig/4z74QfWoup1LzXrV
JNqBgjWOcsK/fbjsIla4H6q1//HmxjveVPqYG7GD2im4lkiCVlopDrZMd7Pe1xeEUkBQCxOjtND3
a0UMSLfpPpAbr7TBTInVSwnAQlsFc4u2LQgtio/oegyYNRL1maK3S5fZSfLOQM1ecURFg9Al0G3E
Vly9AByp1srPb8gjYv4aYKH9Lrf9qJBjx3ISZ2bGDwI5j9w/CquXui9IgslhLx/+HIGv747L/qP+
vAWIhkp+DRIdW7cnqcmSIUzDZKGjonGBNqUcUjkTt5MsTSs9qtiuk0DzZYCbbkuo42Oz2rK5plOr
rCDrqq9IXldhNf+YqdUkbLuJRQtGUxaQG4NAKEx6VkSXlrrBwj9xOFe1w2LLx6bWzt26jR5OLf69
wjHZxt+Xv3OZS4D/tFQ4foaxfg76tCcPDeqSzWqp8EYc31zoqT1rtKZ+uWblfLwTz+PtS5ff62dO
7gjJFxqZ8hAuv0JBr4FHA7+orucD/qrbI68IxZ46YLSX0l7VWLO3HdtMj5Kk7/pjGc+m6DuZrrLz
eWFiz33NP4fw8Z9jcI+/6MNt+5PHLyFpM6tmDQvudDJNvVUquFECx2ehlgSjDLTlcMf/gmk3X7zK
IERcXalqB2SkMSx8HxMSNuWgY14QgGSSRq04f2PC5hEB25Kdrg/c42o/9HKcTF8J8eirTNzgD+8g
enEcKlkdABEvgNf4cTYzHgo8TfssVck7q2w3GV/E4QAbFUJWcE8vuIccKQxDLc9Iz67Fiyv70rsX
05otV+yZ5fJv+b6vx2BbQaUPPZLnNnX07+m2p2pDKWOWY0k2CSURI45hU+sWmr0h1l618bMHLLp7
rbyNQKgVW40+I3trLJZw/TjD+8jOoFjisfxpfuQw9JxyPPiaG49wyE8XScO/LXDjKOngXePshf19
iM4n3Lnyc8LDnj74eeEWLaGhmhNaoKB36Yv0HE9ESL7tEpYFYbIydFBMBgNyvrUNktvdcdbPnBhq
/o6GKpPnwElL097KPQJ/kWOMjBs9K50sfSAxYM6TmXudPw6Nd6iWj6lrDt6h3zKcJvqCCvN8bfu3
XCiCyIyRJHQD5htwFl2Qs+UBLst0j4KtxBeLNslFtaDzC6p600Mmym2hyFYQqQyaX9yBoXNojg8Y
0S5Arj0W78R0PjLkg2vaOUKxmzhfAaYxPmHo/HHt1Tcrl9EfOLcGmk6/uHlWmEfZ5eNhQvgcruID
pFzzUWdjZzVU5RdEafvyg0mJwuCtPteRNd95MnvhOgrmJkN9xlm9oJxttUOM1uMnpqrXAGOxJ5TN
ADlbwXsbNlPaNB+5uNiWCjJ+4Hg+dVygyPVCxn8UHBdwhq3oSOewQdlTdOoflydBUZfeb0M+q3vJ
EUw8tO/xbLS9sdGg3XAIkO/E5JtVdBVEycIHb2DrxaSfPWLTgkB3zYIpTPb43isT9IBPMdpFr4AU
z7Dty3dTT+57tgLwAcS6StE7+7p5kRPYp0muZvC67+3xlISGulM28ePUL/xYUlh2B5kn7BnunyJq
y4MviOyquwbUIHwIFlRzAoEvLwtVL6PflEYLLSWiN7/kR2wIkxApljY17SZOI9o2Lo7jKlt0JVjr
JBpGyiAQS1A9jU9bMoA9bXxIaPE/rskVsLZu4vv0v18QrIuek0Cc56SJrw7ZI/RL2Rs0ckaZHyxv
zG/McEkTsF+TffeaC3XnGPqzsPAmUsJ2yyKsQNwYW3VU3/67bht5tu+rL/8vBnQSj0S1YuSwUmt/
slMhUMUHsyX82vw001wPOyGoUGuKgsTexsIuOJPCpOv5WCik5hLMP1i/rOw0uNs4L+lytP/9rgx3
M8ssAk8Q+7SXthBRM+jyHx4BSECDlkf483MtvC5BHY9MVo46YzDKw0pEUSnoPPlylHiJmzleYNok
V8RuGGctIySfSguDIfIwH4tghW5r76GJvtiFBFD3Q2qODdocVbld9daI6gGZ2D3jfN1eN0I83CF2
sN7vqniTKrOGdO1OMyFyENpTyyfXxjedvfz+/A3QxQY5S4ERQQVozni+27zKlJCeOigQughsOtIn
zuZfwriaoYgEcBuuARbS/n5wXZwjkfFWkfpw25c6TrN8OxPNLGcJZImoOnxE0iLDA0DoZeX8tyFS
2wgq6VNUAx4iho0xbRZqm/lmhlPuZwkKC7AWFfIgBY+DWrS+9jQ0FKgJYXgQlnLXVpHPeN0tqSDZ
KXiN2I+fIObKP6nqRHRCpvGoqVdfcVpXM1BNG6j7+v5uvDklic8DvLMNm3E0KELq2sQME2FDBZ97
+3j3AabNczWfipXki8JdtGN+1F9BdfgtVOpbi0w5X04amn1mfr2vbocNNuC+A8m276XMGVB448Af
bE58ovJRabQ2EkpD1w4D8hLk/E4rZSk25pxIlBgHOacicbL0J9MIgGEkyVT362SA2h9ZrwNd4GlA
rmoJQG8MZI2WB56e2goJ0Lm/OMe74l/85g3JV5FxrGwZCE/W+GtUkKKzfw1kEURO1GewCy/EaRkS
cfc2KNWg5+n9C02XEtAVmsXoykUKfQ4Ete7Pd2CFNwTaQuIrvGHCggENM/BnT/gudmn/Avg97i2i
cI2lVA3/6j34mzlr4aLofZEtGP4UzHnZ5qDeWbnPIfIIJ5yeaS2/hGQ/DJtSjc6tzUUoNg1oqBKr
qH3iphIu4EeL1s6OmYi55UPDdswHX+mnYatgPoGtXa8p5zf5A7PSqj4CZKyakDuzdFvipsrLM40W
9fCBhIfkmAOw84ZiGBYQo8DM3JOLQhNhIgD7zk3jj+0J/cOvN46Q0BLG0XQa7bk22+OQhIwJY7G3
kcTYPcW3g9ANt5oZNM0NGveVirbMpwej2He4vs4UFmrC4zDobD4F9q+raW4jIVhDWwykYiotzTSR
J92lY0mirg5Tt27VsILiPhQLwz0t9c5YdNKIA0OlezudrjOkVdpmFf6njOdyJFatD8vU/uRAQJDR
70tjj/BguR2RoePn0XcUJuIejFXDLV7f+Nq6uc6vzcCL5lAfSZTVIlq0bH3c54Y6xaE98pHYOtkP
81IA6a+FVI8wAxHr0k7heZlJOOE2CIVT5HatRE3kLheWW4gkQeFLTx4IcmZh7/O0UO8B+mYeVLIT
ebudmDvmGOiHjF3DKrIPSsMSZP1R3gYgFq50fQkNBXSzcO+3B8HTAyByaYqZ8R9xp35mQj/wdVcY
TQEDvnzWpIV9729PHZ7VYW9q5YvW4+DVw5oT/J/JZ+m2KvISj4ZpBhT5wVX1+ucboTgRXmEkYZka
OfuH+K4rbPEC+HsYbfyzuxyJToRQ24bJjQGBdSMw8h3+YCaXtNKwy29+cZeaaKL+iebMUfca61dj
KZc7vJloGaNndI1AzCR8ZjuOYwcne5xtXqjZDb82VlBor97pBr4mtlJ2cRwUtpScjTvZ8vVNUGUf
vvneEGnfUtmGaY6jjInfbM54K2+HSuS7sI4XR1SFS1rxaA03MgM64JCOmw9fZCZkyibUkvg3bQ/p
4nV8FcYssU1y5K626MdeSFBAJvSQmsQmSbAkANcOktiknZDMsMbGgRiAN9c6QI3OlfC/qG5e/WYW
m3lBXIttwqpAdwgBzCtHSNUBQ+6IRH1NYifgIWEz4NhV/+eVVtgckjdoWDbni1OlzbEmKyZFLlya
0DvxnPHX+evWMY6Lx5M7TavYB7lcv1OWuDJPktzHqUEKssvm+yRldLdTf/JXjC1i/Ff8IeMe0ODf
gkquHtvaHBf7zVHMaKImRK201csOKTg7nlf+mMkhJjn+WZIa/4hWx+9XZAkWoMLEXdzVVNmBiP2/
JqX5s4QW4aIRMI/gck9QXgTm+ubYO1QvSwUCuFLzNJ17J6g0+QPPN3A2OIuS5OkQixNDHWPR+5Ud
Y9A0VFBKYHAiP70KaTPgPkNd69WAaahGV/roOBvn6cglR35yj9JvmAEbAXphhneJKUzF8jTInmC1
FQxDOeA2NRiPeU9zq4FwJNW6SIOjdVoHYhBSAIzU7JW1IlQtMBPHUv8cSlXNWCcTZp9xK5GNJ28U
qmPENhte+MuBmFzBykcybILnSqvKwc3S6l5qLT6ga//UUefk0JbXix/niDVHJdxPRd4IVt3oSEAU
Fh+FlDK0GMZUvIwfvDRFJ1s1giGoFjHyqn52BBGGrNHBJ6VYIs1QbReDsvlxRDXAwZfYEUI7/aCP
NtqtovIUi8bD2pZ6WM7+A13Vsx8L/pjur0PIeysYwwbrrNwHJFVdKW/Hl/wFLWj2H4Acs+JSw0Ih
LfO25cPeL2Ypo13Jk+tBYwl54OGLB5VzgLjyJo6UXRSqhag7J3ykWu2bJwOe7KaukGd7bqOiudkb
OszWg+WrsDBm2+ZqkwqzFSlhm9OS75TaMjtcqXs5P6vjZeHoojz2Sv6O2u//v9OKRcTMtBRiCPph
XQNiZfEXpSOd96y9VqL6m5hytwrsw1Kbc6FY3E8pohqk4E3w8vLAuEYo00cN1+9BH+2aWICfb5Zy
2FF4G8pBxlt612abeyUdI8OID4gMFrE9qPxhNJeMgwziJLuugEQqCSdIwvkSyWJKi6WN0w4Qcyfj
9hpRRiuHvDFxIhTsKdRFT8s8pWhdNKja8cnSh609WDM2ORFTJYe7XHS88oZNymFNEQBDemUf5pAK
jl7ja9k7WZJjJqch8e6b8HFxlpqsPd1zxSqkyvZftZfWBNPq13k0W1bLRBFM3oodVHWmmVNuWZCo
SkqcD/ycXtTJML7DVWBSqkUxtOyvqVS/k7B9Rc7GCVAo1AS6LMMKoqQ2kAwrfka8pAHF9lhHnJJv
zlb+dTdgXt0ETcFbyZbLFNwm4UNDIcVemmTrL2XpKMzQQKwgD/wbU63qPs9jTyr5C+W0KjlfYpZR
nCn07lYkWhNyYKPnEpLunzWVZRtmC0j+IbH/rgaDc/UHAZLvtp9DLMUXbQE7WPjYODsvC8Tg5TrV
HDxu8Z52a+pleXos0w2RlZ04ia6HXenY147rKf8PitCplCf53K/ycZMACuu0vkcaiknOktEApIwg
FlU4fdGVefBhXS56Qt925HXzdgIV5vdzExQxRXS093C4snoE8DDa8yMaRkTVQLu4HGeudwtiVjHU
YA8l72tf9I7KEXCg5BmlmnDvsp+5jFXZO91VYwIR9X//ssRVxZhi3s+369e76nXmfFfKGheIXSs5
BA4sgQk1tWFkDwfyqHo+5U2CpYQ00T3Ogefd9JTdZXXcFytRUUUksEc9sDHzM+50Z12kyBQ/uSmH
v6aKbaqSQGu4CdJdOuyXrmL2eqZCdNFFd/5SBKQkVfLgOuOQ8WwGcwxcEEQlQ0+ggEKZGBlAgggs
6E+YnpFJRzjB+03uTwIEvzrBp3ZX+Y0+Prk1lTIHHCjsMoELpyVTbmR95sd2zZfLVecB2Eq5yTj2
ste1ckCLuKCucHPTq2yGQsDU2vIH3IXsoXd3DUdncOHLjivZQFJlkWIgl1UqJJhuqc8Mphe7KiQs
lCRmoh9tMfC5MVGeZagvDnH95jXLQPSeK4N94kn1cWAd3SAQ7GkrEhc1XWs5QivA90SVG7WU4RVF
x955FXfc/zMURl5oUb0X2EFp6A2glH5DjI1EEeuKlZyA59qKM2Ny5p41z9yWFY0bhmLTDmFe/ceb
HsNs8G1s3cgvfLqUk5TBi/HJuXD2Gfv04jDBjj2+Kd4v8vkds2bvcxvB7gXe2ATGXM/hhbTH8y6P
efwFJTV9GUw2jIFcqo6z70Dq4pS7DP7JiD7QZUQMcGBwG4UcgFTRxmROFGGI6XBiFkDtXioaTGXG
DVh9BrsXWnQhdbthUPdFo+RoAE8qcS4WnU/1rru+cG3me8qJQ6Z6o4yA+5aQdYnar1mK3R0gpNd9
hR83zu/zYM3U3FWwrALfck96wF+pVv72fOcTfQuoMQlkXmuTnnerQPgat++RoeKbGxuAQ9n6siGH
HdyUhx8LL6F0MbWjISuuUL7FShtKgtEi8AvKfXjzhLPquNu7n0PYYHaYkXji0UO0sNsZfSu/btaw
q9itq5L1qblluEFD7riFaNnGg5n+f7rQUl84Y0r5Rk50OD6HOZ7s+TdJcafu0tc3n9Zk6WA0+Ph1
9v+gJ1J0JKRml3RV72EaZsjlMomtQmftCOHCZrrdA2TL/nuFPHXE/OJPfsyAkUw06sx6wTPhA2vQ
sMVa+KvjkWKqERLQBzh5HrnElTHm+Y8oO1F1Tnm7Dh/Glzrq9AjwfMpenwu69CXzxKvK0x3614PS
eCekmtuSUkLOFPjqjx+NmaUlxcTgoKIXcX9lpImxx+qoClAaIZB5UptzntzIUwaF/xMLQTroDh4z
CNaCvqxSKA0kMHQcy3OBKtLM+GRyeY7KAYJcnxrf9an7bETowHUv6/8glDljK44u6G7+pBUKvnZ/
AqIlzmB314n3MOjcvY91gSzAm2MVUKsPlcdUO4TIySoCrbvVenYtnogn3da5ujSuDvXV1cbELFie
/VXLjE9vn+FmAGzItIDuRznEHYA94tqIeNtFp1Ljxg4l+A8LsYY/B0E2DS++WNNWijHZtCx+jlqW
VxXbsthG+3thMtweUtkeDs2nBCEJNVfbBl5ZMmTWKU82u2TVDrByXRw7di7a3fMRcxIsOzP8lrTa
YfkAJr29igPSr2zeD2Mjc9JKy08pHze8pXhmin4uO8Y4aMs7O5WSlfC3zbr604Cbye7EIVhS5Kai
JYb5E7/HuPXj7gaO6u97Wdqro/7eImKWIKLA7D8kyP5Ve/oZICZPNNB/2dvviYXSm1c1g3unZIec
3UwSD6rKtLcuH4jOZxoFMH4lr4CWf+zys2zbdVoAmJzvtYxv8tgBmYqj2bNemAuKNrjQPAKzCeYH
BTg1keZKSgfL56NWWrWjoQtEZdEsLEd3tR4PmazYpKtg5piD7CYkj1TJiFHZwLUUsxfeQqn9ZGAH
t/FlEoJl/dRf0lddUaBikt8ZOU9kcENf+v0ZFlVduXQg8gU2MTq0UCeEg1dDIvpv9D/N5Pf78DkF
uNymgZ4RcKXD8DIoTJR6fUc/diQjRTOV4J6D665JExf4ewe4wylNk10Guc4TNqvba8he+NaHE+jg
V2FW2fSiBR9IO3+FqcLXnJD/9b9URopwyEAaBA1H4s1zelfSxo7gE2r2u1+aU8cwf/izcy7RM3eo
wSgFdkNVE9DYKHap4qBTRlQCKIya45AWp8Md/37yQlwDmYUNbOmGP2TRcY4pSwM51i+tsodIUSAa
4K0+h0EIp0yKBDcAS/cqPV48bXhDauiTB1h7GLU5012Pb5+LofD/LhkU+ZakZ+IFG99d6oBB4ZWE
Ird8TieavS0wcRTypWLaA3vXmyAP30JZGu4+bbqwSpMoL3/xx93MqUQan/eFwZEpjOyGSWenlx2c
19USKkLL8fjeHRIifzNs1EO6Pitrz1chV2Y3azqum8YX05kF7Hnb355K1bUo/P7tScZldSRZShXZ
4Z6Y77YDOeZWd39HsC3FGo91k45XnPdJvQ8KQ8EZLT60Q2PEDk5z0e7l03SWegh+l4pLrJBGZ3ls
AE1xzaabePvdMMXQjG1h8nGsftyrkg467u4DVfY7QqPZCwBIBVgbzDtIXa95MQSCXLMlExb8pSv9
0aGjT/mIPkzZijN9vWGgNlb+dDwliKYG46CKA9mk1YTbRwqUzrOLnYir1TqvKUVCnuEw3uYT5w/7
yXiZ/Y1W67pJC6qbnIvky+Si00eLCe/BZd8kFzRxfPhrAfk/jD+Rgmzzx/0+uwPYuhbLEkVdi5LM
u13wTof1fTFMEOsQ26307Dbnw+2NdYrz6XHLXnTtij8gn4GBsNepNYdCZFUrK94hxR//Lxmz6PRq
KNRTTCPYEDSmkx8jglP2ezfOTCMoT+KjsUyXq72ek/iNxlxvsOE4p8TUMU3hjj5idJrnyiwWjeyQ
+0==