<?php //00923
/**
 * ---------------------------------------------------------------------
 * In Touch v2.1.2
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 November 21
 * version 2.1.2
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPp2aCNqtYOfosXMaNj7M72KbVTUJOrfq0TiHVCuT3bvrnRzB5CfSWKJmn3x1RO309YJwPhZ/
UJHtZKA26iDSrykj+V/gA4XHGzzELPrDyzEFDeMhBqDbjlSlJNbY7NYBv8/N+mIJA4nS6kF5DdRG
rz6rJbhLzOVtpPw0QQqiaDYiOaMGzNWFusQmHRF9dYnAg01b5FcAlZdZh+gpB3RdliaQVMVjohT7
uDpt2Fyfh5il2/DpjJCz1sxmt6S0b48rhTqUmbBuDURPVcUGWS/CzoWJF3n/ywet5m//LQqenK4r
mvDUrnuspxmqASmlE9MR197Z1wAHwO8KfvqNMUti86ZL3b3bhCqjb4nbA5x3Dwc7sU1Zh78A6k85
dnfqDzwn51QmX9xyAF9mM4og7/qGc1MdKbZb0xbhhUdz64WAholz6R1aOUTgShLZFZS0tTs0qgiA
pH+7zOE9w1kjyad7zG4bH7nrCNQi7s/1tySVzFYS12kOPQcLrd0dBUZ1s1gT3RS1VJAZlLG2aDTl
oO8lSpYnuKJe0gjT8KvwMjXm0zRFl4zyCVsBAK854VuUghVGA/eBP3c7SPg1guw3X9nTGdX+cLqW
0iToEA4gvzxvs6GOUNb3+wflnEFPOMQ5IVfaIX4SyKm8JbsbmAifpuNXGGqFPyvjw2mmvqAXl99Z
M3wZLc4Uknw+e158WhQIAkTWkV6ul6F2hvioJ0IaqcuZo0lRyXyZlWvkAlGNiUFtA0tRtUbOEjp1
8RNHTqOh9WFU4xs17ZCICRkP8ku6vSxYOOf7BRpJbdisa+mOHwy5zfxqzS0CYKwrn4oMAKAh5Cs9
SW/klRGKtFnfbzbQskmcKMUzXbHmMLULfCHtSD9ILq0+J1JF1qbLT93NcHInUkdz00UocFTjFLgA
V5kOVMTseT9uVLBj2FkjSUyNjlOWkfD2+x/krYEtX9m/XptuvRg2cDZfHRTZDjOr9KawtF1vPay3
viPXCkw+O0PgBSQvRRfsh0cmzPD4USL8+hQDX9ue+2kJOPgrAvdlIYEOapIqiCHuwIBRQj9LWRCs
oBAZTAvli5xnPZyGjJQ6jYer0Hx/7RC94/l5hQ84220V8XS/QaXIPJiej0L6sIq1K+oxAyZkecO3
BNJ4TlJLbfdqLMjqPRWe1JWGrqN+eMou81+IWi2tvVt8b3lk3zoxj2jwiDb1MX4TdwHukmm2own4
0Jfmi4anbDFYTvbiCk2mMO/k/UVjuSP1E8M6NA0motWOH4tKrM8odHGEscoMwcIS/k7wpvneWDor
sONc7Vml1uCMBFb02/R0tQQkIX4IU0T5VWYjYi1ukvI25rS=