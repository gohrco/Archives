<?php //00923
/**
 * ---------------------------------------------------------------------
 * In Touch v2.1.2
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 November 21
 * version 2.1.2
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPxX3Kiq1egRYoF37xa8pqUCUijgqMuQQmln4q0fXuh6sJ2NIblhjq6i9tasf8rI46n6BxFR7
ZQih1VBMSeDMcKGqhdA9rK+PmpABS5re9iRsJmY70uz5DJcdVZ9RttocPmnQWJ6DNRH6NB2zQl/p
B8bet09s4L7mXx8HSd6bGMfVp+ObGxb2jqzAVqvJt/pvDsr/K/2BKMnDZ2rYPFk9GcbVUVTNZeHU
edoyyRM1BPcBjnw4jwL9ZV3SPm2KGZMjtHx2KlWrvjbYPjELJA0kqTRL9rD3kUiMOFycAgC0777u
Xz8ZBqnXDqz8qhL3T3/0gjJOubWdqCuSji2KUNEsQdI0rm2/GTrMEUWHP4Dv4K2JZVSutMXPxQDD
C/lfSRLvRp+NRvIKbcIOPzi9vncB857lqN5NkkULLSWQT5EIyAKJoWi/G1OzsZx4GBAo3XCpRynE
v38ZoszEC0ZIR9zjY1w7TqVdlKxybeKBwrvLULdsVkYTXBn6M1VWEYslf99gjw0JsN7kuhmvHhRH
R3PfOrHMDnVFOkNpRpUqwIbg1t96AaQU/cFV4r3rhrRmcOs/pDUu67DyjKRh10IGpdXO2GxjYKql
tgDOyp5pxeCmmuo134ZlV9iVb1ST/yDHqD1WT0cJqomvJ2dPhXHo6QuCB7BL49vHqEwsqsAZ1Xzo
JdhtbZZdK5w0je8mywD+xNsuzGwss8ipTOSLwL9qzMBBO4CjKxbPwyfoS6jX2r0mQsxH4RB7FjwW
hV3xem64w68QemOh4aIkRflPWCQEY+LvLPPensJ31uDU3SvMlCq8vzYLtzBAQ2lGozC5SW/Jygp4
GrTZuAUDWRJehNLa1k+eLNNcdrBsmj1n1R1//+ZI3bIqOgocxmfpDbBnNZ/r5+dZJ9qRzBN+VkAv
H8MksRrb82ni1FNal4mFunFfyLxiY2fqTLcfAHu3MnAbYHpKcP9L9sBE9WHAyW3yb4p/CJYd7/Et
UoxJ1kRvSiY2yLnLaT3TUhXgL/gjauUZN6EH+KL8qhqg4gzQsSusTnJ6QYBFXt7SgwAQXQ/AxRjr
wMk8WfVU5O6Gp7bk9is5j11o8lZtdy81vCIiqtJtEtc2ivGvLMIAOGVcx0Kj+4T/3fJBYsbPw/wT
VzWNkimCvvIFEECsrolaIt2AbYMBL/JuM0FVL8uTVSxCxVv2x34jy4l6emm2hCXzUR0IAEwKOG/H
Xvrc01Q/toncNnNn5fbVY3gY+mQ+mFKBhDmLe6PJ0WUqrdUPRc5LQ4gpLIybWDLJGXam+y2bt52O
2RAovagdGcRDwaAb/wa2pSGlQUaBMOBYjQqSZ8xHxif7c4m4I9NylQMSH9wkN5gzl+krLt+lW/5h
U9SA3EXvSX2FHjyWAg8XlpbRLUEVuDXwL4dXa9hUXjFE0BlFPgxgBeVbmaG/bY7tWx5wM/X1pOwl
lpZtPaejGdjd84P6xZ8xyS1xbOQRoSAJ9rk//dXaxU4JtiQFGmq2cNzlMc8M8wkMSX6JD4cYFQ65
zIx0utz3Kj+zXDzkCVZob6EUKbhJ5T/AKVkZemOezixJsY7FwqQ4MLd4CjGStGvtHdQWWQIOHaTN
PbLxTLhdPvWGrIH3BkpwFQ6nde/pOI5d2WxI7B4OQcdRpWzG0r2FLapHPlqAiQj21H1zbRGuM/eX
nfAyvTIIXsgW5jlN6vYSwEj7Y4efj+CGbkQtUyCLBZxEPNm4K4ccUBTYB/sd1CG667q1c4sO5hOe
pz5sv5TSRz8FidI4ukuU2ccKCUnnNHpxZvRJU79irOjTcpJclMG751F2z/cqvBZ28CJ/vPwQ0QN4
JtHvbrl7zsKSI9wCzpaxzh/x/aSmgcsOsi+D/hKno9ZRxNRMTpBn94ymVWsFcdkKOYH3ADBfxaQQ
MqjHVn7+qIJUGTg8hvNcBcdMUIGbV1pVIf/41u7GJpXqe/VOQ0xRezVw5DRQ6SBHwjz3bIJ4aeb0
A5+win3pKt8o1GBtUQacn3GkEqqnbcuWcdzUKD1Hft1s5s43wLHZ+uUSGEJY6kYMla5nuLNA+97k
ZGzXN7Twu1keeZ//NHn9iUGWn29IBgBewrBk64ZA5JcqM+k25/mWxSm2ougT5ECYfH2dvtE6S9Oj
U2nh/PSDCNTVfAsA5Cr+45bfzt0KGdeqAQ2FXbK7n+uanx5IDg9aq3aX