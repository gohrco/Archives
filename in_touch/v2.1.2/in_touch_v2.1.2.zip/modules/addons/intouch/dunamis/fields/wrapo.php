<?php //00923
/**
 * ---------------------------------------------------------------------
 * In Touch v2.1.2
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 November 21
 * version 2.1.2
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPo+EZmIlKNGheZqQ9qBlOu/18Pd3bzLkqTC7IuHeOegwx96aHJOn7yYq5BI0k5+cuRc6xpSz
s8mBorlXS+AfVVcYhwvRYycGTe/Ch/PjdIL+xL1Xyn84Xc9HtDJ8Zx/CCWU1hCG6XRo3KXHkM94F
SszFl8rWxLwlZ6+7f+OrQYk2X5dp/N2/V4zi9V3aDP78k6kZk0rxL1gs3do0zkBRAXp5BTMp9b2s
VYBzOM3GdfFWU9NlZVI8el3SPm2KGZMjtHx2KlWrvjdOQ0ByoMnctiVuYjppeWmNR/+E0yFKs8F6
HkitlIqtglAwOA1OIkVGJ223CCGfkwoXjtuWjJcyiLZN9AwkKtXBBoel90R1ZGRPR51ayd0+a62d
BbVdOmUO75+haxX2ma8zVAD5Bzlph87ejfgv7Jtq0ZjnnUKG29/0wZc/zCF2TqfgU6EtN37UyBFJ
sBLCHaMm+vWd3d1GtnOlcAmv8BwxtsZXX0BWgjcWbqu7zig8wwELc4TSPFenHXZGRdCspDCAavTf
Ry/9NP0CDWI4dXbKevRuriIzsgl9u5xT2PbxO7bGm2eVB6Sh+SAVD6afZ9uhOGvuLpFeysgQ58l3
L4Nxg0oRz8Xum5w8077u9whOxBS6/wJ7Q4/JjuTO6IiXL+egFnhtd682PiHdzuIiIBb4KBb71Cog
WBbdc5sW6k/T3EJ0a0sZ0Ht/nCqMyVjxMsdkefvlZ4TrQFxX6zNIKSON+0Io4oEOJ3QHzH+jQ1Wl
yOrmzb0IupSUBiirovgKjxCzhm/a2oGz7sgup96mOqnNPqwEXSN+BL14g0sA6h8T2q8XBCCi2+fG
1nf03ZqgGOYFTX5M+ob5u3tn6TfFnuxEoXB4bctB3OVPZkPAg/csxqtS0dU5RbvOCir5MpCe34/7
tjFiFlUUPKpNSB58BGFcXFcLKOU8J4/Aqxie+IV2cAvV89B8AfW+Jz3Y2/a0/aw9osKLcpluO4HN
XyEdAmSshJLaPFfx1gqvXRmRqJ90nmaaTWRvi5QBXGr/+5fSWPq4BSenNJs5z0K6j+YI+IwhOtlF
vjywxg7K8a8XsBgkB8AWAZRlW7JrqMUjN19tqUAnMlGB3BnczzBAiMnjMxP0AMYoYa+P9r2T8coc
lSMt8JzXZXOA2AOUeIaNLkjKh6jI6cwOC8CEO1ZjkvYf2eXEVG6TEedOzRdmoMhyyjSI4xCVvVR7
OmOeqwMxLOiEZtxwu/nsnJ3yXtQoDhQGAnwWsUeCh0EEr4QsEz2XJt54361t2jMDQABoWPnLgTsd
cujZ3CVLkcv5UuJuRCTutuEiEWgFmAhcpIYVzVLt9rHWYZw4xzmvSABrIz9azgdo5d8O4VS49ftO
RLTU64qkTdm8eyzNBdb5X1a/XewcLkIvPQV9NbuPJGW6/x+ZQr6pgcopBR35lZWR7LTTY1lmEf8W
TzU7JoYgRkG7vjzXttB1rsPp3M9JjaKw/B5e+76saBZ9XsmuGHVPnjLFmRT4PErTdnbIvF2b7rKJ
MQlUZtbtIFE3wFRY6TDewliUrAbJVddnwM7Cr5KIhCiOt/GhyUsO2IAKhCFCf2EKE0GDU/VEulYM
NgbyjvxEnX2j0EIfH4riy662sA4FM8WaPtnH1YbCw30U1W33OvxPG98O1NqEHDsdtmmtltIijJTL
jt6s0LXU55faOsyt2qKPuK1StJU/VXZ1z4VNdjazwdd58ZkteHBdmVigubZry86MBSF9Et+EzNZx
f/Q3eu+yPHdxCg6k7PAteY+MczK5RQw3sgwgVJxkdAWxpPReOsVKMPFWkVnS6ChpuKYQRIwa+sOl
TPkhvKWXuXFU4kzgYHAGf2a2owxvGs9aIJwXksp5qApsg2KQHZAt7lEf836UA+KEBgehvxQVlpzp
is9sCdxedBkjYilQ4Yw5tHl42BIDZWZ7fipST4d5E1f/WSIJD2kYbUkUZooph/rHcdiE3MU2g6wl
Kq2mEJFoAcSQ30EgtRGh4wO69wqGE5bB6i0Qy2/zIfKMZsj29MmLlWxqGupl7PORX/DuFS6JZGxw
JY9alX+Jxj4=