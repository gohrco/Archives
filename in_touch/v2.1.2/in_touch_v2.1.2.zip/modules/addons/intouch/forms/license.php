<?php //00923
/**
 * ---------------------------------------------------------------------
 * In Touch v2.1.2
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 November 21
 * version 2.1.2
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cP+zFmJFLapa4jFzkL13G035HsJILok5UbOYisSoazUfxns5tdHpO5uTJ7UZmyCCvuXulQ+KS
tLt4H26HKCVR/YwxinqMeWUwjk9kS3/UXS/nRHJI6tvecfneMphaYh4mGtl4IrsKB+TV7ALhhl73
1owHmSM6dgTGeFMsmpDVNmm0dwwdzAr5W3qTWeF9221KLREfvsGmER9Ee9RNvnHmhcCtwGfyvgiC
iI90yNjuZO4b+ihIZK/LyDnd09H2DQtT7i9I+3NcsV1cJ2f8u+T7bp5S/dimeHT4R1kW7vf9feNx
d+c7BZhDC7nXwZccGQ3DkKXBh0CXyn2vvIKXtSs2m8RAZouIONTwMeeLXbpCe2hobOF8nmoPV8aC
gAmnOuMISo91/M+Dvfj0bzaV8rOSZxXeaOkJmn9+lpyH06c9NNyPeJTne8Il3PBafEgqpGr0dDe8
Iocwc7s5IW3SCsZ0aU3+WevwJ9CJ6EZ9ywDN/9jaWO+e1MT5szumuK21KkeGGIRYdKX46OEODPOr
FaExrekMWPYvEeC8Sr8KS1DzMWpvRdswcDUAoOBTllz6jSgbEG8Q2qnJV8l3tL3FXxU66NP0UPG2
IP+0SnGPUliZF+jbOQtTKbO7LDYpz4V/1+ce3NLiC29w5EY2SE5BfpMzuBP22ctDT34qZH5ilJgY
IjCtJd+c1VlR7Fc64IjNhAU3larooPKmdONUCYKlK3Pmlgnm4EzWVwGfuaIeIdGZ5lFdRFoWqjTp
GN7eLyCScGOdajzcjbI16KIkpxJ1dSlEJMEHKllB5evo1CV5D4rOo21M029UxGkdfpyRshgG0/GA
H+N2CoQa48/9PkmwP+9Tko4prMvVK4hYSNPNTn1x6MIdTKLs3hbx6lzTkg7bpSifLhUsy7EuCvES
m9Ple70iCBi6FJZ0fm9uE/TjQx1Eo6ah6YlGchqfSjFbJmIKjQv8GMi+b7FEI2SqtQRHKrTa/g2o
moBKzStifNTKUAtPV0hdBAnYHwKRNLb2qOIEJOb2IXVtU4gH2EcsZMZqohKjky9WTl2lhqFG6BTW
CVkq30ORcJVxkV5uBJb/lpFQ79TQWSK4a2MbaIKlpW==