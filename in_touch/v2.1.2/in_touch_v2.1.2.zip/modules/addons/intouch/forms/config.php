<?php //00923
/**
 * ---------------------------------------------------------------------
 * In Touch v2.1.2
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 November 21
 * version 2.1.2
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPw2RBGCGPPOq+Icu8Fc4a1IfRAQN6tIrIDXuKpwehglk4tPmK24zxZQ0zqVC7P7rNhX+3vsj
cYj5z9Cj1aFh6uM/gh3xFgTkLGe4oAmbJ2nHBa7Fn50Wfjbp+t1hMXfgcfBzAfWk1gI57e0K0rU8
pOPZqq1N6UQ2LeHrspYIASJ3dqTS9PI++O0ERaXw8fdMMK9aoX6n4Qx9bpCrWOENz2UXDDdDcRqX
n641bJiSZCi0pQE7/uN+M1xmt6S0b48rhTqUmbBuDURPMLyddLcYzejZ/BNHytgV5t4o/y36MUuF
HFhIvVklOlZSzwpdE/rMr7L8dFGT1FQmwJQzeG0kqVw0CbzX1PTsEVQCR3kHTY5DCPa2mA+VNzUM
A1EIrD62RhzDeiXLxwFCu67RNGvGK1DiWgfC/Bn9YPW+Cko5zga8N5+299F5SCLiG0p2yWRPmoiM
JNHo/Mu53yWMIFw1eY5zupxFEPNLk8g2N8K55wAlNRLSPuN6C3LJ03948OBxgGq1RNuvDIHghVVh
fB1uc11tgQg/xYm5259cfjJ8Yqz237Q4IJ67EuNY8BomRWcTOsdTvS+UfbtUN9KVQIEnnmRSHZEX
L6B9m/HAbDmvNc1FKDyhVm0hmH1Npsetbl+1GJF/IhkD5BKG0XMHgkxiiYZSSPI8A5Fw6oR7y6fV
jRaM85DhwyVivIpv+AMeoQjygurnZVmJBQsxCf/7+SIw/5wP1HaqF/6GucueTKUkk4mncrU5KVrc
jjXKEu0e4LWkam7EOSNjDFvSOir7CJVlopqpiCZJbwiomJXJhwN+E245GrQz/e1hUPfHUu65htfA
H33n6MVtC1Xg5REoXsfIWRTm+SSvociRj2PbaSEaxYMqwEs7pUx14Bb+TSJSsJvimztfFHq8o5lt
Hkz6dIVeAqjhmoi1YCGSqN2J4O/I6EjbDgh1VfAw9vxOsJOQ67sONGcgyV7rIEs4mvyYHlpSv4Hl
KRl8aB+SU8WPNTbYmf6zAdsoxHKsL8Jz2M51DYo5qgW8ZDmFlPEchB4n8lo0ys2P3C5qDCrvAAuR
d2a1kYRVPBqrBHJ3H0zkmE9+LcK3HQUQV0PyjSQ1ULJqoR2ZlPLT38JvdP9tfYEfD9qAk1MQcn32
z3Bk8OPGvTj/mw4fTzdd6Jt+LRyMM4ZxBH/Cyp9g4EuPVFaKjvhFTRDZjqcFMRmdJBiHhLleedrX
9d9apsOp4qH7SCP8RH7vqDdNaQjDGnk+Lgd2a+QfhGAsT0oxfeYTr/zjARO+BIwqiqH7GASdVe9t
Kq9RyByd+wG6BqsACccdEskbgogOjQygbh28P2nP/hnaEzAVN9opLs8sKF3tFMdB1lZt50iKAfV4
s6F1IivzNRafBD3jVW6cPrqG5WfbBMP6BmoQ0CgKg8wXU+6xX0iDH4hEoVaIzHaEB2iGzBX01sgj
bBy9GMJuiWQD1ijjU/I5qruODlADmJC42oXl4QbUsQauJER5ZqMxlrzL2d4KrzN07t/QZOW3VkdI
vsv93PV5XxC4l72B0n1hTv75WZFZNdRnrBXaXiFA3QhAaMgtiHOE3Xeo2i2JQU7d0qDsmbcfmcBO
364HAwCaUZ0dKrKQOTZrtgWDCjMnsL+0vgNwL95Wg+TyimARmv6c+q8jwgfGaZe0bcZquV84iPbK
6o4md1e9E4oeUo58PY298gEpl7O7Zek15o03pEz5j+o90+qifu5F4yxZLdpQ8a6Ma0ypmJXxe7Ex
/90REJW3s4kZvta1vawDZkYSK3rHU5mByy6ljCubA4e=