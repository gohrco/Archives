

INSERT INTO `mod_intouch_settings` (`key`, `value`) VALUES ( 'usewysiwyg', '1' )

