<?php defined('DUNAMIS') OR exit('No direct script access allowed');
/**
 * Dunamis - Updates Module Base File
 *
 * @package    Dunamis
 * @copyright  @copyWrite@
 * @license    GNU General Public License version 2, or later
 * @version    1.4.5 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      1.4.0
 *
 * @desc       This file handles the updates for the product
 *
 */


/**
 * Installer Module Class for Dunamis
 * @version		1.4.5
 *
 * @author		Steven
 * @since		1.4.0
 */
class DunamisInstallerDunModule extends DunamisAdminDunModule
{
	/**
	 * Provide means to check for file integrity
	 * @access		protected
	 * @var			string
	 * @since		1.4.0
	 */
	protected $checkstring	=	"@checkString@";
	
	
	/**
	 * Initialise the object
	 * @access		public
	 * @version		1.4.5
	 *
	 * @since		1.4.0
	 * @see			IntegratorAdminDunModule :: initialise()
	 */
	public function initialise()
	{
		$this->action = 'installer';
		parent :: initialise();
	}
	
	/**
	 * Method to execute tasks
	 * @access		public
	 * @version		1.4.5
	 * 
	 * @since		1.4.0
	 */
	public function execute() { }
	
	
	/**
	 * Method to render back the view
	 * @access		public
	 * @version		1.4.5
	 * 
	 * @return		string containing formatted output
	 * @since		1.4.0
	 */
	public function render( $data = null )
	{
		load_bootstrap( 'dunamis' );
		
		$data	= $this->buildBody();
		
		return parent :: render( $data );
	}
	
	
	/**
	 * Builds the body of the action
	 * @access		public
	 * @version		1.4.5
	 * 
	 * @return		string containing html formatted output
	 * @since		1.4.0
	 */
	public function buildBody()
	{
		$data	=	'<div class="row-fluid">'
				.	'	<div class="span12 well">'
				.	t( 'dunamis.installer.subtitle' )
				.	t( 'dunamis.installer.body' )
				.	'	</div>'
				.	'</div>';
		return $data;
	}
}