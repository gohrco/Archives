<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.4
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2016 February 4
 * version 2.2.4
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPqYGfeEIVHkqVo0peCRIZXk9/OvcTa3yrgwiyEgjWLCUykHsltCMSg4emB2djB8jhZhCDQlA
PBdBI+U8bGw8AEcUBvcBFxzFWEJiarfPcNCuPDUncDGXkmTgYLgfvO3CMiLcfTHQU+hXAejeyzj4
hCXCM/pKfPnjjQdeYRqPUetB4HsjELc0JF3uKq9eJ8RpmphfDw0IUR9+0f1uMJB9aJ1CpymIafcz
sTL/U6gOaeM4bd4o3nADpxf3+a8fHgUw1BOC3+znYw1e0ivE9UgDlCvVdXyYJXafTtSIkmW5wPZF
dRmuGYxvNdnODVqw8CsXvVRhLlL26cmlamM3JBwDD6hA1O6KODXzUnlvI6uHkFwaFu7I5MfVRJ8z
0dp9zZAWrflMIsPXZ7JxLujxDmyg8NWg+0ln83i5O9xdAWVrqckXjoBIHnnPtzH8ctiYOCGAYMj2
XvGeR23o0jrMC+HK/zmvHBx9rICurM2RMg21xXcA10yw2sIQ1sL/vN5CYyuBHcpHXcn95QaBK08k
lpuLvFtZKXFpAd+4E66wuXvrTDHtOeLyhf1OqMhObVL4q0Y2/6GuddslC5b3VjpSsZ3QGQtwDdS+
bU4HVPb8BDW9CEZL7eB9iUEXUWDOxNM42PmrvOqloVsGVteezUK2izDFNFUm7RjVfoNknGsD8LgR
Mfo/HRRMnieM0I1/5b6gqLIYkjLSjuj0UjZxr3I9mvhWDIwYDRzGA9KM9RzFoVmVkQnGELB9WWKV
h8VE/5iYKU5Tj9viPZwdWr0RQ3jqNORtP0o6+3g1WDq1elwmsKFf4tYtbVrlUiaiN6aEWrCJufA3
/hE/EQtyHy2lLOmOmlxOPC1k8s3CagVTXYaqcWCKX8OjCAns6qrjW+Ac293rSZCZnMFxIvyErvq/
H6wo35M3txJ6xA7YkR7wtU6Z5ccUIctbxHUFu/e6Nx5RiBqReCJ6pWULenS0Lf2abGz9dz0DJRaf
9+c1b+e0mvqMS58GjpELsNp3FKYGf+q1kathaOHWbRtdbmCCZ5hn1HtdDv8ZSn4tydODrbboV9w/
D7MQ7DLAstPr+myqjrEfI4GFU6lNtu6j58fTV2bPQ6dx9WtF9royymfKw7cTbHPEruByRtvlnjf8
+6ALHYjydEfe5cyigQqzSmDWlUnfMn51gjcnshuWot0fThjnu/4P+XLrRt9PA5g+B8T7OuilVHes
7fBPgQlDxfVEXH1yFgxyMVRG