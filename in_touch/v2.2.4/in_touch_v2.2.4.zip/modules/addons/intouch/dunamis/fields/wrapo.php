<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.4
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2016 February 4
 * version 2.2.4
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPrWNq0A5+2WrHAL58PlKx3YoO0hhWIGt1wAisuAEySXbSZ9PU8b0aMLCWS4KB33/7s3g17Cn
i2zN1pLpMTyWvJfiM+7fKRR+MPAV85jIreJwQLHiIZyzYGyzWrsfd21P5yw6JHBxeswSVMyYHqMX
ncJ5tRaJmXh0nZEsbaePQIazNp+0UKshyug/nHs1sF69zepumoTE4XgMakJ/KyLesYGN0Wif5Tpu
O4ofcxlOrR+eEu/TQG7+pxf3+a8fHgUw1BOC3+znYsjUi9Kj9j2v+T7vpH+gJXaz/s8qGdFDP/Qp
H4+Am4gE6y3eJYBtAJSPjNmYCAc3ubA2A1aeLvYZhEO1PNG3k0AIbtYCdcnGkyI32qNp5hD+UX+W
QI3Mw85HxEkuaAYUNFzvJCVR5HUm8u/QHlmSkjIW/2nFoWTVxzPi2zNC6BMyW5bnQ5x42s8hBK3o
LTBLZ8cj/QUCxPQ/Q36wBYPNXjjG5aHsS9TG2Ast1pW4fbGqZXWr+fX/t2HAPOhTJHa6JOV/ckz7
ieAQhtbYNOi6LOhmtJKwUcgPlv+8nrg7PKig1PhiV3EHOIdeZx/YVmj1lBFiqej57Su0oJBV0x3u
+zdNFT24bUHrTTga7vPCqEHWh2B/r3RcCD0MX2+flyu1TiTja+U1J6l9zk2GxhrnBcHe6cbRz4ZU
aR5OjQxQhaxcQZHWPfSftOnJaU7xDw9yuM9TyynQturzLXISxci+14VWGmt0zSec86wIV1U8Sugc
0M3Opd8qou4Sba1+jqzbm6U+CJaJAs2gtThM/FduModNn4E3q36pMmXOPVIkbR933F/SwbbjioKr
WX6wCMxO+Sg0PnvQAxu5OkCHblHPKcErWOeJLxp0yj9QQNJl0+x7UwUkRilyBxZxpPq4cjsuNBNu
vLAtZ2p+sOuj9uFWUnPGTdAtSdy3QLCj2cluDs2H431Chdr3384ITlJLbnhOy0PE2V+xaxoNd3Ic
W1u7px6D2Qra6QWhPbte5T+Y7dR3an2PwJPZ9wlC/Tks1JDbAl6neatiMnSZazrnPi2N7A7kMcFb
JAKhaGSH3uGEiAZyGuVojFAeHi9lW17nZRA6xG7qWOZ2l3AbREOhucbC6XHMFl98o3h9klNoaUaA
MjHlumXAMqdnQIN8kl26LM50hTUeUDqZliJeadoi+jNneaXC4+8eQESd0N4L6iV0wuZEY8PFdJ2v
6N0H2aKSJm4A9nm4Y67m/HTkvo6KElkWCFrwQ5wawGTGi77iVUERMGGpwmEnqKPft8HY/c6NISdh
wggmggANU2lL/efmvzzUILixCceP/+/lVTell46SxfeJ8zyEb92vI8NQhRlrIclvvwEp/axIPwyP
OrckdizjsHWZDccX6ZhMORBMOzJljJH4UqvKz4vKd6EqlES9p7w6e+kp5gFvQo1E6Tsorxzmb019
tXHdwJZccW0YJB2KPiD2H0JR96q0j1s2WEYzFmHhZwjFggr/qzR2FcgfpZ8KE93Vl7D+Pq+0GeCo
dsutkOrr8GvaRf7dgmnvPp26hVHLQrHRhBPFfDNH3mlZwEGOVogax6JUIvJpePk8gX0ZENwVq0vE
I4FWnos3wnD8SGmeFsTwpdlQnqrsdXRKqCdWyYQ/bFTyYF+puSyjSR3TzvekAB/gOIYM5mjE+90j
cfLJztSfkkD3o7t7rTEYuxhbp93hH5QyVr4JS6bym5e8vPRmDYakrlgw/lq7HVbo84do0XZJZOSr
O3crCwfp3x+ipansOjlSW0z73QkoTS82MrrfSaEbfO0SR2NFrKINmWE4jM15HpyWxcF9/22FQtnx
HR1rs+Rmxug0SsBdCK/lYRS0LUWUGd7e+8i85F9hf8HQov8=