<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.4
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2016 February 4
 * version 2.2.4
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPtgv+m3AXC0tXmfk8qbji70dXWvT0HaqR/8ERnj9Us9dvGmxdN+lobhQ4oJa6juGKYbcKfKS
PvYhSsC6wVtpI/zfxyVfz2WMue4fJPE2NlBQzc8lKiV9eBIprGw6iFN5ryx5dsYGhV736tvTOYs0
m0K2a4d2pCqT+07DUOAWlm25iwah/LDrTZsqEvqz0XyoxLPk7DJrEIdaNkiSOdbi9WbFuEVZNmdm
CXKcgBmhqrnuU1kHJGfOQxqVpxf3+a8fHgUw1BOC3+znYpvWrH6y/fJHkEd4I1ywKnaBpPjExAH0
+5/EmnNTqeVmnz4qadE29PqJBWxInpU18aUeVUCJ7OpdUXk4uOTTHCaApqqonMPPBubiexZqGMxX
nYFmiN6JCZ8WtwkWakhtn1RrU4xMZC+rzH25zpJzuh0Z8UhBwUR4e2rqyeRe6t5BC+DlBwEKe8ur
yKQLAlEouUNZA4n7+Xa1HfaYJyz1GhOsGKtoRrIuiQ73xiVvoMvRh6dwmhyrK+vSPBgLl5YPcuAh
inkp63vzLuG5Cg4L3SmlBrZLE0e9g00b3tcWyWoBzWWnPP2WaCSHZaSZTUqff/8rFKTsVgDdESIY
totLJB0+d73HPrc9RAM7Eqif0MoI+h8dgrJ/v14pvMQLOzwZRhDNYyL8lR8iqP1/wtlXDHWdLmIg
kGn3fb6nZNDsiwP6HRQ1iVGZavXwafnEYUILR5NA/BC6y7UYWoLYmsGq0zzqJHJqLixmjZerxF3f
vhD4A5E3SPwWyVUpEEhW6zGXpHLDd19MHqVm/2yT1eQ6ogb6jy3znabSKy1KJNAP+Xyn6K0/rKqY
hIfVR8H2GNZB+auGJzPnYj8HIC7inx/xLWgHW3rtyMCuyKdRBJQJpCfmHR+c3G7r5VQD4D+oE91a
PZZDmHQcFRFVfeyNPhMYbzonBomxIuWjRAKUebBn1vKLN9jZy5qLa3TNCXabaIv6X1eFdvSzHyvJ
FVYhQWYmEsoDT63VN4lWPnA+ep7gJq8Ef64YXTT51z8CbSYqc09Ywx8cK8GVS+Sien43Qb6e867B
dO6THJ4ZoLJ8925BeC5OtZA4u8BwFKn+18Hhy9DYLJi20Q2VE/4CEl/KH4f3VHmkwLIZPdfcqEtq
EzEJ/puHggD2Ln80U0wknrO14xIIIP3WPgYfz9VNl2UOTVONnYbnFr7FYHLxL4FOI4S1qXlnz23h
l9nJW+ncwRoh99rSKfXEWKwCH93K4wmvk8NDgF6b/puxk8TX7J1o7nuuybcqflDaT2lYj8pfl+sI
hDgwDcePGZhD4yEdVZ3CNorFvqAe+LEF1tPQXHH3/vStyVu1SNupnXkLXEBRatdWKq3JAuHKMzkU
6fTk/WTRbWtL4MfIpToXucrPi9NF26TEFwesthW2lmBbm/fWDTo9wrvbR3Gox5D9mGg5p55wIae4
NEP8Iu0kwLUbhqbxAXnKLHBkoJTynELbv+gGu0E7cnp11B0eLnXxEqQKUKWFUkSqNrN1OFKTQ1zf
tb97LaxF9Wlu6Z/s+lMbLlWivI9L2Uh9cPrgbt1qTuOnqz4Z3x9Aehi2D6KruQPLgZBKAT8lQQm5
dl/10uwIXgNLgFztSnSXdclCDR53xGYdb4UJA8p1279SQGU8Cv9aoqESaj5Cx7nwhaQ6ukNrW7eq
qn8Fd3xxBwWwpIF3dkP1JHryaWnL7PiqW9VKiKDf1g0HsfH7E7r3o+vupaLeoWaYXmjxbUEAuqO+
YqPzlhBpYOhAaLXLYTYVNjSYB2aE0/Wf0lU0uqT5yd9wb+RoNxb1mUlXjIKFIKtM/4hOIlny7fVm
cEmIP8c6JMHswX6z3FcHb8dEQA+s+b5UbGQHjJePd/b4rHmDznEu0yAsd9o+ifmm8HG9uoPy5Dtr
gtnLXULSR+XJv5rtYqhIIm/UoJhvixecTd77SmraG/JGbqW02pGgdFk0ecWZXnET1X7QV5KvCsGu
XtXE0hNrPfZwWt8kMg98S9xD