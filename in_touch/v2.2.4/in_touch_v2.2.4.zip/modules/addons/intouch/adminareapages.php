<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.4
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2016 February 4
 * version 2.2.4
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPvFgLffrRQlT5373kU11EKjn3XRkj4vbEycNzY8RJAhYwavZt5uScia1h4HmQxJnzGPmJ5im
8jJFTnUvGNV+vSsiO40sSnETeYjpNNACKzRYFUb1/1FFvbo6a/eaAfhESxI98+ZWO+BT7a7eQZZP
AR/FYwqL/JzMs+XaJpdRLI/66xgZI/x6/ubUXoMWSmktfjPtTiygIe4S4Mus3OoRSayQJBs2jmQr
Hk5oUQ7W1kE5zP0KWJY6Yy+wG/f2AKQdkWIs30/lSOlHOznZPUd/13lanzCVgauP63uEQnB4VhWi
eFfGNP3fxp3te7nIGAiGMwfXuRM+I+YdtihJywOLu4ZljibPsFlz2N5vmjWpNMzNIiy07qfb/9YZ
M92DGEA1b84EsTgiiALcsWlwfwF7uau3iFfoFcS3hvS3nVhC3X1K7VXTSqueyAcT5KF8y0e2u3U6
veb0kxa3w6K7AUlchx3Ap9A+Y0zsuWnAmSVf0JrZxFd/vQBWJiiqDCvqMHe41UTRANFj8WRjEIH4
HtaJCEHsXAE08+ax6muZD9lCEFUE/xWaLZ1nByoTCkcOG3ylf1oS9B1PizLqgDhXyc5K5ENH4kJX
hCzmAoDe7uvCxCI5vfsUlgx9v7htZEYfh0q+kIpTiq0tkF0VQOpFTmuXkjl14bYemVRQElYIo0xa
j8KFZPSFMXxnThS6OFLsyUR7OAxYeuDmnBy5J2e3ibvgnPmq8ts+aaplRHUPQvK5k/I0pMhAkYEs
QBHwrUeupQQspGmrRISunUmFvhx4MY3c9kQjXp7oicdZuB68Zzo2FZtA5OPYoM5ZOOHwNyZ6p5NU
APukdhTF63FHh93mlbFavndL/mwmr2cMLCtd1JeUIXjxpdTGJHqEPvORdiDfHUnSc/SQu9gMfciR
s6n/R2NtY4qvCX1l/XpATOmdEssrlyFB133Z3tj29HknEyACoDanhDihLp787nV03ekOiyYEjejz
3bqk7QrMzmHTBOIMYEvo7nQDZGQeihlQamcWs3OSHC+Foqm6jwVTWMED9Li8VOU60PrWBz1LvYDv
nmaT4v0VcqSH4fhov0nmUhR6t/ftnCtWfsYziu4rYV12HYmdT99c3isAtZOZ6SNfvMzv80f251AY
zamJ7HgpyDSwavDJYZtuRX8r7htp2BIH9xeIJBMsajLh7mpS5NRoQyOOdMkXrZwRLqRtC6NDbrVB
DbFp4MxwnzINvhi5LVC1FPUWmyGJVeBpNW6wGgL1oA9dKLt1s1I4BleexmGQv6dyTm82fyFIbwLn
euODu6kamF4n5egBtNZR4I1qgDUmWFMtW7FVse2XNiEkIwVtSh2jJpSENMURXwHWi+cHje6fMud5
Nv1DIt8cbJLLINbi0rN4U4gSgs6WYjSx48nGCf0sc5m/rh64xb6LUk4WnfkrPZtVNaH3ZQSRVhWE
6JELP6FVc9+bweFjO+E3C+5esN87NvOFq9d2kY3hg6URhBuWf5e1SuqDch5ZIJOqjMCQSFu6f3HS
sg1Uo+jtgRkH2lR+Rg+rdVZpIqpDRFvBPpywFm7UNOi382GIL09qJKBfAcr9IiuargRu2qKDr8g6
bIFLOpOkfnONHjVSSLw0+4uorCQx9H1fJv3eBY69z2ivflECbra18Z4kaacQJ+CPyup16REvRK8L
P4olFf9sr6n4qO4iON9jjzJvqp34GMpsPTehNYl1wzd+YXdcgAr0C2z/YwtZN8JBdspessahyHJY
3//bLYzmK3VTtZ5O76puHrs7lQEXjePqy/6iBuxNcMsPCi8NAwovmb8i/npr3/sSJLAHt1YCL4AT
7g6VOiHlGsrxY2xGcRvGV9f5DaqvgdMotyk6oeHRxBCoNXuX3m/F9gfyft4xz+rgBhURy2s/T0H0
G/WwTJcfvM+kSCG3uDClNoQEC089lws96/oTxZAmxtJIuV8nacnp/t0QNQ2DgAyzLsS0rPDQUVeK
YrkxNstB8B733ok6nMJtRfJ9U9fCxylRBaF0GALJBW3mclRY/DTan43kUsygFnJ7qyJXpDhU+wAw
vbCXyitiMDZ1cYMSl8Zdm8P616qryLncmsFNpKUyZovorEi/kbTQU5xIKejtH1Kv15X0UKcKXgOO
CSX8VJIarl2UE5751rIigeFQ2nGNCIqlLBPLsqoHxzrg2ZznJlsiAHxNoFQ9yfC7LVGiK3/FjTwh
sgvTSeBK+mpY/5RMH780rFMmNThSEPb0RZJybhE04Ysm042XsTcnDVqcfbLepqxjQJ8N6bA6VdUu
kFZ5lWWqFL240L2oA1JBjmF30PKTU+wE+dhFqiEcdIuo9pBpY1/ZhUPfOwt97qNGBMegUIR8bML9
c/rdhFequPxQnPJEzKLu2eQZ32x+D68OeeVAQZf12B/AbHzqqK5Ftdz2aCcTBsbm0FDEyafRg4i0
dAFijH+h6SftZCz3q1WLmHmGyLTy4lwrIYjqZ3sZWMCNP4kY+x+dqsJnNGfpDd0TBij49iW4kdHN
d/HzguTqhvo7i9GBxViDYILVzlolAQxSxGBATCP14cEfJohXQnbYU3MA9hSEg4CqclGVCkb+8U3I
3I68D7uHsn9xSxz2odTY5Tg+ZpS58OJssSWglzUESStOqLnFfUoY0GtUcfAzKTEnfIIS9XS0Ya+S
rB7eC3/rM0foNBVPmJ5huc1yG1e4JD+ECXAn/jIz+OMdUow31dxSxVTBXqlW9Gw7gxKSIlVGtBZx
KLLxkIuo7MQXilJWOLlAXN0TyxRt1Ikg0ms0uHhsq1DL6HvXaWKMugvpmbDCbbeZ93uDvVrJDnH7
Xq5WGY4n2gV0rNDIdCDrj6L3Mr5JSaDktJLWlUSbbtbtmnN26/KESo0ECCFIbakid/gWHH8qdFfk
cEddXXNSpqm6Zf96Vn2ZXmcpNC6kThxXcNI897T6QZYs/2aq94w08La5uWIQyJrNqUY22ZtRFkju
VEIXG8pfEkvc2P8w939hudX5JB05qp47GDDlcKzDpchxatzlRy09krrRK2gl9IKPYMvu8GEdB6bs
SEx3Iqvi74jz1Iocf+GdKCQAKPxYq4E7rLE20F4bBFLEAZqD+jOpgL9CjK28C7tnf7oKoulbfRcQ
uikzc7GuSDuFei0LA6WeCBCCaMi8uUHphqoP7h8g+NYk6L5u4d83e/LA3MzJUMeXG+dJh0+mMHjU
FuDikLKmjFfGp00f/divCAInS1ENKIooyekCNm+DuDXuPY9QoYHbdMuXO9EH6NmdXzGiVwRva8z0
guZVopjnk+wvA3khkmyfx8FQa20Z/3V73JZJ/2+Kc40Rj9NEs10OyHnKOMohZhcHymdW2GAQdfYW
h5HkwFjH4fNtQYRNMSWSS9vLEA48Q1nbEVjkMIp3SM5UUelYk7mY1ton+/STKTgcHimtGfS+ejxU
IlnEJktfMhAKd2u+94sdYwFaphhAyTUu/J7LfygdmO+i5sWg0tAeIweaMBlS+kZ1pvulT1FJFoag
p2CYrUErgNZYfRfzNsrv5pMvMXm1NA5JW+d5XJ2pHSC8K965XK6Lbm2c8qL/PyiVj9+xG3EeBC4q
G0sMQx/oEwI26HGrfVygK5RzLUz4oFwkWY5bP9hCFwsL5BWRqbeG+49Kc9UMM1Du+7xaEb6T3I5A
R9E7vOhjK84g7dtTQR0pqdbPZFyBz/MCQOQ3d7Gr6mYvz9Ox6v0OEqK8YCK4NlDc55IV+49VlQxM
JwUGe5ciQZHsLYq7rjF3oXSTzZdVQ1J/KzkAaG42MRTC/xoE4IjsvUU398j7OFPbX6uqkU3/uVJx
dN17nMLh0q+1eepYvydPzWH9Gj2szUE4nHvq42gkmqhJsXN5IuYPfXArWf7V1Zf1BqrBmQSs3HOf
WjsQgApN4te+LeDZYsmfu4Vh/IdTXpDYn43cuE/Iuv99YbSf5ZPTRLlqUnFWnFFsmTkmznuB1GMk
Q/j3RWIKfOk1f1BsjuHdrObejWcEOc0gWgKmbnhq117XsMf5q6rxxa6Sb0b21Sa4KdybL+vm6JKd
/T/85nbg6Njr/fn/fNB6iDS2WDFYNsuYYisbROy+NM0A2zpTeU39f5WiywEp5IflRm4EGvgNJq7N
JHJN3N7/Od6PCBzFuESTM+hGjB8v2PhIhfl/ooPjMXZwOoKCRRKocQ64RHzG0/hoAgOxJ7u+IPNO
Nq1Docen8vtIRsS9G3bEJrfnRACUQhcGh+Yfn02a6n/i7owpdvfdt5GB2Ob/yk3j6vc6ZdLJae7R
OawyErA7gAuAk5kPkSW8a96RCT7v+AWM/Jtp9F32w6gXvOlqxa5FxvW9S9JoOW8j7rRXb25oq5ZY
z7BZP4e2ObW9Th3eu5bEsC0HUmAWl8/r+H5uX+Ay35pvO4ctu4KS9tzL6nn2QXm0K7sw7D0Yb6Cl
bll0Mzjf+hm9zW4vup4zA2/65VqnPMn7RhtpIYJe3qeXLl+M/TgDxetxG8iXDUYF0vjCM5NkqfP1
jeH1LwooRoeDI/LtNlY605gN6oluN/fXfsjV1N8NC0MMY7htQ1ivEi/EsZc6kk/4FQEgyGJPXpQ4
bc1Iv7j01it/78NSkH83+p8MM6BRxeNFjhDSCLYpGFVBu9qsp5PtcY494F4+EV/OAAsul+s0R5vP
pYtqSJPjbSVv6I690UC+V+exaW+yzlPqMV9M96B6Yz2A8RrX5uuHyjWUbW+S+YjvayPv1GVeLYNA
H04znw/2hc2uxFZBAO7JckQcsGaOVjHB8o8Q7GJDOZJvCoVnis8lW142uZHpMt02oXII/NciR0Yy
VRkKP2j3nkC22pzIIYAiQ94w7vP3kIAquXmDijXcHS91so9Qo5SwKWLc542/iyhZnl9tRbPxMhNO
1vvvwlNCiPjNSF2c6GwOsG6GKaNepE6sqHzUZTqajL/T+sfYJMCsADg2qv2XLfW5L98H8DBO5W84
WqFCbUIn/H/OBm7iD+G2OMy3JaYAdglE8DGDuTJhxRcHq1pxRx8joQJyUQrZ0tjJqrzoPGUCecjG
nR77aGiolUh+9NzRy9ZjE5i2s8nr591HZDNhexwp+39foOCMRJXcgAkjHpGaAHxRLYwR4GkNUvVD
deDTX0zQVatm+wCgwiWgWqy+/FsVbZF30lD8S2AS30TgZtifSJYktuNloQZZVMjjlyEsoC/Z3/Jb
EdpziiSIiC79iBBbd/T5zWbeOiAc9DJYI03OVqLUgKX3kGKdYrt+U1DVoy9DS5GsCwoWjUooRbW1
JlP1d5TNT+7vVQRgS4EHXG2L/P8FqoVchvA3Df0/fYky5MFWLQTi83Z0MY3zXp9WQOYUrHkclzQh
GU3BzsIGwgzzyclRqMrzt3BDVXUyFUldVp2m4LOdxQw6cFfcAwTu59Wgc2bw2r7HtMQ6CWtA6GeJ
cdSQHBrfFufkd+ztQ+4jTMrKm/IjN3e6sxvhzIsmkg/kU62rZAsWlGsCb/YOogyxrnPgWCTgv6+I
zckiJFs6+F2k0BCZZD/HCo7WSQgEM6yP/ZYAEy7OYq0dbsEnP5+q0hCHdgLKHO9wKUAJFGRTsSR7
CKwFQL3TRgbgh7TLjvlhOyDtDSJXsu0SmQMGjLP1pu5YzZ94nfYCayJ8rd2By2Y8qNjkLOB2YC9v
iVzjdHd2fuxEekrn8n2YzEwmVwxz2w8zFxV99lGSzUvgtHusRu4Te0FuoqK8ya5NLrVGu5uNTP5J
4nrnLOQGz5XGS87wYOd2C2BObljXQ2H0tAnyDgdx4sF0YToEELXbBut92SrdZ1dde7/rm3qa2iVq
Xu1KDDhX8/Z5Vf0mMYQVZw+wNO7s2KkhUmb9GSmMDQNfD3Vz/nentF9FI+IoWob2Ess6FY7AfRpW
huE95sNNTcJhHXqSiVIQmkifUjRJoKDXSXQkkxIaomA2D6tSGDPP6MqNekgX1jeRIXwXG06hWFP9
Vd2y7kdD82B53HuAT5llg9+23WnTQI0+NY++TASz+MoGADBA3Asd+XnUfVV2D14Q8VDc5rihAFQG
xdXzDCHbRUnAfe2W9Lg8t+1np7Y4QlUrcD/U/DaloZOxkvQ/Js91prac2FK/ujsLCMegVYzQ+tyq
IE+NBxXVjlzeJQvQtecw1aCLsn7BMc9zqZJhKzxWzj6DlEmIYOpQ76BxTE28jfkAyFfpq4vxA+2Z
sOh1DA5bh+Zg67WKmX/4qwF5tqSmE2EiqTRl8ly1kTkcn0UhkHWbYQC4t3DUoxRpAWVmd7dW8rTv
8msPFZrl7iLzHpdej7twkNz19qcYWlgdMEOuudELj7tY79L7KiDqO9FmUPqU6ZWot8Z52/DgK9vo
r5eap3eul/SrqdcGrUIs6WFcqBWdsJ7z1Eu69HrEQ64uS2Yo4/gjL1xkRogVzAOrAP6wnow/h61O
qf5kuUczaaEqYqGoVi9tQapcjga8t7Zt58nxaunv2xUA14LFH6Txa73D+sthL6abseQrWGip5uIg
GOSEkYYf9tJnMhF9iJxiX+9phk7HN15xWeoUKHGkJi0kJxDtWTuHYIqAguEqNnoB8n5XydC2QNaM
fs8I+v5++AcirIGr4qNeYeS4JiNA0rPmKuMS+LcHuttx0PIiU3QH2DskW8CpMmc5oKNrXOIY+alH
9wWhz8vxD4I5anNRi67oM3h7rqUtjhJcdJFC3b+UZJbLdNaWZ3xP568KQXpy1CJVUxSW4JMMPnHp
qFNWoRznRrkr8lcOmepxNTTqv6te7xa8+A7oJ03iCujVnMx/fo47E+ULU1DcaHknya47Dwr1baKd
EysN+eDs9MTFbND6ZyTNbRjX5lGoNrMqZUVhvCLC1Uj23wIC4IS0DCrMEoyMJa6shMxElIzXVsAz
lYpuXybM6vm1vg+QrfaIH8va204+jyBH5phE1RbRnXGQiaN/CMu6hMlwucYDyPoB65LXVuRDjz3G
aYcaOYqt7SYpggFDjjqWBO+MkRDCl1NwbdSbIQmHZkp94ohwBsc2Pw4Dz2W9JqPZFxbpcBdTSWaF
OZF7VRZt7WtqEZdS3I6MKoHQKf43z/PPfPFm5zvNtfXyIbXIFufjns6Oa8u93tVTiJNPU8bFneJw
2WujsZQmYDsYFHZQkT7AAW+1m6Qg3WhJii4q+chMKY/3dvWjJUmSQWtZfmgw9DRabfXd+dDZRjCO
7q0InsO9R8FzjmxbaPSsWTwHM5mc3AxzXvgQyw1NWufpig0WPLggnB6FM/5HqROQjsMzopsoAyvf
TUEGPils5Bn2CzOCUfvh+jivg+1fN8v/8YlW2RXbngfGDZugjTLBmQNpooZ83IyM+IRJgv5tSOyr
CBOYhPNA8XIkWBAGpDhhDXcX5nC/B8Y0CbpTl1XGULF55JBB5zfkiPI/hgeQgG3FdgtFlirqkkZD
V8dqhA89ntdkurbDh2aRkVReD1k07HyxzZ41dx4c+I2u0l93/6X5cL44EC+nt5crmPjOPISfmJ6w
yJQoen+kPAn1mbQuLzCaxN3wcnpU+gwbq9Hj048QGBA/KIyfQ7dB/EKVsWdDk44/DXZVTXABj0bW
UOn0ba8Dv8yZkgedUrUhBviP1obzjZLptMweyqHuWkBDtv5Tn+fjPblZXrNGLVYeRZEb/vzGba1d
n69Vj+ypv2EDMo0U1Gmxw8B0Hve7oyC0kLIFGyQwwPjmSNij4d02J4VmJn/WTAaQzWHOQ2fdjAU0
Dy7S1BEJ4qK1KOR1hkvyd7CsYBK2cH8UqvGmauqFFdNo/+M66Wll3dYd5ObckCgxvH7yx8NF5z+A
Sdi02zu7MTqcs6wNZPAJQ4uhRleC2p3CgSbmOqZUncCP9eY8u1s9TXW+2V2k6DSJnwnf4LL5uTJT
qi/GfNAg84feYz6s5JPDoe8Qal4LDBYusTcsx/bygBT4AXkU66KYbMip4OZF2tlpDy3FvODTe8/g
qRJuxoZ3QKb0xV4z6dxIj7AKqkZVhjFwfdz/a+txGfqSY7Csfj1ey6ueh2EiMsHNeWnVYGPqULg1
18TWOJvM0AJGgJ7AjhYSi2W4f9QeHuJIVBasbT7vghUTdeiMrQxFdP/A0PRlZgmHXtGwYKv8aIsN
JCfmeWcZnZ9b065JowLD3xrQW7tiwxr2XKQb0JyADP70xCqw0OKwla/1h/W5ixUVpElLlPBJRMgm
FrUVd6CjXEV/mpbbAQjctChSC6IQddu2XoJJOe7O5JBpaKAqHaIhIADbLWJXOWGsRSnMSWv+KlmX
J+247dK9OoRY7aqVuI29tlRLLbJK9uaezHlmZxvY6iVPQ+S/1SAuLGeMf9StgTW0INGtSh6yFp7z
6CgU8APoVJMJ6tR4AD1a2DDgoAwwmmfOsN65fK3hBoVE6rEZRVavfOfUnkJG0kV/L1O8GXEjlxCx
dpCCHw1JivBb2vkMdTPkita3O3ZrDtWO+Q2Fjq4I5EIhXQp2XhmlvXWxTN7LR3LKIvvEHeczC5fz
hWCkTLTQlkWeCDssa3sg3m+251wy8K/MApWLsTfPE+gg7FP47DE0XtTRePweBDCLY6hKCfOPD5rI
77SRYqUV+WW8GPY1mqQAcdrIObOvp75TRRnbo7FkbtIGWbalJvj7wyGDJlbEQLbv/gUfq5soXru3
gLQm2DZ9PZ8vnkFXtI04M/24pD/VQjyqE60nol9smEBIll1VmmoziZVBwn18uFz9yzbqeHN+gMZA
vjUtzjY8/hNipZbmNmE1Y9Rj6JbImNDXYieCOL1WT+HYRS+rM+SVq0Lb1y1MRRGEulVk3LyK6Qko
EkDGzoDLlTTxdBPEb6A8LiGCfVbvVSj08QB7ujj4MS9bPnxMMDih+kpBT806k9Re8kT13wC6TU23
/8p0hNhHPcOcisSzHUfkLH90BIJLZx0QtXh894Rz4y9XpIA4O6dCwaLwqWWA0oq5Nro5lfKXOQ2Q
ikkHUI4Hx8vxeAJjhOUgdBUceI/mflw1o0SYBort8LJFx4seGpgcyhKqbR4OPxKwmYRX5/5tRofZ
0a4Qw2tb39gM+MVXRRIdH/HCzzAkb1f8uLfBOJGJOYQNT1H8bnvxcmvRQJrchawS+FgiXwRvlI2o
enBOjDO+Twg7e9+KGc+ugUGrtTbk6IEAfPKRVuZa4Y+xW0fuPnE9LRgb91i+PbeaRkiZl4o2/+wi
okETbeP8AfnimNZOEAW2cVSd4nxLvnSi5zxc8j29NCLH0JPYhirV8dxYQGDECeXoPB/GnaDVq2xT
fAX/fpD7Iu7sAtye8PPS5ZiSqJAlmDfhxTN+S8GAcazpHH6G4IZeJnbam8Cn7PpiA3jfhIoMmCH3
hrdYNfVTH8rz0HcD77AQuFSY5wHb3+xK+WTe20BqFXCWM8IQ333R0kZVmggv7b+3sCB2Zqc6H/60
+mjgEhxru07uBOs8D/sPm70bJV6RHuQNc33c1KcCEolEVMB2Sj5fVeOVvuJcIt7gpegLPjPbOgUj
QPACZUvYafna+kPlDayVipddrThtsnaI9fA5KOTvwl6ejmlk8ELi6zT+uU5R9opOZzDkEFfPmVVM
HPNB/Ev2w07olUpik3fGP8/mOKEZTYMgzxu5tLv3Zz4Um6lp9RdbFSe4CpahjKrMqi8o/LVwYKde
aFVWkH0zxdAKC2jU4boZvy5npkPd56OLhgI0JuaEPfypFbq4HKPNpMxs+cAzdNgijl+TDOmPq9py
/pLYGqN1QwtDoYuu/mdZ0o3MQMXCGUHGOYmNbm/mwbwIQ4AbqEHpXCpXPiZjqcJrtJFJSaq/YHPz
28OxXSLjRlmYmmpiacfSJ1N9i3dMhsnLbIZY9MikA5LvZwuwZ16PCq9XUP3idXDTXSUIndoXlwyG
Yuvrx4MdRvMsXYR9qBF9/3WZmWod0chbM53e0r23w9zvb27uM6j7WJ5CcHkrApuvsHEAoZS//0vm
iRThvWRJJbtzrnOHO5I1Vzc7tqVaTCpDrzOwefI/gYu9vahWiV61iBR7/Fwn3O8IpLrxuN56ZX7s
rV9ltPlmMSju6WPhcXiWim6gTiekamD9+ZxJ7F+3u2smohaWQd56G584UcyeUvADFnglRrMw1p2T
u8fBJld/KqozAWNGCy1CXvsNbv/nFGK+x6hnkvt7DObL6MoK+61w1Mt4nL1yC30GnljKeu02fuhV
opP/KUyoV0TCUNcnu0N2O9lxUeYkHCEMRXCR9mxgBsNAvXDSayylJNUZDKF/97+kqL/hSzJb/Zs0
qXQrb/OjhQvVIKi75FFDQjHvjDU5fD1DCWJL6vFTOboDCfEKc8v0yXy4QLzfc17Icps+Ggdf8QVB
ZswA