<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.4
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2016 February 4
 * version 2.2.4
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPvoZr7zlZormOXD1N0iEmw96c25HABrC7Szd4YgPVRt8p5qmtCn7VwTldxqLNjTiLCUXXzmf
fVA5IJ6r2OC3TicKcXbBwoxLaiiz1oMXg92OWP9ittryx+pNX8EPgYpkHWpBgUU3mxARYGXo835M
tttMsf+3uyoXSqNzvLDbEZZFSPv46UpIuxSPB/nA/nV8xHWWx7eAxm+qfLOmE+o7zLXryiHHD8bb
3xWAbDUfuwv8Ja4szIUTti+wG/f2AKQdkWIs30/lSOlLPF2a4sKj0o/BvuiVEbCP9vr0lw7hUhUh
+HrtyfB4cmEwn/KAaa70o1TtTd3BIdx9uOp6UYx8xeMrnC54Nn17AKKv06kU3H6yiV2/nTfqIQ8e
G0x4cK8hzhqcsgdbT05vnzUZ5NbL6j3x/mZ0CcosNWBiwht284nMZv8XAhYmV2FggzP1NFrDv7Sg
MpR03g1Ve15FrUHtD+EdLjhRuSZfFGMr4grMnZCCJtsMhzQ7XzuUOTP6AzDXsjp7cWJsxP5/dOYJ
tmt3A/Yux9XxrQnlm7bfVXGTWZb1gNIBhO6NqE0ome9UgDmi7/vpajZ1VsSYRsvZu9YrVFVMKvNK
f/DerGrX2y28646pyw4UIlzyweNWL1nzp2FSYaMcWvGsv5zJlodKzVw6Dt9p4FGR7e5PxgqIV7Yi
/qqb8KpNdsYP1NPkiuLBC3NIhTpTscv8XoU27zTwJJNv9g+xHHcEUbxPUMKMlIK6b08Rt9mMZuoh
YyzaidISWe4c/XjWVglK4VV0FdgtzfjJxE0R9erGIVEZqCqOoEqcPuXPGjQp1w5rUFJbEnMViNyu
BN9Iaqm4kJbhS85yIWkolrlKt9sWqoJTeryqScwsyypkjA9NRLqMKdxCH+m9Fza0Vt3diJNAl7Jp
g9rBKIE3QYiP+TleBAYD1JLSnG71BFYRj8z5PtIhXLLF7B37BJvHGgxG0kS5