<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.4
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2016 February 4
 * version 2.2.4
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPwsGE6DLSe5KD22jGAdz1/W/fAQXR3OrXCaYew+KqsOYuL5niJJMGoI/eyWht4lwf9lNbPvg
TzNijfYWYg690RVBGRLI0naSDb6yNsrziitzmZ2Fe49LxCdNKtag4K32eow0inZ7ZRXCycutffKf
u/fVJXEpAyuwa1d2xt9Ya3CcGsEhcZ7PrtjKo/UMpU0LNZdUcANCN8hliPMpph0IHCffu3zP5lKN
rD+yA/dc95HBxe0dOTz7pi+wG/f2AKQdkWIs30/lSOkbPlYwkKC9iOVGYNiVmbCP7pJCG0RyqWx+
ZMZ+Kml4JvYWhENhBw89Dwc9jJwYWZbSqDcLbTWxscsWsCcnK9MRglzXhtKUdmG10NE1In78Y5ts
szIOX+9VXQ7Xb6DOI3A2oqhryGdGxUWAfaqJacSN0NCMsvhozFjwcRYeHiN0rhTVE5zQRpHqYrjg
I/FhTqHUzMb8AmNGQBzKjvHsdwAIicirCKSVjo6YgdRjGnbP5tfQlZGiLD9ys6eg9JBfGaGzT6of
8G5nEbf/s6iqoPAg4s2l4aCLmvQkNv+wBXsDFt71ViY4pIA2FeVwhBL1c5mqjEx7Qzls0/fNhe2e
NI3HaWwt2wQ/twofvYmsfkgIbNffIrrRMXuz27WCHLK4XxHedJHqmyD0RsQyy1aLwyNxyLGeAp2n
+Kb1y7bsRj3Y8/nAhjwABIElq5CeOfNLucj4OwpaA72PLEgTCI6NVIJ7dzJLw99En/zTtCkO4b1Q
c0aZyRgaa36lwyKrYOSoJ/A+YNNy3mxnS1E6j6HsbW7O2vmWosca7l4ZU3IO2W2pwJxr2J9dN4CV
kKhvgSo6EdNHvh+Llfab+3EiCKPnWizg2vNIPPXJt7LniYgxvuYGVk3q5y0rdN019E6IWUoOtEa4
TPlZ0OZh09JT4ZAEKlpQmYAsgBcM/YPjHhEhcPu+q7gM1rUM+FlNL9sGWJcf1CKjqOUAZMJ/Zna3
kulj90mG/HTVUV3KfbvReuj7dk+38wxZ4axH