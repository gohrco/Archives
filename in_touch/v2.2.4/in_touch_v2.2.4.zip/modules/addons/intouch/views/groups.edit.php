<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.4
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2016 February 4
 * version 2.2.4
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPrbbbqeuosjjqTS2QP4ED8xK28CUIgpXdQ6iLEmsrTNCxGvFqgGUHgYcae0kMvOfxHG1330l
0YAIPoRzCCAowOFq5FbFJeiOrJSnnacE7AqA4DiwiR3PwTcVV1Of9e7x4WY3hQZ1LpN5xS9tVdma
pnw4MzLxKj+vtsXILR1mO9LgGsWSYIlRayOEPcEgG2tKbSkzD7WnEAfPq642H6BT/smkyO/Go/Xi
XJV6YExaNYTXG5dUgsCbpxf3+a8fHgUw1BOC3+znY/1V6hlU902hoGyqzn+gJXa0/xVbX1F9Vets
dLE9qZvhBOH5sxhTxv25jLxT9lOvJ0bFx9vTkwW4VchfMF2W0rMyVGVzBX2FD80316cIP4KG2WXo
UNF7MHlsonBBwVXzelv62G8Ga461zIWlR4oiMTJTcLTxTi3eRSm6K6yjZIZYTX26aQqATVBp8+lB
qTw13ZRyhfAIhLNj5//TnxUu8SVN/vW2xRnkCoOS1gy0WvAa50iDCGFtGfP+kJlPqzmGpFdzWaQy
YsPPOGr95kfljISu1NymTn3w2P8/n6oXAQBAqcd2TLcoVUkWmi+CLgY9BzWEH26C5mMH7A+Su+5z
tZNeCHFnR3DTuWMAeInf1YbM1NazLPx6oqzQBGp2V7niqNdRumUwIdTUfQE+xp4STxEhDwvLBwp8
J8NQRAckVKNGD1uIqeSdU4YNe/wNQOSxzvbF4pAP8CsYCq+Kz0Uu/wv1Vo5E6kHR6qgwEglYC2Hi
ihwCGUgaqGRKLx3iX0B+5+F3bjV8UvCcUOxnHl9I3afP5/X4WHARv/GqkZZzDaKBMEKVcuzLhVFu
LDtS+nZQsTuaGMT3gh/iCLBrzC6Vv8n2CFxdU3DFGgPHn0VjVdaBIDQKog2C54xH6+07Nv3Sc9k4
rhG1OCVfCKXOnbW72u3Yw3NmJKzr4uhnlMcRjqCLz5KeOs4jiVkxA6HTnvdcZhJjHjgwXS+ABF+U
uGwg5OOlEt6AuyN1hf+MRvo4deEguZSUVfrVmE8LKEBUJrAxsJgL/KNGzvr5YN7cTmZsNrQpRTlu
Jf8Oy/FJ6uBPDkj5TamSk3Zx6jwN2rND2wwL+nSEGY/EaDAfTI6T4fTTmgnTZq2rzETIxBo7aQJU
rP0eP4wwNd8DtEmaNxGwxhu88pLJgv8C3Mq0feATzMhOxsTWYpWAgFOjwMvv1AWHxwsJl7bbRx97
1DNrH+BvBhjhfLd6B4h8kTsnB1idLam7FqroqvlbfeN8OjES/dWM8wTEevb++iePbylbheaOvzHQ
aUZuQZi88NjF/5s2dcYzWWq6y47ojC4P8a51/pg4dkqBItNWR3W67vBP0RCIKlEEowQ9/rv3GigL
0QcTLoHfWexKkmoXHErOAruL04+QLKfSiPTX+1wQWJFS/nDT9rC1+RMQbQgj0ylvEnXfMJEGJkQX
p05aQZDLBIrq9nJRqb/+iKJxIwKTPPJT5a4Nv8KFaOzSlwagzOVC2dVaydJUm4Pqloi1FTv4EvtE
xVjWho0Ly2rVgAafgJVGPy3cTagucfrf8JLDttqnugerOxToJV7jGSn82avqCP8Yzmx6PE1X/SCV
gPYErBzrBA0NNfUaEFF5EGKQ8fMjZTqPDGnDCu7ewku/vRwsCqsa2njicUreHDIRVpEtq4QPVKGa
LLdYsQ4HRLu9qpWicpS8LtM80yb+xnb0fOeVQsQrerP/5YsTiTaLGhK=