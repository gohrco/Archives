<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.4
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2016 February 4
 * version 2.2.4
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPvO1mXLGxpPQERDNDcBisEHEbI+k/gFhk9Iifw99me9draiioSxojSLYrI+RZ/Lh+PdOHQg3
ZET0iM1bUm7RKat1aBdw3ve5/ev7yw7XpBv06wuElrvmJwJdUvM36m9mcWEF6N+pk41CR3x9i7aw
k0ReloLIoqlds3Q2yG7/NubfmvYrWQSeKEfWFR565VLWkuUe2QAY4L1iEkbCx+ntJZT7s3WkBI4C
lyLbsekAAzOG8JdiMtiOpxf3+a8fHgUw1BOC3+znYs5aqy8Qrk4pdo3971+gJXbL/+IfpUbPYjGf
11EIlIf2E1UuQl8lt+S0B6MmavR9IHzzGgn7HGs/kXf1BU9Y4jaqYlU/bR9tPCR/86N8Nl3HVwBW
KwE1VysD1XpZ6rD937XuNge4khhmIggGfxYFofMrdUam/HSZ6VRxnaEsxg3zuC65YtwaGpBNP+hl
DjeoG8Ey4YxkGprDTdV5K+wvA/MishslREZ/CbOfNcMwkIjs82DMluxzCOfakOCBnoMlsB2Tx433
66rNQ2Y/CljOnKEp6al5prmzuO/ItGQQAOl4CCOsqA9qZj2HOMa5EX8HuWggXbAmdwIGbGQb8gSC
1dt0hDIpuKTr1pl+oUcBLWjRd7aqUfgFbJs1uCQ4w3clcrFH0bLKd9hy+mzrZktH3M6lL+R4uLPz
YWVDYgvM5PAFEeNBiCT/vPaB1ZBAdt9TLCCll0i5fFphXA9ymX3H5cUeeA3Lux8YnGa/KKLHYmDh
w6K9eECoUxr/t378SeRoD9UcIalzsK8w7i9aFUIpnTg5oAzWBytgebEG9RiW/upWNt+0JAnlYmZE
ypCf1t8HYJBWtgt4v3R7pUwOhM0IRwDDS70T0FMQQ6WA88loeD89hXs/kgMRFOjF0P6+Tl9Ve5RA
kUaxeRAyMpzHayejG3XEmEhEvgNeU2S9Pa2Mt12rQ9w5gzMfguG1Z05Rxuwrq0/n0wKmydPrGoOr
EYeijFZtZDF8+slHusSCksJaOX+ZjPknFLRH6F6yMe6nANz1O8Dj5jWPxphtEdTAFKI3MZ2Ti9Ho
aUOCgeRJi9UUpdXQiTMFiC9OI9sPUy3WSurop+6TzJeBGzWd4J22RbqNrJck2EdfEYZyV8nHEooH
oyu7M4MdabkJgngeQhZSeD5rVhR60GsfDcmSXZaPpCJFG0CxK7Sk7lAS9RxGgVzX+ySfwBv8m9nr
fNNewVmJaxuTrcTfp58jTCB4OkqF5e9J6jSNL4ztcaXT7izbOIPnFaDOBrxzVV62x1SwLd9T2P+c
OdYOCXamd9NIgaL/Uy0hBCWBefbpsdGmaBh48ezR8941wmaQ7gjt9rt9Z8wBa41FmgyzGTQpHau0
KEYgLCH1ctbig9FViWCnk5BYR6md9zBY8oMKYdJVzEorlERyyVdYsQu2V7ImsW2x9Aup3kB9Mj2T
ZrEUfmAmYY+lkOpQ140qQoyhc0b8Ji9t8QzYOkQKrVJasgvWnbTcXjcJwaF+GCAnSmAkBcMm1K8A
ZnaAq/fvHD0G8fHqWPHZ1x4JiJslufZBdvl7gpJ8dwGVQTFOGtYbl4fIjDtUVXKL98nQpWy8ySBB
gAS42KpM2epHK3MIq41EICKCn+mH/gBM51oVTS7lzjG8zhmoX6t0ZDhIVIBsqrv8isVt68+rJtis
w7DgERn+nLCspy6gd/wQTCqqWax8qYR7TkE34tMDsu1m2PUHXZ2E8xZNpGapNEh0J49WAutAZB0z
d4K0e4GxkX8jVKu=