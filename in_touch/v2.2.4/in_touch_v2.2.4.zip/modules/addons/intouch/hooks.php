<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.4
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2016 February 4
 * version 2.2.4
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPrFpHV0eKhx78K3GqnDuv2qNiqn8Z/YTrP6ifk+L7fHN8c5QZ1sGWPTLb0vPCjiAVYxd+RK3
Rg+a2kdi3xWJrirWT7Q8l35Eum5dP6qT3Ad2dI1zKii7ZiU/VbXmTaihtWESUfPb4FrurBBae/H1
PZ6ZfT8ocsyBTakJ+9TwHgkn8AIp+UyJ0QAySHdA9qX4HXTI+nsaqOuf29MBoa5k67+7ffRpo7di
lWleS/Ki0PFR4ykkAymCpxf3+a8fHgUw1BOC3+znYxfWswSAVr4dPMgJbHyYJXbDetBvc5nNZj8Y
PGv66upXZpLq2gjTh/vV+DWOVbpH6HcXPzCv1Yb0J6+PpfZ1HTgK8zzLQttXUb+/qHwVR6TcrRvv
oqQSKgXo6WoeoEkgX+hu8bwQyfuTuUFC0nDDzFkQbMXm74Gu7V3cf7N+vKo+uRvnmHCABfNf+0j5
rCSoPuB42b9/AYKxXLrsPtuMEWeOIK2cM7AqhenHvertxVDi21JeFVkDq51Rr9wSYesHekiCFw8k
dFa1pHXm9QdYsBry6I2RXPBAqT/bc/Qv4MOkeXbOnZSo9c+OVoupcgDbjzG65GIMTCDLDSZoIr8Q
odtu8175+XotGPExSdIS0JMg6W2YcdekK/v06sWXAzX6CApiqP+BR5TZ65qO0HAFYpJuJKB2vWxd
X9V1+etHdd1X0rn7o9g1KQsV724qVV8WLHc6b0k3GiRq4rS1K9K50fgowNevxC/sP0W+v5WvUdsR
+p6hCsF+ffo10jKgmPlPHfESiOH3bBXLBEsWjMUZ0L9xAYL6C3KhHO3HwNalqjKllMrQ5FXMQIpx
s4llvCl646kChISTU/TWJk74ST2mGlOvu0nIf3++hCpBx2FAJ8C73RB6y4eQoMueOq9WRSNYvlYd
ib2Puz8MbqjdUBDns5jrVwcTqf7+1oAFP6EpfmbMLhspnH4ot5ce/m5td1hgjSvIDZCMQtWjmnN/
V4yuBNG9FImg9RlVSxIk2bbNmQTUgt3RMDab52Duda44OIHFY4pHyO/cFkgJJ2KRdLPeLsFrJ8uf
uCIFviPjB27WRCAVcYXBJfoOge15SLiIdEjbhx1o4qjItvjNMqobcuGWumw5bYhfvJte47SAluK0
ydOBim1SZiJEBp20uttkPadRi3bX1PTNomEFY+1j1du6D9XJ/dzzmofwRqWfQaMrlK3hfX04Lf4L
HwuDCfAIhC3nxDl3wYXEgg9/LTIDgLVuCnDdMLmDPP1lXOMf52vJHmjV5u6EiKcwYhJgICKOIfLk
VX3mVeT8UphSt0csZ9cDtZPrf94ikTYAONZHTnWAeRnyIPSxDBNl+18plSAYTlnYBwdbFYoo9bfw
IRoT/1guGhU4y+uselOli4Eq79DaxcMMmWEh4snIavf+g05LIO3a4QFJdvFYulQBL1ISmaW9P6Jk
fLAlAdkyY79J2OWt9We19Qk1fvDDRX03towrOEw/Ox93CG9CFWbyZWbZaDkbem0dZCSiqW/xljVu
clxrPiVVPpRW1EKlyf1VXkig1pi+7Psv102t5ixkmwcvfROoUhONw6gbYSSKbEKRDDrEB19Y6tKf
OEcVcOxh/hZEU/CvsbAsx7U8CY/6Sr0bTeYeC2s84jUL+YiI24jI5XIdWf8d9TTew0RBcZfOpj6w
xvyWSXgmeBN7pF6sgCtvdJB/Yf0OxqBLHrd2CXfZ2CQtASso1CHyCeOTLsD0rtlHePyYptQQFwYr
JStVoJDD7BuUB7/ZC/pDDH01N019JU/s7ETuyUWoQ/KFnta15b1Rg4qkQIPDp7X5AFvI57i0UocE
90jCeQLcvd2gfB82k97NoESBmLorSpCj5FoPhBimJLGH4Bku3CAddxK/jr4QEdlmx7GMYDx7cj2l
qNRc658RdFR55XULewp1LDHfa7WzP5lFK8ik822IqqpgUtNnFjxu2U8/a45ba3M2mZ5VbhmcJr18
SAH5JQCdRWUXA4/ZC8OKt2ppPUCZTQKJDmE9ieRzhj60DK3ljzlk4djTKRAEPJuPiHZ+ed0vrUSM
UKZ3HcRzDuuU8dRBXIep0KGiaKiqN54vJyKSYkiLJUNtuc523cyBH12dXO5JrA1oHNXvLOK932M/
oaaPeCZWpIny0SRgleqF7GVqDC2n/3DQEuA2ecwBG6MvO8XQkXYfbBO=