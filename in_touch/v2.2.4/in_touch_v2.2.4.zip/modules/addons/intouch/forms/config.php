<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.4
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2016 February 4
 * version 2.2.4
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPsgKVarIU4DZFoRhRjZnlyr8u57vs9yntgwi4n171n/+3myK/7Jb242pFzSqcjVHoHHGjT5T
tL6lrlh6/3zBiWut3FZeaJJTSco+2SPHUEOQnEgbr8vUxvu0GqIsIJ9SHfB8PhHCEcEwClaAO+ZG
CWo5MSpy6ZgWoTQ2y8RB713NEKDVlKrlAgDpH4h2vLoWjrguNbI+LMQgWo4DOoP/cD+nSlQxSCbd
kaCedDHQ+RnlDKbDWze9pxf3+a8fHgUw1BOC3+znYuvZ61dqi68NKWqGQX+gJXaVE9gi3h0RHyZW
X6/rEcgwGo2KSbIy7gYUHMZxH5GKpLI20PJbnTkrqB73KP7uaueKC2WqqIscU1xTdwK3ncFmFREz
L7nmzeLiy27qrn4z5rYPfqIjsywgLGIl2BZf/R8MEEENkVUKcXFgn+ucCMMoLA5GwPAFXiAwb01Q
iy2tRTCR7Z4FOz4gKXOSkN7DWFNoU9e2Ei9WQbV2bUpmOVTh6yN7LQlMy4neoBc+vuvKPVAOEaw0
rQOTW18Lpc/VJRHHmUj6IdwiFcQ9L2khIMMYU6uQEUeMUsv6Y/nb1KDnd/uUR9IbSwnlqnWTp5NQ
U7bcCiyszhMYp7PJ6mdTcbijppYIdLzD/bb05vdGUMAgJtimTtdw82PZ6WMrE7j0iqC6i30oX8AE
tnyP/G6fgOZkgfrs+AKNcnof/Xr3MPH4AgU44u4Msk2H3TkqQw6Rs0m5ccQVKGInf7+hfyH8dXaC
6Gkbkp+dwCmzRiYF648vqzcifvp7GKp0hA93jNC+0s0Sa0pLIzTmbB9HmYbVxkz/SbGeeGS7Vo2Y
RYiFY3xodzjYG2sdO1E6cHIV89aihPkKOO5OGxNcJAbR1xPCavqlz7wVPlpOheyeG1OU7RpK1GT2
nUzNv+RA5zcimH+odndKwyNDdoYPOb3N31l5nhAMrgENvipAaB+GgfgOm/s/b0PZpg/YAZ3H925+
Jk2LvjK5ZaBJRWT0WaPY1IqcJTVIlu4DhyJKSPxdwAc4OqxTNUQXwgLLaIPTyt+Snez72k4pti51
OnIfHAvyR49PB42pr4ZPamWiLOmh3BpfWdfSRGBrZgats4grR8v9YSdIEbrA93U0Y9HPRQsZ8gaX
6I/MEzqaQSTjOZhstaHNn/ErpWmlG9JIafjngTVkk/62iOOK4XH998gDcuippWc+w+zNVlAHsEJW
ZDD5AXvP1XZKzIlykAErPaHEzeX2ZH7rAk9L3lZNK5OX+8voteaR15cedlD67b6vHHgURcX02g6b
EetnvnUyIcBhnTaIpkLw5FVDPxe9NN2SgFYXBuOP/mg2xDgjkqcgNyPNH7/xLTFWICz1MLrbHUBE
2DKtQI0Urojfg9uWtL7BHVSghOcpeAtgDh/Y1iyS0u77Uqewqg6DQTI7e7wMsh9k1rZsjhaOTuk7
a24Hn6aDV/q0H4z8Lcqw3DyZCTyf8PUrO1cM2eHb0J/9gndMAUUBA93Fi6/NevzKrCeQkbW1RRlv
/C6hQ3sSASlHVZJXPnLvct4Ui1IkA+4YAFQScowqCpZxfvISMstE7xICZkqb9Ti2RgkuFqANR4OI
g+KkCi6jo5bmzhF2StY5vck9hzITuxuUHMQvX3Eer1VCJYS9JEzTNJCruP+f1YmGA314/z447FYv
d6zMH0is+zT1LdapLiiGRJ1hC+NWvIX3whIZTimOKweX9P34aRg9nTjLouF5DSwkbYb5RSyoW1rE
2mwcd97KLbxnGxV4SGF5QFqKkjfQpV2ve8xZYZ2KL5UmiYyiBm==