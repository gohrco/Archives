

UPDATE `tbladdonmodules` SET `value` = '2.0.7' WHERE `module` = 'intouch' AND `setting` = 'version'

