

UPDATE `tbladdonmodules` SET `value` = '2.0.6' WHERE `module` = 'intouch' AND `setting` = 'version'

