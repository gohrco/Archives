<?php //00920
/**
 * ---------------------------------------------------------------------
 * In Touch v2.0.7
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 April 12
 * version 2.0.7
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPnGZZoRK3tG9jPCQ1Sc1SKS9+GoLapWlauMiWsBJ5AJF8ovX4tky15IUFzl0LZWGz5NNneRb
ZGFiyx51s4EXwMcSGlGjv635k2VDwTVCldNKd52gyleD+xSz5bJPQ6bBVfwuxLHmhuQ2ezU7I9DA
Yrp3FlQWrFi/A/xNGeH4/x5AOVOSUxSL+ZsDfxV1h5tSTO6QhwV+xXH0JJG8W0HH4LoT5XfvrxPs
OaBhi59R7xpI8v6XjzmEWhE1UbZrQM7u+8cGv93EERnc1QJPMYFybWGXh1hbXk4r/xISdMN/Gmvm
EBEkSLNaQxdC0tq7DUhvUA+WzF5+e/FUMb891zIzlNp4WqarZ5q/je3arjJh+CwDTAlmpDZn8FlM
5CSuP7YquaVUQ1A23/eSba/EubAhcis+Q+Eb3BfBFLRmD3AtJCB0rabVoOq44wRLVc1IDnKcc3CC
WwvDVBFcBxR7qnjZGoamP6p3wBgObtbITezh5BFjiavWBcud7RlB53WSLXuYsaVW9QnSCxup9l4W
5B7gkF+MxdsWIfQXhWnp7qfKTDeHRCKrtwCqHvcRANyA0p3fAz6wRwEm7+Olo3bBXsL0cKyD3Xpi
9Ys55S9ntgUu2SbVpX9ZSWkR124lXEdWYHuzKWjJp02PDuNV61W3YNxkYgYW6EJg7C4sHjHUlQp5
Gx4NTj5K4XZfbzo11cpFvZfZ7esuPxW/e/MH1JN6VpvcxEeJ1GEI76A9uDX4zfwQy1P5VAYs2lUU
+1Ywp99g4lv5sYCrroAgWHJdTGmszsirQxtuFfIIjMTGoUm79jKOYFBRMt47QE/6cO8bjhWIJ7EL
jumXWJWaRXffhXpURbnHNSD8LyIgr96aZkwhsE48ZA+10DUPIWpYShnABOY21S0sCjmPXUVh65gq
pKEairXHk8FOlxj4ad7rGjtKUe2oSXfhdfv8uXRa+acmdLkaJ2qhqwOZOpeuit9tM3JbVpSkinzU
hxfeU1xTTZlJlhMvzhz9N2ER5+IrixKxt7JSDNFnokOL6ZU52wZz09WNVzSNi6NGg4rtdrm36Jbp
f+SDJZlU2xq34QDNwtHNJngJcLQ741wiH2TmAm==