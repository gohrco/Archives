<?php //00920
/**
 * ---------------------------------------------------------------------
 * In Touch v2.0.7
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 April 12
 * version 2.0.7
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPu3NyC5mFids6MHbukYizHPysZPM0hQapjL5FRTdGsJzI1lWs0Q2iNG6xv9XbvNDS9kJ+ywA
MeTUM7y5e8RFvCIwjqXgwckYPA8pT3JpDFGEjKRF/iTLAaI75x+bCcZOz2c073CfMC/ym5N+FpqS
41j8+5Uu+sfD6lbdmVOn8cXbvHGPstf0cj/vETWKMyEAQ9BkiI5om0HqPFzKXZBAks6r9sdApzRL
YT2uAAIryqX88FDNLkC8CvfzWhE1UbZrQM7u+8cGv93EEQTgW270088SWwdovngLd+4pMEpC1vUG
UWTU3lsBqtbc/B0h+01o40kiHLVYQT0SkYXvMSIYJ6JL3qh4g7fyYWjhC8BvvKKNQ8i0y3Jmv8ZP
/HNfctIVk1Uu/TKNs91qDnD21HgHzyjtvt+JcIUcM5C+0LPSLrY7bSxTbD5D4I2leUbLN5JycWgx
1CCAEyxk7KcZZvcMIW0j6Y+tn944IG/Cxb7N4tEBC0tLLhizEqu+dlEgcROboQKeuHVgt+3i6GUL
3mR9YGeYLnyn2GaTt2SSEK6uJOtJ2p2GgTANira6gJFoaTnZ/VrGugFwaCQZLShyKRjpaflMSBpf
JsZ175isGc6BMh3z09DHB2hwd3abXUVZKNJ/2W1949KiW2RR+15JtF/1mAKhkk0BpK8Zy9x0Qh07
FY7x6JVnLPxOvbAMW98/A6/ssl8hoQaLYwIvfrKn1tEYFPk8LQryqW92ttngLu5wjddZJUZEhQmH
mvBPev7Xfvv3tTgZ8EDa+7Ls/IDvd/Mb9fxP3SN/KqOMxQNFsSpP3c3ViA51E5h/3PlG/TpHxmOv
zijBGB+NnACkxycNmaR1Q9D2uUz9fcgVG4QEc7+r2S2H8CtKFJasGAZERgg84Bsa+spPiZiMt4OS
apyoUi21+/6C0diiOULAmrv/RPe8OhaiCS/+vAm0YtLbYxhhd0cdIUIDjoG/TXS2yAxFmn4oLV/b
muSg36HKDPZ/6rA1/kqL3YExHocPZ1yl7XjfVEIAcFBHkqvtUYHa2JLBIcDYzAuFc5WBa5Ef38N7
rZzzHAZc46VtfJNU1/45Vp6E8S0NKIdaZMBecSFSmGoMnlTQkurpQXz7/gpjby3YXeW2uA62YbQP
GmSOQiHglOwXRpcEJxc42OHM2aHM0uVF1lBf/46tuEHcegi3kpRrucE7y1SToxp0X/tEap9TD7Gk
fld1xBZAnkHmQ89bMao4zfTubrKTKjrY7PO41Rl+t3i3ATqliFDz/c5wAW2Du8I94e7FGVOP5snI
sA+fKzEHNsWimb2X3QcFLLQ1awGXWwVzYriv/qCWu3codmmVPBJeXeNyqroZVB0xcF0bVjKWWWDh
MRJfAdMCuiqXHO20MCzpQnHPpeWQtQ2m/tLN4boSZ9DPs8Uas1zfQy3kCUGommXObffq4nXCCWKD
jBrRAkI9TZvnERrtIOMoP88BuMNt4HORrKYCojrG7I84DkB7pCNeWA4Zhvmsvl0l6bpof04urIgK
THoxxwQLXPOgxWrWor03w8hGwTZymFLQ4zWsB8Ych1Wl+D2dlRtDpVYYyz6349e7XeNrF+mxv572
iK3z7jtKAQtpPisBgCmSTy/hS5AAMOuPBAConc0KWp4ZZF3kVOmQtn4TW8OhOP46Bj/kmYett0gq
nXZJXFFRS5Zm7tLBVYUT88dlgQj6+BJGBucRuu4WHNGBwooOWDANe7acVA+DcLjCEeWtABWaoyEt
9eSF6CMLU3DYMNy60O2G7gy5E7k+FJvUrwmGkitXUPz3hcI6rvV3pV4JrbvbM9aTan/fKZxTHPHh
YzFpyHHbVtYStQX29snmaxNmvVJ3RiYcrx9sW7fO8/DDcMstkYD4Crigyjk7/ylJ0wIRfnT88dsJ
5PghEN6LerraYaHj7KHXTosg0kLEjq+kxjyMbqLDt2w+m9D91AYGRAKcZMyjB71v77SZrCSt5iTJ
qGZfunBhHZC/cga6GtgQo6XVGdZFwSizipz2A+q5hrl/812ZnaS6OK7nDqIaxlTy7T0Nk7QGKm0=