<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.0.0
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 January 22
 * version 2.0.0
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPtdZTzLpJqmR7bFYziAwxQesWco2KWMrGjy/t0ou9y22WClSXwQbN+qHphqZLokknKn7aynZ
Exfp7s01TYnyJfAIctuGoLBlb6XBXYt/R9C2RVCX8m6FDrgI/LVEDoKhBaJoXKqUlBK2tHmQKGQR
y2MbDsyXlqeP29uZd5VKPnl60MD40zcqFvT4XksYbU+dwcRZMNAIXKRxk31LPvNDHUVaYDalPNr8
OCwg70zchK3Bmr6a55UztIJwGvD+isSmvPTFfprtTXYeGL+yTFsZzumzINd47Hmpocy4voqkPuyJ
HpLkTnOspcEEURWMQAZen0DbFxAKrqJQTddefhozTulwBY5XJymPOgF0T5u9al/mr/4NW7vO7eTw
PyHiugz6fcmETooWriFQQVEoSQ5alC861y5lNGRJndvZGntnAqvjVXS9CjU0bMnwXhjSpSV4BQpn
mgq80eQIiFzAn7afaPG11KymPtl7HoW1SP2A78Y9kDO3Kh0GSVxB/vmrFexNnTww6M15mLT9d2+/
SbfZ8OMi2UcJOEigBsfuLsm55mfoA3INpM1FjiG+NDa2K83IqQIAUhuwzkEnw11IKSDvSBJXBZNr
1Nvz2NO9Ctl+3HA5hB9RDU3dhoxpljh6GvpI4F+2KWpEHRXXJN8bt5FrKLRW0Z41+kFda9tjN0HR
Pe+RfFskuxJUhNojBIBwWiZ1aMT+eeL6l7BAz5Lj6f2X4D4r4BbcihgDnJAg9LC3k6W8uJqam6iE
y76Ff5lySglbuzXU6xs3DQD8ZYfWcHHIxYe9d7veCQvedGNaKEAkoIE/yPmL8nYk8SwVS8YwRC1G
zSbkPdm1LJG7BSKdWRAbCeRuNVA6MoTLHMkSezgWD4FZ5y3/GtngnpKdE+05gx8ClMDR9F9BoJWw
3fAvSf9UOPDib6bvZ4HT/F9kU/mDZ8Dws37qM8SVoaU2+jzx/qhD+ndXlBOnWmb2YdsEAMgvAT8x
Xp69ibDTAGu3jrsjeWUiy89DhLSt0nfNPa253TiKy/giSviM2FnFq3UrB5H4Tx7xCaKJQLVAVDrt
n0AMZWo4unPdaH5vmsGpZBtyZmaa4dFditiYGsCdoJhIz/11nu9eHp4tYlwBAYET3B2RcAITviII
BJjjkIT1CzifUU+jSfDg8P6rYazdBx6UFj3L