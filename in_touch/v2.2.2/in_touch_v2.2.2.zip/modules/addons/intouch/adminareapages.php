<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.2
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2015 October 22
 * version 2.2.2
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPvTHJ12I1xKdVuhPCnFn9oqmDCY6kbQiAeoiX8w4GV9CE28InPJTEddYdAgKxpI1sk0RvOKm
WAuT2E861jKdg7jLe2fttPQscsnYzDESaR8WrAwG7nlzv6HnqNPCfCBHRxPS7hL1jEr8k/QgkEmL
uM0/XLePgMUgfusyczDKTmbNbL1D6tGKKL++DFhtpWmTmpKKVzky26/i5PFVAXBJv7aCZ8GJbxKw
S/UDUc8G1lE/AaczDESgCqagmGgayneKATZEGXfNQ6DVpfwx01N1BRuHQzU0RZzP/oKBpAbP5FWV
B5wh3CYCwjCxqjNqrGqcmrDtlq9ahkiNRicXHSeArabBUMlMh8lsL7W120QMjaTRCnEOnuoNAxI4
YGcHN4bAFcO/3/CNYUyYk/fVV12WwyoA1Gqcd5ujB+bDsUcDpTgyuxSSfdqmPNedvVZyhnpyO3k4
KDE75GP8A98wMThw9eTtOlwcs9r9ZiN57SKJEJ86eEe8gd+0FsoZpufC0UWSp4G0fDsnHhoDZpd6
2tgoxyrioLR/REYGObwSEA4+PuhjkvWkoDsMRyZkZAOYMGKsj4QNO2buzI2X2TtpcepXHDT0StXv
0YMxf7m5jvFOPcABE7atKF/5Ds1HNMpXg4hlm3ldVHQcexecu1bskrSvlaTFQ2ybg5HIzESNKuop
PkeGu8JeuNsYfE+pnjXw1uMtL9FzvwUrk2IxacVVC3Q3GVVjyHIjERsKSWc+W9PFFzpwzoTAHGvq
SpbMTQDdt8A8M7c3DrdO4M3XO3+NUb3oU3FrdepURJdFdAE+Y8ysaNIykQIZ6BMzRSV1KFUu/uyN
SsnDJQx6R9pdn1oIqu5yfKzjGA6EKOD94hOj5rxS4jndJk65D9EWqaiH8XFP/kHHN7xDRe416AZU
GPBVOi0KB1Jd7WYB/BuVsoHxcWa6dZD9ZVP3lJHckPyQPfA4Tfpq9r8bGUVwjbSNO94VRyMJob3Y
5PpGkPswnvRYyMoOexzU+AHp3F/xnMxHBGLUAW3ndAYVXVvQaFc7FwIpTkv4Jz4QNURwLWaGNnbn
oN0RM2Ur9xfmXgaMGnf9dZjW+BvHDHzP9WlC2LvjxDPuxpEnhxVLqz1M2yqj/dPnFg4q2mGFQw/+
h5dKyPnRZ2WiY6mxqO78/aSrH1Zj3Nt3vXcv/LjTxA5mSQ3cP69NSxO7aslXjS7qmMU8ZsVeX09D
6Iz7ZWLc8vb/y6LGSoLCCD7lfmwe7efumLPWw14vquU2lK4xwIXkfcAT0vZ5JL/OM6+ISlQxDP2F
SnorhsTUtFNE491nHQGaolVgAcbsgNa5MqzVhqatIF/LrziHOViLqk5hFrRcZFZi/ZgacU94ZaZ+
skO7rmeLmyOYSsvhnoezK56KkDUwgOLe3Fv/BELJMYo2jRC9fNunON0TQNgt21lpPVAP8liaj6JR
hOycnj4Ux8odFvfKBWa7Uvv9mHTVuZjcx1nnXvFJGx7A9mqug917SsK5N22AyoWd05bdkbf9jUoA
P2j1/MEZg0FvxM/rjHYWqhVEzoir9wgW2R5LgzTHco8RtiFzeNi0fNliOVDn+vSZX8E5/zLSins0
IUmqfYKiMGvwRIcNejaCrzlPrNO0PJT/7XpAodzEGbqi/JrnpF1EIS0Z3pWok8D08ue8vlLONywo
dTyZJ5TW30VT/Vo7YHn70NU8yrsW716kElc3ATgzqC3Asq7/hHhfKYOB5fJ6kOoCgDyNpccylh4O
oqt2QrM+SqgEis5ag6tt9SuEmOG38Ec3Kd+oY2scV4Z71DvhBZsgKZcPyHz47Djjt8OlP5t51nz2
uL6p2l0P/Xh+8Le8mQdb6A0IvIo+N4Pfhvn0kHp3K8Ho5lycrGikdQqQUdl3SqpVPGvXf0iGGnJn
lSBwV+Yatpc9pCxZ/57a2OwdYHenb7lm2FCJhVpb/v7ZK8Qfnn3O8pBF9r0HnSG6dATWO/PuusXB
ugWj54jGUaV0W1nKYTAXxBewRxoPNZjD+tIpVtL434HWw79+pK+oEdd622rDzRTWIXaTE8gLGIyn
mDlKVjNqU6UanezdM2SLYc30Y5MZxHVv10Ssf9BacKfi+xje1TCIqINUoEHl/18kl/wo33Wuftkb
zUTQdUil2aM0Im10LY9ycCYc3q5fmcZh+L8cES2GvQynkiBrRpyQSHROfH1Jv+9MaYaIW6Oo0C+j
NBoLQmLjyY+DcBiz/DxxBhOWV4agMHKia1g4xOClfGpl3uH9pn1krRNrNABnAfywF/24pvd5beIk
mJFSnleoa3afECniU6jARwQfkR9rILT/678oQg4U9V9TVSDKJPcYgOvyDxrpMqYcjFMzE7Iq+pOY
EE/s98ERSSZMPOrR1+2AmfhZtSc82Ki4pW2yENvtj1F79sPRK7hIZLSiWAVCSnro44EYlWTGQ/BE
xwg4oI3nKngJCltOKotv7UFPYSw3kJw9OZ4Z1riB3gi4kbvMCEQjURD7jGGBwWTmB74utcPmdlPW
Cf3GryMecbdOojp5MphRl8+38ehcD1UH5Hy4Le0+JIkZgX8h+x65Knrni87nz/pgI07aM2B9I5PM
kg3bParCC4no0yuPHO5bnAZjqHrDkYAv/2HXtFMUccmwQlAGwzWeWDLY/xTI1OeH5BLmrZxuTRla
ci6iJrL98sjmgWI68MrK6mTEY79m30bJZWq4U9EPHB9ccGKxNcX7kVLyB/iQxWNQ+x2r+J2Jq7kz
OM6vjWNDstgbLRwQvy9KFHAUNy5Yg0jM8hzD2lgoY7BMdDHHljaT/22FfNxV4uarXA1ssr2EWSCH
iXxZqS5ipc9lOv2DZx+nV4T+Z8+BLdEoEyG1X4Vto+Xcjw0GMMEa/TSoUYnxbaZIaCTFn/AZuQY+
kDmKwS/Zq5ybhyBti1J9Ci80zTIF3JAHiuNlfnBBvceNvdKckTT8Sl00IA0ZNxMjbjMJmotho42t
mi0qpHTW3pT1mk9ClkgZ0xwIRUriXvxnoB00JFqQmYFXSv7I/Pwr6vWV/ZcmCd0xlnf00HL47csH
JMOGjDLebwdcIIcT7fdpkKQI6ojS9rTHDYmSj9j0FJHAghthwMuP1faCvVe3vsLO43xHUL/b4pK7
nhweuauCIRh+hxNeqlwzxugIzvB+HaFy+U3C9b3zE+3FilU8o7kRDTh3XfG344QM+FH0HIn4HS6B
UZMY2zBsl4IXwjDEN+pH5c4vy8w6v+9R9KkI0VqJQv5gd+NxP2GRhcIfkF0u/hvhnZJiZUcxI8mH
DHDeHmqVReyz7WB0ktqMAW2CEcRSKoEtE5NLrlfq9jBcuWJiIw9UVWGd4qMje6Dokw6/95rSBIK6
J06cItCojIH3VrMJx3ueZazD0UgdeiWe/RaX/bug3CWMX1bzQsFfcLPNNKO35gRGLCThObIx/UOI
s0iEUmUU98Nw7sNK65hjlNTWGv8VakP6nXbw4V7RbGG+pYRw2kGIvJd9BUqAFnuLBtII4/vXOxmY
C6JeTdCzp6C3ZpJgQglMe+onddX4j8M2vIGxVFsT6XITibViRsLuvvI19p8hojNe6VCZdcPgkXyn
CaxHgVCMvQOAric3MVCZoGCYnlSmjUgGgr8ThlHK0JcKmtXjaicf31FumpOvi9ME2ZAnXyTao2EA
LqANL20lUkI39xBFEUE0eVEZzgBKhLJXK165bqCpoJH198eta4cIaDMchg9aOeyvAdcQ8+Zf3x/S
4lpg76FjRjLrexec1V8PqLjBiD7H1A+5s/TG6kiqMmd/nMe9AO3sIO+qrls4VjLbB+pZtj9ZLZve
KzOOpGAknsE5k667DZ0SJUIfpqICWmcLr33Hyy/zK+Aq1wMXR4QFIPSOB5OU7nN/Gg6RD5vd3mCI
HD9geLVMZQQSPaWlbYV9fs2Pvatj82jefnKlNmQM2sOqpjocInErIPmEz3qvnd1qJH0U5KIgzL/8
OB3+bQw6ohlAV/KkaOCia5GFUnQP4rJna3NGllADBfTDh36yP8IpQGarvLO/nGspNE82p2rgy7y4
eyG7OrntoiE+4HHLGfVLv0oNvYIqglL4hof0WSf7/vEd85JJmk0ek67U5sCurD6ZuKfL17u/nynU
u4dROF/0lVRt7LJNxpLXUcoof/oslw1Wt1x0cl6KYqXuT5NVjaNtdeobKeGnsCSSxWceajK84s1F
UNBrqR6iTubNz/WK6PQssKnuiYPu6PF4d9nrcFq4KUwp0fvuDxxfXA7t2t9l20biFant8ylpSiE4
TFGfLMIFEzO3wcl2XQq5DgpOLNMIvJMwj2o+K+phL7Owx57q7SktfEKvZFPcfMeRJwZDtMtKu2QX
uuglMH5tEHMOoC+AzAq/6E8fOkRu9OAFvMGdfGCvdbPwH3WjH4kI72lvWh6WJrANioqtlXbuYE2D
24kdrX9ujuFD7/2kB+mw1NR50MmjIROQJ/klAq804Q4edSB5K1xQlWHg5Ik/dABp2ZT2GNdkTY4m
x+5XT3NDuxpPAKPUBLHPDc8pc6jZPAnDZGDjfcS1r/zm+FMzynD9RTNGR8xBVuwiWk8WlhX/QwY6
ueKYN8fRpblzOYq+ULLAXSPv62cuP8/MRATpCrkoLiLyjlcTFMKfm+HuNrT7ePrFAlUMArlVxn7f
VnX1a6bjeH2baKPTRahtD/m6h7I8CbjX3t+2wuQMmqXCJmyaaF28OjArZs4fhAVB4O5ALOSnmOU0
XPRDp9IDWPuIPU09aHEe0qWvuZFmHR+31dr5wohBgWv/0H+eQl28rhzNnjZLNZ4YnKLEWUZM6r88
voEPIWKtDeI2FZ3fl+wecsIYW2K4/UmRWUDcMpfyuHvJReI75k3seZOZKdm1lt7mgQDiYyxO3w3f
dHsUfKi/AHlVO5YlOlYyAFhPr0uSla4MNRst7GohQc7iesQegSMQcyd80ZaFXITuNcfVitiVcMFS
Fguhulvkbxi7M5DVYtWqX/0p67w1/4naWgP1RTom5bgEnOe/Srjm3C6naxOTGftYg6ZL7/+Jn0DP
/uRBkthrzb4IuuCB7Kp5ewXcxYZb6gx3JsBTKY++NKMm68VPL0v9aMAWXC7XWakRlNdCVSUNhjxs
9pvxi2253LaAo+S2WmZNlhE9jannX5vBvT0WBfNpfCeUcGpawPJRKWMW2DBlqst/8259Dp5l3QAO
+kC288EQc/3fMquJMrdlooID3+aHLsAUZhzHOY5aGIZtGY4oPFKpLV1RUr+JILSHV9gF6Mz0XOjJ
h9pKN5uQv6mxgvxZkTjX4QMfsN6uG0aHYPHM6cfGX8wYLe+XT4zDTsPC6rl/B6ikDsYSyGmPKXr1
wAOoTLdJD9xl0GCwYtjWz80Xyy5DsEOqPQiguFQgyEs9K5gYBN12bgJL21t9CL2u/1+3qSrfJetS
ewL6s8k+0+quRtOx88oKmahXZGHS6P1VSFyFbxuVA1Hp50fAIsrBXhQes/x1KKUw2Z55pnGb9lM+
/1x/2l90NxQw7wzYI0i/gVFV2K7CdfS2RbjvFuPVAjVGrhfDfaBjXUn3J3JOPcgQhAscOzkXoSTK
c1pj8MCgLnNXkyj/CJj03BaE79SMy9RNnkMwFuau5bNF5LXFUiiGwr3UBJOjiN30ocj33KzG1jCA
1qk59UXshSYkMbeK+k5mEBrA1r8u9Qn/9hIGtxkkwPAlmVbSWHu63R9U1vFfWSVLQuZWT2kZgYkF
XEgObiKrPuUk8FvIZYvvh4mcc9RnCRKvakpzqnVjWqQobUKbJRvfArjkSL/z3eY0jFdeg9DNXeRX
85Woqt9V72q5IOFtYE51xUKaNZvNgfsdZ5QfqUOKckD209PAjmcIE9e9xwMePE6/XSh0Wv9T/sgC
y/QPfK5NLRHQVq1VtB9pUfZeM6Y/InHs5zOIBd3NZH26kw2AdjAXR5VTQyT2HZVrbM0txFMDK733
0DydngSTsZ6fXOtmrE3HKQfcfhpswkGB7jCtEjnfAc++mqnBNoEK44Lby1CmTM9NO8K3wX72oJXk
gwcx7IjVKMalZNJm4LNVUWsea9ZOwvESMoj3nKC1zYKJFoX3rMHNxPFnkOqrSvTSejepWoNQhEqx
/SxCrVl7ZzU8Dgj/SE4XtC1LH5MYHHeAL6MMqDn+oha7Eq6c4OzlcBmCLiE5vSX9UtKkgLqAmnEy
gdmIPuUcrxy3izgOhswMyLQdmTVH3v3cnIR+byrT0DHu+ITp6Q3xCtdXcTm9dUZZab0VYgNOTfnf
Vlfb6GWI2RhwXK5yaRZQhb0NamDG/X0UGhczdIMOc1YUl3eHzXZw9Q0IgRsIDi+TtNlzEa+1j3Km
9BiDsClHkiU4gZ7qI6HltSpA4/2w9b6wQvHDw742lhKwcCKRUDAag0eMV0nZ5AZHtKtAUv551juF
47S7fZNcfwZTv+qR9/TU6NuM6y6N51jM4E3qi+fK/dKgKLcVdgHfleIOseTgbNdx9vDJ2dGzxL+g
iYeJ0lseBCbfOjjnmmvPovJ8giQH7SuUbZ0CiQxDTPLSqZEA+XC5wMYwXbKZfu16mDH53OY6TGBs
eAlI2PLgysbCI/ac3CoRRKRIdSzyAnm3UPTHP26jm4/lv/HQ9c7Sf7Vw2LuYwmkZebZzNGZRT5mV
gSqmZq9gU0PLyV/acdesYCVj07d+MM/Zb1mk5UFibDEt/Ap2XKblM6f2ZErFqb+CLuVCwQaclHsN
LdB5cqbZAWI/4/w+RR7Bp0Go/EK/Mxvtn3TUentaJzXwZzDQXm+wvddqPaT7qBautvJMwhDsCnJg
Qtn1r+c7gt5m0RKBjJiogOmlS9MqvbAtSVdbfCnWqv/txE8JYvw846EkfKCO4b0NB16WmrLDLc9T
efU/pYfTgNo5eKwpYKE0wg0TWbbg22wQwKIPSG9yMDsL7+QZCt3VsJNPYCFyZEhHKvoUxUiP6duj
bW6EswgIMVgE3uJsNSa9qgrkyY2Ftu1V9t6zVQdMDfp+iolOAMbwcZ6mD6IuVWd9lfr0fXMBBnW5
IZdFOZzjO6HaYyqsK9v13QM7lNuuUNxuklieDRDrzCzjOK9POOrrmak5ukJMNerLEuRDGRrNuRdw
KS2tH9bPjLlenvLkzHZgGn148daRJLifFqlY38yo1tJ3/8itJxM0cqpiJzyP8ohE/S3kHBcswBRo
tYLE0nQZbtC3s+HaY9+me6FQPuVL1x5qxDXxM25fB9avNKKvtWoal/7fKmAR93VzeVxxHK6Fddzj
+8DD5g00/tLu/fye6ui2vcbF48b22cx8sYxxTtiVw4qMwi4nzGJYHB6rNrSPXf30wz5k0UzvDwA0
IPbSZwA40loFcP66HnShuFzFiUzAXcJVOmBdU+Rgh+SjugbQWxK9ItFFMDmhfsO2uRUmncpICqLI
Vtvf1CInC0zXC8gkmWaTW7vubCafSR3VQQVWlG8x5PUbvgq/48b3dtaxdUzcIcJF2MfmeddX82AF
Jo/ZcJ29PQGkhrXr3Jh/3BG89fE1oK1pPv4J2N3FjPmb29ZwLCQRJNnpfFcK6kF9ydVVyzjzFRKH
qZ/RMfiXuoXf+8EEgjkjUgLiseVkcalZ1uwNN6u6f5j8zqF/UfznHX5xzncm4qxxkRU48ITbk7/B
uneJDFeptrurkWPPvO+nP/967ZJ9GvfVI4NyuXvIUb7ivYyD4s/WhPLzdMm9f1DfJyW3Ktd8MoX3
eNKF9BcS9v0hl6Jf1USxe1eS9d57jVE7C9RI+fm2olzvhqAAKcFFY/Sfq30TNQpSOPvsL0ZKwquQ
mPOerXTLGm/T1kEPPWO8yjVtVoDzYN8eTp3ZGQOQ33gXl13BQUrcJFsZguU+OS/iVCzGUsm1K8sw
W6YT1CV1TlZeup58sakhaq02b/3cYJxI/iJwK84XHeI2FJ7YHfUxKRbPncKnIr9Vs9JEbtP3lqDw
XiMkisDbF/z3GdHtXe3TL71piCaffoi4CWM4AJWeyFnorrCULmYpK+GCJP/3BRDfpOBUgkJSRY2h
EqJpkHS+3Fz9kPZHhzisTt3l5N5oZFnfcwTdJ6+bJ+lTVNlGlxVGGNhlhP41BqaZgzdMHtjZAq9V
8h72PLgO8c0ec3tVuCCzq5jWB2krXyixuxwbg4B5bNKWleU5J6/UIpbowHLtm06bI8cCRxY52L+R
N1yu4ETMCPUybRi4godm7BdJDZ2pX2ZbRQcv47lbSuV2MBs2gcgvTXBNsnHdYFJYs4O3kbEdRvcR
VmrLKzgWbIYjeuRnI+nkO+7pc7H6c6uJI1HPk2IRovEReoudxCYYdeATDDAkPPpW6tpopSjKjygT
oMFot0wWX9ILxCm7uX+KIG7l6rEiR1gpJbZqvOcKqnXFrsgT4uqZPV/5dTuRzRebHE7clr9mPYK3
KQI2UMp5Aa4h4M/d6W481Yxt6G5aZnFTsc7K47wpr9yEouQAN77TZemK9a9LMs0MZ//j0H4Pp36+
r+gqcrxsX/FrX1faRmnyQfp7ISbU4jsNpl59rqtLNS9WPHC7ds9FarpUJIft8O5yZ2NLH51KGkTm
20BHL9NpItHfd+hAPeYOTGEKQ8tLc5L01raShAW7x11XqWHGfuCrQRxvKjpPXqTL4eeHtm1XKUTv
ZKBYTBteldjBoZfXy1//VXXlS0tWXZ+yRC2BN9ySjSfrce74jA6rJggeE3jVik1xycSBnIQyk5uc
+pN3JIIT1urT1osnXEuEkq0MadFG6wXd46oh6x2OJZaYcy6vPHyJUZZw/4sakWmVOJvqdveXIcno
GtsDmps5lJFdVYvMzLzYJlJKTaOpWhzQd07SS42Edlzok99OaE6mIZXQ09bhV0W2tMhN36BVn4I0
vq8o6u4uH+kaJSLEGhKBkuM7p0g4STwJMU9GrEDEvXmZQl1yyw50YgBVMdf4+LN0ehcAu40hARaO
kT3yYvXBz213o1gHolBlhPlQtQcmw0Vf9dK4U/b3Nlq8kK6C2vNWI80u1mGvEz/h2520VbhH8jtn
0ZFtQfNj418u+Ta7gDMTqmgQ1vAOvhCwG1IpIQRsW+6Dq7vPHkNgZHNni/5AQCIB64lvZfVkptAI
L7rsVxenjAX5HiZfl8JyIuWbSQwGh+lGPCIaSsnHyH8T+vkKZS34OL1YqaaHzqtD20+LKd4gVv3T
bz7DwMT4CePHZbiKZZbqTWH4jeROi+9ISyDvJND1ZitfChOwOYQwNpeZKtGrQArktC/G7ji15i4z
AnKfsgQumKkv2USCC/O15I6y5xVwx0Tl2TXdxfn/P1XpJEt8N97kiuX912Vn2qdplMtNVZMJ23KY
pNdUOdKAePZmCqjaDTt/lGncmmYe8rWC/rik/+QTAdic+tPoQ1DJRca1mZtCE0B1BDRz37kH5jbn
Rt8VV7D3OFFrS72bgxrBTL6K4BlsO4X4Wq0QzjHEcJgKDv4X9pthQpJYUuxmygNbUzd2gCcfhAYZ
UpPW5i0+zZ7ud/Z75Eukr0BNjzoUTNPhqTvMBSdPvQnHVpQiqGlrS3UBDdhMr6B0URhqMBxOtRYj
Yw597FJiH0+HloRBkhR/6MF0pVs1sH9DTX9vJYCh5StiTILvCzwWcYK1LqkNnJxYJABTCIowqdWN
BcLXxALLHIGY9kr/GecUeV8i2lNOYUGPQOJuaToX6oBOCqtbziw9egIAZy0aBHT3PH+WQtj+HytD
aA/V28DX6+QHw29wpWoFc3fifn3BecFoY5Q4kCqaB4WLMyYv4AExlxyNf9uVW/+15NWDuj4B7d7L
ZAVXOyiei9ErbtoxOVZqvuk27oM3wkBbky3PKpFnajGTtoob9tzfUfZ3gMCG5nH324ZnkSNNjCP0
gbV9PvG0q/U9cxrfWAZ0yL+cVds/rd5gJ04WEA8hcN0wT3XHFexS0+aYcrgzQNpYFwjOYHKQ06u8
+IDBMJqdfyyBUDwTd4ZiMBG6aCT8iK0F1+vvqRgeSHugiv7+hL8P6SLh967B1WZskYQCyX65l+RY
gf7tFwskx4okneKcPnc+XlsvLxIz0jwwYilDN1XNBrhohk+B0kHMaac2qcIPAdlZE+98pWMSsNM6
L0EVJkG0l8BpZCdthXJWTRBDAE/eWO9QYMyQCRQyZcocbdDJ+iUmY6tLaoy5v/73h4s2zMtMtMyI
BOQXVPphmcpETA3965UxusMSk8hvyVTRqRvc84XEvT+OuN0CrjS7hLZ02hxAHiXtQV5ldiGPhU8S
bbSE9vzsnQGoExW6o8GeljAJx4ksveEeVG==