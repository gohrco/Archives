<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.2
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2015 October 22
 * version 2.2.2
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPnGSaGXivsalVQi4AvL1kjOcaEk8rNbzc8oiCcnF2W497dY9IzNZSp1GoFv9a1kN8laCif5f
QdUmqlGlseQ36v6fGEb28VDdE1LyLEZj7qwNVjcsTqf7gxYHIr4915ZZ7P8GS2YFSmlo5COpLe9Z
z8Ihih09319avTWvq5hh6DOGQBXP+nA/bmHaSRnwQ9xFYuZ3VZxxv/tmNxDU7ucg57TY+4hn8HSc
U9mtXuGxLz3omSVaoa0aCqagmGgayneKATZEGXfNQ8DTRCvNGPUT3JIhljS8RpyA14MbvBAAmmre
hxVCzNuaO1dRKvoTNyEM9OVqiTQGaIc+5WeM/E0VTeeZ28SOldZA08gQgH5EDSYPcCwdtp22yfTZ
AZ2ioaNviK5SRmC9wpFEZ4DzNJg66rKrAwM4Lc9rbbe+6Y5Rkr3YgMNt13QMzg6DlcqvoIzyLY6z
HYejeo1fG5s1wpZHR3GDuoR64eXKu+DEFwbVE+jUDJ2zcrXivVnghRxSULaPBT9nA8HbZUSRLx7a
z4479gGlSHa1eJTH6Y+n1CMP3ihQyhZ7oqM+qvnmcYIusOZS3k2LmMY9RTJSYPm0ZYNWYWUB6Hpf
NjCk9tsDggNZkcsmWVVsGTLUD47jkeh+79cEpbU5R+BzCaXtACkCu9SLo0T4T4L73FKNL1kXjqPz
Bh0HmBRuOciuR5hI2TsezP/a3l2P/pcpscwsmRglaaFlo7Ldswuj+1ZLM0qTMWjXRCouUL03ftNz
G1aGM+kZRFu9cw28JcLV9MDhgTa/52QmtwSXA9ba8TVNnq4LFqwcXgsbBGAwt3AL0RYsmjof