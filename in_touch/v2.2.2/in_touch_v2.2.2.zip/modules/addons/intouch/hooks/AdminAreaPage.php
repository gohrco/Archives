<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.2
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2015 October 22
 * version 2.2.2
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPqpdnh5XJJk6Q55JalXXsPd08nzV9gE2dfQi4Wwbd7sqs99I7MABmOEvK3S+ueUMrIi64tCk
xpgy0/tARSYzzDW2L9dTg/I2OxwCcRTY5XYKszqNjUPoLPvoRa6cZez3yhZKAlGwBIL6YwIeMEOR
4Hh7Q0pbRhjFC7mBUN/bXXxxwnIq4AHK03UulqU1Fp4zCOxP5yOsgwyAYaGLZA7R/hysG5tNwSp6
i7yBFr3w0XdlkvwMpz0pCqagmGgayneKATZEGXfNQ5zW+J8EM9y9wHJjZjUOSpyPV5wlPYZVfhiB
5NzJtb0pa7oAFShHt/n419xfqEvt66NHyqQVIxwwvu+zQ0K/JHmSixzhFJgp+1HlrgGThxZo6Olt
7JlyqyXNKKk25MNRKQ1/NaGzft1Ycb8tcQX0PtIBLRpecPEvOqFoH9vMSIWmnAR73GrOgAq+jMe/
9xMPKZaOIUCt7Ln0mtHfUngqFQhnHoPszqqeMFDNcJaKDYNh7lG0Y+yp4onqSCfdJVxPBoRBZKbJ
Lu9S+N0aZJYfkUYj7jmNTvwSQI4mXFfrmwZmlUgB+R05PxV8