<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.2.2
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2015 October 22
 * version 2.2.2
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPrnw+fQlnTxPeibljIMjnjD/RJP0pg7OdjiW2k9w1UH1MghDcR8eZoUDqYg+G1+tfvgCtZcX
/SmgTC63Yvpr6cG4bkf6iv+qIvd+ZKarTegA7q+Z7arXch9y2/q1v4qnexxDshcddTK0tQ372KWh
reOlfRqlVCkuk52h4XaaYF3krVR8HBvFgvNwOGmxSTz7WvrGExG4CVy3E3b8eAxo2egqHqn2UmVY
EICSfojs9cT9kDZlkNL293D9Ai4AfFCQ52dOpa8QLsWvOu0fdGdn5hnOaUBNbtC/1A01QijTQlkX
v/B0THcXwTuWCMvXS/anLTCXhLdfHP2I90vr9nYhua/yjMKBJ9io76toWp0acuThZyUTlODMpda/
GAq/Gq34ApZAew4l9AgNEz8gU0ScMeNfpmGfI67edYrm5qxjFSLDaiG42cvA0H9vxfnFKSApteID
odJZoFqXP8sHvoeILbLLSlDyUQe2JaNnQvjK7E3ErHYzysXyN9DBX0u1NdC4oEtjb4vMx6Ktj5tt
3dxqOrVljnHZ8rD5YafIiitMggCQkrkHhqwII1iGlPLzg9REKOGgcMsMUu5xCK7zImiFlHJATiVv
AiX0G5F3S1crVGw5FMNBfyu5Uhx50I97TGtXGg6fL19y97iX+mDd4Myo8I3LCoXsX2uSIZ/zgYxU
/CXK3bUQo9ZtynktglQYc5HXYez71AcsM+wyjfVDEXtOHetHpbtkgzB6EUyupcLQatPWrIm9q5jo
xV1mtk0CuPmroNPwZ9vErsBjOjsRtaFyyO3Th8U1Goorg3jblEOQAdLtePrRcl9q3s9U6EJiGQxL
8fU6bU8aDOiK+6NbfGy3YrcfKeEl45px+Jw47KVO4PmvifskNsLjL0yWaqFgg8Ucz49wZ4e2hhhV
hOy/iNUQGd+zJ2VRTc5GI/zPz1IvHgqkc4/y6IIXgBBNnBMAc6cRqsAr6Diw+egniUdYAbJxJY5l
JXB5k+W9UyiK3TUtQlE1x2/1MVaBbufLVWS8sFE6EWCQO75pYo1+haQ/nt81OZe1zTqpkuQexlNa
iwXAKjsRZN8hnOyA778Zb8sDIXzwfF93qOOZ/9diHUyI2c/uH6rXtVSd+Y5IpcW/xNiZVB+xlL8w
CA12FSItQE7jZgZqfLXBV+EH956u/pW1HaVAMCZ5XKrtE3vq17FRNLldvsz4szwYPepm3z0JMau2
h+Yg3vkP0qUwkRf+pVrgm3f3CAqXAwUXrlS9gToI1LuvfNyh0BIfNercnpQMXeicmHVaIj2fh+uR
2rLnisbbuRNdvsXrAYdRO9a+PY1FXP38tadE9Fc7dPwNVV/7pyjCLCY6HqhnaNVl9WA5h4V1esrJ
IV1fAX1S2q07f54ZFfPescyIbpyWyrr7yBiFVQ876xElisEgi/nYOL8fHffTUwPsabW4CDtYZoKz
75OsBMB5PiV2zaMvxZaAcLymh0ptiGNFWjLBRrjoK4/OhlL9WjmsdgYraH/bmeY4QqMyT0uz8CJS
JKNBxU1gMPEVTfLyUWd8lDKbJUciT1z+dYC/mHgWJyacTl25JvKnbPyw3IM2VjMPVrIIFb6TH1CZ
mwuX62SLWR12U5e9JD8I1V0UqVaP98kmMiINCkCYpim92pLwM+k7uhOP/91w+vtb2OUIp7MRkflG
ga2FoKvRUXUhLU9dLGQZSiLULIGvnQvBcBhuIaFGv5j8e6ir4ADDi7/4Byp/dSRNtMDh3p9tV22o
mqN8gXnuiG75MQdvH04Ev91gpQg38AolVDd0gjGXOMakaJGdgjv0m6tg0K4M9slL7huWCVHIHCOa
DTe1VuceythOQ+6KkINXcyOZQSAlUAE2yM94ZQ/lxFawtoTaPMNJEugfnt4E3ui2IbMPHtSNhFNh
gieMjsoI84LScotEvcOCBEglt3x0vE9v2pR+u5ek5coa5NCfUrjNKvGC3S2d6M9KTMhdxPo9WYDp
v1jwf5cG7lDbGRiVScca