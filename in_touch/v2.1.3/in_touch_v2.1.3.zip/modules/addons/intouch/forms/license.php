<?php //00923
/**
 * ---------------------------------------------------------------------
 * In Touch v2.1.3
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 November 26
 * version 2.1.3
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPowjA/6RS936TXs+qZln3VI4563xYS/yVivJXG12r4Hl05CAVhQRK5cAsMXSjtfD2wi9/jo3
kiA3vKhjXaVuCHcv73xSprZYkgJ1KLqcvKnTjQcPxks/8kwAWiHYuJkfkD+DW5av/CkY9JRgpgRf
2lgSNvQE4jbSP8kGJTqzpyl1w5SleymsC08X3VJu2ufvJLa27Faj08mi0saSAhz2SUipsp5tITeg
IPDG7r0Y+zY0+2ErWG+rPe+67Xe4Pksn30SU1/dvmdlv2sILl8NO911LLj+1pUGzRWN/wIP91xs0
NzU/yk6T2JSUp/I7Cl3mCkF5yvv8XjF+z4aePRQHN+tN15f2Eskm0ct7aCBN89JPG+ukddWAvwh0
54UwFImg2MSvfRfHT+ddQlJa1Xsdxmmb+zyCHWUutMQvmyPEyVQ76uhgYj2MUNqUwW8xm10ejei6
kiXh+7aRgqVBjGsManhW2LiWW+ghJj28zki9kORgh3iBXpNHc6PPEAyn+o1gcEbHicBq1Uw70HZj
Y/MskoF6tRiGoD8s3nmcXYhhOeR9T1uXD+VOYd/3KU7pGm4hsjL/iHQj18uzaN7zqhmGbx3ergFq
CyBSWIlxy0JFT5IE+PfvRFA6W2pWS3k3BbhBfTIWJwqbiOd2/qvy3vK8bVTU0yASYFDsVADFzDkp
Nx4trOrGeruVzDMkUS3kaUBWDJWIvgismNW1gPZOCsF/ImXUhzFDuT8pdXMzigxzlD1URVezIUs2
Jh/DwYlCrqD8LGcaKknFNMtIsCageKnZPFYptJrX6hjjNgFVu1rIEeBMqhadprhtNEGl6mYgsqqE
K0XcqU8NI4YYt8gHLqx/5TUJ3G9UFq1lBPPLuXEEOdNAdT9CX2I8mkt+v+9Ts4rbvkBil2zApECQ
MovUE+GNSEyD7oCULR5PSBvQMJMQuacrqnE5uwn6vhGMIbHoxbZUnk3K3jo4hCxH0/+KvNxZ/98O
n0jHrYvZKE9pCvkQHrREv2ekBXBeryopiJGFJk88JLtJC0XCNIQ9WZM2k/SH1v252tqNW2ylS837
76B3hwr0aH2Qx8VvT7IhVwTMZ3IXQ+q16Xvrlquu/Ym=