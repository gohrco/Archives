<?php //00923
/**
 * ---------------------------------------------------------------------
 * In Touch v2.1.3
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 November 26
 * version 2.1.3
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPz3tljqJNGCI/a4h/X6KijJ85iuniI30ShMihfQpizaCUmoxBzVu2mtH7RsUnrTwfs76eYIr
lO+8YALY1TuL2he1RQmvIJQ4udXvKVU8kXPA/LVgkxKgVCNGYroxvL91XvMJ7+8gSWxrClxN8fFW
rERH9jbfxstqfH0bn6WezxTKFn6iig8acfVFy2b9CeM2GQk/S7y4k0Ls4mE1dMrh5bOw45oGRCYK
IdkhAKQtSjsP5YMjI0eDXXuQ16RjiGm77WVv+S9x+R5Wv4ICpWq333BEwSrya6u4LjahXpsXn32l
IUYU7HmKnMZg+XwOyFroATngms3bmJM8kGANaeiOHG/zAhzcIbanKE1ty2DrFRB0smQcZTQeR9CP
6/sMFUcHJGKYfWjjEuqGSJs8LLHjX2euRSRL8ghmtk9Y73M/jt367si8Wmv4jfkWBuzo2lRA5kjJ
r46Gvjxl1BB/UaJtJiznih+R4zKawxXL/q0vo9f8bzm8VKPTY6StAaI/FiBE6D/tWD6jCYbxl9H9
QN9/v54nQPTNyJ9lGMmzkHMypGsqEc8BcG==