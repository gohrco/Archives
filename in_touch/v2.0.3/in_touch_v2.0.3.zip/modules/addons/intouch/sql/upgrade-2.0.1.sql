

UPDATE `tbladdonmodules` SET `value` = '2.0.2' WHERE `module` = 'intouch' AND `setting` = 'version'

