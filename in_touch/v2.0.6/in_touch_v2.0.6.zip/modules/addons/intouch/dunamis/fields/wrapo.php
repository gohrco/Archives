<?php //00920
/**
 * ---------------------------------------------------------------------
 * In Touch v2.0.6
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 March 14
 * version 2.0.6
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPtT4mH4Igpac/pltL38cRvqih7tK0jrjN+fh7i265HIe1RVJTRvqMhGlQQqqQglY5v3nrsi9
yXcIelZkxF4qeGEuoik2uRFEcsyvxP5EirliG/4GpAPESDAslL63GrsiFTbSA7c/YK0wmfVJ1RLJ
0JtZyvTCOOZHgLIu+5skAd0HBbrow53N9Nd/TUPdWsBQgYrzpSbAgCnBieCNm1nZR6JFojntWb3d
Pv5tFOI36eZSix7RA05svOElo7zf8ysLDag8T96x2e/hQsVl4Yne8rDl2jQp1Pswn6t/zvflr18X
51z5IpjXbGpOshS/GYck27K4S6pIbloJ4vjUfuxtjv0Ue+8KXbRmML6qMGRX0XvWc6QxB3d9d9EM
HBdxbgVl1ZJDBGMToBEkhfHv0WJcS+8EIPcNpLKYgS5IOBBoHe0nb00Aq8QJeVri9TPIOqGKq6rs
AJX8h7JFi91nKe7JMqmG2iHUiwQt7ls6t8sMItWPzLfO2qrwTeq9ygqev93r9nTdIB5DV0bEqQ3t
QeISGHxmWB7mJHbLq71xuA0HXpL5JjeGSx4hlC1BtHaqOBUSwHqRModPE+95IVVTkI441P3PooC9
u4+lHm9kCxXpIa4zMB8EyGzyDp8mAVzCecma5ndvz3cBit2ruk06xcmfbE+dHp2miFag6Livjbu5
kRFUzerjh/rNmWam3IffmLASWZ+V0GtX4bZGN9c5glMneI8Xoao1L/87hIykEPrSXtsI3VUyakSb
9VRrTrF3HiDL+7LwuDM3ieNn7MirMFHiM3t+cPZMmzg5woAD177JjqJMT05O9ILaCy1w4sfUpi3+
tZromvsvQorRiTSeLYu5eSsTgCAQu9dEBLnC9/TrGOhmlpRucqr0Nq3iSTzqQEbDt/mC46V8q/LL
obd98OmMi23hC9rr6l5duVbcnq9fXwRNaiJ5wVZxJhlAiLpm7fI9glI3rcd/lQGRqIj0w0mZNSu6
NmDbillZ/of9p3N12Y/xgOSUPlwhffcydPq3GmWUptu1esyJtn60hfL+49e1HNIj3pD0Q6y7Su5S
tmASzYOjsDMWL6lSPjbyBiau/ZsUEp5eJ+RVyHwLe+M5TaTLA4m9IdEWI2C2tgTMbywd79lxxzbu
SL+Hp7X57MPTKSi0tC934uQl1TMZQ6rKH2CAJ5GKQUgJew3DI1s67jlGFsoWXYKlN5cpYwtcX/fq
riidSI3arqwQ2pqpf4UF2fYcxagHZ3l2rrDiXqSUrGLhcn+rgRm8YgLWBCqZsHhT06qq3N14kBs0
eXqMpd6si1DsUcop2xf3Yxaubx5TwBsKcL5JNtCmfaMHOgQ3ge0tWC/KSfwjX3UDzIk0JA/lobgt
mAs7W82yeOZqv0691lYSbtuTSW4HlxVQJSfjfwdtzKwn7685ahbGO7euQAJd4LSdVtlPD4QHSKIM
5d27jWh8/0aiwCVfIpb5Ue710/Zm1l4KpYtyOut8hZVTAqRrIkUTaI7WknqvIkttbuxyoc37yUnG
CNwnw0IxCusJu9yPn6GzpzV5j4evBtP2fIKbbEObILtEt4OJCDthoLrfAiUH96HF/Jqs8Q05TNWo
Cl48qW3+5LVHgjPnluMQenhFLGKuV5KvrQ/4Aarzlb8vPI6sXDby50Bedob+uCrCdoDsLFplHDzm
eNby7i1ae5ATLG5MfiITehydF/GxWPxv0OYzWeOsZnr6WAygKWUWyiZNnhoOXzGO0lCgEtpWWXA1
qW4vL8StC0OgjtReuHNNAmWJYY3alIFkgUv182+xBnbwIkC/jHefz/p4GI3TzKd7KpqIdKB/ywrr
sGvBgsWJIqc/cMaiU4gEXkxffqRYQDAzI2A08YrBxF3MC3rfamSWCSe4k8APWvep5V92W+jyTLfy
27ExIXlarleCzI85/f6Pc+adZtt3i0t1yvsU+pO+cof6DEW9TJ+fULZFtc8W/8dRLRY6oPman8AT
/HUchtJCU8dRPsV6c79MxkCrzlZZkfu/45Rvucvx9kBSE4W70Uo7qGGONrlQ4JHoAlIXVJMmB6//
nHqDsKqm+MLlljoD8kK=