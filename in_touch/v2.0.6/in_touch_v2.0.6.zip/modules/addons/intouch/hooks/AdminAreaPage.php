<?php //00920
/**
 * ---------------------------------------------------------------------
 * In Touch v2.0.6
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 March 14
 * version 2.0.6
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPxyXtVz+pmicy8ANIDno/aQb4CaqB69MrPwicnmZqTPawmBywozu+kjFBfO2WMqwhFPTqQHC
UXYtcLxXKa/WXi9Zu8c1YTuTKQMrZpbj+F/+zTTm34Dm1RiAAPfEgZVGLZFgS5LMVXhKdmSPZJYo
jZxwe+oLHMh5sgH5zu9BC3H0bZr8fcKhDatvrgUu3ntapY0ujcatNvKoohNTljwCqdyLfWe+1zhX
pBFWY6wUCX2YTgz4oKadhyX/QIFDbJPAY7IHkmgFwnHbkEw0vD1xA2vatWLjqCGQlSi0LDQZeI5d
7xQO3Fl89KzSPKTPE0nLQOatRXHGuF4c/+/C1T8RfawI82dP192mosl9hJ+R4Q0wBFfGlzdhwJks
3C6FBg7vGyW90lmRKrjlDh3ASyK+woNHOR1Jpfrwj/O+YDF++iiJCggWCBomMBbGNh6i8ZcDGtQP
z06fon73XdWXhVU8N2vM+2AClAqxLmH8T3cVIFXsuxvANxM/4HsXvz/YvSaswLO8tyPtl4TdpyBh
fmIxauJaJV0IEgxxO70H