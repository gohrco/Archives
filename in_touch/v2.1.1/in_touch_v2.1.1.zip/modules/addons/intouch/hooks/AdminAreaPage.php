<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.1.1
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 November 7
 * version 2.1.1
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPzvQdiiPfcBiyEmBwC3qDCduBUjZ2zbf7lK9RMC5YWKA+k6moq4H2ZSjS5BMj9X1PIYCa18x
iuVbv0nnCWWKwahMiojp7kHrH8/ym1X9xaJUNXllUFoQGuQPZstv80mkMDPOtHrTaB9WA5+b3tLf
vPxYthqT5SPzQL81HYFkpNPEEug9mwX6jfJtZQJIPYfpChi5Ei5zbDr2rzTpmpko0BR3085sdXGu
5g6R3LXW5o9WcTySOF3MSif06qSDVmNm49/tZIM96hmmS5+gbb2/o5odLLryGgPaxWPCdeeYRfZj
mIQyE4n0qZT8QS6iGyI9g06pjCnkuKEDa1/bL1tJTvCjJ2lF6LhvSPisXFWjOdocHauigiPDhanX
KJSWi/6EqVmbuuhCj8OEM7P6rgaFzwyNkD6KCXdpZr9t5C0mRt65IMjDxp6rokhHonDYNKLg3NA9
s2Qo2vL6YhLGOfyVCtgORPJ6VLmFlzBt+NDJnj/YAe9xIA6Owg0ktTmU6mYwIzW+NNEbi1xsJG+O
0+xbkB8zH3IqGKizGn3kMJ6tu5bUfbjX630=