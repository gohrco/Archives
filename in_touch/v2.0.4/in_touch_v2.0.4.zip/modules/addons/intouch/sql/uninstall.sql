

DROP TABLE IF EXISTS `mod_intouch_settings`;

-- command split --


DROP TABLE IF EXISTS `mod_intouch_groups`;


