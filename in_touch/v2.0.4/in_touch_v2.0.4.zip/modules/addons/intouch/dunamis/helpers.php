<?php //00923
/**
 * ---------------------------------------------------------------------
 * In Touch v2.0.4
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 February 27
 * version 2.0.4
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPuSlTCKkyqph8v/XveRrAkQ16ezbhkWWBxMiKwCnJifpp+KR2OjAiZ+F5Bt6VXN1952BeetY
wOOuXJug8mRzXbc92XfzJPKac+AzxbspsDowlp/C3IhMH/ZYxg54HHk1jlzHf5MJZRht3qXzPOHP
Bnd5j1dzYrdgEUYHncp7lv+ku7Um6jLMOaZ82rBnt2wZYMGXbVBqEAgyk3Tph6rjpC17BO1i0ZHO
exsJUYRpAmkyUZspQxvaVWAGub1QveblhKcWtByJuibbcOMLnsoi04FfSCh+IhHesPcA5epqL9O7
Ix/thiXLEl87yHMP5ngh4fSj/C9K5MZp9BOGOhscOh3T/VK2is0EJUYukelIC56yyK3ho4deV8j0
zRX1zpgnextsbr3fbheYgoi2o1Oa9bfnLlVEcfXNtYSjJQXnnLJl7IoUujuRNJqHcSqBsFFU1/c1
SlLYug6h52J/w5xrEDRIroMwzGfvPM3SrQyBQ+8QC6ZHJF1TgHyA0CJLohVtNPM1kpN/H2In2yWa
0/vQuIjRO0dPplwpeQlYF/g3BSZ1OQueXwseU8ThQo9fAfYJk8s8mdKb2wDlzDdzdkD5uRENEwzF
+fikZ0gW86k3xQatygwGhAooaC5aT3iXzXI+Psoh/F1MVgapCxH+LrlyVKg1Cr8+H3rjWZu7lKPK
cobkl8t3mfEN/Aw7qYF4KmtsvTq27NbZ0l56hr5fz++KE5mtTjkl081E3EbtTaVZykTRQPrFlpFu
d4OpiYH7Ynrl04IitLH0cPBvOOKvZ5nmmJq83NCd+jgAZkxGEL2ddMcIJTrVyAq2I1CsJ6Ji21m0
kW5nUM4tDTQylFmeKinEKVqXxurQrLGS6Rbzi6Skgjl/dvrWQZSDaKC8uQPdNVwr51qnwsMCZQ2S
BlQU4Lf09t1g1gExKBfUYp/EK0oyZc8c8CI0Spg5pQmDcrNaG5Wndu93AU3MxPqDdJDWn2apbkQk
I4OWoWo0C+tG7f6eYpCASCrtehu548YoZXBpVeQ+KgKVwVOulHBqTLHPpp4gfDfycpjqP5JU3ywL
8f6vmRjcBr/PIf3RL67Aec8gydy=