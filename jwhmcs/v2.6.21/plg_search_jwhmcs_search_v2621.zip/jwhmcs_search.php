<?php
/**
 * J!WHMCS Integrator - Search Plugin
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009-2015 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id$
 * @since      2.5.15
 * 
 * @desc		This plugin searches the WHMCS Knowledgebase 
 * 
 */


/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

jimport( 'dunamis.dunamis' );
jimport( 'joomla.plugin.plugin' );


/**
 * System - J!WHMCS Integrator plugin
 * @version		2.6.21
 *
 * @since		2.5.15
 * @author		Steven
 */
class plgSearchJwhmcs_search extends JPlugin
{
	
	/**
	 * Property indicating if the plugin should be enabled or not
	 * @access		private
	 * @var			boolean
	 * @since		2.5.15
	 */
	private $_enabled	=	false;
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		2.6.21
	 * @param		object		- $subject: The object to observe
	 * @param 		array		- $config: An array that holds the plugin configuration
	 * 
	 * @since		1.5.0
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct( $subject, $config );
		
		$this->loadLanguage();
		
		$app		=	JFactory :: getApplication();
		$user		=	JFactory :: getUser();
		
		// Run through tests
		// -----------------
		// Ensure we have Dunamis installed
		if (! function_exists( 'get_dunamis' ) ) {
			// Not admin don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
			
			// Show error message
			$this->_displayError( 'JWHMCS_SEARCH_CONFIG_NODUNAMIS', 'library' );
			return;
		}
		
		get_dunamis( 'com_jwhmcs' );
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		
		if (! is_a( $config, 'Com_jwhmcsDunConfig' ) ) {
			// Not admin or not logged in don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
				
			// Show error message
			$this->_displayError( 'JWHMCS_SEARCH_CONFIG_NOJWHMCSCONFIG', 'jwhmcsconfig' );
			return;
		}
		
		// Ensure we are active...
		if (! $config->get( 'enable' ) ) {
			// Not admin or not logged in don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
			
			// Show error message
			$this->_displayError( 'JWHMCS_SEARCH_CONFIG_NOTENABLED', 'enable' );
			return;
		}
		
		// All good, lets go
		$this->_enabled	=	true;
	}
	
	
	/**
	 * Determine areas searchable by this plugin.
	 *
	 * @return  array  An array of search areas.
	 *
	 * @since   1.6
	 */
	public function onContentSearchAreas()
	{
		if (! $this->_enabled ) return;
		
		static $areas = array(
				'jwhmcs_search' => 'PLG_SEARCH_JWHMCS_SEARCH_AREA'
		);
	
		return $areas;
	}
	
	
	/**
	 * Search content (WHMCS Knowledgebase).
	 * @access		public
	 * @version		@fileVerrs@
	 * @param		string		Target search string.
	 * @param		string		Matching option (possible values: exact|any|all).  Default is "any".
	 * @param		string		Ordering option (possible values: newest|oldest|popular|alpha|category).  Default is "newest".
	 * @param		mixed		An array if the search it to be restricted to areas or null to search all areas.
	 * 
	 * @return  	array of results
	 * @since   	2.5.15
	 */
	public function onContentSearch($text, $phrase = '', $ordering = '', $areas = null)
	{
		// Dont bother searching if we aren't looking to
		if ( is_array( $areas ) ) {
			if (! array_intersect( $areas, array_keys( $this->onContentSearchAreas() ) ) ) {
				return array();
			}
		}
		
		// Nothing being sought
		if (! $text ) return array();
		
		$post	=	array(
			'text'	=>	$text,
			'type'	=>	$phrase,
			'order'	=>	$ordering
		);
		
		$api	=	dunloader( 'api', 'com_jwhmcs' );
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		$items	=	(array) $api->searchknowledgebase( $post );
		$data	=	array();
		
		// Empty result
		if (! $items ) return array();
		
		// Process for Joomla
		$whmcsurl	=	$config->get( 'whmcsurl' );
		
		foreach ( $items as $item ) {
			$new_item			=	new stdClass();
			$new_item->href		=	rtrim( $whmcsurl, '/' ) . '/knowledgebase' . ( $item->isseo ? '/' . $item->id . '/' . $item->seotitle . '.html' : '.php?action=displayarticle&id=' . $item->id );
			$new_item->title	=	$item->title;
			$new_item->text		=	$item->article;
			$new_item->section	=	$item->category;
			$new_item->created	=	null;
			
			$data[]	=	$new_item;
		}
		
		return $data;
	}
	
	
	/**
	 * Common method for displaying an error message
	 * @access		private
	 * @version		2.6.21
	 * @param		string		- $msg: the message to display
	 *
	 * @since		2.5.15
	 */
	private function _displayError( $msg = null, $task = 'token', $usesess = true )
	{
		// Translate string first
		$msg		=	JText :: _( $msg );
		$session	=	JFactory :: getSession();
	
		$hasrun		=	$session->get( 'jwhmcs_search.' . $task, false );
	
		if ( $hasrun && $usesess ) {
			return;
		}
		elseif ( $usesess ) {
			$session->set( 'jwhmcs_search.' . $task, true );
		}
	
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JFactory::getApplication()->enqueueMessage( "{$msg}" );
		}
		else {
			JError::raiseNotice( 100, "{$msg}" );
		}
	}
	
}