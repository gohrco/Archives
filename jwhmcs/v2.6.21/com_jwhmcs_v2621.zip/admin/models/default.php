<?php
/**
 * Ajax Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009-2016 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id$
 * @since      2.0.0
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );


/**
 * JwhmcsModelDefault class handles default data manipulation
 * @version		2.6.21
 *
 * @since		2.5.0
 * @author		Steven
 */
class JwhmcsModelDefault extends JwhmcsModelExt
{
	/**
	 * Constructor task
	 * @access		public
	 * @version		2.6.21
	 *
	 * @since		1.5.1
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Method to synchronize settings with WHMCS
	 * @access		public
	 * @version		2.6.21 ( $id$ )
	 *
	 * @return		string on error or true on success
	 * @since		2.5.0
	 */
	public function settingssync()
	{
		$api	=	dunloader( 'api', 'com_jwhmcs' );
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		
		// Verify API is enabled and working
		if (! $api->isEnabled() ) {
			return 'APIDISABLED';
		}
		
		$data	=	array(
				'enable'				=>	$config->get( 'enable' ),
				'debug'					=>	$config->get( 'debug' ),
				'token'					=>	$config->get( 'token' ),
				'enableuserbridging'	=>	$config->get( 'enableuserbridging' ),
				'languageenable'		=>	$config->get( 'languageenable' ),
				'regmethod'				=>	$config->get( 'regmethod' )
				);
		
		if (! $api->updatesettings( $data ) ) {
			return 'APIERROR';
		}
		
		return true;
	}
}