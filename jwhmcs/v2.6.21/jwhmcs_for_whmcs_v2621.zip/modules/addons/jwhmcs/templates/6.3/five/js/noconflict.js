/**
 * noconflict.js
 * Compatible with WHMCS v6.3 and above
 * 
 * J!WHMCS Integrator - Custom Javascript File
 *
 * @package    J!WHMCS Integrator
 * @copyright  @copyWrite@
 * @license    GNU General Public License version 2, or later
 * @version    2.6.21 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.6.20
*/

jQuery.noConflict();