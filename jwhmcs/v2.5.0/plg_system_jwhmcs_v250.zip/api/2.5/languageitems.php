<?php
/**
 * J!WHMCS Integrator - API Language Items File
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.5.0 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.5.0
 *
 * @desc       This is the Languageitems Task for the J!WHMCS Integrator API
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Languageitems Jwhmcs API Class
 * @version		2.5.0
 *
 * @since		2.5.0
 * @author		Steven
 */
class LanguageitemsJwhmcsAPI extends JwhmcsAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		2.5.0
	 * 
	 * @since		2.5.0
	 * @see			JwhmcsAPI :: execute()
	 */
	public function execute()
	{
		$db		=	dunloader( 'database', true );
		$query	=	"SHOW TABLES LIKE " . $db->Quote( "%languages" );
		
		$db->setQuery( $query );
		$result	=	$db->loadResult();
		
		if (! $result ) {
			$this->error( JText :: _( 'JWHMCS_SYSM_API_LANGITEMS_NOTABLE' ) );
		}
		
		$query	=	"SELECT `title` as `name`, `lang_code` as `code`, `sef` as `shortcode` FROM #__languages WHERE `published` <> '-2' ORDER BY name";
		$db->setQuery( $query );
		$langs	=	$db->loadObjectList();
		
		$return	=	(object) array( 'languageitems' => $langs, 'version' => DUN_ENV_VERSION );
		$this->success( $return );
	}
}