<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');
JHTML::_('behavior.formvalidation');

$data = $this->data;
?>


<form action="index.php" method="post" name="adminForm">
<div id="adminInput">
	<table class="admintable" width="675px">
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_LICENSE_PRODUCTLICENSE_TEXT" ); ?>
				</div>
				<div class="paramdesc">
				<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_LICENSE_PRODUCTLICENSE_DESC" ); ?>
				</div>
			</td>
			<td rowspan="2" width="220px" valign="top">
				<div id="whmcsstatus">
					<div id="whmcsstatusimg"></div>
					<div id="whmcsstatusmsg" style="width: 200px; margin: 0px auto; font-size: small; font-weight: bold; clear: both; padding: 10px; text-align: center; "></div>
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="text" name="licensekey" value="<?php echo $data->license; ?>" size="40" style="font-size: 14px; " onChange="ajaxLicenseCheck();" id="licensekey" />
			</td>
		</tr>
	</table>
</div>
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="task" value="licenseAccept" />
<input type="hidden" name="license" id="license" value="0" />
<input type="hidden" name="controller" value="install" />
<input type="hidden" id="whmcsstatusmsgdefault" value="<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_STATUSDEFAULT" ); ?>" />
</form>
<script language="javascript">
window.onload = ajaxLicenseCheck();
</script>