<?php
/**
 * Group Management Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: grpmgr.php 169 2011-02-04 05:39:14Z steven_gohigher $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model

include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelGrpmgr
 * Extends:		JwhmcsModel
 * Purpose:		Used as the group management model
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsModelGrpmgr extends JwhmcsModel
{
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
		
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getData
	 * Purpose:		This model retrieves the data for the view based
	 * 				on the parameters and task sent to it.
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function getData($task = null)
	{
		// 0:  Initialize Common Variables
		global $mainframe;
		$db		= &JFactory::getDBO();
		$uri	= &JURI::getInstance();
		
		// 1:  Switch on task
		switch ($task):
		case 'add':
		case 'edit':
			$isNew		= ($this->_id < 1);
			
			if ($isNew):
				$data->id = 0;
			else:
				$query	= 'SELECT grp.id, grp.cname, grp.fname, grp.lname, grp.email, grp.password '
							.' FROM #__jwhmcs_group AS grp '
							.' WHERE grp.id='.$this->_id
							.' ORDER BY grp.cname, grp.lname';
				$db->setQuery($query);
				$data = $db->loadObject();
			endif;
			break;
		case 'userlist':
			$query	= 'SELECT a.id as `id`, CONCAT(a.name, "(", a.username, ")") as `name`, a.email, '.$this->_id.' as groupid '
						. ' FROM (#__jwhmcs_xref as x INNER JOIN #__jwhmcs_group as grp ON x.xref_b=grp.id) '
						. ' INNER JOIN #__users as a ON a.id = x.xref_a '
						. ' WHERE x.xref_type=4 '
						. ' AND x.xref_b='.$this->_id
						. ' ORDER BY name, email';
			$db->setQuery($query);
			$data = $db->loadObjectList();
			break;
		case 'useradd':
			$query	= 'SELECT a.id as `value`, CONCAT(a.name, " (", a.username, "::", a.email, ")") as `text` '
						. ' FROM #__users as a '
						. ' ORDER BY name, username, email';
			$db->setQuery($query);
			$result = $db->loadAssocList();
			foreach( $db->loadObjectList() as $obj )
				$users[] = JHTML::_('select.option',  $obj->value, $obj->text );
			
			$data->joomlaid	= JHTML::_('select.genericlist', $users, 'joomlaid', '', 'value', 'text' );
			$data->groupid	= JRequest::getVar( 'groupid' );
			break;
		default:
			$query	= 'SELECT grp.id, grp.cname, grp.fname, grp.lname '
						.' FROM #__jwhmcs_group AS grp '
						.' ORDER BY grp.cname, grp.lname';
			$db->setQuery($query);
			$data	= $db->loadObjectList();
		endswitch;
		
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		store
	 * Purpose:		This method stores data sent from the group manager
	 * 				form.
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function store($post)
	{
		return $this->storeData('group', $post);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		delete
	 * Purpose:		This method deletes data sent from the group manager
	 * 				list.
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function delete($post)
	{
		return $this->deleteData('group', $post);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		userstore
	 * Purpose:		This method stores the user selected in the xref
	 * 				table with the group.  It also has to remove any
	 * 				existing xrefs in the table
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function userstore($post)
	{
		// 0:  Initialize Variables
		$db	= &JFactory::getDBO();
		
		// 1:  Search for any existing xrefs of any user type
		$query	= 'SELECT x.xref_a as joomlaid, x.xref_type as type, x.xref_b as clientid FROM #__jwhmcs_xref as x WHERE x.xref_a='.$post['joomlaid'];
		$db->setQuery($query);
		$existing = $db->loadAssocList();
		
		// 2:  Delete exising xrefs
		$this->deleteXref($existing);
		
		// 3:  Add the new reference to the table
		$query	= 'INSERT INTO #__jwhmcs_xref (`xref_a`, `xref_type`, `xref_b`) VALUES ('.$post['joomlaid'].', 4, '.$post['groupid'].')';
		$db->setQuery($query);
		$db->query();
		
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		userremove
	 * Purpose:		This method removes the user selected in the xref
	 * 				table with the group.  
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function userremove($post)
	{
		// 1:  Search for any existing xrefs of any user type
		foreach ($post['cid'] as $joomlaid):
			$xref[] = array('joomlaid' => $joomlaid, 'type' => 4, 'clientid' => $post['groupid']);
		endforeach;
		
		// 2:  Delete exising xrefs
		$this->deleteXref($xref);
		
		return;
	}
	
	/* ----------------------------------------- *\
	 *              SUB FUNCTIONS                *
	\* ----------------------------------------- */
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		deleteXref (private)
	 * Purpose:		Removes xrefs in the database  
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	private function deleteXref($xref)
	{
		$db	= &JFactory::getDBO();
		
		foreach($xref as $x):
			$query = 'DELETE FROM #__jwhmcs_xref WHERE xref_a='.$x['joomlaid'].' AND xref_type='.$x['type'].' AND xref_b='.$x['clientid'];
			$db->setQuery($query);
			$db->query();
		endforeach;
	}
}