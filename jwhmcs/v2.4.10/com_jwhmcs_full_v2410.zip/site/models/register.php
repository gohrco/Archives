<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.4.10 ( $Id: register.php 469 2012-05-04 20:04:56Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      2.1.0
 * 
 * @desc       This file contains the register model which allows the user and system to interact with the data
 *  
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * Register model handles user registration data interaction
 * @version		2.4.10
 * 
 * @since		2.1.0
 * @author		Steven
 */
class JwhmcsModelRegister extends JwhmcsModel
{
	
	/**
	 * Constructor
	 * @access		public
	 * @version		2.4.10
	 * 
	 * @since		2.1.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Retrieves the posted variables if returning to same page
	 *  - Required to return null array for strict error reporting
	 * @access		public
	 * @version		2.4.10
	 * 
	 * @return		array of posted variables or null array
	 * @since		2.3.2
	 */
	public function getPost()
	{
		$vars	= array( "firstname", "lastname", "companyname", "address1", "address2", "city", "state", "postcode", "country", "phonenumber", "username", "email" );
		$post	= array();
		
		foreach ( $vars as $v ) $post[$v] = JwhmcsHelper :: get( $v, null );
		
		return $post;
	}
	
	
	/**
	 * Save data submitted for the username layout
	 * @access		public
	 * @version		2.4.10
	 * @deprecated	moved to changeusername model
	 * 
	 * @return		boolean true on success
	 * @since		2.1.0
	 */
	public function submitUsername()
	{
		global $mainframe;
		
		if (! defined( "JWHMCS_AUTH" ) )	// Set so we don't try to add the new user to WHMCS
			define("JWHMCS_AUTH", true);
		
		$db		= & JFactory::getDBO();
		$user	= & JFactory::getUser( JwhmcsHelper :: get( 'joomlaid' ) );
		
		// Validate token first or fail
		JwhmcsHelper :: checkToken() or jexit( 'Invalid Token' );
		
		$binder	= array(	'username'	=> JwhmcsHelper :: get('username') );
		
		if (! $user->bind($binder) ) {
			JError::raiseError( 500, $user->getError());
			return false;
		}
		
		if (! $user->save() ) {
			JError::raiseWarning('', JText::_( $user->getError()));
			return false;
		}
		
		// Update xref table
		$jid = JwhmcsHelper :: get( 'joomlaid' );
		$wid = JwhmcsHelper :: get( 'whmcsid' );
		
		$query	= "UPDATE #__jwhmcs_xref x SET xref_type=2 WHERE xref_a = $jid AND xref_b = $wid AND xref_type = 8";
		$db->setQuery($query);
		$db->query();
		
		$query	= "UPDATE #__jwhmcs_xref x SET xref_type=6 WHERE xref_a = $jid AND xref_b = $wid AND xref_type = 9";
		$db->setQuery($query);
		$db->query();
		
		// Build the credentials array
		$parameters['username']	= $user->get('username');
		$parameters['id']		= $user->get('id');
		
		$credentials['fullname']	= $user->get( 'name' );
		$credentials['username']	= $user->get( 'username' );
		$credentials['email']		= $user->get( 'email' );
		$credentials['password']	= JwhmcsHelper :: get( 'password' );
		$credentials['status']		= JAUTHENTICATE_STATUS_SUCCESS;
		$credentials['type']		= 'jwhmcs_auth';
		
		// Set clientid in the options array if it hasn't been set already
		$options['clientid'][] = $mainframe->getClientId();
		
		// Import the user plugin group
		JPluginHelper::importPlugin('user');

		// Now log in with correct credentials and allow Joomla to handle the rest
		$result = $mainframe->triggerEvent( 'onLoginUser', array( $credentials, array() ) );
		
		return true;
	}
	
	
	/**
	 * Assembles data to request new username from client
	 * @access		public
	 * @version		2.4.10
	 * @deprecated	moved to changeusername model
	 * 
	 * @return		array containing user data
	 * @since		2.1.0
	 */
	public function username()
	{
		$db		= & JFactory::getDBO();
		$user	= & JFactory::getUser();
		
		// Pull user from DB
		$query	= "SELECT `xref_a` as joomlaid, `xref_type` as type, `xref_b` as whmcsid FROM #__jwhmcs_xref xref WHERE xref.xref_a = {$user->id} AND xref.xref_type BETWEEN 8 AND 9";
		$db->setQuery($query);
		$result	= $db->loadAssocList();
		
		// Make sure we got one
		if ( ( count( $result ) > 1 ) || ( count( $result ) == 0 ) )
			return false;
		
		$result	= $result[0];
		
		// Pull password from DB
		$sarray	= $this->getSess( JwhmcsHelper :: get( 'token' ) );
		$type	= $result['type'] == '8' ? 'client' : 'contact';
		$whmcs	= $this->getWhmcsData( $result['whmcsid'], 'id', $type );
		$whmcs['password'] = $sarray['password'];
		$data	= array_merge($result,$whmcs);
		
		return $data;
	}
	
	
	/**
	 * Check a user requested name against the database
	 * @access		public
	 * @version		2.4.10
	 * @deprecated	
	 * @param 		string		- $username: contains requested username
	 * @param 		integer		- $userid: contains the user id requesting new username
	 * 
	 * @return 		array containing results and message
	 * @since		2.1.0
	 */
	public function validateUsername( $username = null, $userid = 0 )
	{
		$db	= & JFactory::getDBO();
		
		// If nothing sent return false
		if ( is_null( $username ) || ( trim( $username ) == '' ) ) return array('result' => false, 'message' => JText::_( 'REGISTER_USERNAME_ERROR00' ) );
		
		// Check to see if username is an email address
		$pattern = "/\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,5}\b/i";
		$match = preg_match($pattern, $username);
		if ($match > 0) return array( 'result' => false, 'message' => JText::_( 'REGISTER_USERNAME_ERROR01' ) );
		
		// Check to see if the username is "too short"
		if ( strlen( $username ) < 3 ) return array( 'result' => false, 'message' => sprintf( JText::_( 'REGISTER_USERNAME_ERROR02' ), $username ) );
		
		// See if there is a user by that name
		$query	= "SELECT `id` FROM `#__users` WHERE `username` = " . $db->quote( $username );
		$db->setQuery($query);
		$result = $db->loadResult();
		
		// If we get an id back then the name is taken
		if ( $result )
		{
			if ($result == $userid)
			{
				return array( 'result' => true, 'message' => sprintf( JText::_( 'REGISTER_USERNAME_SUCCESS02' ), $username ) );
			}
			else
			{
				return array( 'result' => false, 'message' => sprintf( JText::_( 'REGISTER_USERNAME_ERROR03' ), $username ) );
			}
		}
		else
		{
			return array( 'result' => true, 'message' => sprintf( JText::_( 'REGISTER_USERNAME_SUCCESS' ), $username ) );
		}
	}
	
	
	/**
	 * Checks information to see if it is valid
	 * (Called through Ajax)
	 * @access		public
	 * @version		2.4.10
	 * @param 		string		- $type: the type of info to validate
	 * @param 		string		- $value: the value passed to check
	 * 
	 * @return 		array containing results
	 * @since		2.1.0
	 */
	public function validInfo( $type, $value )
	{
		$db		= & JFactory::getDBO();
		$params	= & JwhmcsParams::getInstance();
		
		switch($type):
		case 'username':
			// If nothing sent return false
			if ( is_null( $value ) || ( trim( $value ) == '' ) ) return array('result' => false, 'message' => JText::_( "COM_JWHMCS_REGISTER_AJAX_USERNAME_VALID_ERROR00" ) );
			
			// Check to see if username is an email address
			if ( ( JwhmcsHelper::isEmail( $value ) ) AND ( $params->get( "WuserAuthenticate" ) ) ) {
				return array( 'result' => false, 'message' => JText::_( "COM_JWHMCS_REGISTER_AJAX_USERNAME_VALID_ERROR01" ) );
			}
			
			// Check to see if the username is "too short"
			if ( strlen( $value ) < 3 ) return array( 'result' => false, 'message' => sprintf( JText::_( "COM_JWHMCS_REGISTER_AJAX_USERNAME_VALID_ERROR02" ), $value ) );
			
			// See if there is a user by that name
			$query	= "SELECT `id` FROM `#__users` WHERE `username` = " . $db->quote( $value );
			$db->setQuery($query);
			$result = $db->loadResult();
			
			// If we get an id back then the name is taken
			if ( $result )
			{
				return array( 'result' => false, 'message' => sprintf( JText::_( "COM_JWHMCS_REGISTER_AJAX_USERNAME_VALID_ERROR03" ), $value ) );
			}
			else
			{
				return array( 'result' => true, 'message' => sprintf( JText::_( "COM_JWHMCS_REGISTER_AJAX_USERNAME_VALID_SUCCESS" ), $value ) );
			}
			
			break;
			
		case 'email':
			// If nothing sent return false
			if ( is_null( $value ) || ( trim( $value ) == '' ) ) return array( 'result' => false, 'message' => JText::_( "COM_JWHMCS_REGISTER_AJAX_EMAIL_VALID_ERROR00" ) );
			
			// Check to see if the value is an email address
			if (! JwhmcsHelper::isEmail( $value) ) return array( 'result' => false, 'message' => JText::_( "COM_JWHMCS_REGISTER_AJAX_EMAIL_VALID_ERROR01" ) );
			
			// See if there is a user by that name
			$query	= "SELECT `id` FROM `#__users` WHERE `email` = " . $db->quote( $value );
			$db->setQuery($query);
			$result = $db->loadResult();
			
			if ( $result )
				return array( 'result' => false, 'message' => sprintf( JText::_( "COM_JWHMCS_REGISTER_AJAX_EMAIL_VALID_ERROR02" ), $value ) );
			
			if ($this->getWhmcsData( $value, 'email', 'client' ) !== false )
				return array( 'result' => false, 'message' => sprintf( JText::_( "COM_JWHMCS_REGISTER_AJAX_EMAIL_VALID_ERROR03" ), $value ) );
			
			if ($this->getWhmcsData( $value, 'email', 'contact' ) !== false )
				return array( 'result' => false, 'message' => sprintf( JText::_( "COM_JWHMCS_REGISTER_AJAX_EMAIL_VALID_ERROR04" ), $value ) );
			
			if ( $this->_blockFreeEmail( $value ) === true ) {
				return array( 'result' => false, 'message' => sprintf( JText::_( 'COM_JWHMCS_REGISTER_AJAX_EMAIL_VALID_ERROR05' ), $value ) );
			}
			
			return array( 'result' => true, 'message' => sprintf( JText::_( "COM_JWHMCS_REGISTER_AJAX_EMAIL_VALID_SUCCESS" ), $value ) );
			break;
			
		case 'password':
			// If nothing sent return false
			if ( is_null( $value ) || ( trim( $value ) == '' ) ) return array( 'result' => false, 'message' => JText::_( "COM_JWHMCS_REGISTER_AJAX_PASSWORD_VALID_ERROR00" ) );
			
			// Retrieve setting in WHMCS for password strength
			$stdpws = $this->getPWSetting();
			$thispw = $this->getPasswordStrength( $value );
			
			if ( $thispw < $stdpws ) return array( 'result' => false, 'message' => sprintf( JText::_( "COM_JWHMCS_REGISTER_AJAX_PASSWORD_VALID_ERROR01" ), $thispw, $stdpws ) );
			
			return array( 'result' => true, 'message' => JText::_( "COM_JWHMCS_REGISTER_AJAX_PASSWORD_VALID_SUCCESS" ) );
			break;
		endswitch;
	}
	
	
	/**
	 * Retrieve and remove the passed session info
	 * @access		public
	 * @version		2.4.10
	 * @deprecated	use JwhmcsHelper::getSession() instead
	 * @param		string		- $token: passed session token
	 * @see 		JwhmcsModel::getSess()
	 * 
	 * @return		array containing values from database
	 * @since		1.5.0
	 */
	public function getSess($token)
	{
		$db =& JFactory::getDBO();
		$query = 'SELECT `value` FROM #__jwhmcs_sess WHERE token="'.$token.'"';
		$db->setQuery($query);
		$result = $db->loadResult();
		
		$tmp = preg_split('/\n/', $result);
		foreach ($tmp as $t):
			$var = explode('=', $t);
			$k = $var[0];
			unset($var[0]);
			$ubind[$k] = implode("=", $var);
			unset($var, $k);
		endforeach;
		$query = 'DELETE FROM #__jwhmcs_sess WHERE token="'.$token.'"';
		$db->setQuery($query);
		$res = $db->query();
		
		return $ubind;
	}
	
	
	/**
	 * Determines the password strength according to WHMCS rules
	 * @access		private
	 * @version		2.4.10
	 * @param 		string		- $pw: the password to test strength for
	 * 
	 * @return		integer of determined password strength
	 * @since		2.1.0
	 */
	private function getPasswordStrength( $pw )
	{
		// String Length
		$pwlength = strlen($pw);
		if ( $pwlength > 5 ) $pwlength = 5;
		
		// How many numbers
		$numnumeric = preg_replace( "/[0-9]/", "", $pw );
		$numeric = strlen( $pw ) - strlen( $numnumeric );
		if ( $numeric > 3 ) $numeric = 3;
		
		// How many symbols
		$symbols = preg_replace( "/\W/", "", $pw );
		$numsymbols = strlen( $pw ) - strlen( $symbols );
		if ( $numsymbols > 3 ) $numsymbols = 3;
		
		// How many uppercase
		$numupper = preg_replace( "/[A-Z]/", "", $pw );
		$upper = strlen( $pw ) - strlen( $numupper );
		if ( $upper > 3 ) $upper = 3;
		
		// Calculate password strength
		$pwstrength = ( ( $pwlength * 10 ) - 20 ) + ( $numeric * 10 ) + ( $numsymbols * 15 ) + ( $upper * 10 );
		
		// Keep strength between 0 and 100 and return
		if ( $pwstrength < 0 ) $pwstrength = 0;
		if ( $pwstrength > 100 ) $pwstrength = 100;
		return $pwstrength;
	}
	
	
	/**
	 * Retrieve the active password strength from WHMCS
	 * @access		private
	 * @version		2.4.10
	 * 
	 * @return		integer containing password strength from WHMCS
	 * @since		2.1.0
	 */
	private function getPWSetting()
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		$jcurl->setAction('jwhmcsgetsettings', array("get" => "RequiredPWStrength"));
		$whmcs = $jcurl->loadResult();
		
		if ( empty($whmcs) || ( $whmcs['result'] != 'success' ) )
			return 0;
		
		return $whmcs['requiredpwstrength'];
	}
	
	
	/**
	 * Request user information from WHMCS
	 * @access		public
	 * @version		2.4.10
	 * @deprecated	use JwhmcsHelper::getWhmcsUser() instead
	 * @param 		string		- $method: contains either an email or id to use to retrieve with
	 * @param 		string		- $by: either email or id
	 * @param 		string		- $type: either client or contact
	 * 
	 * @return		array of user data or false on error
	 * @since		2.1.0
	 */
	public function getWhmcsData($method, $by = 'email', $type = 'client' )
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		switch($type):
		case 'client':
			if ($by == 'email') {
				$jcurl->setAction('getclientsdatabyemail', array('email' => $method));
			}
			else {
				$jcurl->setAction('getclientsdata', array('clientid' => $method));
			}
		
			$whmcs	= $jcurl->loadResult();
			
			// WHMCS v421:  Now receive array of array -- need to test for it
			if ( isset($whmcs[0]['result']) ) $whmcs = $whmcs[0];
			
			if (( isset($whmcs['result'])) && ($whmcs['result'] == 'success')) {
				$ret = $whmcs;
			}
			else {
				$ret = false;
			}
			break;
		case 'contact':
			
			$jcurl->setAction('jwhmcsgetcontact', array("get" => "$by=$method"));
			$whmcs = $jcurl->loadResult();
			
			if ($whmcs['result'] == 'success') {
				$whmcs['userid'] = $whmcs['id'];
				$ret = $whmcs;
			}
			else {
				$ret = false;
			}
			break;
		endswitch;
		
		return $ret;
	}
	
	
	/**
	 * Checks to see if an email is from a free email service if it should block them
	 * @access		private
	 * @version		2.4.10
	 * @param		string		- $email: containing the address to check
	 * 
	 * @return		boolean true if it should be blocked, false otherwise
	 * @since		2.2.6
	 */
	private function _blockFreeEmail( $email )
	{
		$params	= & JwhmcsParams::getInstance();
		if ( $params->get( "RegNofreeemail" ) == "0" ) return false;
		
		$domains	= explode( ",", $params->get( "RegNofreeemaildomains" ) );
		for($i=0;$i<count($domains);$i++) $domains[$i] = trim($domains[$i]);
		
		$eparts	= explode("@",$email);
		if ( in_array( $eparts[1], $domains ) ) return true;
		return false;
	}
}