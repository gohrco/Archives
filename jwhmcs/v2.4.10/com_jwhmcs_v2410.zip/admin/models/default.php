<?php
/**
 * Default Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: default.php 555 2012-09-06 02:10:32Z steven_gohigher $
 * @since      1.5.1
 */
 
// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model


/**
 * JwhmcsModelDefault class is the default model for the admin area
 * @version		2.4.10
 * @see			JwhmcsModel
 * 
 * @since		1.5.1
 * @author		Steven
 */

class JwhmcsModelDefault extends JwhmcsModel
{
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		2.4.10
	 * 
	 * @since		1.5.1
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Creates icons for display on the default page
	 * @access		public
	 * @version		2.4.10
	 * @param		JObject		- $canDo: permissions user has
	 * 
	 * @return		array containing icon definitions
	 * @since		1.5.1
	 */
	public function getIconDefinitions( $canDo )
	{
		$ret = array();
		
		if ( $canDo->get( 'core.manage' ) ) {
			$ret[] = $this->_makeIconDefinition( 'j-48-usrmgr.png', JText::_('COM_JWHMCS_DEFAULT_VIEW_BUTTON_USERMANAGER'), 'usermgr' );
			//$ret[] = $this->_makeIconDefinition( 'j-48-grpmgr.png', JText::_('COM_JWHMCS_DEFAULT_VIEW_BUTTON_GROUPMANAGER'), 'grpmgr' );
			$ret[] = $this->_makeIconDefinition( 'j-48-sync.png', JText::_('COM_JWHMCS_DEFAULT_VIEW_BUTTON_SYNCMANAGER'), 'sync' );
		}
		
		if ( $canDo->get( 'core.admin' ) ) {
			$ret[] = $this->_makeIconDefinition( 'j-48-chinst.png', JText::_('COM_JWHMCS_DEFAULT_VIEW_BUTTON_CHECKINSTALL'), 'check' );
			$ret[] = $this->_makeIconDefinition( 'j-48-settings.png', JText::_('COM_JWHMCS_DEFAULT_VIEW_BUTTON_SETTINGS'), 'config');
			$ret[] = $this->_makeIconDefinition( 'ajax-loader-48.gif', JText::_('COM_JWHMCS_BUTTON_UPDATESLOADING' ), 'updates', 'jwhmcs_icon_updates' );
		}
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) && $canDo->get( 'core.admin' ) ) {
			$ret[] = $this->_makeIconDefinition( 'j-48-apiconxn.png', JText::_('COM_JWHMCS_DEFAULT_VIEW_BUTTON_APICONXN'), 'default', null, null, 'apiconxn' );
			$ret[] = $this->_makeIconDefinition( 'j-48-license.png', JText::_('COM_JWHMCS_DEFAULT_VIEW_BUTTON_LICENSE'), 'default', null, null, 'license' );
		}
		
		$ret[] = $this->_makeIconDefinition( 'j-48-helppage.png', JText::_('COM_JWHMCS_DEFAULT_VIEW_BUTTON_HELPPAGE'), 'helppage');
		
		return $ret;
	}
	
	
	/**
	 * Method to create an icon definition
	 * @access		private
	 * @version		2.4.10
	 * @version		2.4.0		- May 2012: Added id tag to img
	 * @param		string		- $iconFile
	 * @param		string		- $label
	 * @param		string		- $controller
	 * @param		string		- $id: the id tag of the image to use
	 * @param		string		- $view
	 * @param		string		- $task
	 * 
	 * @return array
	 * @since		1.5.1
	 */
	private function _makeIconDefinition($iconFile, $label, $controller = null, $id = null, $view = null, $task = null )
	{
		return array(
			'icon'		=> $iconFile,
			'label'		=> $label,
			'controller'=> $controller,
			'id'		=> $id,
			'view'		=> $view,
			'task'		=> $task
		);
	}
}