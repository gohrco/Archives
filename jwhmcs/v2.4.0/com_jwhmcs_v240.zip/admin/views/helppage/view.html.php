<?php
/**
 * Help Page View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    ${p.PROJECT_LICJOOMLA}
 * @version    $Id: view.html.php 169 2011-02-04 05:39:14Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsViewHelppage
 * Extends:		JView
 * Purpose:		Used to view support options
 * As of:		version 2.1.0
\* ------------------------------------------------------------ */
class JwhmcsViewHelppage extends JView
{
	/* ------------------------------------------------------------ *\
	 * Method:		display
	 * Purpose:		Assembles the page for the application to send to
	 * 				the user
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function display($tpl = null)
	{
		
		JToolBarHelper :: title( JText::_( 'COM_JWHMCS_HELPPAGE_VIEW_TITLE' ), 'helppage.png' );
		JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
		
		parent::display($tpl);
	}
}