<?php
/**
 * Default View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    ${p.PROJECT_LICJOOMLA}
 * @version    $Id: view.html.php 471 2012-05-11 15:45:12Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );


/**
 * JwhmcsViewDefault class is the default view for the admin area
 * @version		2.4.0
 *
 * @since		1.5.0
 * @author		Steven
 */
class JwhmcsViewDefault extends JView
{
	
	/**
	 * Assembles the page for the application to send to user
	 * @access		public
	 * @version		2.4.0
	 * @param		unknown		- $tpl: internal tpl override option
	 * 
	 * @since		1.5.0
	 */
	public function display($tpl = null)
	{
		$model	= & $this->getModel('default');
		$params	= & JwhmcsParams::getInstance();
		$user	= & JFactory::getUser();
		$lic	=   $model->checkLicense();		// Check J!WHMCS Integrator License
		//$wup	=   $model->whmcsParamUpdate();	// Update WHMCS Parameters (bool)
		$task	=   JwhmcsHelper :: get( 'task' );
		 
		// Retrieve ACL permitted actions
		$canDo	= JwhmcsHelper :: getActions();
		
		// Create the toolbar
		JwhmcsToolbar :: build( 'default', $task, $canDo );
		
		// Grab the icons for the cpanel
		$icons = $model->getIconDefinitions( $canDo );
		
		JwhmcsHelper :: addMedia( 'common/js' );
		JwhmcsHelper :: addMedia( 'ajax/js' );
		JwhmcsHelper :: addMedia( 'icons/css' );
		
		$this->assignRef('lic',		$lic);		// Contains the license check data
		$this->assignRef('icondefs', $icons); // Icon definitions
		$this->assignRef('data',	$params);
		parent::display($tpl);
	}
}