<?php
/**
 * Group Management Controller for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    ${p.PROJECT_LICJOOMLA}
 * @version    $Id: grpmgr.php 169 2011-02-04 05:39:14Z steven_gohigher $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsControllerGrpmgr
 * Extends:		JwhmcsController
 * Purpose:		Used for Group Management
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsControllerGrpmgr extends JwhmcsController
{
	/* ------------------------------------------------------------ *\
	 * Task:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
		
		$this->registerTask( 'add',	'edit' );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		edit
	 * Purpose:		Allows for adding and editing of Managed Groups
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function edit()
	{
		JRequest::setVar( 'layout', 'form' );
		JRequest::setVar( 'hidemainmenu', 1 );
		parent::display();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		save
	 * Purpose:		Allows for saving Managed Groups
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function save()
	{
		$model	= $this->getModel( 'grpmgr' );
		$post[]	= JRequest::get( 'method' );
		
		if ($model->store($post))
			$msg = JText::_( "COM_JWHMCS_GRPMGR_CTRL_GRPADDY" );
		else
			$msg = JText::_( "COM_JWHMCS_GRPMGR_CTRL_GRPADDN" );
		
		$link = 'index.php?option=com_jwhmcs&controller=grpmgr';
		$this->setRedirect($link, $msg);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		remove
	 * Purpose:		Allows for removal of Managed Groups
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function remove()
	{
		$model	= $this->getModel( 'grpmgr' );
		$post	= JRequest::getVar( 'cid', array(0), 'post', 'array' );
		
		if($model->delete($post))
			$msg = JText::_( "COM_JWHMCS_GRPMGR_CTRL_GRPDELY" );
		else
			$msg = JText::_( "COM_JWHMCS_GRPMGR_CTRL_GRPDELN" );
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=grpmgr', $msg );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		useradd
	 * Purpose:		Allows for the addition of users to Managed Groups
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function useradd()
	{
		JRequest::setVar( 'layout', 'userform' );
		JRequest::setVar( 'hidemainmenu', 1 );
		parent::display();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		userlist
	 * Purpose:		Display list of users in a Managed Group
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function userlist()
	{
		JRequest::setVar( 'layout', 'userlist' );
		parent::display();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		usersave
	 * Purpose:		Allows for saving Managed Groups
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function usersave()
	{
		$model	= $this->getModel( 'grpmgr' );
		$post	= JRequest::get( 'method' );
		
		$model->userstore($post);
		
		$msg = JText::_( "COM_JWHMCS_GRPMGR_CTRL_GRPADDA" );
		
		$link = 'index.php?option=com_jwhmcs&controller=grpmgr&task=userlist&cid='.$post['groupid'];
		$this->setRedirect($link, $msg);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		userremove
	 * Purpose:		Allows for removing users from Managed Groups
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function userremove()
	{
		$model	= $this->getModel( 'grpmgr' );
		$post	= JRequest::get( 'method' );
		
		$model->userremove($post);
		$msg = JText::_( "COM_JWHMCS_GRPMGR_CTRL_GRPUSR" );
		
		$link = 'index.php?option=com_jwhmcs&controller=grpmgr&task=userlist&cid='.$post['groupid'];
		$this->setRedirect($link, $msg);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		cancel
	 * Purpose:		Handle cancelation requests
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	public function cancel()
	{
		$msg = $msg = JText::_( "COM_JWHMCS_GRPMGR_CTRL_CANCEL" );
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=grpmgr', $msg );
	}
}