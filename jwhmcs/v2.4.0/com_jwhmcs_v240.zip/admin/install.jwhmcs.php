<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    ${p.PROJECT_LICJOOMLA}
 * @version    2.4.0 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      2.3.0
 * 
 * @desc       Installation Script
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( "joomla.filesystem.file" );


if (! version_compare( JVERSION, '1.6.0', 'ge' ) )
{
	if (! function_exists( 'com_install' ) )
	{
		function com_install()
		{
			$app	= & JFactory :: getApplication();
			$app->redirect( 'index.php?option=com_jwhmcs&controller=install&task=interview' );
		}
	}
}
