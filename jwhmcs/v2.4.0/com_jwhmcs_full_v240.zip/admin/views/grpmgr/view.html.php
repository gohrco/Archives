<?php
/**
 * Group Management View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    ${p.PROJECT_LICJOOMLA}
 * @version    $Id: view.html.php 169 2011-02-04 05:39:14Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsViewGrpmgr
 * Extends:		JView
 * Purpose:		Used as the group management view
 * 
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsViewGrpmgr extends JView
{
	/* ------------------------------------------------------------ *\
	 * Method:		display
	 * Purpose:		Assembles the page for the application to send to
	 * 				the user
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function display($tpl = null)
	{
		$model	= & $this->getModel('grpmgr');
		$user	= & JFactory::getUser();
		$task	=   JRequest::getVar( 'task' );
		$data	=   $model->getData( $task );
		
		switch ($task):
		case 'add':
		case 'edit':
			$isNew		= ($data->id < 1);
			$text		= $isNew ? JText::_( "COM_JWHMCS_GRPMGR_VIEW_ADDNEW_TITLE" ) : JText::_( "COM_JWHMCS_GRPMGR_VIEW_EDITEX_TITLE" );
			
			JToolBarHelper::title(   JText::_( "COM_JWHMCS_GRPMGR_VIEW_TITLE" ).': <small><small>[ ' . $text.' ]</small></small>', 'grpmgr.png' );
			JToolBarHelper::back();
			JToolBarHelper::save();
			
			if ($isNew)
				JToolBarHelper::cancel();
			else
				JToolBarHelper::cancel( 'cancel', 'Close' );
			
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
			
			$this->assignRef('data',	$data);
			break;
		case 'userlist':
			JToolBarHelper::title( JText::_( "COM_JWHMCS_GRPMGR_VIEW_TITLE" ).': <small><small>[ ' . JText::_( "COM_JWHMCS_GRPMGR_VIEW_USERLIST_TITLE" ).' ]</small></small>', 'grpmgr.png' );
			JToolBarHelper :: custom( 'display', 'grpmgr.png', 'grpmgr.png', JText::_( "COM_JWHMCS_DEFAULT_VIEW_BUTTON_GROUPMANAGER" ), false, false );
			JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
			JToolBarHelper::divider();
			JToolBarHelper::addNewX( 'useradd', JText::_( "COM_JWHMCS_GRPMGR_VIEW_BUTTON_ADDUSER" ) );
			JToolBarHelper::divider();
			JToolBarHelper::deleteList( 'JWHMCS_ADMIN_BUTTON_DELMSG', 'userremove', JText::_( 'JWHMCS_ADMIN_BUTTON_GRPDEL' ));
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
			
			$this->assign('groupid', $model->_id);
			break;
		case 'useradd':
			$text	= JText::_( "COM_JWHMCS_GRPMGR_VIEW_USERADD_TITLE" );
			
			JToolBarHelper::title(   JText::_( "COM_JWHMCS_GRPMGR_VIEW_TITLE" ).': <small><small>[ ' . $text.' ]</small></small>', 'grpmgr.png' );
			JToolBarHelper::back();
			JToolBarHelper::save( 'usersave', 'Save' );
			JToolBarHelper::cancel();
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
			$this->assignRef('data',	$data);
			break;
		default:
			JToolBarHelper::title( JText::_( "COM_JWHMCS_GRPMGR_VIEW_TITLE" ), 'grpmgr.png' );
			JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', JText::_( "COM_JWHMCS_DEFAULT_VIEW_BUTTON_JWHMCS" ), false, false );
			JToolBarHelper :: custom( 'usrmgr', 'usrmgr.png', 'usrmgr.png', JText::_( "COM_JWHMCS_DEFAULT_VIEW_BUTTON_USERMANAGER" ), false, false );
			JToolBarHelper::divider();
			JToolBarHelper::addNewX();
			JToolBarHelper::editListX();
			JToolBarHelper::divider();
			JToolBarHelper::deleteList();
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
		endswitch;
		
		JHtml::stylesheet( "com_jwhmcs/icons.css", array(), true );
		JHtml::stylesheet( "com_jwhmcs/admin.css", array(), true );
		
		$this->assignRef('data', $data);
		parent::display($tpl);
	}
}