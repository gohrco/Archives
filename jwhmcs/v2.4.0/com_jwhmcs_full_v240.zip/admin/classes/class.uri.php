<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    ${p.PROJECT_LICJOOMLA}
 * @version    $Id: class.uri.php 169 2011-02-04 05:39:14Z steven_gohigher $
 * @since      2.1.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class JwhmcsUri
{
	var $_uri = null;
	var $_scheme = null;
	var $_host = null;
	var $_port = null;
	var $_user = null;
	var $_pass = null;
	var $_path = null;
	var $_query = null;
	var $_fragment = null;
	var $_vars = array ();
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Called upon initialization of object class
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function __construct($uri = null)
	{
		if ($uri !== null) {
			$this->parse($uri);
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getInstance
	 * Purpose:		Returns a reference to object, creating if not exists
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function &getInstance($uri = 'SERVER', $force = false)
	{
		static $instances = array();
		
		if ($force && isset($instances[$uri]))
			unset ($instances[$uri]);
		
		if (!isset ($instances[$uri])) {
			if ($uri == 'SERVER') {
				if (isset($_SERVER['HTTPS']) && !empty($_SERVER['HTTPS']) && (strtolower($_SERVER['HTTPS']) != 'off')) {
					$https = 's://';
				} else {
					$https = '://';
				}
				if (!empty ($_SERVER['PHP_SELF']) && !empty ($_SERVER['REQUEST_URI'])) {
					$theURI = 'http' . $https . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
				}
				else {
					$theURI = 'http' . $https . $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME'];
					if (isset($_SERVER['QUERY_STRING']) && !empty($_SERVER['QUERY_STRING'])) {
						$theURI .= '?' . $_SERVER['QUERY_STRING'];
					}
				}
				
				$theURI = urldecode($theURI);
				$theURI = str_replace('"', '&quot;',$theURI);
				$theURI = str_replace('<', '&lt;',$theURI);
				$theURI = str_replace('>', '&gt;',$theURI);
				$theURI = preg_replace('/eval\((.*)\)/', '', $theURI);
				$theURI = preg_replace('/[\\\"\\\'][\\s]*javascript:(.*)[\\\"\\\']/', '""', $theURI);
			}
			else {
				$theURI = $uri;
			}

			// Create the new JwhmcsUri instance
			$instances[$uri] = new JwhmcsUri($theURI);
		}
		return $instances[$uri];
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		base
	 * Purpose:		Returns the base uri for the request
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function base($pathonly = false)
	{
		static $base;
		
		if (!isset($base))
		{
			$uri			= & JwhmcsUri::getInstance();
			$base['prefix'] = $uri->toString( array('scheme', 'host', 'port'));
			
			if (strpos(php_sapi_name(), 'cgi') !== false && !empty($_SERVER['REQUEST_URI'])) {
				//Apache CGI
				$base['path'] =  rtrim(dirname(str_replace(array('"', '<', '>', "'"), '', $_SERVER["PHP_SELF"])), '/\\');
			} else {
				//Others
				$base['path'] =  rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
			}
		}
		
		return $pathonly === false ? $base['prefix'].$base['path'].'/' : $base['path'];
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		root
	 * Purpose:		Returns the root uri for the request
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function root($pathonly = false, $path = null)
	{
		static $root;
		
		if(!isset($root))
		{
			$uri	        =& JwhmcsUri::getInstance(JwhmcsUri::base());
			$root['prefix'] = $uri->toString( array('scheme', 'host', 'port') );
			$root['path']   = rtrim($uri->toString( array('path') ), '/\\');
		}

		// Get the scheme
		if(isset($path)) {
			$root['path']    = $path;
		}

		return $pathonly === false ? $root['prefix'].$root['path'].'/' : $root['path'];
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		current
	 * Purpose:		Returns the url for the request minus query
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function current()
	{
		static $current;
		
		if (!isset($current))
		{
			$uri	 = & JwhmcsUri::getInstance();
			$current = $uri->toString( array('scheme', 'host', 'port', 'path'));
		}
		return $current;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		parse
	 * Purpose:		Parse a given Uri and populate class fields
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function parse($uri)
	{
		$retval = false;
		$this->_uri = $uri;
		
		if ($_parts = $this->_parseURL($uri)) {
			$retval = true;
		}
		
		if(isset ($_parts['query']) && strpos($_parts['query'], '&amp;')) {
			$_parts['query'] = str_replace('&amp;', '&', $_parts['query']);
		}

		$this->_scheme = isset ($_parts['scheme']) ? $_parts['scheme'] : null;
		$this->_user = isset ($_parts['user']) ? $_parts['user'] : null;
		$this->_pass = isset ($_parts['pass']) ? $_parts['pass'] : null;
		$this->_host = isset ($_parts['host']) ? $_parts['host'] : null;
		$this->_port = isset ($_parts['port']) ? $_parts['port'] : null;
		$this->_path = isset ($_parts['path']) ? $_parts['path'] : null;
		$this->_query = isset ($_parts['query'])? $_parts['query'] : null;
		$this->_fragment = isset ($_parts['fragment']) ? $_parts['fragment'] : null;

		if(isset ($_parts['query'])) parse_str($_parts['query'], $this->_vars);
		return $retval;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		toString
	 * Purpose:		Returns full uri string
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function toString($parts = array('scheme', 'user', 'pass', 'host', 'port', 'path', 'query', 'fragment'))
	{
		$query = $this->getQuery(); //make sure the query is created

		$uri = '';
		$uri .= in_array('scheme', $parts)  ? (!empty($this->_scheme) ? $this->_scheme.'://' : '') : '';
		$uri .= in_array('user', $parts)	? $this->_user : '';
		$uri .= in_array('pass', $parts)	? (!empty ($this->_pass) ? ':' : '') .$this->_pass. (!empty ($this->_user) ? '@' : '') : '';
		$uri .= in_array('host', $parts)	? $this->_host : '';
		$uri .= in_array('port', $parts)	? (!empty ($this->_port) ? ':' : '').$this->_port : '';
		$uri .= in_array('path', $parts)	? $this->_path : '';
		$uri .= in_array('query', $parts)	? (!empty ($query) ? '?'.$query : '') : '';
		$uri .= in_array('fragment', $parts)? (!empty ($this->_fragment) ? '#'.$this->_fragment : '') : '';

		return $uri;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setVar
	 * Purpose:		Adds a query variable, replacing if it exists
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function setVar($name, $value)
	{
		$tmp = @$this->_vars[$name];
		$this->_vars[$name] = $value;
		$this->_query = null;
		return $tmp;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getVar
	 * Purpose:		Returns a query variable by name
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function getVar($name = null, $default=null)
	{
		if(isset($this->_vars[$name])) {
			return $this->_vars[$name];
		}
		return $default;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		deltVar
	 * Purpose:		Remove a query variable if it exists
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function delVar($name)
	{
		if (in_array($name, array_keys($this->_vars)))
		{
			unset ($this->_vars[$name]);
			$this->_query = null;
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setQuery
	 * Purpose:		Sets the query to string
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function setQuery($query)
	{
		if(!is_array($query)) {
			if(strpos($query, '&amp;') !== false)
			{
			   $query = str_replace('&amp;','&',$query);
			}
			parse_str($query, $this->_vars);
		}

		if(is_array($query)) {
			$this->_vars = $query;
		}

		//empty the query
		$this->_query = null;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getQuery
	 * Purpose:		Returns flat query string
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function getQuery($toArray = false)
	{
		if($toArray) {
			return $this->_vars;
		}

		//If the query is empty build it first
		if(is_null($this->_query)) {
			$this->_query = $this->buildQuery($this->_vars);
		}

		return $this->_query;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		buildQuery
	 * Purpose:		Build a query from an array
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function buildQuery ($params, $akey = null)
	{
		if ( !is_array($params) || count($params) == 0 ) {
			return false;
		}

		$out = array();

		//reset in case we are looping
		if( !isset($akey) && !count($out) )  {
			unset($out);
			$out = array();
		}

		foreach ( $params as $key => $val )
		{
			if ( is_array($val) ) {
				$out[] = JURI::buildQuery($val,$key);
				continue;
			}

			$thekey = ( !$akey ) ? $key : $akey.'['.$key.']';
			$out[] = $thekey."=".urlencode($val);
		}

		return implode("&",$out);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getScheme
	 * Purpose:		Get the Uri scheme
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function getScheme()
	{
		return $this->_scheme;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setScheme
	 * Purpose:		Set the Uri scheme
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function setScheme($scheme)
	{
		$this->_scheme = $scheme;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getUser
	 * Purpose:		Get the Uri username
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function getUser()
	{
		return $this->_user;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setUser
	 * Purpose:		Set the Uri username
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function setUser($user)
	{
		$this->_user = $user;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getPass
	 * Purpose:		Get the Uri password
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function getPass()
	{
		return $this->_pass;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setPass
	 * Purpose:		Set the Uri password
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function setPass($pass)
	{
		$this->_pass = $pass;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getHost
	 * Purpose:		Get the Uri host
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function getHost()
	{
		return $this->_host;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setHost
	 * Purpose:		Set the Uri host
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function setHost($host)
	{
		$this->_host = $host;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getPort
	 * Purpose:		Get the Uri port
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function getPort()
	{
		return (isset ($this->_port)) ? $this->_port : null;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setPort
	 * Purpose:		Set the Uri port
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function setPort($port)
	{
		$this->_port = $port;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getPath
	 * Purpose:		Gets the Uri path string
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function getPath()
	{
		return $this->_path;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setPath
	 * Purpose:		Set the Uri path string
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function setPath($path)
	{
		$this->_path = $this->_cleanPath($path);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getFragment
	 * Purpose:		Get the Uri anchor string
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function getFragment()
	{
		return $this->_fragment;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setFragment
	 * Purpose:		Set the Uri anchor string (#)
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function setFragment($anchor)
	{
		$this->_fragment = $anchor;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		isFragment
	 * Purpose:		Returns true if uri is a fragment only
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function isFragment()
	{
		if (!is_null($this->_scheme)) return false;
		if (!is_null($this->_host)) return false;
		if (!is_null($this->_port)) return false;
		if (!is_null($this->_user)) return false;
		if (!is_null($this->_pass)) return false;
		if (!is_null($this->_path)) return false;
		if (!is_null($this->_query)) return false;
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		isSSL
	 * Purpose:		Checks whether current Uri is https
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function isSSL()
	{
		return $this->getScheme() == 'https' ? true : false;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		isInternal
	 * Purpose:		Checks if supplied url is internal
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function isInternal($url)
	{
		$uri	= & JwhmcsUri::getInstance($url);
		$base	=   $uri->toString(array('scheme', 'host', 'port', 'path'));
		$host	=   $uri->toString(array('scheme', 'host', 'port'));
		if(stripos($base, JwhmcsUri::base()) !== 0 && !empty($host)) {
			return false;
		}
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_cleanPath (private)
	 * Purpose:		Resolves //, ../ and ./ from path and returns result
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	private function _cleanPath($path)
	{
		$path = explode('/', preg_replace('#(/+)#', '/', $path));
		
		for ($i = 0; $i < count($path); $i ++) {
			if ($path[$i] == '.') {
				unset ($path[$i]);
				$path = array_values($path);
				$i --;
			}
			elseif ($path[$i] == '..' AND ($i > 1 OR ($i == 1 AND $path[0] != ''))) {
				unset ($path[$i]);
				unset ($path[$i -1]);
				$path = array_values($path);
				$i -= 2;
			}
			elseif ($path[$i] == '..' AND $i == 1 AND $path[0] == '') {
				unset ($path[$i]);
				$path = array_values($path);
				$i --;
			} else {
				continue;
			}
		}
		return implode('/', $path);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_parseURL
	 * Purpose:		parse_url wrapper
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	private function _parseURL($uri)
	{
		$parts = array();
		$parts = @parse_url($uri);
		return $parts;
	}
}