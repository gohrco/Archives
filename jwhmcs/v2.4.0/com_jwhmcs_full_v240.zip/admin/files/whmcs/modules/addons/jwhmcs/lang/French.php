<?php

$intlang = array(
		
		'shortcode'		=> 'fr',
		
		'cfg_name'		=> 'J!WHMCS Integrator',
		'cfg_desc'		=> 'This module integates your WHMCS application with Joomla',
		
		'loginemail'	=> "Nom d'utilisateur",
		
		'AUTH00P000'	=> "Aucun mot de passe a été fourni!",	
		'AUTH00P001'	=> "Votre compte ne peut être affichée en ce moment.",
		'AUTH01P000'	=> "Impossible de mettre les paramètres de votre compte en ligne!",	
		'AUTH01P001'	=> "Connectez-vous refusé! Votre compte a été bloqué ou soit vous ne l'avez pas encore activé. N'avez-vous pas obtenir une activation e-mail et suivez le lien de validation?",
		'AUTH01P002'	=> "Nom d'utilisateur ou mot de passe est incorrect ou vous n'avez pas encore de compte.",
		'AUTH01P003'	=> "Impossible de mettre les paramètres de votre compte en ligne!",
		'AUTH01P004'	=> "Connectez-vous refusé! Votre compte a été bloqué ou soit vous ne l'avez pas encore activé. N'avez-vous pas obtenir une activation e-mail et suivez le lien de validation?",
		'AUTH01P010'	=> "Nom d'utilisateur ou mot de passe est incorrect ou vous n'avez pas encore de compte.",
		'AUTH01P011'	=> "Nom d'utilisateur ou mot de passe est incorrect ou vous n'avez pas encore de compte.",
		'AUTH01P021'	=> "Il y avait un problème de liaison paramètres de votre compte!",
		'AUTH01P022'	=> "Il y avait un problème de sauvegarde des paramètres de votre compte!",
		'AUTH01P023'	=> "Il y avait un problème de liaison paramètres de votre compte!",
		'AUTH01P024'	=> "Il y avait un problème de sauvegarde des paramètres de votre compte!",
		'AUTH02P000'	=> "Impossible de mettre les paramètres de votre compte en ligne!",
		'AUTH02P001'	=> "Connectez-vous refusé! Votre compte est inactif ou a été bloquée.",
		'AUTH02P002'	=> "Nom d'utilisateur ou mot de passe est incorrect ou vous n'avez pas encore de compte.",
		'AUTH02P010'	=> "Nom d'utilisateur ou mot de passe est incorrect ou vous n'avez pas encore de compte.",
		'AUTH02P011'	=> "Nom d'utilisateur ou mot de passe est incorrect ou vous n'avez pas encore de compte."
);