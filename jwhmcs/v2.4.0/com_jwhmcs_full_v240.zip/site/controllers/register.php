<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    ${p.PROJECT_LICJOOMLA}
 * @version    2.4.0 ( $Id: register.php 469 2012-05-04 20:04:56Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      2.1.0
 * 
 * @desc       This file contains the register controller class allowing the system to intereact with the data based upon actions
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * Register controller handles data input for user registration
 * @version	2.3.0
 * 
 * @since	2.1.0
 * @author	Steven
 */
class JwhmcsControllerRegister extends JwhmcsController
{
	/**
	 * Contructor
	 * @access	public
	 * @version	2.3.0
	 * 
	 * @since	2.1.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Task to handle validated form data from user input
	 * @access	public
	 * @version	2.3.0
	 * 
	 * @since	1.5.0
	 */
	public function save()
	{
		$app		= & JFactory::getApplication();
		$params		= & JwhmcsParams::getInstance();
		$fromjwhmcs =   JwhmcsHelper :: get( 'fromjwhmcs', false );
		
		// Check for request forgeries
		if (! $fromjwhmcs) {// if this variable exists, then we are probably coming from the jwhmcs root file
			JwhmcsHelper :: checkToken() or jexit( "Invalid Token" );
		}
		elseif ( $fromjwhmcs == $params->get( "Secret" ) ) {
			define('JWHMCS_AUTH', true); // Set so we don't try to add the new user to WHMCS
		}
		else {
			jexit( "Invalid Token" );
		}
		
		// Get required system objects
		$model		=   $this->getModel();
		$user 		=   clone(JFactory::getUser());
		$pathway 	= & $app->getPathway();
		$config		= & JFactory::getConfig();
		$authorize	= & JFactory::getACL();
		$document   = & JFactory::getDocument();
		$session	= & JFactory::getSession();
		$jcurl		= & JwhmcsCurl::getInstance();
		$db			= & JFactory::getDBO();
		$date		= & JFactory::getDate();
		
		
		/* reCaptcha if option set */
		if ( (! $fromjwhmcs ) && ( $params->get( 'RecaptchaEnable' ) ) )
		{
			require_once(JPATH_COMPONENT.DS.'recaptchalib.php');
			
			$privatekey = $params->get( 'RecaptchaPrivatekey' );
			
			$resp = recaptcha_check_answer ($privatekey,
                                $_SERVER["REMOTE_ADDR"],
                                JwhmcsHelper :: get( 'recaptcha_challenge_field' ),
                                JwhmcsHelper :: get( 'recaptcha_response_field' ) );
			
			if (!$resp->is_valid) {
				JError::raiseWarning( 200, JText::_( $resp->error ) );
				JwhmcsHelper :: set( 'view', 'register' );
				parent::display();
				return;
			}
		}
		
		// If user registration is not allowed, show 403 not authorized.
		$usersConfig = & JComponentHelper::getParams( 'com_users' );
		if ($usersConfig->get('allowUserRegistration') == '0') {
			if ($fromjwhmcs)
				$this->_stop('result=failed;error='.JText::_( 'Access Forbidden'));
			else
				JError::raiseError( 403, JText::_( 'Access Forbidden' ));
			return;
		}
		
		// ===================================================================
		// Coming from WHMCS during so we somehow are checking to see to match
		if ( ( $userid = $this->_checkEmail( $ubind['email'] ) ) && ( $fromjwhmcs ) ) {
			if ( $params->get( 'JuserEmailsync' ) ) {
				$this->_stop('result=success;existing=1;userid='.$userid);
			}
			else {
				$this->_stop('result=failed;error='.JText::_( "Email address already in use" ));
			}
		}
		// ===================================================================
		
		
		// Build the user array for binding
		$ubind = JwhmcsHelper::getUserArray( "joomla" );
		
		// Initialize new usertype setting
		$newUsertype = $usersConfig->get( 'new_usertype' );
		
		// If user activation is turned on, we need to set the activation information
		$useractivation = (int) ( ( $fromjwhmcs  AND ( $params->get( 'JuserAuthorize' ) == "0" ) ) ? 0 : $usersConfig->get( "useractivation" ) );
		
		// ============================================
		// Joomla 2.5 Handles some stuff before binding
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) )
		{	// Set J2.5 new user type if not in config file
			if (! $newUsertype ) $newUsertype = 2;
			
			// Add to bind array
			$ubind['groups'][] = $newUsertype;
			
			// Check if the user needs to activate their account.
			// 1 = self; 2 = admin approval
			if (($useractivation == 1) || ($useractivation == 2)) {
				jimport('joomla.user.helper');
				$ubind['activation'] = JUtility::getHash(JUserHelper::genRandomPassword());
				$ubind['block'] = 1;
			}
		}
		else 
		{	// Don't forget to set J1.5 user types if not in config file
			if (! $newUsertype ) $newUsertype = 'Registered';
		}
		// ============================================
		// ------BIND ARRAY----------------------
		// ======================================
		// Bind the post array to the user object
		if (!$user->bind( $ubind, 'usertype' )) {
			if( $fromjwhmcs )
				$this->_stop('result=failed;error='.JText::_( $user->getError()));
			else
				JError::raiseError( 500, $user->getError());
		}
		// ======================================
		// -----------------------------------------
		// ===========================================
		// Joomla 1.5 Handles some stuff after binding
		if (! version_compare( JVERSION, '1.6.0', 'ge' ) )
		{
			$user->set('id', 0);
			$user->set('usertype', '');
			$user->set('gid', $authorize->get_group_id( '', $newUsertype, 'ARO' ));
			$user->set( 'registerDate', $date->toMySQL() );
			
			// Dont send welcome email by default
			$sendEmail = false;
			if ( $useractivation == '1' ) {
				jimport('joomla.user.helper');
				$user->set( 'activation', JUtility::getHash( JUserHelper::genRandomPassword() ) );
				$user->set( 'block', '1' );
				$sendEmail = true;
			}
		}
		// ===========================================
		
		// Load the users plugin group.
		JPluginHelper::importPlugin('user');
		
		// If there was an error with registration, set the message and display form
		if ( !$user->save() ) {
			if ($fromjwhmcs)
				$this->_stop('result=failed;error='.JText::_( $user->getError()));
			else {
				JError::raiseWarning('', JText::_( $user->getError()));
				$user 	= & JFactory::getUser();
				
				if ( $user->get('guest')) {
					JwhmcsHelper :: set( 'view', 'register' );
					parent::display();
					return;
				}
				else {
					$this->setRedirect('index.php?option=com_jwhmcs&controller=register',JText::_('You are already registered.'));
				}
			}
			return false;
		}
		
		$notify	= ( $fromjwhmcs  AND ( $params->get( 'JuserAuthorize' ) == "0" ) ) ? false : $useractivation;
		
		$data = $user->getProperties();
		$data['fromname']	= $config->get('fromname');
		$data['mailfrom']	= $config->get('mailfrom');
		$data['sitename']	= $config->get('sitename');
		$data['siteurl']	= JUri::base();
		
		$lang	=   JFactory::getLanguage();
		$lang->load( 'com_users', JPATH_ADMINISTRATOR );
		
		switch ( $notify ):
		case '2':
			
			// Set the link to confirm the user email.
			$uri = JURI::getInstance();
			$base = $uri->toString(array('scheme', 'user', 'pass', 'host', 'port'));
			$data['activate'] = $base.JRoute::_('index.php?option=com_users&task=registration.activate&token='.$data['activation'], false);

			$emailSubject	= JText::sprintf(
				'COM_JWHMCS_EMAIL_ACCOUNT_DETAILS',
				$data['name'],
				$data['sitename']
			);

			$emailBody = JText::sprintf(
				'COM_JWHMCS_EMAIL_REGISTERED_WITH_ADMIN_ACTIVATION_BODY',
				$data['name'],
				$data['sitename'],
				$data['siteurl'].'index.php?option=com_users&task=registration.activate&token='.$data['activation'],
				$data['siteurl'],
				$data['username'],
				$ubind['password']
			);
			
			break;
		
		case '1':
			
			// Set the link to activate the user account.
			$uri = JURI::getInstance();
			$base = $uri->toString(array('scheme', 'user', 'pass', 'host', 'port'));
			$data['activate'] = $base.JRoute::_('index.php?option=com_users&task=registration.activate&token='.$data['activation'], false);

			$emailSubject	= JText::sprintf(
				'COM_JWHMCS_EMAIL_ACCOUNT_DETAILS',
				$data['name'],
				$data['sitename']
			);

			$emailBody = JText::sprintf(
				'COM_JWHMCS_EMAIL_REGISTERED_WITH_ACTIVATION_BODY',
				$data['name'],
				$data['sitename'],
				$data['siteurl'].'index.php?option=com_users&task=registration.activate&token='.$data['activation'],
				$data['siteurl'],
				$data['username'],
				$ubind['password']
			);
			
			break;
		
		case '0':
			
			$emailSubject	= JText::sprintf(
				'COM_JWHMCS_EMAIL_ACCOUNT_DETAILS',
				$data['name'],
				$data['sitename']
			);

			$emailBody = JText::sprintf(
				'COM_JWHMCS_EMAIL_REGISTERED_BODY',
				$data['name'],
				$data['sitename'],
				$data['siteurl']
			);
			
			break;
			
		endswitch;
		
		// Send the registration email.
		$return = JwhmcsHelper :: sendMail( $data['mailfrom'], $data['fromname'], $data['email'], $emailSubject, $emailBody );
		
		// Everything went fine, set relevant message depending upon user activation state and display message
		if ( $useractivation == 1 ) {
			$message  = JText::_( "COM_JWHMCS_REGISTER_CTRL_COMPLETEACTIVATE" );
		} else {
			$message = JText::_( "COM_JWHMCS_REGISTER_CTRL_COMPLETE" );
		}
		
		if ($fromjwhmcs)
			$this->_stop('result=success;userid='.$user->id);
		else
			$this->setRedirect( 'index.php', $message);
	}
	
	
	/**
	 * Validate info sent by the registration form prior to submittal
	 * @access	public
	 * @version	2.3.0
	 * 
	 * @since	2.1.0
	 */
	public function validInfo()
	{
		$app		= & JFactory::getApplication();
		$type		=   ( ( $type = JwhmcsHelper :: get( 'type' ) ) ? $type : JwhmcsHelper :: get( 'token' ) );
		$value		=   ( ( $value = JwhmcsHelper :: get( 'value' ) ) ? $value : JwhmcsHelper :: get( 'jwhmcs' ) );
		$model		= & $this->getModel( 'register' );
		$result		= & $model->validInfo( $type, $value );
		
		foreach ($result as $k => $v) $data[$k] = $v;
		echo $model->buildResponse($data);
		$app->close();
	}
	
	
	/**
	 * Checks to see if an email address is being used
	 * @access	private
	 * @version	2.3.0
	 * @param	string		$email - the email address to check for
	 * 
	 * @return	True if exists, false if not
	 * @since	2.1.2
	 */
	private function _checkEmail( $email )
	{
		$db = & JFactory::getDBO();
		$email = trim( $email );
		$query	= "SELECT u.id FROM #__users u WHERE email = '{$email}'";
		$db->setQuery( $query );
		$result = $db->loadResult();
		
		return ( $result ? $result : false );
	}
}
	