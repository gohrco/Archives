<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    ${p.PROJECT_LICJOOMLA}
 * @version    2.4.0 ( $Id: controller.php 469 2012-05-04 20:04:56Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.5.0
 * 
 * @desc       Controller File:  Primary controller file used for default view
 *  
 */

jimport('joomla.application.component.controller');

/**
 * JwhmcsController class
 * @version		2.4.0
 * 
 * @since		1.5.0
 * @author		Steven
 */
class JwhmcsController extends JController
{
	/**
	 * Overrides and displays the default view to the front end user
	 * @access		public
	 * @version		2.4.0
	 * 
	 * @since		1.5.0
	 * @see			JController::display()
	 */
	public function display()
	{
		// If the view hasn't been set, set it to default
		if (is_null(JwhmcsHelper :: get( 'view'))) JwhmcsHelper :: set('view', 'default' );
		parent::display();
	}
	
	
	/**
	 * Retrieves a session storedin the database from the token passed along
	 * @access		protected
	 * @version		2.4.0
	 * @deprecated	by JwhmcsHelper::getSession since 2.3.0
	 * @param		string		- $token: contains the token stored in database
	 * 
	 * @return 		array containing database fields
	 * @since		1.5.0
	 */
	protected function _getSess($token)
	{
		$db =& JFactory::getDBO();
		$query = 'SELECT `value` FROM #__jwhmcs_sess WHERE token="'.$token.'"';
		$db->setQuery($query);
		$result = $db->loadResult();
		
		$tmp = preg_split('/\n/', $result);
		foreach ($tmp as $t)
		{
			$var = explode('=', $t);
			$k = $var[0];
			unset($var[0]);
			$ubind[$k] = implode("=", $var);
			unset($var, $k);
		}
		
		$query = 'DELETE FROM #__jwhmcs_sess WHERE token="'.$token.'"';
		$db->setQuery($query);
		$res = $db->query();
		
		return $ubind;
	}
	
	
	/**
	 * Stops the Joomla application outputting a message to browser
	 * @access		protected
	 * @version		2.4.0
	 * @deprecated	not used in base class; moved to ajax handler
	 * @param		string		- $msg: contains the message to output
	 * 
	 * @since		1.5.0
	 */
	protected function _stop($msg = '')
	{
		$app = & JFactory::getApplication();
		echo $msg;
		$app->close();
	}
}
?>
