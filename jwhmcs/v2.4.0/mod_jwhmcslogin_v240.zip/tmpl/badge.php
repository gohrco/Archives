<?php if ( $params->get( 'grav_style', true ) ) : ?>
<div class='jwhmcslogin-badge'>
	<div style="padding: 2px; text-align: center; width: <?php echo $params->get( 'grav_size', '60' ); ?>px; float: left;" >
		<?php echo $jwhmcs->avatar['url']; ?><br/>
		<small><small><a href="<?php echo $jwhmcs->avatar['option']; ?>" title="<?php echo JText::sprintf( 'MOD_JWHMCSLOGIN_BADGE_GRAV_ENTITL', ( $jwhmcs->avatar['enabled'] ? JText::_( 'MOD_JWHMCSLOGIN_BADGE_GRAV_DISABLE' ) : JText::_( 'MOD_JWHMCSLOGIN_BADGE_GRAV_ENABLE' ) ) ) ; ?>" ><?php echo strtolower( ( $jwhmcs->avatar['enabled'] ? JText::_( 'MOD_JWHMCSLOGIN_BADGE_GRAV_DISABLE' ) : JText::_( 'MOD_JWHMCSLOGIN_BADGE_GRAV_ENABLE' ) ) ); ?></a></small></small>
	</div>
	<div style="margin: 0 0 0 -<?php echo ( $params->get( 'grav_size', '60' ) - 4 ); ?>px; padding: 2px 0 2px <?php echo ( $params->get( 'grav_size', '60' ) + 2 ); ?>px; width: 100%; ">
		<strong><?php echo $jwhmcs->firstname.' '.$jwhmcs->lastname.(empty($jwhmcs->companyname) ? '' : '<br />'.$jwhmcs->companyname ); ?></strong><br />
		<small><?php echo $jwhmcs->email; ?></small><br />
	</div>
	<div class="jwhmcs-imgs" style="clear: both; text-align: center; ">
		<?php if (! $contact ): ?>
		<?php if ( $params->get( "displaycredit", "0" ) ):?>
		Current Credit: <?php echo $params->get( "displaycreditsymbol", "$" ); ?>&nbsp;<?php echo $jwhmcs->credit; ?><br />
		<?php endif; ?>
		<a href="<?php echo $jwhmcs->clienturl; ?>/clientarea.php?action=details" title="<?php echo JText::_('MOD_JWHMCSLOGIN_BADGE_UPDATE_YOUR_DETAILS'); ?>"><img src="<?php echo $jwhmcs->clienturl; ?>/images/details.gif" border="0" hspace="5" align="absmiddle" alt="<?php echo JText::_('MOD_JWHMCSLOGIN_BADGE_UPDATE_YOUR_DETAILS'); ?>" /></a>
		<?php if ($params->get( 'addfunds' )): ?>
			<a href="<?php echo $jwhmcs->clienturl; ?>/clientarea.php?action=addfunds" title="<?php echo JText::_( 'MOD_JWHMCSLOGIN_BADGE_ADD_FUNDS' ); ?>"><img src="<?php echo $jwhmcs->clienturl; ?>/images/affiliates.gif" border="0" align="absmiddle" alt="<?php echo JText::_( 'MOD_JWHMCSLOGIN_BADGE_ADD_FUNDS' ); ?>" /></a>
		<?php endif; ?>
		<a href="<?php echo $jwhmcs->clienturl; ?>/jwhmcs.php?task=ulogout" title="<?php echo JText::_('MOD_JWHMCSLOGIN_BADGE_LOGOUT'); ?>" ><img src="<?php echo $jwhmcs->clienturl; ?>/images/logout.gif" border="0" hspace="5" align="absmiddle" alt="<?php echo JText::_('MOD_JWHMCSLOGIN_BADGE_LOGOUT'); ?>" /></a>
		<?php endif; ?>
	</div>
</div>

<?php else : ?>

<table width="100%" class="jwhmcslogin-badge" cellspacing="1">
	<tr class="jwhmcslogin-clientareatableactive">
		<td style="padding: 2px; width: <?php echo $params->get( 'grav_size', '60' ); ?>px; ">
			<?php echo $jwhmcs->avatar['url']; ?><br/>
			<small><small><a href="<?php echo $jwhmcs->avatar['option']; ?>" title="<?php echo JText::sprintf( 'MOD_JWHMCSLOGIN_BADGE_GRAV_ENTITL', ( $jwhmcs->avatar['enabled'] ? JText::_( 'MOD_JWHMCSLOGIN_BADGE_GRAV_DISABLE' ) : JText::_( 'MOD_JWHMCSLOGIN_BADGE_GRAV_ENABLE' ) ) ) ; ?>" ><?php echo strtolower( ( $jwhmcs->avatar['enabled'] ? JText::_( 'MOD_JWHMCSLOGIN_BADGE_GRAV_DISABLE' ) : JText::_( 'MOD_JWHMCSLOGIN_BADGE_GRAV_ENABLE' ) ) ); ?></a></small></small>
		</td>
		<td style="padding: 5px; ">
			<strong><?php echo $jwhmcs->firstname.' '.$jwhmcs->lastname.(empty($jwhmcs->companyname) ? '' : '<br />'.$jwhmcs->companyname ); ?></strong><br />
			<?php echo $jwhmcs->email; ?><br />
			<?php if (! $contact ): ?>
			<?php if ( $params->get( "displaycredit", "0" ) ):?>
			Current Credit: <?php echo $params->get( "displaycreditsymbol", "$" ); ?>&nbsp;<?php echo $jwhmcs->credit; ?><br />
			<?php endif; ?>
			<a href="<?php echo $jwhmcs->clienturl; ?>/clientarea.php?action=details" title="<?php echo JText::_('MOD_JWHMCSLOGIN_BADGE_UPDATE_YOUR_DETAILS'); ?>"><img src="<?php echo $jwhmcs->clienturl; ?>/images/details.gif" border="0" hspace="5" align="absmiddle" alt="<?php echo JText::_('MOD_JWHMCSLOGIN_BADGE_UPDATE_YOUR_DETAILS'); ?>" /></a>
			<?php if ($params->get( 'addfunds' )): ?>
				<a href="<?php echo $jwhmcs->clienturl; ?>/clientarea.php?action=addfunds" title="<?php echo JText::_( 'MOD_JWHMCSLOGIN_BADGE_ADD_FUNDS' ); ?>"><img src="<?php echo $jwhmcs->clienturl; ?>/images/affiliates.gif" border="0" align="absmiddle" alt="<?php echo JText::_( 'MOD_JWHMCSLOGIN_BADGE_ADD_FUNDS' ); ?>" /></a>
			<?php endif; ?>
			<a href="<?php echo $jwhmcs->clienturl; ?>/jwhmcs.php?task=ulogout" title="<?php echo JText::_('MOD_JWHMCSLOGIN_BADGE_LOGOUT'); ?>" ><img src="<?php echo $jwhmcs->clienturl; ?>/images/logout.gif" border="0" hspace="5" align="absmiddle" alt="<?php echo JText::_('MOD_JWHMCSLOGIN_BADGE_LOGOUT'); ?>" /></a>
			<?php endif; ?>
		</td>
	</tr>
</table>

<?php endif; ?>