function myValidate(f) {
        if (document.formvalidator.isValid(f)) {
                return true; 
        }
        else {
                alert('Some values are not acceptable.  Please retry.');
        }
        return false;
}

function submitbutton(pressbutton) {
	var form = document.adminForm;

	if (pressbutton == 'cancel') {
		submitform( pressbutton );
		return;
	}

	if (myValidate(form) == true) {
		submitform( pressbutton );
	}
	
}