<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.4.5 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.4..0
 * 
 * @desc       This is the default layout for the updates view file for the backend of J!WHMCS Integrator
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusion --*/
JHtml::_('behavior.tooltip');
/*-- File Inclusion --*/

$cycle	= array( 'component' => JText :: _( 'COM_JWHMCS_UPDATES_HEADING_COMPONENT' ), 'file' => JText :: _( 'COM_JWHMCS_UPDATES_HEADING_EXTERNALFILES' ), 'module' => JText :: _( 'COM_JWHMCS_UPDATES_HEADING_MODULES' ), 'plugin' => JText :: _( 'COM_JWHMCS_UPDATES_HEADING_PLUGINS' ) );
$count	= ( 4 + count( $this->updates['component'] ) + count( $this->updates['module'] ) + count( $this->updates['file'] ) + count( $this->updates['plugin'] ) );

// Set link / img
$img	= JURI::root().'media/com_jwhmcs/icons/' . ( $this->updates['action'] === true ? 'update-48' : ( $this->updates['action'] === false ? 'accept-48' : 'fail-48' ) ) . '.png';
$link	= ( $this->updates['action'] === true ? JRoute :: _( 'index.php?option=com_jwhmcs&controller=updates&task=begin' ) : '#' );
$axn	= JText :: _( 'COM_JWHMCS_UPDATES_LINK_' . ( $this->updates['action'] === true ? 'UPDATE' : ( $this->updates['action'] === false ? 'NOTHING' : 'ERROR' ) ) );
?>
<form action="<?php echo JRoute::_('index.php?option=com_jwhmcs'); ?>" method="post" name="adminForm">
	<table class="adminlist">
		
	<!-- BEGIN BODY -->
	
	<tbody>
		<?php foreach( $cycle as $group => $heading ) : ?>
		<tr>
			<td width="80%" colspan="2" align="left" valign="top" style="border-color: #888; border-width: 0 0 1px 0; ">
				<h2 style="padding: 0pt 0pt 4px; margin: 10px 0pt 0pt; ">
					<?php echo $heading; ?>
				</h2>
			</td>
			<?php if ( $link ) : ?>
			<td rowspan="<?php echo $count; ?>" align="center" valign="top">
				<div id="cpanel" style="clear: both; width: 135px; margin: 0 auto; padding-top: 50px; ">
					<div style="float: left; ">
						<div style="float: left; ">
							<div class="icon">
								<a href="<?php echo $link; ?>">
									<img
										src="<?php echo $img; ?>"
										border="0" alt="<?php echo $$axn; ?>" />
									<span><?php echo $axn; ?></span>
								</a>
							</div>
						</div>
					</div>
				</div>
			</td>
			<?php $link = false; ?>
			<?php endif; ?>
		</tr>
		<?php foreach ( $this->updates[$group] as $item ) : ?>
		<tr>
			<td width="40%" align="left" valign="middle">
				<h3><?php echo $item['name']; ?></h3>
			</td>
			<td width="40%" align="center" valign="middle">
				<h3><?php echo $item['version']; ?></h3>
			</td>
		</tr>
		<?php endforeach; ?>
		<?php endforeach; ?>
		
	</tbody>
	
	<!-- END BODY -->
	<!-- BEGIN HEADER -->
	
	<thead>
		
		<tr>
			<th>
				<?php echo JText::_( 'COM_JWHMCS_UPDATES_HEADING_EXTNAME' ); ?>
			</th>
			<th>
				<?php echo JText::_( 'COM_JWHMCS_UPDATES_HEADING_VERSION' ); ?>
			</th>
			<th>
				&nbsp;
			</th>
		</tr>
		
	</thead>
	
	<!-- END HEADER -->
	<!-- BEGIN FOOTER -->
	
	<tfoot>
		
		<tr>
			<td colspan="3">&nbsp;</td>
		</tr>
		
	</tfoot>
	
	<!-- END FOOTER -->
		
	</table>
	<div>
		<input type="hidden" name="task" value="updates.begin" />
		<?php echo JHtml::_( 'form.token' ); ?>
	</div>
</form>