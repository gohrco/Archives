<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 		API Render File
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.6.00 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.5.0
 *
 * @desc       This is the Render Task for the J!WHMCS Integrator API
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Ping Jwhmcs API Class
 * @version		2.6.00
 *
 * @since		2.5.0
 * @author		Steven
 */
class RenderJwhmcsAPI extends JwhmcsAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		2.6.00
	 * 
	 * @return		false
	 * @since		2.5.0
	 * @see			JwhmcsAPI :: execute()
	 */
	public function execute()
	{
		$db		=	dunloader( 'database', true );
		$input	=	dunloader( 'input', true );
		$status	=	$input->getVar( 'isloggedin', false );
		
		// If we should be logged in
		if ( $status ) {
			
			// ---- BEGIN JWHMCS-29
			//		Rendering fails if the user doesn't exist in Joomla yet
			// See if we have a user first
			if ( JFactory :: getUser()->guest ) {
				$query	=	"SELECT `id` FROM `#__users` WHERE `email` = " . $db->Quote( $input->getVar( 'useremail', null ) ) . " LIMIT 1";
				$db->setQuery( $query );
				$userid	=	$db->loadResult();
			}
			
			// Check the user to see if this is our first run through
			if ( JFactory :: getUser()->guest && $userid ) {
				// ---- END JWHMCS-29
				
				// Grab the user
				$instance	=	JUser::getInstance();
				$instance->load( $userid );
				$instance->set( 'guest', 0 );
				
				// Set the user into the session
				$session	=	JFactory :: getSession();
				$session->set( 'user', $instance );
				
				// Clean up the session
				$app		=	JFactory :: getApplication();
				$app->checkSession();
				
				// Attach this user to the session table
				$query	=	"UPDATE `#__session` SET `guest` = '0', `username` = "
						.	$db->Quote( $instance->get( 'username' ) ) . ", `userid` = "
						.	$db->Quote( $instance->get( 'id' ) ) . " WHERE `session_id` = "
						.	$db->Quote( $session->getId() );
				
				$db->setQuery( $query );
				$db->query();
				
				
				// --------------------------------------------------------------
				// Redirect to ourselves to have the user catch at initialization
				// --------------------------------------------------------------
				$document	=	JFactory :: getDocument();
				$signature	=	(string) plgSystemJwhmcs_sysm :: generateSignature();
				
				$uri	=	DunUri :: getInstance( 'SERVER', true );
				$uri->setVar( 'apisignature', rawurlencode( $signature ) );
				
				// If curl isnt able to follow redirects then we must not try to set a cookie and redirect, just bail
				if ( ! ini_get('safe_mode') && ! ini_get('open_basedir')) {
					
					// We will do our own redirection thank you very much
					header( 'JwhmcsRequestSignature: ' . rawurlencode( $signature ) );
					header( 'HTTP/1.1 303 See other' );
					header( 'Location: ' . $uri->toString() );
					header( 'Content-Type: text/html; charset=' . $document->getCharset() );
					
					// Close cleanly
					$app->close();
				}
			}
		}
		
		// Attach our render and route handlers to ensure we get fired last
		$dispatcher	=	JDispatcher :: getInstance();
		$dispatcher->register( 'onBeforeRender', 'RenderJwhmcsAPIPlugin' );
		$dispatcher->register( 'onAfterRoute', 'RenderJwhmcsAPIPlugin' );
		return false;
	}
}


/**
 * Render Plugin Class
 * @desc		This class is only attached to the disptacher object if we are called
 * 				through the API handler and have met all the requirements to do so.
 * @version		2.6.00
 * 
 * @author		Steven
 * @since		2.5.0
 */
class RenderJwhmcsAPIPlugin extends JPlugin
{
	/**
	 * System Event Handler: onBeforeRender
	 * @desc		Intercepts the rendering prior to actually outputing to browser
	 * 				and parses the content, encodes it into base64 code and returns
	 * 				a json formatted string
	 * @access		public
	 * @version		2.6.00 ( $id$ )
	 *
	 * @since		2.5.0
	 */
	public function onBeforeRender()
	{
		$app		=	JFactory :: getApplication();
		$session	=	JFactory :: getSession();
		$doc		=	JFactory :: getDocument();
		$input		=	dunloader( 'input', true );
		$config		=	dunloader( 'config', 'com_jwhmcs' );
		
		// Grab the template and build the parameters
		$template	=	$app->getTemplate(true);
		
		$params	=	array(
			'template'	=>	$app->getTemplate(),
			'file'		=>	'index.php',
			'directory'	=>	JPATH_THEMES,
			'params'	=>	$template->params
			);
		
		// ---- BEGIN JWHMCS-9
		//		Some templates are rendering links / js twice
		/* $doc->parse($params); */
		// ---- END JWHMCS-9
		
		// Render the template
		$html = $doc->render( false, $params );
		
		// Perform some initial regexes on the whole data
		if ( $input->getVar( 'lang', false, 'string', 'get' ) && ( $langrev = $input->getVar( 'langrev', false, 'string', 'get' ) ) ) {
			// Find WHMCS URLs and affix the language to them
			$whmcsurl	=	$config->get( 'whmcsurl', null );
			$whmcsuri	=	DunUri :: getInstance( $whmcsurl, true );
			$whmcsurl	=	preg_quote( $whmcsuri->toString( array( 'user', 'pass', 'host', 'port', 'path', 'query', 'fragment' ) ), '#' );
			$regex		=	'#<a[^>]+([\"\']+)(?P<link>http(?:s|)\://' . $whmcsurl . '[^\1>]*)\1[^>]*>#im';
			
			preg_match_all( $regex, $html, $matches, PREG_SET_ORDER );
			
			foreach ( $matches as $match ) {
				$uri	=	DunUri :: getInstance( $match['link'], true );
				$uri->setVar( 'language', $langrev );
				$repl	=	str_replace( $match['link'], $uri->toString(), $match[0] );
				$html	=	str_replace( $match[0], $repl, $html );
			}
		}
		
		// Lets fix any login forms people insist on using
		$whmcsurl	=	$config->get( 'whmcsurl', null );
		$whmcsuri	=	DunUri :: getInstance( $whmcsurl, true );
		$whmcsuri->setScheme( 'http' . ( $input->getVar( 'isssl', false ) ? 's' : '' ) );
		
		$regex		=	'#(?><form)[^>]+?action=[\"|\']+(?P<link>[^\"|\']+)[\"|\']+[^>]*>.*?(?></form>)#ims';
		preg_match_all( $regex, $html, $matches, PREG_SET_ORDER );
		foreach ( $matches as $match )
		{
			// Replace log in actions
			if ( preg_match( '#<input[^>]+[\"|\']+com_users[^>]+>#im', $match[0] ) && preg_match( '#<input[^>]+[\"|\']+user\.login[^>]+>#im', $match[0] ) ) {
				$whmcsuri->setPath( rtrim( $whmcsuri->getPath(), '/' ) . '/dologin.php' );
				$match['fix']	=	str_replace( $match['link'], $whmcsuri->toString(), $match[0] );
				$html			=	str_replace( $match[0], $match['fix'], $html );
			}
			
			// Replace log out actions
			if ( preg_match( '#<input[^>]+[\"|\']+com_users[^>]+>#im', $match[0] ) && preg_match( '#<input[^>]+[\"|\']+user\.logout[^>]+>#im', $match[0] ) ) {
				$whmcsuri->setPath( rtrim( $whmcsuri->getPath(), '/' ) . '/logout.php' );
				$match['fix']	=	str_replace( $match['link'], $whmcsuri->toString(), $match[0] );
				$html			=	str_replace( $match[0], $match['fix'], $html );
			}
		}
		
		// Blow em up
		$parts	=	explode( '<jwhmcs />', $html );
		
		// Backup explosion
		if ( count( $parts ) < 2 ) {
			$parts	=	explode( '<!-- J!WHMCS -->', $html );
		}
		
		// Lets see if we have a content header
		$headsig	=	(string) rawurldecode( $input->getVar( 'HTTP_JWHMCSREQUESTSIGNATURE', false, 'STRING', 'server' ) );
		
		// If we are debugging and we aren't coming from WHMCS echo the page back out
		if ( $config->get( 'debug' ) && ! $headsig ) {
			$session->destroy();
			$content	=	(string) implode( '', $parts );
			exit( $content );
		}
		
		// Encode the parts 
		$hdr	=	base64_encode( array_shift( $parts ) );
		$ftr	=	base64_encode( array_pop( $parts ) );
		$string	=	json_encode( array( 'result' => 'success', 'htmlheader' => $hdr, 'htmlfooter' => $ftr ) );
		
		// Remove user and session
		$session->destroy();
		exit( $string );
	}
	
	
	/**
	 * System Event Handler: onAfterRoute
	 * @desc		After the system has parsed the route, J!WHMCS goes in and forces
	 * 				it's own component items into place.  This permits us to no longer
	 * 				parse the content for the menu item and makes menu item selection
	 * 				more intuitive
	 * @access		public
	 * @version		2.6.00 ( $id$ )
	 *
	 * @since		2.5.0
	 */
	public function onAfterRoute()
	{
		$input	=	dunloader( 'input', true );
		$input->setVar( 'option', 'com_jwhmcs', 'get', true );
		$input->setVar( 'view', 'default', 'get', true );
	}
}