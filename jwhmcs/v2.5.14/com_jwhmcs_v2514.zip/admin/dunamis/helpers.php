<?php


/**
 * Function for building a full name based on the WHMCS user data
 * @version		2.5.14 ( $id )
 * @param		array		- $user: the user array from WHMCS to use
 *
 * @return		string
 * @since		2.5.0
 */
if (! function_exists( 'build_fullname' ) ) {
function build_fullname( $user )
{
	$user	=	(object) $user;
	$name	=	"{$user->firstname} {$user->lastname}";
	
	return $name;
}
}

/**
 * Function for building a username based on JWHMCS settings
 * @version		2.5.14 ( $id )
 * @param		array		- $user: the user array from WHMCS to use
 *
 * @return		string
 * @since		2.5.0
 */
if (! function_exists( 'build_username' ) ) {
	function build_username( $user )
	{
		$user	=	(object) $user;
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		$input	=	dunloader( 'input', true );
		$name	=	null;
		
		switch ( $config->get( 'useraddusernamepattern', 1 ) ) :
		// Create the username as `firstname.lastname`
		case '0' :
			$name	=	"{$user->firstname}.{$user->lastname}";
		break;
		// Create the username as `lastname.firstname`
		case '1' :
			$name	=	"{$user->lastname}.{$user->firstname}";
			break;
			// Create the username as `random`
		default :
		case '2' :
			for ($i=0; $i<12; $i++) {
				$d = rand(1,30)%2;
				$name	.=	( $d ? chr(rand(65,90)) : chr(rand(48,57)));
			}
			$name	=	ucfirst(strtolower($user));
			break;
			// Create the username as `f.lastname`
		case '4' :
			$name	=	substr($user->firstname, 0, 1).".{$user->lastname}";
			break;
			// Create the username as `firstname.l`
		case '8' :
			$name	=	"{$user->firstname}.".substr($user->lastname, 0, 1);
			break;
			// Create the username as `firstname`
		case '16' :
			$name	=	"{$user->firstname}";
			break;
			// Create the username as `lastname`
		case '32' :
			$name	=	"{$user->lastname}";
			break;
			// Create the username as their email address
		case '64' :
			$name	=	"{$user->email}";
			break;
		endswitch;
		

		return $name;
	}
}