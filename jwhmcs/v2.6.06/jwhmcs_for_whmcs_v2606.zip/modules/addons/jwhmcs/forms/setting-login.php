<?php //00950
/**
 * ---------------------------------------------------------------------
 * J!WHMCS Integrator v2.6.06
 * ---------------------------------------------------------------------
 * @copyWrite@
 * 2015 December 14
 * version 2.6.06
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.    Go Higher Information Services, LLC  may  terminate  this
 * license if you don't comply with any of the terms and  conditions set
 * forth in our  commercial  end user license agreement(EULA).   In such
 * event,  licensee  agrees  to  return license or destroy all copies of
 * software upon termination of the license.
 *
 * For the full End User License Agreement, please visit our web site at
 * https://www.gohigheris.com/policies/commercial-eula
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPqKQy2lYvCWCxwfb2BI8IoH04Hdja+uLcF9veqHaJWoNi2avcQ5hfLITp1oJHHjvvfA9JGUS
BYOYAuv/gRtjJlyjkrWD5XJg1u6FnZw476tQ38q+SWCYCwK8zrYA4MsicsPaYHWamjN9i/P4/XI1
K+kcDkKE7TS0w/2uaDcxnxqSODXrNfLMD0nLCxIpB9TF59kYlC0Qg3h2K9rMcglqbD20xP5fbLGh
XLrL4cdG7osI5+gBnH0bJ38mZ1zrzrYGafBToJ9ZCoNJCbqRIhBGr4mlz8eXrGfvrqN/LA0Pb5HH
WXL8J1Coyu3KN9KJn8BjVIKq7OpbVBWnxGGxdLsdOsofOygPEy0JSwJvsAmukX6TtyIrHbwp2N2r
pAh5/si86H3eKRu8ha0lLhJCwP3oNVTmkvBn738S133qd8QpETcREcNRapVnhMKNCJaqKmLPBvRU
B1Um5Q6deMxS8dSpe7lVVqsRKqRoYCt0ksokE4bIu1G5vU/LKv7OZZr+6CDMl6yq6WU+dONIqobX
TvWuKwfIz8234MWMKWzf3/DAtcTo+ixCbWB0jkCLfuTtk2pgphQF1Wa8HyY6i7IrTfQKY/dbrv17
sZKHT8RQwTVyyAVZwsXmThZQWTNsOFylKjPD0y/Zgx7IxhUkojLLwmmcBaiBestwNBV4do1iTutT
fuB2iZgxgyEltZtG1RyRUqbQAsvIW5N+BJdpSDr7V5PA0V/RULnWMO832mBQWz3RbG9Ig0GqV/4/
RZ7NWgTejEmLljNbzw+e/144Hhp84n78dbCsk4USJ+4C2pS5SjjjRrj/eiO/j8u5ykVf6m/PAjAI
mRsj2lGJHm76zCR/RX4KKz0+d4hKdL5BqFvI05d0YjG7CwTAi5ffzgkdpGiWSsxzdWVIh83a+Xbx
zsrWQpzcWEU4ZLH0mq3ZuDhgjN9U1vgS2AnfCEc8PwSY02oGcr/bNTFqbe/sPukEYZ556hhRNWIY
pxkGgPJPn99CExctzWO52Q12mObLe9SJqw8=