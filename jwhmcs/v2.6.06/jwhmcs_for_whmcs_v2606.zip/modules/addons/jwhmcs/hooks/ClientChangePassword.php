<?php //00950
/**
 * ---------------------------------------------------------------------
 * J!WHMCS Integrator v2.6.06
 * ---------------------------------------------------------------------
 * @copyWrite@
 * 2015 December 14
 * version 2.6.06
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.    Go Higher Information Services, LLC  may  terminate  this
 * license if you don't comply with any of the terms and  conditions set
 * forth in our  commercial  end user license agreement(EULA).   In such
 * event,  licensee  agrees  to  return license or destroy all copies of
 * software upon termination of the license.
 *
 * For the full End User License Agreement, please visit our web site at
 * https://www.gohigheris.com/policies/commercial-eula
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPmZmHZetKhizsa3J6IHFWcLkFXWPDd0rekEPs1Y+0ZxX4OWrsziOdYAnNQGw/kA2IEseDbFe
rqNt5RdjGJLYqR9mZxgAp2krE+EqvOVhj0dxcRazemWi9waHwo22y+tE315UAftFKEMS1/T9W4EF
A4CSN0G1DBgvbjwwxreqkUJFcoAERke/R94dKuXynHu/fJS3yhc3GazuBDD0J8phpRKL3Ce/vA8u
DA64Z0c6k57Bd6k9WX92H32C7tNtM92Iajt9CcCp9TDFNmyk/TZbC7CBzlxL2ddNRdcHBEYkFT4T
527O2oLsJTTaKh8lek0D9ZIxdFk3I0BmdDpH1AUSN0voyG+mkcARG0lAPuQLTB68q9EPDJWeRv1m
u3I1r5mAwa53WeD7My1KaaX/M54iJ2UkfkLiTB6ird/e8+VonsW7DAWqfe/RLpcZ2KPZ/Ms6z/Qh
ZWC33otwqZJ6LQDcqvCzWc049uEOCdKcezEYtoNBUyiS57Q2PZN9wo1uYpD2n39kQYaECdkHFXBp
xC8CrongEjUm4Maxzf47/6LzgyoHIe+nBG/K5lzol9I8Lyqkj7EheXd8wMToLMxAzot/ZtioQcsT
HvFkPw4b/kR4UivffNfymBIjSNWj/VOc/tK1hlgMq0EOEJGu45ijuKR2rJOprPNuFSYGiRSu24FW
vamd/r6fiMSoQxUD6hjqonoJZZezUFB3Fmzr4FNSyBwOhgRd5yJcm9ARq/ME506LOgXugA1xffj+
x5FyctJ5iZlnOHheX2DXkUtHvQp0ZzAztgJZDRV+WZV6MrnMmI9wPkRm0pbssFmG53e+xZuF0Emv
ZoGRROwrYOHkhhndQmIEgD/aiaf/guSOKEb93zMcaB5ftdpJ