<?php //00950
/**
 * ---------------------------------------------------------------------
 * J!WHMCS Integrator v2.6.06
 * ---------------------------------------------------------------------
 * @copyWrite@
 * 2015 December 14
 * version 2.6.06
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.    Go Higher Information Services, LLC  may  terminate  this
 * license if you don't comply with any of the terms and  conditions set
 * forth in our  commercial  end user license agreement(EULA).   In such
 * event,  licensee  agrees  to  return license or destroy all copies of
 * software upon termination of the license.
 *
 * For the full End User License Agreement, please visit our web site at
 * https://www.gohigheris.com/policies/commercial-eula
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cP/hPe5Ws81cVssurUrTecEQmE2f+bHDofQAi96UnPOg2NMNS1X7/hjVZ9fVi41RMlOn+yyXR
3tDz2zvfxsQ5LpdIBmJ2wajnSWZ7XD6vHwAvoggpyY/DlHUW0QzMTSn341dn4WaOHg7p/UTBx0HC
7GIV6mD28fT63YitiHMS+nGWwCAIU6BgH9jA/ds219iMD+8q8zaq9NgxJCeH/Pqny56yu2RTvPEN
Meup00neUlo7B7PxLwaIC8mVTVTOa9AItSaoOpCbq+rTZoRixzaSxEw4hDLwHTXcXldYzLUo6NG5
DC3WA+YWE93IrUEu83KtdiKHPsfKTlilNmspNYSs5oa+xY8OYHnVObcC2bpGnzqVmGmWQ/GEUXYx
41yu9jU3/wFlUyTwJkpliRGfo8CYa5jCqypU8e59HDRGzqXeNYqHosnP0sK3x3ylaDZ8MTrRsBRu
loqiwajAw0acmIFyXdbEU9DnWMIYkeSFFNqgbDVHBYhEGi4+kdk6n7s0TW87/XPf2yuHCK9MS7J7
oRRorV57jm0pKLtM39WHR/XjdUIT52Dq92KJNUArhojC/+aQaGtwEGrNSUdwU+sRTvRjwvuU1ZMY
80xg4PBfSKEzrm11YruYB/3C+OA3u1gbyxHpszQmZVo0vTZr5mV797mFLDEBWSabgjNnWQORNyrg
TW4OHhT92rMADVLKsYOzrSaoIfg9s8yq7PL4D97lanyADde62glElTmrh5skXPw0e8FhGfyzTXdV
G5Q+gdXInhPXkqPLmohd3LiMBahK/c1JQNPL4lQTNdORiEQ1EbqxMztDUX+qhH0V3Ln5S/MY1cqT
TXnbJFaipq0Wg2w5r3EyCiJdhitCpky=