<?php //00950
/**
 * ---------------------------------------------------------------------
 * J!WHMCS Integrator v2.6.06
 * ---------------------------------------------------------------------
 * @copyWrite@
 * 2015 December 14
 * version 2.6.06
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.    Go Higher Information Services, LLC  may  terminate  this
 * license if you don't comply with any of the terms and  conditions set
 * forth in our  commercial  end user license agreement(EULA).   In such
 * event,  licensee  agrees  to  return license or destroy all copies of
 * software upon termination of the license.
 *
 * For the full End User License Agreement, please visit our web site at
 * https://www.gohigheris.com/policies/commercial-eula
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cP+FgIOOiDBAfFLhSfI4qg3/N2dxGaPSlQ8IiG0Ucs+EYAzy/Yi4xyYUFjcd7sUSUByQ+34vo
PrT0QFofh7mIsnbutQ0zdxM0bJ74adsUIbiwZ1bnKID5rFNCTokHEJUoA+H5lANWfNGZoVVGTtSt
Q4hxNfhxcEDJoYW0ZE/K2ssrEmHYKivRsbg7N8+48k4A40mR87hYn7T7Pgpf4f+4PKSYHqvGcF37
1JODy+vDrvNwf3AFMEoWC8mVTVTOa9AItSaoOpCbq+bXebycUhxdOtOMwzKAUTTr/+PP8neKD1Rd
AU1UMccg6uob3XE++kSJSyqaU2qkYSyBHmmWGSCitdWbKBz3QAxH9Ib8t6vQW/YaPUqKNnBS9zGB
Ga0GjrMoT+383AyYa6+iXzeaqiUotW/gav5kzxYKI6aDlVnDvHVfn8aS9M6VoMSiz+NNJ1PYbkJn
CwhOJDYpsMr7L+qmSU8+zdZMRxNSjQjYNPxevIxxAchWo1DthHSuKjVVPKnfcYsAPCHg/Mmlhzzt
FUcPP0iuHHYwZbAHohqBeQl/BdIVaVImt+wYjjQcR8khEwV96EAqsgcm1YG6T+5nHNYfBesnyOqp
xcHEUr5YWiRCcAFb2XZPBlQeFXoH4D/w8fb7QlQGkP7cghhY58NFV8hLNGiZll0kLtPq8bZ29Ul3
C7a16BHga0VK3Eos3PbEHq+hMyLpIj18UNyNHweQXBlg0Yae9xUiTxrZCRBeQlO8fuNipoAKzWJl
Goy7GS+E2bmOHp5Ts1MI4fzA3OEM0JJG0YWv65bM4rb/PDBXFeFwXDpjg/JcM9D4EMXUjfpI51GC
5pM8fSO+msBMTw2YizmVOdzJNhjfqvLF