<?php //00950
/**
 * ---------------------------------------------------------------------
 * J!WHMCS Integrator v2.6.06
 * ---------------------------------------------------------------------
 * @copyWrite@
 * 2015 December 14
 * version 2.6.06
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.    Go Higher Information Services, LLC  may  terminate  this
 * license if you don't comply with any of the terms and  conditions set
 * forth in our  commercial  end user license agreement(EULA).   In such
 * event,  licensee  agrees  to  return license or destroy all copies of
 * software upon termination of the license.
 *
 * For the full End User License Agreement, please visit our web site at
 * https://www.gohigheris.com/policies/commercial-eula
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPytAdRBX4MQ5w7q8aH5Hv+ZBfI8pio4c/DnKgyPEoqhnecrtkObOl36d6DfeLq4KCNfKDC7K
kCGq4sKersCAbzarzB42FXOT6VA6ZffqYOyoMhtSQo8JrJdc5ekYBDMKDGX3ZjpKihzs9Ufp7Ri5
qoqTUuwCPR+EDDsSlEZGdAyVSMJxL38mhw7O73feR6c+fcoe0ysq9zMD9XN/Has+AK2oY4KONm1F
AyV/Lh2jIVlxwsL5qEUmQTCmZ1zrzrYGafBToJ9ZCoNJ8cF/aDO28EUbEKcMrQe1sn7/+LaoHuc1
zYRgzd5PTmJrKSZ6Pwdu19AssCJypqxcr4pJ2rgJdhfig/pI9Zh5QA3n+FfZwFOOYfgJHv91yvf4
LQRVJpOX6+4JEtBl5J4oYw/4Q+jxgzcDpG2pm+HLg54uv4xvGd5+UxDVl3Cl/tgb8TLFgKw+UqsB
bRgbYrTAyMa3ZREeOlR90IyBpQzbLxAjfhJ3t+Ahv1mmV+pl/zAxn1y3cYl9d1RTP1FEnUSz9zHI
4p95mHtJNt7VkgDRwtgUIwC+g41oiUlF0siXYcf43LEuB4Di5l3+lFyRB0hXUnV72aVvmbdw1Eke
nfi/iow9hy1nYIRDnyj9i3QhCzZlBwBR8A1k51xgenZ5jgsqk3qvqlTPpxbt48zuqXpSMCUfPrC+
7vkyBdQ5EUQLoYCCy1kRVPXNQWiz4RPNZOIRq9bI5s8lBWMNkhoUuuhrqXzcrK2gMuLj0bcoydkN
Kqd1ysFoE0v8UZYb8rdXCAVxO4n19JX09T88sRUm2986YsZWOFd/pFYS+kjtayZtmHaXE8EOcOka
kHOXMi5Rr0BqxeRVtL2/7joLj0==