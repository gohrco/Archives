<?php
/**
 * Default Controller for J!WHMCS Integrator
*
* @package    J!WHMCS Integrator
* @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
* @license    GNU General Public License version 2, or later
* @version    $Id: default.php 555 2012-09-06 02:10:32Z steven_gohigher $
* @since      1.5.1
*/

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
include_once( JPATH_SITE . DIRECTORY_SEPARATOR . 'administrator' . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_jwhmcs' . DIRECTORY_SEPARATOR . 'jwhmcs.legacy.php' );


/**
 * JwhmcsController class is the default task handler for the front end
 * @version		2.6.06
 *
 * @since		1.5.0
 * @author		Steven
 */
class JwhmcsController extends JwhmcsControllerExt
{

	/**
	 * Constructor task
	 * @access		public
	 * @version		2.6.06
	 * @version		2.5.0		- May 2013: major rewrite
	 *
	 * @since		1.5.1
	 */
	public function __construct()
	{
		parent::__construct();
	}



	/**
	 * Display task
	 * @access		public
	 * @version		2.6.06
	 * @version		2.5.0		- May 2013: major rewrite
	 *
	 * @since		2.4.9
	 * @see			JwhmcsController :: display()
	 */
	public function display()
	{
		$input	=	dunloader( 'input', true );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			$input->setVar( 'layout', 'default35' );
		}
		
		parent::display();
	}
}