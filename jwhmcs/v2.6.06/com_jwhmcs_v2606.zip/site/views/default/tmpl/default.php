<?php 
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.6.06 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.1.0
 * 
 * @desc       Default View - default layout:  The default layout for the default view
 *  
 */

defined('_JEXEC') or die('Restricted access');
?>

<?php if ( $this->params->get( 'show_page_heading', false ) ): ?>
<h1><?php echo $this->params->get( 'page_title' ); ?></h1>
<?php endif; ?>

<!-- J!WHMCS -->
<jwhmcs /><!-- J!WHMCS:  COMPONENT -->
<!-- J!WHMCS -->