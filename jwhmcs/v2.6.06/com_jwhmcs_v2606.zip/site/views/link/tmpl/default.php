<?php 
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.6.06 ( $Id: default.php 606 2012-11-09 22:05:56Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      2.1.0
 * 
 * @desc       Register View - default layout:  The default layout for the registration view
 *  
 */

defined('_JEXEC') or die('Restricted access');

?>

<script type="text/javascript">
<!--
	window.addEvent('domready', function() {
		document.formvalidator.setHandler('passverify',
			function (value) {
				return ($('newpw').value == value);
		});
	});
// -->
</script>

<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery("#newpw").keyup(function () {
		var pwvalue = jQuery("#newpw").val();
		var pwstrength = getPasswordStrength(pwvalue);
		jQuery("#pwstrength").html("<?php echo JText::_( "COM_JWHMCS_REGISTER_PASSWORD_STRONG" ); ?>");
		jQuery("#pwstrengthpos").css("background-color","#33CC00");
		if (pwstrength<75) {
			jQuery("#pwstrength").html("<?php echo JText::_( "COM_JWHMCS_REGISTER_PASSWORD_MODERATE" ); ?>");
			jQuery("#pwstrengthpos").css("background-color","#ff6600");
		}
		if (pwstrength<30) {
			jQuery("#pwstrength").html("<?php echo JText::_( "COM_JWHMCS_REGISTER_PASSWORD_WEAK" ); ?>");
			jQuery("#pwstrengthpos").css("background-color","#cc0000");
		}
		jQuery("#pwstrengthpos").css("width",pwstrength);
		jQuery("#pwstrengthneg").css("width",100-pwstrength);
    });
});

function getPasswordStrength(pw){
    var pwlength=(pw.length);
    if(pwlength>5)pwlength=5;
    var numnumeric=pw.replace(/[0-9]/g,"");
    var numeric=(pw.length-numnumeric.length);
    if(numeric>3)numeric=3;
    var symbols=pw.replace(/\W/g,"");
    var numsymbols=(pw.length-symbols.length);
    if(numsymbols>3)numsymbols=3;
    var numupper=pw.replace(/[A-Z]/g,"");
    var upper=(pw.length-numupper.length);
    if(upper>3)upper=3;
    var pwstrength=((pwlength*10)-20)+(numeric*10)+(numsymbols*15)+(upper*10);
    if(pwstrength<0){pwstrength=0}
    if(pwstrength>100){pwstrength=100}
    return pwstrength;
}

function showStrengthBar() {
    document.write('<table align="left"><tr><td style="width: 100%; text-align: center; "><?php echo JText::_( "COM_JWHMCS_REGISTER_PASSWORD_STRENGTH" ); ?></td></tr><tr><td><table align="center"><tr><td width="102"><div id="pwstrengthpos" style="position:relative;float:left;width:0px;background-color:#33CC00;border:1px solid #000;border-right:0px;">&nbsp;</div><div id="pwstrengthneg" style="position:relative;float:right;width:100px;background-color:#efefef;border:1px solid #000;border-left:0px;">&nbsp;</div></td></tr></table></td></tr><tr><td><div id="pwstrength" style="width: 100%; text-align: center; "><?php echo JText::_( "COM_JWHMCS_REGISTER_PASSWORD_WEAK" ); ?></div></td></tr></table>');
}


function comparePW() {
	var img = $("pass2Result");
	var pass1 = $('newpw');
	var pass2 = $('password2');
	var val = $("password2Valid");
	
	if ( pass1.value != pass2.value ) {
		val.setProperty('value', "");
		img.removeClass('imgnotice').removeClass('imgrequired').removeClass('imgvalid').addClass('imginvalid');
	} else {
		val.setProperty('value', "1");
		img.removeClass('imgnotice').removeClass('imginvalid').addClass('imgvalid');
	}
}


function hasInfo(type, value)
{
	var img = $(type+"Result");
	var val = $(type+"Valid");

	if (! value ) {
		val.setProperty( 'value', "" );
		img.removeClass('imgnotice').removeClass('imgrequired').removeClass('imgvalid').addClass('imginvalid');
	} else {
		val.setProperty( 'value', "1" );
		img.removeClass('imgnotice').removeClass('imgrequired').removeClass('imginvalid').addClass('imgvalid');
	}
}
</script>
<?php
if(isset($this->message)){
	$this->display('message');
}

$ajax = ( $this->params->get( 'RegAjax' ) ? true : false );
$ajaxClass = ( $ajax ? '' : ' required' );
?>

<form action="<?php echo JRoute::_( "index.php?option=com_jwhmcs&controller=register&Itemid=" . $this->params->get( 'RegMenu' ) . "&controller=register&task=save"); ?>" method="post" id="josForm" name="josForm" class="form-validate">

<?php if ( $this->tmplparams->get( "show_page_heading" ) ) : ?>
<h1>
	<?php echo $this->tmplparams->get( "page_heading" ); ?>
</h1>
<?php endif; ?>

<?php if ( $this->tmplparams->def( 'show_page_title', 1 ) ) : ?>
<h2>
	<?php echo $this->escape($this->tmplparams->get('page_title')); ?>
</h2>
<?php endif; ?>

<table cellpadding="0" cellspacing="0" border="0" width="100%" class="contentpane">
<tr>
	<td class="labelCell">
		<label id="firstnamemsg" for="firstname">
			<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_FIRSTNAME" ); ?>:
		</label>
	</td>
	<td class="imgCell"><div id="firstnameResult" class="notifier imgrequired">&nbsp;</div></td>
  	<td>
  		<input type="text" name="firstname" id="firstname" size="40" value="<?php echo $this->post['firstname']; ?>" class="inputbox<?php echo $ajaxClass; ?>" maxlength="50"<?php if ($ajax): ?> onblur="hasInfo( 'firstname', this.value ); " onchange="hasInfo( 'firstname', this.value) ; "<?php endif; ?> /> *
  		<input type="hidden" id="firstnameValid" class="required" name="firstnameValid" value="" />
  	</td>
</tr>
<tr>
	<td class="labelCell">
		<label id="lastnamemsg" for="lastname">
			<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_LASTNAME" ); ?>:
		</label>
	</td>
	<td class="imgCell"><div id="lastnameResult" class="notifier imgrequired">&nbsp;</div></td>
  	<td>
  		<input type="text" name="lastname" id="lastname" size="40" value="<?php echo $this->post['lastname']; ?>" class="inputbox<?php echo $ajaxClass; ?>" maxlength="50"<?php if ($ajax): ?> onblur="hasInfo( 'lastname', this.value) ; " onchange="hasInfo( 'lastname', this.value) ; "<?php endif; ?> /> *
  		<input type="hidden" id="lastnameValid" class="required" name="lastnameValid" value="" />
  	</td>
</tr>
<tr>
	<td colspan="2" class="labelCell">
		<label id="companynamemsg" for="companyname">
			<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_COMPANYNAME" ); ?>:
		</label>
	</td>
	<td>
  		<input type="text" name="companyname" id="companyname" size="40" value="<?php echo $this->post['companyname'];  ?>" class="inputbox" maxlength="50" />
  	</td>
</tr>
<tr>
	<td class="labelCell">
		<label id="address1msg" for="address1">
			<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_ADDRESSONE" ); ?>:
		</label>
	</td>
	<td class="imgCell"><div id="address1Result" class="notifier imgrequired">&nbsp;</div></td>
  	<td>
  		<input type="text" name="address1" id="address1" size="40" value="<?php echo $this->post['address1']; ?>" class="inputbox<?php echo $ajaxClass; ?>" maxlength="50"<?php if ($ajax): ?> onblur="hasInfo( 'address1', this.value) ; " onchange="hasInfo( 'address1', this.value) ; "<?php endif; ?> /> *
  		<input type="hidden" id="address1Valid" class="required" name="address1Valid" value="" />
  	</td>
</tr>
<tr>
	<td colspan="2" class="labelCell">
		<label id="address2msg" for="address2">
			<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_ADDRESSTWO" ); ?>
		</label>
	</td>
  	<td>
  		<input type="text" name="address2" id="address2" size="40" value="<?php echo $this->post['address2'];  ?>" class="inputbox" maxlength="50" />
  	</td>
</tr>
<tr>
	<td class="labelCell">
		<label id="citymsg" for="city">
			<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_CITY" ); ?>:
		</label>
	</td>
	<td class="imgCell"><div id="cityResult" class="notifier imgrequired">&nbsp;</div></td>
  	<td>
  		<input type="text" name="city" id="city" size="40" value="<?php echo $this->post['city'];  ?>" class="inputbox<?php echo $ajaxClass; ?>" maxlength="50"<?php if ($ajax): ?> onblur="hasInfo( 'city', this.value) ; " onchange="hasInfo( 'city', this.value) ; "<?php endif; ?> /> *
  		<input type="hidden" id="cityValid" class="required" name="cityValid" value="" />
  	</td>
</tr>
<tr>
	<td class="labelCell">
		<label id="statemsg" for="state">
			<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_STATE" ); ?>:
		</label>
	</td>
	<td class="imgCell"><div id="stateResult" class="notifier imgrequired">&nbsp;</div></td>
  	<td>
  		<input type="text" name="state" id="state" size="40" value="<?php echo $this->post['state'];  ?>" class="inputbox<?php echo $ajaxClass; ?>" maxlength="50"<?php if ($ajax): ?> onblur="hasInfo( 'state', this.value) ; " onchange="hasInfo( 'state', this.value) ; "<?php endif; ?> /> *
  		<input type="hidden" id="stateValid" class="required" name="stateValid" value="" />
  	</td>
</tr>
<tr>
	<td class="labelCell">
		<label id="postcodemsg" for="postcode">
			<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_POSTCODE" ); ?>:
		</label>
	</td>
	<td class="imgCell"><div id="postcodeResult" class="notifier imgrequired">&nbsp;</div></td>
  	<td>
  		<input type="text" name="postcode" id="postcode" size="40" value="<?php echo $this->post['postcode'];  ?>" class="inputbox<?php echo $ajaxClass; ?>" maxlength="50"<?php if ($ajax): ?> onblur="hasInfo( 'postcode', this.value) ; " onchange="hasInfo( 'postcode', this.value) ; "<?php endif; ?> /> *
  		<input type="hidden" id="postcodeValid" class="required" name="postcodeValid" value="" />
  	</td>
</tr>
<tr>
	<td colspan="2" class="labelCell">
		<label id="countrymsg" for="country">
			<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_COUNTRY" ); ?>:
		</label>
	</td>
  	<td>
  		<?php echo JHtml::_('select.genericlist', JwhmcsHelper::buildCountries( true ), 'country', null, 'value', 'text', ( ( $ctry = JwhmcsHelper :: get( 'country' ) ) ? $ctry : $this->params->get( 'WhmcsDefaultcountry' ) ) ); ?> *
  	</td>
</tr>
<tr>
	<td class="labelCell">
		<label id="phonenumbermsg" for="phonenumber">
			<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_PHONENUM" ); ?>:
		</label>
	</td>
  	<td class="imgCell"><div id="phonenumberResult" class="notifier imgrequired">&nbsp;</div></td>
	<td>
  		<input type="text" name="phonenumber" id="phonenumber" size="40" value="<?php echo $this->post['phonenumber'];  ?>" class="inputbox<?php echo $ajaxClass; ?>" maxlength="50"<?php if ($ajax): ?> onblur="hasInfo( 'phonenumber', this.value) ; " onchange="hasInfo( 'phonenumber', this.value) ; "<?php endif; ?> /> *
  		<input type="hidden" id="phonenumberValid" class="required" name="phonenumberValid" value="" />
  	</td>
</tr>
<tr>
	<td colspan="3">
		<div id="message" class="message">&nbsp;</div>
	</td>
</tr>
<tr>
	<td class="labelCell">
		<label id="usernamemsg" for="username">
			<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_USERNAME" ); ?>:
		</label>
	</td>
	<td class="imgCell"><div id="usernameResult" class="notifier imgrequired">&nbsp;</div></td>
	<td>
		<input type="text" id="username" name="username" size="40" value="<?php echo $this->post['username'];  ?>" class="inputbox<?php echo $ajaxClass; ?> validate-username" maxlength="25"<?php if ($ajax): ?> onblur="validInfo('username', this.value); " onchange="validInfo('username', this.value); " onkeypress="return onKeypress(event); "<?php endif; ?> /> *
		<input type="hidden" id="usernameCheckmsg" name="usernameCheckmsg" value="<?php echo JText::_( "COM_JWHMCS_REGISTER_CHECK_USERNAME_MSG" ); ?>" />
		<input type="hidden" id="usernameValid" class="required" name="usernameValid" value="" />
	</td>
</tr>
<tr>
	<td class="labelCell">
		<label id="emailmsg" for="email">
			<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_EMAIL" ); ?>:
		</label>
	</td>
	<td class="imgCell"><div id="emailResult" class="notifier imgrequired">&nbsp;</div></td>
	<td>
		<input type="text" id="email" name="email" size="40" value="<?php echo $this->post['email'];  ?>" class="inputbox<?php echo $ajaxClass; ?> validate-email" maxlength="100"<?php if ($ajax): ?> onblur="validInfo('email', this.value); " onchange="validInfo('email', this.value); " onkeypress="return onKeypress(event); "<?php endif; ?> /> *
		<input type="hidden" id="emailCheckmsg" name="emailCheckmsg" value="<?php echo JText::_( "COM_JWHMCS_REGISTER_CHECK_EMAIL_MSG" ); ?>" />
		<input type="hidden" id="emailValid" class="required" name="emailValid" value="" />
	</td>
</tr>
<tr>
	<td class="labelCell">
		<label id="pwmsg" for="password">
			<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_PASSWORD" ); ?>:
		</label>
	</td>
  	<td class="imgCell"><div id="passwordResult" class="notifier imgrequired">&nbsp;</div></td>
	<td>
  		<input class="inputbox<?php echo $ajaxClass; ?> validate-password" type="password" id="newpw" name="password" size="40" value=""<?php if ($ajax): ?> onblur="validInfo('password', this.value); comparePW(); " onchange="validInfo('password', this.value); comparePW(); " onkeypress="return onKeypress(event); "<?php endif; ?> /> *
  		<input type="hidden" id="passwordCheckmsg" name="passwordCheckmsg" value="<?php echo JText::_( 'COM_JWHMCS_REGISTER_CHECK_PASSWORD_MSG' ); ?>" />
		<input type="hidden" id="passwordValid" class="required" name="passwordValid" value="" />
  	</td>
</tr>
<tr>
	<td class="labelCell">
		<label id="pw2msg" for="password2">
			<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_PASSVERIFY" ); ?>:
		</label>
	</td>
  	<td class="imgCell"><div id="pass2Result" class="notifier imgrequired">&nbsp;</div></td>
	<td>
		<input class="inputbox<?php echo $ajaxClass; ?> validate-passverify" type="password" id="password2" name="password2" size="40" value=""<?php if ($ajax): ?> onblur="comparePW(); " onchange="comparePW(); "<?php endif; ?> /> *
		<input type="hidden" id="password2Valid" class="required" name="password2Valid" value="" />
	</td>
</tr>
<tr>
	<td colspan="2" class="labelCell">
		&nbsp;
	</td>
	<td align="center">
		<script language="JavaScript" type="text/javascript">showStrengthBar();</script>
	</td>
</tr>
<?php if ($this->params->get( 'RecaptchaEnable' )):
$reurl = ($this->params->get( 'scheme' ) == 'https' ? 'https://api-secure.recaptcha.net' : 'http://api.recaptcha.net' );
?> 
<tr>
	<td colspan="2">&nbsp;</td>
	<td>
<script>
var RecaptchaOptions = {
   theme : '<?php echo $this->params->get( 'RecaptchaTheme' ); ?>',
   lang: '<?php echo $this->params->get( 'RecaptchaLang' ); ?>'
};
</script>
<?php
	require_once(JPATH_COMPONENT.DS.'recaptchalib.php');
	$publickey	= $this->params->get( 'RecaptchaPublickey' );
	$useSsl		= ( $this->params->get( 'scheme' ) == 'https' ? true : false );
	echo recaptcha_get_html( $publickey, null, $useSsl );
?>
	</td>
</tr>
<?php endif; ?>
<tr>
	<td colspan="2" class="labelCell">
		&nbsp;
	</td>
	<td>
		<?php echo JText::_( "COM_JWHMCS_REGISTER_REQUIRED" ); ?>
	</td>
</tr>
<?php if ($this->params->get( 'DisplayTOS' )): ?>
<tr>
	<td colspan="2" class="labelCell" style="text-align: right; padding-right: 20px; ">
		<input type="hidden" name="tos" value="0" <?php if ( $this->params->get( 'RequireTOS' ) == 1 ) : ?> class="required" <?php endif; ?>/>
		<input type="checkbox" name="tos" value="1" />
	</td>
	<td>
		<?php echo sprintf( JText :: _( 'COM_JWHMCS_REGISTER_TOSLINK' ), $this->tosurl ); ?>
	</td>
</tr>
<?php endif; ?>
</table>
	<button class="button validate" type="submit"><?php echo JText::_("COM_JWHMCS_REGISTER_BUTTON"); ?></button>
	<input type="hidden" name="id" value="0" />
	<input type="hidden" name="gid" value="0" />
	<input type="hidden" name="usedata" value="1" />
	<input type="hidden" name="option" value="com_jwhmcs" />
	<input type="hidden" name="thisurl" value="<?php echo $this->thisurl; ?>" id="thisurl" />
	<?php echo JHTML::_( 'form.token' ); ?>
</form>