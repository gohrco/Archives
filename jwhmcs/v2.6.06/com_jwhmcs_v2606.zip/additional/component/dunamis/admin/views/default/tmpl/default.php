<?php defined('_JEXEC') or die('Restricted access'); ?>

<div class="row-fluid">
	<div class="span1"> </div>
</div>

<form action="index.php" method="post" name="adminForm">
<input type="hidden" name="option" value="com_dunamis" />
<input type="hidden" name="controller" value="default" />
<input type="hidden" name="task" value="" />
</form>