<?php
/**
 * J!WHMCS Integrator - System Language Plugin
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: jwhmcs_sysmlang.php 557 2012-09-20 17:19:17Z steven_gohigher $
 * @since      2.0.2
 * 
 * @desc		This plugin handles adding the language=xx to external links
 * 				in the Joomla system that are tied to the component parameters.
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.plugin.plugin');

$path	= JPATH_ADMINISTRATOR . '/components/com_jwhmcs/jwhmcs.helper.php';
if ( file_exists( $path ) ) require_once( $path );


/**
 * System Language Plugin
 * @version		2.4.12
 *
 * @since		2.0.2
 * @author		Steven
 */
class plgSystemJwhmcs_sysmlang extends JPlugin
{

	/**
	 * Constructor method
	 *@access		public
	 * @version		2.4.12
	 * @param		object		- $subject: The object to observe
	 * @param 		array		- $config: An array that holds the plugin configuration
	 * 
	 * @since		2.0.2
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
	}
	
	
	/**
	 * onAfterInitialise Event Handler
	 * @access		public
	 * @version		2.4.12
	 * 
	 * @since		2.4.4
	 */
	public function onAfterInitialise()
	{
		$params		= & JwhmcsParams::getInstance();
		
		$app = & JFactory :: getApplication();
		if ( $app->isAdmin() ) return;
		
		if ( ( $lang = JwhmcsHelper :: get( 'jwhmcslang', false ) ) ) {
			$langs	= array_flip( $this->_getLanguages() );
			$lang	= strtolower( $lang );
			if ( isset( $langs[$lang] ) ) {
				$language = & JFactory :: getLanguage();
				$language->setLanguage( $langs[$lang] );
				$language->load();
			}
		}
	}
	
	
	/**
	 * onAfterRender Event Handler
	 * @access		public
	 * @version		2.4.12
	 * 
	 * @since		2.0.2
	 */
	public function onAfterRender()
	{
		if (! class_exists('JwhmcsParams') )
			return;	// Be sure we can load our own parameters
		
		$app	= & JFactory::getApplication();
		$params	= & JwhmcsParams::getInstance();
		$Itemid = & JwhmcsHelper :: get( "Itemid" );
		
		// If we can't load the helper then bail
		if (! class_exists( 'JwhmcsHelper' ) ) return;
		
		if ( $app->isAdmin() )
			return;	// Don't run if we are in the backend!
		
		if ($params->get( 'LangEnable' ) != 1 )
			return;	// We haven't enabled language translations so don't bother proceeding
		
		if ((! $params->get( 'RenderEnable' )) || (! $params->get( 'Enable' )))
			return;	// Don't run if product or visual integration disabled
		
		// Create replacement language tag
		$langarray = $this->_getLanguages();
		
		if ( empty( $langarray ) )
			return;	// No languages set - return in case error reporting high
		
		$buffer 	=   JResponse::getBody();				// Site contents
		$langcurr	= & JFactory::getLanguage();			// Current language of the site
		$selected	=   $langarray[$langcurr->getTag()];	// The corresponding language in WHMCS selected
		
		// If we are rendering the page for WHMCS to wrap, then insert language tag on WHMCS side
		if ( ( $params->get( "RenderLoggedin" ) == $Itemid ) OR ( $params->get( "RenderLoggedout" ) == $Itemid ) ) {
			$selected = "<!-- LANGUAGE_REPLACE -->";
		}
		
		$regex	= '`(?<front><a href\=")(?<link>%s[^>"]+)(?P<back>[^>]+?>)`';
		preg_match_all( sprintf( $regex, $params->get( "ApiUrl" ) ), $buffer, $matches, PREG_SET_ORDER );
		foreach ( $matches as $match ) {
			$uri = & JUri::getInstance( $match["link"], true );
			$uri->setVar( "language", $selected );
			$buffer = str_replace( $match[0], "{$match['front']}{$uri->toString()}{$match['back']}", $buffer );
		}
		
		// Array of possible self references if on page to render around WHMCS
		$regex		= array();
		$regex[]	= '`(?:http|https)://[^\?>]*index\.php\?[^"]*option=com_jwhmcs(?:[^">]*lang=(.{2})[^">]*)`';	// No SEF turned on
		$regex[]	= '`(?:http|https)://[^\?>]*index\.php\?(?:[^">]*lang=(.{2})[^">]*)option=com_jwhmcs`';			// SEF URLS only on
		//$regex[]	= '`http[s]*://[^"]*/(.{2})/component/jwhmcs/[^"]*`';											// Unused Duplicate?
		$regex[]	= '`(?:http|https)://[^\?>]*index\.php\/(.{2})\/jwhmcs-logged-(?:out|in)[^"]*`';				// SEF URLS and suffix added (no rewrite) 
		$regex[]	= '`(?:http|https)://[^\?>]*\/(.{2})\/jwhmcs-logged-(?:out|in)[^"]*`';							// SEF URLS and suffix and rewrite OR SEF and rewrite without suffix
		
		foreach ( $regex as $reg )
			$buffer = preg_replace( $reg, "<!-- LANGUAGE=$1 -->", $buffer );
		
		JResponse::setBody($buffer);
		return;
	}
	
	
	/**
	 * Method to retrieve the menu items from the JWHMCS parameters
	 * @access		private
	 * @version		2.4.12
	 * 
	 * @return		array
	 * @since		2.0.2ww
	 */
	private function _getMenuItems()
	{
		$params	= & JwhmcsParams::getInstance();
		$menus	=   $params->getPrime('menu');
		
		unset($menus['MenuStyle']);
		
		foreach ($menus as $k => $v)
		{
			$return[] = $v;
		}
		return $return;
	}
	
	
	/**
	 * Method to retrieve and assemble the languages for use
	 * @access		private
	 * @version		2.4.12
	 * 
	 * @return		array
	 * @since		2.0.2
	 */
	private function _getLanguages()
	{
		$params = & JwhmcsParams::getInstance();
		$jlangs =   $this->_getJlanguages();
		
		if (! is_array($jlangs))
			return array();
		
		foreach ($jlangs as $lang) {
			$language = $params->get( 'LangJoom'.$lang->shortcode );
			if (! $language) $language = $params->get( 'LangDefault' );
			$return[$lang->code] = $language;
		}
		return $return;
	}
	
	
	/**
	 * Method to call up the languages from the database
	 * @access		private
	 * @version		2.4.12
	 * 
	 * @return		array of objects
	 * @since		2.1.0
	 */
	private function _getJlanguages()
	{
		$db = & JFactory::getDBO();
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$query = "SELECT `title` as `name`, `lang_code` as `code`, `sef` as `shortcode` FROM #__languages ORDER BY name";
		}
		else {
			$query = "SELECT `title` as `name`, `lang_code` as `code`, `sef` as `shortcode` FROM #__languages ORDER BY name";
			//$query = "SELECT `name`, `code`, `shortcode` FROM #__languages ORDER BY name";
		}
		
		$db->setQuery($query);
		$langs = $db->loadObjectList();
		
		return $langs;
	}
	
	
	/**
	 * Event called when gathering update sites to check for updates
	 * @access		public
	 * @version		2.4.12
	 *
	 * @return		array
	 * @since		2.4.0
	 */
	public function getUpdateSite()
	{
		return array(
				'extensionName'				=> 'plg_jwhmcs_sysmlang',
				'options' => array(
						'extensionTitle'	=> 'J!WHMCS Integrator System Language Handler Plugin',
						'storage'			=> 'database',
						'storagePath'		=> null,
						'extensionType'		=> 'plugin',
						'updateUrl'			=> 'https://www.gohigheris.com/updates/jwhmcs/plugins/sysmlang'
				)
		);
	}
}