<?php 
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.4.12 ( $Id: default.php 223 2011-05-25 19:15:48Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      2.1.0
 * 
 * @desc       Default View - default layout:  The default layout for the default view
 *  
 */

defined('_JEXEC') or die('Restricted access');
?>
<!-- J!WHMCS -->

<?php if ( $this->params->get( 'show_page_title' ) ): ?>
<div class="componentheading">
	J!WHMCS Integrator Blank Page - <?php echo $this->params->get( 'page_title' ); ?>
</div>
<?php endif; ?>

<table class="contentpaneopen">
	<tr>
		<td valign="top">
			<p>If you are seeing this page, then you are incorrectly linking directly to the blank place holder on the Hidden Menu.  You should not link directly to this menu item.  You should select this menu item in the component settings under "Visual Integration".  This will then be used by the J!WHMCS Integrator to wrap around your WHMCS site.</p>
			<p>You can always visit this page to see what modules and content to expect on your WHMCS site.  The content you are reading will be stripped out by the J!WHMCS Integrator and replaced with your WHMCS site content.</p>
			<p>A common issue you may experience involves styling from WHMCS overwriting the styles in Joomla.  Some of the style names that are used in WHMCS and also many Joomla templates include:</p>
			<ul>
				<li>wrapper (class style)</li>
				<li>heading (class style)</li>
				<li>element specific styles for table, tr, td, a, img, body... and more</li>
			</ul>
			<p>This is a problem because the styles from WHMCS will overwrite any duplicate style from Joomla, so your pages may not render exactly as you expect.  This isn't an issue with the J!WHMCS Integrator, but simply a styling issue that needs to be addressed in your WHMCS site templates.</p>
		</td>
	</tr>
</table>
<!-- J!WHMCS:  COMPONENT -->
<!-- J!WHMCS -->