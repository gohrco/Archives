<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.4.12 ( $Id: jwhmcs.php 555 2012-09-06 02:10:32Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      1.5.0
 * 
 * @desc       Primary File:  Called directly by Joomla for component handling purposes
 *  
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Define the DS shortcut (3.0 dropped?)
if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
	if (! defined( 'DS' ) ) define( 'DS', DIRECTORY_SEPARATOR );
}

// Require the base controller
require_once (JPATH_SITE . DS . 'components' . DS . 'com_jwhmcs' . DS . 'controller.php');
require_once( JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_jwhmcs' . DS . 'model.php' );

// Helper
$path	= JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_jwhmcs' . DS . 'jwhmcs.helper.php';
require_once( $path );

// Require specific controller if requested
$controller = JRequest::getWord('controller', 'default');
require_once (JPATH_SITE . DS . 'components' . DS . 'com_jwhmcs' . DS . 'controllers'.DS.$controller.'.php');

// Create the controller
$classname	= 'JwhmcsController'.$controller;
$controller = new $classname();

// Perform the Request task
$controller->execute( JRequest::getWord('task'));

// Redirect if set by the controller
$controller->redirect();

?>
