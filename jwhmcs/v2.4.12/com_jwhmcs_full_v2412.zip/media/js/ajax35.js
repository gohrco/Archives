/**
 * Encodes a string for transmission through the URL (frontend only)
 * @param clearString
 * @returns clean {String}
 */
function URLEncode (clearString) {
	var output = '';
	var x = 0;
	clearString = clearString.toString();
	var regex = /(^[a-zA-Z0-9_.]*)/;
	while (x < clearString.length) {
		var match = regex.exec(clearString.substr(x));
		if (match != null && match.length > 1 && match[1] != '') {
			output += match[1];
			x += match[1].length;
		} else {
			if (clearString[x] == ' ')
				output += '+';
			else {
				var charCode = clearString.charCodeAt(x);
				var hexVal = charCode.toString(16);
				output += '%' + ( hexVal.length < 2 ? '0' : '' ) + hexVal.toUpperCase();
			}
			x++;
		}
	}
	return output;
}


/**
 * Function to check for updates via ajax (backend)
 */
function checkForUpdates()
{
	var url = "index.php?option=com_jwhmcs";
	
	jQuery.ajax({
		type: 'POST',
		url: url,
		data: 'controller=ajax&task=checkforupdates',
	}).success( function ( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		processUpdate( obj );
		
	});
}


/**
 * Processes response from update check
 * @version		@fileVers@
 * @since		2.4.0
 */
function processUpdate( response ) {
	
	var apistatuslnk = jQuery( '#jwhmcs_icon_updates_link' );
	var apistatusimg = jQuery( '#jwhmcs_icon_updates_img' );
	var apistatusmsg = jQuery( '#jwhmcs_icon_updates_title' );
	
	apistatusmsg.html( response.message );
	
	apistatusimg.attr( 'src', '');
	apistatusimg.attr( 'alt', '' );
	apistatusimg.addClass( 'ajaxicon' );
	
	if ( response.updates == '1' ) {
		apistatusimg.addClass( 'found' );
	}
	else if ( response.updates == '0' ) {
		apistatusimg.addClass( 'current' );
	}
	else if ( response.updates == '-1' ) {
		apistatusimg.addClass( 'unsupported' );
	} else {
		apistatusimg.addClass( 'stall' );
	}
	
	return;
}


/**
 * Common method for ignoring the return keypress in a field
 */
function onKeypress(e) {
	if (e.keyCode == 13) {
		return false;
	}
}


/**
 * Validate the name and activate or disable submit button
 * @param task
 */
function jwhmcs_submitbutton(task)
{
	var form	= jQuery( '#item-form' );
		
	if ( task == 'validate' ) {
		validateUsername( jQuery( '#username' ).val() );
	}
	else if ( task == 'submit' ) {
		
		jQuery( '#frmsubmit' ).attr( 'disabled', 'true' );
		
		if ( jQuery( '#validusername' ).val() == '1') {
			jQuery( '#item-form' ).submit();
		}
	}
}


/**
 * Reset the change username form
 * @since		2.4.9
 */
function resetValid()
{
	var msg		= jQuery( '#servermsg' );
	var val		= jQuery( '#validusername' );
	var formsub	= jQuery( '#frmsubmit' );
	
	val.attr( 'value', '0' );
	msg.removeClass( 'invalid' ).removeClass( 'valid' ).html( '' );
	formsub.attr( 'disabled', 'true' );
}


/**
 * Perform username validation
 * @param		string	- username : contains the username to validate
 */
function validateUsername(username)
{
	var cmsg	= jQuery( '#servermsg' );
	cmsg.removeClass( 'invalid' ).removeClass( 'valid' ).addClass( 'checking' ).html( 'Checking Username...' );
	
	var val		= jQuery( '#validusername' );
	val.val( 0 );
	
	var jid		= jQuery( '#joomlaid' );
	
	jQuery( '#frmsubmit' ).attr( 'disabled', 'true' );
	
	jQuery.ajax({
		type: 'POST',
		url: jQuery( '#thisurl' ).val() + "?option=com_jwhmcs",
		data: 'controller=changeusername&task=validateUsername&username=' + URLEncode( username ) + '&joomlaid=' + jid.val(),
	}).success( function ( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		if ( obj.result == true ) {
			cmsg.removeClass( 'checking' ).addClass( 'valid' ).html( obj.message );
			val.val( 1 );
			jQuery( '#frmsubmit' ).removeAttr( 'disabled' );
		}
		else if ( obj.result == false ) {
			cmsg.removeClass( 'checking' ).addClass( 'invalid' ).html( obj.message );
			jQuery( '#frmsubmit' ).attr( 'disabled', 'true' );
		}
		else {
			alert( 'Unknown error' );
		}
		
	});
	return;
}


/**
 * Password Strength 
 * @param pw
 * @returns {Number}
 */
function getPasswordStrength( pw )
{
	var pwlength	= (pw.length);
	
	if ( pwlength > 5 ) pwlength = 5;
	
	var numnumeric	= pw.replace( /[0-9]/g, "" );
	var numeric		= ( pw.length - numnumeric.length );
	
	if ( numeric > 3 ) numeric=3;
	
	var symbols		= pw.replace( /\W/g, "" );
	var numsymbols	= ( pw.length - symbols.length );
	
	if ( numsymbols > 3 ) numsymbols=3;
	
	var numupper	= pw.replace( /[A-Z]/g, "" );
	var upper		= ( pw.length - numupper.length );
	
	if ( upper > 3 ) upper=3;
	
	var pwstrength	= ( ( pwlength * 10 ) - 20 ) + ( numeric * 10 ) + ( numsymbols * 15 ) + ( upper * 10 );
    
	if ( pwstrength < 0 ) {
		pwstrength = 0
	}
	
    if ( pwstrength > 100 ){
    	pwstrength=100
    }
    
    return pwstrength;
}


/**
 * Compares the two password on User registration form
 */
function comparePW() {
	var img		= jQuery( '#pass2Result' );
	var pass1	= jQuery( '#newpw' ).val();
	var pass2	= jQuery( '#password2' ).val();
	var pval	= jQuery( '#password2Valid' );

	img.removeClass( 'imgnotice imgrequired imgvalid imginvalid' );
	
	if ( pass1 != pass2 ) {
		pval.val( '' );
		img.addClass('imginvalid');
	}
	else {
		pval.val( '1' );
		img.addClass('imgvalid');
	}
}


/**
 * User registration check function
 */
function hasInfo(type, value)
{
	var img = jQuery( '#' + type + 'Result' );
	var val = jQuery( '#' + type + 'Valid' );
	
	img.removeClass( 'imgnotice imgrequired imgvalid imginvalid' );
	
	if (! value ) {
		val.val( '' );
		img.addClass( 'imginvalid' );
	} else {
		val.val( '1' );
		img.addClass( 'imgvalid' );
	}
}


/**
 * Check if username email etc are valid (registration form)
 */
function validInfo( type, value )
{
	var cmsg 	= jQuery( '#message' );
	var img 	= jQuery( '#' + type + 'Result' );
	var val 	= jQuery( '#' + type + 'Valid' );
	var thisurl	= jQuery( '#thisurl' );
	var url 	= thisurl.val() + '&task=validInfo&type=' + URLEncode( type ) + '&value=' + URLEncode( value );
	
	cmsg.removeClass( 'msginvalid msgvalid' ).addClass( 'msgnotice' ).html ( jQuery( '#' + type + 'Checkmsg' ).val() );
	img.removeClass( 'imginvalid imgrequired imgnotice imgvalid' ).addClass( 'imgcheck' );
	val.val( 0 );
	
	jQuery.ajax({
		type: 'GET',
		url: url,
	}).success( function ( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		cmsg.html( obj.message );
		
		if ( obj.result == '1' ) {
			cmsg.removeClass( 'msgnotice' ).addClass( 'msgvalid' );
			img.removeClass( 'imgcheck' ).addClass( 'imgvalid' );
			val.val( 1 );
		}
		else if ( obj.result == false ) {
			cmsg.removeClass( 'msgnotice' ).addClass( 'msginvalid' );
			img.removeClass( 'imgcheck' ).addClass( 'imginvalid' );
		}
		else {
			alert( 'Unknown error' );
		}
		
	});
	return;
}


/**
 * Used by the check install screen in backend
 * @param		step
 * @param		last
 * @param		caller
 */
function beginCheck(step,last,caller)
{
	jQuery( '#laststep').val(last);
	
	for( i=step; i<=last; i=i+10 ) {
		jQuery( '#checkStep' + i ).removeClass( 'ajaxLoading ajaxSuccess ajaxError ajaxAlert' );
		jQuery( '#checkMessage' + i).html('');
	}
	
	runCheck(step);
}


/**
 * Called by beginCheck above to perform ajax checks of installation 
 * @param		step
 */
function runCheck(step)
{
	var ajaxStatus	= jQuery( '#checkStep' + step );
	var ajaxMessage	= jQuery( '#checkMessage' + step );
	var laststep	= jQuery( '#laststep' ).val();
	
	ajaxStatus.removeClass( 'ajaxInitial' ).addClass( 'ajaxLoading' );
	ajaxMessage.html( '' );
	
	jQuery.ajax({
		type: 'POST',
		url: jQuery( '#thisUrl' ).val() + "?option=com_jwhmcs",
		data: 'controller=ajax&task=checkinstall&step=' + step,
	}).success( function ( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		if ( typeof obj.message != 'undefined' ) {
			var txt = '';
			for (i=0; i<obj.message.length; i++) {
				txt = obj.message[i] + "\n" + txt;
			}
			ajaxMessage.html( txt );
		}
		
		jQuery( '#step' ).val( obj.nextstep );
		
		if ( obj.status == '1' ) {
			ajaxStatus.addClass( 'ajaxSuccess' );
		}
		else if ( obj.status == '0' ) {
			ajaxStatus.addClass( 'ajaxError' );
		}
		else {
			ajaxStatus.addClass('ajaxAlert');
		}
		
		if ( step != laststep ) {
			runCheck( obj.nextstep );
		}
	});
	return;
}


/**
 * Fixes any items in the check install
 * @param		step
 */
function beginFix( step )
{
	jQuery( '#checkStep' + step ).removeClass( 'ajaxLoading ajaxSuccess ajaxError ajaxAlert' );
	jQuery( '#checkMessage' + step ).html( '' );
	
	runFix( step );
}


/**
 * Runs a fix attempt on a given step
 * @param		step
 */
function runFix( step )
{
	var ajaxStatus	= jQuery( '#checkStep' + step );
	var ajaxMessage	= jQuery( '#checkMessage' + step );
	
	ajaxStatus.removeClass( 'ajaxInitial' ).addClass( 'ajaxLoading' );
	ajaxMessage.html( '' );
	
	jQuery.ajax({
		type: 'POST',
		url: jQuery( '#thisUrl' ).val() + "?option=com_jwhmcs",
		data: 'controller=ajax&task=fixinstall&step=' + step,
	}).success( function ( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		var txt = '';
		
		if ( typeof obj.message != 'undefined' ) {
			for (i=0; i<obj.message.length; i++) {
				txt = obj.message[i] + "\n" + txt;
			}
			
		}
		
		ajaxMessage.html( txt );
		
		if ( obj.status == '1' ) {
			ajaxStatus.addClass( 'ajaxSuccess' );
		}
		else if ( obj.status == '0' ) {
			ajaxStatus.addClass( 'ajaxError' );
		}
		else {
			ajaxStatus.addClass('ajaxAlert');
		}
	});
	return;
}


/**
 * Used to check the API connection in the API Connection Manager (backend)
 */
function checkAPIInterface()
{
	var apiusername	= jQuery( '#jwhmcsadminus' ).val();
	var apipassword	= jQuery( '#jwhmcsadminpw' ).val();
	var apiaxskey	= jQuery( '#accesskey' ).val();
	var whmcsurl	= jQuery( '#jwhmcsurl' ).val();
	
	var apistatusimg	= jQuery( '#apistatusimg' );
	apistatusimg.removeClass( 'ajaxSuccess ajaxError' ).addClass( 'ajaxLoading' );
	
	var apistatusmsg	= jQuery( '#apistatusmsg' );
	apistatusmsg.html( jQuery( '#apistatusmsgdefault' ).val() );
	
	jQuery.ajax({
		type: 'POST',
		url: "index.php?option=com_jwhmcs&controller=ajax&task=checkAPIInterface",
		data: 'jwhmcsadminus=' + apiusername + '&jwhmcsadminpw=' + apipassword + '&accesskey=' + apiaxskey + '&jwhmcsurl=' + whmcsurl,
	}).success( function ( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		apistatusmsg.html( obj.message );
		
		if ( obj.result == 'success' ) {
			apistatusimg.removeClass( 'ajaxLoading' ).addClass( 'ajaxSuccess' );
			jQuery( '#apiconnection' ).val( '1' );
		}
		else {
			apistatusimg.addClass('ajaxAlert');
		}
	});
	return;
}


/**
 * Performs the license check for the backend license manager
 */
function checkLicense()
{
	var license	= jQuery( '#licensekey' ).val();
	
	var statusimg	= jQuery( '#whmcsstatusimg' );
	statusimg.removeClass( 'ajaxSuccess ajaxError' ).addClass( 'ajaxLoading' );
	
	var statusmsg	= jQuery( '#whmcsstatusmsg' );
	statusmsg.html( jQuery( '#whmcsstatusmsgdefault' ).val() );
	
	jQuery.ajax({
		type: 'POST',
		url: "index.php?option=com_jwhmcs&controller=ajax&task=checkValidLicense",
		data: 'license=' + license,
	}).success( function ( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		statusmsg.html( obj.message );
		
		if ( obj.result == 'success' ) {
			statusimg.removeClass( 'ajaxLoading' ).addClass( 'ajaxSuccess' );
			jQuery( '#license' ).val( '1' );
		}
		else {
			statusimg.addClass('ajaxAlert');
		}
	});
	return;
}


/**
 * Handles the installation process on the interviewer
 * @param step
 */
function runInstall(step)
{
	var ajaxLog		= jQuery( '#ajaxLog' );
	
	var whmcspath	= encodeURIComponent( jQuery( '#whmcspath' ).val() );
	
	var ajaxStat	= jQuery( '#ajaxStatus' );
	ajaxStat.removeClass( 'ajaxInitial' ).addClass( 'ajaxLoading' );
	
	var ajaxMsgs	= jQuery( '#ajaxMessage' );
	ajaxMsgs.removeClass( 'ajaxMessageInitial' ).addClass( 'ajaxMessageLoading' ).html( 'Installing' );
	
	jQuery.ajax({
		type: 'POST',
		url: jQuery( '#thisUrl' ).val() + '?option=com_jwhmcs&controller=ajax&task=interview',
		data: 'whmcspath=' + whmcspath + '&step=' + step,
	}).success( function ( msg ) {
		var obj = jQuery.parseJSON( msg );
		var txt = ajaxLog.html();
		
		if ( typeof obj.message != 'undefined' ) {
			for (i=0; i<obj.message.length; i++) {
				txt = '<span>' + obj.message[i] + "</span>\n" + txt;
			}
		}
		
		ajaxLog.html( txt );
		jQuery( '#step' ).val( obj.nextstep );
		
		if ( obj.nextstep == '110' || obj.nextstep == '210' ) {
			ajaxCheckAPI( obj.nextstep );
		}
		else if ( obj.nextstep == '150' || obj.nextstep == '155' || obj.nextstep == '250' || obj.nextstep == '255' ) {
			ajaxCheckLicense();
		}
		else if ( obj.nextstep == '1000' ) {
			completeInstall();
		}
		else {
			runInstall( obj.nextstep );
		}
	});
}


/**
 * Check the API connection used by installer
 * @param step
 */
function ajaxCheckAPI(step)
{
	var whmcsurl		= jQuery( '#whmcsurl' ).val();
	var jwhmcsadminus	= jQuery( '#jwhmcsadminus' ).val();
	var jwhmcsadminpw	= jQuery( '#jwhmcsadminpw' ).val();
	var accesskey		= jQuery( '#accesskey' ).val();
	
	var ajaxLog			= jQuery( '#ajaxLog' );
	var origStep		= jQuery( '#step' );
	var reqApi			= jQuery( '#reqApi' );
	var textWelcome		= jQuery( '#textWelcome' );
	var textApivalid	= jQuery( '#textApivalid' );
	var reqWhmcsPath	= jQuery( '#reqWhmcsPath' );
	
	var ajaxStat		= jQuery( '#ajaxStatus' );
	ajaxStat.removeClass( 'ajaxWaiting' ).addClass( 'ajaxLoading' );
	
	var ajaxMsgs		= jQuery( '#ajaxMessage' );
	ajaxMsgs.removeClass( 'ajaxMessageWaiting' ).addClass( 'ajaxMessageLoading' ).html( 'Checking API Username and Password...' );
	
	jQuery.ajax({
		type: 'POST',
		url: jQuery( '#thisUrl' ).val() + '?option=com_jwhmcs&controller=ajax&task=interview',
		data: 'jwhmcsadminus=' + jwhmcsadminus + '&jwhmcsadminpw=' + jwhmcsadminpw + '&whmcsurl=' + whmcsurl + '&accesskey=' + accesskey + '&step=' + step,
	}).success( function ( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		if ( obj.valid == true) {
			var txt = ajaxLog.html();
			
			if ( typeof obj.message != 'undefined' ) {
				for (i=0; i<obj.message.length; i++) {
					txt = '<span>' + obj.message[i] + "</span>\n" + txt;
				}
			}
			
			ajaxLog.html( txt );
			jQuery( '#step' ).val( obj.nextstep );
			
			reqApi.css({ visibility: 'collapse', display: 'none' });
			textWelcome.removeClass( 'visDisplay' ).addClass( 'visHidden' );
			textApivalid.removeClass( 'visHidden' ).addClass( 'visDisplay' );
			
			/* Display path request */
			ajaxMsgs.html( 'Enter Path to WHMCS' );
			reqWhmcsPath.css({ visibility: 'visible', display: 'inherit' });
			textApivalid.removeClass( 'visDisplay' ).addClass( 'visHidden' );
			ajaxStat.removeClass( 'ajaxLoading' ).addClass( 'ajaxWaiting' );
			ajaxMsgs.removeClass( 'ajaxMessageLoading' ).addClass( 'ajaxMessageWaiting' )
		}
		else {
			ajaxStat.removeClass( 'ajaxLoading' ).addClass( 'ajaxWaiting' );
			ajaxMsgs.removeClass( 'ajaxMessageLoading' ).addClass( 'ajaxMessageWaiting' );
			
			reqApi.css({ visibility: 'visible', display: 'inherit' });
			textWelcome.removeClass('visDisplay').addClass('visHidden');
			ajaxMsgs.html( obj.message[0] );
		}
		
	});
}


/**
 * Verifies a path provided by admin user in installer
 */
function verifyPath()
{
	var step		= jQuery( '#step' ).val();
	var whmcspath	= encodeURIComponent( jQuery( '#whmcspath' ).val() );
	var ajaxLog		= jQuery( '#ajaxLog' );
	
	var ajaxStat	= jQuery( '#ajaxStatus' );
	ajaxStat.removeClass( 'ajaxWaiting' ).addClass( 'ajaxLoading' );
	
	var ajaxMsgs	= jQuery( '#ajaxMessage' );
	ajaxMsgs.removeClass( 'ajaxMessageWaiting' ).addClass( 'ajaxMessageLoading' ).html( 'Checking Path...' );
	
	var origStep		= jQuery( '#step' ).val();
	var reqWhmcsPath	= jQuery( '#reqWhmcsPath' );
	var textApivalid	= jQuery( '#textApivalid' );
	var textFileinstall	= jQuery( '#textFileinstall' );
	
	jQuery.ajax({
		type: 'POST',
		url: jQuery( '#thisUrl' ).val() + '?option=com_jwhmcs&controller=ajax&task=verifyPath',
		data: 'whmcspath=' + whmcspath + '&step=' + step,
	}).success( function ( msg ) {
		var obj = jQuery.parseJSON( msg );
		var txt = ajaxLog.html();
		
		if ( typeof obj.message != 'undefined' ) {
			for (i=0; i<obj.message.length; i++) {
				txt = '<span>' + obj.message[i] + "</span>\n" + txt;
			}
		}
		
		ajaxLog.html( txt );
		
		if ( obj.valid == true ) {
			jQuery( '#step' ).val( obj.nextstep );
			reqWhmcsPath.css({ visibility: 'collapse', display: 'none' });
			ajaxStat.removeClass( 'ajaxWaiting' ).addClass( 'ajaxLoading' );
			ajaxMsgs.removeClass( 'ajaxMessageWaiting' ).addClass( 'ajaxMessageLoading' ).html( 'Installing' );
			textApivalid.removeClass( 'visDisplay' ).addClass( 'visHidden' );
			textFileinstall.removeClass( 'visHidden' ).addClass( 'visDisplay' );
			runInstall( obj.nextstep );
		}
		else {
			ajaxStat.removeClass( 'ajaxLoading' ).addClass( 'ajaxWaiting' );
			ajaxMsgs.removeClass( 'ajaxMessageLoading' ).addClass( 'ajaxMessageWaiting' ).html( 'Path Error' );
			reqWhmcsPath.css({ visibility: 'visible', display: 'inherit' });
			textApivalid.removeClass( 'visDisplay' ).addClass( 'visHidden' );
		}
	});
}


/**
 * Verifies FTP credentials during installation
 */
function verifyFtp()
{
	var step		= jQuery( '#step' ).val();
	var hostname	= encodeURIComponent( jQuery( '#FtpHostname' ).val() );
	var port		= encodeURIComponent( jQuery( '#FtpPort' ).val() );
	var username	= encodeURIComponent( jQuery( '#FtpUsername' ).val() );
	var password	= encodeURIComponent( jQuery( '#FtpPassword' ).val() );
	
	
	
	
	var ajaxStat		= jQuery( '#ajaxStatus' );
	ajaxStat.removeClass( 'ajaxWaiting' ).addClass( 'ajaxLoading' );
	
	var ajaxMsgs		= jQuery( '#ajaxMessage' );
	ajaxMsgs.removeClass('ajaxMessageWaiting').addClass('ajaxMessageLoading').html( 'Verifying Credentials - This may take a moment' );
	
	var ajaxLog			= jQuery( '#ajaxLog' );
	var reqFtp			= jQuery( '#reqFtp' );
	var textWelcome		= jQuery( '#textWelcome' );
	var textApivalid	= jQuery( '#textApivalid' );
	
	
	jQuery.ajax({
		type: 'POST',
		url: jQuery( '#thisUrl' ).val() + '?option=com_jwhmcs&controller=ajax&task=verifyFtp',
		data: 'hostname=' + hostname + '&port=' + port + '&username=' + username + '&password=' + password + '&step=' + step,
	}).success( function ( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		if ( obj.valid == true ) {
			
			var txt = ajaxLog.html();
			
			if ( typeof obj.message != 'undefined' ) {
				for (i=0; i<obj.message.length; i++) {
					txt = '<span>' + obj.message[i] + "</span>\n" + txt;
				}
			}
			
			ajaxLog.html( txt );
			
			jQuery( '#step' ).val( obj.nextstep );
			
			
			reqFtp.css({ visibility: 'collapse', display: 'none' });
			ajaxStat.removeClass( 'ajaxWaiting' ).addClass( 'ajaxLoading' );
			ajaxMsgs.removeClass( 'ajaxMessageWaiting' ).addClass( 'ajaxMessageLoading' ).html( 'Installing' );
			textApivalid.removeClass( 'visDisplay' ).addClass( 'visHidden' );
			textFileinstall.removeClass( 'visHidden' ).addClass( 'visDisplay' );
			runInstall( obj.nextstep );
		}
		else {
			ajaxStat.removeClass( 'ajaxLoading' ).addClass( 'ajaxWaiting' );
			ajaxMsgs.removeClass( 'ajaxMessageLoading' ).addClass( 'ajaxMessageWaiting' ).html( obj.message );
		}
	});
}


/**
 * Performs a check of the license at installation
 */
function ajaxCheckLicense()
{
	var step		= jQuery( '#step' ).val();
	var whmcspath	= encodeURIComponent( jQuery( '#whmcspath' ).val() );
	var license		= encodeURIComponent( jQuery( '#licensekey' ).val() );
	
	var ajaxStat	= jQuery( '#ajaxStatus' );
	ajaxStat.removeClass( 'ajaxWaiting' ).addClass( 'ajaxLoading' );
	
	var ajaxMsgs	= jQuery( '#ajaxMessage' );
	ajaxMsgs.removeClass( 'ajaxMessageWaiting' ).addClass( 'ajaxMessageLoading' ).html( 'Checking License...' );
	
	var ajaxLog		= jQuery( '#ajaxLog' );
	var reqLicense	= jQuery( '#reqLicense' );
	
	var textFileinstall		= jQuery( '#textFileinstall' );
	var textLicensevalid	= jQuery( '#textLicensevalid' );
	
	jQuery.ajax({
		type: 'POST',
		url: jQuery( '#thisUrl' ).val() + '?option=com_jwhmcs&controller=ajax&task=interview',
		data: 'whmcspath=' + whmcspath + '&license=' + license + '&step=' + step,
	}).success( function ( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		if ( obj.valid == true ) {
			var txt = ajaxLog.html();
			
			if ( typeof obj.message != 'undefined' ) {
				for (i=0; i<obj.message.length; i++) {
					txt = '<span>' + obj.message[i] + "</span>\n" + txt;
				}
			}
			
			ajaxLog.html( txt );
			
			jQuery( '#step' ).val( obj.nextstep );
			
			reqLicense.css({ visibility: 'collapse', display: 'none' });
			ajaxStat.removeClass( 'ajaxWaiting' ).addClass( 'ajaxLoading' );
			ajaxMsgs.removeClass( 'ajaxMessageWaiting' ).addClass( 'ajaxMessageLoading' ).html( 'Installing' );
			textFileinstall.removeClass( 'visDisplay' ).addClass( 'visHidden' );
			textLicensevalid.removeClass( 'visHidden' ).addClass( 'visDisplay' );
			
			runInstall( obj.nextstep );
		}
		else {
			ajaxStat.removeClass( 'ajaxLoading' ).addClass( 'ajaxWaiting' );
			ajaxMsgs.removeClass( 'ajaxMessageLoading' ).addClass( 'ajaxMessageWaiting' );
			reqLicense.css({ visibility: 'visible', display: 'inherit' });
			textFileinstall.removeClass( 'visDisplay' ).addClass( 'visHidden' );
			
			var upgrade	= jQuery( '#upgrade' ).val();
			
			if ( upgrade == false ) {
				ajaxMsgs.html( 'License Invalid' );
			}
			else {
				ajaxMsgs.html( upgrade );
			}
		}
		
	});
}



/**
 * Complete installation function
 */
function completeInstall()
{
	var txtLic	= jQuery( '#textLicensevalid' );
	var txtCom	= jQuery( '#textComplete' );
	txtLic.removeClass( 'visDisplay' ).addClass( 'visHidden' );
	txtCom.removeClass( 'visHidden' ).addClass( 'visDisplay' );
	
	var ajaxLog	= jQuery( '#ajaxLog' ).html();
	
	jQuery( '#installLog' ).val( jQuery( '#ajaxLog' ).html() );
	
	jQuery( '#item-form' ).submit();
}