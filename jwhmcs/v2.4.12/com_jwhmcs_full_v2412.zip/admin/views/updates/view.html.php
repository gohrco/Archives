<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.4.12 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.4.0
 * 
 * @desc       This is the updates view file for the backend of J!WHMCS Integrator
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.view' );
if ( file_exists( $path = JPATH_COMPONENT_ADMINISTRATOR . DS . 'update' . DS . 'update.php' ) )
	require_once( $path );
/*-- File Inclusions --*/

/**
 * J!WHMCS Integrator Updates View
 * @author		Steven
 * @version		2.4.12
 * 
 * @since		2.4.0
 */
class JwhmcsViewUpdates extends JwhmcsView
{
	
	/**
	 * Display view
	 * @access		public
	 * @version		2.4.12
	 * @param		string		- $tpl: contains a template to overload with
	 * 
	 * @return		parent :: display()
	 * @since		2.4.0
	 */
	function display( $tpl = null )
	{
		$updates	=   JwhmcsUpdate :: getSortedList( true );
		
		// Retrieve ACL permitted actions
		$canDo	= JwhmcsHelper :: getActions();
		
		JwhmcsToolbar :: build( 'updates', null, $canDo );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JwhmcsHelper :: addMedia( 'icons35/css' );
		}
		else {
			JwhmcsHelper :: addMedia( 'icons/css' );
		}
		
		$this->updates		= $updates;
		
		parent::display($tpl);
	}
	
	
	/**
	 * Displays the proces view
	 * @access		public
	 * @version		2.4.12
	 * @param		string		- $tpl: conains the template to overload with
	 * 
	 * return		parent :: display()
	 * @since		2.4.0
	 */
	function process( $tpl = null )
	{
		$this->setLayout( 'process' );
		
		parent::display($tpl);
	}
}