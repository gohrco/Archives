<?php
/**
 * Default Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: usermgr.php 569 2012-09-28 12:00:42Z steven_gohigher $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * Used to handle user management from the view and controller of J!WHMCS Integrator
 * @version		2.4.12
 *
 * @author		Steven
 * @since		1.5.1
 */
class JwhmcsModelUsermgr extends JwhmcsModel
{
	
	public $_data			= array();
	public $_total			= null;
	public $_pagination		= null;
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		2.4.12
	 * 
	 * @since		1.5.1
	 */
	public function __construct()
	{
		parent::__construct();
		
		$app	= & JFactory::getApplication();
		
		// Set $this->_id to array containing selected ids
		$array = JwhmcsHelper :: get('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
		
		// Get pagination request variables
		$limit			= $app->getUserStateFromRequest('global.list.limit', 'limit', $app->getCfg('list_limit'), 'int');
		$limitstart		= $app->getUserStateFromRequest('com_jwhmcs.limitstart', 'limitstart', 0, 'int');
		$search			= $app->getUserStateFromRequest('com_jwhmcs.user_search', 'user_search', '', 'string');
		$search			= JString::strtolower($search);
		
		// In case limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
		$this->setState('user_search', $search);
	}
	
	
	/**
	 * Method to clean up duplicates and errant cross references
	 * @access		public
	 * @version		2.4.12
	 * 
	 * @return		true or string containiner end of error string
	 * @since		2.4.6
	 */
	public function cleanup( $step = 1 )
	{
		$db	= & JFactory :: getDbo();
		$query		= "SELECT `xref_a` as xa, `xref_type` as xt, `xref_b` as xb FROM #__jwhmcs_xref ORDER BY xref_a";
		$db->setQuery( $query );
		
		$results = $db->loadObjectList();
		
		switch ( $step ) :
		
		// Find actual users that got removed due to duplicates
		case 4:
			
			$this->matchAll();
			
			break;
		
		// Find duplicates in the xref table
		case 3:
		
			// xa => Joomla users, xbc => WHMCS clients, xbt => WHMCS contacts
			$data	= array( 'xa' => array(), 'xbc' => array(), 'xbt' => array() );
			
			foreach( $results as $result ) {
				
				$type	= ( in_array( $result->xt, array( '1', '2', '3', '8' ) ) ? 'xbc' : 'xbt' );
				if (! isset( $data['xa'][$result->xa] ) ) $data['xa'][$result->xa] = array();
				if (! isset( $data[$type][$result->xb] ) ) $data[$type][$result->xb] = array();
				
				$data['xa'][$result->xa][]	= $result;
				$data[$type][$result->xb][]	= $result;
			}
			
			foreach( $data as $set ) {
				foreach ( $set as $items ) {
					if ( count( $items ) == 1 ) continue;
					
					foreach( $items as $item ) {
						$this->syncBreak( (array) $item );
					}
				}
			}
			
			// Find any actual users that got broken
			$this->cleanup( 4 );
			
			break;
			
		// Find broken users
		case 2:
			
			if ( version_compare( JVERSION,'1.6.0', 'ge' ) ) {
				
			}
			else {
				$query = "DELETE FROM #__users WHERE gid = '0' AND usertype = ''";
				$db->setQuery( $query );
				$db->query();
			}
			
			// Find duplicates in the xref table
			$this->cleanup( 3 );
			
			break;
			
		// Find users to ensure they exist
		case 1:
		default:
			
			if (! $results ) return 'NOXREF';
			
			// Cycle through and catch missing users
			foreach( $results as $result ) {
				
				// Lets load the Joomla user first
				$user = JUser :: getInstance( $result->xa );
				
				// Check for existing Joomla user first
				if (! $user->id ) {
					$this->syncBreak( (array) $result );
					continue;
				}
				
				// Now lets try to find the WHMCS users
				$whmcs	= JwhmcsHelper :: getWhmcsuser( $result->xb, 'id', ( in_array( $result->xt, array( '1', '2', '3', '8' ) ) ? 'client' : 'contact' ) );
				
				// Check for existing WHMCS user now
				if (! $whmcs ) {
					$this->syncBreak( (array) $result );
					continue;
				}
				
				// Verify the two users have the same email address still
				if ( $whmcs['email'] != $user->email ) {
					$this->syncBreak( (array) $result );
					continue;
				}
			}
			
			// Find any broken users
			$this->cleanup( 2 );
			
			break;
			
		endswitch;
		
		return true;
	}
	
	
	/**
	 * Method to get the data for display
	 * @access		public
	 * @version		2.4.12
	 * @version		2.0.2		- February 2010: changed where data for force add was coming from
	 * 
	 * @since		1.5.1
	 */
	public function getData( $task = null )
	{
		$app	= & JFactory::getApplication();
		$db		= & JFactory::getDBO();
		$uri	= & JURI::getInstance();
		$jcurl	= & JwhmcsCurl::getInstance();
		
		$filter_order		= $app->getUserStateFromRequest( "com_jwhmcs.sortby",		'sortby',	'a.name',	'cmd' );
		$filter_order_Dir	= $app->getUserStateFromRequest( "com_jwhmcs.sortord",		'sortord',	'',			'word' );
		$filter_type		= $app->getUserStateFromRequest( "com_jwhmcs.filter_type",		'filter_type', 		0,			'string' );
		$search				= $app->getUserStateFromRequest( "com_jwhmcs.search",			'search', 			'',			'string' );
		$search				= JString::strtolower( $search );
		
		$limit				= $app->getUserStateFromRequest( 'global.list.limit', 'limit', $app->getCfg('list_limit'), 'int' );
		$limitstart			= $app->getUserStateFromRequest( 'com_jwhmcs.limitstart', 'limitstart', 0, 'int' );
		
		// All this for the icon images...
		$urlpath		= $uri->base().'components/com_jwhmcs/assets/icons/';
		$img			= array();
		$img['match']	= $urlpath.'Security.png';
		$img['alert']	= $urlpath.'Alert.png';
		$img['error']	= $urlpath.'Close.png';
		
		// Switch off on tasks
		switch ($task):
		case 'joomadd':			// Add new user to Joomla DB
		case 'joomedit':		// Edit existing user in Joomla DB
			// 0:  Initialize Variables
			$contact = false;
			if ($wid = JwhmcsHelper :: get( 'wcontid' )) {
				$contact = true;
			}
			else {
				$wid	= JwhmcsHelper :: get( 'whmcsid' );
			}
			
			// 1:  Retrieve user data from Jwhmcs User table and bind to wuser
			$query	= "SELECT * FROM #__jwhmcs_user".($contact ? "sub" : "" )." WHERE id = $wid";
			$db->setQuery($query);
			$wuser	= $db->loadAssoc();
			
			// 3:  Get the Joomla user info (if set)
			if ($joomlaid	= JwhmcsHelper :: get( 'joomlaid' ))
			{
				$query = 'SELECT a.*, g.name AS groupname'
						. ' FROM #__users AS a'
						. ' INNER JOIN #__core_acl_aro AS aro ON aro.value = a.id'
						. ' INNER JOIN #__core_acl_groups_aro_map AS gm ON gm.aro_id = aro.id'
						. ' INNER JOIN #__core_acl_aro_groups AS g ON g.id = gm.group_id'
						. ' WHERE a.id = '.$joomlaid
						. ' GROUP BY a.id';
				$db->setQuery($query);
				$juser	= $db->loadAssoc();
				
				// 4a: Assign data variables for existing Joomla user
				$this->_data['name']		= $juser['name'];
				$this->_data['email']		= $juser['email'];
				$this->_data['username']	= $juser['username'];
				$this->_data['gid']			= $juser['groupname'];
			} else {
				// 4b: No user from Joomla exists, so assign email as default value
				$this->_data['email']	= $wuser['email'];
				$this->_data['gid']		= 'Registered';
				$this->_data['id']		= 0;
			}
			
			// 5:  Build Groupbox
			if (! version_compare( JVERSION, '1.6.0', 'ge' ) ) {
				$acl		= & JFactory::getACL();
				$gtree		=   $acl->get_group_children_tree( null, 'USERS', false );
				$groups		=   JHtml::_('select.genericlist',   $gtree, 'form[gid]', 'size="10"', 'value', 'text', $this->_data['id'] );
			}
			
			$this->_data['gidtypes']	= ( version_compare( JVERSION, '1.6.0', 'ge' ) ? JHtml::_("access.usergroup", "form[gid]", $this->_data['gid'] ) : $groups );
			$this->_data['wid']			= $wid;
			$this->_data['contact'] 	= ($contact ? true : false );
			break;
		
		case 'whmcsadd':		// Add new user to WHMCS DB
		case 'whmcsedit':		// Edit existing user in WHMCS DB
			$jid	= JwhmcsHelper :: get( 'joomlaid' );
			$query	= 'SELECT a.email FROM #__users AS a WHERE a.id = '.$jid;
			$db->setQuery($query);
			$jemail	= $db->loadResult();
			
			// get the ID of selected user
			if ($clientid = JwhmcsHelper :: get( 'whmcsid' ))
			{
				$jcurl->setAction('getclientsdata', array('clientid' => $clientid));
				$this->_data = $jcurl->loadResult();
				$this->_data['jid']	= $jid;
			} else {
				$this->_data['email']	= $jemail;
				$this->_data['jid']		= $jid;
				$this->_data['id']		= 0;
			}
			
			break;
		default:
			// Retrieve sort values from JRequest, set defaults otherwise
			$qp['sortby']	= (JwhmcsHelper :: get( 'sortby' ) ? JwhmcsHelper :: get( 'sortby' ) : 'wlname' );
			$qp['sortord']	= (JwhmcsHelper :: get( 'sortord' ) ? (JwhmcsHelper :: get( 'sortord' ) == 1 ? 'ASC':'DESC') : 'ASC' );
			
			// Create Joomla user query
			$query	= $this->_buildQuery($task, $qp);
			$qry = str_replace('#_', 'jos', $query);
			
			// Retrieve users from Joomla
			$db->setQuery( $query, $limitstart, $limit ); 
			$items = $db->loadObjectList();
			
			// Fetch Pagination
			jimport('joomla.html.pagination');
			$pagination = new JPagination($this->getTotal($query), $limitstart, $limit );
			
			$this->_data['data']			= $items;
			$this->_data['pagination']	= $pagination;
			
		endswitch;
		
		return (object) $this->_data;
	}
	
	
	/**
	 * Method to save the new or edited joomla user info
	 * @access		public
	 * @version		2.4.12
	 * @version		2.4.10		- Oct 2012: Incorporated same registration methods as front end to handle 
	 * @version		2.4.0		- May 2012: offloaded user sync to appropriate method
	 * @param		array		- $form: contains the passed data
	 * @param		string		- $task: what we are doing
	 * 
	 * @return		boolean
	 * @since		1.5.1
	 */
	public function joomsave( $form, $task )
	{
		// 0:  Initialize variables
		$db				= & JFactory::getDBO();
		$params			= & JwhmcsParams::getInstance();
		$authorize		= & JFactory::getACL();
		$usersConfig	= & JComponentHelper::getParams( ( version_compare( JVERSION, '1.6.0', 'ge' ) ? 'com_users' : 'com_user' ) );
		$config			= & JFactory::getConfig();
		$date			= & JFactory::getDate();
		
		$user			=   ( $task == 'joomeditsave' ) ? new JUser( JwhmcsHelper :: get( "joomlaid" ) ) : new JUser();
		$original_gid	=   $user->get('gid');
		
		JwhmcsHelper :: checkToken() or jexit( 'Invalid Token' );
		
		// ===================================================================
		// Build the user array for binding
		$ubind = JwhmcsHelper::getUserArray( "joomla", $form );
		
		// ===================================================================
		// Initialize new usertype setting
		$newUsertype = $usersConfig->get( 'new_usertype' );
		
		// ===================================================================
		// If user activation is turned on, we need to set the activation information
		$useractivation = (int) $usersConfig->get( "useractivation" );
		
		// ============================================
		// Joomla 2.5 Handles some stuff before binding
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) )
		{
			// Set J2.5 new user type if not in config file
			if (! $newUsertype ) $newUsertype = 2;
				
			// Add to bind array
			$ubind['groups'][] = $newUsertype;
				
			// Check if the user needs to activate their account.
			// 1 = self; 2 = admin approval
			if (($useractivation == 1) || ($useractivation == 2))
			{
				jimport('joomla.user.helper');
			
				// Yes, 3.0 does things differently but just enough
				if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
					$ubind['activation']	= JApplication :: getHash( JUserHelper :: genRandomPassword() );
				}
				else {
					$ubind['activation']	= JUtility::getHash(JUserHelper::genRandomPassword());
				}
				
				$ubind['block'] = 1;
			}
		}
		// Don't forget to set J1.5 user types if not in config file
		else {
			if (! $newUsertype ) $newUsertype = 'Registered';
		}
		
		// ===========================================
		// ------BIND ARRAY---------------------------
		// ===========================================
		// Bind the post array to the user object
		if (!$user->bind( $ubind, 'usertype' )) {
			JError::raiseError( 500, $user->getError() );
		}
		// ===========================================
		// -------------------------------------------
		// ===========================================
		// Joomla 1.5 Handles some stuff after binding
		if (! version_compare( JVERSION, '1.6.0', 'ge' ) )
		{
			$user->set('id', 0);
			$user->set('usertype', '');
			$user->set('gid', $authorize->get_group_id( '', $newUsertype, 'ARO' ));
			$user->set( 'registerDate', $date->toMySQL() );
				
			// Dont send welcome email by default
			$sendEmail = false;
			if ( $useractivation == '1' ) {
				jimport('joomla.user.helper');
				$user->set( 'activation', JUtility::getHash( JUserHelper::genRandomPassword() ) );
				$user->set( 'block', '1' );
				$sendEmail = true;
			}
		}
		// ===========================================
		// If there was an error with registration, set the message and display form
		if ( !$user->save() ) {
			JError::raiseWarning('', JText::_( $user->getError()));
			return false;
		}
		
		$this->syncUser( $form['email'], ( JwhmcsHelper :: get( 'contact' ) ? 7 : 3 ), JwhmcsHelper :: get( 'whmcsid' ) );
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			// We allow Joomla! 2.5+ to handle the email to be sent out... 1.5 doesn't do it for us
			return true;
		}
		
		$notify	= $useractivation;
		
		$data = $user->getProperties();
		$data['fromname']	= $config->get('fromname');
		$data['mailfrom']	= $config->get('mailfrom');
		$data['sitename']	= $config->get('sitename');
		$data['siteurl']	= JUri::base();
		
		$lang	=   JFactory::getLanguage();
		$lang->load( ( version_compare( JVERSION, '1.6.0', 'ge' ) ? 'com_users' : 'com_user' ), JPATH_ADMINISTRATOR );
		
		switch ( $notify ):
		case '2':
				
			// Set the link to confirm the user email.
			$uri = JURI::getInstance();
			$base = $uri->toString(array('scheme', 'user', 'pass', 'host', 'port'));
			$data['activate'] = $base.JRoute::_('index.php?option=com_users&task=registration.activate&token='.$data['activation'], false);
			
			$emailSubject	= JText::sprintf(
					JText :: _( 'COM_JWHMCS_EMAIL_ACCOUNT_DETAILS' ),
					$data['name'],
					$data['sitename']
			);
			
			$emailBody = JText::sprintf(
					JText :: _( 'COM_JWHMCS_EMAIL_REGISTERED_WITH_ADMIN_ACTIVATION_BODY' ),
					$data['name'],
					$data['sitename'],
					$data['siteurl'].'index.php?option=com_users&task=registration.activate&token='.$data['activation'],
					$data['siteurl'],
					$data['username'],
					$ubind['password']
			);
				
			break;
			
		case '1':
				
			// Set the link to activate the user account.
			$uri = JURI::getInstance();
			$base = $uri->toString(array('scheme', 'user', 'pass', 'host', 'port'));
			$data['activate'] = $base.JRoute::_('index.php?option=com_users&task=registration.activate&token='.$data['activation'], false);
		
			$emailSubject	= JText::sprintf(
					JText :: _( 'COM_JWHMCS_EMAIL_ACCOUNT_DETAILS' ),
					$data['name'],
					$data['sitename']
			);
		
			$emailBody = JText::sprintf(
					JText :: _( 'COM_JWHMCS_EMAIL_REGISTERED_WITH_ACTIVATION_BODY' ),
					$data['name'],
					$data['sitename'],
					$data['siteurl'].'index.php?option=com_users&task=registration.activate&token='.$data['activation'],
					$data['siteurl'],
					$data['username'],
					$ubind['password']
			);
				
			break;
		
		case '0':
				
			$emailSubject	= JText::sprintf(
			JText :: _( 'COM_JWHMCS_EMAIL_ACCOUNT_DETAILS' ),
			$data['name'],
			$data['sitename']
			);
		
			$emailBody = JText::sprintf(
					JText :: _( 'COM_JWHMCS_EMAIL_REGISTERED_BODY' ),
					$data['name'],
					$data['sitename'],
					$data['siteurl']
			);
				
			break;
				
		endswitch;
		
		JwhmcsHelper :: sendMail( $data['mailfrom'], $data['fromname'], $data['email'], $emailSubject, $emailBody );
		
		return true;
	}
	
	
	/**
	 * Method to save a new or edited WHMCS user
	 * @access		public
	 * @version		2.4.12
	 * @version		2.4.0		- May 2012: offloaded xref and user sync to appropriate model methods
	 * @param		array		- $form: contains the passed data
	 * @param		string		- $task: what we are doing
	 * 
	 * @return		result of data request from WHMCS
	 * @since		1.5.1
	 */
	
	function whmcsaddsave( $post, $task )
	{
		// 0:  Initialize variables
		$db		= & JFactory::getDBO();
		$uri	= & JURI::getInstance();
		$jcurl	= & JwhmcsCurl::getInstance();
		
		// 0b: Create duplicate of $post for modifying for WHMCS
		$fields			= $post;
		$fields['currency'] = '1';
		
		// 1a: Create array of fields to unset for storing in WHMCS build fields for storing
		$unsets = array('option', 'whmcsid', 'joomlaid', 'task', 'subtask', 'controller');
		foreach ($unsets as $unset) unset($fields[$unset]);
		
		// 1b: Issue cUrl command to create new WHMCS user
		$fields['action']	= 'addclient';
		
		$jcurl->setAction('addclient', $fields);
		$whmcs	= $jcurl->loadResult();
		
		// If we succeeded
		if ($whmcs['result']=='success')
		{
			// Sync the users
			$sync = & JwhmcsModel :: getInstance( 'sync', 'JwhmcsModel' );
			$sync->reload();
			
			$this->syncUser( $post['email'], 2, $whmcs['clientid'] );
		}
		
		return $whmcs;
	}
	
	
	/**
	 * Method to change a username at next login
	 * @access		public
	 * @version		2.4.12
	 * @param		array		- $post: contains the requested changes
	 *
	 * @return		boolean
	 * @since		2.1.0
	 */
	public function changeUsername($post)
	{
		$db		= & JFactory::getDBO();
		$newxt	=   ( $post['xt'] < 4 ? 8 : 9 );
		
		// We don't allow username changes to groups
		if ( $post['xt'] == 4 )
			return;
		
		// We don't need to change the username for an added user
		if ( $post['xt'] == 3 || $post['xt'] == 7 )
			return;
		
		$query	= "DELETE FROM `#__jwhmcs_xref` WHERE `xref_a` = {$post['xa']} AND `xref_b` = {$post['xb']} AND `xref_type` = {$post['xt']}";
		$db->setQuery($query);
		$db->query();
		
		$query	= "INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`)
					VALUES ({$post['xa']}, $newxt, {$post['xb']})";
		$db->setQuery($query);
		if ($db->query()) return true;
		return false;
	}
	
	
	
	/**
	 * Method to change all usernames
	 * @access		public
	 * @version		2.4.12
	 *
	 * @return		boolean
	 * @since		2.1.0
	 */
	public function changeAllusername()
	{
		$db		= & JFactory::getDBO();
		
		$query	= "SELECT * FROM #__jwhmcs_xref";
		$db->setQuery($query);
		$xrefs	= $db->loadObjectList();
		
		$ret	= true;
		$return	= true;
		foreach ($xrefs as $xref) {
			$x['xa'] = $xref->xref_a;
			$x['xt'] = $xref->xref_type;
			$x['xb'] = $xref->xref_b;
			
			$ret = $this->changeUsername($x);
			if (! $ret)
				$return = false;
			
			unset($x);
		}
		
		return $return;
	}
	
	
	
	/**
	 * Method to sync users from WHMCS to Joomla
	 * @access		public
	 * @version		2.4.12
	 * @version		2.4.0		- May 2012: Added ability to call locally
	 * @param		string		- $email: contains the email to sync
	 * @param		integer		- $type: the xref type to set
	 * @param		integer		- $id: the joomla or WHMCS id to use
	 * @param		string		- $find: what we are looking for
	 * 
	 * @return		boolean
	 * @since		1.5.1
	 */
	public function syncUser( $email = null, $type = 2, $id = null, $find = 'joomla' )
	{
		// 0:  Initialize Variables
		$db		= &JFactory::getDBO();
		$jcurl	=& JwhmcsCurl::getInstance();
		
		if ( is_null( $email ) )
		{
			// 1:  Pull existing email address to find
			if ($whmcsid = JwhmcsHelper :: get( 'whmcsid' )):
				$find	= 'joomla';
				$type	= 2;
				$query	= "SELECT w.email FROM #__jwhmcs_user as w WHERE w.id = $whmcsid";
			elseif ($whmcsid = JwhmcsHelper :: get( 'whsubid' )):
				$find	= 'joomla';
				$type	= 6;
				$query	= "SELECT w.email FROM #__jwhmcs_usersub as w WHERE w.id = $whmcsid";
			else:
				$find = 'whmcs';
				$joomid = JwhmcsHelper :: get( 'joomid' );
				$query	= 'SELECT a.email FROM #__users as a WHERE a.id = '.$joomid;
			endif;
			$db->setQuery($query);
			$email	= $db->loadResult();
		}
		else {
			if ( $find == 'joomla' ) {
				$whmcsid = $id;
			}
			else {
				$joomid = $id;
			}
		
		}
		
		// 2:  Search based on email address
		switch($find):
		case 'joomla':
			/* ------------------------------------ *\
			 * For this section we have a WHMCS ID
			\* ------------------------------------ */
			// J1: Lets start by pulling the data from Joomla based on the email
			$query	= 'SELECT a.id FROM #__users as a WHERE a.email='.$db->Quote($email);
			$db->setQuery($query);
			
			// J2: Does it return a result?  then continue
			if ($xref_a = $db->loadResult()):
				
				// J3: Now check the xref table to see if it exists already
				$query	= 'SELECT x.xref_b FROM #__jwhmcs_xref as x WHERE x.xref_a='.$xref_a.' AND x.xref_type BETWEEN 1 AND 9';
				$db->setQuery($query);
				
				// J4: Does it exist?  No?  Then proceed
				if (is_null($db->loadResult())):
					
					// J5: Create xref table record
					$query = "INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) 
								VALUES ($xref_a, $type, $whmcsid)";
					$db->setQuery($query);
					
					if ($db->query()):
						
						// J6: All is well, return succesful
						return true;
					endif;
				endif;
			endif;
			return false;
			break;
		case 'whmcs':
			/* ------------------------------------ *\
			 * For this section we have a Joomla ID
			\* ------------------------------------ */
			// W1: Lets start by pulling the data from WHMCS based on the email
			
			$fields['email'] = $email;
			$jcurl->setAction('getclientsdatabyemail', $fields);
			$whmcs	= $jcurl->loadResult();
			$tblsub = ""; $type = 2;
			
			if ( $whmcs['result'] != 'success' ) {
				$jcurl->setAction('jwhmcsgetcontact', array("get" => "email=$email"));
				$whcon	= $jcurl->loadResult();
				$type	= 6;
				
				if ( $whcon['result'] != 'success' ) {
					return false;
				}
				else {
					$whmcs = $whcon;
					$tblsub	= "sub";
					$whmcs['userid'] = $whcon['id'];
				}
			}
			
			// W3: Now find out if that matched ID from WHMCS already exists in the xref
			$query	= 'SELECT x.xref_a, x.xref_type FROM #__jwhmcs_xref as x WHERE x.xref_b='.$whmcs['userid'].' AND x.xref_type BETWEEN 1 AND 9';
			$db->setQuery($query);
			
			// W4: Is there an existing xref?  Yes - then check joomla id against what we have
			if (! is_null( $result = $db->loadAssoc() ) )
			{
				if ( $joomid != $result['xref_a'] ) $this->syncBreak( array( 'xa' => $result['xref_a'], 'xt' => $result['xref_type'], 'xb' => $whmcs['userid'] ) );
				else return false;
			}
			
			$query	= "INSERT INTO #__jwhmcs_user$tblsub (id, fname, lname, cname, email, address1, address2, city, state, postal, country, phonenumber) VALUES (%1\$s, %2\$s, %3\$s, %4\$s, %5\$s, %6\$s, %7\$s, %8\$s, %9\$s, %10\$s, %11\$s, %12\$s) 
						ON DUPLICATE KEY UPDATE fname=%2\$s, lname=%3\$s, cname=%4\$s, email=%5\$s, address1=%6\$s, address2=%7\$s, city=%8\$s, state=%9\$s, postal=%10\$s, country=%11\$s, phonenumber=%12\$s";
			
			$query	= sprintf($query, $whmcs['userid'], $db->Quote($whmcs['firstname']), $db->Quote($whmcs['lastname']), $db->Quote($whmcs['companyname']), $db->Quote($whmcs['email']), $db->Quote($whmcs['address1']), $db->Quote($whmcs['address2']), $db->Quote($whmcs['city']), $db->Quote($whmcs['state']), $db->Quote($whmcs['postcode']), $db->Quote($whmcs['country']), $db->Quote($whmcs['phonenumber']));
			
			$db->setQuery($query);
			$db->query();
			
			// W8: Create the xref record
			$query = 'INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) '
						.'VALUES ('.$joomid.', '.$type.', '.$whmcs['userid'].')';
			$db->setQuery($query);
			
			if ($db->query()) return true;
			
			break;
		endswitch;
		return false;
	}
	
	
	
	/**
	 * Method to break sync for a user
	 * @access		public
	 * @version		2.4.12
	 * @param		array		- $post: contains the ids to break
	 * 
	 * @return		boolean
	 * @since		1.5.1
	 */
	public function syncBreak($post)
	{
		// 0:  Initialize Variables
		$db = &JFactory::getDBO();
		
		// 1:  Create Query
		$query	= 'DELETE FROM #__jwhmcs_xref WHERE xref_a = '.$post['xa'].' AND xref_type = '.$post['xt'].' AND xref_b = '.$post['xb'];
		$db->setQuery($query);
		
		// 2:  Execute and return
		if ($db->query())
			return true;
		else
			return false;
	}
	
	
	
	/**
	 * Method to match all users up
	 * @access		public
	 * @version		2.4.12
	 *
	 * @return		boolean
	 * @since		1.5.1
	 */
	public function matchAll()
	{
		// 0:  Initialize Variables
		$db				= & JFactory::getDBO();
		$jcurl			= & JwhmcsCurl::getInstance();
		$group_members	=   array();
		$ids			=   array();
		$jids			=   array();
		$qresult		=   array( 'client' => true, 'subs' => true );
		
		// 1:  Pull all ids of group members
		$query	=	'SELECT x.xref_a as id '.
					'FROM #__jwhmcs_xref x '.
					'WHERE x.xref_type IN (4)';
		$db->setQuery($query);
		$group_members = $db->loadResultArray();
		
		// 2:  Pull all emails from WHMCS user base (stored in Joomla) that AREN'T in xref
		$query	=	"	SELECT ju.id, ju.email
						FROM #__jwhmcs_user ju 
						WHERE ju.id NOT IN ( 
							SELECT DISTINCT ju.id 
							FROM #__jwhmcs_user ju 
								INNER JOIN #__jwhmcs_xref jx ON jx.xref_b = ju.id 
							WHERE jx.xref_type IN (1,2,3,8) 
						) AND ju.email NOT IN ( 
							SELECT DISTINCT jg.email 
							FROM #__jwhmcs_group jg 
								INNER JOIN #__jwhmcs_xref jx ON jx.xref_b = jg.id 
							WHERE jx.xref_type IN (4) 
						)";
		$db->setQuery($query);
		$wemails = $db->loadAssocList();
		
		// 3:  Cycle through each WHMCS email and add to new xref array
		foreach ($wemails as $wu) {
			$query	= 'SELECT u.id '.
						'FROM #__users u '.
						'WHERE u.email = "'.$wu['email'].'"';
			$db->setQuery($query);
			
			if ($jid = $db->loadResult()) {
				if (in_array($jid, $group_members)) continue;
				$ids[] = "($jid, 2, ".$wu['id'].")";
			}
		}
		
		// 4:  Execute SQL to add new ids to xref before pulling for WHMCS
		if (! empty($ids)) {
			$query	=	'INSERT INTO #__jwhmcs_xref (`xref_a`, `xref_type`, `xref_b`) VALUES '.implode(', ',$ids).';';
			$db->setQuery($query);
			$db->query();
		}
		unset ($ids, $jid, $wemails);
		
		// 2b:  Pull all emails from WHMCS subaccount base (stored in Joomla) that AREN'T in xref
		$query	=	"	SELECT ju.id, ju.email
						FROM #__jwhmcs_usersub ju 
						WHERE ju.id NOT IN ( 
							SELECT DISTINCT ju.id 
							FROM #__jwhmcs_usersub ju 
								INNER JOIN #__jwhmcs_xref jx ON jx.xref_b = ju.id 
							WHERE jx.xref_type IN (5,6,7,9) 
						) AND ju.email NOT IN ( 
							SELECT DISTINCT jg.email 
							FROM #__jwhmcs_group jg 
								INNER JOIN #__jwhmcs_xref jx ON jx.xref_b = jg.id 
							WHERE jx.xref_type IN (4) 
						)";
		
		$db->setQuery($query);
		$wemails = $db->loadAssocList();
		
		// 3b:  Cycle through each WHMCS email and add to new xref array
		foreach ($wemails as $wu) {
			$query	= 'SELECT u.id '.
						'FROM #__users u '.
						'WHERE u.email = "'.$wu['email'].'"';
			$db->setQuery($query);
			
			if ($jid = $db->loadResult()) {
				if (in_array($jid, $group_members)) continue;
				$ids[] = "($jid, 6, ".$wu['id'].")";
			}
		}
		
		// 4b:  Execute SQL to add new ids to xref before pulling for WHMCS
		if (! empty($ids)) {
			$query	=	'INSERT INTO #__jwhmcs_xref (`xref_a`, `xref_type`, `xref_b`) VALUES '.implode(', ',$ids).';';
			$db->setQuery($query);
			$db->query();
		}
		
		// 5:  Pull all emails from Joomla user base that AREN'T in xref
		$query	=	'SELECT u.id, u.email '.
					'FROM #__users u '.
					'WHERE u.id NOT IN ( '.
						'SELECT DISTINCT u.id '.
						'FROM #__users u '.
							'INNER JOIN #__jwhmcs_xref jx ON jx.xref_a = u.id '.
						'WHERE jx.xref_type BETWEEN 1 AND 9 '.
					')';
		$db->setQuery($query);
		$jemails = $db->loadObjectList();
		
		// 6:  Cycle through each email and check via api check
		foreach ($jemails as $ju) {
			$fields['email'] = $ju->email;
			$jcurl->setAction('getclientsdatabyemail', $fields);
			$whmcs	= $jcurl->loadResult();
			
			if ($whmcs['result']=='success') {
				$jids[] = "($ju->id, 2, ".$whmcs['userid'].")";
				
				$wuser[]='('.$db->Quote($whmcs['userid']).', '
							.$db->Quote($whmcs['firstname']).', '
							.$db->Quote($whmcs['lastname']).', '
							.$db->Quote($whmcs['companyname']).', '
							.$db->Quote($whmcs['email']).', '
							.$db->Quote($whmcs['address1']).', '
							.$db->Quote($whmcs['address2']).', '
							.$db->Quote($whmcs['city']).', '
							.$db->Quote($whmcs['state']).', '
							.$db->Quote($whmcs['postcode']).', '
							.$db->Quote($whmcs['country']).', '
							.$db->Quote($whmcs['phonenumber']).')';
				continue;
			}
			
			$fields['get'] = "email={$ju->email}";
			$jcurl->setAction('jwhmcsgetcontact', $fields);
			$whmcs	= $jcurl->loadResult();
			
			if ($whmcs['result']=='success') {
				$jids[] = "($ju->id, 6, ".$whmcs['id'].")";
				
				$wuser[]='('.$db->Quote($whmcs['id']).', '
							.$db->Quote($whmcs['firstname']).', '
							.$db->Quote($whmcs['lastname']).', '
							.$db->Quote($whmcs['companyname']).', '
							.$db->Quote($whmcs['email']).', '
							.$db->Quote($whmcs['address1']).', '
							.$db->Quote($whmcs['address2']).', '
							.$db->Quote($whmcs['city']).', '
							.$db->Quote($whmcs['state']).', '
							.$db->Quote($whmcs['postcode']).', '
							.$db->Quote($whmcs['country']).', '
							.$db->Quote($whmcs['phonenumber']).')';
			}
		}
		
		// 7:  Run SQL to insert into database
		if (! empty($jids)) {
			$query	=	'INSERT INTO #__jwhmcs_xref (`xref_a`, `xref_type`, `xref_b`) VALUES '.implode(', ', $jids).';';
			$db->setQuery($query);
			$qresult['client']	= $db->query();
			$query	= 'INSERT INTO #__jwhmcs_usersub (id, fname, lname, cname, email, address1, address2, city, state, postal, country, phonenumber) VALUES '.implode(', ', $wuser).';';
			$db->setQuery($query);
			$qresult['subs']	= $db->query();
		}
		
		if ( in_array( false, $qresult, true ) )
			return false;
		else
			return true;
	}
	
	
	/* ----------------------------------------- *\
	 *              SUB FUNCTIONS                *
	\* ----------------------------------------- */
	
	
	/**
	 * Common method for pulling user data from the database (massive)
	 * @access		private
	 * @version		2.4.12
	 * @version		1.5.3		- October 2009: added refined user manager features
	 * @param		array		- $task: the form data sent by request
	 * @param		array		- $qp:  optional query parameters
	 * 
	 * @return		string
	 * @since		1.5.3
	 */
	private function _buildQuery($task, $qp = null)
	{
		$db = & JFactory::getDBO();
		
		if ($this->getState('user_search')) {
			$needle   = $db->Quote( '%'.$db->getEscaped( $this->getState('user_search'), true ).'%', false );
			$usersrch = ' IFNULL( LOWER( %s ) LIKE %s, NULL )';
			
			$arsch[0] = array('a.name', 'a.username', 'a.email', 'w.fname', 'w.lname', 'w.cname', 'w.email', 'w.address1', 'w.address2', 'w.city', 'w.state', 'w.postal');
			$arsch[1] = array('a.name', 'a.username', 'a.email', 'w.fname', 'w.lname', 'w.cname', 'w.email');
			$arsch[2] = array('a.name', 'a.username', 'a.email');
			$arsch[3] = array('w.fname', 'w.lname', 'w.cname', 'w.email', 'w.address1', 'w.address2', 'w.city', 'w.state', 'w.postal', 'w.country', 'w.phonenumber');
			
			foreach ($arsch as $key => $scharray) {
				foreach ($scharray as $item ) {
					$srch[] = sprintf($usersrch, $item, $needle);
				}
				$search[$key] = ' AND ( '.implode(' OR', $srch).' )';
				unset ($srch);
			}
		}
		else {
			$search = array(null, null, null, null);
		}
		
		$jusers		= JwhmcsHelper :: get('filter_jusers')?JwhmcsHelper :: get('filter_jusers'):0;
		$wusers		= JwhmcsHelper :: get('filter_wusers')?JwhmcsHelper :: get('filter_wusers'):0;
		$matches	= JwhmcsHelper :: get('filter_matches')?JwhmcsHelper :: get('filter_matches'):0;
		
		$sqlseg		= array(array(),array(),array(),array());
		
		switch($matches):
		case '-1':
			$sqlseg[0][0] = false;			// Sql:  Joomla users joined to WHMCS users 
			$sqlseg[1][0] = false;			// Sql:  Joomla users groups to single WHMCS
			$sqlseg[2][0] = true;			// Sql:  unmatched Joomla users only
			$sqlseg[3][0] = true;			// Sql:  nmatched WHMCS users only
			$sqlseg[4][0] = false;			// Sql:  Joomla users joined to WHMCS subaccounts 
			$sqlseg[4][1] = null;			// 				null
			$sqlseg[5][0] = true;			// Sql:  unmatched WHMCS subaccounts only
			break;
		case 1:
			$sqlseg[0][0] = true;			// Sql:  Joomla users joined to WHMCS users 
			$sqlseg[0][1] = "IN ( '1' )";	// 				Specifies only silver matches
			$sqlseg[1][0] = false;			// Sql:  Joomla users groups to single WHMCS
			$sqlseg[2][0] = false;			// Sql:  unmatched Joomla users only
			$sqlseg[3][0] = false;			// Sql:  nmatched WHMCS users only
			$sqlseg[4][0] = true;			// Sql:  Joomla users joined to WHMCS subaccounts 
			$sqlseg[4][1] = "IN ( '5' )";	// 				Specifies only silver matches
			$sqlseg[5][0] = false;			// Sql:  unmatched WHMCS subaccounts only
			break;
		case 2:
			$sqlseg[0][0] = true;			// Sql:  Joomla users joined to WHMCS users 
			$sqlseg[0][1] = "IN ( '2' )";	// 				Specifies only orange matches (found) 
			$sqlseg[1][0] = false;			// Sql:  Joomla users groups to single WHMCS
			$sqlseg[2][0] = false;			// Sql:  unmatched Joomla users only
			$sqlseg[3][0] = false;			// Sql:  unmatched WHMCS users only
			$sqlseg[4][0] = true;			// Sql:  Joomla users joined to WHMCS subaccounts 
			$sqlseg[4][1] = "IN ( '6' )";	// 				Specifies only orange matches (found)
			$sqlseg[5][0] = false;			// Sql:  unmatched WHMCS subaccounts only
			break;
		case 3:
			$sqlseg[0][0] = true;			// Sql:  Joomla users joined to WHMCS users 
			$sqlseg[0][1] = "IN ( '3', '8' )";	// 				Specifies only purple matches (forced)
			$sqlseg[1][0] = false;			// Sql:  Joomla users groups to single WHMCS
			$sqlseg[2][0] = false;			// Sql:  unmatched Joomla users only
			$sqlseg[3][0] = false;			// Sql:  nmatched WHMCS users only
			$sqlseg[4][0] = true;			// Sql:  Joomla users joined to WHMCS subaccounts 
			$sqlseg[4][1] = "IN ( '7', '9' )";	// 				Specifies only purple matches (forced)
			$sqlseg[5][0] = false;			// Sql:  unmatched WHMCS subaccounts only
			break;
		case 4:
			$sqlseg[0][0] = false;			// Sql:  Joomla users joined to WHMCS users 
			$sqlseg[0][1] = null;			// 				null
			$sqlseg[1][0] = true;			// Sql:  Joomla users groups to single WHMCS
			$sqlseg[1][1] = "'4'";			// 			Specifies group xref id
			$sqlseg[2][0] = false;			// Sql:  unmatched Joomla users only
			$sqlseg[3][0] = false;			// Sql:  nmatched WHMCS users only
			$sqlseg[4][0] = false;			// Sql:  Joomla users joined to WHMCS subaccounts 
			$sqlseg[4][1] = null;			// 				null
			$sqlseg[5][0] = false;			// Sql:  unmatched WHMCS subaccounts only
			break;
		default:
			$sqlseg[0][0] = true;			// Sql:  Joomla users joined to WHMCS users 
			$sqlseg[0][1] = "IN ( '1', '2', '3', '8' ) OR x.xref_type='' ";	// Specifies all match types or no match type
			$sqlseg[1][0] = true;			// Sql:  Joomla users groups to single WHMCS
			$sqlseg[1][1] = "'4'";			// 			Specifies group xref id
			$sqlseg[2][0] = true;			// Sql:  unmatched Joomla users only
			$sqlseg[3][0] = true;			// Sql:  unmatched WHMCS users only
			$sqlseg[4][0] = true;			// Sql:  Joomla users joined to WHMCS subaccounts 
			$sqlseg[4][1] = "IN ( '5', '6', '7', '9' ) OR x.xref_type='' ";	// Specifies all match types or no match type
			$sqlseg[5][0] = true;			// Sql:  unmatched WHMCS subaccounts only
			
		endswitch;
		
		switch($jusers):
		case 1:
			if ($matches==0):
				$sqlseg[0][0] = true;			// Sql:  Joomla users joined to WHMCS users
				$sqlseg[1][0] = true;			// Sql:  Joomla users groups to single WHMCS
				$sqlseg[2][0] = false;			// Sql:  unmatched Joomla users only
				$sqlseg[3][0] = false;			// Sql:  unmatched WHMCS users only
				$sqlseg[4][0] = true;			// Sql:  Joomla users joined to WHMCS subaccounts
				$sqlseg[5][0] = false;			// Sql:  unmatched WHMCS subaccounts only
			else:
				JwhmcsHelper :: set('filter_jusers', 0);
			endif;
			break;
		case 2:
			if ($matches==0):
				$sqlseg[0][0] = false;			// Sql:  Joomla users joined to WHMCS users
				$sqlseg[1][0] = false;			// Sql:  Joomla users groups to single WHMCS
				$sqlseg[2][0] = true;			// Sql:  unmatched Joomla users only
				$sqlseg[3][0] = false;			// Sql:  unmatched WHMCS users only
				$sqlseg[4][0] = false;			// Sql:  Joomla users joined to WHMCS subaccounts
				$sqlseg[5][0] = true;			// Sql:  unmatched WHMCS subaccounts only
			else:
				JwhmcsHelper :: set('filter_jusers', 0);
			endif;
			break;
		endswitch;
		
		switch($wusers):
		case 1:
			if ($matches==0):
				$sqlseg[0][0] = true;			// Sql:  Joomla users joined to WHMCS users
				$sqlseg[1][0] = true;			// Sql:  Joomla users groups to single WHMCS
				$sqlseg[2][0] = false;			// Sql:  unmatched Joomla users only
				$sqlseg[3][0] = false;			// Sql:  unmatched WHMCS users only
				$sqlseg[4][0] = true;			// Sql:  Joomla users joined to WHMCS subaccounts
				$sqlseg[5][0] = false;			// Sql:  unmatched WHMCS subaccounts only
			else:
				JwhmcsHelper :: set('filter_wusers', 0);
			endif;
			break;
		case 2:
			if ($matches==0):
				$sqlseg[0][0] = false;			// Sql:  Joomla users joined to WHMCS users
				$sqlseg[1][0] = false;			// Sql:  Joomla users groups to single WHMCS
				$sqlseg[2][0] = false;			// Sql:  unmatched Joomla users only
				$sqlseg[3][0] = true;			// Sql:  unmatched WHMCS users only
				$sqlseg[4][0] = false;			// Sql:  Joomla users joined to WHMCS subaccounts
				$sqlseg[5][0] = true;			// Sql:  unmatched WHMCS subaccounts only
			else:
				JwhmcsHelper :: set('filter_wusers', 0);
			endif;
			break;
		endswitch;
		
		switch ($task):
		default:
			$orderby	= 'ORDER BY '.$qp['sortby'].' '.$qp['sortord'];
			
			$query 	= '';
			
			/* ------------------------------------------- *\
			 * Sql:  Joomla users joined to WHMCS users
			\* ------------------------------------------- */
			if ($sqlseg[0][0]):
				$query[] = $this->_fetchQuery( 'joined', $sqlseg, $search );
			endif;
			
			/* ------------------------------------------- *\
			 * Sql:  Joomla users groups to single WHMCS
			\* ------------------------------------------- */
			if ($sqlseg[1][0]):
				$query[] = $this->_fetchQuery( 'groups', $sqlseg, $search );
			endif;
			
			
			/* ------------------------------------------- *\
			 * Sql:  unmatched Joomla users only
			\* ------------------------------------------- */
			if ($sqlseg[2][0]):
				$query[] = $this->_fetchQuery( 'joomla', $sqlseg, $search );
			endif;
			
			/* ------------------------------------------- *\
			 * Sql:  unmatched WHMCS users only
			\* ------------------------------------------- */
			if ($sqlseg[3][0]):
				$query[] = $this->_fetchQuery( 'whmcs', $sqlseg, $search );
				
				/* ------------------------------------------- *\
				 * Sql:  Matched group to WHMCS users only
				\* ------------------------------------------- */
				// This is an additional Query to bridge 
				/*$query[]="( SELECT
								'0' as xref_type, g.id as `jid`, CONCAT(g.cname, ': ', g.lname, ', ', g.fname) as `jname`, NULL as `jusername`, NULL as `jemail`, NULL as `jblock`, NULL as `jgroupname`,
								w.id as `wid`, w.fname as `wfname`, w.lname as `wlname`, w.cname as `wcname`, w.email as `wemail`, w.address1 as `waddress1`,
								w.address2 as `waddress2`, w.city as `wcity`, w.state as `wstate`, w.postal as `wpostal`, w.country as `wcountry`, w.phonenumber as `wphone` 
							FROM #__jwhmcs_user AS w 
								INNER JOIN #__jwhmcs_group g ON g.email = w.email "
							.($search[3]?" WHERE ".substr(substr($search[3], 6), 0, -2) : "" )." ) ";*/
			endif;
			
			/* ------------------------------------------- *\
			 * Sql:  Matched WHMCS subaccount only
			\* ------------------------------------------- */
			if ($sqlseg[4][0]):
				$query[] = $this->_fetchQuery( 'submatch', $sqlseg, $search );
			endif;
			/* ------------------------------------------- *\
			 * Sql:  Unmatched WHMCS subaccount only
			\* ------------------------------------------- */
			if ($sqlseg[5][0]):
				$query[] = $this->_fetchQuery( 'subnomatch', $sqlseg, $search );
			endif;
			
			if (count($query)>1)
				$qrystr = implode(' UNION ', $query).$orderby;
			else
				$qrystr = $query[0].$orderby;
			
			break;
		endswitch;
		
		return $qrystr;
	}
	
	
	/**
	 * Fetches just the SQL portion for given JVERSION
	 * @access		private
	 * @version		2.4.12
	 * @param		string		- $qry: which query we need
	 * @param		array		- $sqlseg: gather sql segments
	 * @param		array		- $search: search items
	 * 
	 * @return		string
	 * @since		2.4.0
	 */
	private function _fetchQuery( $qry, $sqlseg, $search )
	{
		$data	= null;
		
		switch ( $qry ) :
		
		case 'joined' :
			
			if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
				$data	= <<< SQL
( SELECT x.xref_type, a.id as `jid`, a.name as `jname`, a.username as `jusername`, a.email as `jemail`, a.block as `jblock`, GROUP_CONCAT( DISTINCT ug.title ORDER BY ug.title DESC SEPARATOR ' | ' ) as `jgroupname`,
w.id as `wid`, w.fname as `wfname`, w.lname as `wlname`, w.cname as `wcname`, w.email as `wemail`, w.address1 as `waddress1`,
w.address2 as `waddress2`, w.city as `wcity`, w.state as `wstate`, w.postal as `wpostal`, w.country as `wcountry`, w.phonenumber as `wphone`
FROM ( #__users AS a
	INNER JOIN #__user_usergroup_map ugm ON a.id = ugm.user_id
	INNER JOIN #__usergroups ug ON ug.id = ugm.group_id )
	INNER JOIN (#__jwhmcs_xref as x INNER JOIN #__jwhmcs_user as w ON w.id=x.xref_b) ON a.id = x.xref_a
WHERE ( x.xref_type {$sqlseg[0][1]}) {$search[0]} 
GROUP BY a.id ) 
SQL;
			}
			else {
				$data	= <<< SQL
( SELECT x.xref_type, a.id as `jid`, a.name as `jname`, a.username as `jusername`, a.email as `jemail`, a.block as `jblock`, g.name as `jgroupname`, 
w.id as `wid`, w.fname as `wfname`, w.lname as `wlname`, w.cname as `wcname`, w.email as `wemail`, w.address1 as `waddress1`, 
w.address2 as `waddress2`, w.city as `wcity`, w.state as `wstate`, w.postal as `wpostal`, w.country as `wcountry`, w.phonenumber as `wphone`  
FROM (#__users AS a 
	INNER JOIN #__core_acl_aro AS aro ON aro.value = a.id INNER JOIN #__core_acl_groups_aro_map AS gm ON gm.aro_id = aro.id INNER JOIN #__core_acl_aro_groups AS g ON g.id = gm.group_id) 
	INNER JOIN (#__jwhmcs_xref as x INNER JOIN #__jwhmcs_user as w ON w.id=x.xref_b) ON a.id = x.xref_a 
WHERE ( x.xref_type {$sqlseg[0][1]}) {$search[0]} ) 
SQL;
			}
			
			break;
			
		case 'groups' :
			
			if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) :
				$data	= <<< SQL
( SELECT 
	x.xref_type, a.id as `jid`, a.name as `jname`, a.username as `jusername`, a.email as `jemail`, a.block as `jblock`, GROUP_CONCAT( DISTINCT ug.title ORDER BY ug.title DESC SEPARATOR ' | ' ) as `jgroupname`, 
	w.id as `wid`, w.fname as `wfname`, w.lname as `wlname`, w.cname as `wcname`, w.email as `wemail`, NULL as `waddress1`, 
	NULL as `waddress2`, NULL as `wcity`, NULL as `wstate`, NULL as `wpostal`, NULL as `wcountry`, NULL as `wphone` 
FROM ( #__users AS a
	INNER JOIN #__user_usergroup_map ugm ON a.id = ugm.user_id
	INNER JOIN #__usergroups ug ON ug.id = ugm.group_id ) 
	INNER JOIN (#__jwhmcs_xref as x INNER JOIN #__jwhmcs_group as w ON w.id=x.xref_b) ON a.id = x.xref_a 
WHERE x.xref_type = {$sqlseg[1][1]}{$search[1]}
GROUP BY a.id ) 
SQL;
			else:
				$data	= <<< SQL
( SELECT 
	x.xref_type, a.id as `jid`, a.name as `jname`, a.username as `jusername`, a.email as `jemail`, a.block as `jblock`, g.name as `jgroupname`, 
	w.id as `wid`, w.fname as `wfname`, w.lname as `wlname`, w.cname as `wcname`, w.email as `wemail`, NULL as `waddress1`, 
	NULL as `waddress2`, NULL as `wcity`, NULL as `wstate`, NULL as `wpostal`, NULL as `wcountry`, NULL as `wphone` 
FROM (#__users AS a 
	INNER JOIN #__core_acl_aro AS aro ON aro.value = a.id INNER JOIN #__core_acl_groups_aro_map AS gm ON gm.aro_id = aro.id INNER JOIN #__core_acl_aro_groups AS g ON g.id = gm.group_id) 
	INNER JOIN (#__jwhmcs_xref as x INNER JOIN #__jwhmcs_group as w ON w.id=x.xref_b) ON a.id = x.xref_a 
WHERE x.xref_type = {$sqlseg[1][1]}{$search[1]} ) 
SQL;
			endif;
			break;
			
		case 'joomla' :
			
			if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) :
				$data	= <<< SQL
( SELECT 
	x.xref_type, a.id as `jid`, a.name as `jname`, a.username as `jusername`, a.email as `jemail`, a.block as `jblock`, GROUP_CONCAT( DISTINCT ug.title ORDER BY ug.title DESC SEPARATOR ' | ' ) as `jgroupname`, 
	NULL as `wid`, NULL as `wfname`, NULL as `wlname`, NULL as `wcname`, NULL as `wemail`, NULL as `waddress1`, NULL as `waddress2`, 
	NULL as `wcity`, NULL as `wstate`, NULL as `wpostal`, NULL as `wcountry`, NULL as `wphone`
FROM ( #__users AS a
	INNER JOIN #__user_usergroup_map ugm ON a.id = ugm.user_id
	INNER JOIN #__usergroups ug ON ug.id = ugm.group_id ) 
	LEFT JOIN #__jwhmcs_xref as x ON a.id = x.xref_a 
WHERE x.xref_type IS NULL {$search[2]}
GROUP BY a.id ) 
SQL;
			else :
				$data	= <<< SQL
( SELECT 
	x.xref_type, a.id as `jid`, a.name as `jname`, a.username as `jusername`, a.email as `jemail`, a.block as `jblock`, g.name as `jgroupname`, 
	NULL as `wid`, NULL as `wfname`, NULL as `wlname`, NULL as `wcname`, NULL as `wemail`, NULL as `waddress1`, NULL as `waddress2`, 
	NULL as `wcity`, NULL as `wstate`, NULL as `wpostal`, NULL as `wcountry`, NULL as `wphone`
FROM (#__users AS a 
	INNER JOIN #__core_acl_aro AS aro ON aro.value = a.id INNER JOIN #__core_acl_groups_aro_map AS gm ON gm.aro_id = aro.id INNER JOIN #__core_acl_aro_groups AS g ON g.id = gm.group_id) 
	LEFT JOIN #__jwhmcs_xref as x ON a.id = x.xref_a 
WHERE x.xref_type IS NULL {$search[2]} ) 
SQL;
			endif;
			break;
			
		case 'whmcs' :
			
			if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) :
				$data	= <<< SQL
( SELECT 
	NULL as `xref_type`, NULL as `jid`, NULL as `jname`, NULL as `jusername`, NULL as `jemail`, NULL as `jblock`, NULL as `jgroupname`,
	w.id as `wid`, w.fname as `wfname`, w.lname as `wlname`, w.cname as `wcname`, w.email as `wemail`, w.address1 as `waddress1`, 
	w.address2 as `waddress2`, w.city as `wcity`, w.state as `wstate`, w.postal as `wpostal`, w.country as `wcountry`, w.phonenumber as `wphone`
FROM #__jwhmcs_user AS w 
	LEFT JOIN #__jwhmcs_xref as x ON w.id = x.xref_b 
WHERE (( x.xref_type IS NULL OR x.xref_type = 4 ) 
	AND w.email NOT IN ( SELECT email FROM #__jwhmcs_group )) {$search[3]} ) 
SQL;
			else :
				$data	= <<< SQL
( SELECT 
	NULL as `xref_type`, NULL as `jid`, NULL as `jname`, NULL as `jusername`, NULL as `jemail`, NULL as `jblock`, NULL as `jgroupname`,
	w.id as `wid`, w.fname as `wfname`, w.lname as `wlname`, w.cname as `wcname`, w.email as `wemail`, w.address1 as `waddress1`, 
	w.address2 as `waddress2`, w.city as `wcity`, w.state as `wstate`, w.postal as `wpostal`, w.country as `wcountry`, w.phonenumber as `wphone`
FROM #__jwhmcs_user AS w 
	LEFT JOIN #__jwhmcs_xref as x ON w.id = x.xref_b 
WHERE (( x.xref_type IS NULL OR x.xref_type = 4 ) 
	AND w.email NOT IN ( SELECT email FROM #__jwhmcs_group )) {$search[3]} ) 
SQL;
			endif;
			break;
			
		case 'submatch' :
			
			if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) :
				$data = <<< SQL
( SELECT
	x.xref_type, a.id as `jid`, a.name as `jname`, a.username as `jusername`, a.email as `jemail`, a.block as `jblock`, GROUP_CONCAT( DISTINCT ug.title ORDER BY ug.title DESC SEPARATOR ' | ' ) as `jgroupname`,
	w.id as `wid`, w.fname as `wfname`, w.lname as `wlname`, w.cname as `wcname`, w.email as `wemail`, w.address1 as `waddress1`,
	w.address2 as `waddress2`, w.city as `wcity`, w.state as `wstate`, w.postal as `wpostal`, w.country as `wcountry`, w.phonenumber as `wphone` 
FROM ( #__users AS a
	INNER JOIN #__user_usergroup_map ugm ON a.id = ugm.user_id
	INNER JOIN #__usergroups ug ON ug.id = ugm.group_id ) 
	INNER JOIN
		(#__jwhmcs_xref as x INNER JOIN #__jwhmcs_usersub as w ON w.id=x.xref_b) ON a.id = x.xref_a
WHERE ( x.xref_type {$sqlseg[4][1]}) {$search[0]}
GROUP BY a.id )
SQL;
			else :
				$data = <<< SQL
( SELECT
	x.xref_type, a.id as `jid`, a.name as `jname`, a.username as `jusername`, a.email as `jemail`, a.block as `jblock`, g.name as `jgroupname`,
	w.id as `wid`, w.fname as `wfname`, w.lname as `wlname`, w.cname as `wcname`, w.email as `wemail`, w.address1 as `waddress1`,
	w.address2 as `waddress2`, w.city as `wcity`, w.state as `wstate`, w.postal as `wpostal`, w.country as `wcountry`, w.phonenumber as `wphone` 
FROM (#__users AS a
	INNER JOIN #__core_acl_aro AS aro ON aro.value = a.id
		INNER JOIN #__core_acl_groups_aro_map AS gm ON gm.aro_id = aro.id
			INNER JOIN #__core_acl_aro_groups AS g ON g.id = gm.group_id)
	INNER JOIN
		(#__jwhmcs_xref as x INNER JOIN #__jwhmcs_usersub as w ON w.id=x.xref_b) ON a.id = x.xref_a
WHERE ( x.xref_type {$sqlseg[4][1]}) {$search[0]} ) 
SQL;
			endif;
			break;
			
		case 'subnomatch' :
			
			if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) :
				$data = <<< SQL
( SELECT
	'-1' as xref_type, NULL as `jid`, NULL as `jname`, NULL as `jusername`, NULL as `jemail`, NULL as `jblock`, NULL as `jgroupname`, 
	w.id as `wid`, w.fname as `wfname`, w.lname as `wlname`, w.cname as `wcname`, w.email as `wemail`, w.address1 as `waddress1`,
	w.address2 as `waddress2`, w.city as `wcity`, w.state as `wstate`, w.postal as `wpostal`, w.country as `wcountry`, w.phonenumber as `wphone`  
FROM #__jwhmcs_usersub AS w
	LEFT JOIN #__jwhmcs_xref as x ON w.id = x.xref_b
WHERE ( x.xref_type IS NULL ) {$search[3]} ) 
SQL;
			else :
				$data = <<< SQL
( SELECT
	'-1' as xref_type, NULL as `jid`, NULL as `jname`, NULL as `jusername`, NULL as `jemail`, NULL as `jblock`, NULL as `jgroupname`, 
	w.id as `wid`, w.fname as `wfname`, w.lname as `wlname`, w.cname as `wcname`, w.email as `wemail`, w.address1 as `waddress1`,
	w.address2 as `waddress2`, w.city as `wcity`, w.state as `wstate`, w.postal as `wpostal`, w.country as `wcountry`, w.phonenumber as `wphone`  
FROM #__jwhmcs_usersub AS w
	LEFT JOIN #__jwhmcs_xref as x ON w.id = x.xref_b
WHERE ( x.xref_type IS NULL ) {$search[3]} ) 
SQL;
			endif;
			break;
		endswitch;
		
		return $data;
	}
	
	
	/**
	 * Common method to create a new user array to bind to JUser object
	 * @access		private
	 * @version		2.4.12
	 * @param		array		- $form: the entire post array
	 * 
	 * @return		array
	 * @since		1.5.1
	 */
	private function _getUserArray($form)
	{
		// Because we can't send the entire post value to bind, we have to create new array
		$ubind = array(	'name'		=> $form['name'],
						'username'	=> $form['username'],
						'email'		=> $form['email'],
						'password'	=> $form['password'],
						'password2'	=> $form['password2'],
						'task'		=> $form['task'],
						'id'		=> $form['id'],
						'groups'	=> array( $form['gid']) );
		return $ubind;
	}
	
	
	
	/**
	 * Method to send an email to the user notifying them of password change
	 * @access		private
	 * @version		2.4.12
	 * @param		JUser object	- $user: the user to send to
	 * @param		string			- $password: the new password to send
	 * 
	 * @since		1.5.1
	 */
	private function _sendMail(&$user, $password)
	{
		$app		= & JFactory::getApplication();
		$db			= & JFactory::getDBO();
		$name 		=   $user->get('name');
		$email 		=   $user->get('email');
		$username 	=   $user->get('username');
		
		$usersConfig 	= &JComponentHelper::getParams( 'com_users' );
		$sitename 		= $app->getCfg( 'sitename' );
		$useractivation = $usersConfig->get( 'useractivation' );
		$mailfrom 		= $app->getCfg( 'mailfrom' );
		$fromname 		= $app->getCfg( 'fromname' );
		$siteURL		= rtrim(JURI::base(), "/administrator/");
		
		$subject 	= sprintf ( JText::_( 'ACCOUNT_DETAILS_FOR' ), $name, $sitename);
		$subject 	= html_entity_decode($subject, ENT_QUOTES);
		
		$message	= sprintf ( JText::_( 'SEND_MSG' ), $name, $sitename, $siteURL);
		$message = html_entity_decode($message, ENT_QUOTES);
		
		//get all super administrator
		$query = 'SELECT name, email, sendEmail' .
				' FROM #__users' .
				' WHERE LOWER( usertype ) = "super administrator"';
		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		
		// Send email to user
		if ( ! $mailfrom  || ! $fromname ) {
			$fromname = $rows[0]->name;
			$mailfrom = $rows[0]->email;
		}
		
		JwhmcsHelper :: sendMail ( $mailfrom, $fromname, $email, $subject, $message );
		return;
	}
} 