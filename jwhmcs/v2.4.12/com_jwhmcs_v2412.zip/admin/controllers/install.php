<?php
/**
 * Group Management Controller for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: install.php 555 2012-09-06 02:10:32Z steven_gohigher $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsControllerInstall
 * Extends:		JwhmcsController
 * Purpose:		Used for Installing J!WHMCS Integrator
 * As of:		version 2.0.0
\* ------------------------------------------------------------ */
class JwhmcsControllerInstall extends JwhmcsController
{
	/* ------------------------------------------------------------ *\
	 * Task:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
		
		$this->registerTask( 'apiconxnAccept',	'licenseAccept' );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		abort
	 * Purpose:		Handle abort install request
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function abort()
	{
		$msg = JText::_( "COM_JWHMCS_INSTALL_CTRL_MSG_CANCEL" );
		$this->setRedirect( 'index.php?option=com_jwhmcs', $msg );
	}
	
	
	/**
	 * Task to offer choice of installation methods to user (J! 1.6+)
	 * @access		public
	 * @version		2.4.12
	 * 
	 * @since		2.4.9
	 */
	public function installed()
	{
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JwhmcsHelper :: set( 'layout', 'installed35' );
		}
		else {
			JwhmcsHelper :: set( 'layout', 'installed' );
		}
		
		parent::display();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		interview
	 * Purpose:		Pushes install to automatic install
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	function interview()
	{
		JRequest::setVar( 'hidemainmenu', 1 );
		JRequest::setVar( 'view', 'install' );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JRequest::setVar( 'layout', 'interview35' );
		}
		else {
			JRequest::setVar( 'layout', 'interview' );
		}
		
		parent::display();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		comlete
	 * Purpose:		Handle installation complete
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function complete()
	{
		$model = $this->getModel('install');
		$model->complete();
		
		$lnk = 'index.php?option=com_jwhmcs';
		$msg = JText::sprintf( "COM_JWHMCS_INSTALL_CTRL_MSG_COMPLETE", JWHMCS_VERS );
		$this->setRedirect( $lnk, $msg);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		manual
	 * Purpose:		Display manual instructions page
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function manual()
	{
		JRequest::setVar( 'layout', 'manual' );
		parent::display();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		license
	 * Purpose:		Check the license
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function license()
	{
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JwhmcsHelper :: set( 'layout', 'license35' );
		}
		else {
			JwhmcsHelper :: set( 'layout', 'license' );
		}
		
		$model	= $this->getModel('install');
		
		$licchk = $model->checkLicense();
		if (isset($licchk['response'])) {
			$this->setRedirect( 'index.php?option=com_jwhmcs&controller=install&task=apiconxn', JText::_( "COM_JWHMCS_INSTALL_CTRL_MSG_LICENSE_ERROR" ) );
		}
		else {
			JwhmcsHelper :: set ( 'hidemainmenu', 1 );
			//JRequest::setVar( 'hidemainmenu', 1 );
			//JRequest::setVar( 'layout', 'license' );
			parent::display();
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		license
	 * Purpose:		Check the license
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function licenseReload()
	{
		$model	= $this->getModel('install');
		$model->licenseReload();
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=install&task=license', '' );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		apiconxn
	 * Purpose:		Check the API connectivity
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function apiconxn()
	{
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JwhmcsHelper :: set( 'layout', 'apiconxn35' );
		}
		else {
			JwhmcsHelper :: set( 'layout', 'apiconxn' );
		}
		
		JwhmcsHelper :: set ( 'hidemainmenu', 1 );
// 		JRequest::setVar( 'hidemainmenu', 1 );
// 		JRequest::setVar( 'layout', 'apiconxn' );
		parent::display();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		licenseAccept
	 * Purpose:		Redirect to default upon license acceptance
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function licenseAccept()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs', null );
	}
}