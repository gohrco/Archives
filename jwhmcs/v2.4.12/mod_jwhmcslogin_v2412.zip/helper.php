<?php
/**
 * @package		J!WHMCS Integrator:  Login Module
 * @copyright	Copyright (C) 2010 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: helper.php 585 2012-10-20 21:54:43Z steven_gohigher $
 * @since		2.0.0
 */

defined( '_JEXEC' ) or die( 'Restricted access' );


/**
 * Module helper file for Login Module
 * @version		2.4.12
 * 
 * @since		2.0.0
 * @author		Steven
 */
class modJwhmcsloginHelper
{
	var $firstname		= null;
	var $lastname		= null;
	var $companyname	= null;
	var $address1		= null;
	var $address2		= null;
	var $city			= null;
	var $state			= null;
	var $postcode		= null;
	var $countryname	= null;
	var $email			= null;
	var $credit			= null;
	var $clienturl		= null;
	var $whmcsurl		= null;
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		2.4.12
	 * 
	 * @since		2.0.0
	 */
	public function __construct() { }
	
	
	
	/**
	 * Retrieves the data for logged in users
	 * @access		public
	 * @version		2.4.12
	 * @version		2.4.11		- Changed response type from XML to JSON
	 * @version		2.3.3		- Added SimpleXML usage in Curl / XML handler (Bug 5)
	 * @param 		JParameter object	- $params: contains the module parameters
	 * @param 		JwhmcsParam object	- $jparams: contains the component parameters
	 * @param 		boolean				- $status: true if logged in
	 * @param 		boolean				- $contact: true if user is a WHMCS contact
	 * 
	 * @return		object containing user data from WHMCS and variables for module rendering
	 * @since		2.0.0
	 */
	public function getData( & $params, & $jparams, $status, $contact = false )
	{
		$jcurl	= JwhmcsCurl::getInstance( array( "simple" => true, "force" => true ) );
		
		if ( $contact ) {
			$jcurl->setAction( 'jwhmcsgetcontact', array("get" => "id={$status}" ) );
			$whmcs	= $jcurl->loadResults();	// We get our custom contact retrieval item
		}
		else {
			$jcurl->setParse( false );
			$jcurl->setAction('getclientsdata', array('clientid' => $status, 'responsetype' => 'json' ));
			$whmcs	= $jcurl->loadResults();
			$whmcs	= json_decode( $whmcs, 1 );
			$jcurl->setParse();
		}
		
		$tmp	= self::getCommon( $params, $jparams, $status );
		foreach ($tmp as $k => $v) $whmcs[$k] = $v;
		
		if ( $params->get( 'enable_gravatar', false ) ) {
			$whmcs['avatar'] = self::get_gravatar( $jparams, $whmcs['email'], $params->get( 'grav_size', 60 ), $params->get( 'grav_default', 'mm' ), 'g', true );
		}
		
		return (object) $whmcs;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	getCommon
	 * Purpose:		Retrieves common variables for module 
	 * As of:		version 2.0 (January 2010)
	 * 
	 * Significant Revisions
	 *  2.1.0 (Apr 2010)
	 *  	* Modified parameter retrieval for form action
	\* ------------------------------------------------------------ */
	function getCommon( & $params, & $cparams, $status )
	{
		$uri	= new Juri ( $cparams->get( 'ApiUrl' ) );
		
		$ssl	= self::isSsl();
		$uri->setScheme( ( $ssl ? 'https' : 'http' ) );
		$uri->setPath( rtrim($uri->getPath(),'/') );
		
		$return->clienturl	= $uri->toString();
		$uri->setPath( $uri->getPath() . '/jwhmcs.php' );
		
		$return->scheme		= $uri->getScheme().'://';
		$return->whmcsurl	= $uri->toString();
		$return->return		= self::getReturnURL( $params, $cparams, ($status ? 'RenderLoggedout' : 'RenderLoggedin' ));
		$return->iswhmcs	= self::isWhmcs( $params );
		if (!$return->return) unset($return->return);
		
		return $return;
	}
	
	
	/**
	 * Method to assemble links for the module
	 * @access		public
	 * @version		2.4.12
	 * 
	 * @return		JObject
	 * @since		2.4.0
	 */
	public function getLinks()
	{
		$data	= new JObject();
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$data->set( 'pwreset',	JRoute :: _( 'index.php?option=com_users&view=reset' ) );
			$data->set( 'username',	JRoute :: _( 'index.php?option=com_users&view=remind' ) );
			$data->set( 'register',	JRoute :: _( 'index.php?option=com_users&view=registration' ) );
		}
		else {
			$data->set( 'pwreset',	JRoute :: _( 'index.php?option=com_user&view=reset' ) );
			$data->set( 'username',	JRoute :: _( 'index.php?option=com_user&view=remind' ) );
			$data->set( 'register',	JRoute :: _( 'index.php?option=com_user&task=register' ) );
		}
		
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	getReturnURL
	 * Purpose:		creates the return url for the form 
	 * As of:		version 2.0 (January 2010)
	\* ------------------------------------------------------------ */
	function getReturnURL($params, $cparams, $type )
	{
		$uri = new Juri();
		$curOption	= JwhmcsHelper :: get('option');
		$curView	= JwhmcsHelper :: get('view');
		
		if( $params->get( "redirectoverride", "0" ) ) {
			if ( $params->get( "redirectsuccess" ) )
				$url = JRoute::_($params->get( "redirectsuccess" ) );
			
			elseif (($curOption == 'com_jwhmcs') && ($curView == 'default'))
				return "<!-- JWHMCS RETURN URL -->";
			
			else
				$url = JRoute::_($uri->toString());
		}
		elseif ( ( $curOption == 'com_jwhmcs' ) && ( $curView == 'default' ) ) {
			return "<!-- JWHMCS RETURN URL -->";
		}
		else {
			$uri = new JURI( $cparams->get( "RedirLoginurl" ) );
			$url = $uri->toString();
		}
		
		return base64_encode($url);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	isContact
	 * Purpose:		Determines if the userid supplied is a contact 
	 * As of:		version 2.10 (April 2010)
	\* ------------------------------------------------------------ */
	function isContact( $userid )
	{
		// An id wasn't sent back by isLoggedin so they can't be a contact
		if ( ( $userid === true ) || ( $userid === false ) )
			return false;
		
		if ( $contactid = JwhmcsHelper :: get( 'contactid' ) )
			return true;
		
		$db		= & JFactory::getDBO();
		$user	= & JFactory::getUser();
		
		$query	=  "SELECT `xref_type` FROM #__jwhmcs_xref WHERE xref_a = {$user->id} AND xref_b = {$userid} AND xref_type IN (5,6,7,9)";
		$db->setQuery( $query );
		
		if (! $result = $db->loadObject() )
			return false;
		else
			return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	isLoggedin
	 * Purpose:		Check the status of the current user 
	 * As of:		version 2.0 (January 2010)
	\* ------------------------------------------------------------ */
	function isLoggedin( & $params = array() )
	{
		// Initialize variables
		$user		= & JFactory::getUser();
		$curOption	= JwhmcsHelper :: get('option');
		$curView	= JwhmcsHelper :: get('view');
		
		// Check Joomla User object to see if logged in
		if (! $user->guest) {
			$whmcsid = self::getWhmcsId($user->id);
			if ($whmcsid === false) {
				return true;
			}
			else {
				return $whmcsid;
			}
		}
		
		// Check variables for option and view to see if we are rendering site
		if (($curOption == 'com_jwhmcs') && ($curView == 'default')) {
			if ($clientid = JwhmcsHelper :: get('clientid'))
			{
				if ( $contactid = JwhmcsHelper :: get( 'contactid' ) )
					return $contactid;
				else
					return $clientid;
			}
		}
		return false;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	isSsl
	 * Purpose:		Determine if the url passed to it is using ssl 
	 * As of:		version 2.12 rc11 (October 2010)
	\* ------------------------------------------------------------ */
	function isSsl( $url = null)
	{
		if ( JwhmcsHelper :: get( 'usessl', false ) ) {
			$ssl = JwhmcsHelper :: get( 'usessl', false );
		}
		else if ( ( JwhmcsHelper :: get('option') == 'com_jwhmcs' ) && ( JwhmcsHelper :: get('view') == 'default' ) ) {
			$ssl = JwhmcsHelper :: get( 'usessl', false );
		}
		else {
			$uri = ( $url == null ? Juri::getInstance() : Juri::getInstance( $url ) );
			$ssl = $uri->isSSL();
		}
		
		return $ssl;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	isWhmcs
	 * Purpose:		Determines if the request is coming from WHMCS 
	 * As of:		version 2.12 rc9 (September 2010)
	\* ------------------------------------------------------------ */
	function isWhmcs( $params )
	{
		$isWhmcs = ( ( (JwhmcsHelper :: get('option') == 'com_jwhmcs') && (JwhmcsHelper :: get('view') == 'default') ) ? true : false );
		return ( $params->get( 'redirectwhmcs' ) == "1" ? true : ( $params->get( 'redirectwhmcs' ) == "2" ? false : $isWhmcs ) );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	getWhmcsId
	 * Purpose:		Retrieve the WHMCS ID for a Joomla ID 
	 * As of:		version 2.0 (January 2010)
	\* ------------------------------------------------------------ */
	function getWhmcsId( $id )
	{
		// Initialize variables
		$db		= & JFactory::getDBO();
		
		$query	=  "SELECT `xref_a`, `xref_type`, `xref_b`
					FROM #__jwhmcs_xref
					WHERE xref_a= $id AND xref_type BETWEEN 1 AND 7";
		$db->setQuery($query);
		
		if (! $result = $db->loadObjectList() ) {
			return false;
		} elseif ( count( $result ) > 1 ) {
			$results = $result[(count( $result ) - 1)];
		}
		else {
			$results = $result[0];
		}
		
		if ($results->xref_type == '4') {
			$query = "SELECT `email` FROM #__jwhmcs_group WHERE id = ".$results->xref_b;
			$db->setQuery($query);
			$email = $db->loadResult();
			
			$jcurl = JwhmcsCurl::getInstance();
			$jcurl->setAction('getclientsdatabyemail', array('email' => $email));
			$whmcs	= $jcurl->loadResult();
			return $whmcs['userid'];
		}
		/*elseif ( $results->xref_type > '4' ) {
			$jcurl = JwhmcsCurl::getInstance();
			$jcurl->setAction('jwhmcsgetcontact', array('get' => "id={$results->xref_b}"));
			$whmcs	= $jcurl->loadResult();
			return $whmcs['userid'];
		}*/
		else {
			return $results->xref_b;
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	getStylesheet
	 * Purpose:		Pulls a custom style sheet or standard sheet 
	 * As of:		version 2.1.0 (April 2010)
	\* ------------------------------------------------------------ */
	function getStylesheet()
	{
		$app	= & JFactory::getApplication();
		
		// Build the template and base path for the layout
		$tPath	= JPATH_BASE.DS.'templates'.DS.$app->getTemplate().DS.'html'.DS.'mod_jwhmcslogin'.DS;
		$tUrl	= "templates/".$app->getTemplate()."/html/mod_jwhmcslogin/";
		$bUrl	= "modules/mod_jwhmcslogin/tmpl/";
		
		// If the template has a layout override use it
		if (file_exists($tPath)) {
			return $tUrl;
		} else {
			return $bUrl;
		}
	}
	
	
	/**
	 * Get either a Gravatar URL or complete image tag for a specified email address.
	 *
	 * @param string $email The email address
	 * @param string $s Size in pixels, defaults to 80px [ 1 - 512 ]
	 * @param string $d Default imageset to use [ 404 | mm | identicon | monsterid | wavatar ]
	 * @param string $r Maximum rating (inclusive) [ g | pg | r | x ]
	 * @param boole $img True to return a complete IMG tag False for just the URL
	 * @param array $atts Optional, additional key/value attributes to include in the IMG tag
	 * @return String containing either just a URL or a complete image tag
	 * @source http://gravatar.com/site/implement/images/php/
	 */
	public function get_gravatar( $jparams, $email, $s = 80, $d = 'mm', $r = 'g', $img = false, $atts = array() )
	{
		$jid	= & self::get_xref_id();
		$user	= & JFactory::getUser( $jid );
		
		if (! is_null( $enable = JwhmcsHelper :: get( 'dg' ) ) ) {
			$user->setParam( 'display_gravatar', $enable );
			$user->save();
		}
		
		if ( $user->defParam( 'display_gravatar', '2' ) == '2' ) {
			$user->setParam( 'display_gravatar', false );
			$user->save();
		}
		
		if ( ( JwhmcsHelper :: get('option') == 'com_jwhmcs' ) && ( JwhmcsHelper :: get('view') == 'default' ) ) {
			$uri	= new Juri( $jparams->get( 'JoomlaUrl' ) );
			$uri->setVar( 'dg', ( $user->getParam( 'display_gravatar', false ) ? '0' : '1' ) );
			$option = $uri->toString();
		}
		else {
			$uri	= JUri::getInstance();
			$uri->setVar( 'dg', ( $user->getParam( 'display_gravatar', false ) ? '0' : '1' ) );
			$option	= $uri->toString();
		}
		
		if ( $user->getParam( 'display_gravatar', true ) == false ) {
			$email = 'donotdisplay@localhost.com';
		}
		
		$mode = self::isSsl();
		$url	= 'http' . ( $mode == true ? 's://secure' : '://www' ) . '.gravatar.com/avatar/';
		$url .= md5( strtolower( trim( $email ) ) );
		$url .= "?s=$s&d=$d&r=$r";
		if ( $img ) {
			$url = '<img src="' . $url . '"';
			foreach ( $atts as $key => $val )
				$url .= ' ' . $key . '="' . $val . '"';
			$url .= ' />';
		}
		
		return array( 'url' => $url, 'option' => $option, 'enabled' => $user->getParam( 'display_gravatar', false ) );
	}
	
	
	/**
	 * Retrieves the Joomla ID from the xref table for the user with client / contact ID
	 * @access		public
	 * @version		2.4.12
	 * 
	 * @return		integer containing id of user or null on none found
	 * @since		2.2.81
	 */
	public function get_xref_id()
	{
		$db			= & JFactory::getDbo();
		$status		=   self::isLoggedin();
		$contact	=   self::isContact( $status );
		
		if ( $contact ) {
			$sql = "SELECT `xref_a` FROM #__jwhmcs_xref WHERE xref_b = {$status} AND xref_type IN (5,6,7,9)";
		}
		else {
			$sql = "SELECT `xref_a` FROM #__jwhmcs_xref WHERE xref_b = {$status} AND xref_type IN (1,2,3,8)";
		}
		$db->setQuery( $sql );
		return $db->loadResult();
	}
}
?>