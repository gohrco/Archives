<?php
/**
 * Default Controller for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: usermgr.php 528 2012-07-12 22:34:03Z steven_gohigher $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );


/**
 * JWHCMS User Manager Controller
 * @author		Steven
 * @version		2.4.6
 *
 * @since		1.5.1
 */
class JwhmcsControllerUsermgr extends JwhmcsController
{
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		2.4.6
	 *
	 * @since		1.5.1
	 */
	public function __construct()
	{
		parent::__construct();

		// Register Extra tasks
		$this->registerTask( 'whmcsadd',		'whmcsedit' );
		$this->registerTask( 'joomadd',			'joomedit' );
		$this->registerTask( 'joomaddsave', 	'joomeditsave' );
		$this->registerTask( 'whmcsaddsave',	'whmcseditsave' );
	}
	
	
	/**
	 * joomedit task allowing for editing of joomla users
	 * @access		public
	 * @version		2.4.6
	 *
	 * @since		1.5.1
	 */
	public function joomedit()
	{
		JwhmcsHelper :: set( 'view', 'usermgr' );
		JwhmcsHelper :: set( 'layout', 'formjoomla' );
		JwhmcsHelper :: set( 'hidemainmenu', 1 );
		parent::display();
	}
	
	
	/**
	 * whmcs edit task allows for adding of WHMCS users
	 * @access		public
	 * @version		2.4.6
	 *
	 * @since		1.5.1
	 */
	 public function whmcsedit()
	{
		JwhmcsHelper :: set( 'view', 'usermgr' );
		JwhmcsHelper :: set( 'layout', 'formwhmcs' );
		JwhmcsHelper :: set( 'hidemainmenu', 1 );
		parent::display();
	}
	
	
	/**
	 * Task to handle saving of Joomla user info
	 * @access		public
	 * @version		2.4.6
	 *
	 * @since		1.5.1
	 */
	public function joomeditsave()
	{
		$model		= $this->getModel( 'usermgr' );
		$form		= JwhmcsHelper :: get( 'form' );
		$task		= JwhmcsHelper :: get( 'task' );
		
		if ( $model->joomsave($form, $task) )
		{
			$msg	= JText::_( "COM_JWHMCS_USERMGR_CTRL_USRJSY" );
		} else {
			$msg	= JText::_( "COM_JWHMCS_USERMGR_CTRL_USRJSN" );
		}
		
		$link = 'index.php?option=com_jwhmcs&controller=usermgr';
		$this->setRedirect($link, $msg);
	}
	
	
	/**
	 * Task to handle saving of WHMCS user info
	 * @access		public
	 * @version		2.4.6
	 *
	 * @since		1.5.1
	 */
	public function whmcseditsave()
	{
		$model		= $this->getModel( 'usermgr' );
		$post		= JwhmcsHelper :: get( 'form' );
		$task		= JwhmcsHelper :: get( 'task' );
		
		$result		= $model->whmcsaddsave($post, $task);
		if ($result['result'] != 'success')
		{
			$msg = JText::sprintf( "COM_JWHMCS_USERMGR_CTRL_USRWSN", $result['message'] );
		} else {
			$msg = JText::_( "COM_JWHMCS_USERMGR_CTRL_USRWSY" );
		}
		
		$link = 'index.php?option=com_jwhmcs&controller=usermgr';
		$this->setRedirect($link, $msg);
	}
	
	
	/**
	 * Task to set the xref so username is requested at login
	 * @access		public
	 * @version		2.4.6
	 *
	 * @since		2.1.0
	 */
	public function changeUsername()
	{
		$model	= $this->getModel('usermgr');
		$post	= JwhmcsHelper :: get( 'x' );
		
		if ($model->changeUsername($post))
			$msg	= JText::_( "COM_JWHMCS_USERMGR_CTRL_CUSY" );
		else
			$msg	= JText::_( "COM_JWHMCS_USERMGR_CTRL_CUSN" );
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', $msg );
	}
	
	
	/**
	 * Task to change ALL usernames to be requested at login
	 * @access		public
	 * @version		2.4.6
	 *
	 * @since		2.1.0
	 */
	public function changeAllusername()
	{
		$model	= $this->getModel('usermgr');
		
		if ($model->changeAllusername())
			$msg	= JText::_( "COM_JWHMCS_USERMGR_CTRL_CUSY" );
		else
			$msg	= JText::_( "COM_JWHMCS_USERMGR_CTRL_CUSN" );
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', $msg );
	}
	
	
	public function cleanup()
	{
		$model	= $this->getModel( 'usermgr' );
		$msg	= 'COM_JWHMCS_USERMGR_CTRL_CLEANED_' . ( ( $msg = $model->cleanup() ) === true ? 'SUCCESS' : $msg );
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', JText :: _( $msg ) );
	}
	
	
	/**
	 * Task to sync users found by email
	 * @access		public
	 * @version		2.4.6
	 * 
	 * @since		1.5.1
	 */
	public function sync()
	{
		$model	= $this->getModel('usermgr');
		$post	= JwhmcsHelper :: get( 'method' );
		
		if ($model->syncUser($post))
			$msg	= JText::_( "COM_JWHMCS_USERMGR_CTRL_USRSY" );
		else
			$msg	= JText::_( "COM_JWHMCS_USERMGR_CTRL_USRSN" );
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', $msg );
	}
	
	
	/**
	 * Task to break the sync match of a user
	 * @access		public
	 * @version		2.4.6
	 *
	 * @since		1.5.1
	 */
	public function syncBreak()
	{
		$model	= $this->getModel('usermgr');
		$post	= JwhmcsHelper :: get( 'x' );
		
		if ($model->syncBreak($post))
			$msg	= JText::_( "COM_JWHMCS_USERMGR_CTRL_USRSBY" );
		else
			$msg	= JText::_( "COM_JWHMCS_USERMGR_CTRL_USRSBN" );
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', $msg );
	}
	
	
	/**
	 * Task to match all Joomla users to WHMCS users
	 * @access		public
	 * @version		2.4.6
	 *
	 * @since		2.0.2
	 */
	public function matchAll()
	{
		$model	= $this->getModel('usermgr');
		
		if ($model->matchAll())
			$msg	= JText::_( "COM_JWHMCS_USERMGR_CTRL_USRSMY" );
		else
			$msg	= JText::_( "COM_JWHMCS_USERMGR_CTRL_USRSMN" );
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', $msg );
	}
	
	
	/**
	 * Task to allow canceling an edit
	 * @access		public
	 * @version		2.4.6
	 *
	 * @since		1.5.1
	 */
	public function cancel()
	{
		$msg = JText::_( "COM_JWHMCS_USERMGR_CTRL_MSGCNCL" );
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', $msg );
	}
}