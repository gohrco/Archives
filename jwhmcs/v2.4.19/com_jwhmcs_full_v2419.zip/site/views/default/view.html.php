<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.4.19 ( $Id: view.html.php 555 2012-09-06 02:10:32Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      1.5.0
 * 
 * @desc       Default View:  This file handles assembling the data and rendering the view to the user
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * Default view is used to render the wrapper around WHMCS
 * @version		2.3.0
 * 
 * @since		1.5.0
 * @author		Steven
 */
class JwhmcsViewDefault extends JwhmcsViewExt
{
	/**
	 * Builds the view from the display task for the user
	 * @access		public
	 * @version		2.3.0
	 * @param 		string		$tpl - presumably a template name never used
	 * 
	 * @since		1.5.0
	 */
	public function display($tpl = null)
	{
		// Load data for register layout
		$app		= & JFactory::getApplication();
		$tplparams	=	$app->getParams();
		$params		= &	JwhmcsParams::getInstance();
		$uri		= &	JURI::getInstance();
		$document	= &	JFactory::getDocument();
		
		$whmcsurl	= & JUri::getInstance( $params->get( 'ApiUrl' ), true );
		$whmcsurl->setPath( rtrim( $whmcsurl->getPath(), "/" ) . "/includes/jscript/" );
		
		if ($params->get( 'RenderJqueryenable' )) {
			if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
				//JHtml :: script('jquery.js', $whmcsurl->toString( array( 'scheme', 'host', 'path' ) ), true);
			}
			else {
				//JHtml :: script('jquery.js', rtrim( $params->get( 'ApiUrl' ), "/" ) . '/includes/jscript/', true);
			}
			
			//JwhmcsHelper :: addMedia( 'noconflict/js' );
		}
		
		$base = & $document->getBase();
		
		if( empty( $base ) ) {
			$document->setBase( $uri->toString( array('scheme', 'host', 'path') ) );
		}
		
		// Include CSS reset ?
		if ( $params->get( "RenderCssreset" ) ) {
			JwhmcsHelper :: addMedia( 'wrapper/css' );
		}
		
		$this->assignRef('params',	$tplparams);
		
		parent::display($tpl);
		
	}
}