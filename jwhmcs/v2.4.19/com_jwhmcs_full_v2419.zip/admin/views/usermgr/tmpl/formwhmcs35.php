<?php defined('_JEXEC') or die('Restricted access');

$isNew	= (isset($this->data->id)?($this->data->id < 1?true:false):true);

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('behavior.keepalive');

?>


<script type="text/javascript">
	Joomla.submitbutton = function( task ) {
		if ( task == 'cancel' || document.formvalidator.isValid(document.id('item-form'))) {
			Joomla.submitform(task, document.getElementById('item-form'));
		} else {
			alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED'));?>');
		}
	}
</script>

<form id="item-form" name="adminForm" method="post" class="form-validate form-horizontal">

	<div class="control-group">
		<div class="control-label">
			<label for="form[firstname]" class="hasTip" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WNAME" ); ?>::<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WNAME" ); ?>"><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WNAME" ); ?></label>
		</div>
		<div class="controls">
			<input class="text_area required" placeholder="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WFNAME" ); ?>" type="text" name="form[firstname]" id="form[firstname]" size="50" maxlength="255" value="<?php echo $isNew?'':$this->data->firstname; ?>" />
			<input class="text_area required" placeholder="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WLNAME" ); ?>" type="text" name="form[lastname]" id="form[lastname]" size="50" maxlength="255" value="<?php echo $isNew?'':$this->data->lastname;?>" />
		</div>
	</div>
	
	<div class="control-group">
		<div class="control-label">
			<label for="form[companyname]" class="hasTip" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCNAME" ); ?>::<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCNAME" ); ?>"><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCNAME" ); ?></label>
		</div>
		<div class="controls">
			<input class="text_area" placeholder="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCNAME" ); ?>" type="text" name="form[companyname]" id="form[companyname]" size="50" maxlength="255" value="<?php echo $isNew?'':$this->data->companyname;?>" />
		</div>
	</div>
	
	<div class="control-group">
		<div class="control-label">
			<label for="form[address1]" class="hasTip" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WADDR" ); ?>::<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WADDR" ); ?>"><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WADDR" ); ?></label>
		</div>
		<div class="controls">
			<p><input class="text_area required" placeholder="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WADDR1" ); ?>" type="text" name="form[address1]" id="form[address1]" size="50" maxlength="255" value="<?php echo $isNew?'':$this->data->address1;?>" /></p>
			<input class="text_area" placeholder="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WADDR2" ); ?>" type="text" name="form[address2]" id="form[address2]" size="50" maxlength="255" value="<?php echo $isNew?'':$this->data->address2;?>" />
		</div>
	</div>
	
	<div class="control-group">
		<div class="control-label">
			<label for="form[city]" class="hasTip" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCSTZIP" ); ?>::<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCSTZIP" ); ?>"><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCSTZIP" ); ?></label>
		</div>
		<div class="controls">
			<p><input class="text_area required" placeholder="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCITY" ); ?>" type="text" name="form[city]" id="form[city]" size="40" maxlength="255" value="<?php echo $isNew?'':$this->data->city;?>" /></p>
			<p><input class="text_area required" placeholder="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WSTATE" ); ?>" type="text" name="form[state]" id="form[state]" size="40" maxlength="255" value="<?php echo $isNew?'':$this->data->state;?>" /></p>
			<p><input class="text_area required" placeholder="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WPOSTAL" ); ?>" type="text" name="form[postcode]" id="form[postcode]" size="40" maxlength="255" value="<?php echo $isNew?'':$this->data->postcode;?>" /></p>
			<?php echo JHtml :: _( 'select.genericlist', JwhmcsHelper::buildCountries( true ), 'form[country]', null, 'value', 'text', $this->data->country, 'country' ); ?>
		</div>
	</div>
	
	<div class="control-group">
		<div class="control-label">
			<label for="form[phonenumber]" class="hasTip" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCONTACT" ); ?>::<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCONTACT" ); ?>"><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCONTACT" ); ?></label>
		</div>
		<div class="controls">
			<p><input class="text_area required" placeholder="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WPHONE" ); ?>" type="text" name="form[phonenumber]" id="form[phonenumber]" size="25" maxlength="255" value="<?php echo $isNew?'':$this->data->phonenumber;?>" /></p>
			<input class="text_area" type="text" name="form[emaildis]" id="email" size="50" maxlength="255" value="<?php echo $this->data->email;?>" disabled />
		</div>
	</div>

	<input type="hidden" name="option" value="com_jwhmcs" />
	<input type="hidden" name="whmcsid" value="<?php echo $this->data->id; ?>" />
	<input type="hidden" name="joomlaid" value="<?php echo $this->data->jid; ?>" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="subtask" value="<?php echo JRequest::getVar( 'task' ); ?>" />
	<input type="hidden" name="controller" value="usermgr" />
	<input type="hidden" name="form[email]" value="<?php echo $this->data->email; ?>" />
	<input type="hidden" name="password2" value="temppassword" />
	
</form>