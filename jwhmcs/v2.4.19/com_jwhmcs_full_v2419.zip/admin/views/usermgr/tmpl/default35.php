<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');
jimport( "joomla.user.helper" );
?>

<form action="index.php" method="post" name="adminForm" id="adminForm">

	<table class="table">
		<thead>
			<tr>
				<th>
					<div class="jwhmcs-hdr"><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_LABEL_JUSERS' ); ?></div>
					<select name="filter_jusers" onchange="document.adminForm.submit(); ">
						<option value="0"<?php echo $this->sort['jusers']==0?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_ALL_USERS' ); ?></option>
						<option value="1"<?php echo $this->sort['jusers']==1?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_MATCHED_USERS_ONLY' ); ?></option>
						<option value="2"<?php echo $this->sort['jusers']==2?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_UNMATCHED_USERS_ONLY' ); ?></option>
					</select>
				</th>
				<th>
					<div class="jwhmcs-hdr"><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_LABEL_MATCHES' ); ?></div>
					<select name="filter_matches" onchange="document.adminForm.submit(); ">
						<option value="-1"<?php echo $this->sort['matches']==-1?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_UNMATCHED_USERS_ONLY' ); ?></option>
						<option value="0"<?php echo $this->sort['matches']==0?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_ALL_USERS' ); ?></option>
						<option value="1"<?php echo $this->sort['matches']==1?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_USER_MATCHES' ); ?></option>
						<option value="2"<?php echo $this->sort['matches']==2?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_FOUND_MATCHES' ); ?></option>
						<option value="3"<?php echo $this->sort['matches']==3?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_CREATED_MATCHES' ); ?></option>
						<option value="4"<?php echo $this->sort['matches']==4?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_GROUP_USERS' ); ?></option>
					</select>
				</th>
				<th>
					<div class="jwhmcs-hdr"><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_LABEL_WUSERS' ); ?></div>
					<select name="filter_wusers" onchange="document.adminForm.submit(); ">
						<option value="0"<?php echo $this->sort['wusers']==0?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_ALL_USERS' ); ?></option>
						<option value="1"<?php echo $this->sort['wusers']==1?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_MATCHED_USERS_ONLY' ); ?></option>
						<option value="2"<?php echo $this->sort['wusers']==2?' selected':''; ?>><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_PARAM_UNMATCHED_USERS_ONLY' ); ?></option>
					</select>
				</th>
			</tr>
			<tr>
				<th class="title">
					<div class="jwhmcs-hdr"><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_LABEL_JSORTBY' ); ?></div>
					<div class="jwhmcs-hdrsort">
					<?php echo $this->sort['joomla']; ?>
					</div>
				</th>
				<th class="title">
					<div class="input-prepend">
						<span class="add-on"><i class="icon-search"></i></span><input type="text" name="user_search" id="user_search" value="<?php echo $this->sort['user_search'] ?>" class="text_area" onchange="document.adminForm.submit();" />
						<button class="btn" onclick="this.form.submit();"><?php echo JText::_( 'Go' ); ?></button>
						<button class="btn" onclick="document.getElementById('user_search').value='';this.form.submit();"><?php echo JText::_( 'Reset' ); ?></button>
					</div>
				</th>
				<th class="title">
					<div class="jwhmcs-hdr"><?php echo JText::_( 'COM_JWHMCS_USERMGR_VIEW_LABEL_WSORTBY' ); ?></div>
					<div class="jwhmcs-hdrsort">
					<?php echo $this->sort['whmcs']; ?>
					</div>
				</th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="3">
					<?php echo $this->pagination->getListFooter(); ?>
				</td>
			</tr>
		</tfoot>
		<tbody>
		
			<?php for ( $i = 0, $n = count( $this->data ); $i < $n; $i++ ) : ?>
			<tr>
				<?php echo buildrow( $this->data[$i], $i ); ?>
			</tr>
			
			<?php endfor; ?>
		</tbody>
	</table>
	
	<input type="hidden" name="option" value="com_jwhmcs" />
	<input type="hidden" name="controller" value="usermgr" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="sortby" value="<?php echo $this->sort['sortby']; ?>" />
	<input type="hidden" name="sortord" value="<?php echo $this->sort['sortord']; ?>" />
	<?php echo JHTML::_( 'form.token' ); ?>
</form>

<?php 

function buildrow( $data, $cnt )
{
	$disp	= array();
	$img	= ( $data->jblock ? 'publish_x' : 'tick' ) . '.png';
	$task	= ( $data->jblock ? 'unblock' : 'block' );
	$alt	= JText :: _( 'COM_JWHMCS_USERMGR_VIEW_LABEL_JUSER_' . ( $data->jblock ? 'BLOCKED' : 'ENABLED' ) );
	
	$disp	= array(
			'break'		=> array( 'display' => false, 'img' => JUri :: root() . 'media/com_jwhmcs/icons/j-32-userunlock.png', 'link' => JRoute::_('index.php?option=com_jwhmcs&controller=usermgr&task=syncbreak&x[xa]='.$data->jid.'&x[xb]='.$data->wid.'&x[xt]='.$data->xref_type), 'icon' => 'userunlock', 'title' => JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_BRKMATCH" ) ),
			'find'		=> array( 'display' => false, 'img' => JUri :: root() . 'media/com_jwhmcs/icons/j-32-userfind.png', 'link' => JRoute::_('index.php?option=com_jwhmcs&controller=usermgr&task=sync&'.($data->wid?'whmcs':'joom').'id='.($data->wid?$data->wid:$data->jid)), 'icon' => 'userfind', 'title' => JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_FNDMATCH" ) ),
			'findsub'	=> array( 'display' => false, 'img' => JUri :: root() . 'media/com_jwhmcs/icons/j-32-userfind.png', 'link' => JRoute::_("index.php?option=com_jwhmcs&controller=usermgr&task=sync&whsubid={$data->wid}"), 'icon' => 'userfind', 'title' => JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_FNDMATCH" ) ),
			'add'		=> array( 'display' => false, 'img' => JUri :: root() . 'media/com_jwhmcs/icons/j-32-useradd.png', 'link' => JRoute::_('index.php?option=com_jwhmcs&controller=usermgr&task='.($data->wid?'joom':'whmcs').'add&'.($data->wid?'whmcs':'joomla').'id='.($data->wid?$data->wid:$data->jid)), 'icon' => 'useradd', 'title' => JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_FORCEADD" ) ),
			'addsub'	=> array( 'display' => false, 'img' => JUri :: root() . 'media/com_jwhmcs/icons/j-32-useradd.png', 'link' => JRoute::_("index.php?option=com_jwhmcs&controller=usermgr&task=joomadd&wcontid={$data->wid}"), 'icon' => 'useradd', 'title' => JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_FORCEADD" ) ),
			'update'	=> array( 'display' => false, 'img' => JUri :: root() . 'media/com_jwhmcs/icons/j-32-userupdate.png', 'link' => JRoute::_('index.php?option=com_jwhmcs&controller=usermgr&task=changeUsername&x[xa]='.$data->jid.'&x[xb]='.$data->wid.'&x[xt]='.$data->xref_type), 'icon' => 'userupdate', 'title' => JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_CHUSERNAME" ) ),
			'group'		=> array( 'display' => false, 'img' => JUri :: root() . 'media/com_jwhmcs/icons/j-32-grpmgr.png', 'link' => JRoute::_('index.php?option=com_jwhmcs&controller=grpmgr&task=userlist&cid='.$data->wid), 'icon' => 'userunlock', 'title' => JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_MANGROUP" ) )
			);
	
	switch( $data->xref_type ) {
		case '-1' :
			$disp['findsub']['display']	= true;
			$disp['addsub']['display']	= true;
			break;
		case '0' :
		case '4' :
			$disp['group']['display']	= true;
			break;
		case null :
			$disp['find']['display']	= true;
			$disp['add']['display']		= true;
			break;
		case '8' :
		case '9' :
			$disp['break']['display']	= true;
			break;
		default :
			$disp['break']['display']	= true;
			$disp['update']['display']	= true;
			break;
	}
	
	// We have a Joomla user
	if ( $data->jid ) {
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$jblock	= $data->jblock ? 0 : 1;
		}
		else {
			$jblock	= new stdClass();
			$jblock->published = $data->jblock ? 0 : 1;
		}
		
		$jalign		= 'top';
		$username	= ( $data->xref_type == 0 ? '' : "US:  {$data->jusername}<br/>" );
		$groups		= $data->jgroupname;
		$block		= JHtml :: _( "grid.published", $jblock, $cnt );
		$idlabel	= JText :: _( 'COM_JWHMCS_USERMGR_VIEW_LABEL_' . ( $data->xref_type == 0 ? 'GROUPID' : 'JOOMLAID' ) );
		
		
		$jcontent	=	<<<HTML
<strong>{$data->jname}</strong>
<div style="margin-left: 30px; ">
{$username}{$groups}<br/>
<a href="mailto:{$data->jemail}">{$data->jemail}</a><br/>
{$block}
{$idlabel} {$data->jid}
</div>
HTML;
		
	}
	// We do not have a Joomla user
	else {
		$jalign		= 'middle';
		$jcontent = '<div style="vertical-align: middle; text-align: center; width: 100%; ">' . JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_NOJUSERM" ) . '</div>';
	}
	
	
	// We have a WHMCS user
	if ( $data->wid ) {
		$walign	=	'top';
		$label	=	JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_WTXT{$data->xref_type}" );
		$wuser	=	( isset( $data->wcname ) ? $data->wcname . '<br/>' : '' )
				.	( isset( $data->waddress1 ) ? $data->waddress1 . '<br/>' : '' )
				.	( isset( $data->waddress2 ) ? $data->waddress2 . '<br/>' : '' )
				.	( isset( $data->wcity ) ? $data->wcity . '<br/>' : '' )
				.	( isset( $data->wstate ) ? $data->wstate . '<br/>' : '' )
				.	( isset( $data->wpostcode ) ? $data->wpostcode . '<br/>' : '' )
				.	( isset( $data->wcountry ) ? $data->wcountry . '<br/>' : '' )
				.	( isset( $data->wphonenumber ) ? 'Phone: ' . $data->wphonenumber . '<br/>' : '' );
		
		$wcontent	= <<<HTML
<strong>{$data->wfname}&nbsp;{$data->wlname}</strong>
<div style="margin-left: 30px; ">
	{$wuser}
	<a href="mailto:{$data->wemail}">{$data->wemail}</a><br/>
	{$label} #: {$data->wid}
</div>
HTML;
	}
	// We do not have a WHMCS user
	else {
		$walign		=	'middle';
		$wcontent	=	'<div style="vertical-align: middle; text-align: center; width: 100%; ">'.JText::_( "COM_JWHMCS_USERMGR_VIEW_MSG_NOWUSER" ).'</div>';
	}
	
	$buttons	= null;
	foreach ( $disp as $item ) {
		if ( $item['display'] === false ) continue;
		$buttons	.=	'<a class="btn span1" href="' . $item['link'] . '">'
					.	'<img src="' . $item['img'] . '" />'
					.	'<span class="linktitle" title="' . $item['title'] . '">' . $item['title'] . '</span></a>';
	}
	
	$msg	= JText :: _( "COM_JWHMCS_USERMGR_VIEW_MSG_X{$data->xref_type}" );
	
	$return	= <<<HTML

<td style="vertical-align: {$jalign}; ">
	{$jcontent}
</td>
<td align="center" style="vertical-align: middle; ">
	<div class="row-fluid">
		<div class="span12 axnicon-x{$data->xref_type} axnicon">
			<h3 class="axnhdr">{$msg}</h3>
		</div>
	</div>
	<div class="span12 cpanel">
		{$buttons}
	</div>
</td>
<td style="vertical-align: {$walign}; ">
	{$wcontent}
</td>
HTML;
	
	return $return;
}
