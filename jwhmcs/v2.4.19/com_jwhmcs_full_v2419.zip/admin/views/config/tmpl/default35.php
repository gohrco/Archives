<?php  defined('_JEXEC') or die('Restricted access');

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('behavior.keepalive');

$data = $this->data;

$global_config	= $this->data->global;
$user_config	= $this->data->user;
$kayako_config	= $this->data->kayako;
$style_config	= $this->data->style;
// $whmcs_config	= $this->data->whmcs;
$reg_config		= $this->data->registration;
$recap_config	= $this->data->recaptcha;
$lang_config	= $this->data->language;
$menu_config	= $this->data->menu;
$upd_config		= $this->data->updates;
$adv_config		= $this->data->install;

$allitems		= array( 'global_config', 'user_config', 'kayako_config', 'style_config', 'reg_config', 'recap_config', 'lang_config', 'menu_config', 'upd_config', 'adv_config' );


$active = true;
?>

<script type="text/javascript">
	Joomla.submitbutton = function( task ) {
		if (task == 'cpanel' || document.formvalidator.isValid(document.id('item-form'))) {
			
			Joomla.submitform(task, document.getElementById('item-form'));
		} else {
			alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED'));?>');
		}
	}
</script>

<div class="tabWrapper">
<form action="index.php" method="post" name="adminForm" id="item-form" class="form-validate form-horizontal">

<ul class="nav nav-tabs">
<li class="active"><a data-toggle="tab" href="#global_config"><?php echo JText::_('COM_JWHMCS_CONFIG_GLOBAL2_TAB'); ?></a></li>
<li><a data-toggle="tab" href="#user_config"><?php echo JText :: _( 'COM_JWHMCS_CONFIG_USER2_TAB' ); ?></a></li>
<li><a data-toggle="tab" href="#kayako_config"><?php echo JText :: _( 'COM_JWHMCS_CONFIG_KAYAKO_TAB' ); ?></a></li>
<li><a data-toggle="tab" href="#style_config"><?php echo JText :: _( 'COM_JWHMCS_CONFIG_STYLE2_TAB' ); ?></a></li>
<li><a data-toggle="tab" href="#reg_config"><?php echo JText :: _( 'COM_JWHMCS_CONFIG_REGISTRATION_TAB' ); ?></a></li>
<li><a data-toggle="tab" href="#recap_config"><?php echo JText :: _( 'COM_JWHMCS_CONFIG_RECAPTCHA_TAB' ); ?></a></li>
<li><a data-toggle="tab" href="#lang_config"><?php echo JText :: _( 'COM_JWHMCS_CONFIG_LANGUAGE2_TAB' ); ?></a></li>
<li><a data-toggle="tab" href="#menu_config"><?php echo JText :: _( 'COM_JWHMCS_CONFIG_MENU_TAB' ); ?></a></li>
<li><a data-toggle="tab" href="#upd_config"><?php echo JText :: _( 'COM_JWHMCS_CONFIG_UPDATE_TAB' ); ?></a></li>
<li><a data-toggle="tab" href="#adv_config"><?php echo JText :: _( 'COM_JWHMCS_CONFIG_INSTALL_TAB' ); ?></a></li>
</ul>

<div class="tab-content">

	<?php 
	foreach ( $allitems as $itemset ) :
		$isactive = $active ? ' active' : ''; $active = false;
	?>
	
	<div id="<?php echo $itemset; ?>" class="tab-pane<?php echo $isactive; ?>">
		<?php foreach ($$itemset as $item): ?>
		<?php if (!$item->display) continue; ?>
		<div class="control-group">
			<div class="control-label">
				<label class="hasTip" title="<?php echo $item->name; ?>::<?php echo $item->desc; ?>"><?php echo $item->name; ?></label>
			</div>
			<div class="controls">
				<?php echo $item->field; ?>
			</div>
		</div>
		<?php endforeach; ?>
	</div>
	
	<?php endforeach; ?>
	
	
</div>

<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="config" />
</form>
</div>