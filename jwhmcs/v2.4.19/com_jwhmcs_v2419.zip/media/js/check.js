function beginCheck(step,last,caller)
{
	$('laststep').setProperty('value', last);
	
	for(i=step; i<=last; i=i+10) {
		ajaxStatus = document.getElementById('checkStep'+i);
		ajaxStatus.removeClass('ajaxLoading').removeClass('ajaxSuccess').removeClass('ajaxError').removeClass('ajaxAlert');
		ajaxMessage = document.getElementById('checkMessage'+i);
		//ajaxMessage.set('html','');
		mySetHTML( ajaxMessage, '' );
	}
	runCheck(step);
}


function beginFix(step)
{
	ajaxStatus = document.getElementById('checkStep'+step);
	ajaxStatus.removeClass('ajaxLoading').removeClass('ajaxSuccess').removeClass('ajaxError').removeClass('ajaxAlert');
	ajaxMessage = document.getElementById('checkMessage'+step);
	//ajaxMessage.set('html','');
	mySetHTML( ajaxMessage, '' );
	runFix(step);
}


function runCheck(step)

{
	var ajaxStatus = document.getElementById('checkStep'+step);
	var ajaxMessage = document.getElementById('checkMessage'+step);
	var url = document.getElementById('thisUrl').getProperty('value')+"?option=com_jwhmcs&controller=ajax&task=checkinstall&step="+step;
	var laststep = document.getElementById('laststep').getProperty('value');
	
	ajaxStatus.removeClass('ajaxInitial');
	ajaxStatus.addClass('ajaxLoading');
	//ajaxMessage.set('html','');
	mySetHTML( ajaxMessage, '' );
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var rawtxt = xhr.responseText.trim();
				var resp = parseXml( rawtxt );
				var nextStep = resp.getElementsByTagName("nextstep")[0].childNodes[0].nodeValue;
				var curStatus = resp.getElementsByTagName("status")[0].childNodes[0].nodeValue;
				var message  = resp.getElementsByTagName("message");
				var txt = ajaxMessage.innerHTML;
				var i=0;
				
				for (i=0; i<message.length; i++) {
					txt = message[i].childNodes[0].nodeValue + "\n" + txt;
				}
				//ajaxMessage.set('html',txt);
				mySetHTML( ajaxMessage, txt );
				
				document.getElementById('step').setProperty('value', nextStep);
				
				ajaxStatus.removeClass('ajaxLoading');
				if (curStatus == '1') {
					ajaxStatus.addClass('ajaxSuccess');
				}
				else if (curStatus == '0' ) {
					ajaxStatus.addClass('ajaxError');
				}
				else {
					ajaxStatus.addClass('ajaxAlert');
				}
				
				if (step != laststep) {
					runCheck(nextStep);
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function runFix(step)
{
	var ajaxStatus = document.getElementById('checkStep'+step);
	var ajaxMessage = document.getElementById('checkMessage'+step);
	var url = document.getElementById('thisUrl').getProperty('value')+"?option=com_jwhmcs&controller=ajax&task=fixinstall&step="+step;
	
	ajaxStatus.removeClass('ajaxInitial');
	ajaxStatus.addClass('ajaxLoading');
	mySetHTML( ajaxMessage, '' );
	
	var xhr = createXHR();
	xhr.open("GET",url,true);
	xhr.send(null);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				var rawtxt = xhr.responseText.trim();
				var resp = parseXml( rawtxt );
				var curStatus = resp.getElementsByTagName("status")[0].childNodes[0].nodeValue;
				var message  = resp.getElementsByTagName("message");
				var txt = ajaxMessage.innerHTML;
				var i=0;
				
				for (i=0; i<message.length; i++) {
					txt = message[i].childNodes[0].nodeValue + "\n" + txt;
				}
				mySetHTML( ajaxMessage, '' );
				
				ajaxStatus.removeClass('ajaxLoading');
				if (curStatus == '1') {
					ajaxStatus.addClass('ajaxSuccess');
				}
				else if (curStatus == '0' ) {
					ajaxStatus.addClass('ajaxError');
				}
				else {
					ajaxStatus.addClass('ajaxAlert');
				}
			} else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}