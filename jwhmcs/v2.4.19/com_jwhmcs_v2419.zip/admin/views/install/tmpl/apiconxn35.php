<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');
JHTML::_('behavior.formvalidation');

$data = $this->data;
?>
<script type="text/javascript">
	Joomla.submitbutton = function( task ) {
		if ( document.formvalidator.isValid(document.id('item-form'))) {
			
			Joomla.submitform(task, document.getElementById('item-form'));
		} else {
			alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED'));?>');
		}
	}
</script>

<form action="index.php" method="post" name="adminForm" id="item-form">
<div id="adminInput">
	<table class="admintable" width="675px" border="0">
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_WHMCSURL_TEXT" ); ?>
				</div>
				<div class="paramdesc">
				<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_WHMCSURL_DESC" ); ?>
				</div>
			</td>
			<td rowspan="11" width="220px" valign="top">
				<div id="apistatus">
					<div id="apistatusimg"></div>
					<div id="apistatusmsg" style="width: 200px; margin: 0px auto; font-size: small; font-weight: bold; clear: both; padding: 10px; text-align: center; "></div>
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="text" name="jwhmcsurl" value="<?php echo $data->jwhmcsurl; ?>" size="40" style="font-size: 14px; " onChange="checkAPIInterface();" id="jwhmcsurl" />
			</td>
		<tr><td>&nbsp;</td></tr>
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_APIUSERNAME_TEXT" ); ?>
				</div>
				<div class="paramdesc">
				<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_APIUSERNAME_DESC" ); ?>
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="text" name="jwhmcsadminus" value="<?php echo $data->jwhmcsadminus; ?>" size="40" style="font-size: 14px; " id="jwhmcsadminus" onChange="checkAPIInterface();" />
			</td>
		</tr>
		<tr><td>&nbsp;</td></tr>
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_APIPASSWORD_TEXT" ); ?>
				</div>
				<div class="paramdesc">
				<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_APIPASSWORD_DESC" ); ?>
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="password" name="jwhmcsadminpw" value="<?php echo $data->jwhmcsadminpw; ?>" size="40" style="font-size: 14px; " id="jwhmcsadminpw" onChange="checkAPIInterface();" />
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_APIACCESSKEY_TEXT" ); ?>
				</div>
				<div class="paramdesc">
				<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_APIACCESSKEY_DESC" ); ?>
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area" type="text" name="accesskey" value="<?php echo $data->accesskey; ?>" size="40" style="font-size: 14px; " id="accesskey" onChange="checkAPIInterface();" />
			</td>
		</tr>
	</table>
</div>
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="apiconnection" id="apiconnection" value="0" />
<input type="hidden" name="task" value="apiconxnAccept" />
<input type="hidden" name="controller" value="install" />
<input type="hidden" id="apistatusmsgdefault" value="<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_STATUSDEFAULT" ); ?>" />
</form>
<script language="javascript">
window.onload = checkAPIInterface();
</script>