<?php
/**
 * @package		J!WHMCS Integrator:  Login Module
 * @copyright	Copyright (C) 2010 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: mod_jwhmcslogin.php 171 2011-02-05 00:03:04Z steven_gohigher $
 * @since		2.0.0
 */

defined('_JEXEC') or die('Restricted access');

/**
 * Called at installation
 * @author 		Steven
 * @version		2.4.19
 * 
 * @since		2.3.2
 */
class mod_jwhmcsloginInstallerScript
{
	/**
	 * Called after the module has been installed or updated
	 * @access		public
	 * @version		2.4.19
	 * @param		string		- $type: contains the type of installation performed
	 * @param 		object		- $parent: the parent object calling the script
	 * 
	 * @since		2.3.2
	 */
	function postflight( $type, $parent )
	{
		// Check to see if we are installing on Joomla 3.0+
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			$path			=	JPATH_SITE			. DIRECTORY_SEPARATOR
							.	'modules'			. DIRECTORY_SEPARATOR
							.	'mod_jwhmcslogin'	. DIRECTORY_SEPARATOR;
			
			JFile :: move( 'mod_jwhmcslogin_30.xml', 'mod_jwhmcslogin.xml', $path );
		}
		
		if ( $type != "Install" ) return;
		
		$db = & JFactory::getDbo();
		
		$query	= "UPDATE `#__modules` SET `title` = 'Client Login' WHERE `module`='mod_jwhmcslogin' AND `client_id`=0";
		$db->setQuery($query);
		$db->query();
		
		return;
	}
}