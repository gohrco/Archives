<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.5.5 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.4.0
 * 
 * @desc       This is the updates controller file for the backend of J!WHMCS Integrator
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
if ( file_exists( $path = JPATH_COMPONENT_ADMINISTRATOR . DS . 'update' . DS . 'update.php' ) )
	require_once( $path );
/*-- File Inclusions --*/

/**
 * Jwhmcs Rules Controller
 * @author		Steven
 * @version		2.5.5
 * 
 * @since		2.4.0
 */
class JwhmcsControllerUpdates extends JwhmcsControllerExt
{
	
	/**
	 * Task that beings the update procedure
	 * @access		public
	 * 
	 * @since		2.4.0
	 */
	public function begin()
	{
		$result		= $this->setCredentials();
		
		// We must supply FTP creds still so throw an error
		if ( $result === true ) {
			JError::raiseWarning('SOME_ERROR_CODE', JText :: _( 'COM_JWHMCS_UPDATES_CREDENTIALS_MISSING' ) );
			$this->setRedirect( 'index.php?option=com_jwhmcs&controller=updates&view=updates' );
			$this->redirect();
		}
		else if ( $result === false ) {
			JError::raiseWarning('SOME_ERROR_CODE', JText :: _( 'COM_JWHMCS_UPDATES_FTPCREDENTIALS_MISSING' ) );
			$this->setRedirect( 'index.php?option=com_jwhmcs&controller=updates&view=updates' );
			$this->redirect();
		}
		else {
			$this->setRedirect( 'index.php?option=com_jwhmcs&controller=updates&view=updates&task=download' );
			$this->redirect();
		}
	}
	
	
	/**
	 * Task to display the appropriate layout for J!WHMCS
	 * @access		public
	 * @version		2.5.5
	 * 
	 * @since		2.4.9
	 * @see			JwhmcsController::display()
	 */
	public function display()
	{
		$input	=	dunloader( 'input', true );
		$input->setVar( 'view', 'updates' );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JwhmcsHelper :: set ( 'layout', 'default35' );
		}
		else {
			JwhmcsHelper :: set ( 'layout', 'default' );
		}
		
		parent :: display();
	}
	
	
	/**
	 * Task that downloads the updates locally
	 * @access		public
	 * 
	 * @since		2.4.0
	 */
	public function download()
	{
		$model		= $this->getModel();
		$creds		= $this->setCredentials();
		$updates	= JwhmcsUpdate :: getUpdateInformation( true );
		
		foreach ( $updates as $update ) {
			if ( $update['update']->hasupdate ) {
				//$update['update']->downloadURL .= $creds;
				$update['update']->creds = $creds;
				$result	= $model->download( $update );
				
				if ( $result === false ) {
					$this->setRedirect( 'index.php?option=com_jwhmcs&controller=updates&view=updates' );
					$this->redirect();
				}
			}
		}
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=updates&view=updates&task=extract' );
		$this->redirect();
	}
	
	
	/**
	 * Task that extracts the updates locally
	 * @access		public
	 * 
	 * @since		2.4.0
	 */
	public function extract()
	{
		$model		=   $this->getModel();
		$updates	=   JwhmcsUpdate :: getUpdateInformation( true );
		
		foreach ( $updates as $update ) {
			if ( $update['update']->hasupdate ) {
				$result = $model->extract( $update );
				
				// Problem with download / extraction
				if ( $result === false ) {
					JError::raiseWarning('SOME_ERROR_CODE', JText :: sprintf( 'COM_JWHMCS_UPDATES_ERROR_EXTRACT', $update['config']->get( '_extensionTitle' ) ) );
					$this->setRedirect( 'index.php?option=com_jwhmcs&controller=updates&view=updates' );
					$this->redirect();
				}
			}
		}
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=updates&view=updates&task=install' );
		$this->redirect();
	}
	
	
	/**
	 * Retrieves the model for the controller
	 * @access		public
	 * @version		2.5.5
	 * @param		string		- $name: default to Update
	 * @param		string		- $prefix: default prefix to JwhmcsModel
	 * 
	 * @return		JwhmcsModelUpdate model
	 * @since		2.4.0
	 */
	public function getModel( $name = 'Update', $prefix = 'JwhmcsModel') 
	{
		$model = parent::getModel( $name, $prefix, array( 'ignore_request' => true ) );
		return $model;
	}
	
	
	/**
	 * Task that performs that actual update procedure
	 * @access		public
	 * 
	 * @since		2.4.0
	 */
	public function install()
	{
		$model		=   $this->getModel();
		$updates	=   JwhmcsUpdate :: getUpdateInformation( true );
		$overall	=   true;
		
		foreach ( $updates as $update ) {
			if ( $update['update']->hasupdate ) {
				$result = $model->install( $update );
				
				if (! $result ) {
					$model->cleanup ( $update );
					$overall = false;
				}
				else {
					$cache = JFactory::getCache( 'mod_menu' );
					$cache->clean();
				}
			}
		}
		
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=updates&view=updates' );
		$this->redirect();
	}
	
	
	/**
	 * Method to set the credentials for downloading from Go Higher
	 * @access		private
	 * @version		2.5.5
	 * @param		string		- $client: ftp usually
	 *
	 * @return		string containing credentials for Go Higher, true if they ARE NOT set, false if they are set but the local client needs FTP credentials to function
	 * @since		2.4.0
	 */
	private function setCredentials( $client ='ftp' )
	{
		jimport( 'joomla.application.component.helper' );
		jimport( 'joomla.client.helper' );
		
		$params	= & JwhmcsParams :: getInstance();
		$user	= $params->get( 'GHusername' );
		$pass	= $params->get( 'GHpassword' );
		
		if ( $user == '' || $pass == '' ) return true;
		
		if (! JClientHelper :: hasCredentials( $client ) ) {
			return false;
		}
		
		return array( 'username' => $user, 'password' => $pass );
		return '?username=' . $user . '&password=' . $pass;
	}
}