<?php
/**
 * Default Controller for J!WHMCS Integrator
*
* @package    J!WHMCS Integrator
* @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
* @license    GNU General Public License version 2, or later
* @version    $Id: default.php 555 2012-09-06 02:10:32Z steven_gohigher $
* @since      1.5.1
*/

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );


/**
 * JwhmcsControllerApicnxn class is the task handler for the api connection checker in the admin area
 * @version		2.5.5
 *
 * @since		2.5.0
 * @author		Steven
 */
class JwhmcsControllerApicnxn extends JwhmcsControllerExt
{

	/**
	 * Constructor task
	 * @access		public
	 * @version		2.5.5
	 *
	 * @since		2.5.0
	 */
	public function __construct()
	{
		parent::__construct();
	}



	/**
	 * Display task
	 * @access		public
	 * @version		2.5.5
	 *
	 * @since		2.5.0
	 * @see			JwhmcsController :: display()
	 */
	public function display()
	{
		$input	=	dunloader( 'input', true );
		$input->setVar( 'view', 'apicnxn' );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			$input->setVar( 'layout', 'default35' );
		}

		parent::display();
	}
	
	
	/**
	 * Task to return user to main screen of JWHMCS
	 * @access		public
	 * @version		2.5.5 ( $id$ )
	 * 
	 * @since		2.5.0
	 */
	public function mainscreen()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=default' );
		$this->redirect();
	}
}