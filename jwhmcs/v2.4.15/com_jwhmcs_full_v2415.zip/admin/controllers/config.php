<?php
/**
 * Configuration Controller for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: config.php 555 2012-09-06 02:10:32Z steven_gohigher $
 * @author     Go Higher Information Services, LLC
 * @since      1.5.1
 * 
 * @desc       This is the config controller for the backend of J!WHMCS Integrator
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
	jimport('joomla.application.component.controllerform');
}
else {
	jimport( 'joomla.application.component.controller' );
	// CHEAT TO PERMIT 1.5.0 TO WORK
	class JControllerForm extends JController {}
}
/*-- File Inclusions --*/


/**
 * JWHCMS Config Controller
 * @author		Steven
 * @version		2.4.15
 * @version		2.3.7		- October 2011:  Added ability to apply settings
 * 
 * @since		2.3.0
 */
class JwhmcsControllerConfig extends JwhmcsControllerForm
{
	/**
	 * Constructor Method
	 * @access		public
	 * @version		2.4.15
	 * 
	 * @since		2.3.0
	 */
	public function __construct()
	{
		if ( is_null( JwhmcsHelper :: get( 'view' ) ) ) JwhmcsHelper :: set( 'view', JwhmcsHelper :: get( 'controller' ) );
		parent::__construct();
		
		$this->registerTask( 'cpanel',	'myredirect' );
		$this->registerTask( 'helppage',	'myredirect' );
		$this->registerTask( 'apply',		'save' );
	}
		
	
	public function display()
	{
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JwhmcsHelper :: set( 'layout', 'default35' );
		}
		parent::display();
	}
	
	/**
	 * Redirector method
	 * @access		public
	 * @version		2.4.15
	 * 
	 * @since		2.3.7
	 */
	public function myredirect()
	{
		$task	= $this->getTask();
		$task	= ( $task == 'cpanel' ? 'default' : $task );
		$link	= 'index.php?option=com_jwhmcs&controller=' . $task;
		$this->setRedirect( $link );
	}
	
	
	/**
	 * Save method
	 * @access		public
	 * @version		2.4.15
	 * @version		2.3.7		- October 2011:  Added ability to apply settings
	 * 
	 * @since		2.3.0
	 */
	public function save()
	{
		$model	= $this->getModel( 'config' );
		$task	= $this->getTask();
		
		if ($model->storeData())
			$msg = JText::_( "COM_JWHMCS_CONFIG_CTRL_SAVED" );
		else
			$msg = JText::_( "COM_JWHMCS_CONFIG_CTRL_ERROR" );
		
		
		$link = ( $task == 'apply' ?
					'index.php?option=com_jwhmcs&controller=config' :
					'index.php?option=com_jwhmcs'
				);
		$this->setRedirect($link, $msg);
	}
}