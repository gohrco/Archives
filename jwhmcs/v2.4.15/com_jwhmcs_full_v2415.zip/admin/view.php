<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: controller.php 469 2012-05-04 20:04:56Z steven_gohigher $
 * @since      2.4.9
 */

class JwhmcsView extends JwhmcsViewExt
{
	
}