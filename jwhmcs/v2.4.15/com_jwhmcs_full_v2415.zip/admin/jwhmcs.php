<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: jwhmcs.php 555 2012-09-06 02:10:32Z steven_gohigher $
 * @since      1.5.0
 */


// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
define( 'JWHMCS_VERS', '2.4.15' );

// Define the DS shortcut (3.0 dropped?)
if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
	if (! defined( 'DS' ) ) define( 'DS', DIRECTORY_SEPARATOR );
}

// Access check.
if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
	if (!JFactory::getUser()->authorise('core.manage', 'com_jwhmcs')) {
	        return JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
	}
}

// Helper
$path	= JPATH_ADMINISTRATOR . '/components/com_jwhmcs/jwhmcs.helper.php';
require_once( $path );

// Toolbar
$path	= JPATH_ADMINISTRATOR . '/components/com_jwhmcs/toolbar.jwhmcs.php';
require_once( $path );

require_once( JPATH_COMPONENT.'/controller.php' );
require_once( JPATH_COMPONENT.'/model.php' );
require_once( JPATH_COMPONENT.'/view.php' );

if($controller = JRequest::getWord( 'controller', 'default' ) ) {
	$path = JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php';
	if (file_exists($path)) {
		require_once $path;
	} else {
		$controller = '';
	}
}

// Create the controller
$classname	= 'JwhmcsController'.$controller;
$controller	= new $classname( );

// Perform the Request task
$controller->execute( JRequest::getVar( 'task' ) );

// Redirect if set by the controller
$controller->redirect();