<?php
/**
 * WHMCS User Synchrization View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: view.html.php 555 2012-09-06 02:10:32Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * View for the check installation of J!WHMCS Integrator
 * @version		2.4.15
 *
 * @author		Steven
 * @since		2.0.0
 */
class JwhmcsViewCheck extends JwhmcsView
{
	/**
	 * Display view
	 * @access		public
	 * @version		2.4.15
	 * @param		unknown		- $tpl: override to pass for tpl
	 *
	 * @since		2.0.0
	 */
	public function display($tpl = null)
	{
		$params = & JwhmcsParams::getInstance();
		$model	= & $this->getModel('check');
		$data	=   $model->getData();
		
		JwhmcsToolbar :: build( 'check' );
		
		JwhmcsHelper :: addMedia( 'common/js' );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JwhmcsHelper :: addMedia( "check25/css" );
			JwhmcsHelper :: addMedia( 'icons35/css' );
			JwhmcsHelper :: addMedia( 'ajax35/js' );
		}
		else if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			JwhmcsHelper :: addMedia( "check25/css" );
			JwhmcsHelper :: addMedia( 'icons/css' );
			JwhmcsHelper :: addMedia( 'ajax/js' );
			JwhmcsHelper :: addMedia( "check/js" );
		}
		else {
			JwhmcsHelper :: addMedia( "check15/css" );
			JwhmcsHelper :: addMedia( 'icons/css' );
			JwhmcsHelper :: addMedia( 'ajax/js' );
			JwhmcsHelper :: addMedia( "check/js" );
		}
		
		
		$this->assignRef('data', $data);
		$this->assignRef('params', $params);
		parent::display($tpl);
	}
}