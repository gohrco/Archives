<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.4.15 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.4..0
 * 
 * @desc       This is the default layout for the updates view file for the backend of J!WHMCS Integrator
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusion --*/
JHtml::_('behavior.tooltip');
/*-- File Inclusion --*/

$cycle	= array( 'component' => JText :: _( 'COM_JWHMCS_UPDATES_HEADING_COMPONENT' ), 'file' => JText :: _( 'COM_JWHMCS_UPDATES_HEADING_EXTERNALFILES' ), 'module' => JText :: _( 'COM_JWHMCS_UPDATES_HEADING_MODULES' ), 'plugin' => JText :: _( 'COM_JWHMCS_UPDATES_HEADING_PLUGINS' ) );
$count	= ( 4 + count( $this->updates['component'] ) + count( $this->updates['module'] ) + count( $this->updates['file'] ) + count( $this->updates['plugin'] ) );

// Set link / img
$img	= JURI::root().'media/com_jwhmcs/icons/' . ( $this->updates['action'] === true ? 'update-48' : ( $this->updates['action'] === false ? 'accept-48' : 'fail-48' ) ) . '.png';
$link	= ( $this->updates['action'] === true ? JRoute :: _( 'index.php?option=com_jwhmcs&controller=updates&task=begin' ) : '#' );
$axn	= JText :: _( 'COM_JWHMCS_UPDATES_LINK_' . ( $this->updates['action'] === true ? 'UPDATE' : ( $this->updates['action'] === false ? 'NOTHING' : 'ERROR' ) ) );
?>

<script type="text/javascript">
	Joomla.submitbutton = function( task ) { Joomla.submitform(task, document.getElementById('item-form')); }
</script>


<div class="row-fluid">
	<div class="span1"> </div>
	<div class="span7">

		<?php foreach ( $cycle as $group => $heading ) : ?>
		
		<table class="table">
			<thead>
				<tr>
					<th style="width: 50%; ">
						<?php echo $heading; ?> :: <?php echo JText::_( 'COM_JWHMCS_UPDATES_HEADING_EXTNAME' ); ?>
					</th>
					<th>
						<?php echo JText::_( 'COM_JWHMCS_UPDATES_HEADING_VERSION' ); ?>
					</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $this->updates[$group] as $item ) : ?>
				<tr>
					<td>
						<?php echo $item['name']; ?>
					</td>
					<td>
						<?php echo $item['version']; ?>
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
			<tfoot>
				<tr>
					<td colspan="2">&nbsp;</td>
				</tr>
			</tfoot>
		</table>
		
		<?php endforeach; ?>

	</div>
	<div class="span4">
		<div class="cpanel">
			<a href="<?php echo $link; ?>" class="btn span1">
				<img src="<?php echo $img; ?>" border="0" alt="<?php echo $axn; ?>" />
				<span class="linktitle"><?php echo $axn; ?></span>
			</a>
		</div>
	</div>
</div>

<form action="<?php echo JRoute::_('index.php?option=com_jwhmcs'); ?>" method="post" name="adminForm" id="item-form">
<input type="hidden" name="task" value="updates.begin" />
<?php echo JHtml::_( 'form.token' ); ?>
</form>
