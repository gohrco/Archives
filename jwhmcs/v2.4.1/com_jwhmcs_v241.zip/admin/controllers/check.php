<?php
/**
 * Group Management Controller for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: check.php 469 2012-05-04 20:04:56Z steven_gohigher $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );


/**
 * JWHCMS Check Controller
 * @author		Steven
 * @version		2.4.1
 *
 * @since		1.5.1
 */
class JwhmcsControllerCheck extends JwhmcsController
{
	
	/**
	 * Constructor task
	 * @access		public
	 * @version		2.4.1
	 * 
	 * @since		1.5.1
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Task to process the check
	 * @access		public
	 * @version		2.4.1
	 * 
	 * @since		1.5.1
	 */
	public function process()
	{
		JwhmcsHelper :: set( 'layout', 'form' );
		JwhmcsHelper :: set( 'hidemainmenu', 1 );
		
		$model	= $this->getModel( 'check' );
		$model->process();
		
	}
}