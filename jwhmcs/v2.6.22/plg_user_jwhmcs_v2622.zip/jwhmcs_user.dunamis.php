<?php

defined('_JEXEC') or die( 'Restricted access' );

/**
 * Define the JWHMCS version here
 */
if (! defined( 'DUN_MOD_JWHMCS' ) ) define( 'DUN_MOD_JWHMCS', "2.6.22" );
if (! defined( 'DUN_MOD_JWHMCS_USER' ) ) define( 'DUN_MOD_JWHMCS_USER', "2.6.22" );


class Jwhmcs_userDunModule extends DunModule
{
	public function initialise()
	{
		
	}
}