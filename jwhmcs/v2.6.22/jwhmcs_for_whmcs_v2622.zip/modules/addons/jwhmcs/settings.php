<?php //00988
/**
 * ---------------------------------------------------------------------
 * J!WHMCS Integrator v2.6.22
 * ---------------------------------------------------------------------
 * 2009-2016 Go Higher Information Services, LLC.  All rights reserved.
 * 2017 January 28
 * version 2.6.22
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.    Go Higher Information Services, LLC  may  terminate  this
 * license if you don't comply with any of the terms and  conditions set
 * forth in our  commercial  end user license agreement(EULA).   In such
 * event,  licensee  agrees  to  return license or destroy all copies of
 * software upon termination of the license.
 *
 * For the full End User License Agreement, please visit our web site at
 * https://www.gohigheris.com/policies/commercial-eula
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPyDmnCWTvV+2xzYfKUkgA7YbNQ8XCrkWHwculdoAoQkWFK4vkPYICx6n35AV5WqRo1dpCx2L
e9bSxYpknIQ8PSyFh1oMxAyE5BiNHuCuyGu4RCEghhcCH6MiwXMyLyY5KojmgupLeH8JpnoxoZTT
pxIWdfhBP/9QGKUlpxXF4esV74h9I1LPrQFUlec57tM0Ynv5fn2VmC921AXq+af0J1VNEKOeKhgl
/rHQLhnVVqhfKXRpqvXGWs0q7zeKU0Xz0vFbNPfN0CvH9otMFItGxCXw6HncUvTBLa2AO8L/IBqV
XYqW/rUqyQqd9eMT71cMSnFP/AKmNhWzsLeR+1Kss1chVUmRjfRxMUtgEKdCBLLxAZaE12AzSSwc
1uLFR3v5jNnEOCSB5BiYog4Ca3WoFSE/D83JmtVPaOvB0E2IO4EVQa4cKrJx2kaTQ1te3vOoiYNK
QvqO9ovd6mEAYp4RXR1wUd/dN2sO7jGG74+QxXr5fT/M7rg/D3AfULyjbnpBWks8HuPvvghF+g+s
/kJULmTXh9opcfnNE0UXphRKMHN+NGINSdHvwO6gI35V7VmKv4WGuELgSEdEQgEChAnsO1vjTsE7
GQydoRBh9WC8CRzFoh2QpLSK0Vt0nyb3Y700FVf2R0al3HObcTuSqfPtQkAlaxHs5SbZa6/vgQWb
PLvl5UGcnPli6suPuxj9z6n1LgImwsA9lcxFQBXHB6vIbfBEreK5eGIF8Gi0GpEMGFX5m3jjf6fL
XlcEBgHUlQZ719V14hZQeozsi1XUaa/MR/YC9nonMzfg/8+/nXCRdtr5LAKbMN4RPwJjWMWlG2n0
/AqrmlW8Ebo6hS8i7r5ea8VxdtosYSekieEoKynYUWtPAx/6Y0HsYsqV/wZeuABpntDSRmO09PY3
OWDWbM3GCnMBrp92ixoCHi8cetaxW209UhTXK9xK5ILUxgP8rHDJH7X00qqmCV3PrVlrz81cE378
maejpo7fRKjmtP/svdZr//B5XZq9KTKawz9JC7MzBv17As/NXcsvmzUG5PxnaOYcMLc7GAzd62Sc
QhYJUwveKv8sRicRVTEYO6N+lrvYUONDOPQDccopCxujnJVJLk5UodTICRrTYWkgkJzO4DTV1TeX
e7B4J/Kp+GbvQ5Ps8LrYJxmgO5DrEW0wmFVfdwmata/xp65LX1LGryHlEEfxZDthXZFAOEG1/wst
vhZ5Q6XrqS5dnBbCXqm2slMzp2WX6gtCly4MtTMuHXesG59aVWBE9E/rCXBP2dQuiYUJVoQG6TVJ
ZR+HBVV2+JQocQIJBND9OObcP+M8w2zafYc9q1cmMe/PWNg7v0H//mrdmuMl8YnSTK/GV+3XXfGa
/5eGI+4ZDhEhYlgtV3xjD72gZmfQsR7MTXcAsFh4pSG2qBt0rseXmo5dJYouBEuU27xFoMLxHx41
FfD8NHWT0//FRFCS6yEFUaPiEXt3s2Txke+0a/mv51MzWrqONtUCGtni4oDOPbHObnfq/OAP+SEO
Omc0PE7eZRC0SmEjwBL1mW+1jDzRn3z1Kz3GcCYXbekd0plzyz9p+Se9LBJXfsRYq4+YHrJo91zt
2SQwVOeoOhtuLa3qT13zqVqGmrtI719aLQ/ZocNp70PPteV0FjJxbnL/fkOaaikRPN1Hx82jakDU
0sdbKJzX0g4IJaWtHrL0vKYH4VB1edzC+DY4AKXuyzC2uGZb9Ioyz+OcOP9J7JY+T+Pw4Ed/ZxCg
MDFCpDadruhl7uWLVJu7gIrfYa5jf8kKqUdNvltWfqyN4O1fMWguLtxRbVFodwrp5lVRBW1ZjQ6y
Fm3GGAxUGiFPcFkRXlG34DpavfsMJ8WZ70nJkKHJbSVsdLrHxnzX0C1QjXoJ5v8H45WaXf37vYSu
+O1Vr+sQtMZqWZ+VJGsonG2QPK/VehXSuTG3Ihg2LgrhHU3mT2rKkUvscSyIvnqzA8w88q74iQph
W3XzkkvLISHQDwfE0/T8C0/DjtS5T9mfS7oBJZ78VIETnADZ4lW1x5Dkoq5u5l/B1A2mxS190BC4
XVox6WFqjbNuiDMAdzum2gydHZWk6IYIlC5FSo6ETzBMbQb/zu6QI06u6mg1HLaXjOvzaBAm2Q2j
V/7+FtFyRP41Mk4EOMYyceg2I1VLABFP2ncZrxbgbm+l2z88I7IEoCBWw+BPW3+pbewhte/5udMB
8gCOL1bqZSmrakbvyXOW/ulN/tXCiWAIlQVRsi60ZSWgA3vb0q4kTaS1BKfnRzSup4AhHWajRN4C
g1qwfTMkozVg1gK9bzFrnmOw6JCOzNh/SWUTfTCupJ30PCdO1NrfFoHeyERXUPE9WQQ0+PdMpQDW
EwRapg4SIOViDz1Yj4gslCXv/tnTLaT8wJPWJAWjwi39yUzmxb1BQdQWumRaUZYEiWCOC2Azxahx
C6+Z/dodbgxhSlDJpLwklfMlDLo6gjVpWlQI1bOCYDPBtOknArZJRPLykldehtQaYb/TbHFNnCT9
yTSgQdpFs5kH2b5QFl+JM8Qp1Ii32t+dLoq3Ax2FkIteKCkCkBT4HhgvWNe/Dj7U5xv7Nz8LgDjX
BzlecDcgd2xzeJKjHHy92uWYIplp8FPqX/Q+71Gx32nP3B+aP+mTp2gmCz39Tg8VxNgY7WHwdW8B
yBfbArcBjuNu9tSufl3cfYIkYG5wbmiAk8I8/coZYb+giwThihg8srVEA3UA42p/tRSBZu1taCA4
BX5Mw9lxsMNskJ5nQK2A+NmhyzI3e2SGPEQgaucokCWnah9Fs5VUK762g/FGqfZbZq7nD4nPY52B
0DVRlW7gkSYFkbo5JcV9w8A7imTGw0WxkZ6g2blTcK5x4yRMohtJxZMGlHWSRAibEY5vdqn4FQx8
b41yirdHiK0W+w/74U0GaDOWnCfqZRCMFcktLH1rr9MKAHRmjEFNEIp5ibw9xvfSgyukT8lKeERR
CH4xRdHF+DKPER/1dCuXR/4qJCQ2dYXZra8fCIV+cREJXH03ROYETTB4zV8Mb23ton+kTyoO8Oh3
TIS62DEQpXJExSpM2lZP38fCOl/2WFYzByiV3Xd86ZOBKDzvUgwJuprBqOO1FQ4SfNHUUj48nbHa
J4eLhIWHq/JbmdeRKBHrftV4dme0M1hRBTAx00cibpwNiXnt6xJpO6KECq6Nqoksj2d0+3Uf77Yq
tkaDSDgeLQF0IhYeUbDt0DlbAY8BRyb7Mo7ufg+COKzDZn5Yb48aGKg+t2W95qtyHYbXLxehYmMZ
MA8kE2YRl9Ld/zh3Pi4QEitMKjejMIO4zwLgDUiCfFWsANuAFIMxBTgd5nMpxskNiZ6MG4n2hXHR
8mFM0e5Y2EoPVxVpN3z58wpfPFfE67eLft1w2D4KsepXrwJJwz3WHBaI9ZXodfLnracTCyYEBRp4
VAhA3Q56vHMOtElnf2GZv/S+HVd8Gdyj6e47j+jd//KaCdZejfvwxx8QNvCCxEKiUlrc40UIk2Lo
z61mN7JFl2PJCZzEGgho4VBCQT13ipDSttHvi82397NLEX+22xsCfvYf9jYcwS6GO66SgC0qrsX5
WiVRARI4yFTJC/zfiaW1mS1M2/80aM0T/VLgeId3smRHYf/deUQGkkJJcVWqrqluIBLFxWgJC3qU
Ll8QZlQBrDQx2VkhZkW1ALIkogb4EqbXmKvUdExm3mGkGBgHcY8eOTSOjk7eGhRfHTeobMYshGbS
e6OxRL7sozS5xkc26Qo0OFSCAB0foob/YcibWRHolzMAdsqb+u0PE0F3teItGy2OPPNAUJEo6azq
jME2xZc8yAae3eXkwTwtCzM1pWGHXybk1DjRAjIogXm36o6d8+iuNyywh7nMdPg9JRNMgkIN6xGN
EUul6XhvOKylMOghvyROTG6+h6iaVp0zChl9a1xvb79W5t5FcuchGN/PwgemDj2A1kB/9RZb/Hxs
tXra6+tQ64ysodA6GfONbiukGopThX9gQmgkW5mpVMwsgqECVjsKs9GMV93GGFPPpYk9r0sXKLjv
jyrWmnkarIXN67N1AoxZmv4kq1f6uAGJ+8Y18QwBRUED6bLkOf1gkGoNJLeWy78Qq/CvwwPw3F/f
uM5bTWk86adrLA9DNZCVpx5dOdJavZNAao6JPftxVRhZuUS1SFwt1YU4s+UsTkLyN3aC7iGt/Tad
ohHbar7QCVBKEu7SnqyFdJxkKGM0gUmhNQGKGS9MBqh6x+0OIOynnk90BMBviBG6GD0r7LqpelCt
4Rz/264toSK+X5LyZbnRCgLSTz+aNUcqGq5DNrHp7PB1OMb2zDWLo0RcY7WK75MUPCTDwtC6CmGN
pshuU2StjL4i5WKOqoJ+mkXIv5qCDe0lWH5pKd2b6doUfuH+xXkqaD0S1mBmpAZJI70LzPPIZ1Ve
eCmFkiRr1TTUgbwMuqxgrWIQtI9I98xO3M5vqwL6omAUrGN/5wIb/lyaYROjTxTvEDTexViLjHqU
0DSfho16c4nRGEfSi9qjxQBxfTK5iNKi3MzKA2j/KocWRfhnrqiTFoUI9TdRE2Qh54qiGKetltSv
CPt6Az6egx/dcohQzmZkH2SzfHztaan6k0wKsT1/qv2Qxdz6C+4xtr8assCfe04JmI/Zc30wXtvN
7xGTsJFdBRlVHMDGb3A/4YEj9EQ7SEw8IAMIv6pbc40FX8M+Gkf3pgrh/avPmN+s+cOdumH5Xh4i
2dg8zaKdR/yenFgPSMqJZ6U6GJ3rBGXp0+wBNsAt3IgDh8qg01TgCohPc2LjHlttrgCSIatFtcM6
A1GWyLK6/YJrbVxUbOTTg3IVArG9p/xSfDZXr31Pawr+rEPc9jQrDhoa7vEvWbDYnoTgHWxg+Ab8
D17YojLVgvRDZOHgfci8ZlXj8QTb1Vej0D2AfBL4Qz7IviFF4t8KMC2RokgGraY5hh8L2urSXC6k
or3ihnk3i6UQ+fAUXWp+r7EJhy0Nu262oXb8P8JqWtTM6P36k0kBhXuqRSHk4ggLqz5dPpPwb53c
Ug86NXmB2JSujfME39rm8azBfylDlVj0O06DSqhjZ042/dQqWOhFQCCr4gYdyzgtCMEsKuuMcTUb
HH2n4yqnfAEYZfEtDwZMz6oDDLrfQkSkVGG4UgB3mr5SJCNF/SrDAY1J64McGy7U6CvEQqGv0mCe
pGFBwWMO8WhH148McZPkUueTKoFxFnvrZiJMMd2n8bIqBtRfcGGP1n0gOjJ+gJ1TZCuY1eatpPDz
5hg2jEynCnjZWjx3gYkqjDFaKbtTaV/pv4M77bFzvz+NOY27clbJ7FlxlfOdS0OtOfYAO/jOi2L6
V6RFV/iHpSyPAXaYxt8BporT/m4Ztjmm9rahX9KSKUa3pB55RiI9nXKDnZTTjxBOaiB2/6TnuOFP
TV11labZWaMA034u1buMGpQsOufMdku6WZWod0ecG4ewaq3BMpSSAVfBK9FFZ/FmrTr/fxyA89BQ
ozyjBjljsjr5u6jDbVXm7hGI1HYRqSydaZIID1+lnj7UdovcmOVBOzKpttLfgpUFx4BpB1+k1OHP
smi/SbbNyG60jZlzCDpNW81QW2tiSRoVDQHercBKpFmixIJJ3PtULvAVR27VLjaMa0Bx0BaNW7CG
TmZxA+vR8R6FDH5XUYM+Do8rblyEyks531+hjO81657ESEdQmDB4TMRFaBh6UMnL2v5HD5sW9zf7
21Rk+YfwSwE7md0qXYYK8GqU0L4cuKhobTLujd/3Muw/1PyX3aZL0TuO7HhkcsYTIExi5dw1mETh
a5O9eaNA+HaoS67jauA5qcamcrYyTLnV9KUF2oM5po5zUkcI1GsdiucQFwfcZmBG1Wt7mNbE/uuO
KWikkHxdJEJQjUDbzwD9OY8JfE5mZyjNgCqhsDT/Hb24adIKf0fpHCT6sCSODuKmvWzD3PXFnOng
j0jxoLuL9m4ISHBab0Ztm9WFEgBN6Lmf/kfZhNfFY6648GAZGM906qEvbj2dKXcNJgkzpgC2nhYe
D4WbKSnDbDh+SiEO8dhV+sqgB5enDW5iG8lNxzdauSj627H8MD8bXVfiTtFdyj5oOxwVqX6Poycw
0ip+IAMmpAkFhzo5cmXhYlpUWO0jTS6QtGIrvDli920l2qSMJQ1ENoC0m5cA2kcZMRIupPcJj4iN
Prtl6UQkaIE3caeLxFoEzzV59QC7chSZQr9i8KHNuhqNcYr8u0+et623cSxsx7o2dqCttlCOJdIx
QxqPS+K+p9vAJnFOpvS5IQ3NAWp/YnYtDqH5zm1pPqaRnr8pWcBnXmNy6NtKVV0aY++VlNSmQmdq
Prgpbap1LxoRcXcTzT3yZgzSJZuPaaXBaki5INQyxqkgGgPIiyUbAgIVO7YZEYtv758uGbasgL0t
bBur91pjSsm2pfcy8YcrwO9eRW+ynbvwdcZtI0tI21LfbJIxbuFT5PqLRjhM+cKRrnv8PVSxarCz
4nOJYIrVhLeJ0k3BvZ1QDNNCoaLG+FxZfpY0C1sgMwCnreFIYyxZJ+0zGG8dTIVYm2986U9eGJLt
B/zuzK1yRMpXWdRgV3efd80bOVlz4Rlt1l2Y+IYhnlGdZxQrl0vJMEqnkmuKRQGLO9zfWhoO8n68
yPu/9aCO0R3FrKSb/wynSi7bDpjFbjnYc7zFBaDOq1FS+4Vf4llMGlvs/Relv491PptHQCsqSZBw
7BHOUDKJU7mfVrMcgsSiKeP2cCf4U2ZYIe4T5ofaDTL0/ykGKy9eTZf//jKiajpzBK95ei7bse1d
N3v0zc8vZ1irN5vkQlWgrz6ZB+hx0b8uXxUb6i3k4Bn+mvreDdl3g+kP3Up5QfXGDnx0UetPMrcz
osTL0hC8XxDvofcezfE2gHxVbK1TzQBX2SsZPfjnreK+Eo+B1GSDhGKbGuzsbOAcp1GjtFM8JzIN
FOUa5YRq4PhLbKZFGpVToDN5EkJmgEHeru92EaZeLrGGDOOu96ak52OHuYUz/bMDGinDIGuccXST
GlnKnYEjJowzuN0HoMhLWUtPBTNqdb7svDS3JPcdGCDX9sLY3aLEsfXvH2EB6s5gSa/PB/nduwgf
tSn7G0blUwQTB2QYHEhevCcwazQYn87f2yYnodS5IA4qsTwWRiR/PYlfw5DQAVPf+ihnyRkA21cb
jZELVQdU98yrKWN80OphvMwHc3GeydFoKGjiuKOTpK/UPY7/X47oJcEUm+PJkoPcOxnK0pFy2Dml
Wok72tDPoC2fYSZFGjCjwcOH2G3SAsQR/DVDTAwbmCJ2bC6sbqk4AMpEMFj8V6mDY8+12FgKrpy8
qr+VA8KFw1Kppj4RG/pY/brRTLrsMzR6vt2AaVIJJa8ZZL0z2oAJnY0ErTWgOZsgydzpnvn3wK+0
PG62gcP/bwPkfqwhH9RymEW1/LVvCcTmBdZBeK8JMrJjRx2Lm7J09YgBHqgru/jcu9O6TFG7Ipho
Jgq+9WJM9KeDb8aGZtGQwWihwn8+I6kKqb8KlAVr3WrkhL6AWHbwmax14wnpan/7HsaJZdro4GCz
GfdGpIv9m3W+mPGnprndCXD7ae7pH1CbXd0ejNQFtDGicJCwyX1Ek+G1IlznMyIT4FrUX51tXo/g
G46/huyISW90Tn1/PtoIUmce3ehXHRv1cWbBX2Gz5U+dt/FtWKiLdlj2dQyQuKQ76UPEJgIiwhH4
4t/tjlm0dzosGw/jmDX6iXuHBNGCww3aiqGw8ecc5BK2XwPRgSMCChFx21epnS7k3iiE6kRWx9yu
jPDTbSQi1HaA7ibjOn5HKHHcZCT5bHho7Nt9pAjIkqK7z7XA1gRJSSmPtO3Ocqng/07Si/AdRtX2
QYJHYjZ9qOs4guQi0ZYeNUp7VPexRfhqunfu85Djxm1/QicTVFvVEMSWGQ0dxxhUHBc+qvXQ34oh
JgXy5hqH1hek1QGZoi0tjjUv1hx7KIB3M/VxCwU1D+8mPSdWltdglzpIZKKi1uZnBiGKTTs6k82j
EHdBUtX2rC1gG4YI5gsU1q3BwbgBoyHUj+C9UwFer6mrXAFRrk5oQ8gKxyr8Vd6BDIcmhTglhWjh
e2eMYEFmpHgK4ZBMe7S5LuF3PNVRqxO8eIA3bFUvKZwC+ur+0ba89aWZzfwUPO48X628RgGad2O0
PWT4wGuJOFaB7e5kxkoQGqe9/1ZqDLxtRSehbyWLICWKbqmwl1pjUcybeI3ND98rGJgCZkUGVsCQ
+qAieVflIuu602fC3Vn2NYZQXR++C605NLJpBTD40TSzY7I7CGAh8pfBGvz4+tl9o4Yi+R+rUZ7L
wbUW996KkovmQ8miGq5f5ZBb0CnmjdkhAp2bRmfDcjNVvJS+UUPuGF3SBllvnhRWV/xzIDObcyJf
XZh4YCtFABRuccxpAfYlMH1Y2dPv3SFQTfgI8c6hVw38+w4meF/OX3uUnl/rN9FiuknLc87pQ0uU
Ljzwu16l+T1lK0jFUZupsBiomIwtBcU/PimkMbpl4I841IIVok1ha7j7ysnqTKBeha0dFpeI3uAd
0Wq2yfFlpxEOxAnhsorwSt1hN6Xccmn67QDZ16VmpzMeVrzJx1p97dIdGr4HUMGzJHve8sFhXcnY
5rnwD8gY8lHAEhbwAAc/zve42qMwuhc9QV+N+PKL9BZMZlMewLItUNLgyonWBYUjOMCmZdOLdw9/
f5Da3KGTOyiq3vZstCKoiUyS2tPUYcBf9tQ0JDotc5WhJV3hwBlwd9GPP4jlsJTGaWMwd4GfjqkF
BotQ5lZefkUy46RRWUVmsIdmxMVPX+2JJK8HQXcwL1V6MeGYV8UfXWvJW8BTc4uApxnQz2M/M51r
r3vt0MYuloBkvOb3COSmSUqp8CvgHjVHSJGJ+WjgYe+5kDrV+g9jo0zoR2wF5IxsZoKZ42P6vmwp
xLglVgp5TyJFt+aJMHFjFGIeqGSG+vjLTyNMb0T8l2t6OmCWTrrBlyZq0ZvKGRhSjmKlrK8WSJQ5
GREGw3jB51Go3yAnzp+R677AlCN0W6mHA/8DugoOUnGKZLoYs5/LjpELXqpEsmPaeTwHBElgGMok
qLKMxaGWySaRDM+tV/0C/YZSZ/XbjgvqPWUZUoJ5Yjas6fuhH/kSNtivtiiIHcAp9SU/u2iBWDyE
ZROupIKd+KmgOYZ99o2VjuSo91bdbx9Z3APofB4ENDs+oKegXzQWOG+u5ZA7Trvq08gGe7DfWv1x
RzT78HkohabSkj7bQb67cqX2rYE7XGvQLRNtNETFWRA1oljglw/fpLRJefsyTMBM1P53zS6eVQWI
g80F+1pPmcxJ6ujr1Klz6mmGBCLaTN6/qpeVhJJBQeiSfKzMK2N+OEMLbP0+7nA7/bYtoL7QxN4C
883DvWIcP4fPc5pnAqozvPBgm02EnlCtEU3dLnTB/IlNKTuh+egournoF+q3oHWmbAjFbUrBUNHC
N8hoHdvAmK+F4vDJ9xNvUkTTTHmKN1TDMC74sPcctwW9baOvNde0HKUSIDP4jph83hO4xhOio9xe
fL3FHpYnSKwF2x91Xo6MLluEwsP5xcE7IWQAN48b8vRcK1K2B5vFMIp/Ee+ftIVcMAuAWr37J29K
X8HRZI6f7sC7ZW==