<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 		API Ping File
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009-2016 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.6.22 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.5.0
 *
 * @desc       This is the Verify Task which replaces the ping task for the J!WHMCS Integrator API
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Verify Jwhmcs API Class
 * @version		2.6.22
 *
 * @since		2.5.3
 * @author		Steven
 */
class VerifyJwhmcsAPI extends JwhmcsAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		2.6.22
	 * 
	 * @since		2.5.0
	 * @see			JwhmcsAPI :: execute()
	 */
	public function execute()
	{
		// ---- BEGIN JWHMCS-4
		//		When doing anything on the WHMCS side if Joomla doesn't have curl enabled it can result in failures
		// Lets test for curl_exec to ensure we can curl back
		if (! function_exists( 'curl_exec' ) ) {
			$this->error( JText :: _( 'JWHMCS_SYSM_API_PING_NOCURL' ) );
		}
		
		// ---- END JWHMCS-4
		
		$this->success( 'pong' );
	}
}