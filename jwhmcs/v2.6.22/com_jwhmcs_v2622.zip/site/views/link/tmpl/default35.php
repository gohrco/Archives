<?php 
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009-2016 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.6.22 ( $Id: default.php 469 2012-05-04 20:04:56Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      2.1.0
 * 
 * @desc       Register View - default layout:  The default layout for the registration view
 *  
 */

defined('_JEXEC') or die('Restricted access');

JHtml::_('behavior.formvalidation');

// Recaptcha URL?
$reurl = ($this->params->get( 'scheme' ) == 'https' ? 'https://api-secure.recaptcha.net' : 'http://api.recaptcha.net' );

require_once( JPATH_COMPONENT . DS . 'recaptchalib.php' );
$publickey	= $this->params->get( 'RecaptchaPublickey' );
$useSsl		= ( $this->params->get( 'scheme' ) == 'https' ? true : false );

?>

<script type="text/javascript">
<!--
	window.addEvent('domready', function() {
		document.formvalidator.setHandler('passverify',
			function (value) {
				return ($('newpw').value == value);
		});
	});
// -->
</script>

<script type="text/javascript">

/**
 * Calculates the password strength bar
 */
 jQuery( document ).ready( function() 
 {
	jQuery( '#newpw' ).keyup( function ()
	{
		var pwvalue		= jQuery( '#newpw').val();
		var pwstrength	= getPasswordStrength( pwvalue );
		
		jQuery( '#pwstrength' ).html( '<?php echo JText::_( "COM_JWHMCS_REGISTER_PASSWORD_STRONG" ); ?>' );
		jQuery( '#pwstrengthpos' ).css( 'background-color', '#33CC00' );
		
		if ( pwstrength < 75 ) {
			jQuery( '#pwstrength' ).html( '<?php echo JText::_( "COM_JWHMCS_REGISTER_PASSWORD_MODERATE" ); ?>' );
			jQuery( '#pwstrengthpos' ).css( 'background-color', '#ff6600' );
		}
		
		if ( pwstrength < 30 ) {
			jQuery( '#pwstrength' ).html( '<?php echo JText::_( "COM_JWHMCS_REGISTER_PASSWORD_WEAK" ); ?>' );
			jQuery( '#pwstrengthpos').css( 'background-color', '#cc0000' );
		}
		
		jQuery( '#pwstrengthpos' ).css( 'width', pwstrength );
		jQuery( '#pwstrengthneg' ).css( 'width' , 100-pwstrength );
    });
});

// Declare RecaptchaOptions
var RecaptchaOptions = {
   theme : '<?php echo $this->params->get( 'RecaptchaTheme' ); ?>',
   lang: '<?php echo $this->params->get( 'RecaptchaLang' ); ?>'
};

</script>
<?php

if ( isset( $this->message ) )
{
	$this->display('message');
}

/**
 * We have the option to use ajax validation or just the internal validation
 */
$ajax		= ( $this->params->get( 'RegAjax' ) ? true : false );
$ajaxClass	= ( $ajax ? '' : ' required' );

?>

<form action="<?php echo JRoute::_( "index.php?option=com_jwhmcs&controller=register&Itemid=" . $this->params->get( 'RegMenu' ) . "&controller=register&task=save" ); ?>" method="post" id="item-form" name="josForm" class="form-validate form-horizontal">

<?php if ( $this->tmplparams->get( "show_page_heading" ) ) : ?>

<div class="page-header">
	<h1><?php echo $this->tmplparams->get( "page_heading" ); ?></h1>
</div>

<?php endif; ?>

<?php if ( $this->tmplparams->def( 'show_page_title', 1 ) ) : ?>

<div class="page-header">
	<h2><?php echo $this->escape($this->tmplparams->get('page_title')); ?></h2>
</div>

<?php endif; ?>

<table cellpadding="0" cellspacing="0" border="0" width="100%" class="contentpane table">
	
	<tr>
		<td class="labelCell">
			<label id="firstnamemsg" for="firstname" class="control-label">
				<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_FIRSTNAME" ); ?>:
			</label>
		</td>
		<td class="imgCell"><div id="firstnameResult" class="notifier imgrequired">&nbsp;</div></td>
		<td>
			<input type="text" name="firstname" id="firstname" size="40" value="<?php echo $this->post['firstname']; ?>" class="inputbox<?php echo $ajaxClass; ?>" maxlength="50"<?php if ($ajax): ?> onblur="hasInfo( 'firstname', this.value ); " onchange="hasInfo( 'firstname', this.value) ; "<?php endif; ?> />
			<input type="hidden" id="firstnameValid" class="required" name="firstnameValid" value="" />
		</td>
	</tr>
	
	<tr>
		<td class="labelCell">
			<label id="lastnamemsg" for="lastname" class="control-label">
				<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_LASTNAME" ); ?>:
			</label>
		</td>
		<td class="imgCell"><div id="lastnameResult" class="notifier imgrequired">&nbsp;</div></td>
		<td>
			<input type="text" name="lastname" id="lastname" size="40" value="<?php echo $this->post['lastname']; ?>" class="inputbox<?php echo $ajaxClass; ?>" maxlength="50"<?php if ($ajax): ?> onblur="hasInfo( 'lastname', this.value) ; " onchange="hasInfo( 'lastname', this.value) ; "<?php endif; ?> />
			<input type="hidden" id="lastnameValid" class="required" name="lastnameValid" value="" />
		</td>
	</tr>
	
	<tr>
		<td class="labelCell">
			<label id="companynamemsg" for="companyname" class="control-label">
				<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_COMPANYNAME" ); ?>:
			</label>
		</td>
		<td class="imgCell">&nbsp;</td>
		<td>
			<input type="text" name="companyname" id="companyname" size="40" value="<?php echo $this->post['companyname'];  ?>" class="inputbox" maxlength="50" />
		</td>
	</tr>
	
	<tr>
		<td class="labelCell">
			<label id="address1msg" for="address1" class="control-label">
				<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_ADDRESSONE" ); ?>:
			</label>
		</td>
		<td class="imgCell"><div id="address1Result" class="notifier imgrequired">&nbsp;</div></td>
		<td>
			<input type="text" name="address1" id="address1" size="40" value="<?php echo $this->post['address1']; ?>" class="inputbox<?php echo $ajaxClass; ?>" maxlength="50"<?php if ($ajax): ?> onblur="hasInfo( 'address1', this.value) ; " onchange="hasInfo( 'address1', this.value) ; "<?php endif; ?> />
			<input type="hidden" id="address1Valid" class="required" name="address1Valid" value="" />
		</td>
	</tr>
	
	<tr>
		<td class="labelCell">
			<label id="address2msg" for="address2" class="control-label">
				<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_ADDRESSTWO" ); ?>
			</label>
		</td>
		<td class="imgCell">&nbsp;</td>
		<td>
			<input type="text" name="address2" id="address2" size="40" value="<?php echo $this->post['address2'];  ?>" class="inputbox" maxlength="50" />
		</td>
	</tr>
	
	<tr>
		<td class="labelCell">
			<label id="citymsg" for="city" class="control-label">
				<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_CITY" ); ?>:
			</label>
		</td>
		<td class="imgCell"><div id="cityResult" class="notifier imgrequired">&nbsp;</div></td>
		<td>
			<input type="text" name="city" id="city" size="40" value="<?php echo $this->post['city'];  ?>" class="inputbox<?php echo $ajaxClass; ?>" maxlength="50"<?php if ($ajax): ?> onblur="hasInfo( 'city', this.value) ; " onchange="hasInfo( 'city', this.value) ; "<?php endif; ?> />
			<input type="hidden" id="cityValid" class="required" name="cityValid" value="" />
		</td>
	</tr>
	
	<tr>
		<td class="labelCell">
			<label id="statemsg" for="state" class="control-label">
				<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_STATE" ); ?>:
			</label>
		</td>
		<td class="imgCell"><div id="stateResult" class="notifier imgrequired">&nbsp;</div></td>
		<td>
			<input type="text" name="state" id="state" size="40" value="<?php echo $this->post['state'];  ?>" class="inputbox<?php echo $ajaxClass; ?>" maxlength="50"<?php if ($ajax): ?> onblur="hasInfo( 'state', this.value) ; " onchange="hasInfo( 'state', this.value) ; "<?php endif; ?> />
			<input type="hidden" id="stateValid" class="required" name="stateValid" value="" />
		</td>
	</tr>
	
	<tr>
		<td class="labelCell">
			<label id="postcodemsg" for="postcode" class="control-label">
				<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_POSTCODE" ); ?>:
			</label>
		</td>
		<td class="imgCell"><div id="postcodeResult" class="notifier imgrequired">&nbsp;</div></td>
		<td>
			<input type="text" name="postcode" id="postcode" size="40" value="<?php echo $this->post['postcode'];  ?>" class="inputbox<?php echo $ajaxClass; ?>" maxlength="50"<?php if ($ajax): ?> onblur="hasInfo( 'postcode', this.value) ; " onchange="hasInfo( 'postcode', this.value) ; "<?php endif; ?> />
			<input type="hidden" id="postcodeValid" class="required" name="postcodeValid" value="" />
		</td>
	</tr>
	
	<tr>
		<td class="labelCell">
			<label id="countrymsg" for="country" class="control-label">
				<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_COUNTRY" ); ?>:
			</label>
		</td>
		<td class="imgCell">&nbsp;</td>
		<td>
			<?php echo JHtml::_('select.genericlist', JwhmcsHelper::buildCountries( true ), 'country', null, 'value', 'text', ( ( $ctry = JwhmcsHelper :: get( 'country' ) ) ? $ctry : $this->params->get( 'WhmcsDefaultcountry' ) ) ); ?>
		</td>
	</tr>
	
	<tr>
		<td class="labelCell">
			<label id="phonenumbermsg" for="phonenumber" class="control-label">
				<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_PHONENUM" ); ?>:
			</label>
		</td>
		<td class="imgCell"><div id="phonenumberResult" class="notifier imgrequired">&nbsp;</div></td>
		<td>
			<input type="text" name="phonenumber" id="phonenumber" size="40" value="<?php echo $this->post['phonenumber'];  ?>" class="inputbox<?php echo $ajaxClass; ?>" maxlength="50"<?php if ($ajax): ?> onblur="hasInfo( 'phonenumber', this.value) ; " onchange="hasInfo( 'phonenumber', this.value) ; "<?php endif; ?> />
			<input type="hidden" id="phonenumberValid" class="required" name="phonenumberValid" value="" />
		</td>
	</tr>
	
	<tr>
		<td colspan="3">
			<div id="message" class="message">&nbsp;</div>
		</td>
	</tr>
	
	<tr>
		<td class="labelCell">
			<label id="usernamemsg" for="username" class="control-label">
				<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_USERNAME" ); ?>:
			</label>
		</td>
		<td class="imgCell"><div id="usernameResult" class="notifier imgrequired">&nbsp;</div></td>
		<td>
			<input type="text" id="username" name="username" size="40" value="<?php echo $this->post['username'];  ?>" class="inputbox<?php echo $ajaxClass; ?> validate-username" maxlength="25"<?php if ($ajax): ?> onblur="validInfo('username', this.value); " onchange="validInfo('username', this.value); " onkeypress="return onKeypress(event); "<?php endif; ?> />
			<input type="hidden" id="usernameCheckmsg" name="usernameCheckmsg" value="<?php echo JText::_( "COM_JWHMCS_REGISTER_CHECK_USERNAME_MSG" ); ?>" />
			<input type="hidden" id="usernameValid" class="required" name="usernameValid" value="" />
		</td>
	</tr>
	
	<tr>
		<td class="labelCell">
			<label id="emailmsg" for="email" class="control-label">
				<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_EMAIL" ); ?>:
			</label>
		</td>
		<td class="imgCell"><div id="emailResult" class="notifier imgrequired">&nbsp;</div></td>
		<td>
			<input type="text" id="email" name="email" size="40" value="<?php echo $this->post['email'];  ?>" class="inputbox<?php echo $ajaxClass; ?> validate-email" maxlength="100"<?php if ($ajax): ?> onblur="validInfo('email', this.value); " onchange="validInfo('email', this.value); " onkeypress="return onKeypress(event); "<?php endif; ?> />
			<input type="hidden" id="emailCheckmsg" name="emailCheckmsg" value="<?php echo JText::_( "COM_JWHMCS_REGISTER_CHECK_EMAIL_MSG" ); ?>" />
			<input type="hidden" id="emailValid" class="required" name="emailValid" value="" />
		</td>
	</tr>
	
	<tr>
		<td class="labelCell">
			<label id="pwmsg" for="password" class="control-label">
				<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_PASSWORD" ); ?>:
			</label>
		</td>
		<td class="imgCell"><div id="passwordResult" class="notifier imgrequired">&nbsp;</div></td>
		<td>
			<input class="inputbox<?php echo $ajaxClass; ?> validate-password" type="password" id="newpw" name="password" size="40" value=""<?php if ($ajax): ?> onblur="validInfo('password', this.value); comparePW(); " onchange="validInfo('password', this.value); comparePW(); " onkeypress="return onKeypress(event); "<?php endif; ?> />
			<input type="hidden" id="passwordCheckmsg" name="passwordCheckmsg" value="<?php echo JText::_( 'COM_JWHMCS_REGISTER_CHECK_PASSWORD_MSG' ); ?>" />
			<input type="hidden" id="passwordValid" class="required" name="passwordValid" value="" />
		</td>
	</tr>
	
	<tr>
		<td class="labelCell">
			<label id="pw2msg" for="password2" class="control-label">
				<?php echo JText::_( "COM_JWHMCS_REGISTER_LABEL_PASSVERIFY" ); ?>:
			</label>
		</td>
		<td class="imgCell"><div id="pass2Result" class="notifier imgrequired">&nbsp;</div></td>
		<td>
			<input class="inputbox<?php echo $ajaxClass; ?> validate-passverify" type="password" id="password2" name="password2" size="40" value=""<?php if ($ajax): ?> onblur="comparePW(); " onchange="comparePW(); "<?php endif; ?> />
			<input type="hidden" id="password2Valid" class="required" name="password2Valid" value="" />
		</td>
	</tr>
	
	<tr>
		<td colspan="2" class="labelCell">&nbsp;</td>
		<td align="center">
			<table align="left"><tr><td style="width: 100%; text-align: center; "><?php echo JText::_( "COM_JWHMCS_REGISTER_PASSWORD_STRENGTH" ); ?></td></tr><tr><td><table align="center" style="width: 120px !important; margin: 0 auto; "><tr><td width="102"><div id="pwstrengthpos" style="position:relative;float:left;width:0px;background-color:#33CC00;border:1px solid #000;border-right:0px;">&nbsp;</div><div id="pwstrengthneg" style="position:relative;float:right;width:100px;background-color:#efefef;border:1px solid #000;border-left:0px;">&nbsp;</div></td></tr></table></td></tr><tr><td><div id="pwstrength" style="width: 100%; text-align: center; "><?php echo JText::_( "COM_JWHMCS_REGISTER_PASSWORD_WEAK" ); ?></div></td></tr></table>
		</td>
	</tr>
	
	<?php if ($this->params->get( 'RecaptchaEnable' )): ?>
	
	<tr>
		<td colspan="2">&nbsp;</td>
		<td>
			<?php echo recaptcha_get_html( $publickey, null, $useSsl ); ?>
		</td>
	</tr>
	
	<?php endif; ?>
	
	<tr>
		<td colspan="2" class="labelCell">&nbsp;</td>
		<td>
			<?php echo JText::_( "COM_JWHMCS_REGISTER_REQUIRED" ); ?>
		</td>
	</tr>
	
	<?php if ($this->params->get( 'DisplayTOS' )): ?>
	<tr>
		<td colspan="2" class="labelCell" style="text-align: right; padding-right: 20px; ">
			<input type="hidden" name="tos" value="0" <?php if ( $this->params->get( 'RequireTOS' ) == 1 ) : ?> class="required" <?php endif; ?>/>
			<input type="checkbox" name="tos" value="1" />
		</td>
		<td>
			<?php echo sprintf( JText :: _( 'COM_JWHMCS_REGISTER_TOSLINK' ), $this->tosurl ); ?>
		</td>
	</tr>
<?php endif; ?>

</table>

<div class="controls">
	<button class="btn btn-primary button validate" type="submit"><?php echo JText::_("COM_JWHMCS_REGISTER_BUTTON"); ?></button>
</div>

<input type="hidden" name="id" value="0" />
<input type="hidden" name="gid" value="0" />
<input type="hidden" name="usedata" value="1" />
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="thisurl" value="<?php echo $this->thisurl; ?>" id="thisurl" />
<?php echo JHTML::_( 'form.token' ); ?>

</form>