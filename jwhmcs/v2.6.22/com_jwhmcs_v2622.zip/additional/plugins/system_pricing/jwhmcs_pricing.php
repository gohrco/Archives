<?php
/**
 * J!WHMCS Integrator - System Pricing Plugin
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id$
 * @since      2.1.0
 * 
 * @desc		This plugin locates tags embedded in modules and content of a
 * 				site and replaces them with the appropriate pricing from WHMCS.
 * 
 */


/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

jimport( 'dunamis.dunamis' );
jimport( 'joomla.plugin.plugin' );


/**
 * System - J!WHMCS Integrator plugin
 * @version		2.6.22
 *
 * @since		1.5.0
 * @author		Steven
 */
class plgSystemJwhmcs_pricing extends JPlugin
{
	
	/**
	 * Property indicating if the plugin should be enabled or not
	 * @access		private
	 * @var			boolean
	 * @since		2.5.0
	 */
	private $_enabled	=	false;
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		2.6.22
	 * @param		object		- $subject: The object to observe
	 * @param 		array		- $config: An array that holds the plugin configuration
	 * 
	 * @since		1.5.0
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct( $subject, $config );
		
		$this->loadLanguage();
		
		$app		=	JFactory :: getApplication();
		$user		=	JFactory :: getUser();
		
		// Run through tests
		// -----------------
		// Ensure we have Dunamis installed
		if (! function_exists( 'get_dunamis' ) ) {
			// Not admin don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
			
			// Show error message
			$this->_displayError( 'JWHMCS_PRICING_CONFIG_NODUNAMIS', 'library' );
			return;
		}
		
		get_dunamis( 'com_jwhmcs' );
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		
		if (! is_a( $config, 'Com_jwhmcsDunConfig' ) ) {
			// Not admin or not logged in don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
				
			// Show error message
			$this->_displayError( 'JWHMCS_PRICING_CONFIG_NOJWHMCSCONFIG', 'jwhmcsconfig' );
			return;
		}
		
		// Ensure we are active...
		if (! $config->get( 'enable' ) ) {
			// Not admin or not logged in don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
			
			// Show error message
			$this->_displayError( 'JWHMCS_PRICING_CONFIG_NOTENABLED', 'enable' );
			return;
		}
		
		// Ensure we load our pricing plugin into Dunamis
		$dun = get_dunamis( 'jwhmcs_pricing' );
		$pconfig	=	dunloader('config', 'jwhmcs_pricing' );
		
		if (! is_a( $pconfig, 'Jwhmcs_pricingDunConfig' ) ) {
			// Not admin or not logged in don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
		
			// Show error message
			$this->_displayError( 'JWHMCS_PRICING_CONFIG_NOPJWHMCSCONFIG', 'jwhmcsconfig' );
			return;
		}
		
		// All good, lets go
		$this->_enabled	=	true;
	}
	
	
	/**
	 * Applies pricing to modules and content
	 * @access		public
	 * @version		2.6.22
	 *
	 * @since		2.1.0
	 */
	public function onAfterRender()
	{
		$app	=	JFactory :: getApplication();
		
		if ( $app->isAdmin() ) {
			return;
		}
		
		$body	=	JResponse::getBody();
		$regex	=	'/{whmcs\s*\|(?<type>[^\|}]*)\|(?<id>[^\|}]*)\|(?:(?<currency>[^\|}]*)\|)?(?<freq>[^\|}]*)[^}]*}/i';
		
		// If we have this plugin disabled then remove any tags so they don't appear at all
		if (! $this->_enabled ) {
			$body = preg_replace( $regex, '', $body );
			JResponse::setBody( $body );
			return true;
		}
		
		$finds	=	preg_match_all( $regex, $body, $matches, PREG_SET_ORDER );
		
		// In the event we don't find any and customer has strict reporting on get outta there
		if ( ( count( $matches ) == 0 ) OR ( $finds === false ) ) {
			return true;
		}
		
		// Loop through each and do our replacements
		foreach ( $matches as $match ) {
			$price	= '';
			$by = ( is_numeric( $match['id'] ) ? 'id' : 'name' );
			$price	= $this->_getPrice( array( 'type' => $match['type'], 'id' => $match['id'], 'freq' => $match['freq'], 'curr' => ((! $match['currency'] ) ? false : $match['currency'] ) ), $by );
			$body = str_replace( $match[0], $price, $body );
		}
	
		JResponse :: setBody( $body );
	}
	
	
	/**
	 * Common method for displaying an error message
	 * @access		private
	 * @version		2.6.22
	 * @param		string		- $msg: the message to display
	 *
	 * @since		2.5.0
	 */
	private function _displayError( $msg = null, $task = 'token', $usesess = true )
	{
		// Translate string first
		$msg		=	JText :: _( $msg );
		$session	=	JFactory :: getSession();
	
		$hasrun		=	$session->get( 'jwhmcs_pricing.' . $task, false );
	
		if ( $hasrun && $usesess ) {
			return;
		}
		elseif ( $usesess ) {
			$session->set( 'jwhmcs_pricing.' . $task, true );
		}
	
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JFactory::getApplication()->enqueueMessage( "{$msg}" );
		}
		else {
			JError::raiseNotice( 100, "{$msg}" );
		}
	}
	
	
	/**
	 * Performs actual price retrieval
	 * @access		private
	 * @version		2.6.22
	 * @param		array		- $options - contains the found price point options
	 * @param		string		- $by: indicates how to search for the price id || name
	 *
	 * @return		string containing the price retrieved from WHMCS
	 * @since		2.1.1
	 */
	private function _getPrice( $options = array(), $by = 'id' )
	{
		static $prices = array();
	
		$serialized = serialize( $options );
		
		if (! isset( $prices[$serialized] ) ) {
			$api	=	dunloader( 'api', 'com_jwhmcs' );
			$config	=	dunloader( 'config', 'jwhmcs_pricing' );
			
			$type	= $this->_getType( strtolower( $options['type'] ) );
			$id		= $options['id'];
			$freq	= $this->_getFreq( strtolower( $options['freq'] ) );
			$curr	= strtoupper( $this->_getCurr( $options['curr'] ) );
			
			$string	=	"$type,$id,$freq,$curr";
			
			$data	=	$api->getprice( $string, $by );
			$price	=	null;
			
			if( $data ) {
				$price = ( $config->get( "showprefix", false ) ? $data->prefix : "" ) . $data->value . ( $config->get( "showsuffix", false ) ? " " . $data->suffix : "" );
			}
			
			$prices[$serialized] = $price;
		}
	
		return $prices[$serialized];
	}
	
	
	/**
	 * Wrapper to ensure we retrieve the correct type of price
	 * @access		private
	 * @version		2.6.22
	 * @param		string		- $type: indicating which type to get
	 *
	 * @return		string containing the matching table ref in WHMCS
	 * @since		2.1.1
	 */
	private function _getType( $type )
	{
		switch( $type ):
		case 'product':
			return 'product';
		case 'addon':
			return 'addon';
		case 'config':
			return 'configoptions';
		case 'domainaddon':
			return 'domainaddon';
		case 'domainreg':
			return 'domainregister';
		case 'domaintrans':
			return 'domaintransfer';
		case 'domainrenew':
			return 'domainrenew';
			endswitch;
	
			// Just in case I miss one
			return $type;
	}
	
	
	/**
	 * Wrapper to ensure we retrieve the correct price point
	 * @access		private
	 * @version 	2.6.22
	 * @param 		string		- $freq: string containing found price point
	 *
	 * @return		string containing matching tbl ref in WHMCS
	 * @since		2.1.1
	 */
	private function _getFreq( $freq )
	{
		switch( $freq ):
		case 'monsetup':
			return 'msetupfee';
		case 'qtrsetup':
			return 'qsetupfee';
		case 'semsetup':
			return 'ssetupfee';
		case 'annsetup':
			return 'asetupfee';
		case 'biasetup':
			return 'bsetupfee';
		case 'trisetup':
			return 'tsetupfee';
		case 'monprice':
			return 'monthly';
		case 'qtrprice':
			return 'quarterly';
		case 'semprice':
			return 'semiannually';
		case 'annprice':
			return 'annually';
		case 'biaprice':
			return 'biennially';
		case 'triprice':
			return 'triennially';
			endswitch;
	
			// Just in case they add one
			return $freq;
	}
	
	
	/**
	 * Wrapper to determine which currency to retrieve from WHMCS
	 * @access		private
	 * @version		2.6.22
	 * @param 		string		- $curr: currency type to get or false for default
	 *
	 * @return		string containing the currency short code to retrieve
	 * @since		2.2.0
	 */
	private function _getCurr( $curr )
	{
		return ( $curr === false ? $this->params->get( "defcurrency", "USD" ) : $curr );
	}
}