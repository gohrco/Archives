<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 		API Base File
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009-2016 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.6.22 ( $Id$ )
 * @since      2.5.0
 *
 * @desc		This is the Base File for handling all API requests for Belong
 */


/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Base Jwhmcs API Class
 * @version		2.6.22
 *
 * @since		2.5.0
 * @author		Steven
 */
class JwhmcsAPI
{
	
	/**
	 * Method for returning an error
	 * @access		protected
	 * @version		2.6.22
	 * @param		mixed		- $data: contains data to send back
	 * 
	 * @since		2.0.0
	 */
	protected function error( $data )
	{
		$this->_response( array( 'result' => 'error', 'error' => $data ) );
	}
	
	
	/**
	 * Method for calling a variable from the input handler of Joomla
	 * @access		protected
	 * @version		2.6.22
	 * @param		string		- $var: the variable we want
	 * @param		mixed		- $default: the default to send back if not found
	 * @param		string		- $filter: what to filter by (cmd|string|array|int...)
	 * @param		string		- $hash: the source hash (get|post|request...)
	 * @param		integer		- $mask: level of cleaning to apply
	 * 
	 * @return		mixed result or default
	 * @since		2.0.0
	 */
	protected function getVar( $var, $default = null, $filter = 'none', $hash = 'default', $mask = 0 )
	{
		if ( version_compare( JVERSION, '1.7.1', 'ge' ) ) {
			$app	= & JFactory :: getApplication();
			$method	=	$app->input->getMethod();
			return $app->input->$method->get( $var, $default, $filter );
		}
		else {
			$value	= JRequest :: getVar( $var, $default, $hash, $filter, $mask );
			// If we are resetting pw on front end, post is empty for some reason
			if ( empty( $value ) && $var == 'post' ) $value = JRequest::get( 'post' );
			return $value;
		}
	}
	
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		2.6.22
	 * 
	 * @since		2.0.0
	 */
	public function execute() { }
	
	
	/**
	 * Method for returning data successfully
	 * @access		protected
	 * @version		2.6.22
	 * @param		mixed		- $data: the data to send back
	 * 
	 * @since		2.0.0
	 */
	protected function success( $data )
	{
		$this->_response( array( 'result' => 'success', 'data' => $data ) );
	}
	
	
	/**
	 * Method for sending a response
	 * @access		private
	 * @version		2.6.22
	 * @param		array		- $data: contains the data to render back to the user
	 * 
	 * @since		2.0.0
	 */
	private function _response( $data )
	{
		$string	= json_encode( $data );
		exit( $string );
	}
}