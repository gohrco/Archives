<?php
/**
 * @package         Dunamis
 * @subpackage		WHMCS
 * @version         2.0.0
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2009 - 2016 Go Higher Information Services.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 * 
 * @desc			This file outputs document data to the admin head
 */

echo dunloader( 'document', true )->renderHeadData();