<?php defined('DUNAMIS') OR exit('No direct script access allowed');
/**
 * WHMCS Debug File
 * This is the environment debug handler of the Dunamis Framework
 *
 * @package         Dunamis
 * @version         1.2.1
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2009 - 2013 Go Higher Information Services.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 */


/**
 * WHMCS Debug class handler
 * @version		1.2.1
 *
 * @author		Steven
 * @since		1.0.11
 */
class WhmcsDunDebug extends DunDebug
{
	
	/**
	 * Method to initialize the debug object
	 * @access		public
	 * @static
	 * @version		1.2.1 ( $id$ )
	 * @param		string		- $name: the calling name
	 *
	 * @since		1.0.11
	 */
	public static function init()
	{
		// Check to see if we are enabled or not
		if (! self :: isEnabled() ) {
			return;
		}
		
		// Lets initialized
		parent :: init();
	}
	
	
	/**
	 * Method to check if debugging is enabled
	 * @access		public
	 * @static
	 * @version		1.2.1 ( $id$ )
	 *
	 * @return		boolean
	 * @since		1.0.11
	 */
	protected static function isEnabled()
	{
		if ( self :: $isEnabled === null ) {
			self :: $isEnabled = get_errorsetting_whmcs( 'DebugErrors' );
		}
		
		return (bool) self :: $isEnabled;
	}
}


class WDD extends WhmcsDunDebug {}