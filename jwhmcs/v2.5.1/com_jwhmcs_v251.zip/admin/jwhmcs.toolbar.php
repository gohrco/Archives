<?php
/**
 * J!WHMCS Integrator
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.5.1 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.3.0
 *
 * @desc       This file is a utility helper for JWHMCS Integrator
 *
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
$curlfile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jwhmcs'.DS.'classes'.DS.'class.curl.php';
if (is_readable($curlfile)) include_once($curlfile);


class JwhmcsToolbar extends JObject
{
	/**
	 * Build the toolbar buttons based on permissions
	 * @access		public
	 * @version		2.5.1
	 * @version		2.5.0		- May 2013: Dropped default buttons other than options
	 * @param		string		- $controller:  where we are
	 * @param		string		- $task: what we are doing
	 * @param		JObject		- $canDo: contains permissions user has
	 *
	 * @since		2.4.0
	 */
	public function build( $controller, $task = null, $canDo = null )
	{
		switch ( $controller ) {
			case 'default':
				JToolBarHelper :: title( JText::_( 'COM_JWHMCS' ), 'jwhmcs.png' );
				
				if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
					if ( $canDo->get( 'core.admin' ) ) {
						JToolBarHelper :: preferences(	'com_jwhmcs', '550', '875', 'JToolbar_Options'  );
					}
				}
				else {
					JToolBarHelper :: custom( 'config', 'config.png', '', JText::_( 'COM_JWHMCS_ADMIN_BUTTON_PARAMETERS'), false, false );
				}
	
				break;
				
			case 'apicnxn':
				JToolBarHelper :: title( JText::_( 'COM_JWHMCS_INSTALL_VIEW_APICNXN_TITLE' ), 'apicnxn.png' );
				
				if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
					JToolBarHelper :: custom( 'mainscreen', 'star', 'star', 'J!WHMCS', false, false );
				}
				else {
					JToolBarHelper :: custom( 'display', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
				}
			
				break;
				
			case 'config' :
				
				JToolBarHelper :: title( JText::_("COM_JWHMCS_CONFIG_VIEW_TITLE"), 'settings.png' );
				JToolBarHelper :: apply();
				JToolBarHelper :: save();
				JToolBarHelper :: divider();
				
				if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
					JToolBarHelper :: custom( 'cpanel', 'star', 'star', 'J!WHMCS', false, false );
					JToolBarHelper :: custom( 'helppage', 'question-sign', 'question-sign', 'Help', false, false );
				}
				else {
					JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
					JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
				}
				
				break;
				
			case 'sync':
				
				JToolBarHelper::title( JText::_( 'COM_JWHMCS_SYNC_VIEW_TITLE' ), 'sync.png' );
				
				if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
					JToolBarHelper :: custom( 'reload', 'loop', 'loop', JText::_( "COM_JWHMCS_SYNC_VIEW_BUTTON_REBUILD" ), false, false );
					JToolBarHelper :: custom( 'usrmgr', 'users', 'users', JText::_( "COM_JWHMCS_DEFAULT_VIEW_BUTTON_USERMANAGER" ), false, false );
					JToolBarHelper :: divider();
					JToolBarHelper :: custom( 'cpanel', 'star', 'star', JText::_( "COM_JWHMCS_DEFAULT_VIEW_BUTTON_JWHMCS" ), false, false );
					JToolBarHelper :: custom( 'helppage', 'question-sign', 'question-sign', 'Help', false, false );
				}
				else {
					JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', JText::_( "COM_JWHMCS_DEFAULT_VIEW_BUTTON_JWHMCS" ), false, false );
					JToolBarHelper :: custom( 'usrmgr', 'usrmgr.png', 'usrmgr.png', JText::_( "COM_JWHMCS_DEFAULT_VIEW_BUTTON_USERMANAGER" ), false, false );
					JToolBarHelper :: divider();
					JToolBarHelper :: custom( 'refresh', 'refresh.png', 'refresh.png', JText::_( "COM_JWHMCS_SYNC_VIEW_BUTTON_RELOAD" ), false, false );
					JToolBarHelper :: divider();
					JToolBarHelper :: custom( 'requery', 'sync.png', 'sync.png', JText::_( "COM_JWHMCS_SYNC_VIEW_BUTTON_REQUERY" ), false, false );
					JToolBarHelper :: divider();
					JToolBarHelper :: custom( 'reload', 'reload.png', 'reload.png', JText::_( "COM_JWHMCS_SYNC_VIEW_BUTTON_REBUILD" ), false, false );
					JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
				}
				
				break;
				
			case 'check' :
				
				JToolBarHelper :: title( JText::_("COM_JWHMCS_CHECK_VIEW_TITLE"), 'chinst.png' );
				
				if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
					JToolBarHelper :: custom( 'cpanel', 'star', 'star', 'J!WHMCS', false, false );
					JToolBarHelper :: divider();
					JToolBarHelper :: custom( 'helppage', 'question-sign', 'question-sign', 'Help', false, false );
				}
				else {
					JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
					JToolBarHelper :: divider();
					JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
				}
				
				break;
				
			case 'install' :
				
				switch ( $task ) {
					case 'installed' :
						JToolBarHelper :: title( JText::_( 'COM_JWHMCS_ADMIN_INSTALL_TITLE' ).': <small><small>[ ' . JText::_( 'COM_JWHMCS_ADMIN_INSTALL_INSTALLED' ).' ]</small></small>', 'install.png' );
						
						if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
							JToolBarHelper :: custom( 'cpanel', 'star', 'star', 'J!WHMCS', false, false );
						}
						else {
							JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
						}
						
						break;
					
					case 'license' :
						JToolBarHelper :: title( JText::_( 'COM_JWHMCS_INSTALL_VIEW_LICENSE_TITLE' ), 'license.png' );
						
						if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
							JToolBarHelper :: custom( 'licenseReload', 'loop', null, JText::_( 'COM_JWHMCS_INSTALL_VIEW_LICENSE_BUTTON_RELOAD' ), false, false );
							JToolBarHelper :: custom( 'licenseAccept', 'save.png', '', JText::_( 'COM_JWHMCS_INSTALL_VIEW_LICENSE_BUTTON_LICENSESAVE' ), false, false );
							JToolBarHelper :: divider();
							JToolBarHelper :: custom( 'cpanel', 'star', 'star', 'J!WHMCS', false, false );
						}
						else {
							JToolBarHelper :: custom( 'licenseReload', 'licreload.png', '', JText::_( 'COM_JWHMCS_INSTALL_VIEW_LICENSE_BUTTON_RELOAD' ), false, false );
							JToolBarHelper :: custom( 'licenseAccept', 'save.png', '', JText::_( 'COM_JWHMCS_INSTALL_VIEW_LICENSE_BUTTON_LICENSESAVE' ), false, false );
							JToolBarHelper :: divider();
							JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
						}
						
						break;
					case 'interview':
						JToolBarHelper :: title( JText::_( 'COM_JWHMCS_INSTALL_VIEW_INTERVIEW_TITLE' ).': <small><small>[ ' . JText::_( 'COM_JWHMCS_INSTALL_VIEW_INTERVIEW_AUTO_TITLE' ).' ]</small></small>', 'settings.png' );
						
						if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
							JToolBarHelper :: custom( 'cpanel', 'star', 'star', 'J!WHMCS', false, false );
						}
						else {
							JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
							JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
						}
						
						break;
					case 'manual':
					default:
						JToolBarHelper :: title( JText::_( 'COM_JWHMCS_ADMIN_INSTALL_TITLE' ).': <small><small>[ ' . JText::_( 'COM_JWHMCS_ADMIN_INSTALL_MANUAL' ).' ]</small></small>', 'install.png' );
						
						if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
							JToolBarHelper :: custom( 'cpanel', 'star', 'star', 'J!WHMCS', false, false );
						}
						else {
							JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
							JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
						}
						
						break;
				}
				
				break;
				
			case 'updates' :
				
				JToolBarHelper :: title( JText::_("COM_JWHMCS_UPDATES_VIEW_TITLE"), 'updates.png' );
				
				if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
					JToolBarHelper :: custom( 'cpanel', 'star', 'star', 'J!WHMCS', false, false );
				}
				else {
					JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
				}
				
				break;
				
		}
	
	}
	
	
	public function usermgr( $task = null, $options = array() )
	{
		switch ( $task ) :
		
		case 'joomadd':
		case 'joomedit':
			
			JToolBarHelper::title(   JText::_( "COM_JWHMCS_USERMGR_VIEW_TITLE" ).': <small><small>[ ' . $options['title'].' ]</small></small>', 'usrmgr.png' );
			
			if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
				
			}
			else {
				JToolBarHelper::back();
			}
			
			if ($options['isnew']) {
				JToolBarHelper::save('joomaddsave', 'Save' );
				JToolBarHelper::cancel();
			}
			else {
				JToolBarHelper::save('joomeditsave', 'Save' );
				JToolBarHelper::cancel( 'cancel', 'Close' );
			}
				
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
			
			break;
		
		case 'whmcsadd':
		case 'whmcsedit':
			
			JToolBarHelper::title(   JText::_( "COM_JWHMCS_USERMGR_VIEW_TITLE" ).': <small><small>[ ' . $options['title'].' ]</small></small>', 'usrmgr.png' );
			
			if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			
			}
			else {
				JToolBarHelper::back();
			}
			
			if ( $options['isnew'] ) {
				JToolBarHelper::save('whmcsaddsave', 'Save' );
				JToolBarHelper::cancel();
			}
			else {
				JToolBarHelper::save('whmcseditsave', 'Save' );
				JToolBarHelper::cancel( 'cancel', 'Close' );
			}
				
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
			
			break;
			
		case 'save':
		case 'sync':
		default:
			
			JToolBarHelper :: title( JText::_( 'COM_JWHMCS_USERMGR_VIEW_TITLE' ), 'usrmgr.png' );
			
			if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
				JToolBarHelper :: custom( 'matchAll', 'search', 'search', JText::_( 'COM_JWHMCS_USERMGR_VIEW_BUTTON_MATCHALL' ), false, false );
				JToolBarHelper :: custom( 'changeAllusername', 'cogs', 'cogs', JText::_( 'COM_JWHMCS_USERMGR_VIEW_BUTTON_RESETALL' ), false, false );
				JToolBarHelper :: custom( 'cleanup', 'health', 'health', JText :: _( 'COM_JWHMCS_USERMGR_VIEW_BUTTON_CLEANUP' ), false, false );
				JToolBarHelper :: custom( 'gotosync', 'loop', 'loop', JText::_( "COM_JWHMCS_DEFAULT_VIEW_BUTTON_SYNCMANAGER" ), false, false );
				JToolBarHelper :: divider();
				JToolBarHelper :: custom( 'cpanel', 'star', 'star', JText::_( "COM_JWHMCS_DEFAULT_VIEW_BUTTON_JWHMCS" ), false, false );
				JToolBarHelper :: custom( 'helppage', 'question-sign', 'question-sign', 'Help', false, false );
			}
			else {
				JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', JText::_( "COM_JWHMCS_DEFAULT_VIEW_BUTTON_JWHMCS" ), false, false );
				JToolBarHelper :: custom( 'matchAll', 'matchall.png', 'matchall.png', JText::_( 'COM_JWHMCS_USERMGR_VIEW_BUTTON_MATCHALL' ), false, false );
				JToolBarHelper :: custom( 'changeAllusername', 'userupdate.png', 'userupdate.png', JText::_( 'COM_JWHMCS_USERMGR_VIEW_BUTTON_RESETALL' ), false, false );
				JToolBarHelper :: custom( 'cleanup', 'cleanup.png', 'cleanup.png', JText :: _( 'COM_JWHMCS_USERMGR_VIEW_BUTTON_CLEANUP' ), false, false );
				JToolBarHelper :: divider();
				JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
			}
			
		endswitch;
		
	}
}