<?php
/**
 * Default View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: view.html.php 555 2012-09-06 02:10:32Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );


/**
 * JwhmcsViewDefault class is the default view for the admin area
 * @version		2.5.1
 * @version		2.4.9 - now extends arbitrary view class to correct J! version differences
 *
 * @since		1.5.0
 * @author		Steven
 */
class JwhmcsViewDefault extends JwhmcsViewExt
{
	
	/**
	 * Assembles the page for the application to send to user
	 * @access		public
	 * @version		2.5.1
	 * @param		unknown		- $tpl: internal tpl override option
	 * 
	 * @since		1.5.0
	 */
	public function display($tpl = null)
	{
		$user	= & JFactory::getUser();
		$task	=   JwhmcsHelper :: get( 'task' );
		
		$doc	=	dunloader( 'document', true );
		load_bootstrap( 'jwhmcs' );
		
		// Retrieve ACL permitted actions
		$canDo	= JwhmcsHelper :: getActions();
		
		// Create the toolbar
		JwhmcsToolbar :: build( 'default', $task, $canDo );
		
		// Grab the icons for the cpanel
		$icons = $this->_getButtons( $canDo );
		
		JwhmcsHelper :: addMedia( 'icons/css' );
		JwhmcsHelper :: addMedia( 'ajax/js' );
		
		$this->assignRef('icons',	$icons); // Icon definitions
		
		parent::display($tpl);
	}
	
	
	/**
	 * Method to get the buttons
	 * @access		private
	 * @version		2.5.1 ( $id$ )
	 * @param		JObject		- $canDo: object of things user is permitted to do
	 *
	 * @return		array
	 * @since		2.5.0
	 */
	private function _getButtons( $canDo )
	{
		$ret	=	array();
		$api	=	dunloader( 'api', 'com_jwhmcs' );
		
		if ( $canDo->get( 'core.admin' ) ) {
			$ret[] = $this->_makeIconDefinition( 'apicnxn-48.png', 'COM_JWHMCS_DEFAULT_VIEW_BUTTON_APICONXN', 'apicnxn', null, null, null );
			$ret[] = $this->_makeIconDefinition( 'ajax-loader-48.gif', 'COM_JWHMCS_BUTTON_UPDATESLOADING', 'updates', 'jwhmcs_icon_updates' );
			
			if ( $api->isEnabled() ) {
				$ret[] = $this->_makeIconDefinition( 'sync-48.png', 'COM_JWHMCS_BUTTON_SETTINGSSYNC', null, null, null, 'settingssync' );
			}
		}
		
		return $ret;
	}
	
	
	/**
	 * Method to create an icon definition
	 * @access		private
	 * @version		2.5.1
	 * @version		2.4.0		- May 2012: Added id tag to img
	 * @param		string		- $iconFile
	 * @param		string		- $label
	 * @param		string		- $controller
	 * @param		string		- $id: the id tag of the image to use
	 * @param		string		- $view
	 * @param		string		- $task
	 *
	 * @return array
	 * @since		1.5.1
	 */
	private function _makeIconDefinition($iconFile, $label, $controller = null, $id = null, $view = null, $task = null )
	{
		$mediapath	= JURI::root()."media/com_jwhmcs/icons/";
		
		return (object) array(
				'link'		=> JRoute::_('index.php?option=com_jwhmcs' 
								. (! is_null( $controller ) ? '&amp;controller=' . $controller : '' ) 
								. (! is_null( $task ) ? '&amp;task=' . $task : '' )
								. (! is_null( $view ) ? '&amp;view=' . $view : '' )
						),
				'icon'		=> $mediapath . $iconFile,
				'label'		=> JText :: _( $label ),
				'id'		=> (! is_null( $id ) ? $id : str_replace( '.png', '', $iconFile ) )
				);
	}
}