<?php
/**
 * J!WHMCS Integrator - User Plugin
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: jwhmcs_user.php 831 2014-11-25 16:13:53Z steven_gohigher $
 * @since      1.5.0
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.helper' );
jimport( 'joomla.application.router' );
jimport( 'joomla.application.component.helper' );
jimport( 'joomla.environment.uri' );
jimport( 'joomla.plugin.plugin' );
jimport( 'dunamis.dunamis' );

if ( function_exists( 'get_dunamis' ) ) get_dunamis( 'com_jwhmcs' );

/**
 * User - JWHMCS plugin
 * @version		2.6.20
 *
 * @since		1.5.0
 * @author		Steven
 */
class plgUserJwhmcs_user extends JPlugin
{
	/**
	 * Stores if we need to revert a setting for changing the lock downs
	 * @access		public
	 * @since		2.2.0 (?)
	 * @var			boolean
	 */
	public $changeLock	= false;	// New with WHMCS 4.3 - lockable fields
	
	/**
	 * Stores the client fields we are using from WHMCS
	 * @access		private
	 * @since		2.5.0
	 * @var			array
	 */
	private $_clientfields	=	array(
			'companyname'	=> false,
			'address1'		=> true,
			'address2'		=> false,
			'city'			=> true,
			'state'			=> true,
			'postcode'		=> true,
			'country'		=> true,
			'phonenumber'	=> true,
			'type'			=> false,
			'id'			=> false
				);
	
	/**
	 * Indicates we are enabling the user plugin
	 * @access		private
	 * @since		2.5.0
	 * @var			boolean
	 */
	private $_enabled	=	false;
	
	/**
	 * Indicates the user plugin should redirect
	 * @access		public
	 * @since		2.4.12
	 * @var			boolean
	 */
	public $redirect	= true;
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		2.6.20
	 * @param		unknown_type	$subject
	 * @param		unknown_type	$config
	 * 
	 * @since		1.5.0
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		
		$app	=	JFactory :: getApplication();
		$this->loadLanguage();
		$this->loadLanguage( 'com_jwhmcs' );
		JFormHelper :: addFieldPath( dirname( __FILE__ ) . '/fields' );
		
		// ==============================================================
		// Run through tests
		// ==============================================================
		// Prevent recursion
		if ( defined( "JWHMCSAPI" ) ) {
			return;
		}
		
		// Ensure we have a token set
		if (! function_exists( 'get_dunamis' ) ) {
			// Not admin or not logged in don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
			
			// Show error message
			$this->_displayError( 'JWHMCS_USER_CONFIG_NODUNAMIS', 'library' );
			return;
		}
		
		get_dunamis( 'com_jwhmcs' );
		
		if (! $this->_testApi() ) {
			// Not admin don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
			
			$api	=	dunloader( 'api', 'com_jwhmcs' );
			$error	=	JText :: _( 'COM_JWHMCS_API_' . strtoupper( $api->getError() ) );
			
			// Show error message
			$this->_displayError( array( 'JWHMCS_USER_CONFIG_APIERROR', $error ), 'api' );
			return;
		}
		
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		
		if (! $config->get( 'enable', false ) ) {
			// Not admin don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
				
			// Show error message
			$this->_displayError( 'JWHMCS_USER_CONFIG_PRODDISABLED', 'globaldisable' );
			return;
		}
		
		if (! $config->get( 'enableuserbridging', false ) ) {
			// Not admin don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
			
			// Show error message
			$this->_displayError( 'JWHMCS_USER_CONFIG_USERDISABLED', 'userdisable' );
			return;
		}
		
		// All good, lets go
		$this->_enabled	=	true;
	}
	
	
	/**
	 * onContentPrepareData event
	 * @access		public
	 * @version		2.6.20 ( $id$ )
	 * @param		string			- $context: string
	 * @param		JUser object	- $data: the already assembled user
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	public function onContentPrepareData( $context, $data )
	{
		// If disabled...
		if (! $this->_enabled ) return true;
		
		// Check we are manipulating a valid form.
		if (! in_array( $context, array( 'com_users.profile', 'com_users.user', 'com_users.registration', 'com_admin.profile' ) ) ) {
			return true;
		}
		
		// We need to have an object
		if (! is_object( $data ) ) {
			return true;
		}
		
		// ---- BEGIN JWHMCS-32
		//		Contact form shows persistent error message
		// If we are a new user
		if (! isset( $data->email ) || empty( $data->email ) ) {
			return true;
		}
		// ---- END JWHMCS-32
		
		// Initialize some things
		$api	=	dunloader( 'api', 'com_jwhmcs' );
		
		// Grab the user
		if (! ( $client = $api->findmatchinguser( $data->email ) ) && is_admin() ) {
			$error	=	JText :: _( 'JWHMCS_API_FINDMATCHINGUSER_NOTFOUND', $data->email );
			$this->_displayError( array( 'JWHMCS_USER_CONFIG_APIERROR', $error ), 'getclientsdetails', false );
			return true;
		}
		
		if (! isset( $data->client ) ) {
			$data->client	=	array();
		}
		
		// Cycle through the client fields and assign to object
		foreach ( $this->_clientfields as $field => $required ) {
			$data->client[$field]	=	$client->$field;
		}
	}
	
	
	/**
	 * onContentPrepareForm event
	 * @access		public
	 * @version		2.6.20 ( $id$ )
	 * @param		JForm object	- $form: the form being assembled
	 * @param		JUser object	- $data: the already assembled user
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	public function onContentPrepareForm( $form, $data )
	{
		// If disabled...
		if (! $this->_enabled ) return true;
		
		// Ensure we have a JForm
		if (! ( $form instanceof JForm ) ) {
			$this->_subject->setError('JERROR_NOT_A_FORM');
			return false;
		}
		
		// Check we are manipulating a valid form.
		$name = $form->getName();
		if (! in_array( $name, array( 'com_users.profile', 'com_users.user', 'com_users.registration', 'com_admin.profile' ) ) ) {
			return true;
		}
		
		// Add the registration fields to the form.
		JForm::addFieldPath( JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_jwhmcs' . DIRECTORY_SEPARATOR . 'models' . DIRECTORY_SEPARATOR . 'fields' );
		JForm::addFormPath( dirname(__FILE__) . DIRECTORY_SEPARATOR . 'forms' );
		$form->loadFile( 'client', false );
		
		foreach ( $this->_clientfields as $field => $required ) {
			// Handle registration form requirements
			if ( in_array( $name, array( 'com_users.profile', 'com_users.registration' ) ) ) {
				if ( $required ) {
					$form->setFieldAttribute( $field, 'required', 'required', 'client' );
				}
			}
		}
		
		// See if we have data and bail if not before removing type/id (preprocessSave then?)
		if ( empty( $data ) ) {
			return;
		}
		
		// See if this is a new user - no client then
		if (! isset( $data->client ) && in_array( $name, array( 'com_users.registration', 'com_users.user' ) ) ) {
			$form->removeField('type', 'client');
			$form->removeField('id', 'client');
		}
	}
	
	
	/**
	 * Event triggered prior to saving a user
	 * @access		public
	 * @version		2.6.20
	 * @version		2.5.0		- May 2013: Complete rewrite
	 * @param		object		- $olduser: the old user details
	 * @param		boolean		- $isNew: indicates this is a new user
	 * @param		object		- $newuser: the new user details
	 *
	 * @since		2.2.0
	 */
	public function onUserBeforeSave( $olduser, $isNew, $newuser )
	{
		// If disabled...
		if (! $this->_enabled ) return true;
		
		// See if no changes were made that affect WHMCS
		if (! $isNew && $olduser['email'] == $newuser['email'] ) {
			return true;
		}
		
		/* Check for recursion from System > API Methods */
		if ( defined( 'JWHMCSAPI' ) ) {
			return;
		}
		
		/* Check for recursion from Authentication > Creating New User */
		if ( defined( 'JWHMCSAUTH' ) ) {
			return true;
		}
		
		$api	=	dunloader( 'api', 'com_jwhmcs' );
		
		// Can't find client or contact... so must be good
		if (! $client = $api->findmatchinguser( $newuser['email'] ) ) {
			return true;
		}
		
		// At this point the new user's email address is not permitted so we must throw an error and bail
		$this->_displayError( array( 'JWHMCS_USER_VALIDATION_FAILED', $newuser['email'] ), 'uservalidation', false );
		return false;
	}
	
	
	/**
	 * Event triggered after a user is stored in Joomla!
	 * @access		public
	 * @version		2.6.20
	 * @version		2.5.0		- May 2013: Complete rewrite
	 * @param		array		- $user: the user array 
	 * @param		boolean		- $isNew: true|false
	 * @param		boolean		- $result: the result so far
	 * @param		JErrorObject	$error: an error object
	 *
	 * @since		1.5.0
	 */
	public function onUserAfterSave( $data, $isNew, $result, $error )
	{
		// If disabled...
		if (! $this->_enabled ) return true;
		
		/* Check for recursion from System > API Methods */
		if ( defined( 'JWHMCSAPI' ) ) {
			return;
		}
		
		/* Check for recursion from Authentication > Creating New User */
		if ( defined( 'JWHMCSAUTH' ) ) {
			return true;
		}
		
		$api		=	dunloader( 'api', 'com_jwhmcs' );
		$config		=	dunloader( 'config', 'com_jwhmcs' );
		$input		=	dunloader( 'input', true );
		
		$task		=	'update';
		$type		=	'client';
		$client		=	JArrayHelper :: getValue( $data, 'client', array(), 'array' );
		$fullname	=	JArrayHelper :: getValue( $data, 'name', null, 'string' );
		
		// Split the full name to create first / last name and grab email
		$parts	=	explode( " ", $fullname );
		$client['firstname']	=	array_shift( $parts );
		$client['lastname']		=	(! empty( $parts ) ? implode( " ", $parts ) : null );
		$client['email']		=	$data['email'];
		
		// Catch Enable / Disable toggles
		if (! $isNew && ! isset( $client['type'] ) && ! isset( $client['id'] ) ) {
			$exists = $api->findmatchinguser( $data['email'] );
			if ( $exists->result == 'success' ) {
				$task = 'update';
				$client['type']	=	$exists->type;
				$client['id']	=	$exists->id;
				unset( $client['email'], $client['firstname'], $client['lastname'] );
			}
		}
		
		// See if we are adding or updating WHMCS user
		if ( $isNew || (! isset( $client['type'] ) && ! isset( $client['id'] ) && in_array( $config->get( 'useraddmethod', '4' ), array( '2', '4' ) ) ) ) {
			$task	=	'create';
		}
		else if ( ! $isNew && ! isset( $client['type'] ) && ! isset( $client['id'] ) && ! in_array( $config->get( 'useraddmethod', '4' ), array( '2', '4' ) ) ) {
			// We don't want to add users when updating an account so bail
			return true;
		}
		
		// Determine which type of WHMCS user we are working with
		if ( isset( $client['type'] ) && $client['type'] ) {
			$type	=	$client['type'];
			unset( $client['type'] );
		}
		
		if ( isset( $client['id'] ) && $client['id'] ) {
			$client[($type == 'client' ? 'client' : 'contact' ) . 'id']	=	$client['id'];
			unset( $client['id'] );
		}
		
		// Password handling
		if ( $isNew && isset( $data['password_clear'] ) && ! empty( $data['password_clear'] ) ) {
			$client['password2']	=	$data['password_clear'];
		}
		else if ( $isNew || (! $isNew && $task == 'create' ) ) {
			$client['password2']	=	JApplication :: getHash( mt_rand() );
		}
		// Backend edit check
		else if ( is_admin() ) {
			// Grab the form data from input handler
			$jform	=	$input->getVar( 'jform', array(), 'array' );
			
			// If we set the password in the form then we should update it
			if ( isset( $jform['password'] ) && ! empty( $jform['password'] ) ) {
				$client['password2']	=	$jform['password'];
			}
		}
		// Front End is slightly different
		else {
			$jform	=	$input->getVar( 'jform', array(), 'array' );
			
			// If we set the password in the form then we should update it
			if ( isset( $jform['password1'] ) && ! empty( $jform['password1'] ) ) {
				$client['password2']	=	$jform['password1'];
			}
		}
		
		if ( $data['block'] == '1' ) {
			$client[( $type == 'client' ? 'status' : 'subaccount' )]	=	( $type == 'client' ? 'Inactive' : '0' );
		}
		else {
			$client[( $type == 'client' ? 'status' : 'subaccount' )]	=	( $type == 'client' ? 'Active' : '1' );
		}
		
		// Cleanup for API
		if ( $task == 'create' ) {
			$client['skipvalidation']	=	true;
			
			if (! $config->get( 'useraddsendemailwhmcs' ) ) {
				$client['noemail']			=	true;
			}
		}
		
		// Build API Method
		$method	=	( $task == 'create' ? 'add' : 'update' ) . ( $type == 'client' ? 'client' : 'contact' );
		
		// Make the call... :-)
		$result	=	$api->$method( $client );
		
		if ( $result->result != 'success' ) {
			$this->_displayError( array( 'JWHMCS_USER_CONFIG_APIERROR', $api->getError() ), 'getclientsdetails', false );
			return false;
		}
		
		// Contacts go away here (no possibility of a contact form field to handle username)
		if ( $type == 'contact' ) {
			return true;
		}
		
		// Pass the username over for updating if applicable
		$client['username2']	=	$data['username'];
		$result	=	$api->updateusername( $client );
		return true;
	}
	
	
	/**
	 * Event triggered prior to deletion of a user in Joomla!
	 * @access		public
	 * @version		2.6.20
	 * @param		JUser Object	$user
	 * 
	 * @since		1.5.0
	 */
	public function onUserBeforeDelete($user)
	{
		// If disabled...
		if (! $this->_enabled ) return true;
	}
	
	
	
	/**
	 * Event triggered after deletion of a user in Joomla!
	 * @access		public
	 * @version		2.6.20
	 * @version		2.5.0		- May 2013: Complete rewrite
	 * @param		array	$user
	 * @param		boolean			$succes
	 * @param		JErrorObject	$msg
	 * 
	 * @since		1.5.0
	 */
	public function onUserAfterDelete($user, $succes, $msg)
	{
		// If disabled...
		if (! $this->_enabled ) return true;
		
		$post	=	array();
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		$api	=	dunloader( 'api', 'com_jwhmcs' );
		
		// If we do nothing, then get outta here
		if ( ( $userdeletemethod = $config->get( 'userdeletemethod' ) ) == '0' ) {
			return;
		}
		
		// Find the user
		$client	=	$api->findmatchinguser( $user['email'] );
		$post[( $client->type == 'client' ? 'clientid' : 'contactid' )]	=	$client->id;
		
		// We want to simply close / unsubaccount the account
		if ( $userdeletemethod == '1' ) {
			
			$task	=	( $client->type == 'client' ? 'closeclient' : 'deletecontact' );
			
		}
		// Physically delete the client / contact
		else if ( $userdeletemethod == '2' ) {
			$task	=	( $client->type == 'client' ? 'deleteclient' : 'deletecontact' );
		}
		
		$result	=	$api->$task( $post );
		
		// If we failed over on WHMCS, then throw an error, but its too late here
		if (! $result ) {
			$this->_displayError( array( 'JWHMCS_USER_CONFIG_APIERROR', $api->getError() ), 'getclientsdetails', false );
		}
		
		return;
	}

	
	/**
	 * Event triggered at user login
	 * @access		public
	 * @version		2.6.20
	 * @version		2.1.0	- Modified parameters to reflect database change (Apr 2010)
	 * @param		array		- $user: contains the user array
	 * @param		array		- $options: contains options
	 * 
	 * @since		1.5.0
	 */
	public function onUserLogin($user, $options)
	{
		// Ensure we can run this
		if (! $this->_enabled ) {
			return;
		}
		
		if ( JFactory::getApplication()->isAdmin() ) {
			return; // Dont run in admin
		}
		
		// Don't auth against W if we are coming from W
		if ( isset( $options['jwhmcs'] ) && $options['jwhmcs'] ) {
			return;
		}
		
		// Handle Remember Me
		$this->_handleRememberme( $user, $options );
		
		// Initialize AutoAuth into WHMCS
		$app		=	JFactory::getApplication();
		$config		=	dunloader( 'config', 'com_jwhmcs' );
		$gmt		=	new DateTime( null, new DateTimeZone('GMT') );
		
		// Build our hash
		$token		=	$config->get( 'token' );
		$timestamp	=	$gmt->format("U");
		$email		=	$user['email'];
		$hash		=	sha1( $email . $timestamp . $token );
		
		// Clean up the return url... just in case
		if ( isset( $options['return'] ) && $options['return'] && DunUri :: isInternal( $options['return'] ) ) {
			$return_uri	=	DunUri :: getInstance( JRoute :: _( $options['return'] ) );
			$server_uri	=	DunUri :: getInstance();
			$return_uri->setScheme( $server_uri->getScheme() );
			$return_uri->setHost( $server_uri->getHost() );
			$options['return']	=	$return_uri->toString();
		}
		
		$whmcsurl	=	$config->get( 'whmcsurl' );
		$whmcsuri	=	DunUri :: getInstance( $whmcsurl, true );
		$whmcsuri->setPath( rtrim( $whmcsuri->getPath(), '/' ) . '/dologin.php' );
		$whmcsuri->setVar( 'email', $email );
		$whmcsuri->setVar( 'timestamp', $timestamp );
		$whmcsuri->setVar( 'hash', $hash );
		$whmcsuri->setVar( 'goto', urlencode( 'clientarea.php' ) );
		$whmcsuri->setVar( 'jwhmcs', base64_encode( $options['return'] ) );
		
		$app->redirect( $whmcsuri->toString() );
		$app->close();
		return true;
	}

	
	/**
	 * Event triggered on user logout
	 * @access		public
	 * @version		2.6.20
	 * @version		2.1.0	- Modified parameters to reflect database change (Apr 2010)
	 * @param		array		- $user: logged out user array
	 * 
	 * @since		1.5.0
	 */
	public function onUserLogout( $user, $options = array() )
	{
		// Ensure we can run this
		if (! $this->_enabled ) {
			return;
		}
		
		if ( JFactory::getApplication()->isAdmin() ) {
			return; // Dont run in admin
		}
		
		// Don't logout from W if we are coming from W
		if ( isset( $options['jwhmcs'] ) && $options['jwhmcs'] ) {
			return;
		}
		
		// ---- BEGIN JWHMCS-7
		//		Remember me cookie not being killed by application
		$this->_handleRemembermenot();
		// ---- END JWHMCS-7
		
		// Initialize
		$app		=	JFactory::getApplication();
		$config		=	dunloader( 'config', 'com_jwhmcs' );
		$input		=	dunloader( 'input', true );
		
		$return_uri	=	DunUri :: getInstance( JRoute :: _( base64_decode( $input->getVar( 'return', null ) ) ) );
		$server_uri	=	DunUri :: getInstance();
		
		$return_uri->setScheme( $server_uri->getScheme() );
		$return_uri->setHost( $server_uri->getHost() );
		
		$whmcsurl	=	$config->get( 'whmcsurl' );
		$whmcsuri	=	DunUri :: getInstance( $whmcsurl, true );
		$whmcsuri->setPath( rtrim( $whmcsuri->getPath(), '/' ) . '/logout.php' );
		$whmcsuri->setVar( 'complete', true );
		$whmcsuri->setVar( 'jwhmcs', base64_encode( $return_uri->toString() ) );
		
		$app->redirect( $whmcsuri->toString() );
		$app->close();
		return true;
	}
	
	
	/**
	 * Method to create a hash
	 * @static
	 * @access		public
	 * @version		2.6.20 ( $id$ )
	 * @param		string		- $seed: a seed for the md5er
	 *
	 * @return		string
	 * @since		2.5.0
	 */
	public static function createHash( $seed )
	{
		return md5( JFactory::getConfig()->get('secret') . $seed );
	}
	
	
	/**
	 * Method to determine if we are using ssl
	 * @static
	 * @access		public
	 * @version		2.6.20 ( $id$ )
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	public static function isSslconnection()
	{
		return ( ( isset( $_SERVER['HTTPS'] ) && ( $_SERVER['HTTPS'] == 'on' ) ) || getenv( 'SSL_PROTOCOL_VERSION' ) );
	}
	
	
	/**
	 * Event called when gathering update sites to check for updates
	 * @access		public
	 * @version		2.6.20
	 *
	 * @return		array
	 * @since		2.4.0
	 */
	public function getUpdateSite()
	{
		return array(
				'extensionName'				=> 'plg_jwhmcs_user',
				'options' => array(
						'extensionTitle'	=> 'J!WHMCS Integrator User Plugin',
						'storage'			=> 'database',
						'storagePath'		=> null,
						'extensionType'		=> 'plugin',
						'updateUrl'			=> 'https://www.gohigheris.com/updates/jwhmcs/plugins/user'
				)
		);
	}
	
	
	/**
	 * Common method for displaying an error message
	 * @access		private
	 * @version		2.6.20 ( $id$ )
	 * @param		string		- $msg: the message to display
	 * @param		string		- $task: the task we are calling from
	 * @param		boolean		- $usesession: indicates we should check / store in session
	 *
	 * @since		2.5.0
	 */
	private function _displayError( $msg = null, $task = 'framework', $usesession = true )
	{
		// Translate string first
		if ( is_array( $msg ) ) {
			$string	=	JText :: _( array_shift( $msg ) );
			array_unshift( $msg, $string );
			$msg	=	call_user_func_array( 'sprintf', $msg );
		}
		else {
			$msg		=	JText :: _( $msg );
		}
		
		// If we want to use the session do so
		if ( $usesession ) {
			$session	=	JFactory :: getSession();
			$hasrun		=	$session->get( 'jwhmcs_user.' . $task, false );
			
			if ( $hasrun ) {
				return;
			}
			else {
				$session->set( 'jwhmcs_user.' . $task, true );
			}
		}
		
		// Provide means to only show error one time
		static $instance = array();
		
		if ( isset( $instance[$task] ) ) {
			return;
		}
		
		$instance[$task]	=	true;
		
		// Get to the error message
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JFactory::getApplication()->enqueueMessage( "{$msg}" );
		}
		else {
			JError::raiseNotice( 100, "{$msg}" );
		}
	}
	
	
	/**
	 * Method for handling the Remember me being set on login form
	 * @access		private
	 * @version		2.6.20 ( $id$ )
	 * @param		array		- $user: user data 
	 * @param		array		- $options: options sent
	 *
	 * @since		2.5.0
	 */
	private function _handleRememberme( $user, $options = array() )
	{
		$config	=	dunloader( 'config', true );
		$input	=	dunloader( 'input', true );
		
		if (! isset( $options['remember'] ) || ! $options['remember'] ) {
			return;
		}
		
		$credentials				= array(
				'username'	=>	$input->getVar( 'username', null ),
				'password'	=>	$input->getVar( 'password', null )
				);
		
		jimport('joomla.utilities.simplecrypt');
		
		if ( version_compare( JVERSION, '2.5.6', 'ge' ) ) {
			$privateKey	=	self :: createHash( @$_SERVER['HTTP_USER_AGENT'] );
			$key		=	new JCryptKey( 'simple', $privateKey, $privateKey );
			$crypt		=	new JCrypt( new JCryptCipherSimple, $key );
			$rcookie	=	$crypt->encrypt( json_encode( $credentials ) );
			$lifetime	=	time() + 365 * 24 * 60 * 60;
			
			// Use domain and path set in config for cookie if it exists.
			$cookie_domain	=	$config->get( 'cookie_domain', '' );
			$cookie_path	=	$config->get( 'cookie_path', '/' );
			$secure			=	self :: isSslconnection();
			setcookie( self :: createHash( 'JLOGIN_REMEMBER' ), $rcookie, $lifetime, $cookie_path, $cookie_domain, $secure, true );
		}
		else {
			
			// Create the encryption key, apply extra hardening using the user agent string.
			$key			=	self :: createHash( @$_SERVER['HTTP_USER_AGENT'] );
			$crypt			=	new JSimpleCrypt( $key );
			$rcookie		=	$crypt->encrypt( serialize( $credentials ) );
			$lifetime		=	time() + 365 * 24 * 60 * 60;
			
			// Use domain and path set in config for cookie if it exists.
			$cookie_domain	=	$config->get( 'cookie_domain', '' );
			$cookie_path	=	$config->get( 'cookie_path', '/' );
			setcookie( self :: createHash( 'JLOGIN_REMEMBER' ), $rcookie, $lifetime, $cookie_path, $cookie_domain );
		}
	}
	
	
	/**
	 * Method to kill the remember me cookie
	 * @desc		Added for JWHMCS-7
	 * @access		public
	 * @version		2.6.20 ( $id$ )
	 * 
	 * @return		true
	 * @since		2.5.2
	 */
	private function _handleRemembermenot()
	{
		$config			=	dunloader( 'config', true );
		$cookie_domain	=	$config->get( 'cookie_domain', '' );
		$cookie_path	=	$config->get( 'cookie_path', '/' );
		
		setcookie( self :: createHash( 'JLOGIN_REMEMBER' ), false, time() - 86400, $cookie_path, $cookie_domain );
		
		return true;
	}
	
	/**
	 * Provide means to test the API one time
	 * @access		public
	 * @version		2.6.20 ( $id$ )
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	private function _testApi()
	{
		$session	=	JFactory :: getSession();
		$isvalid	=	$session->get( 'jwhmcs_user.apicheck', false );
		
		if ( $isvalid ) return true;
		
		$api		=	dunloader( 'api', 'com_jwhmcs' );
		$isvalid	=	$api->ping();
		
		if ( $isvalid ) {
			$session->set( 'jwhmcs_user.apicheck', true );
		}
		
		return (bool) $isvalid;
	}
}