<?php
/**
 * WHMCS User Synchrization View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id$
 * @since      2.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'application.component.view' );
jimport( 'application.component.helper' );

/**
 * View for API Connection manager of J!WHMCS Integrator
 * @version		2.6.20
 *
 * @author		Steven
 * @since		2.5.0
 */
class JwhmcsViewApicnxn extends JwhmcsViewExt
{
	
	/**
	 * Display view
	 * @access		public
	 * @version		2.6.20
	 * @param		unknown		- $tpl: override to pass for tpl
	 *
	 * @since		1.5.1
	 */
	public function display($tpl = null)
	{
		$doc	=	dunloader( 'document', true );
		load_bootstrap( 'jwhmcs' );
		
		$params	=	JComponentHelper :: getParams( 'com_jwhmcs' );
		$data	=	new stdClass();
		
		foreach ( array( 'whmcsurl', 'whmcsapiusername', 'whmcsapipassword', 'whmcsapiaccesskey' ) as $item ) {
			$data->$item = $params->get( $item );
		}
		
		JwhmcsToolbar :: build( 'apicnxn' );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JwhmcsHelper :: addMedia( 'bootstrap/css' );
// 			JwhmcsHelper :: addMedia( 'icons35/css' );
// 			JwhmcsHelper :: addMedia( 'install/css' );
		}
		
		JwhmcsHelper :: addMedia( 'common/js' );
		JwhmcsHelper :: addMedia( 'ajax/js' );
		JwhmcsHelper :: addMedia( 'icons/css' );
		
		$this->assignRef( 'data', $data );
		parent :: display( $tpl );
	}
}