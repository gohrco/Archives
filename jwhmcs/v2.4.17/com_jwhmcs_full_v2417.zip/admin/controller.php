<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: controller.php 555 2012-09-06 02:10:32Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

/**
 * JwhmcsController for admin functions
 * @version		2.4.17
 * 
 * @author		Steven
 * @since		1.5.0
 */
class JwhmcsController extends JwhmcsControllerExt
{
	/**
	 * Display Task
	 * @access		public
	 * @version		2.4.17
	 * 
	 * @since		1.5.0
	 */
	public function display()
	{
		// If the view hasn't been set, set it to default
		if ( is_null( JwhmcsHelper :: get( 'controller' ) ) )	JwhmcsHelper :: set( 'controller', 'default' );
		if ( is_null( JwhmcsHelper :: get( 'view' ) ) )			JwhmcsHelper :: set( 'view', JwhmcsHelper :: get( 'controller' ) );
		
		// Call up the parent display task
		parent::display();
	}
	
	
	/**
	 * Control panel task
	 * @access		public
	 * @version		2.4.17
	 * 
	 * @since		1.5.0
	 */
	public function cpanel()
	{
		JwhmcsHelper :: set( 'controller', 'default' );
		JwhmcsHelper :: set( 'view', 'default' );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JwhmcsHelper :: set( 'layout', 'default35' );
		}
		else {
			JwhmcsHelper :: set( 'layout', 'default' );
		}
		
		parent::display();
	}
	
	
	/**
	 * Help page task
	 * @access		public
	 * @version		2.4.17
	 * 
	 * @since		1.5.0
	 */
	public function helppage()
	{
		JwhmcsHelper :: set( 'controller', 'helppage' );
		JwhmcsHelper :: set( 'view', 'helppage' );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JwhmcsHelper :: set( 'layout', 'default35' );
		}
		else {
			JwhmcsHelper :: set( 'layout', 'default' );
		}
		
		parent::display();
	}
	
	
	/**
	 * Redirect to group manager
	 * @access		public
	 * @version		2.4.17
	 * 
	 * @since		1.5.0
	 */
	public function grpmgr()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=grpmgr', null );
	}
	
	
	/**
	 * Redirect to the user manager
	 * @access		public
	 * @version		2.4.17
	 * 
	 * @since		1.5.0
	 */
	public function usrmgr()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=usermgr', null );
	}
}