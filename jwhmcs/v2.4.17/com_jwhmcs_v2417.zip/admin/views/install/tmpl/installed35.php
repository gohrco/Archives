<?php 
$baseurl	= JURI::base();
?>

<style type="text/css" >
table.adminform {
	font-size: 1.1em;
	font-weight: normal;
	line-height: 120%;
}
p.install {
	color: #000000;
	text-align: left;
	text-indent: 1.8em;
}
div#cpanel {
	clear: both;
	margin: 0px auto;
	width: 400px;
}
#cpanel div.icon {
	margin: 10px 40px;
	text-align:center;
}
div.icon span {
	font-size: 0.8em;
}
ul#adminMenu {
	list-style-type: disc;
}
ol#adminMenu, ul#adminMenu {
	color:#000000;
	font-weight:normal;
	margin: 0px 16px;
	text-align:left;
	text-indent:1.8em;
}
</style>

<div class="span10">
	<p><img src="<?php echo JURI::base(); ?>../media/com_jwhmcs/images/logo.jpg" width="281" height="64" /></p>
	<p>Thank you for purchasing and installing J!WHMCS Integrator!  The Joomla component portion of J!WHMCS Integrator has been installed.  To complete installation, you can select from either having the installation completed automatically for you, or to complete the installation manually yourself.</p>
	<p>If your Joomla site and your WHMCS site are live and active and you wish to proceed cautiously with the installation, then it is recommended you do a MANUAL install.  On the WHMCS portion of the install, a hook file is installed in your WHMCS / includes/hooks diretory that will be immediately active upon installation.</p>
	<h3>Automatic Installation</h3>
	<p>The following steps will be completed if you select the automatic installation:</p>
	<ul>
		<li>Plugins installed (authentication, system and user plugins) and activated</li>
		<li>WHMCS files installed</li>
		<li>License verified</li>
		<li>API connection established</li>
		<li>Existing users from WHMCS imported into J!WHMCS Integrator table</li>
		<li>User accounts are matched up based upon email addresses</li>
	</ul>
	<p>To complete your installation using the Automatic method below, you will require the following information:</p>
	<ul>
		<li>Your J!WHMCS Integrator License (available to you when you purchased the product)</li>
		<li>URL to your WHMCS Installation</li>
		<li>File Path to your WHMCS Installation (for automatic install, this path must be accessible by Joomla!)</li>
		<li>WHMCS API Username</li>
		<li>WHMCS API Password</li>
		<li>WHMCS API Access Key (if required by your WHMCS)</li>
	</ul>
</div>

<div class="span12 cpanel">
	<a href="<?php echo JURI::base(); ?>index.php?option=com_jwhmcs&controller=install&task=interview" class="btn span1">
		<img
			src="<?php echo JURI::base() ?>../media/com_jwhmcs/icons/Automatic.png"
			border="0" alt="Automatic Installation" />
		<span class="linktitle">Automatic Install</span>
	</a>
	<a href="<?php echo JURI::base(); ?>index.php?option=com_jwhmcs&controller=install&task=manual" class="btn span1">
		<img
			src="<?php echo JURI::base() ?>../media/com_jwhmcs/icons/Manual.png"
			border="0" alt="Manual Installation" />
		<span class="linktitle">Manual Install</span>
	</a>	
</div>

<form action="index.php" method="post" name="adminForm" id="item-form">
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="task" value="" />
</form>