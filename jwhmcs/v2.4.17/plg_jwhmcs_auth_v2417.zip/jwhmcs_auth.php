<?php
/**
 * J!WHMCS Integrator - Authentication Plugin
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: jwhmcs_auth.php 655 2013-03-20 21:20:28Z steven_gohigher $
 * @since      1.5.1
 * 
 * @desc		This plugin handles authentication of the user in case they use
 * 				their email address instead of their Joomla username.
 */


// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.application.component.helper' );

$path	= JPATH_ADMINISTRATOR . '/components/com_jwhmcs/jwhmcs.helper.php';
if ( file_exists( $path ) ) require_once( $path );


/**
 * Authentication - J!WHMCS Integrator plugin
 * @version		2.4.17
 * 
 * @since		1.5.1
 * @author		Steven
 */
class plgAuthenticationJwhmcs_auth extends JPlugin
{
	private $e		= false;	// Error holder
	private $whmcs	= false;	// Is this coming from whmcs? T/F
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		2.4.17
	 * @param		unknown_type	- $subject
	 * @param		unknown_type	- $config
	 * 
	 * @since		1.5.1
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		$this->loadLanguage();
	}
	
	
	/**
	 * Authenticate the user against Joomla or WHMCS
	 * @access		public
	 * @version		2.4.17
	 * @version		2.1.0		- April 2010: added subaccount authentication
	 * @version		2.0.2		- March 2010: modified response when getting results for email to look for array
	 * @param		array		- $credentials: the passed credentials
	 * @param		array		- $options: the options passed
	 * @param		object		- $response: object
	 * 
	 * @return		boolean
	 * @since		1.5.1
	 */
	public function onUserAuthenticate( $credentials, &$options, &$response )
	{
		$app	= & JFactory::getApplication();
		
		// If we can't find the params bail
		if (! class_exists('JwhmcsParams') ) return;
		
		// If we can't load the helper then bail
		if (! class_exists( 'JwhmcsHelper' ) ) return;
		
		// We are catching eternal cookie logins
		if ( isset( $options['jwhmcsrememberme'] ) && $options['jwhmcsrememberme'] === true ) define( 'INTLOGIN', true );
		
		$db				= & JFactory::getDBO();
		$jcurl			= & JwhmcsCurl::getInstance();
		$params			= & JwhmcsParams::getInstance();
		$this->whmcs	=   ( isset( $options['whmcs'] ) ? $options['whmcs'] : false );
		$response->type	= 'jwhmcs_auth';
		
		if (! $params->get( 'Enable' )) {
			$response->status	= 4;
			$response->error_message = JText::_('AUTH_ERROR_DISABLED');
			return false;
		}
			
		if (! $params->get( 'UserEnable' )) {
			$response->status = 4;
			$response->error_message = JText::_('AUTH_ERROR_USERINT_DISABLED');
			return false;
		}
		
		jimport('joomla.user.helper');
		jimport ('joomla.error.log');
		$conditions = '';
		
		// Verify password isn't empty before doing anything
		if (empty($credentials['password'])) {
			return $this->_errorHandler( $this->whmcs, $response, 'AUTH00P000' );
		}
		
		// If we can even authenticate emails against WHMCS, then find out if an email being used
		$isemail	= ( $params->get( 'WuserAuthenticate' ) ? JwhmcsHelper::isEmail( $credentials['username'] ) : false );
		
		// If this is an email and not an admin area...
		if ($isemail && (! $app->isAdmin())) {
			// Run authentication against WHMCS
			if (! ($wuser = $this->_authWhmcs($credentials, $response) ) )
				return false; // Find a way to not throw errors if authentication itself fails $this->_errorHandler( $this->whmcs, $response, 'AUTH02P001' );;
		}
		// If this is a username...
		else {
			// Run authentication against Joomla
			if (! ($juser = $this->_authJoomla($credentials, $response) ) ) {
				return false;
			}
			
			// Administrators get off here...
			if ($app->isAdmin())
				return true;
		}
		
		/* ---------------------------------------------------------------------- *\
		 * At this point the user is authenticated against either Joomla or WHMCS
		\* ---------------------------------------------------------------------- */
		$whereby	= ($isemail ? "xref_b={$wuser['id']} " : "xref_a={$juser->id} ");
		$subacct	= ( isset( $wuser["subaccount"] ) ? $wuser["subaccount"] : false );
		$xref_type	= "BETWEEN 1 AND 9";
		
		if ( ( $isemail ) AND ( $subacct ) ) {
			$xref_type = "IN ( 5, 6, 7, 9 )";
		}
		elseif ( ( $isemail ) AND (! $subacct ) ) {
			$xref_type = "IN ( 1, 2, 3, 4, 8)";
		}
		
		// If we have arrived here then user has authenticated, now we need to pull Joomla user
		$query	= "SELECT xref_a as joomlaid, xref_type as type, xref_b as clientid FROM #__jwhmcs_xref WHERE {$whereby} AND xref_type {$xref_type}";
		$db->setQuery($query);
		$joom	= $db->loadObjectList();
		
		$joom	= $this->_checkOrphaned($joom, ($isemail ? 'joomla' : 'whmcs') );
		
		// Check to see if the matchedup user is actually a member of a group
		$isgroup	=  ( $isemail ? false : $this->_checkGroup( $joom, $credentials ) );
		
		// Test to ensure there is a joom
		if ($joom):
			// Get matching Joomla info
			if ($isemail) {
				// No matching Joomla info found
				if (! ($juser = $this->_getJoomlaData($joom->joomlaid, 'id')) ) {
					$this->_removeXref($joom->joomlaid, $joom->type, $joom->clientid);
					$joom = null;
				}
				// We did find the matching info now should we reset the password?
				else {
					if (! $this->_handlePassword('joomla', $juser, $joom, $credentials) )
					{
						return $this->_errorHandler( $this->whmcs, $response );
					}
				}
			}
			
			// Or get matching WHMCS info
			else {
				// No matching WHMCS info found
				if (! ($wuser = JwhmcsHelper::getWhmcsUser($joom->clientid, 'id', ( in_array( $joom->type, array( 1, 2, 3, 8 ) ) ? 'client' : 'contact' ) ) ) ) {
					$this->_removeXref($joom->joomlaid, $joom->type, $joom->clientid);
					$joom = null;
				}
				// We did find the matching info in WHMCS, so should we reset the password?
				else {
					if (! $isgroup ) {
						if (! $this->_handlePassword('whmcs', $wuser, $joom, $credentials) ) {
							return $this->_errorHandler( $this->whmcs, $response );
						}
					}
				}
			}
		endif; // End testing through joom variable
		
		// Matching user doesn't exist in xref or was removed b/c it doesn't exist in Joomla
		if ( (! $joom) && ($isemail))
		{
			// Retrieve matching user in Joomla by email
			$juser = $this->_getJoomlaData($wuser['email'], 'email');
			
			// No matching user found
			if (! $juser)
			{
				// Can we add them?
				if ($params->get( 'JuserAutoadd' )) {
					$juser = $this->_addJoomlaUser($wuser, $credentials, $response);
				}
				// We aren't allowed by parameters to add new Joomla user so we fail since we must have a Joomla user to login with
				else
				{
					return $this->_errorHandler( $this->whmcs, $response, 'AUTH01P003' );
				}
			}
		}
		// Matching user doesn't exist in xref or was removed b/c it doesn't exist in WHMCS
		elseif ((! $joom) && (! $isemail))
		{
			// Retrieve matching user in WHMCS by email
			$wuser = JwhmcsHelper::getWhmcsUser($juser->email, 'email', 'client');
			
			if (! $wuser )
			{
				$wuser = JwhmcsHelper::getWhmcsUser($juser->email, 'email', 'contact' );
			}
			
			// No matching user found
			if (! $wuser) {
				// Can we add them?
				if ($params->get( 'WuserAutoadd' )) {
					$wuser = $this->_addWhmcsUser($juser, $credentials, $response);
				}
				// We aren't allowed by parameters to add a new user to WHMCS, but they are authenticated in Joomla so return true
				else {
					$user = JUser::getInstance($juser->id);
					$response->fullname 	= $user->name;
					$response->username		= $user->username;
					$response->email		= $user->email;
					$response->password		= $credentials['password'];
					$response->password_clear = $credentials['password'];
					$response->status		= 1;
					$response->error_message = '';
					return true;
				}
			}
		}
		
		// Error trapping in case Joomla / WHMCS users not created or are empty
		if (( empty( $juser->id ) ) || ( empty ( $wuser['id'] ) ) )
		{
			return $this->_errorHandler( $this->whmcs, $response, 'AUTH00P001' );
		}
		
		// Both users have been created or gathered so lets match em up
		if (! $joom) {
			$justore	=   ( $params->get( 'JusernameStore' ) == '8' ? true : false );  // If we want to request the username check parameter here
			$xtype		=   ( isset( $wuser["xref_type"] ) ? ( $wuser["xref_type"] == 'client' ? 2 : 6 ) : 2 );
			$type		=   ($isemail ? ( $justore ? ( $wuser['xref_type'] == 'client' ? 8 : 9 ) : $xtype ) : 2 );
			$query = "INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) VALUES ({$juser->id}, {$type}, {$wuser['id']})";
			$db->setQuery($query);
			$db->query();
		}
		
		// Return response object true
		$user = JUser::getInstance($juser->id);
		
		// Test to see if the user is blocked and remove password so can't login to WHMCS
		if ( ( $user->get( 'block' ) == 1 ) && (! $params->get( 'JuserPendingallow' ) ) )
		{
			$credentials['password'] = '';
			$response->type	= '';
		}
		elseif ( ( $user->get( 'block' ) == 1 ) && ( $params->get( 'JuserPendingallow' ) ) )
		{
			if (! defined( 'JWHMCS_AUTH' ) ) define('JWHMCS_AUTH', true); // Set so we don't try to add the new user to WHMCS
			
			$ubind = array( 'block' => false );
			
			$juser = JUser::getInstance($user->id); 
			
			if (! $juser->bind($ubind, 'usertype') ) return $this->_errorHandler( $this->whmcs, $response, 'AUTH01P025' );
			if (! $juser->save() ) return $this->_errorHandler( $this->whmcs, $response, 'AUTH01P026' );
			$user = JUser::getInstance( $juser->id );
		}
		
		$response->fullname 	= $user->name;
		$response->username		= $user->username;
		$response->email		= (! $isgroup ? $user->email : $credentials['username'] );
		$response->password		= $credentials['password'];
		$response->password_clear = $credentials['password'];
		$response->status		= 1;
		$response->error_message = '';
		return true;
	}
	
	
	
	/**
	 * Method to authenticate a WHMCS user
	 * @access		private
	 * @version		2.4.17
	 * @param		array		- $credentials: the credentials passed to us
	 * @param		object		- $response: the response object
	 * 
	 * @return		array
	 * @since		2.1.0
	 */
	private function _authWhmcs($credentials, &$response)
	{
		// Start by getting client data
		$type	= 'client';
		$whmcs = JwhmcsHelper::getWhmcsUser($credentials['username'], 'email', $type );
		
		if (! $whmcs ) {
			$type	= 'contact';
			$whmcs = JwhmcsHelper::getWhmcsUser( $credentials['username'], 'email', $type );
		}
		
		// result failed - no user found by that email
		if ( $whmcs['result'] != 'success' )
			return $this->_errorHandler( $this->whmcs, $response, 'AUTH02P010' );
		
		$isActive	= $this->_isActive( $whmcs, $type );
		if (! $isActive ) return $this->_errorHandler( $this->whmcs, $response, 'AUTH02P001' );
		
		if (! $this->_testWhmcsPassword($whmcs['password'], $credentials['password']))
			return $this->_errorHandler( $this->whmcs, $response, 'AUTH02P011' );
		
		if ( $whmcs['xref_type'] == 'client' ) {
			$whmcs['id']	=	$whmcs['userid'];
		}
		
		return $whmcs;
	}
	
	
	/**
	 * Authenticates a Joomla user
	 * @access		private
	 * @version		2.4.17
	 * @param		array		- $credentials: the passed credentials
	 * @param		object		- $response: object
	 * 
	 * @return		JUser object
	 * @since		2.1.0
	 */
	private function _authJoomla($credentials, &$response)
	{
		$app	= & JFactory::getApplication();
		$params = & JwhmcsParams::getInstance();
		$user	=   $this->_getJoomlaData($credentials['username'], 'username');
		
		// result failed - no user found by that username
		if (!$user)
			return $this->_errorHandler( $this->whmcs, $response, 'AUTH01P010' );
		
		// If the user is set to be blocked and we can't override then fail
		if ( ( $user->block ) && (! $params->get( 'JuserPendingallow' ) ) )
			return $this->_errorHandler( $this->whmcs, $response, 'AUTH01P004' );
		
		// If the passwords don't match then fail
		if (! $this->_testJoomlaPassword($user->password, $credentials['password']))
			return $this->_errorHandler( $this->whmcs, $response, 'AUTH01P011' );
		
		// If we are actually an administrator and we have authenticated then set response
		if ($app->isAdmin()) {
			$response->email			= $user->email;
			$response->fullname			= $user->name;
			$response->status			= 1;
			$response->error_message	= '';
		}
		
		return $user;
	}
		
	
	/**
	 * Grabs the Joomla user data
	 * @access		private
	 * @version		2.4.17
	 * @param		string		- $method: username or email
	 * @param		string		- $by: indicates how we should get the user
	 * 
	 * @return		object
	 * @since		2.1.0
	 */
	private function _getJoomlaData($method, $by = 'username')
	{
		$db = & JFactory::getDBO();
		
		$query	= "SELECT a.* FROM `#__users` AS a WHERE {$by}={$db->Quote($method)}";
		$db->setQuery($query);
		return $db->loadObject();
	}
	
	
	/**
	 * Method to handle a password
	 * @access		private
	 * @version		2.4.17
	 * @param		string		- $type: the type of user we have
	 * @param		mixed		- $user: JUser object or array of WHMCS user
	 * @param		object		- $joom: the xref object pulled for the user
	 * @param		array		- $credentials: the passed credentials
	 * 
	 * @return		boolean
	 * @since		2.1.0
	 */
	private function _handlePassword($type, $user, &$joom, &$credentials)
	{
		$jcurl			= & JwhmcsCurl::getInstance();
		$params			= & JwhmcsParams::getInstance();
		$usepassword	=   $credentials['password'];
		
		switch ($type):
		case 'joomla':
			// Check first to see if the Joomla user is disabled
			if (! $params->get( 'JuserPendingallow' ) )
			{
				if ( $user->block == true ) 
				{
					$this->e	= 'AUTH01P001';
					return false;
				}
			}
			
			// Test the current password
			$testpw = $this->_testJoomlaPassword($user->password, $credentials['password']);
			
			if ($testpw)
				return true; // Password is the same so send back
			
			// Password is not the same, but the user authenticated against Whmcs, can we update Joomla password?
			if ($params->get( 'JuserAutosync' ))
			{
				if (! defined( 'JWHMCS_AUTH' ) ) define('JWHMCS_AUTH', true); // Set so we don't try to add the new user to WHMCS
				
				$ubind = array('password' => $credentials['password'], 'password2' => $credentials['password'], 'block' => false );
				
				$juser = JUser::getInstance($user->id); 
				if (! $juser->bind($ubind, 'usertype') )
				{
					$this->e	= 'AUTH01P021';
					return false;
				}
				if (! $juser->save() )
				{
					$this->e	= 'AUTH01P022';
					return false;
				}
			}
			else
			{	// Can't update Joomla password so fail
				$this->e	= 'AUTH01P000';
				return false;
			}
			break;
		case 'whmcs':
			// Test the current password 
			if ( isset( $user['password'] ) ) {
				if ( $this->_testWhmcsPassword($user['password'], $credentials['password']) )
					return true;
			}
			
			if ( $params->get( 'WuserAutosync' ) )
			{
				// If WHMCS version 4.1 or higher, return password clear text
				if (str_replace(".", "", $params->get( 'WhmcsVersion' ) ) < 410 ) {
					// We must encode the password for WHMCS < 4.1
					$jcurl->setAction('getclientpassword', array('userid' => $user['id']));
					$whmcs	= $jcurl->loadResult();
					
					// Explode password hash to get salt and resalt new password and return
					$pwexp	= explode(':', $whmcs['password']);
					$usepassword = md5($pwexp[1].$password).':'.$pwexp[1];
				}
				
				// Subaccounts
				if ($joom->type == 6) {
					$fields['set']			= "id={$user['id']};password=$usepassword";
					$action = 'jwhmcsgetcontact';
				}
				// Regular clients
				else {
					$fields['clientid']		= $user['id'];
					$fields['password2']	= $usepassword;
					$action = 'updateclient';
				}
				
				$jcurl->setAction($action, $fields);
				$whmcs	= $jcurl->loadResult();
			}
			else
			{
				$this->e	= 'AUTH02P000';
				return false;
			}
			break;
		endswitch;
		
		return true;
	}
	
	
	/**
	 * Method to drop an xref
	 * @access		private
	 * @version		2.4.17
	 * @param		integer		- $a: the Joomla id
	 * @param		integer		- $t: the xref type
	 * @param		integer		- $b: the WHMCS id
	 * 
	 * @since		2.1.0
	 */
	private function _removeXref($a, $t, $b)
	{
		$db = & JFactory::getDBO();
		
		$query = "DELETE FROM #__jwhmcs_xref WHERE xref_a={$a} AND xref_type={$t} AND xref_b={$b}";
		$db->setQuery($query);
		$db->query();
	}
	
	
	/**
	 * Method to add a user to Joomla
	 * @access		private
	 * @version		2.4.17
	 * @param		array		- $whmcs: the WHMCS authed user
	 * @param		array		- $credentials: the entered credentials
	 * @param		object		- $response: object
	 *
	 * @return		JUser object
	 * @since		2.1.0
	 */
	private function _addJoomlaUser($whmcs, $credentials, &$response)
	{
		if (! defined( 'JWHMCS_AUTH' ) ) define('JWHMCS_AUTH', true); // Set so we don't try to add the new user to WHMCS
		
		// Add user to J! database
		$acl	= &JFactory::getACL();
		$user	= JFactory::getUser(0);	
		$usersConfig	=& JComponentHelper::getParams( 'com_users' );
		
		$newUsertype = $usersConfig->get( 'new_usertype' );
		if (!$newUsertype)
			$newUsertype = ( version_compare( JVERSION, '1.6.0', 'ge' ) ? 2 : 'Registered' );
		
		// Build the user array for binding
		$ubind	= $this->_buildUserinfo( $whmcs, $credentials );
		$ubind['email']		= $whmcs['email'];
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$ubind['groups']	= array( $newUsertype );
		}
		else {
			$ubind['gid']		= $acl->get_group_id( '', $newUsertype, 'ARO' );
		}
		$ubind['password']	= $credentials['password'];
		$ubind['password2']	= $credentials['password'];
		$ubind['sendEmail']	= 0;
		$ubind['block']		= 0;
		
		// Bind the post array to the user object
		if (! $user->bind( $ubind ) )
			return $this->_errorHandler( $this->whmcs, $response, 'AUTH01P023' );
		
		$date =& JFactory::getDate();
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			$user->set('registerDate', $date->toSql());
		}
		else {
			$user->set('registerDate', $date->toMySQL());
		}
		
		// If there was an error with registration, set the message and display form
		if (! $user->save() )
			return $this->_errorHandler( $this->whmcs, $response, 'AUTH01P024' );
		
		return $user;
	}
	
	
	/**
	 * Method to add a user to WHMCS
	 * @access		private
	 * @version		2.4.17
	 * @param		JUser object	- $user: the Joomla authed user
	 * @param		array			- $credentials: the entered credentials
	 * @param		object			- $response: object
	 * 
	 * @return		WHMCS user
	 * @since		2.1.0
	 */
	private function _addWhmcsUser($user, $credentials, &$response)
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		$fields['firstname']	= $credentials['username'];
		$fields['lastname']		= '(web site user)';
		$fields['address1']		= $params->get( 'WuserDefaultaddress' );
		$fields['city']			= $params->get( 'WuserDefaultcity' );
		$fields['state']		= $params->get( 'WuserDefaultstate' );
		$fields['postcode']		= $params->get( 'WuserDefaultpostal' );
		$fields['country']		= $params->get( 'WuserDefaultcountry' );
		$fields['phonenumber']	= $params->get( 'WuserDefaultphone' );
		$fields['currency']		= '1';
		$fields['email']		= $user->email;
		$fields['password2']	= $credentials['password'];
		
		// 4a1b: Send to curl for adding user and get id back
		$jcurl->setAction('addclient', $fields);
		$whmcs	= $jcurl->loadResult();
		
		// 4a1c: Add new user to xref DB
		$query = 'INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) '
					.'VALUES ("'.$user->id.'", "1", '.$whmcs['clientid'].')';
		$db->setQuery($query);
		$db->query();
		
		return JwhmcsHelper::getWhmcsUser( $whmcs['clientid'], 'id', 'client' );
	}
	
	
	/**
	 * Method to test a Joomla password
	 * @access		private
	 * @version		2.4.17
	 * @param		string		- $encoded: contains the encoded password
	 * @param		string		- $clear: contains the entered password to test
	 * 
	 * @return		boolean
	 * @since		2.1.0
	 */
	private function _testJoomlaPassword($encoded, $clear)
	{
		$testpw = JwhmcsHelper::encodePassword( "joomla", $encoded, $clear );
		return ($testpw == $encoded ? true : false);
	}
	
	
	/**
	 * Method to test a WHMCS password
	 * @access		private
	 * @version		2.4.17
	 * @param		string		- $encoded: the encoded password from WHMCS
	 * @param		string		- $clear: the entered password to test
	 * 
	 * @return		string containing md5 password if good, true if non-md5, false on fail
	 * @since		2.1.0
	 */
	private function _testWhmcsPassword($encoded, $clear)
	{
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		if ($params->get( 'WhmcsNomd5' )) {	// We are not using MD5
			$jcurl->setAction('decryptpassword', array('password2' => $encoded));
			$whmcs	= $jcurl->loadResult();
			
			if ($whmcs['result'] == 'success') { 
				$return = ( $whmcs['password'] == $clear ? true : false );
			}
		}
		else {	// We are using MD5 here
			$testpw = JwhmcsHelper::encodePassword( "whmcs", $encoded, $clear);
			$return = ( $testpw == $encoded ? $testpw : false );
		}
		return $return;
	}
	
	
	/**
	 * Method to check for and clean up orphaned xrefs
	 * @access		private
	 * @version		2.4.17
	 * @param		array		- $xref: the xref objects pulled from the database
	 * @param		string		- $system: which type of user is this (joomla or whmcs)
	 * 
	 * @return		array of single xref or null on empty
	 * @since		1.5.1
	 */
	private function _checkOrphaned($xref, $system)
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		
		for ($i=0; $i<count($xref); $i++):
			$x = $xref[$i];
			switch($system):
			case 'joomla':	// We are testing for a set of Joomla IDs
				// Add error testing for xref'd Joomla ID
				$query = 'SELECT a.id FROM #__users as a WHERE id='.$x->joomlaid;
				$db->setQuery($query);
				$joom	= $db->loadResult();
				
				if (!$joom):
					$query = 'DELETE FROM #__jwhmcs_xref WHERE xref_a='.$x->joomlaid.' AND xref_type='.$x->type.' AND xref_b='.$x->clientid;
					$db->setQuery($query);
					$db->query();
					unset($xref[$i]);
				else:
					$ret = $xref[$i];
				endif;
				break;
			case 'whmcs':	// We are testing for a set of WHMCS IDs
				if ($x->type==4):
					// Pull the email and password from jwhmcs_user table
					$query	= 'SELECT grp.email as email FROM #__jwhmcs_group AS grp WHERE id='.$x->clientid;
					$db->setQuery($query);
					
					if ($joom = $db->loadObject()):
						$action				= 'getclientsdatabyemail';
						$fields['email']	= $joom->email;
					else:
						// WHMCS account must not exist, so break switch and reloop
						break;
					endif;
				else:
					$action				= 'getclientsdata';
					$fields['clientid']	= $x->clientid;
				endif;
				
				$jcurl->setAction($action, $fields);
				$whmcs	= $jcurl->loadResult();
				
				if ($whmcs['result']!='success'):
					$query = 'DELETE FROM #__jwhmcs_xref WHERE xref_a='.$x->joomlaid.' AND xref_type='.$x->type.' AND xref_b='.$x->clientid;
					$db->setQuery($query);
					$db->query();
					unset($xref[$i]);
				else:
					$ret = $xref[$i];
				endif;
				break;
			endswitch;
		endfor;
		
		if (count($xref)==0)
			$ret = null;
		
		return $ret;
	}
	
	
	/**
	 * Method to check for a group existance in xref table
	 * @access		private
	 * @version		2.4.17
	 * @param		integer		- $xref: the xref_type
	 * @param		array		- $credentials: the authenticated user credentials
	 * 
	 * @return		boolean
	 * @deprecated	Group management is being phased out
	 * @since		1.5.1
	 */
	private function _checkGroup(&$xref, &$credentials)
	{
		// 0:  Check type to see if we need to continue
		if (! isset( $xref->type ) || $xref->type <> 4 )
			return false;
		
		// 1:  We need this, so lets initialize variables 
		$db	= &JFactory::getDBO();
		
		// 2:  Use clientid to pull user from jwhmcs_group table to retrieve pw
		$query	= 'SELECT grp.email, grp.password FROM #__jwhmcs_group AS grp WHERE grp.id='.$xref->clientid;
		$db->setQuery($query);
		if ($res = $db->loadObject()) {
			$credentials['password']	= $res->password;
			$credentials['username']	= $res->email;
		}
		else {
			return false;
		}
		
		$whmcs = JwhmcsHelper::getWhmcsUser($res->email, 'email', 'client');
		$xref->clientid = $whmcs['id'];
		
		return true;
	}
	
	
	/**
	 * Method to determine if a whmcs user is active
	 * @access		private
	 * @version		2.4.17
	 * @param		array		- $whmcs: user data from WHMCS
	 * @param		string		- $type: the type of user (client or contact)
	 * 
	 * @return		boolean
	 * @since		2.1.2
	 */
	private function _isActive( $whmcs, $type )
	{
		switch ( $type ):
		case 'client':
			if ( isset( $whmcs['status'] ) )
			{
				$ret	= ( in_array( $whmcs['status'], array( 'Active', 'Inactive' ) ) ? true : false );
			}
			else
			{
				// Need to figure out how to test for status when it isn't being passed back by WHMCS
				$ret = true;
			}
			break;
		case 'contact':
			$ret	= ( $whmcs['subaccount'] == 1 ? true : false );
			break;
		endswitch;
		return $ret;
	}
	
	
	/**
	 * Method to build the username and name for storage
	 * @access		private
	 * @version		2.4.17
	 * @param		array		- $whmcs: user data from whmcs
	 * @param		array		- $credentials: the authenticated credentials
	 * 
	 * @return		array
	 * @since		2.0.0
	 */
	private function _buildUserinfo( $whmcs, $credentials )
	{
		$params		= & JwhmcsParams::getInstance();
		
		$data		= array();
		$user		= '';
		$firstname	= $whmcs['firstname'];
		$lastname	= $whmcs['lastname'];
		$company	= $whmcs['company'];
		
		switch ($params->get( 'JusernameStore' )):
		case '1':						// firstname.lastname
			$user = "{$firstname}.{$lastname}";
			break;
		case '2':						// lastname.firstname
			$user = "{$lastname}.{$firstname}";
			break;
		case '8':						// Request username at login
		case '3':						// random
			for ($i=0; $i<12; $i++) {
				$d = rand(1,30)%2;
				$user .= ( $d ? chr(rand(65,90)) : chr(rand(48,57)));
			}
			$user = ucfirst(strtolower($user));
			break;
		case '4':						// f.lastname
			$user = substr( $firstname, 0, 1 ).".{$lastname}";
			break;
		case '5':						// firstname.l
			$user = "{firstname}.".substr( $lastname, 0, 1 );
			break;
		case '6':						// firstname
			$user = "{$firstname}";
			break;
		case '7':						// lastname
			$user = "{$lastname}";
			break;
		endswitch;
		
		// If we aren't authenticating against WHMCS and assumign emails are Joomla usernams then we set the username to the email address
		if (! $params->get( "WuserAuthenticate" ) ) $user = $whmcs['email'];
		
		switch ($params->get( 'JuserStore' )):
		case '3':
			$name = (! empty( $company ) ? ' ('. $company .')' : '' );
		case '1':
			$name = $firstname . ' ' . $lastname . $name;
			break;
		case '4':
			$name = (! empty( $company ) ? ' (' . $company . ')' : '' );
		case '2':
			$name = $lastname . ', ' . $firstname . $name;
			break;
		endswitch;
		
		$data['name']		= $this->_decode( $name );
		$data['username']	= $this->_decode( $user, true );
		
		$db = & JFactory :: getDbo();
		$query	=   "SELECT COUNT(*) FROM #__users u WHERE u.username LIKE '{$data['username']}%'";
		$db->setQuery($query);
		$count	= $db->loadResult();
		
		if ( $count ) {
			$count	= (int) $count;
			$data['username'] .= '.' . $count++;
		}
		
		return $data;
	}
	
	
	/**
	 * Method to wrap error handling and provide debug capabilities
	 * @access		private
	 * @version		2.4.17
	 * @param		boolean		- $whmcs: indicates we are coming from WHMCS
	 * @param		object		- $response: object
	 * @param		string		- $code: if set we are sending a response code
	 * 
	 * @return		false
	 * @since		2.1.2
	 */
	private function _errorHandler( $whmcs = false, &$response, $code = null )
	{
		$params	= & JwhmcsParams::getInstance();
		$debug	=   $params->get( 'Debug' );
		
		// If we are sending a code directly here
		if ( $code !== null ) $this->e = $code;
		
		$response->status = 4;
		$response->error_message = $this->e;
		
		// Assume if it is coming from WHMCS we shouldnt raise the auth error
		if (! $whmcs ) {
			JError::raiseWarning( $this->e, JText::_( "{$this->e}" ) . ( $debug ? "  ({$this->e})" : "" ) );
		}
		// Work around to send error message back to WHMCS
		else {
			global $jwhmcs_error;
			$jwhmcs_error = new stdClass();
			$jwhmcs_error->error_message = $this->e;
		}
		
		return false;
	}
	
	
	/**
	 * Method to decode non-utf8 characters for storage in Joomla
	 * @access		private
	 * @version		2.4.17
	 * @param		string		- $source: the string to decode
	 * @param		boolean		- $strip:  indicates non-utf8 characters should be stripped
	 * 
	 * @return		string
	 * @since		2.2.0
	 */
	private function _decode($source, $strip = false )
	{
		// entity decode
		$trans_tbl = get_html_translation_table(HTML_ENTITIES);
		foreach($trans_tbl as $k => $v) {
			if ( $strip ) $ttr[$v] = "";
			else $ttr[$v] = utf8_encode($k);
		}
		$source = strtr($source, $ttr);
		// convert decimal
		$source = preg_replace('/&#(\d+);/me', ( $strip ? "" : "utf8_encode(chr(\\1))" ), $source); // decimal notation
		// convert hex
		$source = preg_replace('/&#x([a-f0-9]+);/mei', ( $strip ? "" : "utf8_encode(chr(0x\\1))" ), $source); // hex notation
		return $source;
	}
	
	
	/**
	 * onAuthenticate - Joomla 1.5 compatibility
	 * @access		public
	 * @version		2.4.17
	 * @param		array		- $credentials: contains the passed along credentials
	 * @param		array		- $options: contains passed along credentials
	 * @param		JError		- $response: response object
	 *
	 * @return		result of authentication routine
	 * @since		2.4.0
	 */
	public function onAuthenticate(  $credentials, &$options, &$response )
	{
		$result	= $this->onUserAuthenticate(  $credentials, $options, $response );
		return $result;
	}
	
	
	/**
	 * Event called when gathering update sites to check for updates
	 * @access		public
	 * @version		2.4.17
	 *
	 * @return		array
	 * @since		2.4.0
	 */
	public function getUpdateSite()
	{
		return array(
				'extensionName'				=> 'plg_jwhmcs_auth',
				'options' => array(
						'extensionTitle'	=> 'J!WHMCS Integrator Authentication Plugin',
						'storage'			=> 'database',
						'storagePath'		=> null,
						'extensionType'		=> 'plugin',
						'updateUrl'			=> 'https://www.gohigheris.com/updates/jwhmcs/plugins/auth'
				)
		);
	}
}