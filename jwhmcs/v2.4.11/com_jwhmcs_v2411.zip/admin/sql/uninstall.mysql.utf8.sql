DROP TABLE IF EXISTS `#__jwhmcs_config`;
DROP TABLE IF EXISTS `#__jwhmcs_group`;
DROP TABLE IF EXISTS `#__jwhmcs_sess`;
DROP TABLE IF EXISTS `#__jwhmcs_user`;
DROP TABLE IF EXISTS `#__jwhmcs_usersub`;
DROP TABLE IF EXISTS `#__jwhmcs_xref`;