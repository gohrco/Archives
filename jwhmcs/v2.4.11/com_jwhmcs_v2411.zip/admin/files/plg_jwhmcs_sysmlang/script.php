<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.4.11 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.4.9
 * 
 * @desc       Installation Script
 * 
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( "joomla.filesystem.file" );



/**
 * plgsystemjwhmcs_sysm installation Script
 * @version		2.4.11
 * 
 * @since		2.4.9
 * @author		Steven
 */
if (! class_exists( 'plgsystemjwhmcs_sysmlangInstallerScript' ) ) {	// Workaround for Installation purposes
class plgsystemjwhmcs_sysmlangInstallerScript
{
	/**
	 * Run at the time of upgrade only
	 * @access		public
	 * @version		2.4.11
	 * @param		JApplication object	- $parent: calls this function
	 * 
	 * @since		2.4.9
	 */
	public function install( $parent )
	{
		return;
	}
	
	
	/**
	 * Run at the time of uninstallation only
	 * @access		public
	 * @version		2.4.11
	 * @param		JApplication object	- $parent: calls this function
	 * 
	 * @since		2.4.9
	 */
	public function uninstall( $parent )
	{
		return;
	}
	
	
	/**
	 * Run at the time of upgrade only
	 * @access		public
	 * @version		2.4.11
	 * @param		JApplication object	- $parent: calls this function
	 * 
	 * @since		2.4.9
	 */
	public function update( $parent )
	{
		return;
	}
	
	
	/**
	 * Runs prior to installation, upgrade or uninstallation
	 * @access		public
	 * @version		2.4.11
	 * @param		string				- $type: the task being performed (install, upgrade etc)
	 * @param		JApplication object	- $parent: calls this function
	 * 
	 * @since		2.4.9
	 */
	public function preflight( $type, $parent )
	{
		return;
	}
	
	
	/**
	 * Runs after installation, upgrade
	 * @access		public
	 * @version		2.4.11
	 * @param		string				- $type: the task being performed (install, upgrade etc)
	 * @param		JApplication object	- $parent: calls this function
	 * 
	 * @since		2.4.9
	 */
	public function postflight( $type, $parent )
	{
		$path			=	JPATH_PLUGINS		. DIRECTORY_SEPARATOR 
						.	'system'			. DIRECTORY_SEPARATOR
						.	'jwhmcs_sysmlang'	. DIRECTORY_SEPARATOR;
		
		JFile :: move( 'jwhmcs_sysmlang_30.xml', 'jwhmcs_sysmlang.xml', $path );
		return;
	}
}
}