<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 		API Findusername File
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.6.10 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.5.0
 *
 * @desc       This is the Findusername Task for the J!WHMCS Integrator API
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Findusername Jwhmcs API Class
 * @version		2.6.10
 *
 * @since		2.5.0
 * @author		Steven
 */
class FinduserJwhmcsAPI extends JwhmcsAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		2.6.10
	 * 
	 * @since		2.5.0
	 * @see			JwhmcsAPI :: execute()
	 */
	public function execute()
	{
		$db		=	dunloader( 'database', true );
		$find	=	dunloader('input',true)->getVar('find', false );
		
		// ===================================================================
		// Select the userid based on the email
		// ===================================================================
		$query	=	$db->setQuery( "SELECT u.id FROM #__users AS u WHERE u.email = " . $db->Quote( $find ) );
		if (! ($uid = $db->loadResult() ) ) {
			$this->error( sprintf( JText :: _( 'JWHMCS_SYSM_API_EDITUSER_NOTFOUND' ), $find ) );
		}
		
		$user	=	JUser :: getInstance( $uid );
		$data	=	array(
				'name'		=> $user->get( 'name', null ),
				'username'	=> $user->get('username', null ),
				'email'		=> $find
				);
		
		$this->success( (object) $data );
	}
}