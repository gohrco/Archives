<?php

defined('_JEXEC') or die( 'Restricted access' );

/**
 * Define the JWHMCS version here
 */
if (! defined( 'DUN_MOD_JWHMCS' ) ) define( 'DUN_MOD_JWHMCS', "2.5.9" );
if (! defined( 'DUN_MOD_JWHMCS_SYSM' ) ) define( 'DUN_MOD_JWHMCS_SYSM', "2.5.9" );


class Jwhmcs_sysmDunModule extends DunModule
{
	public function initialise()
	{
		
	}
}