<?php //0094b
/**
 * ---------------------------------------------------------------------
 * J!WHMCS Integrator v2.5.13
 * ---------------------------------------------------------------------
 * @copyWrite@
 * 2014 May 27
 * version 2.5.13
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.    Go Higher Information Services, LLC  may  terminate  this
 * license if you don't comply with any of the terms and  conditions set
 * forth in our  commercial  end user license agreement(EULA).   In such
 * event,  licensee  agrees  to  return license or destroy all copies of
 * software upon termination of the license.
 *
 * For the full End User License Agreement, please visit our web site at
 * https://www.gohigheris.com/policies/commercial-eula
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPu4/BSHFk9Nh0kQuvv/31IcVx4GPUn5VA/KVW7xyqBcDojMUlmX9DdeVkvBnAWl6PJYfDpOv
N/D06RwCrOKk1rQ4IhFVT/tWjf4hZeKB05GWvvQZBKpYin++Aoszkhe1e1R4QsNADswxzIHXVz8e
KidNZmmFUkCVOxmaQq78/kXT6dwqCx0qTOIbqOEAWly7Ri/Nwd8Q+FI9Lx6LIJw/FbvdfWx1GjYL
VthCaZvdhn+bmvk9pVhfgNQlVlyY6/KV5i1E4Naz2s/QOXjXxkV/+RnNf5c4clUzSlyZHJEvxKG3
Wq4lsBEOJRVsr9l2GL03EfjXkPGqZqIHfgSt8Tv1xBnfHETLrvkw4YiB/tBnNGE9qKY9gZq3Mm4i
+DD7x1+kP/kdj0yF9ys/6+5gThKGjoQK8iGYlAdgXUaea9uYhJ8O/788r1iT4vpAtBUlV1mQ5nG/
0kByc/56OhVoJ0NikddWA9ZZKDWkgAoRO7Ljf7K82FPHXwjDZ2KA/Sf5G5ZaytmZjzq4noQWkKIi
iNmDkcKiSqVJex0RMS+K0ClAIfxjICtubcMEVncIFWPt94fiR4NMty7iJmGXFiNlDnT38OPxm3kx
DZMMCLt83Zb/1dsmjPsCnYQzNj5U/w25r/hl8JuwgJTHRELTo7ePcBikaQfnAJH0FHCWDxqgOcVc
kt5LMKc2JrP3G3KidE9jxlIUaudSq4IgrSaiXMc9Ku5lJ2Li826t5rWrne8RmFJb2C4F4rF0y7kT
1Dq3BCv9YWjy619ME3wGLgC+jSng0aHktpYVQ2uMuPNCoIMI+N3q3sBinckX7RHxl8U6MTbuDztW
cfsR/xVgAqBe5M1oj+qLTU+uXzuCjpvh9yWRd1G2OPPBp9mtSTL+tw/LoDOpl3cYqEyQrDHzI0aM
vF/GYYBxI5RuNgoC6k42JJHHvue7Zzp/jTFZiI7C6D8jAqXj9tIKg1a5+lCTOyF/dJJW1oaimn+B
4n49zm7b+VFcZrmwdO/3mqouw9bwHpAfTYsDv3fxYEFA9HWmeeD9qgB7IHabvWBoQdZq72+irDzP
sq2Bp8sAhUlN9bFXXmUT6D7PEMd5pHyTLOGl9hYWOvx4c9iCcD3pYSBjljdBlhAhzueLRSYyZdl2
9yTAHTmBWUwzqT+7T+A7/fVem6N0mYFyJ78QpU6CGhNzxmvaizsyIFv8xXqgQDplPgmv7LcgOH2r
tynKbXgXpF9MNwanrAuQ44mYhnsIY7FhLCOzGWZrTbcBwhatcxAExmlahabEnEIKTNCUVscMC+Au
UUGVd5yOO1OEigcegnZCMzWC5yawpPtEVlyeY7GjyYGPWitbDW+FKvBjKgdMqq6f0kxzfe5aG98M
pX5SuSa4ZE4QjN2jvuAArofWzSinic2OWcFeqQRWFvTIZHShzvmVfyTSX6rw8FSbECkXwjzM2hE5
D/hiLdM6yX4izd+2WH+jWDxD0+6yrvhymp/tk1wzl8Gq8aqenoJpeW7iLakAedf+9IDHgO0Of+9E
MQHfCl/4RTp0QGtQbQNq8B5BljNw2W3NbtWfiUijq33PuNaebLaddWa5E9uFiJkiveX6I7uBUNMM
7tqHVW+uQj3fNZsDYUb4vOjWDqhIQtDHuVVAYTOdBPwNPzsKQbaYkGy8ip+13hYvgYSKtGvS7X6w
PBoKOhlxD/EzhC5t/bbgpI67dcBNJtVWKaBtB9pu4XPKmEfXFXYmYN6hBR0AloUWQSDvRwukajON
oTS4178fxWfrXmfp32LVX+WmtD5kNC7izODByoFo3rn+OSB+HkvMK4TCW58I6r0YqlAl8trwN1fm
3URUi43SGt9dMfUyRxgSA8qFaBE2Db31LIpvkICQbpEjaaDNeEO02ZgWd37TK0XuTH8uylo8PoV4
YdOxitIa5x8/Nk6WoUkklacrscoC7w/JUNgyCsVgG+o0jHCkWJMg5MMc6Q5c/7TQ0vo7CWM1eAND
jhRxg79GWSd6Scr0kNFJ8cVAY3BRa0iefPOjat/gW59+jeJ7X+s0fNRcG6edcDvyS/uE1hQC1J5A
vhdcNrl8ZeERFeahbv7IVvd6pg/rxmhS3NMuVXT49ZFUXpc/dLwwkntO7XnuqfxGribRRnVSbVeW
II8lQE95RjPHyAdcQ6Gc5qo6t9i8oBj62JNgD/FG65Y5xyIdfZYpyqM56YpOajnnW7AjIvpY8oS9
uQVJZScHE1+4RMSqxhkUwML3+Pfyyhm1mWqDMFldX/7j5QHNBFCuJaTizpgQClTvTMG9JwZcdlwJ
ER98DiFEwpSJZTWnt4qrIgCuyXaZXBvXtV2k4/P43PSMUQCFB8H6YJcIYR8qNCdtzVn5duFSme+P
l9zLUBjE4iQlC9k0rtUrs5HC/F22PidtvfwNZOxVihMfYRlTTUgPgkooyVjZAmOmplhA8hpPgidk
y1Ww7MamsBWPJ6/S5M2SCcURxblAQ/Ei60tY0CQU4qCLBWjNuaOUDHJu2whsKdSZ0W9szI+9ulCh
bp5oEL74ICDjH1cJCaPUKQCHYXoftntoyBK2wfrrDAkD3EGkVmWaQmdGIZtaBsjMFgCmANwZuvHF
WHNdjnbS9uZQeb+tdh5/ulg/kgh3gMZfTWh88hV4LyBEuB6I61quclCZpRMiTv+ryuwhqlgJjTNJ
4P7+XDIDpAfqgFV5gsKshzyzUs9TjWXxFhLDPr+9UUl13Ny3P6T0/yOzi3y/vwCu8nbatewtmrd/
wrF6LXTD/vXeGZtu+OTuuJNgl7zFGskfSFerlWpT6/qSLTFQdqrHJeKOjWobGucyfBj7J6cW+zSh
3kDZNgJnGpaUdSRo5Mg9X8+6QPGglBl+vJviobsthfOoC8Pj8WQn5fSaF+NgJUeE7qt0+UM7lsv8
dx4K5/o8s/cxxRmpr63/GAulrFouZGTqeYek13enbYcX3EQnVJw8+VXsfzHYuTUs/irkAJ48ozuY
1p/m6tNniD7KGu+aRklmShccfuT0T9CXwlPCgRzWEmjRP23wz5Kgv0Qs0RwpA/YN4YIJrgFR/TB4
ZwivbklJKKgC4phV39pTK6I0UZcrfr5lgT7qeGh9Ssl9Igx+TB+jr7Aclxr6QROZV/Z9dhtsdM5l
oIQ8R7ipDiVbthZVui5SH2QgCkX1BbUZVtVUzSlm0R/UU1tClavfWvkykXT1Sb6rVdmvMwikHBfc
B/rKzXCGBzQLvhuZqD/N7fqRvqN2Je0DFh3TCOYTRxAj1RIbbprtu/RW8i33UapzpcCHidJlospZ
s/AjUQVehDL4BkaZRXfstg0z3SlbWEOHPQDgikJSPtoSqQ4AR+49U+QOoueGWKKXUVbU3s7QKDe3
8ucU2z+UE9gC61+dtVipFmCJjRb1pBfQl13Ah7lBn6xbbqvaNHM8Sr1NQPbnEugyvtumIzQqE9Y7
YauIHADvf1SEI9mrqQDau6gyVhJJpBOCXo+W2wpsiP1ja155bJF730hJ+86SoyQL0jqt6CwqvRsD
w5ZQ+4EhBaiDJ8UfN/U+AggcHm0I4s+I2oeoOUwpyQ8zhjb9jn4dsb6yas1QJLGYFMDpxqMA42Hs
EEkF0CXhrGUQgZsJoD6QvwZ0r8Cd+2uZFVI9+bLblgjxm4Uq0rjYEY9Fymkzp3lKUzgWlMF6n2ha
3LlMPrJn2JVnMg7bbU4p6etNvkYpJaER7/zeTDTl+/vIITEvAZKGxqG3lRYdqlTVCqiDk/2Hoj2X
0eRzcQ4g/mbNeRTYG7UlgOCPcd+2aNOcxF4LnX6Wx0v5X+Q1tQAXbIhidc9tZgboPtZE/nKmiKSd
Ar/6Zdyl9KSp+S4I4KO2GBYDCAuDaX0aXoaz9T38B6TYGpOeHuFFjLQOspbvr/ykuW/gLx+oQutY
ndxzTlp+TGPe+HRQc2RHbTLD/9R1QGDqzNyfjC/vPPh65vHBGGGwl4nUmTTWMVjzUkf5FiQTu25s
1z2PCaHaKs/nIJyaxTo68XVfM2jAdmxrhoPbRF9Rw5HrcAkHM0Bx2okk+CWBfcQjvbVYTzzuAumw
oC81bbx/FQHm3f7Q81qq+6ENciJrlWr4ePzA9lZoMpY1fDiKLTDHWCwf7KIW9IGIHHp/0Rj2PVh7
1gXJMqZNJ+PXLaYWP7DzkjVHcqdte0cyQviO+/40lHoQ5KIX46xWNq3H3C2AbZ6WQWbn911uejUK
OVHfTjVtWRPnUqSlgm8Faj1n+jWd8Z16Perluj7Dic3N8hvNqNtDN87YEPh9RHcV6MESzLZMnmxH
/3Psy4/UzXdOcHFfC/3x+6t7yT7CowTpBjAlA8lR5w5chxKWnxVFtU9oT3yHeY4/xdhDQNZ1OQ+X
aAp+XHAoee+LCXpUuOPFXGZ19kUToZBfO5b3z+sYKlPopGbGbT1xkor2GhlrVmAi2dBvi2ccNxaq
U8ODKokLVW2gBprs3tEe/3xZhUc3E9zT1OouJnYQoOL2/i7wWUL0pjsWn/QTdpWBqSBtVP4n7ZwN
Unrv+VfFJfCrRc/f3jhWNhZeBY8vMTmgBouZ+trtgrCWcgbMrulkojznpW+2C89Zve5rY0FhoACw
fJEwzRYx0kBCPlKSeVh75N/fphCIy54QrJCrGbBJwunV36vPlMFq+oEoQyfq4gxIKvb4KwyK8RAE
iUUFzLueowwiwSsOd4vJ7lE1X+DvhLVzOSjv8naBdxjkAkK9XjaenKfQhidohFGB1LSUFwiPJs/T
btMs6Rq4l+99ToYDwQM9EUQTvkWuGjcZxu14yO0IYPwo608SrGZVsFYEIs4BbtgbJkZe3YqivEH/
5r4x/FL0bWeAfb/mKnNX9D+Uj6D72ZMvdxK4c+aTFRmkVS4T7SZUP72qa4F4sCXNe0OaRVkOoN8b
tieboK7PT2xbCf44ZTNhRzRv8jFo/5nEmMtTD3QpBhz4tmm6dLdI99c2sICfrZyMX7ra4iNvPevj
N5cvbmMJyMgvGJv9iw7mo2+Q5JYcuBVon2SQQeUF7JSV/mmd7DWsmKRsYt83I+AagwvlRfMGcddR
+TD5Xc/L6ITibHgOXEGAIyVZp5X+wj9Fccwht92syzfYc5WbGxMHfdhHDyFm4bxikRTuv2CYehqp
hRMGAWV+TKc87zwHcE31qSGDLTq6gfeWHtkEbdO2C+d31dXsMwnAHZBNGPL+V2eAVJqa1H0aXwA1
xJNP9/t7BmGYOoOQoswjELI1aHe6dBHV0U/v/RY4ME4hei51IYUoRAkbNSvBSsaZjhLsD2amYP9e
SnkTup4qBloUGPmvUJ5y6pUg/Q1NNtSR4tAquGTohzundKH+B3IR8PYpRuYve2wap2hifq3Ifo/C
cf1dAZXsciUPJxrG0A+fEOIyejNcaZZ+G4Z296vxshaDMnrz9fc2zlBkHWnCWUJyQQZgvQ+3EvB/
0b7CyrTWojeURvVLhpIR16RMkgFX9I/Aoea539Vto0cqA/f8wXcwKEcr3a7jBYd9HDVrYZatHmB2
nVWxqH38b87pA/zozs9pGVQqlVvzpXTYFw8KWvBUZ4oJcqGj+gxhMJAWH0tKIk33/ZHJkwFz0JXT
5LbgZ/uaY6hUcBiIUpiAWBlsA6z76IeYOX+BeARfTDMe7jirsZVy1OMlQlKRMz7Ugml/hOJhSkq/
nT55jc2G76EWUbQ+xnrZSM/+/gK8AAfkW6LiyKbAFu+oHszUkVRpf9FoYavwdL7z6bxNrw/36AzK
aP+y7C6ntY1WGgyll9/eOIQYBbGB3yfcqbuk2YHZ9Y7Yzp60L4zr/2FTvwGa8kwHjnK6nFLzXZbE
/F1U9Z+NqSfOUzedl7GmIl7kXOfEeKWC3hAih5INkNvwOHqtZhjV6MM+w/3t/7UCHDJpy/2bX5FS
rtaIWKFF5zsVWsBbiIpPDeq5GcZ2teDL9TBMKCNeE9Mrd+fLfsF/4Ph4Duh9cm05Gm0fbtgyoaE2
wxGl2fzL1NlHwFjskUmUoiRQpaX2FzDbhk6PMXfrXE56x/anLJzlE+iPeBb//2YVQcfNGpRNLPjT
BHcKKTsJ6c0MBwS6/CkHDNvQ6jT9dHcgfyS0T3SgSHtly7vv65NfYcwjTDhzOqVGi8PL6PJKD/xh
TpE9mvRGTBB1sacrGZgOpvW2yMvUZwpXCGvCVPw6zSdr0MYV13DvFTpiDzwUwdBDxqNfOBmE//Ft
Vgn9Zg8Yw4iqZGaKBal/4R0Nj5i87tMTndzJK9iPDjPOTpDc7pE8O5+pQKCfmYy5N5NVcIJNfmXr
bb0NUHAHj3U4SPLBTyTTXBAR5pQA+XETnoiKETU2y88bmWEynxLz5q0GkKDGT+0gqC1wMiUMgQ+V
9PdLH5ZEyrK4Z421BbjdnGpwtNf/WTuHESNWlwffkAvTlU64gsiTT9yVWLoWnz/NljQpRTc9eDm0
bECuelDaT32Wajc2vn7xVmcXJEKAWYtZe+rS0jlrnIyvcRpPaGfdIhIYkwHa0SU7OmWZaS/Fog33
K3gFyEtcU8UhVY+1vu5/bFMCH79GUmv61GVuQlwDp5tov8zVJ1SXDyRZFKURS+KSl/grX0bg2eJx
hfEiqaK8VO4ETfInKUe+7V+cNMA/jrmSuDjiO/bfoWvAYmlhb9oSc8bt6LxirFC5U+zRlG+iZkjr
7vsmSBSBHy6wNl1P7diBETcw/bdSWrbR8vDJpVaQ7INpVbv/5rvzctYC3HrA8fQWTMRckQqU72Ww
kRrH2/cAiuBDwsZkSHYM2liz65towPhUJ1t2NXfXTyJpuO69wOgHKwt+H3kqEy39tD3wERU2X1Xh
m3l3ZCJS9DSANjZa10gfHO+5DnABmDoSlyMRDEJCLV4SZePphCyWuYhGH5rvTu067JwXlsxXfgKz
meCg0EqHUZlMOHQpRzkNolLcGEnbng3YfQykq6kHMtAp7mhAXtwRxHbxl4k0bkIuskSNyoGP8N36
HmZ+VWX6drA5K6NB2fmWa63bTDj4qsbUBdA6BWw9UeSU0mDll3GMVeokXLRGjIr3w0uHVQy+aztv
tCxbaquwNtRFeJLJkNmVJeeW16c2vdpXpUk+TSG1lJ4Yn1a5W45gRZsO3eCviKRu6gqBm5f+Zx2x
Aj1ArggQN9x9+fzrWFBEJMudbAutS8655HWAWumXUt2rJXxF51ii+tti+V+cEpi//2cqlA+EbZyp
YMAMHKqMU6+XHKvOMmKz0uSIeGcXnh8/7NGXP1b6h4JGQ05G7Um0gNZ5Apk8cQogMfOTdpr3YMpR
bhYElDDux333RJ0rY1HbFboAFI1yt6Ovonk06Pt0kUnd/i7t3Z7XwBjH2r3bXszWo0OTD/3Liw+u
gJHm+/lHUIuE36Q0k+Mr1rF/fyhZHLJzJ/e3vAsJXbcx1+Qap6LFo8fsV7/hWpvIB005hYY5Ia89
ZjDQUb0CGiNjz0WMV8X+BmgOXYPQWwHcTIoKBwncS2NPBlIsKPeTv40o2eQ67rDDPPPFEaIg9hhs
PcKCgpcUQOwWcEuUGsZlg4I+UkxCGUW0EzGcLMg1pQHuRgcFudbz6sXlpg56/4xnOag/5MrBrNZT
Xft59Eah2LTbtGEX27WdYwuRSptW4Wv16NArZrt/V/HR0tuu9e7je+IobJf2AVSIh7EVGcc4HLDV
K0QujhDuijdq+uSwqo6BpzCWArdvtvjFf0wazzf5+xxXcqyDYqU+slKGd3BSq6/4fARS5i/5iHA6
yJxlXyrIbm0bTiH/9tzX+GVwsypJCTxuyCpw+F1pqBapJJsy76QFQL5jLyyAe97/kU/yYyJ6dd3r
5q2kyI0RWAuzRmKx9GP+0Yxm51l7MFnfmQYcRJdNlCV51lGl6zjnobRGGBgVfs2JKt7j9pDdtoW3
0BDHutMjzsmd1cHXWcBcFhDsHoS1JwPMJRqABvMJYI8R0l5KwiX8we7VKBwJ9wWHWHnKfp5YL4Ip
HlykLTw+iUYR8GO0HHG5qDNtk9LQJDMKdJJgf9Kxw5ngIOcwwFGkji7hvh9BA3lYkxI9weipJVLQ
qvkvdTNhj00mqyQQzRQiRqdsIbA1dQVrAfsGzgYdIVcOiwju7jhLH2BlJkDHzasC0o1nnm1gZi+t
VPGbcJuL8hjXlHT6EAZ+Tp3vr5xef/4M/H57a3XzcTQicsz2CPL+BrRpcVaSKRD5QYKCI2Kca1Eb
NwThvbu025XeOqd5TvsR8BqoehWgmdH+JdaiiA0E07cJSIHEyIXNmPhTUe8jnSK68O6OZAhm9nSL
diUXLzBAKYLcejLRBvYWHdMhjS9aUvlJhtr4GQLx/y93DqpS/a8HZQLQsmRsim02q6h1iik3pd9R
CV1sM/dEWqtHkCJaq/xLrZJSTgopttx/aqGI5ziUt0it5Qsravi5L/fqu8qByl6jTLOg7Whhp5Nc
hVcNeLKuezNl0NRygLUZhpCG3oe002JDK/bLcxYbil6nUfdEVnmAIwElHF5Sp38wgRSxycdBc7cI
mllsCMAmw+4Wa2WdPpw4RB3CZJOQk3cPeqsvW4wQnDeep5LfKSUyQOEqnQBB2MtRMWnf6STsKz9c
Bd0s8z4N/4sWEcksWSOpZqKB/0SJTrNjgtssiQqdmmjhQC7rLlvzLQx5Vuzy1FYxaOblNlxCTzSY
lJypJFiSRs6m8WHJ8F2B50KG93SHHeuNY8IJql5JYuoYALPXP5Si9X0T+ii/bfqZ2+8eVaR+d/SL
DO3Jmnu18b0Rz+wrUhwnqhFNHyEN6bpfd0h1RQ5bsvfYrA6jqCoK+/I+dhJWDAmZDdqxW6DnbKy3
6LLUdYdtAvV8MCym5IqKth1nyKy6rYUsD223T4zxfaZBraAUnuZUrt1yLOOkrQbKoPcIj84Sv7VO
UV33I6lBFMGqrNbwlkQNwi93mys3htFYGrsaEp+/eHPpgSYsvTsaRM8uN7QQ0xxzRAvlUvxUNI4e
dzkIhWhdBcov9QI1IIU59pJcqxgNfD7SfsV5vg2ABic5NrvX30Jo2r5oJGuSGn0rrDLp1Xir+W4c
Kbvc97KjkmU1FYRy3RhRyIKD21zzc35cxvLEav7sfhJpzyTUPdovRjhqmrzALvZjljPiwwH1k3DL
QEq0CSAdUpEBHsQ7N+Ggi97JReoedcUmH+2PNRiRJR/AebfbvZTM9dH5f0Wg4dVYvfCXzj7gLYz1
f9WsNMfZ5/KHd5QeYLyDzPprLIon99LIGuGwidwLB2t3mhwddDK70bjX840626RXdBTJMkK6I/+w
pU49caw9uRJGnY8Diw02LbFJH1GSTqsSFeKKJvG88Y11XfaK9SrWJ5SStwpHnmP3Q1xN2BZPLh4+
NMHeFXeLWIb44yyG7nkmL2mzfg9ytVh54d4We2+5ijvj+DXUmWXXMQiX0LHtZ44AQCWu8APw8Gx0
Wtz/wPeNkK2rjJIEn31yZVWZd/EZy0IzCpkun0lXXRGtw315f9g56ky2Yh32jx8mQjOb0oMMZu7f
ni1nza0Iykst20PdEB2O4O/Ck41p66laKeEjnHEDDYtmSBnkYinCioNdynAXYZVBbjoWTuqLoFh0
oXpbSewpRQA/Mb70XpcTyHC1igsifRQJ