J!WHMCS Integrator
------------------------------------------------------------------------

 Release Version: 2.5.13
    Release Date: 2014 May 27

 PLEASE READ ALL THE ENCLOSED INSTRUCTIONS

        Forums: https://www.gohigheris.com/forum/
       Support: https://support.gohigheris.com
 Documentation: https://support.gohigheris.com/docs/
   Client Area: https://client.gohigheris.com


[ CONTENTS ] 
------------------------------------------------------------------------

1. Server Requirements
2. Version 2.5.13 Release Notes
3. New Installation Instructions
4. Upgrade Instructions


[ SERVER REQUIREMENTS ]
------------------------------------------------------------------------

1. Joomla! 2.5 / 3.x
2. WHMComplete Solution (WHMCS) version 5.2 or above
3. PHP Version 5.3 or later
4. MySQL Version 5 or later
5. Curl Support (with SSL)
6. Ioncube Loaders Support (required for WHMCS portion of installation)


[ RELEASE NOTES ]
------------------------------------------------------------------------

To review the details and notes for the Version 2.5.13 release, please see:

https://support.gohigheris.com/docs/display/J25/J!WHMCS+2.5+Home


[ NEW INSTALLATION INSTRUCTIONS ]
------------------------------------------------------------------------

For instructions on performing a new installation of J!WHMCSIntegrator, please see:

https://support.gohigheris.com/docs/display/J25/Installation+and+Upgrade+Guide

[ UPGRADE INSTRUCTIONS ]
------------------------------------------------------------------------

The recommended steps for upgrading from an earlier version of J!WHMCS
Integrator to this latest release can be found at:

https://support.gohigheris.com/docs/display/J25/Installation+and+Upgrade+Guide
