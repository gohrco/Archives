<?php
/**
 * @package		J!WHMCS Integrator:  Login Module
 * @copyright	Copyright (C) 2010 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id: mod_jwhmcslogin.php 555 2012-09-06 02:10:32Z steven_gohigher $
 * @since		2.0.0
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.helper' );

// Include the syndicate functions only once
require_once( dirname(__FILE__).DS.'helper.php' );

// Grab JWHMCS helper
$path	= JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_jwhmcs' . DS . 'jwhmcs.helper.php';

// Bail if we dont have JWHMCS installed for some reason
if (! is_readable( $path ) )
	return;

// Require the helper file
require_once( $path );


/* Status Possiblities:
 * 		False = not logged in at all
 * 		True  = Logged into Joomla, no WHMCS id
 * 		(int) = WHMCS ID to retrieve data with
 */
$status		= & modJwhmcsloginHelper::isLoggedin( $params );
$contact	=   modJwhmcsloginHelper::isContact( $status );
$cparams	= & JwhmcsParams::getInstance();
$user		= & JFactory::getUser();

JHTML::stylesheet( 'mod_jwhmcslogin.css', modJwhmcsloginHelper::getStylesheet() );

if (( $status === false ) || ( $status === true ))
{
	$jwhmcs		= modJwhmcsloginHelper :: getCommon( $params, $cparams, $status, false );
	$jlinks		= modJwhmcsloginHelper :: getLinks();
	require(JModuleHelper::getLayoutPath('mod_jwhmcslogin', 'form'));
}
else
{
	$jwhmcs		= modJwhmcsloginHelper::getData( $params, $cparams, $status, $contact );
	
	// If we are using the Gravatar badge
	if ( $params->get( 'enable_gravatar', false ) ) {
		require ( JModuleHelper::getLayoutPath( 'mod_jwhmcslogin', 'badge' ) );
	}
	// Or else...
	else {
		require(JModuleHelper::getLayoutPath('mod_jwhmcslogin', 'info'));
	}
}
?>
