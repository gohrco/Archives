<?php
/**
 * Group Management Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: install.php 667 2013-04-22 16:26:28Z steven_gohigher $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model
jimport( 'joomla.installer.installer' );
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');

include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelInstall
 * Extends:		JwhmcsModel
 * Purpose:		Used to install the J!WHMCS Integrator
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsModelInstall extends JwhmcsModel
{
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
	}
	
	
	public function installed()
	{
		return array();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		license
	 * Purpose:		Returns the license key - needed?
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function license()
	{
		$data	=	new stdClass();
		$params = & JwhmcsParams::getInstance();
		$data->license = $params->get( 'LicenseKey' );
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		license
	 * Purpose:		Returns the license key - needed?
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function licenseReload()
	{
		$params = & JwhmcsParams::getInstance();
		$data->license = $params->set( 'License', '', 'global', true );
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		apiconxn
	 * Purpose:		Returns the api credentials - needed?
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function apiconxn()
	{
		$data	=	new stdClass();
		$params = & JwhmcsParams::getInstance();
		$data->jwhmcsurl	 = $params->get( 'ApiUrl' );
		$data->jwhmcsadminus = $params->get( 'ApiUsername' );
		$data->jwhmcsadminpw = $params->get( 'ApiPassword' );
		$data->accesskey	 = $params->get( 'ApiAccesskey' );
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		removeFiles
	 * Purpose:		remove installation files - needed?
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function removeFiles()
	{
		// We know that the files have been installed, we don't need the directory any longer
		return JFolder::delete(JPATH_COMPONENT_ADMINISTRATOR.DS.'files');
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		interview
	 * Purpose:		retrieves data for the interview process
	 * As of:		version 2.0.2
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 *  	* Modified parameters to reflect database change
	\* ------------------------------------------------------------ */
	function interview()
	{
		$params			= & JwhmcsParams::getInstance();
		$uri			=   JURI::getInstance();
		$date			= & JFactory::getDate();
		$paramupgrade	=   false;
		
		$data	= new stdClass();
		
		if ($params->get( 'ApiUrl' )) {
			$data->whmcsurl = ($params->get( 'ApiUrl' ));
			$install = $this->checkInstall();
			
			if ($install['whmcsdir']) {
				$data->path	= $install['whmcsdir'];
			}
			else {
				$data->path = JPATH_ROOT;
			}
		}
		else {
			$data->path = JPATH_ROOT;
		}
		
		$data->path				= ($params->get( 'FilePath' ) 		? $params->get( 'FilePath' )		: JPATH_ROOT );
		$data->license			= ($params->get( 'LicenseKey' )		? $params->get( 'LicenseKey' )		: '' );
		$data->whmcsurl			= ($params->get( 'ApiUrl' )			? $params->get( 'ApiUrl' )			: '' );
		$data->jwhmcsadminus	= ($params->get( 'ApiUsername' )	? $params->get( 'ApiUsername' )		: '' );
		$data->jwhmcsadminpw	= ($params->get( 'ApiPassword' )	? $params->get( 'ApiPassword' )		: '' );
		$data->accesskey		= ($params->get( 'ApiAccesskey' )	? $params->get( 'ApiAccesskey' )	: '' );
		$data->ftphostname		= ($params->get( 'FtpHostname' )	? $params->get( 'FtpHostname' )		: 'hostname' );
		$data->ftpport			= ($params->get( 'FtpPort' )		? $params->get( 'FtpPort' )			: '21' );
		$data->ftpusername		= ($params->get( 'FtpUsername' )	? $params->get( 'FtpUsername' )		: 'username' );
		$data->ftppassword		= ($params->get( 'FtpPassword' )	? $params->get( 'FtpPassword' )		: 'password' );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			$data->startdate	= $date->format( '%Y-%m-%d %H:%M:%S' );
		}
		else {
			$data->startdate	= $date->toFormat();
		}
		
		$data->thisUrl = $uri->current();
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		complete
	 * Purpose:		retrieves data for completing the interview process
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	function complete()
	{
		$date		= & JFactory::getDate();
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			$date	= $date->format( '%Y-%m-%d %H:%M:%S' );
		}
		else {
			$date	= $date->toFormat();
		}
		
		$installLog = JRequest::getVar( 'installLog' );
		
		
		$array		= explode("\n", $installLog);
		$array[]	= "-----------------------------------------------------------------";
		$array[]	= "           Completed ".$date;
		$array[]	= "Installation Started ".JRequest::getVar( 'starttime' );
		
		$array		= array_reverse($array);
		
		foreach ($array as $ar) {
			if (strlen($ar) < 10)
				$install[] = ' - - - - - - -';
			else
				$install[] = $ar;
		}
		$array[]	= "-----------------------------------------------------------------";
		$installLog = "\n".implode("\n", $install)."\n\n\n";
		
		if (JFile::exists(JPATH_COMPONENT_ADMINISTRATOR.DS.'log.txt')) {
			$buffer = JFile::read(JPATH_COMPONENT_ADMINISTRATOR.DS.'log.txt');
			$installLog .= $buffer;
		}
		
		JFile::write(JPATH_COMPONENT_ADMINISTRATOR.DS.'log.txt', $installLog);
		
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		manual
	 * Purpose:		retrieves data for completing the manual process
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function manual()
	{
		return true;
	}
}