<?php defined('_JEXEC') or die('Restricted access');

$lang	= &JFactory::getLanguage();

$tmp	= explode('-', $this->data->get( 'LicenseKey' ));
$lictype	= $tmp[0];
$mediapath	= JURI::root()."media/com_jwhmcs/icons/";

$reset		= 4;
$cnt		= 0;
?>

<div class="row-fluid">
	<div class="span1"> </div>
	<div class="span6">
		<div class="row-fluid">
			<div class="span12 cpanel">
				<?php foreach ( $this->icondefs as $icon ) :
				$cnt++;
				$link	= JRoute::_('index.php?option=' . JwhmcsHelper :: getCmd( 'option', 'com_jwhmcs' ) . ( is_null( $icon['controller']) ? '' : '&amp;controller='.$icon['controller']) . (is_null($icon['task']) ? '' : '&amp;task='.$icon['task']) . ( is_null($icon['view']) ? '' : '&amp;view='.$icon['view'] ));
				$imgsrc	= $mediapath . $icon['icon'];
				?>
				<a href="<?php echo $link; ?>" class="btn span1" id="<?php echo $icon['id']; ?>_link">
					<img src="<?php echo $imgsrc; ?>" border="0" alt="<?php echo $icon['label']; ?>" id="<?php echo $icon['id']; ?>_img" />
					<span id="<?php echo $icon['id']; ?>_title" class="linktitle"><?php echo $icon['label']; ?></span>
				</a>
				<?php 
				if ( $cnt == $reset ) : ?>
				</div></div>
				<div class="row-fluid"><div class="span12 cpanel">
				<?php $cnt = 0; ?>
				<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<div class="span5">
		
		<div class="row-fluid">
			<div class="span12">
				<h1><?php echo JText::_("COM_JWHMCS"); ?> <small><?php echo JText::sprintf("COM_JWHMCS_DEFAULT_VIEW_TEXT_VERSION", JWHMCS_VERS ); ?></small></h1>
				<p>&nbsp;</p>
				<div class="form-horizontal">
					<div class="control-group">
						<label class="control-label"><?php echo JText::_("COM_JWHMCS_DEFAULT_VIEW_TEXT_LICENSEDTO"); ?></label>
						<div class="controls" style="font-weight: bold; ">
							<?php echo $this->lic['registeredname']; ?>
							<?php echo ( isset($this->lic['companyname']) ? '<br />' . $this->lic['companyname'] : '' ); ?>
							<?php echo ( isset($this->lic['email']) ? '<br />' . $this->lic['email'] : '' ); ?>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label"><?php echo JText::_("COM_JWHMCS_DEFAULT_VIEW_TEXT_REGISTEREDON"); ?></label>
						<div class="controls" style="font-weight: bold; ">
							<?php echo JText::_("COM_JWHMCS_DEFAULT_VIEW_TEXT_LICENSEDETAILS"); ?>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label"><?php echo JText::_("COM_JWHMCS_DEFAULT_VIEW_TEXT_LICENSEDETAILS"); ?></label>
						<div class="controls" style="font-weight: bold; ">
							<?php echo $this->data->get( 'LicenseKey' ); ?><br />
							<span style="text-align: left; color: <?php echo ($this->lic['valid'] ? '#008800' : '#FF0000'); ?>;"><?php echo JText::sprintf( "", ( $this->lic['branded'] ? "B" : "Unb" ), $lictype ); ?></span>
							<?php if ($this->lic['branded']): ?><a href="https://www.gohigheris.com" target="blank"><?php echo JText::_("COM_JWHMCS_DEFAULT_VIEW_TEXT_BRANDINGREMOVAL"); ?></a><?php endif; ?>
							<?php if ( isset( $this->lic['kayako'] ) ) : ?><?php if ($this->lic['kayako']): ?><?php echo JText::_("COM_JWHMCS_DEFAULT_VIEW_TEXT_KAYAKOINCLUDED"); ?><?php endif; ?><?php endif; ?>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label"><?php echo JText::_("COM_JWHMCS_DEFAULT_VIEW_TEXT_LASTSYNCEDON"); ?></label>
						<div class="controls" style="font-weight: bold; ">
							<?php echo ($this->data->get( 'LastSync' ) ? date("F j, Y h:i:s a", $this->data->get( 'LastSync' ) ) : 'Not yet synced' ); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<form action="index.php" method="post" name="adminForm">
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="controller" value="default" />
<input type="hidden" name="task" value="" />
</form>

<script type="text/javascript">
	jQuery.ready( checkForUpdates() );
</script>