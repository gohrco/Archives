<?php
/**
 * Default View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: view.html.php 555 2012-09-06 02:10:32Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * View for user manager of J!WHMCS Integrator
 * @version		2.4.18
 * 
 * @author		Steven
 * @since		1.5.0
 */
class JwhmcsViewUsermgr extends JwhmcsView
{
	/**
	 * Display view
	 * @access		public
	 * @version		2.4.18
	 * @param		unknown		- $tpl: override to pass for tpl
	 *
	 * @since		1.5.0
	 */
	public function display($tpl = null)
	{
		$model		= & $this->getModel('usermgr');
		$params		= & JwhmcsParams::getInstance();
		$user		= & JFactory::getUser();
		$task		=   JwhmcsHelper :: get( 'task' );
		$data		=   $model->getData( $task );
		$options	=   array();
		
		// We check here for easy use down the road
		$v			=   version_compare( JVERSION, '1.6.0', 'ge' ) ? '25' : '15';
		
		switch ($task):
		case 'joomadd':
		case 'joomedit':
			
			$options['isnew']	= ( isset( $data->id ) ? ( $data->id < 1 ? true : false ) : true );
			$options['title']	= $options['isnew'] ? JText::_( 'COM_JWHMCS_USERMGR_VIEW_JUSERADD_TITLE' ) : JText::_( 'COM_JWHMCS_USERMGR_VIEW_JUSEREDIT_TITLE' );
			
			// Load Mootools behaviors
			if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
				//JwhmcsHelper :: addMedia ( "submitbutton25/js" );
			}
			else {
				JHtml :: _( 'behavior.mootools' );
				JHtml :: _( 'behavior.tooltip' );
				JHtml :: _( 'behavior.formvalidation' );
				JwhmcsHelper :: addMedia ( "submitbutton{$v}/js" );
			}
			
			$this->assignRef('data',	$data);
			
			break;
		case 'whmcsadd':
		case 'whmcsedit':
			
			$options['isnew']	= ( isset( $data->id ) ? ( $data->id < 1 ? true : false ) : true );
			$options['title']	= $options['isnew'] ? JText::_( "COM_JWHMCS_USERMGR_VIEW_WUSERADD_TITLE" ) : JText::_( "COM_JWHMCS_USERMGR_VIEW_WUSEREDIT_TITLE" );
			
			$data->country		= $options['isnew'] ? $params->get( 'WhmcsDefaultCountry' ) : $data->country;
			
			// Load Mootools behaviors
			if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
// 				JwhmcsHelper :: addMedia ( "submitbutton25/js" );
			}
			else {
				JHtml :: _( 'behavior.mootools' );
				JHtml :: _( 'behavior.tooltip' );
				JHtml :: _( 'behavior.formvalidation' );
				JwhmcsHelper :: addMedia ( "submitbutton{$v}/js" );
			}
			
			$this->assignRef('data',	$data);
			$this->assignRef('field',	$field);
			break;
		case 'save':
		case 'sync':
		default:
			
			// Available Sort Fields
			$sort	= array('joomla' => array(
								'jid'		=> JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_ID" ),
								'jname'		=> JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_NAME" ),
								'jusername'	=> JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_USERNAME" ),
								'jblock'	=> JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_ENABLED" ),
								'jgroupname'=> JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_GROUP" )),
							'whmcs' => array(
								'wid'		=> JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_ID" ),
								'wfname'	=> JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WFNAME" ),
								'wlname'	=> JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WLNAME" ),
								'wcname'	=> JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCNAME2" ),
								'wcity'		=> JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCITY" ),
								'wstate'	=> JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WSTATE" ),
								'wcountry'	=> JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_WCOUNTRY" )));
			
			// Retrieve sort values from JRequest, set defaults otherwise
			$sortby		= (JwhmcsHelper :: get( 'sortby' ) ? JwhmcsHelper :: get( 'sortby' ) : 'wlname' );
			$sortord	= (JwhmcsHelper :: get( 'sortord' ) ? JwhmcsHelper :: get( 'sortord' ) : 1 );
			$sortjusers	= (JwhmcsHelper :: get( 'filter_jusers' ) ? JwhmcsHelper :: get( 'filter_jusers' ) : 0 );
			$sortwusers	= (JwhmcsHelper :: get( 'filter_wusers' ) ? JwhmcsHelper :: get( 'filter_wusers' ) : 0 );
			$sortmatch	= (JwhmcsHelper :: get( 'filter_matches' ) ? JwhmcsHelper :: get( 'filter_matches' ) : 0 );
			
			$baselnk = 'index.php?option=com_jwhmcs&controller=usermgr&filter_jusers='.$sortjusers.'&filter_wusers='.$sortwusers.'&filter_matches='.$sortmatch;
			
			foreach ($sort['joomla'] as $key => $value):
				if ( $sortby == $key )
					$thissort = ($sortord==1?-1:1);
				else
					$thissort = $sortord;
				$jsort[] = '<span class="jwhmcs-hdrsort"><a href="'.JRoute::_($baselnk.'&sortord='.$thissort.'&sortby='.$key).'">'.$value.'</a></span>';
			endforeach;
			foreach ($sort['whmcs'] as $key => $value):
				if ( $sortby == $key )
					$thissort = ($sortord==1?-1:1);
				else
					$thissort = $sortord;
				$wsort[] = '<span class="jwhmcs-hdrsort"><a href="'.JRoute::_($baselnk.'&sortord='.$thissort.'&sortby='.$key).'">'.$value.'</a></span>';
			endforeach;
			unset($sort['joomla'],$sort['whmcs']);
			$sort['joomla'] = implode(' | ', $jsort);
			$sort['whmcs']	= implode(' | ', $wsort);
			$sort['sortby']	= $sortby;
			$sort['sortord']= $sortord;
			$sort['user_search'] = $model->getState('user_search');
			$sort['jusers']	= (JwhmcsHelper :: get('filter_jusers')?JwhmcsHelper :: get('filter_jusers'):'0');
			$sort['matches']= (JwhmcsHelper :: get('filter_matches')?JwhmcsHelper :: get('filter_matches'):0);
			$sort['wusers']	= (JwhmcsHelper :: get('filter_wusers')?JwhmcsHelper :: get('filter_wusers'):0);
			
			// Assign template variables
			$this->assignRef('sort',		$sort);
			$this->assignRef('user',		$user);
			$this->assignRef('data',		$data->data);
			$this->assignRef('pagination',	$data->pagination);
		endswitch;
		
		JwhmcsToolbar :: usermgr( $task, $options );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JwhmcsHelper :: addMedia( 'icons35/css' );
			JwhmcsHelper :: addMedia( 'usermgr35/css' );
		}
		else {
			JwhmcsHelper :: addMedia( 'usermgr/css' );
			JwhmcsHelper :: addMedia( 'icons/css' );
		}
		
		parent::display($tpl);
	}
}