<?php
/**
 * Ajax Controller for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: ajax.php 555 2012-09-06 02:10:32Z steven_gohigher $
 * @since      2.0.2
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsControllerAjax
 * Extends:		JwhmcsController
 * Purpose:		Used for Ajax calls to J!WHMCS backend
 * 
 * As of:		version 2.0.2
\* ------------------------------------------------------------ */
class JwhmcsControllerAjax extends JwhmcsController
{
	/* ------------------------------------------------------------ *\
	 * Task:		__construct
	 * Purpose:		Needed for building the class
	 * 
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	function __construct() {
		parent::__construct();
		
		$this->registerTask( 'checkAPIInterface', 'checkApiu' );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		checkApi
	 * Purpose:		Handles calls to check the API settings
	 * 
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	function checkApi()
	{
		$app	= & JFactory::getApplication();
		$model	=   $this->getModel( 'ajax' );
		$data	=   $model->checkApi();
		echo $model->buildResponse($data);
		$app->close();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		checkApiu
	 * Purpose:		Handles calls to check the API settings
	 * 
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	function checkApiu()
	{
		$app	= & JFactory::getApplication();
		$model	=   $this->getModel( 'ajax' );
		$data	=   $model->checkApiu();
		echo $model->buildResponse($data);
		$app->close();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		checkPath
	 * Purpose:		Handles calls to check the WHMCS path
	 * 
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	function checkPath()
	{
		$app	= & JFactory::getApplication();
		$model	=   $this->getModel( 'ajax' );
		$data	=   $model->checkPath();
		echo $model->buildResponse($data);
		$app->close();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		checkValidLicense
	 * Purpose:		Handles calls to check the license
	 * 
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	function checkValidLicense()
	{
		$app	= & JFactory::getApplication();
		$model	=   $this->getModel( 'ajax' );
		$data	=   $model->checkValidLicense();
		echo $model->buildResponse($data);
		$app->close();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		interview
	 * Purpose:		Handles calls to the installation interview
	 * 
	 * As of:		version 2.0.2
	\* ------------------------------------------------------------ */
	function interview()
	{
		$app	= & JFactory::getApplication();
		$step	=   JRequest::getVar( 'step' ) ? JRequest::getVar( 'step' ) : 1;
		$model	=   $this->getModel( 'interview' );
		
		if ($step == 1)
		{	// Initialize installation
			$result = $model->instInitialize();
		}
		elseif ($step < 110)
		{	// Installation Plugins, Cache Dir and Hidden Menu
			$result = $model->instPlugins($step, true);
		}
		elseif ($step == 110)
		{	// Installation API Check
			$result = $model->instApi($step, true);
		}
		elseif ($step < 145)
		{	// Install files for WHMCS
			$result = $model->instFiles($step, true);
		}
		elseif ($step == 145)
		{	// Install verify files
			$result = $model->verifyFiles($step);
		}
		elseif ($step == 150)
		{	// Check License
			$result = $model->verifyLicense($step);
		}
		elseif ($step < 200)
		{	// Install wrapup
			$result = $model->instWrapup($step);
		}
		elseif ($step < 210)
		{	// Upgrade Plugins, Cache Dir and Hidden Menu
			$result = $model->instPlugins($step, true);
		}
		elseif ($step == 210)
		{	// Upgrade API Check
			$result = $model->instApi($step, true);
		}
		elseif ($step < 245)
		{	// Upgrade Files for WHMCS
			$result = $model->instFiles($step, true);
		}
		elseif ($step == 245)
		{	// Upgrade verify files
			$result = $model->verifyFiles($step);
		}
		elseif ($step == 250)
		{	// Upgrade check License
			$result = $model->verifyLicense($step);
		}
		else
		{	// Upgrade / Install wrap up
			$result = $model->instWrapup($step);
		}
		
		$result['step']		 = $step;
		//$result['message'][] = '<hr size="1" style="margin: 0; padding: 0px; " />';
		
		foreach ($result as $k => $v) $data[$k] = $v;
		if ( JRequest::getVar( "debug", false ) ) {
			echo "<pre>".htmlentities( print_r( $data, 1 ) )."</pre>";
		}
		else {
			echo $model->buildResponse($data);
		}
		$app->close();
		
	}
	
	
	/**
	 * Task to check for updates from Go Higher
	 * @access		public
	 * @version		2.4.18
	 * 
	 * @since		2.4.0
	 */
	public function checkforupdates()
	{
		require_once( dirname( dirname( __FILE__ ) ) . DS . 'update' . DS . 'update.php' );
		
		$app	= & JFactory::getApplication();
		$value	=   (string) JwhmcsUpdate :: hasUpdates();
		$msg	=   JText :: _( 'COM_JWHMCS_CHECKUPDATE_' . $value );
		
		$data	=   array( 'updates' => $value, 'message' => $msg );
		echo json_encode( $data );
		$app->close();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		checkinstall
	 * Purpose:		Handles calls to check the installation
	 * 
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function checkinstall()
	{
		$app	= & JFactory::getApplication();
		$step	=   JRequest::getVar( 'step' );
		$model	=   $this->getModel( 'check' );
		$result	=   $model->process($step);
		foreach ($result as $k => $v) $data[$k] = $v;
		echo $model->buildResponse( $data );
		$app->close();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Task:		checkinstall
	 * Purpose:		Handles calls to check the installation
	 * 
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function fixinstall()
	{
		$app	= & JFactory::getApplication();
		$step	=   JRequest::getVar( 'step' );
		$model	=   $this->getModel( 'check' );
		$result	=   $model->fixinstall($step);
		foreach ($result as $k => $v) $data[$k] = $v;
		echo $model->buildResponse( $data );
		$app->close();
	}
	
	
	function verifyFtp()
	{
		$app	= & JFactory::getApplication();
		$step	=   JRequest::getVar( 'step' );
		$model	=   $this->getModel( 'interview' );
		$result	=   $model->verifyFtp($step);
		foreach ($result as $k => $v) $data[$k] = $v;
		echo $model->buildResponse($data);
		$app->close();
	}
	
	
	function verifyPath()
	{
		$app	= & JFactory::getApplication();
		$step	=   JRequest::getVar( 'step' );
		$model	=   $this->getModel( 'interview' );
		$result	=   $model->verifyPath($step);
		foreach ($result as $k => $v) $data[$k] = $v;
		echo $model->buildResponse($data);
		$app->close();
	}
}
?>