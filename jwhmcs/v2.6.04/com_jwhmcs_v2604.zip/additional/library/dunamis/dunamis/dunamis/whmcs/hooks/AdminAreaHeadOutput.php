<?php
/**
 * @package         Dunamis
 * @subpackage		WHMCS
 * @version         1.4.3
 *
 * @author          Go Higher Information Services, LLC
 * @link            https://www.gohigheris.com
 * @copyright       2009 - 2015 Go Higher Information Services.  All rights reserved.
 * @license         GNU General Public License version 2, or later
 * 
 * @desc			This file outputs document data to the admin head
 */

echo dunloader( 'document', true )->renderHeadData();