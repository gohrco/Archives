<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 		Upgrade File
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.6.04 ( $Id$ )
 * @since      2.6.02
 *
 * @desc		This file performs a remote update from our WHMCS application
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

jimport( 'joomla.filesystem.folder' );
jimport( 'joomla.filesystem.file' );
jimport( 'joomla.filesystem.path' );

/**
 * Update Jwhmcs API Class
 * @version		2.6.04
 *
 * @since		2.6.02
 * @author		Steven
 */
class UpgradeJwhmcsAPI extends JwhmcsAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		2.6.04
	 * 
	 * @since		2.6.02
	 * @see			JwhmcsAPI :: execute()
	 */
	public function execute()
	{
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		$input	=	dunloader( 'input', true );
		$data	=	$input->getVar( 'data', array(), 'array', 'post' );
		
		$dlid	=	$config->get( 'downloadid', false );
		
		if (! $dlid ) {
			$dlid	=	$data['dlid'];
		}
		
		if (! $dlid ) {
			return $this->error( JText::_( 'JWHMCS_API_NO_DOWNLOADID' ) );
		}
		
		$config->set( 'downloadid', $dlid );
		$config->save();
		
		// Grab our update handler
		$updates	=	dunloader( 'updates', 'com_jwhmcs' );
		$result		=	$updates->download();
		
		JPluginHelper::importPlugin('installer');
		$dispatcher =	JEventDispatcher::getInstance();
		
		// Unpack with our Joomla installer
		$package	=	JInstallerHelper::unpack($updates->getUpdateTarget(), true);
		
		// Get an installer instance.
		$installer = JInstaller::getInstance();
		
		// Install the package.
		if (! $installer->install( $package['dir'] ) ) {
			return $this->error( JText :: _( 'JWHMCS_API_ERROR_UPDATING' ) );
		}
		
		JInstallerHelper::cleanupInstall($package['packagefile'], $package['extractdir']);
		
		// We have our dlid so lets try the upgrade
		return $this->success( JText :: _( 'JWHMCS_API_UPDATECOMPLETE' ) );
	}
}