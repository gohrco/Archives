<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.6.04 ( $Id: view.html.php 555 2012-09-06 02:10:32Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      1.5.0
 * 
 * @desc       Default View:  This file handles assembling the data and rendering the view to the user
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * Link view is used to render the wrapper around WHMCS
 * @version		2.3.0
 * 
 * @since		1.5.0
 * @author		Steven
 */
class JwhmcsViewLink extends JwhmcsViewExt
{
	/**
	 * Builds the view from the display task for the user
	 * @access		public
	 * @version		2.3.0
	 * @param 		string		$tpl - presumably a template name never used
	 * 
	 * @since		1.5.0
	 */
	public function display($tpl = null)
	{
		$app		=	JFactory::getApplication();
		$config		=	dunloader( 'config', 'com_jwhmcs' );
		$params		=	$app->getParams();
		
		$whmcsurl	=	$params->get( 'whmcsurl' );
		$location	=	rtrim( $whmcsurl, '/' ) . '/' . ltrim( base64_decode( $params->get( 'location' ) ), '/' );
		
		// ---- BEGIN: JWHMCS-31
		//		Languages don't get translated properly when on Joomla and going to WHMCS with language settings enabled
		if ( $config->get( 'languageenable' ) ) {
			
			$uri = JUri::getInstance();
			$jconfig	=	dunloader( 'config', true );
			
			if ( $jconfig->get( 'sef_rewrite' ) ) {
				$url	=	str_replace( $uri->base(), '', $uri->toString() );
				$parts	=	explode( '/', ltrim( $url, '/' ) );
				$sef	=	array_shift( $parts );
			}
			else {
				$sef	=	$uri->getVar( 'lang', false );
			}
				
			$langs	=	JLanguageHelper::getLanguages('sef');
			if ( isset( $langs[$sef] ) ) {
				$mylang	=	$config->findLanguage( $langs[$sef]->lang_code );
		
				$locuri	=	DunUri :: getInstance( $location );
				$locuri->setVar( 'language', $mylang );
				$location	=	$locuri->toString();
			}
		}
		// --- END JWHMCS-31
		
		$app->redirect( $location );
		$app->close();
	}
}