<?php
/**
 * J!WHMCS Integrator
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.6.04 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      1.1.0
 *
 * @desc       This is a helper file for the update routines for Jwhmcs
 *
 * The methods and routines within this file are based partly upon the work of
 *   Nicholas K. Dionysopoulos / AkeebaBackup.com
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die();
/*-- Security Protocols --*/


/**
 * JwhmcsStorageFile class object
 * @version		2.6.04
 * 
 * @since		1.1.0
 * @author		Steven
 */
class JwhmcsStorageFile extends JwhmcsStorage
{
	/**
	 * Stores the filename of the storage item
	 * @var		string
	 */
	private static $filename = null;
	
	/**
	 * Stores the path to the storage item
	 * @var		string
	 */
	private static $filepath = null;
	
	
	/**
	 * Method to load an extension into the storage object
	 * @access		public
	 * @version		2.6.04
	 * @param		object		- $config: contains the JwhmcsUpdateConfig object to use for stettings
	 *
	 * @since		1.1.0
	 */
	public function load( $config )
	{
		$path	= $config['_storagePath'];
		$filename	= $config['_storagePath'] . DS . $config['_extensionName'] . ".updates.ini";
		var_dump( $filename );
		self :: $filename = $filename;
		
		jimport('joomla.registry.registry');
		self :: $registry = new JRegistry();
		
		jimport('joomla.filesystem.file');
		
		if ( JFile :: exists( self :: $filename ) ) {
			$data = json_decode( JFile :: read( self :: $filename ), 1 );
			self :: $registry->loadArray( $data );
		}
	}
	
	
	/**
	 * Method to save parameters to the database
	 * @access		public
	 * @version		2.6.04
	 *
	 * @since		1.1.0
	 */
	public function save()
	{
		jimport( 'joomla.filesystem.file' );
		$data = json_encode( self :: $registry->toArray() );
		JFile::write( self :: $filename, $data );
	}
}