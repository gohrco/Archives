<?php defined('DUNAMIS') OR exit('No direct script access allowed');
/**
 * J!WHMCS Integrator
 * J!WHMCS Integrator - API Request Handler File
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.6.04 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.5.0
 *
 * @desc       This file handles requests to the Joomla connection
 *
 */


/**
 * Apirequest Class for J!WHMCS Integrator
 * @version		2.6.04
 *
 * @author		Steven
 * @since		2.5.0
 */
class Com_jwhmcsDunApi extends DunObject
{
	/**
	 * Holds the curl handler
	 * @access		protected
	 * @var			Object
	 * @since		2.5.0
	 */
	protected $curl		=	null;
	
	/**
	 * Stores the joomla options for the API
	 * @access		private
	 * @var			array
	 * @since		2.5.0
	 */
	private $_apioptions	= array();
	
	/**
	 * Stores the variables to post each time through the API
	 * @access		private
	 * @var			array
	 * @since		2.5.0
	 */
	private $_apipost	= array();
	
	/**
	 * Stores the timestamp generated for this set of calls
	 * @access		private
	 * @var			Unix Timestampe
	 * @since		2.5.0
	 */
	private $_apitimestamp	= null;
	
	/**
	 * Stores the secret token being used
	 * @access		private
	 * @var			string
	 * @since		2.5.0
	 */
	private $_apitoken	= null;
	
	/**
	 * Stores the uri for the API
	 * @access		private
	 * @var			DunUri Object
	 * @since		2.5.0
	 */
	private $_apiuri		= null;
	
	/**
	 * Indicates which version of the Joomla API we want to call up
	 * @access		private
	 * @var			string
	 * @since		2.5.0
	 */
	private $_apiversion = '2.6';
	
	/**
	 * Indicates we are enabled or disabled
	 * @access		private
	 * @var			boolean
	 * @since		2.5.0
	 */
	private $_enabled		=	false;
	
	/**
	 * Stores any errors we encounter
	 * @access		private
	 * @var			array
	 * @since		2.5.0
	 */
	private $_error			=	array();
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		2.6.04
	 * 
	 * @since		2.5.0
	 */
	public function __construct()
	{
		parent :: __construct();
		
		$this->_load();
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for creating a client on the connection
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 * @param		array		- $user: the assembled data to send to WHMCS
	 *
	 * @return		object or false on error
	 * @since		2.5.0
	 */
	public function addclient( $user = array() )
	{
		// Catch errors
		if ( empty( $user ) ) return false;
		
		$client = $this->_call_api( 'addclient', $user );
		
		return $client->result == 'success' ? (object) $client : false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for closing a client account on the connection
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 * @param		array		- $user: the assembled data to send to WHMCS
	 *
	 * @return		object or false on error
	 * @since		2.5.0
	 */
	public function closeclient( $user = array() )
	{
		// Catch errors
		if ( empty( $user ) ) return false;
		$client = $this->_call_api( 'closeclient', $user );
		return $client->result == 'success' ? (object) $client : false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for deleting a client on the connection [permanent]
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 * @param		array		- $user: the assembled data to send to WHMCS
	 *
	 * @return		object or false on error
	 * @since		2.5.0
	 */
	public function deleteclient( $user = array() )
	{
		// Catch errors
		if ( empty( $user ) ) return false;
		$client = $this->_call_api( 'deleteclient', $user );
		return $client->result == 'success' ? (object) $client : false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for deleting a contact on the connection [permanent]
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 * @param		array		- $user: the assembled data to send to WHMCS
	 *
	 * @return		object or false on error
	 * @since		2.5.0
	 */
	public function deletecontact( $user = array() )
	{
		// Catch errors
		if ( empty( $user ) ) return false;
		$client = $this->_call_api( 'deletecontact', $user );
		return $client->result == 'success' ? (object) $client : false;
	}
	
	
	/**
	 * Finds a matching user checking first the client then contact api
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 * @param		string		- $email: contains the email address to search for
	 * @param		boolean		- $force: permits overriding cache and loading again
	 *
	 * @return		object or false on error
	 * @since		1.0.0
	 */
	public function findmatchinguser( $email = null, $force = false )
	{
		static $found	=	array();
		
		if ( $email == null ) return false;
		
		// Caching of call
		if ( isset( $found[$email] ) && ! $force ) {
			return $found[$email];
		}
		
		if (! isset( $found[$email] ) || $force ) {
			$found[$email] = false;
		}
		
		$client	=	$this->getclientsdetails( $email, 'email' );
		
		if ( $client ) {
			$client->type	=	'client';
			$found[$email] = $client;
			return $client;
		}
		
		$contact	=	$this->getcontact( $email, 'email' );
		
		if ( $contact->totalresults == 1 ) {
			$contact		=	$contact->contacts->contact[0];
			$contact->type	=	'contact';
			$found[$email] = $contact;
			return $contact;
		}
		
		return false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for retrieving a clients details from the connection
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 * @param		mixed		- $id: contains either the client id, email address or an array of data [int|STRING|array]
	 * @param		string		- $by: indicates what the id is if integer / string passed [EMAIL|clientid]
	 *
	 * @return		object or false on error
	 * @since		2.5.0
	 */
	public function getclientsdetails( $id = null, $by = 'email' )
	{
		static $found	=	array();
		
		$data	=	array();
		
		// Permit passing data array directly
		if ( is_array( $id ) ) {
			if (! isset( $id['email'] ) && ! isset( $id['clientid'] ) ) {
				return false;
			}
			$data	=	$id;
			$find	=	isset( $id['email'] ) ? $id['email'] : $id['clientid'];
		}
		else {
			$find	=	$data[($by == 'email' ? 'email' : 'clientid' )] = $id;
		}
		
		if (! isset( $found[$find] ) ) {
			$client = $this->_call_api( 'getclientsdetails', $data );
			$found[$find]	=	$client->result == 'success' ? (object) $client : false;
		}
		
		return $found[$find];
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for retrieving a contacts details from the connection
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 * @param		mixed		- $id: contains either the client id, email address or an array of data [int|STRING|array]
	 * @param		string		- $by: indicates what the id is if integer / string passed [EMAIL|userid]
	 *
	 * @return		object or false on error
	 * @since		2.5.0
	 */
	public function getcontact( $id = null, $by = 'email' )
	{
		static $found	=	array();
	
		$data	=	array();
	
		// Permit passing data array directly
		if ( is_array( $id ) ) {
			if (! isset( $id['email'] ) && ! isset( $id['userid'] ) ) {
				return false;
			}
			$data	=	$id;
			$find	=	isset( $id['email'] ) ? $id['email'] : $id['clientid'];
		}
		else {
			$find	=	$data[($by == 'email' ? 'email' : 'clientid' )] = $id;
		}
	
		if (! isset( $found[$find] ) ) {
			$client = $this->_call_api( 'getcontacts', $data );
			$found[$find]	=	$client->result == 'success' ? $client : false;
		}
	
		return $found[$find];
	}
	
	
	/**
	 * Method to retrieve an error from the object
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 *
	 * @return		string
	 * @since		2.5.0
	 */
	public function getError()
	{
		if (! empty( $this->_error ) ) {
			return array_pop( $this->_error );
		}
		
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		$debug	=	$config->get( 'debug', false );
		
		$error	=	$this->curl->has_errors();
		
		// If we have debug on, lets return the curl error raw 
		if ( $debug ) return $error;
		
		$error	=	preg_replace( '#\[[^\]]*\]#i', '', $error );
		return $error;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.6
	 * --------------------------------------------------------------------
	 * Method for retrieving the current WHMCS addon version
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 *
	 * @return		boolean
	 * @since		2.6.02
	 */
	public function getinfo( $post = array() )
	{
		$post['module']	=	'jwhmcs';
		$post['method']	=	'api';
		$post['task']	=	'getinfo';
		
		$call = $this->_call_api( 'dunamis', $post );
		return $call->result == 'success' ? (object) $call->data : false;
	}
	
	
	/**
	 * Singleton
	 * @access		public
	 * @static
	 * @version		2.6.04
	 * @param		array		- $options: contains an array of arguments
	 *
	 * @return		object
	 * @since		2.5.0
	 */
	public static function getInstance( $options = array() )
	{
		static $instance = null;
		
		if (! is_object( $instance ) || ( isset( $options['force'] ) && $options['force'] ) ) {
			
			if ( isset( $options['force'] ) ) {
				unset( $options['force'] );
			}
			
			$instance = new Com_jwhmcsDunApi( $options );
		}
	
		return $instance;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for retrieving the languages on WHMCS
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	public function getlanguages( $post = array() )
	{
		$post['module']	=	'jwhmcs';
		$post['method']	=	'api';
		$post['task']	=	'getlanguages';
	
		$call = $this->_call_api( 'dunamis', $post );
		return $call->result == 'success' ? (object) $call->data : false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5.12
	 * --------------------------------------------------------------------
	 * Method for retrieving a price for the J!WHMCS Pricing Plugin
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 * @param		string		- $price: a comma separated list of price options to fetch
	 * @param		string		- $by: indicates how we are identifying the product (name or id)
	 *
	 * @return		object or false on error
	 * @since		2.5.12
	 */
	public function getprice( $price, $by )
	{
		$post['module']	=	'jwhmcs';
		$post['method']	=	'api';
		$post['task']	=	'getprice';
		$post['price']	=	$price;
		$post['by']		=	$by;
		
		$call = $this->_call_api( 'dunamis', $post );
		return $call->result == 'success' ? (object) $call->data : false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for retrieving a clients username from WHMCS
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 * @param		string		- $email: the users' email to find on
	 *
	 * @return		object or false on error
	 * @since		2.5.0
	 */
	public function getusername( $email )
	{
		$post['module']	=	'jwhmcs';
		$post['method']	=	'api';
		$post['task']	=	'getusername';
		$post['email']	=	$email;
		
		$call = $this->_call_api( 'dunamis', $post );
		
		return $call->result == 'success' ? $call->data : false;
	}
	
	
	/**
	 * Method for determining if we encountered any errors
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	public function hasErrors()
	{
		// Check local object first
		$state	= empty( $this->_error );
		if ( $state === false ) return true;
		
		$state	=	$this->curl->has_errors();
		return $state ? true : false;
	}
	
	
	public function isEnabled()
	{
		return (bool) $this->_enabled;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for testing the connection
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	public function ping()
	{
		$ping	=	$this->_call_api();
		
		if (! $ping || ! is_object( $ping ) || $ping->result != 'success' ) return false;
		
		return true;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5.15
	 * --------------------------------------------------------------------
	 * Method for searching the knowledgebase on WHMCS
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 *
	 * @return		boolean
	 * @since		2.5.15
	 */
	public function searchknowledgebase( $post = array() )
	{
		$post['module']	=	'jwhmcs';
		$post['method']	=	'api';
		$post['task']	=	'searchknowledgebase';
	
		$call = $this->_call_api( 'dunamis', $post );
		return $call->result == 'success' ? (object) $call->data : false;
	}
	
	
	/**
	 * Method for setting an error message
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 * @param		string		- $msg: the message string
	 * @param		boolean		- $trans: translate the string [T/f]
	 *
	 * @return		false always
	 * @since		2.5.0
	 */
	public function setError( $msg, $trans = true )
	{
		$this->_error[]	=	$msg;
		return false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for updating an existing client on the connection
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 * @param		array		- $user: the assembled data to send to WHMCS
	 *
	 * @return		object or false on error
	 * @since		2.5.0
	 */
	public function updateclient( $user = array() )
	{
		// Catch errors
		if ( empty( $user ) ) return false;
		
		$client = $this->_call_api( 'updateclient', $user );
		
		return $client->result == 'success' ? (object) $client : false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for updating an existing contact on the connection
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 * @param		array		- $user: the assembled data to send to WHMCS
	 *
	 * @return		object or false on error
	 * @since		2.5.0
	 */
	public function updatecontact( $user = array() )
	{
		// Catch errors
		if ( empty( $user ) ) return false;
		
		$client = $this->_call_api( 'updatecontact', $user );
	
		return $client->result == 'success' ? (object) $client : false;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for updating the username on the connection
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	public function updatesettings( $data = array() )
	{
		if ( empty( $data ) ) return false;
		
		$data	=	array(
				'data'		=>	$data,
				'module'	=>	'jwhmcs',
				'method'	=>	'api',
				'task'		=>	'updatesettings'
				);
		
		$call	=	$this->_call_api( 'dunamis', $data );
		return $call->result == 'success';
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for updating the username on the connection
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	public function updateusername( $user = array() )
	{
		if ( empty( $user ) ) return;
		$user['module']	=	'jwhmcs';
		$user['method']	=	'api';
		$user['task']	=	'updateusername';
		
		$client = $this->_call_api( 'dunamis', $user );
		return $client->result == 'success' ? (object) $client : false;	
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.6
	 * --------------------------------------------------------------------
	 * Method for upgrading the remote WHMCS addon module
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 *
	 * @return		boolean
	 * @since		2.6.02
	 */
	public function upgrade()
	{
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		$data	=	array(
				'dlid'	=>	$config->get( 'downloadid' ),
		);
		
		$post	=	array(
				'action'	=>	'dunamis',
				'module'	=>	'jwhmcs',
				'method'	=>	'api',
				'task'		=>	'upgrade',
				'data'		=>	$data
		);
		
		$call	=	$this->_call_api( 'upgrade', $post, array( 'TIMEOUT' => 300 ) );
		
		// Return result
		return $call;
	}
	
	
	/**
	 * --------------------------------------------------------------------
	 * API METHOD	as of api version 2.5
	 * --------------------------------------------------------------------
	 * Method for validating a login is good
	 * @access		public
	 * @version		2.6.04 ( $id$ )
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	public function validatelogin( $email, $password )
	{
		$user	=	array(
				'email'		=> $email,
				'password2'	=> $password
				);
		
		$data = $this->_call_api( 'validatelogin', $user );
		return $data->result == 'success';
	}
	
	
	/**
	 * Method for calling up the API
	 * @access		private
	 * @version		2.6.04
	 * @param		string		- $call: the actual API method on the remote system
	 * @param		array		- $post: any additional post variables
	 * @param		array		- $optns: we can specify curl options in this
	 * @param		bool		- @wantresult: true if we want the result back false if we just want to know it worked
	 *
	 * @return		mixed array or boolean
	 * @since		2.5.0
	 */
	private function _call_api( $call = 'getactivitylog', $post = array(), $optns = array(), $wantresult = true )
	{
		// Last chance to test before epic fails
		if ( empty( $this->_apiuri ) || empty( $this->_apipost ) ) {
			return false;
		}
		
		// Now we should test to ensure it's live
		$uri	=	clone $this->_apiuri;
		$optns	=	array_merge( $this->_apioptions, $optns );
		$post	=	array_merge( $post, $this->_apipost );
		
		$post['action']	=	$call;
		
		// Assemble the API Request
		$this->curl->create( $uri->toString() );
		$this->curl->post( $post, $optns );
		
		// Execute the Curl Call
		$result	=	$this->curl->execute();
		
		// Debug handling
		dunloader( 'debug', true )->addApi( array(
				'call'		=>	$call,
				'method'	=>	'post',
				'post'		=>	$post,
				'optns'		=>	$optns,
				'result'	=>	$result,
				'curlinfo'	=>	$this->curl->info
		) );
		
		// Return result
		if (! $wantresult ) {
			return $this->curl->has_errors() ? false : true;
		}
		
		// Clean BOMs from beginning of output
		$result	=	preg_replace( '#^\xEF\xBB\xBF#', '', $result );
		
		// Process for returned errors
		$data	= json_decode( $result, false );
		
		if ( $data->result == 'error' ) {
			$this->setError( $data->message, false );
		}
		
		return $data;
	}
	
	
	/**
	 * Loads the API and enables if checks out
	 * @access		private
	 * @version		2.6.04
	 *
	 * @since		2.5.0
	 */
	private function _load()
	{
		$config		=	dunloader( 'config', 'com_jwhmcs' );
		$apiurl		=	$config->get( 'whmcsurl', null );
		$apiuser	=	$config->get( 'whmcsapiusername', null );
		$apipass	=	$config->get( 'whmcsapipassword', null );
		$apiaxs		=	$config->get( 'whmcsapiaccesskey', null );
		
		// We can't do anything if these are empty
		if ( empty( $apiurl ) || empty( $apiuser ) || empty( $apipass ) ) {
			return $this->setError( 'error.apicnxn.' . ( empty( $apiurl ) ? 'nourl' : ( empty( $apiuser ) ? 'nouser' : 'nopass' ) ) );
		}
		
		// Clean the URL and complete it
		$apiurl	= rtrim( $apiurl, '/' ) . '/includes/api.php';
		
		$this->curl				=	dunloader( 'curl', false );
		$this->_apiuri			=	new DunUri( $apiurl );
		
		// This gets used every time
		$this->_apipost	=   array(	'username'		=> $apiuser,
									'password'		=> md5( trim( $apipass ) ),
									'jwhmcs'		=> 1,
									'responsetype'	=> 'json'
				);
		
		if (! empty( $apiaxs ) ) $this->_apipost['accesskey']	=	$apiaxs;
		
		$this->_apioptions	= array(	'HEADER'			=> false,
										'RETURNTRANSFER'	=> true,
										'SSL_VERIFYPEER'	=> false,
										'SSL_VERIFYHOST'	=> false,
										'CONNECTTIMEOUT'	=> 2,
										'FORBID_REUSE'		=> true,
										'FRESH_CONNECT'		=> true,
										'HTTP_VERSION'		=> CURL_HTTP_VERSION_1_1,
										'HTTPHEADER'		=> array(),
		);
		
		if (! $this->ping() ) {
			return;
		}
		
		$this->_enabled = true;
		
		return;
	}
}