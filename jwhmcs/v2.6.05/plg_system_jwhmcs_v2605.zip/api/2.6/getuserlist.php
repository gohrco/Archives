<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 		API Findusername File
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.6.05 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.5.0
 *
 * @desc       This is the Findusername Task for the J!WHMCS Integrator API
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Findusername Jwhmcs API Class
 * @version		2.6.05
 *
 * @since		2.5.0
 * @author		Steven
 */
class GetuserlistJwhmcsAPI extends JwhmcsAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		2.6.05
	 * 
	 * @since		2.5.0
	 * @see			JwhmcsAPI :: execute()
	 */
	public function execute()
	{
		$db		=	dunloader( 'database', true );
		$find	=	dunloader('input',true)->getVar('search', null );
		$search	=	null;
		
		// ===================================================================
		// Get a list of users
		// ===================================================================
		if ( $find != null ) {
			$find	=	$db->Quote( '%' . $find . '%' );
			$search	=	" WHERE u.name LIKE " . $find . " OR u.username LIKE " . $find . " OR u.email LIKE " . $find;
		}
		
		$query	=	$db->setQuery( "SELECT u.email FROM #__users AS u " . $search );
		$users	= $db->loadObjectList();
		
		$this->success( $users );
	}
}