<?php
/**
 * J!WHMCS Integrator
 * Joomla! - Legacy Handler
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.6.05 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.5.0
 *
 * @desc       This file permits J!WHMCS Integrator to operate across Joomla! versions
 *
 */


if ( version_compare( JVERSION, '3.0', 'ge' ) )
{
	if (! class_exists( 'JwhmcsControllerExt' ) ) {
		class JwhmcsControllerExt extends JControllerLegacy {}
	}
	if (! class_exists( 'JwhmcsControllerForm' ) ) {
		class JwhmcsControllerForm extends JControllerForm {}
	}
	if (! class_exists( 'JwhmcsModelExt' ) ) {
		class JwhmcsModelExt extends JModelLegacy {}
	}
	if (! class_exists( 'JwhmcsViewExt' ) ) {
		class JwhmcsViewExt extends JViewLegacy {}
	}
}
else if ( version_compare( JVERSION, '1.6', 'ge' ) )
{
	jimport('joomla.application.component.controller');
	jimport('joomla.application.component.controllerform');
	jimport('joomla.application.component.model');
	jimport( 'joomla.application.component.view' );
	
	if (! class_exists( 'JwhmcsViewExt' ) ) {
		class JwhmcsViewExt extends JView {}
	}
	if (! class_exists( 'JwhmcsControllerExt' ) ) {
		class JwhmcsControllerExt extends JController {}
	}
	if (! class_exists( 'JwhmcsControllerForm' ) ) {
		class JwhmcsControllerForm extends JControllerForm {}
	}
	if (! class_exists( 'JwhmcsModelExt' ) ) {
		class JwhmcsModelExt extends JModel {}
	}
}
else
{
	jimport('joomla.application.component.controller');
	jimport('joomla.application.component.model');
	jimport( 'joomla.application.component.view' );

	if (! class_exists( 'JwhmcsControllerExt' ) ) {
		class JwhmcsControllerExt extends JController {}
	}
	if (! class_exists( 'JwhmcsControllerForm' ) ) {
		class JwhmcsControllerForm extends JController {}
	}
	if (! class_exists( 'JwhmcsModelExt' ) ) {
		class JwhmcsModelExt extends JModel {}
	}
	if (! class_exists( 'JwhmcsViewExt' ) ) {
		class JwhmcsViewExt extends JView {}
	}
}