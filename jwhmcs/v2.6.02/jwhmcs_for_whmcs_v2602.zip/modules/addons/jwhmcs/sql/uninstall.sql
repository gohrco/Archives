

DROP TABLE IF EXISTS `mod_jwhmcs_settings`;

