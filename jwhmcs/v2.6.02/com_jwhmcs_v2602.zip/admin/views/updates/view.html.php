<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.6.02 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.4.0
 * 
 * @desc       This is the updates view file for the backend of J!WHMCS Integrator
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.view' );
//if ( file_exists( $path = JPATH_COMPONENT_ADMINISTRATOR . DS . 'update' . DS . 'update.php' ) )
	//require_once( $path );
/*-- File Inclusions --*/

/**
 * J!WHMCS Integrator Updates View
 * @author		Steven
 * @version		2.6.02
 * 
 * @since		2.4.0
 */
class JwhmcsViewUpdates extends JwhmcsViewExt
{
	
	/**
	 * Display view
	 * @access		public
	 * @version		2.6.02
	 * @param		string		- $tpl: contains a template to overload with
	 * 
	 * @return		parent :: display()
	 * @since		2.4.0
	 */
	function display( $tpl = null )
	{
		$model	=	$this->getModel();
		$data	=	$model->getData( true );
		
		$doc	=	dunloader( 'document', true );
		load_bootstrap( 'jwhmcs' );
		
		// Retrieve ACL permitted actions
		$canDo	= JwhmcsHelper :: getActions();
		
		JwhmcsToolbar :: build( 'updates', null, $canDo );
		
		JwhmcsHelper :: addMedia( 'common/js' );
		JwhmcsHelper :: addMedia( 'ajax/js' );
		JwhmcsHelper :: addMedia( 'icons/css' );
		
		$this->data	= $data;
		
		parent::display($tpl);
	}
	
	
	/**
	 * Displays the proces view
	 * @access		public
	 * @version		2.6.02
	 * @param		string		- $tpl: conains the template to overload with
	 * 
	 * return		parent :: display()
	 * @since		2.4.0
	 */
	function process( $tpl = null )
	{
		$this->setLayout( 'process' );
		
		parent::display($tpl);
	}
}