<?php
/**
 * J!WHMCS Integrator
 * Joomla! - Install Script for Joomla! 2.5+
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.6.02 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.5.0
 *
 * @desc       This file is used by the installer of Joomla! to load the rest of the required elements
 * 
 * Big thanks to YooTheme for the core installation routine
 */
defined( '_JEXEC' ) or die( 'Restricted access' );


/**
 * Extension of our install script
 * @author Steven
 */
class com_jwhmcsInstallerScript extends JwhmcsInstallerScript {}


/**
 * Installation Script
 * @author		Steven
 * @version		2.6.02
 * 
 * @since		2.5.0
 */
class JwhmcsInstallerScript
{
	/**
	 * Method to display the results of an upgrade, install or uninstall
	 * @static
	 * @access		public
	 * @version		2.6.02 ( $id$ )
	 * @param		array		- $extensions: the extensions we just worked with and their result
	 * 
	 * @since		2.5.0
	 */
	public static function displayAdditionalExtensions( $extensions )
	{
		?>
			<table class="adminlist table table-bordered table-striped">
				<thead>
					<tr>
						<th class="title"><?php echo JText::_('Extension'); ?></th>
						<th width="60%"><?php echo JText::_('Status'); ?></th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<td colspan="2">&nbsp;</td>
					</tr>
				</tfoot>
				<tbody>
					<?php
						foreach ( $extensions as $i => $extension ) : ?>
						<tr class="row<?php echo $i % 2; ?>">
							<td class="key"><?php echo $extension->name; ?></td>
							<td>
								<?php $style = $extension->status ? 'font-weight: bold; color: green;' : 'font-weight: bold; color: red;'; ?>
								<span style="<?php echo $style; ?>"><?php echo $extension->message; ?></span>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php 
	}
	
	
	/**
	 * Method for installing the component
	 * @access		public
	 * @version		2.6.02 ( $id$ )
	 * @param		object		- $parent: instance of JInstaller
	 * @param		boolean		- $isInstall: if we are coming from the upgrade call we don't want to actiate deactivated plugins automatically
	 * 
	 * @since		2.5.0
	 */
	public function install( $parent, $isInstall = true )
	{
		$installer	=	$parent->getParent();
		$extensions	=	$this->getAdditionalExtensions( $installer );
		
		// install additional extensions
		foreach ($extensions as $extension) {
		
			if (! $extension->install() ) {
				// rollback on installation errors
				$installer->abort( JText::_('Component') . ' ' . JText::_('Install') . ': ' . JText::_('Error'), 'component' );
		
				foreach ( $extensions as $extension ) {
					if ( $extension->status ) {
						$extension->abort();
					}
				}
				break;
			}
			
			// Only enable plugins on initial install
			if ( $isInstall && $extension->exttype == 'plugin' ) {
				$extension->enable();
			}
			
			// Perform reorder on plugins
			$extension->reorder();
		}
		
		// display table
		if ( $extensions ) {
			self :: displayAdditionalExtensions( $extensions );
		}
	}
	
	
	/**
	 * Method for updating the component
	 * @access		public
	 * @version		2.6.02 ( $id$ )
	 * @param		object		- $parent: instance of JInstaller
	 *
	 * @since		2.5.0
	 */
	public function update( $parent )
	{
		return $this->install( $parent, false );
	}
	
	
	/**
	 * Method for uninstalling the component
	 * @access		public
	 * @version		2.6.02 ( $id$ )
	 * @param		object		- $parent: instance of JInstaller
	 *
	 * @since		2.5.0
	 */
	public function uninstall( $parent )
	{
		// init vars
		$installer  = $parent->getParent();
		$extensions = $this->getAdditionalExtensions( $installer );
		
		// uninstall additional extensions
		foreach ( $extensions as $extension ) {
			$extension->uninstall();
		}
		
		// display table
		if ( $extensions ) {
			self::displayAdditionalExtensions( $extensions );
		}
	}
	
	
	/**
	 * Method for installing the component
	 * @access		protected
	 * @version		2.6.02 ( $id$ )
	 * @param		object		- $installer: instance of JInstaller
	 * 
	 * @return		array of extensions to run
	 * @since		2.5.0
	 */
	protected function getAdditionalExtensions( $installer )
	{
		// Initialize
		$extensions	=	array();
		
		// Find the additional extensions in manifest file
		if (	( $manifest = simplexml_load_file( $installer->getPath( 'manifest' ) ) ) &&
				( $additional = $manifest->xpath( 'additional/*' ) ) ) {
			
			foreach ( $additional as $data ) {
				$extensions[] = new JwhmcsAdditionalExtension( $installer, $data );
			}
		}

		return $extensions;
	}
}


/**
 * Additional Extension class
 * @author		Steven
 * @version		2.6.02
 * 
 * @since		2.5.0
 */
class JwhmcsAdditionalExtension
{
	public $name;
	public $element;
	public $type;
	public $status;
	public $message;
	public $data;
	public $parent;
	public $installer;
	public $database;
	public $folder;
	public $source_path;
	public $last;
	
	/**
	 * Constructor Method
	 * @access		public
	 * @version		2.6.02 ( $id$ )
	 * @param		object		- $parent: instance of JInstaller
	 * @param		$data		- $data: what we read from the manifest file
	 *
	 * @since		2.5.0
	 */
	public function __construct( $parent, $data )
	{
		// init vars
		$this->name			=	(string) $data;
		$this->element		=	(string) $data->attributes()->name;
		$this->type			=	(string) $data->attributes()->type;
		$this->exttype		=	$data->getName();
		$this->status		=	false;
		$this->data			=	$data;
		$this->parent		=	$parent;
		$this->installer	=	new JInstaller();
		$this->database		=	JFactory::getDBO();
		$this->folder		=	(string) $data->attributes()->folder;
		$this->source_path	=	rtrim($this->parent->getPath('source').'/'.$this->folder, "\\/") . '/';
		
		if ( $data->getName() == 'plugin' ) {
			$last		=	(string) $data->attributes()->last;
			$this->last =	(bool) ( $last == 'true' ? true : false );
		}
	}
	
	
	/**
	 * Method for installing an extension
	 * @access		public
	 * @version		2.6.02 ( $id$ )
	 * 
	 * @return		boolean
	 * @since		2.5.0
	 */
	public function install()
	{
		// set message
		if ( $this->status = $this->installer->install( $this->parent->getPath('source').'/'.$this->data->attributes()->folder ) ) {
			$this->message = JText::_('Installed successfully');
		}
		else {
			$this->message = JText::_('NOT Installed');
		}
		
		return $this->status;
	}
	
	
	/**
	 * Method for uninstalling an extension
	 * @access		public
	 * @version		2.6.02 ( $id$ )
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	public function uninstall()
	{
		// get extension id and client id
		$result		=	$this->load();
		$ext_id		=	isset( $result->extension_id ) ? $result->extension_id  : 0;
		$client_id	=	isset( $result->client_id ) ? $result->client_id : 0;
		
		// set message
		if (	$this->status = $ext_id > 0 && 
				$this->installer->uninstall( $this->exttype, $ext_id, $client_id ) ) {
			$this->message = JText::_('Uninstalled successfully');
		}
		else {
			$this->message = JText::_('Uninstall FAILED');
		}
		
		return $this->status;
	}
	
	
	/**
	 * Method for aborting an extension
	 * @access		public
	 * @version		2.6.02 ( $id$ )
	 *
	 * @since		2.5.0
	 */
	public function abort()
	{
		$this->installer->abort( JText::_($this->exttype).' '.JText::_('Install').': '.JText::_('Error'), $this->exttype );
		$this->status = false;
	}
	
	
	/**
	 * Method for aborting an install of an extension
	 * @access		public
	 * @version		2.6.02 ( $id$ )
	 *
	 * @return		object of fields from database
	 * @since		2.5.0
	 */
	public function load()
	{
		$this->database->setQuery( sprintf("SELECT * FROM #__extensions WHERE type='%s' AND element='%s'", $this->exttype, $this->element ) );
		return $this->database->loadObject();
	}
	
	
	/**
	 * Method for enabling an extension
	 * @access		public
	 * @version		2.6.02 ( $id$ )
	 *
	 * @since		2.5.0
	 */
	public function enable()
	{
		$this->database->setQuery( sprintf("UPDATE #__extensions SET enabled=1 WHERE type='%s' AND element='%s'", $this->exttype, $this->element ) );
		$this->database->query();
	}
	
	
	/**
	 * Method for reordering a plugin to last or first position
	 * @access		public
	 * @version		2.6.02 ( $id$ )
	 * 
	 * @since		2.5.0
	 */
	public function reorder()
	{
		// Only plugins allowed
		if ( $this->exttype != 'plugin' ) return;
		
		// Isolate the plugin folder type
		$parts		=	explode( '/', $this->folder );
		$folder		=	array_pop( $parts );
		
		// Build our query
		$ordering	=	( $this->last ? 'DESC' : 'ASC' );
		$query		=	"SELECT `ordering` FROM #__extensions WHERE `type` = '%s' AND `folder` = '%s' ORDER BY `ordering` " . $ordering;
		$this->database->setQuery( sprintf( $query, $this->exttype, $this->type ) );
		
		// Grab the order value
		$order		=	$this->database->loadResult();
		
		if ( $order == null || $order === false ) {
			$order	=	0;
		}
		
		$order		=	( $this->last ? ++$order : --$order );
		
		$this->database->setQuery( sprintf("UPDATE #__extensions SET `ordering` = %s WHERE type='%s' AND element='%s'", $order, $this->exttype, $this->element ) );
		$this->database->query();
	}
}