<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 		API Validate File
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.6.02 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.5.0
 *
 * @desc       This is the Validate Task for the J!WHMCS Integrator API
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Ping Jwhmcs API Class
 * @version		2.6.02
 *
 * @since		2.5.0
 * @author		Steven
 */
class ValidateJwhmcsAPI extends JwhmcsAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		2.6.02
	 * 
	 * @since		2.5.0
	 * @see			JwhmcsAPI :: execute()
	 */
	public function execute()
	{
		$input		=	dunloader( 'input', true );
		$method		=	$input->getMethod();
		$data		=	$input->getVar('data', array(), 'STRING', $method );
		
		$data		=	unserialize( base64_decode( $data ) );
		
		if ( $data['isnew'] ) {
			
			if ( $this->_checkFor( $data['email'] ) ) {
				$this->error( sprintf( JText :: _( 'JWHMCS_SYSM_API_VALIDATEEMAIL_NO' ), $data['email'] ) );
			}
			
			if ( isset( $data['username'] ) && ! empty( $data['username'] ) ) {
				if ( $this->_checkFor( $data['username'], 'username' ) ) {
					$this->error( sprintf( JText :: _( 'JWHMCS_SYSM_API_VALIDATEUSERNAME_NO' ), $data['username'] ) );
				}
			}
		}
		else {
			
			// See if the old / new emails are different
			if ( isset( $data['oldemail'] ) && isset( $data['email'] ) && $data['oldemail'] != $data['email'] ) {
				if ( $this->_checkFor( $data['email'] ) ) {
					$this->error( sprintf( JText :: _( 'JWHMCS_SYSM_API_VALIDATEEMAIL_NO' ), $data['email'] ) );
				}
			}
			
			$oldusername	=	$this->_checkFor( $data['oldemail'], 'username', 'email' );
			
			if ( isset( $data['username'] ) && $data['username'] != $oldusername ) {
				if ( $this->_checkFor( $data['username'], 'username' ) ) {
					$this->error( sprintf( JText :: _( 'JWHMCS_SYSM_API_VALIDATEUSERNAME_NO' ), $data['username'] ) );
				}
			}
		}
		
		$this->success( JText :: _( 'JWHMCS_SYSM_API_VALIDATE_YES' ) );
	}
	
	
	/**
	 * Method for checking a variable in the table
	 * @access		private
	 * @version		2.6.02 ( $id$ )
	 * @param		string		- $value: the value to check
	 * @param		string		- $item: the item we want to check [username|email]
	 * @param		string		- $by: permits us to look according to a different item
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	private function _checkFor( $value = null, $item = 'email', $by = null )
	{
		$by		=	$by == null ? $item : $by;
		$db		=	dunloader( 'database', true );
		$query	=	"SELECT u." . $item . " FROM `#__users` u WHERE `" . $by . "` = " . $db->Quote( $value );
		$db->setQuery( $query );
		return $db->loadResult();
	}
}