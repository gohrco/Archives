<?php

defined('_JEXEC') or die( 'Restricted access' );

/**
 * Define the JWHMCS version here
 */
if (! defined( 'DUN_MOD_JWHMCS' ) ) define( 'DUN_MOD_JWHMCS', "2.6.02" );
if (! defined( 'DUN_MOD_JWHMCS_SYSM' ) ) define( 'DUN_MOD_JWHMCS_SYSM', "2.6.02" );


class Jwhmcs_sysmDunModule extends DunModule
{
	public function initialise()
	{
		
	}
}