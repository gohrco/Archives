<?php

defined('_JEXEC') or die( 'Restricted access' );

/**
 * Define the JWHMCS version here
 */
if (! defined( 'DUN_MOD_JWHMCS' ) ) define( 'DUN_MOD_JWHMCS', "2.5.4" );
if (! defined( 'DUN_MOD_JWHMCS_AUTH' ) ) define( 'DUN_MOD_JWHMCS_AUTH', "2.5.4" );


class Jwhmcs_authDunModule extends DunModule
{
	public function initialise()
	{
		
	}
}