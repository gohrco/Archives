<?php
/**
 * Default Controller for J!WHMCS Integrator
*
* @package    J!WHMCS Integrator
* @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
* @license    GNU General Public License version 2, or later
* @version    $Id: default.php 555 2012-09-06 02:10:32Z steven_gohigher $
* @since      1.5.1
*/

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );


/**
 * JwhmcsControllerAjax class handles ajax calls from the backend
 * @version		2.5.15
 *
 * @since		2.5.0
 * @author		Steven
 */
class JwhmcsControllerAjax extends JwhmcsControllerExt
{

	/**
	 * Constructor task
	 * @access		public
	 * @version		2.5.15
	 *
	 * @since		1.5.1
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Task for checking the apicnxn through ajax
	 * @access		public
	 * @version		2.5.15 ( $id$ )
	 *
	 * @return		void
	 * @since		2.5.0
	 */
	public function apicnxncheck()
	{
		$app	=	JFactory :: getApplication();
		$model	=   $this->getModel( 'ajax' );
		$data	=	$model->apicnxncheck();
		
		// Save settings
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		$config->save();
		
		echo json_encode( $data );
		$app->close();
	}
	
	
	/**
	 * Task for checking updates for the product
	 * @access		public
	 * @version		2.5.15 ( $id$ )
	 *
	 * @return		void
	 * @since		2.5.0
	 */
	public function checkforupdates()
	{
		$app	=	JFactory :: getApplication();
		$model	=   $this->getModel( 'updates' );
		$data	=	$model->getData();
		$status	=	( $data->hasupdates === true ? '1' : ( $data->hasupdates === false ? '0' : '-2' )  );
		$msg	=   JText :: _( 'COM_JWHMCS_CHECKUPDATE_' . $status );
		
		echo json_encode( array( 'result' => 'success', 'message'=> $msg, 'updates' => $status ) );
		$app->close();
	}
	
	
	/**
	 * Task for completing an update
	 * @access		public
	 * @version		2.5.15 ( $id$ )
	 *
	 * @return		void
	 * @since		2.5.0
	 */
	public function updatecomplete()
	{
		$app	=	JFactory :: getApplication();
		$model	=   $this->getModel( 'updates' );
		$data	=	$model->updatecomplete();
	
		echo json_encode( array( 'result' => 'success', 'message' => $data->message, 'state' => $data->state ) );
		$app->close();
	}
	
	
	/**
	 * Task for downloading the updates from our servers
	 * @access		public
	 * @version		2.5.15 ( $id$ )
	 *
	 * @return		void
	 * @since		2.5.0
	 */
	public function updatedownload()
	{
		$app	=	JFactory :: getApplication();
		$model	=   $this->getModel( 'updates' );
		$data	=	$model->updateDownload();
		
		echo json_encode( array( 'result' => 'success', 'message' => $data->message, 'state' => $data->state ) );
		$app->close();
	}
	
	
	/**
	 * Task for initializing the update routine
	 * @access		public
	 * @version		2.5.15 ( $id$ )
	 *
	 * @return		void
	 * @since		2.5.0
	 */
	public function updateinit()
	{
		$app	=	JFactory :: getApplication();
		$model	=   $this->getModel( 'updates' );
		$data	=	$model->updateInit();
		
		echo json_encode( array( 'result' => 'success', 'message' => $data ) );
		$app->close();
	}
}