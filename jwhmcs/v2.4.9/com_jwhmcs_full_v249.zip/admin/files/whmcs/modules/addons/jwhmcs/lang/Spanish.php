<?php

$intlang = array(
		
		'shortcode'		=> 'es',
		
		'cfg_name'		=> 'J!WHMCS Integrator',
		'cfg_desc'		=> 'This module integates your WHMCS application with Joomla',
		
		'loginemail'	=> 'Nombre de usuario',
		
		'AUTH00P000'	=> "No se proporcionó una contraseña!",
		'AUTH00P001'	=> "Su cuenta no se puede encontrar en este momento.",
		'AUTH01P000'	=> "No se puede traer a su configuración de cuenta en línea!",
		'AUTH01P001'	=> "Ingresar negado! Su cuenta ha sido bloqueada o sea que no la ha activado todavía. ¿No has recibido un correo de activación y el enlace de validación?",
		'AUTH01P002'	=> "Nombre de usuario o contraseña es incorrecta o si no tienes una cuenta.",
		'AUTH01P003'	=> "No se puede traer a su configuración de cuenta en línea!",
		'AUTH01P004'	=> "Ingresar negado! Su cuenta ha sido bloqueada o sea que no la ha activado todavía. ¿No has recibido un correo de activación y el enlace de validación?",
		'AUTH01P010'	=> "Nombre de usuario o contraseña es incorrecta o si no tienes una cuenta.",
		'AUTH01P011'	=> "Nombre de usuario o contraseña es incorrecta o si no tienes una cuenta.",
		'AUTH01P021'	=> "Hubo un problema de unificación o desactivar esta función!",
		'AUTH01P022'	=> "Hubo un problema al guardar la configuración de la cuenta!",
		'AUTH01P023'	=> "Hubo un problema de unificación o desactivar esta función!",
		'AUTH01P024'	=> "Hubo un problema al guardar la configuración de la cuenta!",
		'AUTH01P030'	=> 'Nombre de usuario o contraseña es incorrecta o si no tienes una cuenta.',
		'AUTH02P000'	=> "No se puede traer a su configuración de cuenta en línea!",
		'AUTH02P001'	=> "Ingresar negado! Su cuenta está inactiva o ha sido bloqueada.",
		'AUTH02P002'	=> "Nombre de usuario o contraseña es incorrecta o si no tienes una cuenta.",
		'AUTH02P010'	=> "Nombre de usuario o contraseña es incorrecta o si no tienes una cuenta.",
		'AUTH02P011'	=> "Nombre de usuario o contraseña es incorrecta o si no tienes una cuenta."
);