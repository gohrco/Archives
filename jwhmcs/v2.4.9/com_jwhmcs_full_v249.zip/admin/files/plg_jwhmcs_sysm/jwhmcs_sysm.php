<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: jwhmcs_sysm.php 555 2012-09-06 02:10:32Z steven_gohigher $
 * @since      1.5.0
 * 
 * @desc		This plugin redirects links to option=com_user&task=register to
 * 				the J!WHMCS component (com_jwhmcs) user registration to request
 * 				information from end customer for WHMCS.
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.plugin.plugin');

$path	= JPATH_ADMINISTRATOR . '/components/com_jwhmcs/jwhmcs.helper.php';
if ( file_exists( $path ) ) require_once( $path );


/**
 * System - J!WHMCS Integrator plugin
 * @version		2.4.9
 *
 * @since		1.5.0
 * @author		Steven
 */
class plgSystemJwhmcs_sysm extends JPlugin
{

	/**
	 * Constructor method
	 * @access		public
	 * @version		2.4.9
	 * @param		object		- $subject: The object to observe
	 * @param 		array		- $config: An array that holds the plugin configuration
	 * 
	 * @since		1.5.0
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
	}
	
	
	/**
	 * onAfterInitialise event
	 * @desc		This is being used to intercept remember me cookie logins
	 * @access		public
	 * @version		2.4.9
	 * 
	 * @since		2.4.9
	 */
	public function onAfterInitialise()
	{
		$app = JFactory::getApplication();

		// No remember me for admin
		if ($app->isAdmin()) {
			return;
		}

		$user = JFactory::getUser();
		if ($user->get('guest'))
		{
			if ( version_compare( JVERSION, '1.6', 'ge' ) ) {
				$hash = JApplication::getHash('JLOGIN_REMEMBER');
			}
			else {
				jimport('joomla.utilities.utility');
				$hash = JUtility::getHash('JLOGIN_REMEMBER');
			}

			if ($str = JRequest::getString($hash, '', 'cookie', JREQUEST_ALLOWRAW | JREQUEST_NOTRIM))
			{
				jimport('joomla.utilities.simplecrypt');

				// Create the encryption key, apply extra hardening using the user agent string.
                // Since we're decoding, no UA validity check is required.
				if ( version_compare( JVERSION, '2.5.6', 'ge' ) ) {
					$privateKey = JApplication::getHash(@$_SERVER['HTTP_USER_AGENT']);
					
					$key = new JCryptKey('simple', $privateKey, $privateKey);
					$crypt = new JCrypt(new JCryptCipherSimple, $key);
					$str = $crypt->decrypt($str);
					$cookieData = @unserialize($str);
				}
				else {
					$key = JApplication::getHash(@$_SERVER['HTTP_USER_AGENT']);
					
					$crypt = new JSimpleCrypt($key);
					$str = $crypt->decrypt($str);
					$cookieData = @unserialize($str);
				}
				
				// Deserialized cookie could be any object structure, so make sure the
                // credentials are well structured and only have user and password.
                $credentials = array();
                $filter = JFilterInput::getInstance();
                $goodCookie = true;
                if (is_array($credentials)) {
                    if (isset($cookieData['username']) && is_string($cookieData['username'])) {
                        $credentials['username'] = $filter -> clean($cookieData['username'], 'username');
                    } else {
                        $goodCookie = false;
                    }
                    if (isset($cookieData['password']) && is_string($cookieData['password'])) {
                        $credentials['password'] = $filter -> clean($cookieData['password'], 'string');
                    } else {
                        $goodCookie = false;
                    }
                } else {
                    $goodCookie = false;
                }

				if (! $goodCookie || !$app->login($credentials, array('silent' => true, 'jwhmcsrememberme' => true ))) {
					$config = JFactory::getConfig();
					$cookie_domain = $config->get('cookie_domain', '');
					$cookie_path = $config->get('cookie_path', '/');
					// Clear the remember me cookie
					setcookie(
                        JApplication::getHash('JLOGIN_REMEMBER'), false, time() - 86400,
                        $cookie_path, $cookie_domain
                    );
				}
			}
		}
	}
	
	
	/**
	 * Triggered by onAfterRender event
	 * @access		public
	 * @version		2.4.9
	 * @version		1.5.3		- Oct 2009: added ability to redirect to user reg or edit page
	 * 
	 * @since		1.5.0
	 */
	public function onAfterRender()
	{
		$app	= & JFactory::getApplication();
		
		// Don't run if we are in backend
		if( $app->isAdmin() ) return;
		
		// If we can't load the helper then bail
		if (! class_exists( 'JwhmcsHelper' ) ) return;
		
		// Don't run if we can't find the product parameters
		if (! class_exists('JwhmcsParams') ) return;
		else $params = & JwhmcsParams::getInstance();
		
		// Don't run if product or user integration disabled
		if ((! $params->get( 'UserEnable' )) || (! $params->get( 'Enable' ))) return;
		
		$user 		= & JFactory::getUser();
		$option 	=   JwhmcsHelper :: get( 'option',	'',	'default',	'string' );		
		$task   	=   JwhmcsHelper :: get( 'task',	'', 'default',	'string' );
		$view		=   JwhmcsHelper :: get( 'view',	'', 'default',	'string' );
		$layout		=   JwhmcsHelper :: get( 'layout',	'',	'default',	'string' );
		$newlink	=   null;
		
		// Retrieve an array of Joomla oriented tasks
		$joomla		=   $this->_getJoomlaTasks();
		
		// ======================================
		// --------------------------------------
		// ======================================
		// Test for registration link and redirct
		if ( $option == $joomla->component && ( $task == $joomla->regtask || $view == $joomla->regview ) ) {
			// load J!WHMCS Registration page
			if ( $user->get( 'guest' ) ):
				if ( ( $params->get( 'RegMethod' )==1 ) && ( $params->get( 'NewregRedirect' ) != 1 ) ) {
					$uri = new JURI( $params->get( 'ApiUrl' ) );
					$uri->setPath( $uri->getPath() . '/register.php' );
					$newlink = $uri->toString();
				}
				elseif ($params->get( 'RegMethod' ) == 3 ) {
					// Use Itemid or view
					$menuitem	= "&" . ( $params->get( 'RegMenu' ) ? "Itemid={$params->get( 'RegMenu' )}" : '' );
					$newlink = JRoute::_('index.php?option=com_jwhmcs&view=register'.$menuitem, false);
				}
			endif;
		}
		// ======================================
		// --------------------------------------
		// ======================================
		// Test for editing the user profile form
		if ( $option == $joomla->component && ( 
				( $task == $joomla->edittask || $view == $joomla->editview ) || 
				( $view == $joomla->userview && $layout == $joomla->layoutform ) )
			) {
			// load J!WHMCS Edit page
			if (! $user->get('guest') ):
				if ( ( $params->get( 'RegMethod' ) == 1 ) || ( $params->get( 'RegMethod' ) == 3 ) ) {
					$uri = new JURI( $params->get( 'ApiUrl' ) );
					$uri->setPath( $uri->getPath() . '/clientarea.php' );
					$uri->setVar( 'action', 'details' );
					$newlink = $uri->toString();
				}
			endif;
		}
		// ======================================
		// --------------------------------------
		// ======================================
		// Test for resetting a password link
		if ( $option == $joomla->component && ( $task == $joomla->resettask || $view == $joomla->resetview ) ) {
			// load J!WHMCS Edit page
			if ( $user->get('guest') ):
				if ( ( ( $params->get( 'RegMethod' )== 1 ) && ( $params->get( 'PwresetRedirect' ) != 1 ) ) || ( $params->get( 'PwresetRedirect' ) == 2 ) ) {
					$uri = new JURI( $params->get( 'ApiUrl' ) );
					$uri->setPath( $uri->getPath() . '/pwreset.php' );
					$newlink = $uri->toString();
				}
				elseif ( ( $params->get( 'PwresetRedirect' ) == 1 ) && ( $params->get( 'PwresetMenu' ) ) && ( $params->get( 'PwresetMenu' ) != $Itemid ) ) {
					$newlink = JRoute::_( "index.php?Itemid={$params->get( 'PwresetMenu' )}", false );
					$mainframe->redirect( $newlink );
				}
			endif;
		}
		// ======================================
		
		if ( $newlink != null ) {
			$app->redirect( $newlink );
		}
		return;
	}
	
	
	/**
	 * Method to assemble Joomla tasks to check for based on version
	 * @access		private
	 * @version		2.4.9
	 * 
	 * @return		object
	 * @since		2.4.0
	 */
	private function _getJoomlaTasks()
	{
		$data	= array();
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) )
		{	// Joomla! 2.5 tasks
			$data['component']	= 'com_users';
			$data['regtask']	= 'registration';
			$data['regview']	= 'registration';
			$data['edittask']	= 'profile.edit';
			$data['editview']	= 'edit';
			$data['userview']	= 'user';
			$data['formlayout']	= 'form';
			$data['resettask']	= 'reset';
			$data['resetview']	= 'reset';
		}
		else
		{	// Joomla! 1.5 tasks
			$data['component']	= 'com_user';
			$data['regtask']	= 'register';
			$data['regview']	= 'register';
			$data['edittask']	= 'edit';
			$data['editview']	= 'edit';
			$data['userview']	= 'user';
			$data['formlayout']	= 'form';
			$data['resettask']	= 'reset';
			$data['resetview']	= 'reset';
		}
		
		return (object) $data;
	}
	
	
	/**
	 * Event called when gathering update sites to check for updates
	 * @access		public
	 * @version		2.4.9
	 *
	 * @return		array
	 * @since		2.4.0
	 */
	public function getUpdateSite()
	{
		return array(
				'extensionName'				=> 'plg_jwhmcs_sysm',
				'options' => array(
						'extensionTitle'	=> 'J!WHMCS Integrator System Plugin',
						'storage'			=> 'database',
						'storagePath'		=> null,
						'extensionType'		=> 'plugin',
						'updateUrl'			=> 'https://www.gohigheris.com/updates/jwhmcs/plugins/sysm'
				)
		);
	}
}