<?php
/**
 * Help Page View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: view.html.php 555 2012-09-06 02:10:32Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsViewHelppage
 * Extends:		JView
 * Purpose:		Used to view support options
 * As of:		version 2.1.0
\* ------------------------------------------------------------ */
class JwhmcsViewHelppage extends JwhmcsView
{
	/* ------------------------------------------------------------ *\
	 * Method:		display
	 * Purpose:		Assembles the page for the application to send to
	 * 				the user
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function display($tpl = null)
	{
		
		JToolBarHelper :: title( JText::_( 'COM_JWHMCS_HELPPAGE_VIEW_TITLE' ), 'helppage.png' );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JToolBarHelper :: custom( 'cpanel', 'star', 'star', 'J!WHMCS', false, false );
		}
		else {
			JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
		}
		
		parent::display($tpl);
	}
}