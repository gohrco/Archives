<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.4.9 ( $Id: router.php 450 2012-03-29 14:28:04Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      1.5.0
 * 
 * @desc       Router File:  Handles URL routing and parsing for Joomla
 *  
 */


/**
 * Router for building SEF link
 * @version		2.4.9
 * @param		array		- $query: contains an array of items to build the URL route from
 * 
 * @return		array		- $segments: contains an array of segments to build the URL with
 * @since		1.5.0
 */
function JwhmcsBuildRoute(&$query)
{
	$segments = array();
	
	// Catch Itemid and return
	if ( isset( $query['Itemid'] ) ) {
		if ( isset( $query['view'] ) ) unset( $query['view'] );
		return $segments;
	}
	
	// set defaults if not set
	if (! isset( $query['controller'] ) ) $query['controller'] = 'default';
	if (! isset( $query['view'] ) ) $query['view'] = 'default';
	if (! isset( $query['task'] ) ) $query['task'] = 'display';
	if (! isset( $query['layout'] ) ) $query['layout'] = 'default';
	
	$segments[0] = $query['controller'] . '.' . $query['task'];
	$segments[1] = $query['view'] . '.' . $query['layout'];
	
	$removeMe = array( "controller", "task", "view", "layout" );
	foreach ( $removeMe as $remove ) unset( $query[$remove] );
	
	// Query array:  required items up front (view / layout)
	$qarray	= array(	'token'			=> null,
						'jwhmcs'		=> null,
						'username'		=> null,
						'joomlaid'		=> null
	);
	
	foreach ( $qarray as $q => $d )
	{
		if ( isset( $query[$q] ) )
		{
			$segments[] = $query[$q];
			unset ( $query[$q] );
		}
		elseif (! is_null( $d ) )
		{
			$segments[] = $d;
		}
	}
	
	return $segments;
}


/**
 * Router for parsing SEF link
 * @version		2.4.9
 * @param		array		- $segments: contains an array of segments to assign to query variables
 * 
 * @return		array		- $vars: contains query variable assignments
 * @since		1.5.0
 */
function JwhmcsParseRoute($segments)
{
	$vars = array();
	
	if ( count( $segments ) == 0 )
		return $vars;	// Nothing to do
	
	$tmp = explode( ".", $segments[0] );
	
	$vars['controller']	= $tmp[0];
	$vars['task']		= ( count( $tmp ) == 1 ? "display" : $tmp[1] );
	array_shift( $segments );
	
	if ( count( $segments ) == 0 ) {
		$vars['view'] = $vars['controller'];
		$vars['layout'] = 'default';
		return $vars;	// All we can do
	}
	
	$tmp = explode( ".", $segments[0] );
	$vars['view']	= $tmp[0];
	$vars['layout']	= ( count( $tmp ) == 1 ? "default" : $tmp[1] );
	array_shift( $segments );
	
	// Variable array:  required items up front (view / layout)
	$varray	= array(	0	=> 'token',
						1	=> 'jwhmcs',
						2	=> 'username',
						3	=> 'joomlaid'
	);
	
	for ( $i=0; $i<count($segments); $i++ ) {
		if ( isset( $segments[$i] ) ) {
			$vars[$varray[$i]] = $segments[$i];
		}
	}
	
	return $vars;
}
