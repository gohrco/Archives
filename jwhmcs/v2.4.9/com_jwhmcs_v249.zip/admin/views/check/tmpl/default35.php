<?php  defined('_JEXEC') or die('Restricted access');


$data = $this->data;

?>

<script type="text/javascript">
	Joomla.submitbutton = function( task ) { Joomla.submitform(task, document.getElementById('item-form')); }
</script>

<div class="tabWrapper">
	<ul class="nav nav-tabs">
		<li class="active"><a data-toggle="tab" href="#joomla_check"><?php echo JText::_('COM_JWHMCS_CHECK_VIEW_TAB_JOOMLA'); ?></a></li>
		<li><a data-toggle="tab" href="#plugin_check"><?php echo JText :: _( 'COM_JWHMCS_CHECK_VIEW_TAB_PLUGIN' ); ?></a></li>
		<li><a data-toggle="tab" href="#whmcs_check"><?php echo JText :: _( 'COM_JWHMCS_CHECK_VIEW_TAB_WHMCS' ); ?></a></li>
		<li><a data-toggle="tab" href="#product_check"><?php echo JText :: _( 'COM_JWHMCS_CHECK_VIEW_TAB_PRODUCT' ); ?></a></li>
	</ul>
	
	<div class="tab-content">
		
<?php
//		=============== JOOMLA CHECK BELOW =================
?>
		<div id="joomla_check" class="tab-pane active">
			
			<div class="row-fluid">
				<div class="span8">
					
					<table class="table">
						
						<tbody>
							<tr>
								<td>
									<label><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_COMPONENTINSTALLED" ); ?></label>
								</td>
								<td class="stepIcon">
									<div class="ajaxStatus">
									<div class="ajaxStatus" id="checkStep10"></div></div>
								</td>
								<td style="width:70%">
									<div class="ajaxMessage" id="checkMessage10">&nbsp;</div>
								</td>
							</tr>
							<tr>
								<td>
									<label><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_HIDDENMENU" ); ?></label>
								</td>
								<td class="stepIcon">
									<div class="ajaxStatus">
									<div class="ajaxStatus" id="checkStep20"></div></div>
								</td>
								<td style="width:70%">
									<div class="ajaxMessage" id="checkMessage20">&nbsp;</div>
								</td>
							</tr>
							<tr>
								<td>
									<label><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_CLIENTMENU" ); ?></label>
								</td>
								<td class="stepIcon">
									<div class="ajaxStatus">
									<div class="ajaxStatus" id="checkStep30"></div></div>
								</td>
								<td style="width:70%">
									<div class="ajaxMessage" id="checkMessage30">&nbsp;</div>
								</td>
							</tr>
						</tbody>
						
					</table>
					
				</div>
				<div class="span4">
					<div class="cpanel">
						<a class="btn span1" href="#" onclick="beginCheck(10,30,this); return false;" id="joomla_check_href1">
							<img src="<?php echo JURI::root(); ?>media/com_jwhmcs/icons/j-48-checkrun.png" border="0" alt="<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_BEGINCHECK" ); ?>" />
							<span class="linktitle"><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_BEGINCHECK" ); ?></span>
						</a>
					</div>
				</div>
			</div>
			
		</div>
<?php
//		=============== PLUGIN CHECK BELOW =================
?>
		<div id="plugin_check" class="tab-pane">
			
			<div class="row-fluid">
				<div class="span8">
					
					<table class="table">
						
						<tbody>
							<tr>
								<td>
									<label><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_PLUGINAUTH" ); ?></label>
								</td>
								<td class="stepIcon">
									<div class="ajaxStatus">
									<div class="ajaxStatus" id="checkStep100"></div></div>
								</td>
								<td style="width:70%">
									<div class="ajaxMessage" id="checkMessage100">&nbsp;</div>
								</td>
							</tr>
							<tr>
								<td>
									<label><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_PLUGINSYSM" ); ?></label>
								</td>
								<td class="stepIcon">
									<div class="ajaxStatus">
									<div class="ajaxStatus" id="checkStep110"></div></div>
								</td>
								<td style="width:70%">
									<div class="ajaxMessage" id="checkMessage110">&nbsp;</div>
								</td>
							</tr>
							<tr>
								<td>
									<label><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_PLUGINLANG" ); ?></label>
								</td>
								<td class="stepIcon">
									<div class="ajaxStatus">
									<div class="ajaxStatus" id="checkStep120"></div></div>
								</td>
								<td style="width:70%">
									<div class="ajaxMessage" id="checkMessage120">&nbsp;</div>
								</td>
							</tr>
							<tr>
								<td>
									<label><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_PLUGINUSER" ); ?></label>
								</td>
								<td class="stepIcon">
									<div class="ajaxStatus">
									<div class="ajaxStatus" id="checkStep130"></div></div>
								</td>
								<td style="width:70%">
									<div class="ajaxMessage" id="checkMessage130">&nbsp;</div>
								</td>
							</tr>
						</tbody>
						
					</table>
					
				</div>
				<div class="span4">
					<div class="cpanel">
						<a class="btn span1" href="#" onclick="beginCheck(100,130,this); return false;" id="plugin_check_href1">
							<img src="<?php echo JURI::root(); ?>media/com_jwhmcs/icons/j-48-checkrun.png" border="0" alt="<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_BEGINCHECK" ); ?>" />
							<span class="linktitle"><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_BEGINCHECK" ); ?></span>
						</a>
					</div>
				</div>
			</div>
			
		</div>
<?php
//		=============== WHMCS CHECK BELOW =================
?>
		<div id="whmcs_check" class="tab-pane">
			
			<div class="row-fluid">
				<div class="span8">
					
					<table class="table">
						
						<tbody>
							<tr>
								<td>
									<label><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_WHMCSROOT" ); ?></label>
								</td>
								<td class="stepIcon">
									<div class="ajaxStatus">
									<div class="ajaxStatus" id="checkStep200"></div></div>
								</td>
								<td style="width:70%">
									<div class="ajaxMessage" id="checkMessage200">&nbsp;</div>
								</td>
							</tr>
							<tr>
								<td>
									<label><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_WHMCSAPI" ); ?></label>
								</td>
								<td class="stepIcon">
									<div class="ajaxStatus">
									<div class="ajaxStatus" id="checkStep210"></div></div>
								</td>
								<td style="width:70%">
									<div class="ajaxMessage" id="checkMessage210">&nbsp;</div>
								</td>
							</tr>
							<tr>
								<td>
									<label><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_WHMCSDB" ); ?></label>
								</td>
								<td class="stepIcon">
									<div class="ajaxStatus">
									<div class="ajaxStatus" id="checkStep220"></div></div>
								</td>
								<td style="width:70%">
									<div class="ajaxMessage" id="checkMessage220">&nbsp;</div>
								</td>
							</tr>
						</tbody>
						
					</table>
					
				</div>
				<div class="span4">
					<div class="cpanel">
						<a class="btn span1" href="#" onclick="beginCheck(200,220,this); return false;" id="whmcs_check_href1">
							<img src="<?php echo JURI::root(); ?>media/com_jwhmcs/icons/j-48-checkrun.png" border="0" alt="<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_BEGINCHECK" ); ?>" />
							<span class="linktitle"><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_BEGINCHECK" ); ?></span>
						</a>
					</div>
				</div>
			</div>
			
		</div>
<?php
//		=============== PRODUCT CHECK BELOW =================
?>
		<div id="product_check" class="tab-pane">
			
			<div class="row-fluid">
				<div class="span8">
					
					<table class="table">
						
						<tbody>
							<tr>
								<td>
									<label><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_PRODLIC" ); ?></label>
								</td>
								<td class="stepIcon">
									<div class="ajaxStatus">
									<div class="ajaxStatus" id="checkStep300"></div></div>
								</td>
								<td style="width:70%">
									<div class="ajaxMessage" id="checkMessage300">&nbsp;</div>
								</td>
							</tr>
							<tr>
								<td>
									<label><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_APICNXN" ); ?></label>
								</td>
								<td class="stepIcon">
									<div class="ajaxStatus">
									<div class="ajaxStatus" id="checkStep310"></div></div>
								</td>
								<td style="width:70%">
									<div class="ajaxMessage" id="checkMessage310">&nbsp;</div>
								</td>
							</tr>
						</tbody>
						
					</table>
						
				</div>
				<div class="span4">
					<div class="cpanel">
						<a class="btn span1" href="#" onclick="beginCheck(300,310,this); return false;" id="product_check_href1">
							<img src="<?php echo JURI::root(); ?>media/com_jwhmcs/icons/j-48-checkrun.png" border="0" alt="<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_BEGINCHECK" ); ?>" />
							<span class="linktitle"><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_BEGINCHECK" ); ?></span>
						</a>
					</div>
				</div>
			</div>
			
		</div>
<?php
//		=============== END CHECKS =================
?>
	</div>
	
</div>

<form action="index.php" method="post" name="adminForm" id="item-form">
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="thisUrl" id="thisUrl" value="<?php echo $data->thisUrl; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="controller" value="check" />
<input type="hidden" name="step" id="step" value="10" />
<input type="hidden" name="laststep" id="laststep" value="" />
</form>