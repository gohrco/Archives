<?php defined('_JEXEC') or die('Restricted access');

$isNew	= (isset($this->data->id)?($this->data->id < 1?true:false):true);

?>

<form action="index.php" method="post" id="adminForm" name="adminForm" class="form-validate">
	<table class="admintable" cellspacing="1">
		<tr>
			<td width="200" align="right" class="key">
				<label for="name">
					<?php
					$title = JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_NAME" );
					echo JHTML::_('tooltip', null, $title, null, $title); ?>
				</label>
			</td>
			<td>
				<div class="jwhmcs-fieldwrap">
					<input class="validate-text required" type="text" name="form[name]" id="name" size="40" maxlength="255" value="<?php echo $isNew?'':$this->data->name; ?>" /><br />
					<?php echo $title; ?>
				</div>
			</td>
		</tr>
		<tr>
			<td width="200" align="right" class="key">
				<label for="username">
					<?php
					$title = JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_USERNAME" );
					echo JHTML::_('tooltip', null, $title, null, $title); ?>
				</label>
			</td>
			<td>
				<div class="jwhmcs-fieldwrap">
					<input class="text_area required" type="text" name="form[username]" id="username" size="40" maxlength="255" value="<?php echo $isNew?'':$this->data->username; ?>" /><br />
					<?php echo $title; ?>
				</div>
			</td>
		</tr>
		<tr>
			<td width="200" align="right" class="key">
				<label for="email">
					<?php
					$title = JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_EMAIL" );
					echo JHTML::_('tooltip', null, $title, null, $title); ?>
				</label>
			</td>
			<td>
				<div class="jwhmcs-fieldwrap">
					<input class="text_area required" type="text" name="form[emaildis]" id="email" size="40" maxlength="255" value="<?php echo $this->data->email; ?>" disabled /><br />
					<?php echo $title; ?>
				</div>
			</td>
		</tr>
		<tr>
			<td width="200" align="right" class="key">
				<label for="password">
					<?php
					$title = JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_TMPPASS" );
					echo JHTML::_('tooltip', null, $title, null, $title); ?>
				</label>
			</td>
			<td>
				<div class="jwhmcs-fieldwrap">
					<input class="text_area required" type="text" name="form[password]" id="password" size="40" maxlength="255" value="temppass" /><br />
					<?php echo $title; ?>
				</div>
				<div class="jwhmcs-fieldwrap">
					<input class="text_area required" type="text" name="form[password2]" id="password2" size="40" maxlength="255" value="temppass" /><br />
					<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_CONPASS" ); ?>
				</div>
			</td>
		</tr>
		<tr>
			<td width="200" align="right" class="key">
				<label for="group">
					<?php
					$title = JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_GROUP" );
					echo JHTML::_('tooltip', null, $title, null, $title); ?>
				</label>
			</td>
			<td>
				<div class="jwhmcs-fieldwrap">
					<?php echo $this->data->gidtypes; ?><br />
					<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_SELGROUP" ); ?>
				</div>
			</td>
		</tr>
	</table>
	<input type="hidden" name="whmcsid" value="<?php echo $this->data->wid; ?>" />
	<input type="hidden" name="joomlaid" value="<?php echo $this->data->id; ?>" />
	<input type="hidden" name="option" value="com_jwhmcs" />
	<input type="hidden" name="task" value="" />
	<?php if ($this->data->contact): ?>
	<input type="hidden" name="contact" value="1" />
	<?php endif; ?>
	<input type="hidden" name="subtask" value="<?php echo JRequest::getVar( 'task' ); ?>" />
	<input type="hidden" name="controller" value="usermgr" />
	<input type="hidden" name="form[email]" value="<?php echo $this->data->email; ?>" />
	<?php echo JHTML::_( 'form.token' ); ?>
</form>
<div class="clr"></div>