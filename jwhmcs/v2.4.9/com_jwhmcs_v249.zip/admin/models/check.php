<?php
/**
 * Group Management Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: check.php 555 2012-09-06 02:10:32Z steven_gohigher $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * Used to check the installation of J!WHMCS Integrator
 * @version		2.4.9
 *
 * @author		Steven
 * @since		1.5.1
 */
class JwhmcsModelCheck extends JwhmcsModel
{
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		2.4.9
	 * 
	 * @since		2.1.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Retrieves the data for the model
	 * @access		public
	 * @version		2.4.9
	 * 
	 * @return		object
	 * @since		2.1.0
	 */
	public function getData()
	{
		$params = & JwhmcsParams::getInstance();
		$uri	=   JURI::getInstance();
		
		$data	=   new stdClass();
		$data->thisUrl = $uri->current();
		
		return $data;
	}
	
	
	/**
	 * Method to check various steps by ajax
	 * @access		public
	 * @version		2.4.9
	 * @param		integer		- $step: indicates which step the process is at
	 * 
	 * @return		array
	 * @since		2.1.0
	 */
	public function process($step = 10)
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params = & JwhmcsParams::getInstance();
		$uri	= & JURI::getInstance();
		$url	=   $uri->toString(array('scheme', 'host', 'path'));
		
		$data['nextstep'] = $step + 10;
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$pluginquery	= "SELECT `extension_id`, `enabled`, `params`, `ordering` FROM #__extensions WHERE `element` = '%s' AND `folder` = '%s' AND `type` = 'plugin'";
		}
		else {
			$pluginquery	= "SELECT `id` as 'extension_id', `published` as 'enabled', `params`, `ordering` FROM #__plugins WHERE `element` = '%s' AND `folder` = '%s'";
		}
		
		switch($step):
		/* ----------------------------------------------------------------- STEP  10 *\
		 * CHECK INSTALLATION - Component Installed
		\* -------------------------------------------------------------------------- */
		case 10:
			// Obviously if we are here the component is at least installed - future revisions may include health check
			$data['status'] = 1;
			break;
		
		/* ----------------------------------------------------------------- STEP  20 *\
		 * CHECK INSTALLATION - Hidden Menu created
		\* -------------------------------------------------------------------------- */
		case 20:
			$query	= "SELECT `id` FROM `#__menu_types` WHERE `menutype` = 'jwhmcs-hidden'";
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 2;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_("COM_JWHMCS_CHECK_MODEL_FIXIT") ."</a></div>" . JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_20_HIDMENU" );
			}
			else {
				$data['status'] = 1;
			}
			break;
		
		/* ----------------------------------------------------------------- STEP 30 *\
		 * CHECK INSTALLATION - Check API Connection
		\* -------------------------------------------------------------------------- */
		case 30:
			$query	= "SELECT `id` FROM `#__menu_types` WHERE `menutype` = 'client-menu'";
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 2;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_("COM_JWHMCS_CHECK_MODEL_FIXIT") ."</a></div>" . JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_30_CLIENTMENU" );
			}
			else {
				$data['status'] = 1;
			}
			break;
			
		/* ----------------------------------------------------------------- STEP 100 *\
		 * CHECK INSTALLATION - Authentication Plugin installed and on
		\* -------------------------------------------------------------------------- */
		case 100:
			$query	= sprintf( $pluginquery, "jwhmcs_auth", "authentication" );
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 0;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_("COM_JWHMCS_CHECK_MODEL_FIXIT") ."</a></div>" . JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_100_AUTHPLG00" );
			}
			elseif ($result['enabled'] == '0') {
				$data['status'] = 2;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_("COM_JWHMCS_CHECK_MODEL_FIXIT") ."</a></div>" . JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_100_AUTHPLG02" );
			}
			elseif ( $result['ordering'] != '1' ) {
				$data['status'] = 3;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_( "COM_JWHMCS_CHECK_MODEL_FIXIT" ) . "</a></div>" . JText :: _( "COM_JWHMCS_CHECK_MODEL_PROCESS_100_AUTHPLG03" );
			}
			else {
				$data['status'] = 1;
			}
			break;
			
		/* ----------------------------------------------------------------- STEP 110 *\
		 * CHECK INSTALLATION - System Plugin installed and on
		\* -------------------------------------------------------------------------- */
		case 110:
			$query	= sprintf( $pluginquery, "jwhmcs_sysm", "system" );
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 0;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_("COM_JWHMCS_CHECK_MODEL_FIXIT") ."</a></div>" . JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_110_SYSMPLG00" );
			}
			elseif ($result['enabled'] == '0') {
				$data['status'] = 2;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_("COM_JWHMCS_CHECK_MODEL_FIXIT") ."</a></div>" . JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_110_SYSMPLG02" );
			}
			elseif ( $result['ordering'] != '1' ) {
				$data['status'] = 3;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_( "COM_JWHMCS_CHECK_MODEL_FIXIT" ) . "</a></div>" . JText :: _( "COM_JWHMCS_CHECK_MODEL_PROCESS_110_SYSMPLG03" );
			}
			else {
				$data['status'] = 1;
			}
			break;
			
		/* ----------------------------------------------------------------- STEP 120 *\
		 * CHECK INSTALLATION - System Language Plugin installed and on
		\* -------------------------------------------------------------------------- */
		case 120:
			$query	= sprintf( $pluginquery, "jwhmcs_sysmlang", "system" );
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 2;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_("COM_JWHMCS_CHECK_MODEL_FIXIT") ."</a></div>" . JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_120_SLNGPLG00" );
			}
			elseif ($result['enabled'] == '0') {
				$data['status'] = 2;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_("COM_JWHMCS_CHECK_MODEL_FIXIT") ."</a></div>" . JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_120_SLNGPLG02" );
			}
			else {
				$data['status'] = 1;
			}
			break;
		
		/* ----------------------------------------------------------------- STEP 130 *\
		 * CHECK INSTALLATION - User Plugin installed and on
		\* -------------------------------------------------------------------------- */
		case 130:
			$query	= sprintf( $pluginquery, "jwhmcs_user", "user" );
			$db->setQuery($query);
			$result	= $db->loadAssoc();
			
			if (!$result) {
				$data['status'] = 2;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_("COM_JWHMCS_CHECK_MODEL_FIXIT") ."</a></div>" . JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_130_USERPLG00" );
			}
			elseif ($result['enabled'] == '0') {
				$data['status'] = 2;
				$data['message'][] = "<div class='checkFix'><a href='#' onclick='beginFix({$step}); return false;'>" . JText::_("COM_JWHMCS_CHECK_MODEL_FIXIT") ."</a></div>" . JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_130_USERPLG02" );
			}
			else {
				$data['status'] = 1;
			}
			break;
		
		/* ----------------------------------------------------------------- STEP 200 *\
		 * CHECK INSTALLATION - WHMCS Root Files Installed
		\* -------------------------------------------------------------------------- */
		case 200:
			$jcurl->setCall();
			$url = $params->get( 'ApiUrl' ).'/jwhmcs.php?task=installCheck&check=root&joomadmin='.$params->get( 'Secret' );
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
			$jcurl->setRoot('root');
			$result = $jcurl->loadResult();
			
			if ($result['result'] == 'success') {
				$data['status'] = 1;
			}
			else {
				$message = JText::sprintf( "COM_JWHMCS_CHECK_MODEL_PROCESS_200_WHMCSROOT", $params->get( 'ApiUrl' ) );
				$data['status'] = 0;
				$data['message'][] = $message;
			}
			break;
		
		/* ----------------------------------------------------------------- STEP 210 *\
		 * CHECK INSTALLATION - WHMCS Hook Files Installed // OLD
		\* -------------------------------------------------------------------------- */
		case 201:
			$jcurl->setCall();
			$url = $params->get( 'ApiUrl' ).'/jwhmcs.php?task=installCheck&check=hook&joomadmin='.$params->get( 'Secret' );
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
			$jcurl->setRoot('root');
			$result = $jcurl->loadResult();
			
			if ($result['result'] == 'success') {
				$data['status'] = 1;
			}
			else {
				$message	= JText::sprintf( "COM_JWHMCS_CHECK_MODEL_PROCESS_210_WHMCSHOOK00", $params->get( 'ApiUrl' ) );
				if ($result['message'] & 1)
					$message .= JText::sprintf( "COM_JWHMCS_CHECK_MODEL_PROCESS_210_WHMCSHOOK01", "jwhmcs.php" );
				if ($result['message'] & 2)
					$message .= JText::sprintf( "COM_JWHMCS_CHECK_MODEL_PROCESS_210_WHMCSHOOK01", "jwhmcs-lang.php" );
				if (!$result['message'])
					$message .= JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_210_WHMCSHOOK02" );
				
				$data['status'] = 0;
				$data['message'][] = $message;
			}
			break;
		
		/* ----------------------------------------------------------------- STEP 210 *\
		 * CHECK INSTALLATION - WHMCS API Files Installed
		\* -------------------------------------------------------------------------- */
		case 210:
			$jcurl->setCall();
			$url = $params->get( 'ApiUrl' ).'/jwhmcs.php?task=installCheck&check=api&joomadmin='.$params->get( 'Secret' );
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
			$jcurl->setRoot('root');
			$result = $jcurl->loadResult();
			
			if ($result['result'] == 'success') {
				$data['status'] = 1;
			}
			else {
				$message	= JText::sprintf( "COM_JWHMCS_CHECK_MODEL_PROCESS_220_WHMCSAPI00", $params->get( 'ApiUrl' ) );
				if ($result['message'] & 1)
					$message .= JText::sprintf( "COM_JWHMCS_CHECK_MODEL_PROCESS_220_WHMCSAPI01", "jwhmcsconfig.php" );
				if ($result['message'] & 2)
					$message .= JText::sprintf( "COM_JWHMCS_CHECK_MODEL_PROCESS_220_WHMCSAPI01", "jwhmcsgetsettings.php" );
				if (!$result['message'])
					$message .= JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_220_WHMCSAPI02" );
				
				$data['status'] = 0;
				$data['message'][] = $message;
			}
			break;
			
		/* ----------------------------------------------------------------- STEP 230 *\
		 * CHECK INSTALLATION - WHMCS Template Files Installed // OLD
		\* -------------------------------------------------------------------------- */
		case 202:
			$jcurl->setCall();
			$url = $params->get( 'ApiUrl' ).'/jwhmcs.php?task=installCheck&check=template&joomadmin='.$params->get( 'Secret' );
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->set(CURLOPT_FOLLOWLOCATION, false);
			$jcurl->setRoot('root');
			$result = $jcurl->loadResult();
			
			if ($result['result'] == 'success') {
				$data['status'] = 1;
			}
			else {
				$message	= JText::sprintf( "COM_JWHMCS_CHECK_MODEL_PROCESS_230_WHMCSTPL00", $params->get( 'ApiUrl' ) );
				if ($result['message'] & 1)
					$message .= JText::sprintf( "COM_JWHMCS_CHECK_MODEL_PROCESS_230_WHMCSTPL01", "jwhmcs-default" );
				if ($result['message'] & 2)
					$message .= JText::sprintf( "COM_JWHMCS_CHECK_MODEL_PROCESS_230_WHMCSTPL01", "jwhmcs-portal" );
				if (!$result['message'])
					$message .= JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_230_WHMCSTPL02" );
				
				$message .= JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_230_WHMCSTPL03" );
				$data['status'] = 2;
				$data['message'][] = $message;
			}
			break;
			
		/* ----------------------------------------------------------------- STEP 300 *\
		 * CHECK INSTALLATION - Check License
		\* -------------------------------------------------------------------------- */
		case 220:
			$jcurl->setAction('jwhmcsconfig', array("init" => "2" ) );
			$whmcs	= $jcurl->loadResult();
			
			$data['status'] = 0;
			if ( $jcurl->info['http_code'] != "200" ) {
				$data['message'][] = JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_240_NORESPONSE" );
			}
			elseif ( ( $whmcs['result'] == "error" ) AND ( $whmcs['message'] == "Command Not Found" ) ) {
				$data['message'][] = JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_240_COMMANDNOTFOUND" );
			}
			elseif ( $whmcs['result'] == "error" ) {
				$data['message'][] = JText::_( $whmcs['message'] );
			}
			else {
				$data['status'] = 1;
				$data['message'][] = JText::_( $whmcs['message'] );
			}
			
			unset ($whmcs);
			
			break;
			
		/* ----------------------------------------------------------------- STEP 300 *\
		 * CHECK INSTALLATION - Check License
		\* -------------------------------------------------------------------------- */
		case 300:
			$license = $this->checkLicense();
			
			if ($license['return'] == 'Active') {
				$data['status'] = 1;
			}
			elseif (($license['return'] == 'Expired') && ($license['valid'] == 1)) {
				$data['status'] = 2;
				$data['message'] = JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_300_LICCHECK02" );
			}
			elseif (isset($license['response'])) {
				$data['status'] = 0;
				$data['message'] = "<div class='checkFix'><a href='{$url}?option=com_jwhmcs&controller=install&task=apiconxn'>" . JText::_("COM_JWHMCS_CHECK_MODEL_FIXIT") ."</a></div>" . JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_300_LICCHECK01" );
			}
			else {
				$data['status'] = 0;
				$data['message'] = "<div class='checkFix'><a href='{$url}?option=com_jwhmcs&controller=install&task=license'>" . JText::_("COM_JWHMCS_CHECK_MODEL_FIXIT") ."</a></div>" . JText::_( "COM_JWHMCS_CHECK_MODEL_PROCESS_300_LICCHECK00" );
			}
			break;
			
		/* ----------------------------------------------------------------- STEP 310 *\
		 * CHECK INSTALLATION - Check API Connection
		\* -------------------------------------------------------------------------- */
		case 310:
			$apichck = $this->getApiConnection();
			
			if ($apichck['result'] == 'success') {
				$data['status'] = 1;
			}
			else {
				$data['status'] = 0;
				$data['message'] = "<div class='checkFix'><a href='{$url}?option=com_jwhmcs&controller=install&task=apiconxn'>" . JText::_("COM_JWHMCS_CHECK_MODEL_FIXIT") ."</a></div>{$apichck['message']}";
			}
			break;
		endswitch;
		
		return $data;
	}
	
	
	/**
	 * Method to attempt to fix the installation issue discovered
	 * @access		public
	 * @version		2.4.9
	 * @param		integer		- $step: indicates which step of the process we are trying to fix
	 * 
	 * @return		result of process
	 * @since		2.1.0
	 */
	public function fixinstall($step = 10)
	{
		$db			= & JFactory::getDBO();
		$jcurl		= & JwhmcsCurl::getInstance();
		$params		= & JwhmcsParams::getInstance();
		$install	= & JwhmcsModel::getInstance('interview', 'JwhmcsModel');
		
		$result		=   $install->process( $step );
		$data		=   $this->process( $step );
		
		return $data;
	}
	
	
	/* ----------------------------------------- *\
	 *              SUB FUNCTIONS                *
	\* ----------------------------------------- */
	
	
}