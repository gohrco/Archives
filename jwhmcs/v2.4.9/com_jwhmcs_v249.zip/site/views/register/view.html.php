<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.4.9 ( $Id: view.html.php 555 2012-09-06 02:10:32Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      2.1.0
 * 
 * @desc       Register View:  Handles the view for the integrated registration
 *  
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
jimport( "joomla.html.parameter" );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * JwhmcsViewRegister View Script
 * @version		2.4.9
 * 
 * @since		2.1.0
 * @author		Steven
 */
class JwhmcsViewRegister extends JwhmcsViewExt
{
	/**
	 * Called by the task to render view to user
	 * @access		public
	 * @version		2.4.9
	 * @param		unknown		- $tpl: presumably used by Joomla
	 * 
	 * @since		2.3.1
	 */
	public function display($tpl = null)
	{
		// Load data for register layout
		$app		= & JFactory::getApplication();
		$tmplparams	=   $app->getParams();
		$pathway	= & $app->getPathway();
		$params		= & JwhmcsParams::getInstance();
		
		$orig		= & JURI::getInstance();
		$config		= & JFactory::getConfig();
		
		// We use 15 to indicate J!15 version
		$v			=   version_compare( JVERSION, '1.6.0', 'ge' ) ? '' : '15';
		
		/**
		 * Bug 26 - originally to resolve the URL issue for ajax, now requires the proper scheme to be set 
		 */
		if ( $config->get( 'live_site' ) == null ) {
			$uri	= & JURI::getInstance();
		} else {
			$uri	= & JURI::getInstance( $config->get('live_site') );
		}
		$params->set( 'scheme', $uri->getScheme() );
		/**
		 * Bug 26 End
		 */
		
		$uri->setScheme( $orig->getScheme() );
		$thisurl	=   rtrim( $uri->toString( array( 'scheme', 'host', 'path' ) ), "/" ) . "/";
		
		
		// Bug 33 Fix
		$thisurl	= JRoute::_( 'index.php?option=com_jwhmcs&controller=register&task=validInfo' );
		$thisurl	= ( strpos($thisurl, '?') !== false ? $thisurl . '&' : $thisurl . '?' );
		// Bug 33 End
		
		$document	= & JFactory::getDocument();
		$model		= & $this->getModel();
		$user		= & JFactory::getUser();
		
		// Page Title
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			$menups =   $app->getParams();
		}
		else {
			$menus	= & JSite::getMenu();
			$menu	=   $menus->getActive();
			$menups	=   new JParameter( $menu->params );
		}
		
		if ( $menups->get( 'page_title' ) ) $document->setTitle( $menups->get( 'page_title' ) );
		$pathway->addItem( JText::_( 'New' ));
		
		$user 	= & JFactory::getUser();
		$post	=   $this->get( "post" );
		
		// Build Country Select
		$country	= JHtml::_('select.genericlist', JwhmcsHelper::buildCountries(), 'country', null, 'value', 'text', ( ( $ctry = JwhmcsHelper :: get( 'country' ) ) ? $ctry : $params->get( 'WhmcsDefaultcountry' ) ) );
		
		// Load the form validation behavior
		JHtml::_( 'behavior.formvalidation' );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JwhmcsHelper :: addMedia( 'ajax35/js' );
			JwhmcsHelper :: addMedia( "register35/css" );
		}
		else {
			JHtml::_( 'behavior.mootools' );
			JHtml::script( "jquery.js", rtrim( $params->get( 'ApiUrl' ), "/" ).'/includes/jscript/' );
			JwhmcsHelper :: addMedia( 'noconflict/js' );
			JwhmcsHelper :: addMedia( 'common/js' );
			JwhmcsHelper :: addMedia( 'ajax/js' );
			JwhmcsHelper :: addMedia( "register{$v}/css" );
		}
		
		
		
		$tmplparams->set( 'RecaptchaEnable',	$params->get( 'RecaptchaEnable' ));
		$tmplparams->set( 'RecaptchaTheme',		$params->get( 'RecaptchaTheme' ));
		$tmplparams->set( 'RecaptchaLang',		$params->get( 'RecaptchaLang' ));
		$tmplparams->set( 'RecaptchaPublickey',	$params->get( 'RecaptchaPublickey' ));
		
		$this->assignRef( 'tmplparams',	$tmplparams );
		$this->assignRef( 'params',		$params );
		$this->assignRef( 'user',		$user );
		$this->assignRef( 'post',		$post );
		$this->assignRef( 'tmp', 		$params );
		$this->assignRef( 'thisurl',	$thisurl );
		
		parent::display($tpl);
	}
}