<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.4.4 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.3.0
 * 
 * @desc       Installation Script
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( "joomla.filesystem.file" );


if (! version_compare( JVERSION, '1.6.0', 'ge' ) )
{
	if (! function_exists( 'com_install' ) )
	{
		function com_install()
		{
			$app	= & JFactory :: getApplication();
			$app->redirect( 'index.php?option=com_jwhmcs&controller=install&task=interview' );
		}
	}
}
