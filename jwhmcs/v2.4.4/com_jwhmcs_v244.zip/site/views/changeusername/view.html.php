<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.4.4 ( $Id: view.html.php 469 2012-05-04 20:04:56Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      2.1.0
 * 
 * @desc       Change Username View:  This file handles requesting the username from new registrants
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * Changeusername view handles the view assembly for the user
 * @version 2.3.0
 * 
 * @since	2.1.0
 * @author	Steven
 */
class JwhmcsViewChangeusername extends JView
{
	/**
	 * Builds the view from the display task for the user
	 * @access		public
	 * @version		2.4.4
	 * @param		string		$tpl - presumably a template name, never used
	 * 
	 * @since		2.1.0
	 */
	public function display($tpl = null)
	{
		$app		= & JFactory::getApplication();
		$uri		= & JURI::getInstance();
		$model		= & $this->getModel();
		$user		= & JFactory::getUser();
		$data		= & $model->getData();
		
		// Verify that the user isn't a guest
		if ( $user->get( 'guest' ) )
			$data = false;
		
		// Redirect if no data or user is a guest
		if (! $data ) {
			$app->redirect( $uri->base() );
		}
		
		JwhmcsHelper :: addMedia ( 'ajax/js' );
		JwhmcsHelper :: addMedia ( 'signup/css' );
		JwhmcsHelper :: addMedia ( 'register/css' );
		
		$this->assignRef('uriString',	$uri->toString( array( 'scheme', 'host', 'path' ) ) );
		$this->assignRef('data', $data);
		
		parent::display($tpl);
	}
}