<?php
/**
 * WHMCS User Synchrization View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: view.html.php 469 2012-05-04 20:04:56Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * View for the check installation of J!WHMCS Integrator
 * @version		2.4.4
 *
 * @author		Steven
 * @since		2.0.0
 */
class JwhmcsViewCheck extends JView
{
	/**
	 * Display view
	 * @access		public
	 * @version		2.4.4
	 * @param		unknown		- $tpl: override to pass for tpl
	 *
	 * @since		2.0.0
	 */
	public function display($tpl = null)
	{
		$params = & JwhmcsParams::getInstance();
		$model	= & $this->getModel('check');
		$data	=   $model->getData();
		$v		=   version_compare( JVERSION, '1.6.0', 'ge' ) ? '25' : '15';
		
		JwhmcsToolbar :: build( 'check' );
		
		JwhmcsHelper :: addMedia( 'common/js' );
		JwhmcsHelper :: addMedia( 'ajax/js' );
		JwhmcsHelper :: addMedia( "check/js" );
		JwhmcsHelper :: addMedia( 'icons/css' );
		JwhmcsHelper :: addMedia( "check{$v}/css" );
		
		$this->assignRef('data', $data);
		$this->assignRef('params', $params);
		parent::display($tpl);
	}
}