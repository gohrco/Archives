<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.4.4 ( $Id: jwhmcs.php 469 2012-05-04 20:04:56Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      1.5.0
 * 
 * @desc       Primary File:  Called directly by Joomla for component handling purposes
 *  
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Require the base controller
require_once (JPATH_COMPONENT.DS.'controller.php');
require_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'model.php' );

// Helper
$path = JApplicationHelper :: getPath( 'helper', 'com_jwhmcs' );
require_once( $path );

// Require specific controller if requested
$controller = JRequest::getWord('controller', 'default');
require_once (JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php');

// Create the controller
$classname	= 'JwhmcsController'.$controller;
$controller = new $classname();

// Perform the Request task
$controller->execute( JRequest::getWord('task'));

// Redirect if set by the controller
$controller->redirect();

?>
