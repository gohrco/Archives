

CREATE TABLE IF NOT EXISTS `mod_jwhmcs_settings` (
  `key` varchar(50) NOT NULL,
  `value` text NOT NULL,
PRIMARY KEY(`key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

