<?php
/**
 * Default Controller for J!WHMCS Integrator
*
* @package    J!WHMCS Integrator
* @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
* @license    GNU General Public License version 2, or later
* @version    $Id: default.php 555 2012-09-06 02:10:32Z steven_gohigher $
* @since      1.5.1
*/

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );


/**
 * JwhmcsControllerDefault class is the default task handler for the admin area
 * @version		2.5.8
 *
 * @since		1.5.0
 * @author		Steven
 */
class JwhmcsControllerDefault extends JwhmcsControllerExt
{

	/**
	 * Constructor task
	 * @access		public
	 * @version		2.5.8
	 *
	 * @since		1.5.1
	 */
	public function __construct()
	{
		parent::__construct();
		
		
// 		$this->registerTask( 'cpanel',	'display' );
	}



	/**
	 * Display task
	 * @access		public
	 * @version		2.5.8
	 *
	 * @since		2.4.9
	 * @see			JwhmcsController :: display()
	 */
	public function display()
	{
		$input	=	dunloader( 'input', true );
		$input->setVar( 'view', 'default' );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
// 			$input->setVar( 'layout', 'default35' );
// 			JwhmcsHelper :: set( 'view', 'default' );
// 			JwhmcsHelper :: set( 'layout', 'default35' );
		}

		parent::display();
	}
	
	
	/**
	 * Task to sync settings to WHMCS
	 * @access		public
	 * @version		2.5.8 ( $id$ )
	 * 
	 * @since		2.5.0
	 */
	public function settingssync()
	{
		$app	=	JFactory :: getApplication();
		$model	=   $this->getModel( 'default' );
		$result	=	$model->settingssync();
		
		if ( $result === true ) {
			$type	=	'message';
			$msg	=	JText :: _( 'COM_JWHMCS_SETTINGSSYNC_DONE' );
		}
		// Assume string returns are error messages
		else {
			$type	=	'error';
			$msg	=	JText :: _( 'COM_JWHMCS_SETTINGSSYNC_' . $result );
		}
		
		$this->setRedirect( 'index.php?option=com_jwhmcs', $msg, $type )
				->redirect();
	}
}