<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ?>
<?php

// If we are logged in but aren't logged in as a WHMCS user
//		(status === true, otherwise it's an id)
if($status === true) :

?>
<form action="<?php echo $jwhmcs->whmcsurl; ?>" method="post" name="login" id="form-login">
<?php if ($params->get('greeting')) : ?>
	<div>
	<?php if ($params->get('name')) : {
		echo JText::sprintf( "MOD_JWHMCSLOGIN_FORM_HINAME", $user->get('name') );
	} else : {
		echo JText::sprintf( "MOD_JWHMCSLOGIN_FORM_HINAME", $user->get('username') );
	} endif; ?>
	</div>
<?php endif; ?>
	<div align="center">
		<input type="submit" name="Submit" class="button" value="<?php echo JText::_( "MOD_JWHMCSLOGIN_FORM_BUTTON_LOGOUT"); ?>" />
	</div>
	<input type="hidden" name="task" value="ulogout" />
	<?php if ($jwhmcs->return): ?><input type="hidden" name="return" value="<?php echo $jwhmcs->return; ?>" /><?php endif; ?>
	<?php if ( $jwhmcs->iswhmcs): ?><input type="hidden" name="whmcs" value="1" /><?php endif; ?>
</form>
<?php

else :

?>

<form action="<?php echo $jwhmcs->whmcsurl; ?>" method="post" name="login" id="form-login" >
	<?php echo $params->get('pretext'); ?>
	<fieldset class="input">
	<p id="form-login-username">
		<label for="modlgn_username"><?php echo JText::_( "MOD_JWHMCSLOGIN_FORM_LABEL_USERNAME") ?></label><br />
		<input id="modlgn_username" type="text" name="username" class="inputbox" alt="username" size="18" />
	</p>
	<p id="form-login-password">
		<label for="modlgn_passwd"><?php echo JText::_( "MOD_JWHMCSLOGIN_FORM_LABEL_PASSWORD" ) ?></label><br />
		<input id="modlgn_passwd" type="password" name="passwd" class="inputbox" size="18" alt="password" />
	</p>
	<?php if(JPluginHelper::isEnabled('system', 'remember')) : ?>
	<p id="form-login-remember">
		<label for="modlgn_remember"><?php echo JText::_( "MOD_JWHMCSLOGIN_FORM_LABEL_REMEMBER" ) ?></label>
		<input id="modlgn_remember" type="checkbox" name="remember" class="inputbox" value="yes" alt="Remember Me" />
	</p>
	<?php endif; ?>
	<input type="submit" name="Submit" class="button" value="<?php echo JText::_( "MOD_JWHMCSLOGIN_FORM_BUTTON_LOGIN" ) ?>" />
	</fieldset>
	<ul>
		<li>
			<a href="<?php echo $jlinks->pwreset; ?>">
			<?php echo JText::_( "MOD_JWHMCSLOGIN_FORM_LINK_FORGOTPASSWORD" ); ?></a>
		</li>
		<li>
			<a href="<?php echo $jlinks->username; ?>">
			<?php echo JText::_( "MOD_JWHMCSLOGIN_FORM_LINK_FORGOTUSERNAME" ); ?></a>
		</li>
		<?php
		$usersConfig = &JComponentHelper::getParams( 'com_users' );
		if ($usersConfig->get('allowUserRegistration')) : ?>
		<li>
			<a href="<?php echo $jlinks->register; ?>">
				<?php echo JText::_( "MOD_JWHMCSLOGIN_FORM_LINK_REGISTER" ); ?></a>
		</li>
		<?php endif; ?>
	</ul>
	<?php echo $params->get('posttext'); ?>
	<input type="hidden" name="task" value="ulogin" />
	<?php if ($jwhmcs->return): ?><input type="hidden" name="return" value="<?php echo $jwhmcs->return; ?>" /><?php endif; ?>
	<?php if ( $jwhmcs->iswhmcs): ?><input type="hidden" name="whmcs" value="1" /><?php endif; ?>
</form>
<?php endif; ?>