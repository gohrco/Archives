<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    Commercial
 * @version    $Id: jconfig.php 457 2012-04-19 15:33:08Z steven_gohigher $
 * @since      1.5.0
 */
defined('JWHMCSINI') or die('Restricted access');

/* ------------------------------------------------------------ *\
 * Joomla Configuration Path
 * ------------------------------------------------------------
 *   Define the path to the location of your Joomla
 *   configuration file.  Typically this file is located in
 *   something like `/home/username/public_html`
\* ------------------------------------------------------------ */
define( 'JPATH_CONFIG', '%s' );

/* ------------------------------------------------------------ *\
 * Special Configuration File Setting
 * ------------------------------------------------------------
 *   If you use a custom named configuration file, you can
 *   specify that below.  For most this should remain as set.
\* ------------------------------------------------------------ */
define( 'JCONFIG_FILE', '%s' );

?>