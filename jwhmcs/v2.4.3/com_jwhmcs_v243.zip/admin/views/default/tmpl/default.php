<?php defined('_JEXEC') or die('Restricted access');
jimport('joomla.html.pane');
JHTML::_('behavior.mootools');
JHTML::_('behavior.tooltip');

$lang	= &JFactory::getLanguage();

$tmp	= explode('-', $this->data->get( 'LicenseKey' ));
$lictype	= $tmp[0];
$mediapath	= JURI::root()."media/com_jwhmcs/icons/";
?>
<style type="text/css">
.icon-48-jwhmcs { background-image: url('<?php echo $mediapath; ?>j-48-jwhmcs.png'); }
.icon-32-license { background-image: url('<?php echo $mediapath; ?>j-32-license.png'); }
.icon-32-apiconxn { background-image: url('<?php echo $mediapath; ?>j-32-apiconxn.png'); }

span.hasTip {
	text-align: right !important;
	font-weight: bold !important;
}
</style>

<div id="cpanel" style="width: 98%; clear: both; ">
	<div style="width: 400px; float: left; ">
		<?php foreach ($this->icondefs as $icon):
			$imglnk	= JRoute::_('index.php?option=' . JwhmcsHelper :: getCmd( 'option', 'com_jwhmcs' ) . ( is_null( $icon['controller']) ? '' : '&amp;controller='.$icon['controller']) . (is_null($icon['task']) ? '' : '&amp;task='.$icon['task']) . ( is_null($icon['view']) ? '' : '&amp;view='.$icon['view'] ));
			$imgsrc	= $mediapath . $icon['icon'];
		?>
		<div style="float: left; ">
			<div class="icon" id="<?php echo $icon['id']; ?>">
				<a href="<?php echo $imglnk; ?>" id="<?php echo $icon['id']; ?>_link">
					<img
						src="<?php echo $imgsrc; ?>"
						border="0" alt="<?php echo $icon['label']; ?>"
						id="<?php echo $icon['id']; ?>_img" />
					<span id="<?php echo $icon['id']; ?>_title"><?php echo $icon['label']; ?></span>
				</a>
			</div>
		</div>
		<?php endforeach; ?>
	</div>
	<div id="jpmodules" style="width: 450px; float: right;">
		<h1 style="text-align: center; width: 100%; margin: 0px; padding: 0px; " class="title"><?php echo JText::_("COM_JWHMCS"); ?></h1>
		<h4 style="text-align: center; width: 100%; margin: 0px; padding: 0px; " class="title"><?php echo JText::sprintf("COM_JWHMCS_DEFAULT_VIEW_TEXT_VERSION", $this->data->get( "Version" ) ); ?></h4>
		
		<table width="400px" align="center" border="0" cellpadding="5" cellspacing="0" style="margin: 0px auto; ">
			<tr>
				<td align="right" valign="top">
					<?php echo JText::_("COM_JWHMCS_DEFAULT_VIEW_TEXT_LICENSEDTO"); ?>
				</td>
				<td align="left" valign="top" style="font-weight: bold; ">
					<?php echo $this->lic['registeredname']; ?>
					<?php echo ( isset($this->lic['companyname']) ? '<br />' . $this->lic['companyname'] : '' ); ?>
					<?php echo ( isset($this->lic['email']) ? '<br />' . $this->lic['email'] : '' ); ?>
				</td>
			</tr>
			<tr>
				<td align="right" valign="top">
					<?php echo JText::_("COM_JWHMCS_DEFAULT_VIEW_TEXT_REGISTEREDON"); ?>
				</td>
				<td align="left" valign="top" style="font-weight: bold; ">
					<?php echo date("F j, Y", strtotime($this->lic['regdate'])); ?>
				</td>
			</tr>
			<tr>
				<td align="right" valign="top">
					<?php echo JText::_("COM_JWHMCS_DEFAULT_VIEW_TEXT_LICENSEDETAILS"); ?>
				</td>
				<td align="left" valign="top" style="font-weight: bold; ">
					<?php echo $this->data->get( 'LicenseKey' ); ?><br />
					<span style="text-align: left; color: <?php echo ($this->lic['valid'] ? '#008800' : '#FF0000'); ?>;"><?php echo JText::sprintf( "", ( $this->lic['branded'] ? "B" : "Unb" ), $lictype ); ?></span>
					<?php if ($this->lic['branded']): ?><a href="https://www.gohigheris.com" target="blank"><?php echo JText::_("COM_JWHMCS_DEFAULT_VIEW_TEXT_BRANDINGREMOVAL"); ?></a><?php endif; ?>
					<?php if ( isset( $this->lic['kayako'] ) ) : ?><?php if ($this->lic['kayako']): ?><?php echo JText::_("COM_JWHMCS_DEFAULT_VIEW_TEXT_KAYAKOINCLUDED"); ?><?php endif; ?><?php endif; ?>
				</td>
			</tr>
			<tr>
				<td align="right" valign="top">
					<?php echo JText::_("COM_JWHMCS_DEFAULT_VIEW_TEXT_LASTSYNCEDON"); ?>
				</td>
				<td align="left" valign="top" style="font-weight: bold; ">
					<?php echo ($this->data->get( 'LastSync' ) ? date("F j, Y h:i:s a", $this->data->get( 'LastSync' ) ) : 'Not yet synced' ); ?>
				</td>
			</tr>
		</table>
	</div>
</div>
<form action="index.php" method="post" name="adminForm">
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="controller" value="default" />
<input type="hidden" name="task" value="" />
</form>

<script type="text/javascript">
window.addEvent( 'domready', checkForUpdates() );
</script>