<?php
/**
 * @package     Joomla.Platform
 * @subpackage  Form
 *
 * @copyright   Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE
 */

defined('JPATH_PLATFORM') or die;

JFormHelper::loadFieldClass('list');

/**
 * Form Field class for the Joomla Platform.
 * Supports a generic list of options.
 *
 * @package     Joomla.Platform
 * @subpackage  Form
 * @since       11.1
 */
class JFormFieldWhmcscountries extends JFormFieldList
{
	/**
	 * The form field type.
	 *
	 * @var    string
	 * @since  11.1
	 */
	protected $type = 'Whmcscountries';

	
	/**
	 * Method to get the input field from the form object
	 * @access		protected
	 * @version		2.6.03 ( $id$ )
	 *
	 * @return		string containing html field
	 * @since		2.5.0
	 */
	protected function getInput()
	{
		// Grab the default value if not set
		if ( empty( $this->value ) ) {
			$config			=	dunloader( 'config', 'com_jwhmcs' );
			$this->value	=	$config->get( 'defaultcountry' );
		}
		
		return parent :: getInput();
	}
	
	
	/**
	 * Method to get options from the form field
	 * @access		protected
	 * @version		2.6.03 ( $id$ )
	 *
	 * @return		array
	 * @since		2.5.0
	 */
	protected function getOptions()
	{
		// Initialize variables.
		$options = array();
		
		foreach ( $this->_getCountries() as $country ) {
			// Create option
			$tmp = JHtml::_( 'select.option', (string) $country->value, (string) $country->text );
			$options[]	=	$tmp;
		}
		
		return $options;
	}
	
	
	/**
	 * Method to get the country list
	 * @access		private
	 * @version		2.6.03 ( $id$ )
	 *
	 * @return		array of stdClass objects
	 * @since		2.5.0
	 */
	private function _getCountries()
	{
		$countries = array(
				"AF"=>"Afghanistan",
				"AX"=>"Aland Islands",
				"AL"=>"Albania",
				"DZ"=>"Algeria",
				"AS"=>"American Samoa",
				"AD"=>"Andorra",
				"AO"=>"Angola",
				"AI"=>"Anguilla",
				"AQ"=>"Antarctica",
				"AG"=>"Antigua And Barbuda",
				"AR"=>"Argentina",
				"AM"=>"Armenia",
				"AW"=>"Aruba",
				"AU"=>"Australia",
				"AT"=>"Austria",
				"AZ"=>"Azerbaijan",
				"BS"=>"Bahamas",
				"BH"=>"Bahrain",
				"BD"=>"Bangladesh",
				"BB"=>"Barbados",
				"BY"=>"Belarus",
				"BE"=>"Belgium",
				"BZ"=>"Belize",
				"BJ"=>"Benin",
				"BM"=>"Bermuda",
				"BT"=>"Bhutan",
				"BO"=>"Bolivia",
				"BA"=>"Bosnia And Herzegovina",
				"BW"=>"Botswana",
				"BV"=>"Bouvet Island",
				"BR"=>"Brazil",
				"IO"=>"British Indian Ocean Territory",
				"BN"=>"Brunei Darussalam",
				"BG"=>"Bulgaria",
				"BF"=>"Burkina Faso",
				"BI"=>"Burundi",
				"KH"=>"Cambodia",
				"CM"=>"Cameroon",
				"CA"=>"Canada",
				"CV"=>"Cape Verde",
				"KY"=>"Cayman Islands",
				"CF"=>"Central African Republic",
				"TD"=>"Chad",
				"CL"=>"Chile",
				"CN"=>"China",
				"CX"=>"Christmas Island",
				"CC"=>"Cocos (Keeling) Islands",
				"CO"=>"Colombia",
				"KM"=>"Comoros",
				"CG"=>"Congo",
				"CD"=>"Congo, Democratic Republic",
				"CK"=>"Cook Islands",
				"CR"=>"Costa Rica",
				"CI"=>"Cote D'Ivoire",
				"HR"=>"Croatia",
				"CU"=>"Cuba",
				"CW"=>"Curacao",
				"CY"=>"Cyprus",
				"CZ"=>"Czech Republic",
				"DK"=>"Denmark",
				"DJ"=>"Djibouti",
				"DM"=>"Dominica",
				"DO"=>"Dominican Republic",
				"EC"=>"Ecuador",
				"EG"=>"Egypt",
				"SV"=>"El Salvador",
				"GQ"=>"Equatorial Guinea",
				"ER"=>"Eritrea",
				"EE"=>"Estonia",
				"ET"=>"Ethiopia",
				"FK"=>"Falkland Islands (Malvinas)",
				"FO"=>"Faroe Islands",
				"FJ"=>"Fiji",
				"FI"=>"Finland",
				"FR"=>"France",
				"GF"=>"French Guiana",
				"PF"=>"French Polynesia",
				"TF"=>"French Southern Territories",
				"GA"=>"Gabon",
				"GM"=>"Gambia",
				"GE"=>"Georgia",
				"DE"=>"Germany",
				"GH"=>"Ghana",
				"GI"=>"Gibraltar",
				"GR"=>"Greece",
				"GL"=>"Greenland",
				"GD"=>"Grenada",
				"GP"=>"Guadeloupe",
				"GU"=>"Guam",
				"GT"=>"Guatemala",
				"GG"=>"Guernsey",
				"GN"=>"Guinea",
				"GW"=>"Guinea-Bissau",
				"GY"=>"Guyana",
				"HT"=>"Haiti",
				"HM"=>"Heard Island & Mcdonald Islands",
				"VA"=>"Holy See (Vatican City State)",
				"HN"=>"Honduras",
				"HK"=>"Hong Kong",
				"HU"=>"Hungary",
				"IS"=>"Iceland",
				"IN"=>"India",
				"ID"=>"Indonesia",
				"IR"=>"Iran, Islamic Republic Of",
				"IQ"=>"Iraq",
				"IE"=>"Ireland",
				"IM"=>"Isle Of Man",
				"IL"=>"Israel",
				"IT"=>"Italy",
				"JM"=>"Jamaica",
				"JP"=>"Japan",
				"JE"=>"Jersey",
				"JO"=>"Jordan",
				"KZ"=>"Kazakhstan",
				"KE"=>"Kenya",
				"KI"=>"Kiribati",
				"KR"=>"Korea",
				"KW"=>"Kuwait",
				"KG"=>"Kyrgyzstan",
				"LA"=>"Lao People's Democratic Republic",
				"LV"=>"Latvia",
				"LB"=>"Lebanon",
				"LS"=>"Lesotho",
				"LR"=>"Liberia",
				"LY"=>"Libyan Arab Jamahiriya",
				"LI"=>"Liechtenstein",
				"LT"=>"Lithuania",
				"LU"=>"Luxembourg",
				"MO"=>"Macao",
				"MK"=>"Macedonia",
				"MG"=>"Madagascar",
				"MW"=>"Malawi",
				"MY"=>"Malaysia",
				"MV"=>"Maldives",
				"ML"=>"Mali",
				"MT"=>"Malta",
				"MH"=>"Marshall Islands",
				"MQ"=>"Martinique",
				"MR"=>"Mauritania",
				"MU"=>"Mauritius",
				"YT"=>"Mayotte",
				"MX"=>"Mexico",
				"FM"=>"Micronesia, Federated States Of",
				"MD"=>"Moldova",
				"MC"=>"Monaco",
				"MN"=>"Mongolia",
				"ME"=>"Montenegro",
				"MS"=>"Montserrat",
				"MA"=>"Morocco",
				"MZ"=>"Mozambique",
				"MM"=>"Myanmar",
				"NA"=>"Namibia",
				"NR"=>"Nauru",
				"NP"=>"Nepal",
				"NL"=>"Netherlands",
				"AN"=>"Netherlands Antilles",
				"NC"=>"New Caledonia",
				"NZ"=>"New Zealand",
				"NI"=>"Nicaragua",
				"NE"=>"Niger",
				"NG"=>"Nigeria",
				"NU"=>"Niue",
				"NF"=>"Norfolk Island",
				"MP"=>"Northern Mariana Islands",
				"NO"=>"Norway",
				"OM"=>"Oman",
				"PK"=>"Pakistan",
				"PW"=>"Palau",
				"PS"=>"Palestinian Territory, Occupied",
				"PA"=>"Panama",
				"PG"=>"Papua New Guinea",
				"PY"=>"Paraguay",
				"PE"=>"Peru",
				"PH"=>"Philippines",
				"PN"=>"Pitcairn",
				"PL"=>"Poland",
				"PT"=>"Portugal",
				"PR"=>"Puerto Rico",
				"QA"=>"Qatar",
				"RE"=>"Reunion",
				"RO"=>"Romania",
				"RU"=>"Russian Federation",
				"RW"=>"Rwanda",
				"BL"=>"Saint Barthelemy",
				"SH"=>"Saint Helena",
				"KN"=>"Saint Kitts And Nevis",
				"LC"=>"Saint Lucia",
				"MF"=>"Saint Martin",
				"PM"=>"Saint Pierre And Miquelon",
				"VC"=>"Saint Vincent And Grenadines",
				"WS"=>"Samoa",
				"SM"=>"San Marino",
				"ST"=>"Sao Tome And Principe",
				"SA"=>"Saudi Arabia",
				"SN"=>"Senegal",
				"RS"=>"Serbia",
				"SC"=>"Seychelles",
				"SL"=>"Sierra Leone",
				"SG"=>"Singapore",
				"SK"=>"Slovakia",
				"SI"=>"Slovenia",
				"SB"=>"Solomon Islands",
				"SO"=>"Somalia",
				"ZA"=>"South Africa",
				"GS"=>"South Georgia And Sandwich Isl.",
				"ES"=>"Spain",
				"LK"=>"Sri Lanka",
				"SD"=>"Sudan",
				"SR"=>"Suriname",
				"SJ"=>"Svalbard And Jan Mayen",
				"SZ"=>"Swaziland",
				"SE"=>"Sweden",
				"CH"=>"Switzerland",
				"SY"=>"Syrian Arab Republic",
				"TW"=>"Taiwan",
				"TJ"=>"Tajikistan",
				"TZ"=>"Tanzania",
				"TH"=>"Thailand",
				"TL"=>"Timor-Leste",
				"TG"=>"Togo",
				"TK"=>"Tokelau",
				"TO"=>"Tonga",
				"TT"=>"Trinidad And Tobago",
				"TN"=>"Tunisia",
				"TR"=>"Turkey",
				"TM"=>"Turkmenistan",
				"TC"=>"Turks And Caicos Islands",
				"TV"=>"Tuvalu",
				"UG"=>"Uganda",
				"UA"=>"Ukraine",
				"AE"=>"United Arab Emirates",
				"GB"=>"United Kingdom",
				"US"=>"United States",
				"UM"=>"United States Outlying Islands",
				"UY"=>"Uruguay",
				"UZ"=>"Uzbekistan",
				"VU"=>"Vanuatu",
				"VE"=>"Venezuela",
				"VN"=>"Viet Nam",
				"VG"=>"Virgin Islands, British",
				"VI"=>"Virgin Islands, U.S.",
				"WF"=>"Wallis And Futuna",
				"EH"=>"Western Sahara",
				"YE"=>"Yemen",
				"ZM"=>"Zambia",
				"ZW"=>"Zimbabwe"
		);
		asort($countries);
		
		$data	=	array();
		
		foreach ( $countries as $sh => $ln ) {
			$data[]	=	(object) array( 'value' => $sh, 'text' => $ln );
		}
		
		return $data;
	}
}