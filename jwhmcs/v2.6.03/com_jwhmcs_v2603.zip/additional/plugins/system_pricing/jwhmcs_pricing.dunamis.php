<?php

defined('_JEXEC') or die( 'Restricted access' );

/**
 * Define the JWHMCS version here
 */
if (! defined( 'DUN_MOD_JWHMCS' ) ) define( 'DUN_MOD_JWHMCS', "2.6.03" );
if (! defined( 'DUN_MOD_JWHMCS_PRICING' ) ) define( 'DUN_MOD_JWHMCS_PRICING', "2.6.03" );


class Jwhmcs_pricingDunModule extends DunModule
{
	public function initialise()
	{
		
	}
}