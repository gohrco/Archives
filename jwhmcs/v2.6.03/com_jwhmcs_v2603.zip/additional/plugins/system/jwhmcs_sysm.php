<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: jwhmcs_sysm.php 859 2015-07-02 18:12:18Z steven_gohigher $
 * @since      1.5.0
 * 
 * @desc		This plugin redirects links to option=com_user&task=register to
 * 				the J!WHMCS component (com_jwhmcs) user registration to request
 * 				information from end customer for WHMCS.
 */


/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
defined( 'JWHMCSSYSM_FILEPATH' ) or define( 'JWHMCSSYSM_FILEPATH', dirname( __FILE__) . DIRECTORY_SEPARATOR );
/*-- Security Protocols --*/

jimport( 'dunamis.dunamis' );
jimport( 'joomla.plugin.plugin' );


/**
 * System - J!WHMCS Integrator plugin
 * @version		2.6.03
 *
 * @since		1.5.0
 * @author		Steven
 */
class plgSystemJwhmcs_sysm extends JPlugin
{
	
	/**
	 * Property indicating if the plugin should be enabled or not
	 * @access		private
	 * @var			boolean
	 * @since		2.5.0
	 */
	private $_enabled	=	false;
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		2.6.03
	 * @param		object		- $subject: The object to observe
	 * @param 		array		- $config: An array that holds the plugin configuration
	 * 
	 * @since		1.5.0
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct( $subject, $config );
		
		$this->loadLanguage();
		
		$app		=	JFactory :: getApplication();
		$user		=	JFactory :: getUser();
		
		// Run through tests
		// -----------------
		// Ensure we have Dunamis installed
		if (! function_exists( 'get_dunamis' ) ) {
			// Not admin don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
			
			// Show error message
			$this->_displayError( 'JWHMCS_SYSM_CONFIG_NODUNAMIS', 'library' );
			return;
		}
		
		get_dunamis( 'com_jwhmcs' );
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		
		if (! is_a( $config, 'Com_jwhmcsDunConfig' ) ) {
			// Not admin or not logged in don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
				
			// Show error message
			$this->_displayError( 'JWHMCS_SYSM_CONFIG_NOJWHMCSCONFIG', 'jwhmcsconfig' );
			return;
		}
		
		// Ensure we are active...
		if (! $config->get( 'enable' ) ) {
			// Not admin or not logged in don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
			
			// Show error message
			$this->_displayError( 'JWHMCS_SYSM_CONFIG_NOTENABLED', 'enable' );
			return;
		}
		
		// Ensure we have a token set
		if (! $config->get( 'token' ) ) {
			// Not admin or not logged in don't show error message
			if (! $app->isAdmin() || $user->guest ) return;
				
			// Show error message
			$this->_displayError( 'JWHMCS_SYSM_CONFIG_NOTOKEN', 'token' );
			return;
		}
		
		// All good, lets go
		$this->_enabled	=	true;
		
		// But before we go...
		if ( $config->get( 'debug' ) ) {
			// Visitors shouldn't be bothered
			if ( $user->guest ) return;
			
			// WARN EVERYONE ELSE THO
			$this->_displayError( 'JWHMCS_SYSM_CONFIG_DEBUGON', 'debug', false );
		}
	}
	
	
	/**
	 * Method to generate a signature for validation
	 * @static
	 * @access		public
	 * @version		2.6.03 
	 * @version		2.5.8		Added check for sh404sef
	 * 
	 * @return		string
	 * @since		2.5.0
	 */
	public static function generateSignature()
	{
		get_dunamis( 'jwhmcs_sysm' );
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		$input	=	dunloader( 'input', true );
		
		$method	=	self :: getMethod();
		$token	=	$config->get( 'token' );
		$uri	=	clone DunUri :: getInstance( 'SERVER', true );
		$append	=	null;
		
		// Cleanup language uri redirections :(
		if ( ( $l = $uri->getVar( 'lang', false ) ) ) {
			$path	=	$uri->getPath();
			$path	=	str_replace( '/' . $l . '/', '', $path );
			$uri->setPath( $path );
		}
		
		// ---- BEGIN: JWHMCS-31
		//		When using SEF Rewrite feature in Joomla core, the index.php is stripped out of the URL, so signature must be adjusted
		$isSef		=	self :: _usingSefrewrite();
		
		if ( $isSef && strpos( $uri->getPath(), 'index.php' ) === false ) {
			$path	=	rtrim( $uri->getPath(), '/' ) . '/index.php';
			$uri->setPath( $path );
		}
		// ---- END: JWHMCS-31
		
		if ( $method == 'post' ) {
			$post	=	$_POST;
			ksort( $post );
		
			foreach ( $post as $k => $v ) {
				if ( $k == 'apisignature' ) continue;
				$append	.=	$k . $input->getVar( $k, null, 'string', 'post' );
			}
		}
		else if ( $method == 'get' || $method == 'put' ) {
			$uri->delVar( 'apisignature' );
		}
		
		return base64_encode( hash_hmac( 'sha256', rawurldecode( $uri->toString() ) . $append, $token, true ) );
	}
	
	
	/**
	 * Method to determine which method we are using to access the API
	 * @static
	 * @access		public
	 * @version		2.6.03 
	 *
	 * @return		string
	 * @since		2.5.0
	 */
	public static function getMethod()
	{
		if ( version_compare( JVERSION, '1.7.0', 'ge' ) ) {
			$app	= & JFactory :: getApplication();
			return strtolower( $app->input->getMethod() );
		}
		else {
			return strtolower( JRequest :: getMethod() );
		}
	}
	
	
	/**
	 * Event called when gathering update sites to check for updates
	 * @access		public
	 * @deprecated
	 * @version		2.6.03
	 *
	 * @return		array
	 * @since		2.4.0
	 */
	public function getUpdateSite()
	{
		return array(
				'extensionName'				=> 'plg_jwhmcs_sysm',
				'options' => array(
						'extensionTitle'	=> 'J!WHMCS Integrator System Plugin',
						'storage'			=> 'database',
						'storagePath'		=> null,
						'extensionType'		=> 'plugin',
						'updateUrl'			=> 'https://www.gohigheris.com/updates/jwhmcs/plugins/sysm'
				)
		);
	}
	
	
	/**
	 * onAfterInitialise event
	 * @desc		This is being used to intercept remember me cookie logins
	 * @access		public
	 * @version		2.6.03
	 * 
	 * @since		2.4.9
	 */
	public function onAfterInitialise()
	{
		$app = JFactory::getApplication();
		
		// Update sessions if need be (due to group update potentiality)
		$this->_updateSessions();
		
		// Handle the API requests (true indicates we handled an API call so we shouldn't do anything else - if we are even still here)
		if ( $this->_handleApi() ) {
			return;
		}
		
		// No remember me for admin
		if ( $app->isAdmin() ) {
			return;
		}
		
		// Only for front end logins...
		if ( $this->_handleAutoauth() ) {
			return;
		}
		
		// Only for front end logouts...
		if ( $this->_handleAutologouts() ) {
			return;
		}
		
		return;
	}
	
	
	/**
	 * Triggered by onAfterRender event
	 * @access		public
	 * @version		2.6.03
	 * @version		1.5.3		- Oct 2009: added ability to redirect to user reg or edit page
	 * 
	 * @since		1.5.0
	 */
	public function onAfterRender()
	{
		// Ensure we can run this
		if (! $this->_enabled ) return false;
		
		/* Yeay Dunamis! */
		get_dunamis( 'com_jwhmcs' );
		
		// Hand off for the language
		$this->_handleLanguage();
		
		return;
		
	}
	
	
	/**
	 * Triggered by onAfterRoute event
	 * @access		public
	 * @version		2.6.03 
	 *
	 * @since		2.5.0
	 */
	public function onAfterRoute()
	{
		// Ensure we can run this
		if (! $this->_enabled ) return false;
		
		// Initialize
		$config		=	dunloader( 'config', 'com_jwhmcs' );
		$input		=	dunloader( 'input', true );
		$joomla		=   $this->_getJoomlaTasks();
		$app		=	JFactory :: getApplication();
		$user 		=	JFactory :: getUser();
		$option 	=	$input->getVar( 'option' );
		$task   	=   $input->getVar( 'task' );
		$view		=   $input->getVar( 'view' );
		$layout		=   $input->getVar( 'layout' );
		$newlink	=	null;
		
		// Determine if we should run this
		if (! $config->get( 'enableuserbridging' ) ) return false; 
		
		// Registration Method
		$regmethod	=	$config->get( 'regmethod' );
		
		
		// ======================================
		// 	REGISTRATION CHECK
		// ======================================
		if (	$option == $joomla->component
			&&	(	$task == $joomla->regtask
				||	$view == $joomla->regview )
			&&	$regmethod == '1'
			&&	$user->get( 'guest' ) )
		{
			$uri		=	DunUri :: getInstance( $config->get( 'whmcsurl' ), true );
			$uri->setPath( rtrim( $uri->getPath(), '/' ) . '/register.php' );
			$newlink	=	$uri->toString();
		}
		
		if ( $newlink != null ) {
			$app->redirect( $newlink );
		}
		
		return;
		
		
		// ======================================
		// --------------------------------------
		// ======================================
		// Test for editing the user profile form
		if ( $option == $joomla->component && (
				( $task == $joomla->edittask || $view == $joomla->editview ) ||
				( $view == $joomla->userview && $layout == $joomla->layoutform ) )
		) {
			// load J!WHMCS Edit page
			if (! $user->get('guest') ):
			if ( ( $params->get( 'RegMethod' ) == 1 ) || ( $params->get( 'RegMethod' ) == 3 ) ) {
				$uri = new JURI( $params->get( 'ApiUrl' ) );
				$uri->setPath( $uri->getPath() . '/clientarea.php' );
				$uri->setVar( 'action', 'details' );
				$newlink = $uri->toString();
			}
			endif;
		}
		// ======================================
		// --------------------------------------
		// ======================================
		// Test for resetting a password link
		if ( $option == $joomla->component && ( $task == $joomla->resettask || $view == $joomla->resetview ) ) {
			// load J!WHMCS Edit page
			if ( $user->get('guest') ):
			if ( ( ( $params->get( 'RegMethod' )== 1 ) && ( $params->get( 'PwresetRedirect' ) != 1 ) ) || ( $params->get( 'PwresetRedirect' ) == 2 ) ) {
				$uri = new JURI( $params->get( 'ApiUrl' ) );
				$uri->setPath( $uri->getPath() . '/pwreset.php' );
				$newlink = $uri->toString();
			}
			elseif ( ( $params->get( 'PwresetRedirect' ) == 1 ) && ( $params->get( 'PwresetMenu' ) ) && ( $params->get( 'PwresetMenu' ) != $Itemid ) ) {
				$newlink = JRoute::_( "index.php?Itemid={$params->get( 'PwresetMenu' )}", false );
				$mainframe->redirect( $newlink );
			}
			endif;
		}
		// ======================================
		// --------------------------------------
		// ======================================
		// Insert Google Analytics Code
		if ( $option != 'com_jwhmcs' || ( $option == 'com_jwhmcs' && $view != 'default' ) ) {
				
			if ( $params->get( 'GAEnable' ) == 1 ) {
				$uacode		= $params->get( 'GAUacode' );
				$javascript	= <<< JAVASCRIPT
		
<script type="text/javascript">
		
var _gaq = _gaq || [];
_gaq.push(['_setAccount', '{$uacode}']);
_gaq.push(['_trackPageview']);
		
(function() {
	var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();
		
</script>
		
JAVASCRIPT;
				$body		= JResponse::getBody();
				$body		= str_replace( '</body>', $javascript . '</body>', $body );
				JResponse::setBody( $body );
		
			}
		}
		// ======================================
		
		if ( $newlink != null ) {
			$app->redirect( $newlink );
		}
		return;
	}
	
	
	
	
	/**
	 * onContentPrepareForm event
	 * @access		public
	 * @version		2.6.03 
	 * @param		JForm object	- $form: the form being assembled
	 * @param		JUser object	- $data: the already assembled user
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	public function onContentPrepareForm( $form, $data )
	{
		// If disabled...
		if (! $this->_enabled ) return true;
		
		// Ensure we have a JForm
		if (! ( $form instanceof JForm ) ) {
			$this->_subject->setError('JERROR_NOT_A_FORM');
			return false;
		}
		
		// Form is 'com_config.component'
		if ( ( $name = $form->getName() ) != 'com_config.component' ) {
			return true;
		}
		
		// We must isolate our configuration
		$group = $form->getGroup( 'jwhmcslanguage' );
		if (! isset( $group['jform_jwhmcslanguage_languageenable'] ) ) {
			return true;
		}
		
		// Gather available options from WHMCS
		$langoptions	=	$this->_getLanguageChoices( 'whmcs' );
		$joomlangs		=	$this->_getLanguageChoices();
		
		$cnt	=	0;
		$xmlstr	=	'<fieldset name="jwhmcslanguage" label="LANGUAGE_SETTINGS">'
				.	'<field name="languageenable" type="radio" label="COM_JWHMCS_CONFIG_LANGUAGEENABLE_LABEL" description="COM_JWHMCS_CONFIG_LANGUAGEENABLE_DESC" class="inputbox btn-group" default="0">'
				.		'<option value="1">JYES</option>'
				.		'<option value="0">JNO</option>'
				.	'</field>'
				.	'<field name="languagemap_default" type="list" label="DEFAULT">' . $langoptions . '</field>';
		
		$langoptions	=	'<option value="0">Use Default Language</option>' . $langoptions;
		
		foreach ( $joomlangs as $lang ) {
			$xmlstr	.=	'<field name="languagemap_' . $lang->code . '" label="' . $lang->name . '" default="0" type="list">'
					.		$langoptions
					.	'</field>';
			$cnt++;
		}
		
		$xmlstr	.=	'</fieldset>';
		$xml	=	simplexml_load_string( $xmlstr );
		
		$form->setField( $xml, 'jwhmcslanguage', true );
		
	}
	
	
	/**
	 * Method to compare signatures
	 * @desc		Used to prevent timing attacks
	 * @access		private
	 * @version		2.6.03 
	 * @param		string		- $a: signature 1
	 * @param		string		- $b: signature 2
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	private function _compareSignatures( $a, $b )
	{
		$diff = strlen($a) ^ strlen($b);
		
		for ( $i = 0; $i < strlen($a) && $i < strlen($b); $i++ ) {
			$diff |= ord( $a[$i] ) ^ ord( $b[$i] );
		}
		
		return $diff === 0;
	}
	
	
	/**
	 * Common method for displaying an error message
	 * @access		private
	 * @version		2.6.03 
	 * @param		string		- $msg: the message to display
	 *
	 * @since		2.5.0
	 */
	private function _displayError( $msg = null, $task = 'token', $usesess = true )
	{	
		// Translate string first
		$msg		=	JText :: _( $msg );
		$session	=	JFactory :: getSession();
		
		$hasrun		=	$session->get( 'jwhmcs_sysm.' . $task, false );
		
		if ( $hasrun && $usesess ) {
			return;
		}
		elseif ( $usesess ) {
			$session->set( 'jwhmcs_sysm.' . $task, true );
		}
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JFactory::getApplication()->enqueueMessage( "{$msg}" );
		}
		else {
			JError::raiseNotice( 100, "{$msg}" );
		}
	}
	
	
	/**
	 * Method for calling up a failed response
	 * @access		private
	 * @version		2.6.03
	 * @version		2.6.0		- Added debug code
	 * @param		mixed		- $message: the message to fail on
	 *
	 * @since		2.5.0
	 */
	private function _fail( $message )
	{
		$data	=	array(
				'result'	=>	'error',
				'error'		=>	$message,
				'debug'		=>	dunloader( 'debug', true )->renderforApi()
		);
		$string	= json_encode( $data );
		exit( $string );
	}
	
	
	/**
	 * Method for determining the requested API version
	 * @access		private
	 * @version		2.6.03
	 * @param		md5 string		- $sent: we should be sent an md5 hashed string of the intended version
	 *
	 * @return		string containing found matching hashed version or 2.0 as the default
	 * @since		2.5.0
	 */
	private function _findApiversion( $sent = null )
	{
		$apipath	=	JWHMCSSYSM_FILEPATH . 'api' . DIRECTORY_SEPARATOR;
	
		$dh		= opendir( $apipath );
		$data	=	array();
		while( ( $filename = readdir( $dh ) ) !== false ) {
			if ( in_array( $filename, array( '.', '..', 'index.html' ) ) ) continue;
			$data[md5( $filename )]	= $filename;
		}
	
		if ( isset( $data[$sent] ) ) return $data[$sent];
		else return '2.5';
	}
	
	
	/**
	 * Provides single instance of version logic for retrieving variable
	 * @access		private
	 * @version		2.6.03
	 * @param		string		- $var: the variable sought
	 * @param		mixed		- $default: if not set return this
	 * @param		string		- $filter: variable filter
	 * @param		string		- $hash: where the variable should come from
	 * $param		integer		- $mask: an optional mask for Joomla
	 *
	 * @return		value of variable or default
	 * @since		2.5.0
	 */
	private function _get( $var, $default = null, $filter = 'none', $hash = 'default', $mask = 0 )
	{
		if ( version_compare( JVERSION, '1.7.1', 'ge' ) ) {
			$app	= & JFactory :: getApplication();
			if ( $hash == 'default' ) {
				return $app->input->get( $var, $default, $filter );
			}
			else {
				return $app->input->$hash->get( $var, $default, $filter );
			}
		}
		else {
			$value	= JRequest :: getVar( $var, $default, $hash, $filter, $mask );
			// If we are resetting pw on front end, post is empty for some reason
			if ( empty( $value ) && $var == 'post' ) $value = JRequest::get( 'post' );
			return $value;
		}
	}
	
	
	/**
	 * Method to assemble Joomla tasks
	 * @access		private
	 * @version		2.6.03
	 * @version		2.5.0	- July 2013: dropped Joomla! 1.5 version support
	 * 
	 * @return		object
	 * @since		2.4.0
	 */
	private function _getJoomlaTasks()
	{
		$data	= array(
				'component'		=>	'com_users',
				'regtask'		=>	'registration',
				'regview'		=>	'registration',
				'edittask'		=>	'profile.edit',
				'editview'		=>	'edit',
				'userview'		=>	'user',
				'formlayout'	=>	'form',
				'resettask'		=>	'reset',
				'resetview'		=>	'reset',
				);
		
		return (object) $data;
	}
	
	
	/**
	 * Method to get either Joomla or WHMCS language options
	 * @access		private
	 * @version		2.6.03 
	 * @param		string		- $type: indicates type wanted [joomla|whmcs]
	 *
	 * @return		mixed [array for Joomla|string for WHMCS]
	 * @since		2.5.0
	 */
	private function _getLanguageChoices( $type = 'joomla' )
	{
		get_dunamis( 'com_jwhmcs' );
		
		switch ( $type ) :
		case 'joomla' :
			
			$db		=	dunloader( 'database', true );
			$data	=	array();
			
			// ---- BEGIN JWHMCS-26
			//		Language Menu in Joomla not displaying correctly
			mysql_set_charset( 'utf8' );
			// ---- END JWHMCS-26
			
			$query	=	"SHOW TABLES LIKE " . $db->Quote( "%languages" );
			$db->setQuery( $query );
			$result	=	$db->loadResult();
			
			if (! $result ) {
				return $data;
			}
			
			$query	=	"SELECT `title` as `name`, `lang_code` as `code`, `sef` as `shortcode` FROM #__languages WHERE `published` <> '-2' ORDER BY name";
			$db->setQuery( $query );
			$data	=	$db->loadObjectList();
			
			break;
		case 'whmcs' :
			
			$api	=	dunloader( 'api', 'com_jwhmcs' );
			$langs	=	$api->getlanguages();
			$data	=	null;
			
			foreach ( $langs as $lang ) {
				$data	.=	'<option value="' . $lang . '">' . ucfirst( $lang ) . '</option>';
			}
			
			break;
		endswitch;
		
		return $data;
	}
	
	
	/**
	 * Handles the calls for the API interface
	 * @access		public
	 * @version		2.6.03 
	 * 
	 * @return		boolean
	 * @since		2.5.0
	 */
	private function _handleApi()
	{
		// Ensure we can run this
		if (! $this->_enabled ) return false;
		
		/* Yeay Dunamis! */
		get_dunamis();
		
		// Initialize some fun Dunamis things
		$input	=	dunloader( 'input', true );
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		
		// Grab the method first
		$method	=	$input->getMethod();
		
		// See if we should do anything
		if (! ( $jwhmcs =	$input->getVar( 'jwhmcs', false, $method ) ) ) {
			// If we aren't getting the jwhmcs variable than we should assume this is a normal request
			// and send the user on their way
			return false;
		}
		
		
		// ==============================================================
		//	We have a J!WHMCS request so lets test the signature
		// ==============================================================
		
		// See if we have matching signatures
		$postsig	=	(string) rawurldecode( $input->getVar( 'apisignature', false, 'STRING', $method ) );
		$headsig	=	(string) rawurldecode( $input->getVar( 'HTTP_JWHMCSREQUESTSIGNATURE', false, 'STRING', 'server' ) ); //$this->_get( 'HTTP_JWHMCSREQUESTSIGNATURE', false, 'string', 'server' );
		
		// WARNING - BE SURE DEBUG IS DISABLED IN PRODUCTION!
		if ( $config->get( 'debug', false ) ) {
			$headsig = $postsig;
		}
		
		if ( $this->_compareSignatures( $postsig, $headsig ) !== true ) {
			$this->_fail( JText :: _( 'JWHMCS_SYSM_API_BADSIGNATURE' ) );
		}
		
		// Test the signature - randomize head / post sig use
		$_received_signature	=	(string) ( rand( 0, 1 ) == '1' ? $headsig : $postsig );
		$_generatedsignature	=	(string) plgSystemJwhmcs_sysm :: generateSignature();
		
		// Bail if the signatures dont match
		if ( $this->_compareSignatures( $_received_signature, $_generatedsignature ) !== true ) {
			$this->_fail( JText :: _( 'JWHMCS_SYSM_API_BADSIGNATURE' ) );
		}
		
		// Test the timestamp to ensure recent request
		$gmt		=	new DateTime( null, new DateTimeZone('GMT') );
		$current	=	$gmt->format("U");
		$timestamp	=	$input->getVar( 'apitimestamp', 0, $method );
		$timediff	=	( $config->get( 'debug' ) ? 300 : 45 );
		
		// Test the timestamp
		if ( ( $current - $timestamp ) > $timediff ) {
			// The request is older than 2 minutes... something isn't right
			$this->_fail( JText :: _( 'JWHMCS_SYSM_API_OLDREQUEST' ) );
		}
		
		
		// ================================================================
		//	Lets find the base for the API
		// ================================================================
		
		// Take the J!WHMCS Request to get the base loaded
		$parts		=	explode( "/", trim( $jwhmcs, '/' ) );
		$apiversion	=	array_shift( $parts );
		$apirequest	=	array_shift( $parts );
		
		// Find the api path
		$apipath	=	JWHMCSSYSM_FILEPATH . 'api' . DIRECTORY_SEPARATOR;
		
		// Permit possibilities of versioned API
		$apiversion	=	$this->_findApiversion( $apiversion );
		$apipath	.=	$apiversion . DIRECTORY_SEPARATOR;
		
		// Be sure we dont fail ugly - we must have the base
		if (! file_exists(  $apipath . 'base.php' ) ) {
			// If for some reason we don't have the base file for the API for Belong there may
			// have been a problem during installation.
			$this->_fail( sprintf( JText :: _( 'JWHMCS_SYSM_API_BASE_NOPATH' ), $apipath . 'base.php' ) );
		}
		
		// Load the base api file
		@require_once( $apipath . 'base.php' );
		
		$classname	= 'JwhmcsAPI';
		
		// Be sure we dont fail ugly - we must have the base
		if (! class_exists( $classname ) ) {
			// If for some reason we don't have the base class but was able to find the file something
			// is fishy so bail
			$this->_fail( sprintf( JText :: _( 'JWHMCS_SYSM_API_BASE_NOCLASS' ), $classname ) );
		}
		
		
		
		// =============================================================
		//	Now lets find the actual request
		// =============================================================
		
		// API classname
		$apiclassname	= ucfirst( $apirequest ) . $classname;
		
		// Find the api filename
		// @TODO:  Check for safe mode as file exists may fail otherwise
		if ( file_exists( $apipath . strtolower( $apirequest ) . '.php' ) ) {
			@require_once( $apipath . strtolower( $apirequest ) . '.php' );
		}
		
		// Be sure we dont fail ugly
		if (! class_exists( $apiclassname ) ) {
			$this->_fail( sprintf( 'API Method `%s` is unknown.', $apirequest ) );
		}
		
		// Prevent recursion
		define( 'JWHMCSAPI', true );
		
		// Initialize the class and execute
		$api	=	new $apiclassname();
		$result	=	$api->execute();
		
		return $result;
	}
	
	
	/**
	 * Handles the autoauth routine coming from WHMCS
	 * @access		private
	 * @version		2.6.03 
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	private function _handleAutoauth()
	{
		// Ensure we can run this
		if (! $this->_enabled ) return false;
		
		/* Yeay Dunamis! */
		get_dunamis( 'jwhmcs_sysm' );
		
		// Initialize some fun Dunamis things
		$input	=	dunloader( 'input', true );
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		
		// Be sure we need to do this
		if ( $input->getVar( 'task', false ) != 'autoauth' ) {
			return false;
		}
		
		
		// =============================================================
		//	Build our list of variables
		// =============================================================
		
		$token		=	$config->get( 'token' );
		$timestamp	=	(string) $input->getVar( 'timestamp', null, 'STRING', 'get' );
		$signature	=	(string) $input->getVar( 'signature', null, 'STRING', 'get' );
		$username	=	(string) $input->getVar( 'username', null, 'STRING', 'get');
		$checksign	=	(string) $input->getVar( 'checksign', null, 'STRING', 'get');
		$returnurl	=	(string) $input->getVar( 'returnurl', null, 'STRING', 'get' );
		
		// Be sure we have it all together
		if (! $timestamp || ! $signature || ! $username || ! $checksign || ! $token || ! $returnurl ) {
			return false;
		}
		
		
		// =============================================================
		//	Check our username first
		// =============================================================
		$oursign	=	(string) base64_encode( hash_hmac( 'sha256', $username . $timestamp . $token, $token, true ) );
		
		if ( $this->_compareSignatures( $oursign, $checksign ) !== true ) {
			return false;
		}
		
		
		// =============================================================
		//	Next lets pull the email address for that username
		// =============================================================
		$user		=	JUser :: getInstance( $username );
		
		// Ensure we have a user known by that username
		if (! $user ) {
			return false;
		}
		
		$newsign	=	(string) base64_encode( hash_hmac( 'sha256', $user->get( 'email', false ) . $timestamp . $token, $token, true ) );
		
		if ( $this->_compareSignatures( $newsign, $signature ) !== true ) {
			return false;
		}
		
		
		// =============================================================
		//	Time check
		// =============================================================
		if ( ( time() - $timestamp ) > 120 ) {
			return false;
		}
		
		
		// =============================================================
		//	Alright, let's authorize them
		// =============================================================
		$response	=	new stdClass();
		$response->fullname 	= $user->get( 'name' );
		$response->username		= $user->get( 'username');
		$response->email		= $user->get( 'email' );
		$response->password		= $user->get( 'password' );
		$response->password_clear = null;
		$response->status		= 1;
		$response->error_message = '';
		
		
		// =============================================================
		//	Check for subtask: add to WHMCS
		// =============================================================
		if ( $input->getVar( 'subtask', false ) && $input->getVar( 'subtask', null ) == 'adduser' ) {
			
			$name	=	explode( " ", $user->get( 'name' ) );
			$first	=	array_shift( $name );
			$last	=	implode( " ", $name );
			
			$wuser	=	array(
					'firstname'				=>	$first,
					'lastname'				=>	$last,
					'email'					=>	$user->get( 'email' ),
					'password2'				=>	$input->getVar( 'password2', false, 'STRING' ),
					'noemail'				=>	true,
					'skipvalidation'		=>	true,
					);
			
			$api	=	dunloader( 'api', 'com_jwhmcs' );
			$result	=	$api->addclient( $wuser );
		}
		
		
		// =============================================================
		//	Perform our login magic and return home
		// =============================================================
		$app	=	JFactory :: getApplication();
		JPluginHelper::importPlugin('user');
		$app->triggerEvent( 'onUserLogin', array( (array) $response, array( 'action' => 'core.login.site', 'jwhmcs' => true ) ) );
		$app->redirect( base64_decode( $returnurl ) );
		return true;
	}
	
	
	/**
	 * Handles the autologout routine coming from WHMCS
	 * @access		private
	 * @version		2.6.03 
	 *
	 * @return		boolean
	 * @since		2.5.0
	 */
	private function _handleAutologouts()
	{
		// Ensure we can run this
		if (! $this->_enabled ) return false;
		
		/* Yeay Dunamis! */
		get_dunamis( 'jwhmcs_sysm' );
		
		// Initialize some fun Dunamis things
		$input	=	dunloader( 'input', true );
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		
		// Be sure we need to do this
		if ( $input->getVar( 'task', false ) != 'autologout' ) {
			return false;
		}
		
		
		// =============================================================
		//	Build our list of variables
		// =============================================================
		
		$token		=	$config->get( 'token' );
		$timestamp	=	(string) $input->getVar( 'timestamp', null, 'STRING', 'get' );
		$signature	=	(string) $input->getVar( 'signature', null, 'STRING', 'get' );
		$random		=	(string) $input->getVar( 'random', null, 'STRING', 'get');
		$returnurl	=	(string) $input->getVar( 'returnurl', null, 'STRING', 'get' );
		
		// Be sure we have it all together
		if (! $timestamp || ! $signature || ! $random || ! $token || ! $returnurl ) {
			return false;
		}
		
		
		// =============================================================
		//	Check we are valid first
		// =============================================================
		$oursign	=	(string) base64_encode( hash_hmac( 'sha256', $random . $timestamp . $token, $token, true ) );
		
		if ( $this->_compareSignatures( $oursign, $signature ) !== true ) {
			return false;
		}
		
		
		// =============================================================
		//	Time check
		// =============================================================
		if ( ( time() - $timestamp ) > 120 ) {
			return false;
		}
		
		
		// =============================================================
		//	Alright, go ahead and logout
		// =============================================================
		$app	=	JFactory :: getApplication();
		$app->logout( null, array( 'jwhmcs' => true ) );
		$app->redirect( base64_decode( $returnurl ) );
		return true;
	}
	
	
	/**
	 * Handles our language appending to any WHMCS URLs
	 * @access		private
	 * @version		2.6.03 
	 * 
	 * @since		2.5.0
	 */
	private function _handleLanguage()
	{
		// Initialize some things
		$input	=	dunloader( 'input', true );
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		$app	=	JFactory :: getApplication();
		
		// Don't run if we are in backend
		if( $app->isAdmin() ) {
			return true;
		}
		
		// If we have disabled language translations, disable it here also
		if (! $config->get( 'languageenable', false ) ) {
			return true;
		}
		
		$db			=	dunloader( 'database', true );
		$html	 	=   JResponse :: getBody();					// Site contents
		$langcurr	=	JFactory :: getLanguage()->getTag();	// Current language of the site
		
		// Find WHMCS URLs and affix the language to them
		$wlang		=	$config->findLanguage( $langcurr );		// Language to use for WHMCS links
		$whmcsurl	=	$config->get( 'whmcsurl', null );
		$whmcsuri	=	DunUri :: getInstance( $whmcsurl, true );
		$whmcsurl	=	preg_quote( $whmcsuri->toString( array( 'user', 'pass', 'host', 'port', 'path', 'query', 'fragment' ) ), '#' );
		$regex		=	'#<a[^>]+([\"\']+)(?P<link>http(?:s|)\://' . $whmcsurl . '[^\1>]*)\1[^>]*>#im';
			
		preg_match_all( $regex, $html, $matches, PREG_SET_ORDER );
			
		foreach ( $matches as $match ) {
			$uri	=	DunUri :: getInstance( $match['link'], true );
			$uri->setVar( 'language', $wlang );
			$repl	=	str_replace( $match['link'], $uri->toString(), $match[0] );
			$html	=	str_replace( $match[0], $repl, $html );
		}
		
		JResponse::setBody( $html );
		
		return true;
	}
	
	
	/**
	 * Method to update a session for a logged in user
	 * @access		private
	 * @version		2.6.03
	 * 
	 * @since		2.5.0
	 */
	private function _updateSessions()
	{
		// Ensure we can run this
		if (! $this->_enabled ) return;
		
		// Initiate some items
		$session	=	JFactory::getSession();
		$instance	=	$session->get('user');
		
		// Bail if we aren't logged in
		if (! is_a( $instance, 'JUser' ) || $instance->guest ) {
			return;
		}
		
		return;
		// ========================================
		// @TODO:  INCORPORATE SESSION MODIFICATION
		// ========================================
		// Load the user from the database
		$dbuser		= new Juser( $instance->get( 'id' ) );
		$changes	= false;
		
		foreach( array( 'email', 'username', 'name' ) as $item ) {
			if ( $dbuser->get( $item ) == $instance->get( $item ) ) continue;
			$instance->set( $item, $dbuser->get( $item ) );
			$changes	= true;
		}
		
		if ( $changes ) {
			$instance->set( 'email', $dbuser->get( 'email' ) );
			$session->set( 'user', $instance );
		}
	}
	
	
	/**
	 * Method to determine if we are using sef rewrite anywhere
	 * @static
	 * @access		public
	 * @version		2.6.03
	 *
	 * @return		boolean
	 * @since		2.5.8
	 */
	private static function _usingSefrewrite()
	{
		$jconfig	=	dunloader( 'config', true );
		
		// Lets test for Joomla core sef first
		if ( $jconfig->get( 'sef_rewrite' ) ) {
			return true;
		}
		
		// Now lets see if sh404sef is installed and set with sef
		$paths	=	array(
				rtrim( JPATH_ADMINISTRATOR, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_sh404sef',
				rtrim( JPATH_SITE, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_sh404sef',
		);
		
		$found = false;
		foreach ( $paths as $path ) {
			if ( is_dir( $path ) ) {
				$found = true;
				break;
			}
		}
		
		if (! $found ) return false;
		
		$sh404	=	JComponentHelper :: getComponent( 'com_sh404sef', true );
		
		if ( $sh404->enabled ) {
			
			$comp = JComponentHelper :: getComponent( 'com_sh404sef' );
			
			if ( is_object( $comp ) ) {
				if ( JComponentHelper :: getComponent( 'com_sh404sef' )->params->get( 'shRewriteMode' ) == '0' ) {
					return true;
				}
				else {
					return false;
				}
			}
			
			// Old school sh404sef
			$files	=	array( 'sh404seffactory.php', 'shSEFConfig.class.php', 'classes' . DIRECTORY_SEPARATOR . 'config.php' );
			$path	=	JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_sh404sef' . DIRECTORY_SEPARATOR;
			
			foreach ( $files as $file ) {
				if ( file_exists( $path . $file ) ) {
					include_once $path . $file;
				}
			}
			
			if ( class_exists( 'Sh404sefFactory' ) ) {
				$shconf	=	Sh404sefFactory :: getConfig();
				
				if ( $shconf->shRewriteMode == '0' ) {
					return true;
				}
			}
		}
		
		return false;
	}
	
	
	
}