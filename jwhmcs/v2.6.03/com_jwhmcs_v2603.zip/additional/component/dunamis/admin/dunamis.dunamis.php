<?php
/**
 * Dunamis
 *
 * @package    Dunamis
 * @copyright  @copyWrite@
 * @license    GNU General Public License version 2, or later
 * @version    1.4.3 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      1.4.0
 *
 * @desc       This file is the Dunamis file for Dunamis component
 *
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Define the Dunamis version here
 */
if (! defined( 'DUN_MOD_DUNAMIS' ) )		define( 'DUN_MOD_DUNAMIS', "1.4.3" );
if (! defined( 'DUN_MOD_COM_DUNAMIS' ) )	define( 'DUN_MOD_COM_DUNAMIS', "1.4.3" );


class Com_dunamisDunModule extends DunModule
{
	public function initialise()
	{
		
	}
}