<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 		API Getinfo File
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.6.03 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.6.02
 *
 * @desc       This is the Getinfo task and provides a means to get the current version via the API
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

jimport( 'joomla.filesystem.folder' );
jimport( 'joomla.filesystem.file' );
jimport( 'joomla.filesystem.path' );

/**
 * Verify Jwhmcs API Class
 * @version		2.6.03
 *
 * @since		2.6.02
 * @author		Steven
 */
class GetinfoJwhmcsAPI extends JwhmcsAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		2.6.03
	 * 
	 * @since		2.6.02
	 * @see			JwhmcsAPI :: execute()
	 */
	public function execute()
	{
		$db			=	dunloader( 'database', true );
		$result		=
		$results	=	
		$data		=   array();
		
		$query	= array();
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$query[]	=   "SELECT * FROM #__extensions WHERE `name` LIKE '%jwhmcs%'";
		}
		else {
			$query[]	=	"SELECT *, 'component' as `type` FROM #__components WHERE `option` LIKE '%com_jwhmcs%'";
			$query[]	=	"SELECT *, 'plugin' as `type` FROM #__plugins WHERE `element` LIKE '%jwhmcs%'";
		}
		
		foreach ( $query as $q ) {
			$db->setQuery( $q );
			$result	=	$db->loadObjectList();
			foreach ( $result as $res ) $results[] = $res;
		}
		
		foreach ( $results as $row ) {
			switch ( $row->type ):
			case 'component':
				$possible	= array();
				$files		= JFolder::files( JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_jwhmcs' . DIRECTORY_SEPARATOR, '\.xml$', false, false );
				if(! empty( $files ) ) foreach ( $files as $filename ) {
					if ( strpos( $filename, 'com_jwhmcs', 0 ) === false ) continue;
					if ( strpos( $filename, 'com_jwhmcs', 0 ) > 0 ) continue;
					$possible[]	= $filename;
				}
				
				rsort( $possible );
				$filename	= JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_jwhmcs' . DIRECTORY_SEPARATOR . array_shift( $possible );
				$name		= 'joomla|component';
			break;
			case 'plugin':
				$path		= version_compare( JVERSION, '1.6.0', 'ge' ) ? $row->element . DIRECTORY_SEPARATOR : '';
				$filename	= JPATH_PLUGINS . DIRECTORY_SEPARATOR . $row->folder . DIRECTORY_SEPARATOR . $path . $row->element . '.xml';
				$name		= 'joomla|' . $row->folder . '-' . $row->element . 'plugin';
			break;
			endswitch;
				
			// ---- BEGIN INT-13
			//		Joomla 3 drops the use of the JFactory XML handler, so we will just use SimpleXML
			$xml	=	simplexml_load_file( $filename );
			$json	=	json_encode( $xml );
			$xobj	=	json_decode( $json );	// awesome trick...
			
			if ( ( $xml->getName() != 'install' ) && ( $xml->getName() != 'extension' ) ) {
				unset($xml);
				$data[$name] = null;
				continue;
			}
			
			$data[$name] = $xobj->version;
			// ---- END INT-13
		}
		
		return $this->success( $data );
	}
}