<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_('behavior.tooltip');
JHTML::_('behavior.formvalidation');

$data = $this->data;

// 3.0+ compatibility inclusion
if ( version_compare( JVERSION, '3', 'ge' ) ) : ?>
<script type="text/javascript">
	Joomla.submitbutton = function( task ) { Joomla.submitform(task, document.getElementById('item-form')); }
</script>
<?php endif; ?>

<div id="jwhmcs">
	
	<form action="index.php" method="post" name="adminForm" class="form-horizontal" id="item-form">
		
		<div class="row">
			
			<div class="span8">
				
				<div class="control-group">
					
					<label class="control-label" for="whmcsurl">
						<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_WHMCSURL_TEXT" ); ?>
					</label>
					
					<div class="controls">
						
						<input	class="text_area required span4"
								type="text"
								name="whmcsurl"
								value="<?php echo $data->whmcsurl; ?>"
								size="40"
								onChange="apicnxnCheck();"
								id="whmcsurl"
								placeholder="http://www.yourdomain.com/whmcs"
								/>
						
						<span class="help-block">
							<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_WHMCSURL_DESC" ); ?>
						</span>
					</div>
				</div>
				
				<div class="control-group">
					
					<label class="control-label" for="whmcsapiusername">
						<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_APIUSERNAME_TEXT" ); ?>
					</label>
					
					<div class="controls">
						
						<input	class="text_area required span4"
								type="text"
								name="whmcsapiusername"
								value="<?php echo $data->whmcsapiusername; ?>"
								size="40"
								onChange="apicnxnCheck();"
								id="whmcsapiusername"
								/>
						
						<span class="help-block">
							<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_APIUSERNAME_DESC" ); ?>
						</span>
					</div>
				</div>
				
				<div class="control-group">
					
					<label class="control-label" for="whmcsapipassword">
						<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_APIPASSWORD_TEXT" ); ?>
					</label>
					
					<div class="controls">
						
						<input	class="text_area required span4"
								type="password"
								name="whmcsapipassword"
								value="<?php echo $data->whmcsapipassword; ?>"
								size="40"
								onChange="apicnxnCheck();"
								id="whmcsapipassword"
								/>
						
						<span class="help-block">
							<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_APIPASSWORD_DESC" ); ?>
						</span>
					</div>
				</div>
				
				<div class="control-group">
					
					<label class="control-label" for="whmcsapiaccesskey">
						<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_APIACCESSKEY_TEXT" ); ?>
					</label>
					
					<div class="controls">
						
						<input	class="span4"
								type="text"
								name="whmcsapiaccesskey"
								value="<?php echo $data->whmcsapiaccesskey; ?>"
								size="40"
								onChange="apicnxnCheck();"
								id="whmcsapiaccesskey"
								/>
						
						<span class="help-block">
							<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_APIACCESSKEY_DESC" ); ?>
						</span>
					</div>
				</div>
			
			</div>
			
			<div class="span4">
			
				<div id="apistatus">
					
					<div id="apistatusimg" class="icon"></div>
					<div id="apistatusmsg" style="width: 200px; margin: 0px auto; font-size: small; font-weight: bold; clear: both; padding: 10px; text-align: center; "></div>
					<div class="alert" id="apistatushelp"></div>
				</div>
				
			</div>
			
		</div>
	<input type="hidden" name="option" value="com_jwhmcs" />
	<input type="hidden" name="apiconnection" id="apiconnection" value="0" />
	<input type="hidden" name="task" value="display" />
	<input type="hidden" name="controller" value="default" />
	<input type="hidden" id="apistatusmsgdefault" value="<?php echo JText::_( "COM_JWHMCS_INSTALL_VIEW_APICNXN_STATUSDEFAULT" ); ?>" />
	</form>
	<script language="javascript">
	window.onload = apicnxnCheck();
	</script>
</div>