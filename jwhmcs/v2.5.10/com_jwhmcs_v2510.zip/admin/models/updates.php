<?php
/**
 * Ajax Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id$
 * @since      2.0.0
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );


/**
 * JwhmcsModelUpdate class handles update retrieval and application
 * @version		2.5.10
 *
 * @since		2.0.0
 * @author		Steven
 */
class JwhmcsModelUpdates extends JwhmcsModelExt
{
	/**
	 * Retrieves the data to render for the view
	 * @access		public
	 * @version		2.5.10 ( $id$ )
	 *
	 * @return		array of objects
	 * @since		2.5.0
	 */
	public function getData( $force = false )
	{
		$elements	=	$this->_getElements();
		$data		=	array();
		$hasupdates	=	false;
		
		foreach ( $elements as $element => $object ) {
			
			// Load up Dunamis!
			get_dunamis( $element );
			$updates	=	dunloader( 'updates', $element, array( 'force' => $force ) );
			
			if (! $updates ) continue;
			
			// ---- BEGIN JWHMCS-10
			//		If Dunamis can't load the element the updates->exist() method fails ugly
			if (! is_object( $updates ) ) continue;
			// ---- END JWHMCS-10
			
			$data[$element]	=	(object) array(
					'name'		=> $object->name,
					'update'	=> $updates->exist(),
					'current'	=> constant( 'DUN_MOD_' . strtoupper( $element ) ),
					'version'	=> null,
					'released'	=> null,
					);
			
			if ( $updates->exist() ) {
				$hasupdates	=	true;
				$data[$element]->version	=	preg_replace( '#^v#', '', $updates->getUpdate()->version );
				$data[$element]->released	=	$updates->getUpdate()->release_date;
			}
		}
		
		$data	=	(object) array(
				'elements'		=> $data,
				'hasupdates'	=>	$hasupdates
				);
		
		return $data;
	}
	
	
	/**
	 * Completes updates available for user
	 * @access		public
	 * @version		2.5.10 ( $id$ )
	 *
	 * @return		object
	 * @since		2.5.0
	 */
	public function updatecomplete()
	{
		$items	=	$this->getData( false );
		$items	=	$items->elements;
		$data	=	(object) array(
				'state'		=>	1,
				'message'	=>	array(),
				);
		
		foreach ( $items as $element => $item ) {
			
			get_dunamis( $element );
			$updates	=	dunloader( 'updates', $element );
			$extracted	=	$updates->extract();
			
			if (! $extracted ) {
				$data->state = 0;
				$data->message[]	=	JText :: sprintf( 'COM_JWHMCS_UPDATES_MESSAGE_EXTRACTFAILED', $item->name );
				continue;
			}
			
			$complete	=	$updates->update();
			
			if (! $complete ) {
				$data->state		=	0;
				$data->message[]	=	JText :: sprintf( 'COM_JWHMCS_UPDATES_MESSAGE_UPDATEFAILED', $item->name );
				continue;
			}
			
			$data->message[]	=	JText :: sprintf( 'COM_JWHMCS_UPDATES_MESSAGE_UPDATESUCCESS', $item->name, $item->version );
		}
		
		$data->message	=	implode( '<br/>', $data->message );
		return $data;
	}
	
	
	/**
	 * Downloads updates available for user
	 * @access		public
	 * @version		2.5.10 ( $id$ )
	 *
	 * @return		object
	 * @since		2.5.0
	 */
	public function updateDownload()
	{
		$items	=	$this->getData( false );
		$items	=	$items->elements;
		
		$data	=	(object) array(
				'state'		=>	1,
				'message'	=>	array(),
				);
		
		foreach ( $items as $element => $item ) {
			
			// Load up Dunamis!
			get_dunamis( $element );
			$updates	=	dunloader( 'updates', $element );
			$result		=	$updates->download();
			
			if (! $result ) {
				$data->state = 0;
				$data->message[]	=	$updates->getError();
				break;
			}
			else {
				$data->message[]	=	sprintf( JText :: _( 'COM_JWHMCS_UPDATES_MESSAGE_DOWNLOADED' ), $item->version, $item->name );
			}
		}
		
		$data->message	=	implode( '<br/>', $data->message );
		
		return $data;
	}
	
	
	/**
	 * Initializes the update routine
	 * @access		public
	 * @version		2.5.10 ( $id$ )
	 *
	 * @return		string
	 * @since		2.5.0
	 */
	public function updateInit()
	{
		$data	=	$this->getData( false );
		$data	=	$data->elements;
		$text	=	array();
		
		foreach ( $data as $item ) {
			$text[]	=	sprintf( JText :: _( 'COM_JWHMCS_UPDATES_MESSAGE_INIT' ), $item->current, $item->name, $item->version );
		}
		
		return implode( '<br/>', $text );
	}
	
	
	/**
	 * Gathers the various elements based on the com_jwhmcs.xml file
	 * @access		private
	 * @version		2.5.10 ( $id$ )
	 *
	 * @return		array of objects
	 * @since		2.5.0
	 */
	private function _getElements()
	{
		// Lets build the component first
		$data	=	array(
				'com_jwhmcs'	=>	(object) array(
						'name' => 'J!WHMCS Integrator Component'
						),
				);
		
		$path	=	JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_jwhmcs' . DS . 'com_jwhmcs.xml';
		$xml	=	simplexml_load_file( $path );
		
		if (! $xml ) {
			return $data;
		}
		
		$additional	=	$xml->xpath( 'additional/*' );
		
		foreach ( $additional as $added ) {
			
			$object			=	(object) array(
									'name' => (string) $added
								);
			
			$elem			=	(string) $added->attributes()->name;
			$data[$elem]	=	$object;
		}
		
		return $data;
	}
}