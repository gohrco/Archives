<?php
/**
 * Help Page Controller for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: helppage.php 555 2012-09-06 02:10:32Z steven_gohigher $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsControllerHelppage
 * Extends:		JwhmcsController
 * Purpose:		Used as the controller for providing support
 * As of:		version 2.1.0
\* ------------------------------------------------------------ */
class JwhmcsControllerHelppage extends JwhmcsController
{
	/* ------------------------------------------------------------ *\
	 * Task:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
	}
	
	
	public function display()
	{
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JwhmcsHelper :: set( 'layout', 'default35' );
		}
		
		parent :: display();
	}
}