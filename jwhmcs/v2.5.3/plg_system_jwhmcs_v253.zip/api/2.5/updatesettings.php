<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 		API Changepassword File
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.5.3 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.5.0
 *
 * @desc       This is the Changepassword Task for the J!WHMCS Integrator API
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Changepassword Jwhmcs API Class
 * @version		2.5.3
 *
 * @since		2.5.0
 * @author		Steven
 */
class UpdatesettingsJwhmcsAPI extends JwhmcsAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		2.5.3
	 * 
	 * @since		2.5.0
	 * @see			JwhmcsAPI :: execute()
	 */
	public function execute()
	{
		$db		=	dunloader( 'database', true );
		$sent	=	(object) dunloader('input',true)->getVar('data', array(), 'array', 'post' );
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		
		_e( $sent );
		_e( $config, 1 );
		// ===================================================================
		// Select the userid based on the email
		// ===================================================================
		$query	=	$db->setQuery( "SELECT u.id FROM #__users AS u WHERE u.email = " . $db->Quote( $sent->email ) );
		if (! ($uid = $db->loadResult() ) ) {
			$this->error( sprintf( JText :: _( 'JWHMCS_SYSM_API_CHANGEPASSWORD_NOTFOUND' ), $sent->email ) );
		}
		
		$user	=	JUser :: getInstance( $uid );
		$data	=	array(
				'password'	=> $sent->password,
				'password2' => $sent->password2
				);
		
		
		// ===================================================================
		// Bind and save the data array
		// ===================================================================
		if (! $user->bind( $data ) ) {
			$this->error( sprintf( JText :: _( 'JWHMCS_SYSM_API_CHANGEPASSWORD_BIND' ), $user->getError() ) );
		}
		
		if (! $user->save() ) {
			$this->error( sprintf( JText :: _( 'JWHMCS_SYSM_API_CHANGEPASSWORD_SAVE' ), $user->getError() ) );
		}
		
		$this->success( sprintf( JText :: _( 'JWHMCS_SYSM_API_CHANGEPASSWORD_SUCCESS' ), $sent->email ) );
	}
}