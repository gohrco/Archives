<?php

/**
 * Define the JWHMCS version here
 */
if (! defined( 'DUN_MOD_JWHMCS' ) ) define( 'DUN_MOD_JWHMCS', "2.5.3" );
if (! defined( 'DUN_MOD_COM_JWHMCS' ) ) define( 'DUN_MOD_COM_JWHMCS', "2.5.3" );


class Com_jwhmcsDunModule extends DunModule
{
	public function initialise()
	{
		
	}
}