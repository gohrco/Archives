<?php
/**
 * J!WHMCS Integrator - System Plugin
 * 		API Changepassword File
 *
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.5.11 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.5.0
 *
 * @desc       This is the Changepassword Task for the J!WHMCS Integrator API
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Menuitems Jwhmcs API Class
 * @version		2.5.11
 *
 * @since		2.5.0
 * @author		Steven
 */
class MenuitemsJwhmcsAPI extends JwhmcsAPI
{
	
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		2.5.11
	 * 
	 * @since		2.5.0
	 * @see			JwhmcsAPI :: execute()
	 */
	public function execute()
	{
		$db			=	dunloader( 'database', true );
		$children	=   array();
		
		// ---- BEGIN JWHMCS-21
		//		Explicitly declare UTF8 as the character set
		mysql_set_charset( 'utf8' );
		// ---- END JWHMCS-21
		
		$query = 'SELECT menutype, title' .
				' FROM #__menu_types' .
				' ORDER BY title';
		$db->setQuery( $query );
		$menuTypes = $db->loadObjectList();
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			$query = 'SELECT id, parent_id, title as name, title, menutype, type, link, lft as ordering FROM #__menu WHERE published = 1';
		}
		else if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$query = 'SELECT id, parent_id, title as name, title, menutype, type, link, ordering FROM #__menu WHERE published = 1';
		}
		else {
			$query = 'SELECT id, parent, parent as parent_id, name, name as title, menutype, type, link, ordering, sublevel FROM #__menu WHERE published = 1';
		}
		
		$db->setQuery($query);
		$menuItems = $db->loadObjectList();
		
		if ($menuItems)
		{
			foreach ($menuItems as $v)
			{
				$pt 	= $v->parent_id;
				$list 	= @$children[$pt] ? $children[$pt] : array();
				array_push( $list, $v );
				$children[$pt] = $list;
			}
		}
		
		$list = JHTML::_('menu.treerecurse', 0, '', array(), $children, 9999, 0, 0 );
		
		$n = count( $list );
		$groupedList = array();
		foreach ($list as $k => $v) {
			if ( empty( $v->menutype ) ) continue;
			$groupedList[$v->menutype][] = &$list[$k];
		}
		
		// Reorganize Menutypes
		$mt	=	array();
		foreach ( $menuTypes as $type ) {
			if (! isset( $mt[$type->menutype] ) ) $mt[$type->menutype] = $type->title;
		}
		
		$return	=	(object) array( 'menuitems' => base64_encode( serialize( $groupedList ) ), 'version' => DUN_ENV_VERSION, 'menutypes' => base64_encode( serialize( $mt ) ) );
		$this->success( $return );
	}
}