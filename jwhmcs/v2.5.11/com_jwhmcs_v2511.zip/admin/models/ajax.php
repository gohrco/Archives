<?php
/**
 * Ajax Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id$
 * @since      2.0.0
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );


/**
 * JwhmcsModelAjax class handles ajax data manipulation
 * @version		2.5.11
 *
 * @since		2.0.0
 * @author		Steven
 */
class JwhmcsModelAjax extends JwhmcsModelExt
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		2.5.11
	 *
	 * @since		2.0.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Method to check the api connection
	 * @access		public
	 * @version		2.5.11 ( $id$ )
	 *
	 * @return		array
	 * @since		2.5.0
	 */
	public function apicnxncheck()
	{
		$data			=	array( 'result' => 'error' );
		$input			=	dunloader( 'input', true );
		$config			=	dunloader( 'config', 'com_jwhmcs' );
		$whmcsurl		=	$input->getVar( 'whmcsurl', null );
		
		// No URL yet
		if ( empty( $whmcsurl ) ) {
			$data['message']	=	'No URL entered';
			$data['helpful']	=	JText :: _( 'COM_JWHMCS_APICNXN_HELP_NOURL' );
			return $data;
		}
		
		// Be sure to urldecode the variables
		$whmcsapiusername	=	$input->getVar( 'whmcsapiusername', null );
		$whmcsapipassword	=	$input->getVar( 'whmcsapipassword', null );
		$whmcsapiaccesskey	=	$input->getVar( 'whmcsapiaccesskey', null );
		
		// If the accesskey should be empty, set it to null
		if (! $whmcsapiaccesskey ) $whmcsapiaccesskey = null;
		
		// If there wasn't a username or password then don't continue
		if ((! $whmcsapiusername ) || (! $whmcsapipassword ) ) {
			$data['message']	= "Please enter a " . ((! $whmcsapiusername ) ? "API Username" : "API Password" );
			$data['helpful']	=	JText :: _( 'COM_JWHMCS_APICNXN_HELP_NO' . (! $whmcsapiusername ? 'USER' : 'PASS' ) );
			return $data;
		}
		
		$config->set( 'whmcsurl', $whmcsurl );
		$config->set( 'whmcsapiusername', $whmcsapiusername );
		$config->set( 'whmcsapipassword', $whmcsapipassword );
		$config->set( 'whmcsapiaccesskey', $whmcsapiaccesskey );
		
		$api	=	dunloader( 'api', 'com_jwhmcs', array( 'force' => true ) );
		
		if ( $api->hasErrors() ) {
			$data['message']	=	$api->getError();
			
			if ( strpos( $data['message'], 'error: 404' ) !== false ) {
				$msg	=	'ER404';
			}
			elseif ( strpos( $data['message'], 'error: 0' ) !== false ) {
				$msg	=	'ER000';
			}
			elseif ( strpos( $data['message'], 'Invalid IP' ) !== false ) {
				$msg	=	'FIXIP';
			}
			elseif ( strpos( $data['message'], 'Invalid Access' ) !== false ) {
				$msg	=	'FIXXS';
			}
			elseif ( strpos( $data['message'], 'Authentication Failed' ) !== false ) {
				$msg	=	'CREDS';
			}
			elseif ( strpos( $data['message'], 'Access Denied' ) !== false ) {
				$msg	=	'NOAXS';
			}
			
			$data['helpful']	=	JText :: _( 'COM_JWHMCS_APICNXN_HELP_' . $msg );
			return $data;
		}
		
		if ( ( $msg = $config->save() ) !== true ) {
			$data['message']	=	$msg;
			$data['helpful']	=	JText :: _( 'COM_JWHMCS_APICNXN_HELP_DBERR' );
			return $data;
		}
		
		$data['result']		=	'success';
		$data['message']	=	'Successfully connected!';
		$data['helpful']	=	JText :: _( 'COM_JWHMCS_APICNXN_HELP_SAVED' );
		return $data;
	}
	
	
	/**
	 * ??????
	 */
	
	/**
	 * Called to check the API connection from the "API Connection" feature
	 * @access		public
	 * @version		2.5.11
	 * 
	 * @return		array containing results
	 * @since		2.0.0
	 */
	public function checkApiu()
	{
		$jwhmcsurl	= rtrim(trim( urldecode( JRequest::getVar( 'jwhmcsurl' ) ) ), '/' );
		
		// If we didn't get a URL then don't continue
		if (!$jwhmcsurl) {
			$data['result'] = 'error';
			$data['message'] = 'No URL entered';
			return $data;
		}
		
		// Be sure to urldecode the variables
		$jwhmcsus	= urldecode( JRequest::getVar( 'jwhmcsadminus' ) );
		$jwhmcspw	= urldecode( JRequest::getVar( 'jwhmcsadminpw' ) );
		$jwhmcsxs	= trim( urldecode( JRequest::getVar( 'accesskey' ) ) );
		
		// If the accesskey should be empty, set it to null
		if (! $jwhmcsxs ) $jwhmcsxs = null;
		
		// If there wasn't a username or password then don't continue
		if ((! $jwhmcsus ) || (! $jwhmcspw ) ) {
			$data['result']	= 'error';
			$data['message']	= "Please enter a " . ((! $jwhmcsus ) ? "API Username" : "API Password" );
			return $data;
		}
		
		// If the password has an & we can't authenticate (WHMCS filters them out)
		if ( strpos( $jwhmcspw, "&" ) !== false ) {
			$data['result']	= 'error';
			$data['message']	= "Your API password cannot contain an ampersand.";
			return $data;
		}
		
		// Set API settings and chceck connection
		$params = JwhmcsParams::getInstance();
		$params->set( 'ApiUrl', $this->_quickParseUrl($jwhmcsurl), false, 'global' );
		$params->set( 'ApiUsername', $jwhmcsus, false, 'global' );
		$params->set( 'ApiPassword', $jwhmcspw, false, 'global' );
		$params->set( 'ApiAccesskey', $jwhmcsxs, false, 'global' );
		$params->saveAll();
		
		return $this->getApiConnection();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		checkPath
	 * Purpose:		Called during install to check path of WHMCS
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function checkPath()
	{
		$jcurl = JwhmcsCurl::getInstance();
		$files = array( 'configuration.php', 'dologin.php' );
		
		$whmcsurl	= trim( urldecode( JRequest::getVar( 'whmcsurl' ) ) );
		$whmcspath	= trim( urldecode( JRequest::getVar( 'whmcspath' ) ) );
		
		$url = false;
		$path = false;
		
		if (!$whmcsurl) {
			$msg[] = 'No Url Entered';
		}
		else {
			// Test URL to see if dbconnect exists
			$url = $this->_buildUrl($whmcsurl, 'dbconnect.php');
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->setParse(false);
			$jcurl->loadResults();
			
			if ($jcurl->info['http_code'] != 200 ) {
				$msg[] = 'WHMCS Not Found at URL';
			}
			else {
				$url = true;
				$msg[] = 'WHMCS Url Valid!';
			}
		}
		
		if (!$whmcspath) {
			$msg[] = 'No Path Entered';
		}
		else {
			// Test Path to see if files exist there
			$whmcspath = JFolder::makesafe( $whmcspath );
			if (! JFolder::exists( $whmcspath ) ) {
				$msg[] = 'WHMCS Path does not exist';
			}
			else {
				$path = true;
				foreach ($files as $file) {
					if (! JFile::exists($whmcspath.DS.$file) ) {
						$path = false;
					}
				}
				if ($path) {
					$msg[] = 'WHMCS Path Valid!';
				}
				else {
					$msg[] = 'WHMCS Path not valid';
				}
			}
		}
		
		if (($url === true) && ($path === true)) {
			$data['result'] = 'success';
		}
		else {
			$data['result'] = 'error';
		}
		
		$data['message'] = implode("<br />", $msg);
		
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		checkValidLicense
	 * Purpose:		Called during install to check license
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	function checkValidLicense()
	{
		$license = trim( urldecode( JRequest::getVar( 'license' ) ) );
		
		$params = JwhmcsParams::getInstance();
		$params->set( 'LicenseKey', $license, false, 'global' );
		$params->set( 'License', '', false, 'global' );
		$params->saveAll();
		
		$lic = $this->checkLicense();
		if ($lic['valid']) {
			$data['result'] = 'success';
			$data['message'] = 'License is valid';
		}
		else {
			$data['result'] = 'error';
			$data['message'] = ( $lic['upgrade'] ? $lic['upgrade'] : 'License entered not valid' );
		}
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_buildUrl (private)
	 * Purpose:		build a url
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	private function _buildUrl($path, $file)
	{
		$uri = JURI::getInstance( rtrim($path, '/').'/'.$file );
		return $uri->toString();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_quickParseUrl (private)
	 * Purpose:		Parse a url
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	private function _quickParseUrl($url)
	{
		$tmp = JURI::getInstance($url);
		
		return $tmp->toString();
		/*$tmp = parse_url($url);
		
		// Remove a slash if added to the end of the url and set parameter
		if ($tmp['path']=='/') unset($tmp['path']);
		return $tmp['host'].(isset($tmp['path'])?$tmp['path']:'').(isset($tmp['query'])?$tmp['query']:'').(isset($tmp['fragment'])?$tmp['fragment']:'');
		*/
	}
}

?>