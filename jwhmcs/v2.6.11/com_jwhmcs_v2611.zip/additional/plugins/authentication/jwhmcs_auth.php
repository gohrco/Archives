<?php
/**
 * J!WHMCS Integrator - Authentication Plugin
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009-2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: jwhmcs_auth.php 830 2014-11-25 00:03:13Z steven_gohigher $
 * @since      1.5.1
 * 
 * @desc		This plugin handles authentication of the user in case they use
 * 				their email address instead of their Joomla username.
 */


// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'dunamis.dunamis' );
jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.application.component.helper' );

$path	= JPATH_ADMINISTRATOR . '/components/com_jwhmcs/jwhmcs.helper.php';
if ( file_exists( $path ) ) require_once( $path );


/**
 * Authentication - J!WHMCS Integrator plugin
 * @version		2.6.11
 * 
 * @since		1.5.1
 * @author		Steven
 */
class plgAuthenticationJwhmcs_auth extends JPlugin
{
	/**
	 * Permits overriding of plugin activation if left unconfigured
	 * @access		private
	 * @var			boolean
	 * @since		2.5.0
	 */
	private $_enabled	=	false;
	
	private $e		= false;	// Error holder
	private $whmcs	= false;	// Is this coming from whmcs? T/F
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		2.5.0		- June 2013: complete rewrite
	 * @version		2.6.11
	 * @param		unknown_type	- $subject
	 * @param		unknown_type	- $config
	 * 
	 * @since		1.5.1
	 */
	public function __construct(& $subject, $config)
	{
		parent :: __construct( $subject, $config );
		
		$this->loadLanguage();
		
		$app		=	JFactory :: getApplication();
		
		// Run through tests
		// -----------------
		// Ensure we have Dunamis installed
		if (! function_exists( 'get_dunamis' ) ) {
			return;
		}
		
		// All good, lets go
		$this->_enabled	=	true;
	}
	
	
	/**
	 * Authenticate the user against Joomla or WHMCS
	 * @access		public
	 * @version		2.6.11
	 * @version		2.5.0		- June 2013: complete rewrite
	 * @version		2.1.0		- April 2010: added subaccount authentication
	 * @version		2.0.2		- March 2010: modified response when getting results for email to look for array
	 * @param		array		- $credentials: the passed credentials
	 * @param		array		- $options: the options passed
	 * @param		object		- $response: object
	 *
	 * @return		boolean
	 * @since		1.5.1
	 */
	public function onUserAuthenticate( $credentials, $options, $response )
	{
		// Ensure we can run this
		if (! $this->_enabled ) {
			return;
		}
		
		// Don't auth against W if we are coming from W
		if ( isset( $options['jwhmcs'] ) && $options['jwhmcs'] ) {
			return;
		}
		
		/* Double check against API constant */
		if ( defined( 'JWHMCSAPI' ) ) {
			return;
		}
		
		/* Load Dunamis */
		get_dunamis( 'com_jwhmcs' );
		
		/* Establish the API */
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		$api	=	dunloader( 'api', 'com_jwhmcs' );
		$hlps	=	dunloader( 'helpers', 'com_jwhmcs' );
		
		/* Set some vars and check username is email */
		$username	=	$credentials['username'];
		$password	=	$credentials['password'];
		
		if ( empty( $password ) ) {
			return false;
		}
		
		if (! is_email( $username ) ) {
			return;
		}
		
		/* We have an email and password so lets validate them */
		if (! $api->validatelogin( $username, $password ) ) {
			return false;
		}
		
		
		/* ------------------------------------------------- *\
		 * User is now validated against WHMCS if still here *
		 * ------------------------------------------------- */
		
		/* Locate the Joomla user if they exist */
		$juser	=	$this->_getJoomlauser( $username, 'email' );
		
		/* We found a user so bind to response and go home */
		if ( $juser ) {
			
			if ( $config->get( 'requireactivation' ) && ( $juser->blocked || $juser->activation ) ) {
				JError::raiseWarning('SOME_ERROR_CODE', JText::_('JERROR_NOLOGIN_BLOCKED'));
				return false;
			}
			
			$response->fullname 		= $juser->name;
			$response->username			= $juser->username;
			$response->email			= $juser->email;
			$response->password			= $juser->password;
			$response->password_clear	= $credentials['password'];
			$response->status			= 1;
			$response->error_message	= '';
			return true;
		}
		
		
		/* ------------------------------------------------- *\
		 * No matching user in Joomla if we are still here   *
		 * ------------------------------------------------- */
		
		$method	=	$config->get( 'useraddmethod' );
		
		/* Verify we are permitted to create the user in Joomla */
		if (! in_array( $method, array( '1', '4' ) ) ) {
			return false;
		}
		
		/* Lets build the registration object here */
		$params			=	JComponentHelper :: getParams( 'com_users' );
		$useractivation	=	$params->get( 'useractivation' );
		$sendpassword	=	$params->get( 'sendpassword', 1 );
		$user			=	new JUser;
		$data			=	array();
		
		/* Prepare the data for the user object */
		$data['name']		=	$this->_build_fullname( $credentials );
		$data['username']	=	$this->_build_username( $credentials );
		$data['email']		=	$credentials['username'];
		$data['password']	=	$credentials['password'];
		
		/* Set J2.5 new user type if not in config file and add to bind array */
		if (! $newUsertype ) {
			$newUsertype = 2;
		}
		
		$data['groups'][] = $newUsertype;
			
		/* Check if the user needs to activate their account.
		 * 1 = self; 2 = admin approval
		 */
		if ( ( $useractivation == 1 ) || ( $useractivation == 2 ) ) {
			jimport('joomla.user.helper');
		
			// Yes, 3.0 does things differently but just enough
			if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
				$data['activation']	= JApplication :: getHash( JUserHelper :: genRandomPassword() );
			}
			else {
				$data['activation'] = JUtility::getHash(JUserHelper::genRandomPassword());
			}
			
			$data['block'] = 1;
		}
		
		/* Prevent Recursion in User Plugin */
		define( 'JWHMCSAUTH', true );
		
		/* Bind the data */
		if (! $user->bind( $data ) ) {
			return false;
		}
		
		/* Load the users plugin group */
		JPluginHelper :: importPlugin( 'user' );
		
		/* Store the data */
		if (! $user->save() ) {
			return false;
		}
		
		$response->fullname 		=	$user->name;
		$response->username			=	$user->username;
		$response->email			=	$user->email;
		$response->password			=	$user->password;
		$response->password_clear	=	$credentials['password'];
		$response->status			=	1;
		$response->error_message	=	'';
		return true;
	}
	
	
	/**
	 * Method for building a fullname for the user object
	 * @access		private
	 * @version		2.6.11 ( $id$ )
	 * @param		array		- $credentials: the credentials we were passed
	 *
	 * @return		string
	 * @since		2.5.0
	 */
	private function _build_fullname( $credentials )
	{
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		$api	=	dunloader( 'api', 'com_jwhmcs' );
		$email	=	$credentials['username'];
		$user	=	$api->findmatchinguser( $email );
		$name	=	build_fullname( $user );
		return $name;
	}
	
	
	
	/**
	 * Method for building the username for the user object
	 * @access		private
	 * @version		2.6.11 ( $id$ )
	 * @param		array		- $credentials: the credentials we were passed
	 *
	 * @return		string
	 * @since		2.5.0
	 */
	private function _build_username( $credentials )
	{
		$config	=	dunloader( 'config', 'com_jwhmcs' );
		$api	=	dunloader( 'api', 'com_jwhmcs' );
		$email	=	$credentials['username'];
		
		switch ( $config->get( 'useraddusernamemethod' ) ) :
		// Retrieve from WHMCS
		case '0' :
			$username	=	$api->getusername( $email );
			
			break;
		// Build locally
		case '1' :
			$user		=	$api->findmatchinguser( $email );
			$username	=	build_username( $user );
			break;
		endswitch;
		
		return (string) $username;
	}
	
	
	/**
	 * Grabs the Joomla user data
	 * @access		private
	 * @version		2.6.11
	 * @version		2.5.0		- June 2013: method renamed
	 * @param		string		- $method: username or email
	 * @param		string		- $by: indicates how we should get the user
	 *
	 * @return		object
	 * @since		2.1.0
	 */
	private function _getJoomlauser($method, $by = 'username')
	{
		$db = & JFactory::getDBO();
	
		$query	= "SELECT a.* FROM `#__users` AS a WHERE {$by}={$db->Quote($method)}";
		$db->setQuery($query);
		return $db->loadObject();
	}
	
	
	/**
	 * Event called when gathering update sites to check for updates
	 * @access		public
	 * @version		2.6.11
	 *
	 * @return		array
	 * @since		2.4.0
	 */
	public function getUpdateSite()
	{
		return array(
				'extensionName'				=> 'plg_jwhmcs_auth',
				'options' => array(
						'extensionTitle'	=> 'J!WHMCS Integrator Authentication Plugin',
						'storage'			=> 'database',
						'storagePath'		=> null,
						'extensionType'		=> 'plugin',
						'updateUrl'			=> 'https://www.gohigheris.com/updates/jwhmcs/plugins/auth'
				)
		);
	}
}