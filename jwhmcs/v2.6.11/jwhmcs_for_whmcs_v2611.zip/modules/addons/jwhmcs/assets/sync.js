
jQuery( '#syncsearch' ).on( 'change', function() {
	loadSyncTable();
});

jQuery( '#synccount' ).on( 'change', function() {
	loadSyncTable();
});

jQuery( '#syncpage' ).on( 'change', function() {
	loadSyncTable();
});

jQuery(document).ready( function() {
	loadSyncTable();
});


function loadSyncAll()
{
	jQuery( '#syncallbutton' ).attr( "disabled", true );
	syncAll( 1, 0 );
	jQuery( '#syncallbutton' ).attr("disabled", false );
}


function loadSyncTable()
{
	var count		=	jQuery( '#synccount' ).val();
	var search		=	jQuery( '#syncsearch').val();
	var sort		=	jQuery( '#syncsort' ).val();
	var sortdir		=	jQuery( '#syncsortdir' ).val();
	var page		=	jQuery( '#syncpage' ).val();
	var content		=	jQuery( '#synccontent' );
	
	content.html( "<div class='loading'>&nbsp;</div>" );
	jQuery( '#syncallbutton' ).attr( "disabled", true );
	
	// Make the Ajax Call
	var resp	= jQuery.ajax({
					type: "POST",
					url: ajaxurl + '/ajax.php',
					dataType: 'json',
					data: { task: 'syncfetch', count: count, search: search, sort: sort, sortdir: sortdir, page: page
					}
				});
	
	// Success
	resp.done( function( msg ) {
		
		switch ( msg.state ) {
		// Everything is awesome
		case true:
			
			content.html( msg.data );
			
			var table = jQuery('#synctable').DataTable( {
				"bFilter": false,
				"paging": false,
				"info": false,
				"order": [msg.sort, msg.dir ],
				"columns": [
				            null,
				            null,
				            null,
				            null,
				            { "orderable": false }
				],
			});
			
			jQuery('#synctable').on( 'click', 'thead th', function () {
				var idx		=	jQuery("#synctable").dataTable().fnSettings().aaSorting;
				var col		=	idx[0][0];
				var sort	=	idx[0][1];
				
				jQuery( '#syncsort' ).val(col);
				jQuery( '#syncsortdir' ).val( sort );
			});
			
			jQuery( '#syncpage' ).empty().append( msg.pages );
			
			jQuery( 'button[data-action="sync"]' ).on( 'click', function() { runSync(jQuery(this).data('identity')) } );
			
			break;
		
		// Some error
		case false:

			content.html( msg.message );
			
			break;
		}
		
		jQuery( '#syncallbutton' ).attr( "disabled", false );
	});
	
	// Failure
	resp.fail( function( jqXHR, msg ) {
		alert( msg );
	});
}


function runSync(id)
{
	console.log( id );
	jQuery( '#syncallbutton' ).attr( "disabled", true );
	
	// Make the Ajax Call
	var resp	= jQuery.ajax({
					type: "POST",
					url: ajaxurl + '/ajax.php',
					dataType: 'json',
					data: { task: 'syncuser', id: id
					}
				});
	
	// Success
	resp.done( function( msg ) {
		
		switch ( msg.state ) {
		// Everything is awesome
		case true:
			
			jQuery( '#spansync' + id ).removeClass( 'label-inverse label-important' ).addClass( 'label-success' ).html( 'Yes' );
			jQuery( '#button' + id ).remove();
			
			break;
		
		// Some error
		case false:

			jQuery( '#spansync' + id ).removeClass( 'label-inverse label-success' ).addClass( 'label-important' ).html( 'Error' );
			console.log( msg.error );
			
			break;
		}
		
		jQuery( '#syncallbutton' ).attr( "disabled", false );
	});
	
	// Failure
	resp.fail( function( jqXHR, msg ) {
		alert( msg );
	});
}


function syncAll( step, recs, total )
{
	step	=	typeof step !== 'undefined' ? step : 1;
	recs	=	typeof recs !== 'undefined' ? recs : 10;
	total	=	typeof total !== 'undefined' ? total : 0;
	
	jQuery( '#syncallbutton' ).attr( "disabled", true );
	
	// Make the Ajax Call
	var resp	= jQuery.ajax({
					type: "POST",
					url: ajaxurl + '/ajax.php',
					dataType: 'json',
					data: { task: 'syncall', step: step, records: recs, total: total
					}
				});
	
	// Success
	resp.done( function( msg ) {
		
		switch ( msg.state ) {
		// Everything is awesome
		case true:
			
			jQuery( '#synccontent' ).html( msg.html );
			
			if ( msg.step == '2' ) {
				syncAll( 2, msg.records, msg.total );
			}
			
			if ( msg.step == '3' ) {
				loadSyncTable();
			}
			
			break;
		
		// Some error
		case false:

			console.log( msg.error );
			
			break;
		}
	});
	
	// Failure
	resp.fail( function( jqXHR, msg ) {
		alert( msg );
	});
}