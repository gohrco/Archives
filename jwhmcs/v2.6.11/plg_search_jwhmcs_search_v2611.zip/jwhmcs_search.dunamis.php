<?php

defined('_JEXEC') or die( 'Restricted access' );

/**
 * Define the JWHMCS version here
 */
if (! defined( 'DUN_MOD_JWHMCS' ) ) define( 'DUN_MOD_JWHMCS', "2.6.11" );
if (! defined( 'DUN_MOD_JWHMCS_SEARCH' ) ) define( 'DUN_MOD_JWHMCS_SEARCH', "2.6.11" );


class Jwhmcs_searchDunModule extends DunModule
{
	public function initialise()
	{
		
	}
}