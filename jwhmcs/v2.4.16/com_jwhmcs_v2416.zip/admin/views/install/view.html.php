<?php
/**
 * WHMCS User Synchrization View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: view.html.php 555 2012-09-06 02:10:32Z steven_gohigher $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );


/**
 * View for Install manager of J!WHMCS Integrator
 * @version		2.4.16
 *
 * @author		Steven
 * @since		1.5.1
 */
class JwhmcsViewInstall extends JwhmcsView
{
	
	/**
	 * Display view
	 * @access		public
	 * @version		2.4.16
	 * @param		unknown		- $tpl: override to pass for tpl
	 *
	 * @since		1.5.1
	 */
	public function display($tpl = null)
	{
		$model	= & $this->getModel( 'install' );
		$task	=   JwhmcsHelper :: get( 'task' );
		$data	=   $model->$task();
		
		JwhmcsToolbar :: build( 'install', $task );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JwhmcsHelper :: addMedia( 'ajax35/js' );
			JwhmcsHelper :: addMedia( 'icons35/css' );
			JwhmcsHelper :: addMedia( 'install/css' );
		}
		else {
			JwhmcsHelper :: addMedia( 'common/js' );
			JwhmcsHelper :: addMedia( 'ajax/js' );
			JwhmcsHelper :: addMedia( 'icons/css' );
			JwhmcsHelper :: addMedia( 'install/css' );
		}
		
		$this->assignRef('data', $data);
		parent::display($tpl);
	}
}