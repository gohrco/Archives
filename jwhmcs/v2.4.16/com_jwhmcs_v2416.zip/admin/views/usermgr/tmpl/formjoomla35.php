<?php defined('_JEXEC') or die('Restricted access');

$isNew	= (isset($this->data->id)?($this->data->id < 1?true:false):true);

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('behavior.keepalive');

?>


<script type="text/javascript">
	Joomla.submitbutton = function( task ) {
		if ( task == 'cancel' || document.formvalidator.isValid(document.id('item-form'))) {
			Joomla.submitform(task, document.getElementById('item-form'));
		} else {
			alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED'));?>');
		}
	}
</script>

<form action="index.php" method="post" id="item-form" name="adminForm" class="form-validate form-horizontal">

	<div class="control-group">
		<div class="control-label">
			<label for="form[name]" class="hasTip" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_NAME" ); ?>::<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_NAME" ); ?>"><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_NAME" ); ?></label>
		</div>
		<div class="controls">
			<input class="validate-text required" type="text" name="form[name]" id="name" size="40" maxlength="255" value="<?php echo $isNew?'':$this->data->name; ?>" />
		</div>
	</div>
	
	<div class="control-group">
		<div class="control-label">
			<label for="form[username]" class="hasTip" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_USERNAME" ); ?>::<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_USERNAME" ); ?>"><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_USERNAME" ); ?></label>
		</div>
		<div class="controls">
			<input class="text_area required" type="text" name="form[username]" id="username" size="40" maxlength="255" value="<?php echo $isNew?'':$this->data->username; ?>" />
		</div>
	</div>
	
	<div class="control-group">
		<div class="control-label">
			<label for="form[emaildis]" class="hasTip" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_EMAIL" ); ?>::<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_EMAIL" ); ?>"><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_EMAIL" ); ?></label>
		</div>
		<div class="controls">
			<input class="text_area required" type="text" name="form[emaildis]" id="email" size="40" maxlength="255" value="<?php echo $this->data->email; ?>" disabled />
		</div>
	</div>
	
	<div class="control-group">
		<div class="control-label">
			<label for="form[password]" class="hasTip" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_TMPPASS" ); ?>::<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_TMPPASS" ); ?>"><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_TMPPASS" ); ?></label>
		</div>
		<div class="controls">
			<input class="text_area required" type="text" name="form[password]" id="password" size="40" maxlength="255" value="temppass" />
		</div>
	</div>
	
	<div class="control-group">
		<div class="control-label">
			<label for="form[password2]" class="hasTip" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_CONPASS" ); ?>::<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_CONPASS" ); ?>"><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_CONPASS" ); ?></label>
		</div>
		<div class="controls">
			<input class="text_area required" type="text" name="form[password2]" id="password2" size="40" maxlength="255" value="temppass" />
		</div>
	</div>
	
	<div class="control-group">
		<div class="control-label">
			<label for="form[gid]" class="hasTip" title="<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_GROUP" ); ?>::<?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_SELGROUP" ); ?>"><?php echo JText::_( "COM_JWHMCS_USERMGR_VIEW_LABEL_GROUP" ); ?></label>
		</div>
		<div class="controls">
			<?php echo $this->data->gidtypes; ?>
		</div>
	</div>
	
	<input type="hidden" name="whmcsid" value="<?php echo $this->data->wid; ?>" />
	<input type="hidden" name="joomlaid" value="<?php echo $this->data->id; ?>" />
	<input type="hidden" name="option" value="com_jwhmcs" />
	<input type="hidden" name="task" value="" />
	<?php if ($this->data->contact): ?>
	<input type="hidden" name="contact" value="1" />
	<?php endif; ?>
	<input type="hidden" name="subtask" value="<?php echo JRequest::getVar( 'task' ); ?>" />
	<input type="hidden" name="controller" value="usermgr" />
	<input type="hidden" name="form[email]" value="<?php echo $this->data->email; ?>" />
	<?php echo JHTML::_( 'form.token' ); ?>
</form>