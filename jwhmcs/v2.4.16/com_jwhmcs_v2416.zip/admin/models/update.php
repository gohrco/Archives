<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.4.16 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.4.0
 * 
 * @desc       This is the updates model file for the backend of J!WHMCS Integrator
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die();
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.model');
jimport('joomla.filesystem.folder');
include_once(JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR .'classes' . DIRECTORY_SEPARATOR . 'class.curl.php');
/*-- File Inclusions --*/ 

/**
 * Jwhmcs Rules Model
 * @author		Steven
 * @version		2.4.16
 * 
 * @since		2.4.0
 */
class JwhmcsModelUpdate extends JwhmcsModel
{
	
	/**
	 * Method to cleanup any downloaded and extracted files
	 * @access		public
	 * @version		2.4.16
	 * @param		array		- $update: contains the update to cleanup for
	 * 
	 * @since		2.4.0
	 */
	public function cleanup( $update = null )
	{
		if ( $update == null ) return false;
		
		$session	= & JFactory :: getSession();
		$ext		=   $update['config']->get( '_extensionName' );
		$target		=   $session->get('target', '', 'jwhmcs.' . $ext );
		$tempdir	=   $session->get('tempdir', '', 'jwhmcs.' . $ext );
		
		jimport('joomla.installer.helper');
		JInstallerHelper::cleanupInstall($target, $tempdir);
		
		$session->clear('target', 'jwhmcs.' . $ext );
		$session->clear('tempdir', 'jwhmcs.' . $ext );
	}
	
	
	/**
	 * Method to download for a given update
	 * @access		public
	 * @version		2.4.16
	 * @param		array		- $update: contains the update to cleanup for
	 * 
	 * @return		boolean
	 * @since		2.4.0
	 */
	public function download( $update = null )
	{
		if ( $update == null ) return false;
		
		$tmpdir = $this->_getTmpdir();
		$url	= $update['update']->downloadURL;
		$creds	= $update['update']->creds;
		$type	= $this->_getFiletype( $url );
		$ext	= $update['config']->get( '_extensionName' );
		
		$target		= $tmpdir . DS . $ext . '.update.' . $type;
		$tempdir	= $tmpdir . DS . $ext . '_update';
		
		$session = JFactory::getSession();
		$session->set( 'target',	$target,	'jwhmcs.' . $ext );
		$session->set( 'tempdir',	$tempdir,	'jwhmcs.' . $ext );
		
		require_once( JPATH_COMPONENT_ADMINISTRATOR . DS . 'update' . DS . 'classes' . DS . 'download.php' );
		return JwhmcsDownloadHelper :: download( $url, $target, $update['config'], $creds );
	}
	
	
	/**
	 * Method to extract a given update
	 * @access		public
	 * @version		2.4.16
	 * @param		array		- $update: contains the update to cleanup for
	 * 
	 * @return		boolean
	 * @since		2.4.0
	 */
	public function extract( $update = null )
	{
		if ( $update == null ) return false;
		
		$session	= & JFactory :: getSession();
		$ext		=   $update['config']->get( '_extensionName' );
		$target		=   $session->get('target', '', 'jwhmcs.' . $ext );
		$tempdir	=   $session->get('tempdir', '', 'jwhmcs.' . $ext );
		
		jimport( 'joomla.filesystem.archive' );
		return JArchive :: extract( $target, $tempdir);
	}
	
	
	/**
	 * Method to install a given update
	 * @access		public
	 * @version		2.4.16
	 * @param		array		- $update: contains the update to cleanup for
	 * 
	 * @return		boolean
	 * @since		2.4.0
	 */
	public function install( $update = null )
	{
		if ( $update == null ) return false;
		
		jimport( 'joomla.installer.installer' );
		jimport( 'joomla.installer.helper' );
		
		$session	= & JFactory :: getSession();
		$installer	= & JInstaller :: getInstance();
		$ext		=   $update['config']->get( '_extensionName' );
		$title		=	$update['config']->get( '_extensionTitle' );
		$tempdir	=   $session->get('tempdir', '', 'jwhmcs.' . $ext );
		
		// Intercept non-Joomla file updates first
		if ( $update['config']->get( '_extensionType' ) == 'file' )
		{
			$result = $this->_updateFile( $update['config']->get( '_targetPlatform' ), $tempdir, $update );
		}
		// Check for Joomla updates now
		else {
			$packageType	= JInstallerHelper :: detectType( $tempdir );
			
			if (! $packageType ) {
				$msg	= JText :: sprintf( 'COM_JWHMCS_UPDATES_ERROR_INVALIDPKGTYPE', $title );
				$result	= false;
			}
			else if (! $installer->install( $tempdir ) ) {
				$msg	= JText :: sprintf( 'COM_JWHMCS_UPDATES_ERROR_INSTALLFAIL', $title );
				$result	= false;
			} 
			else {
				$msg	= JText :: sprintf( 'COM_JWHMCS_UPDATES_SUCCEED_INSTALL', $title );
				$result	= true;
			}
		
			if ( $result ) {
				$app	= & JFactory :: getApplication();
				$app->enqueueMessage( $msg );
			}
			else {
				JError::raiseWarning('SOME_ERROR_CODE', $msg );
			}
		}
		
		return $result;
	}
	
	
	/**
	 * Method to copy files from this location to a remote location
	 * @access		private
	 * @version		2.4.16
	 * @param		string		- $tempdir: contains the temporary directory that is the source
	 * @param		string		- $src_url: contains the source URL
	 * @param		string		- $dest: contains the relative destination
	 * 
	 * @return		boolean
	 * @since		2.4.0
	 */
	private function _copyFiles( $tempdir, $src_url, $dest = null )
	{
		jimport('joomla.filesystem.file');
		
		$files	=   $this->_getTempfiles( $tempdir );
		$jcurl	= & JwhmcsCurl :: getInstance( true );
		$jcurl->setParse( false );
		$undo	=   false;
		
		foreach ( $files as $file ) {
			if ( $file == '.' || $file == '..' ) continue;
			
			if ( strpos( $file, '.php' ) !== false ) {
				$old	= $file;
				$file	= str_replace( '.php', '.myb', $file );
				
				$target	= $tempdir . DS . $file;
				
				if ( JFile :: exists( $target ) ) {
					if (! @unlink( $target ) ) {
						JFile::delete( $target );
					}
				}
				
				rename( $tempdir . DS . $old, $tempdir . DS . $file );
			}
			
			$tmpdest = $dest . '::::' . $file;
			$tmpsrc  = $tempdir . DS . $file;
			$tmpurl  = $src_url . '/' . $file;
			
			JwhmcsDownloadHelper :: chmod ( $tmpsrc, '0755' );
			
			if ( is_dir( $tmpsrc ) )
			{
				$jcurl->setAction( 'jwhmcs', array( 'task' => 'update', 'responsetype' => 'json', 'step' => '2', 'url' => $url, 'file_source' => $tmpurl, 'file_dest' => $tmpdest, 'is_dir' => 'true' ) );
				$return	= $jcurl->loadResults();
				
				if ( $return === false ) return false;
				$return	= @json_decode( $return, true );
				
				if ( $result['result'] == 'error' ) return false;
				
				$this->_copyFiles( $tmpsrc, $tmpurl, $tmpdest );
			}
			else {
				$jcurl->setAction( 'jwhmcs', array( 'task' => 'update', 'responsetype' => 'json', 'step' => '2', 'url' => $url, 'file_source' => $tmpurl, 'file_dest' => $tmpdest, 'is_dir' => 'false' ) );
				
				$return	= $jcurl->loadResults();
				
				if ( $return === false ) return false;
				$return	= @json_decode( $return, true );
				
			}
			
			if ( $result['result'] == 'error' ) return false;
		}
		
		return true;
	}
	
	
	/**
	 * Method to determine the file type
	 * @access		private
	 * @version		2.4.16
	 * @param		string		- $url: contains the url of the destination file
	 * 
	 * @return		string containing what type of file we are using
	 * @since		2.4.0
	 */
	private function _getFiletype( $url )
	{
		$basename = basename( $url );
		
		if ( strstr( $basename, '?' ) ) {
			$basename = substr( $basename, strstr( $basename, '?' ) + 1 );
		}
		
		switch ( substr( $basename, -4 ) ) {
			case '.zip': $type = 'zip'; break;
			case '.tar': $type = 'tar'; break;
			case '.tgz': $type = 'tar.gz'; break;
			default:
				$type	= ( substr( $basename, -7 ) == '.tar.gz' ? 'tar.gz' : 'zip' );
		}
		
		return $type;
	}
	
	
	/**
	 * Method to read the temporary files from the temp directory
	 * @access		private
	 * @version		2.4.16
	 * @param		string		- $tempdir: the temporary directory
	 * 
	 * @return		array of files / directories
	 * @since		2.4.0
	 */
	private function _getTempfiles( $tempdir )
	{
		return scandir( $tempdir );
	}
	
	
	/**
	 * Method for determining the temporary directory
	 * @access		private
	 * @version		2.4.16
	 * 
	 * @return		string containing temporary path
	 * @since		2.4.0
	 */
	private function _getTmpdir()
	{
		$jreg	= & JFactory::getConfig();
		$tmpdir =   $jreg->get( 'config.tmp_path' );
		
		// Make sure the user doesn't use the system-wide tmp directory. You know, the one that's
		// being erased periodically and will cause a real mess while installing extensions (Grrr!)
		if ( realpath($tmpdir) == '/tmp' ) {
			// Someone inform the user that what he's doing is insecure and stupid, please. In the
			// meantime, I will fix what is broken.
			$tmpdir = JPATH_SITE.DS.'tmp';
		} // Make sure that folder exists (users do stupid things too often; you'd be surprised)
		elseif (! JFolder :: exists( $tmpdir ) ) {
			// Darn it, user! WTF where you thinking? OK, let's use a directory I know it's there...
			$tmpdir = JPATH_SITE.DS.'tmp';
		}
		
		return $tmpdir;
	}
	
	
	/**
	 * Method for determining what the URL to the temporary directory is
	 * @access		private
	 * @version		2.4.16
	 * @param		string		- $tempdir: the temporary folder
	 * 
	 * @return		string containing url to temporary directory
	 * @since		2.4.0
	 */
	private function _getTmpurl( $tempdir = null )
	{
		if ( $tempdir == null ) return false;
		
		$uri	= Juri :: getInstance( JUri :: root() );
		$path	= str_replace( "\\", "/", str_replace( dirname( $this->_getTmpdir() ), '', $tempdir ) );
		$uri->setPath( $uri->getPath() . $path );
		
		return $uri->toString();
	}
	
	
	/**
	 * Method for updating remote files
	 * @accesss		private
	 * @version		2.4.16
	 * @param		string		- $type: the type of update
	 * @param		string		- $tempdir: the temporary directory the update is in
	 * @param		array		- $update: contains an array of objects to update with
	 * 
	 * @return		boolean
	 * @since		2.4.0
	 */
	private function _updateFile( $type = 'whmcs', $tempdir = null, $update = null )
	{
		$config	= $update['config'];
		$update	= $update['update'];
		$result	= true;
		$msg	= null;
		
		switch ( $type ) {
		case 'whmcs':
			
			$url	=   $this->_getTmpurl( $tempdir );
			$jcurl	= & JwhmcsCurl :: getInstance( true );
			$jcurl->setParse( false );
			
			for ( $i = 1; $i <= 3; $i++ ) {
				
				if ( $i == 1 )
				{
				// First time through, be sure we can read Joomla tmp from WHMCS
					$jcurl->setAction( 'jwhmcs', array( 'task' => 'update', 'responsetype' => 'json', 'step' => $i, 'url' => $url ) );
					$return	= $jcurl->loadResults();
					
					if (! $return ) {
						$return = false;
						$msg		= JText :: _( 'COM_JWHMCS_UPDATES_FILE_WHMCS_UPDATEERROR_1' );
					}
					else {
						$return		= @json_decode( $return, true );
					}
				}
				else if ( $i == 2 )
				{
					// We have verified we can see the files, now lets copy them over
					$copied	= $this->_copyFiles( $tempdir, $url, null );
					
					// Copying failed somehow, so throw error
					if ( $copied === false ) {
						$result = false;
						$msg	= JText :: _( 'COM_JWHMCS_UPDATES_FILE_WHMCS_UPDATEERROR_2' );
						break;
					}
					continue;
				}
				else if ( $i == 3 )
				{
					// We have copied the files, lets try to log into WHMCS and update the addon modules settings
					$return	= $api->update( array( 'step' => $i, 'url' => $url ) );
				}
				
				// See if the api call failed
				if ( $return === false ) {
					$result = false;
					$msg	= JText :: _( 'COM_JWHMCS_UPDATES_FILE_WHMCS_APIERROR' );
					break;
				} 
				// If we haven't upgraded to 2.4.0 yet, we can't do this action
				else if (! isset( $return['supported'] ) ) {
					$result = false;
					$msg	= JText :: _( 'COM_JWHMCS_UPDATES_FILE_WHMCS_NOTSUPPORTED' );
					break;
				}
				// Otherwise see if there was an error in the routine
				else if ( $return['result'] == 'error' ) {
					$result = false;
					$msg	= JText :: sprintf( 'COM_JWHMCS_UPDATES_FILE_WHMCS_UPDATEERROR' . $i, JText :: _( $return['message'] ) );
					break;
				}
			}
			
			break;
		} // End switch;
		
		if ( $result === false ) {
			JError::raiseWarning('SOME_ERROR_CODE', $msg );
		}
		
		return $result;
	}
}