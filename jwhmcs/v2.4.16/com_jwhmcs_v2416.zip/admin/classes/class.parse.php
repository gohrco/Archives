<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: class.parse.php 631 2013-01-17 16:50:09Z steven_gohigher $
 * @since      1.5.3
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once ('class.database.php');
require_once ('class.vars.php');
require_once ('class.curl.php');
require_once ('class.uri.php');

class JwhmcsParse
{ 
	
	/**
	 * @var instance to contain object when created
	 */
	private static $instance = null;
	
    /* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Called upon initialization of object class
	 * As of:		version 2.0
	 * 
	 * Significant Revisions:
	 * 	2.1.0 (Apr 2010)
	 * 		* Modified references to parameters
	 * 		* Dropped _buildParse and integrated code into construct
	\* ------------------------------------------------------------ */
	private function __construct($page = null)
	{
		if ($page === null)
			return false;
		
		$params	= & JwhmcsParams::getInstance();
		$vars	= & JwhmcsVars::getInstance();
		
		// Test to see if debug set and no filename, if so set default filename for testing
		if (($params->get( 'Debug' ) == 1) && (!$vars->get( 'filename' ))) {
			$vars->set( 'filename', 'clientarea');
		}
		
		$this->whmcs_charset = trim($params->get( 'WhmcsCharacterset' ));
		
		// Setting SSL scheme
		// 1a: Check if usessl passed in vars (coming from WHMCS)
		if ( $vars->get( 'usessl' ) == 1) {
			// 2: Check if parameter set to use ssl on site (should be deprecated)
			if ( $params->get( 'RenderSslenable' ) ) {
				$ssl = true;
			}
			else {
				$ssl = false;
			}
		}
		// 1b: Check if current page is using SSL (not coming from WHMCS)
		else {
			// 2: Check if current page is using SSL
			if ( $vars->get( 'HTTPS' ) == 'on') {
				$ssl = true;
			}
			else {
				$ssl = false;
			}
		}
		
		// 3: Build and set scheme
		$this->set( 'scheme',	'http'.( $ssl ? 's' : '' ));
		$params->set( 'urlscheme', $this->get( 'scheme ').'://' );
		
		$url['joomla']	= & JwhmcsUri::getInstance($params->get( 'JoomlaUrl' ), true );
		$url['images']	= & JwhmcsUri::getInstance($params->get( 'RenderImageurl' ), true );
		$url['whmcs']	= & JwhmcsUri::getInstance($params->get( 'ApiUrl' ), true );
		
		$url['joomla']->setScheme( $this->get( 'scheme' ));
		$url['images']->setScheme( $this->get( 'scheme' ));
		$url['whmcs']->setScheme( $this->get( 'scheme' ));
		
		$this->set( 'homeurl',		$params->get( 'JoomlaUrl' ) );
		$this->set( 'rooturl',		$url['joomla']->toString() );
		$this->set( 'imgurl',		$url['images']->toString() );
		$this->set( 'newbase',		$url['whmcs']->toString() );
		
		// This is the url to retrieve the Joomla site
		$url['fetch']	= & JwhmcsUri::getInstance($params->get( 'JoomlaUrl' ), true);
		$url['fetch']->setPath( $url['fetch']->getPath(). '/index.php' );
		
		/**
		 * Bug 35
		 */
		$url['fetch']->setVar( 'view', 'default' );
		/**
		 * Bug 35
		 */
		
		if ($vars->get( 'loggedin' )) {
			$url['fetch']->setVar('loggedin', 1);
			$url['fetch']->setVar('clientid', $vars->get( 'clientid' ));
			
			if ( $vars->get( 'contactid' ) ) 
			{
				$url['fetch']->setVar( 'contactid', $vars->get( 'contactid' ) );
			}
			$Itemid = ( $vars->get( 'filename' ) == 'kayako' ? $params->get( 'KayakomenuLoggedin' ) : $params->get( 'RenderLoggedin' ) );
		}
		else {
			$Itemid	= ( $vars->get( 'filename' ) == 'kayako' ? $params->get( 'KayakomenuLoggedout' ) : $params->get( 'RenderLoggedout' ) );
		}
				
		if ($vars->get( 'usessl' ) || $ssl )
			$url['fetch']->setVar( 'usessl', 1 );
		
		// Implemented new Language check (2.4.7)
		if ( $vars->get( 'language' ) ) {
			$lang	= $this->_getLanguage( $vars->get( 'language' ) );
			$url['fetch']->setVar( 'lang', $lang );
			$url['fetch']->setVar( 'language', $lang );
			$url['fetch']->setVar( 'jwhmcslang', $lang );
		}
		
		$url['fetch']->setVar( 'Itemid', $Itemid );
		$url['fetch']->setVar( 'option', 'com_jwhmcs' );
		
		// Generate security hash
		$hash = $this->hashCreate();
		$url['fetch']->setVar( 'signature', $hash['signature'] );
		$url['fetch']->setVar( 'salt', $hash['salt'] );
		
		$this->set( 'url', $url['fetch']->toString() );
		
		$this->set( 'breakpcs',		'<!-- J!WHMCS -->' );
		$this->set( 'rep_content',	'<!-- J!WHMCS:  COMPONENT -->' );
		
		// Build the various parameter options for the pages in WHMCS
		$default	= $params->get( 'MenuDefault' );
		$menuset	= $params->getPrime('menu');
		
		unset ($menuset['MenuDefault'], $menuset['MenuStyle']);
		
		if ( count( $menuset) > 0 ) {
			foreach ($menuset as $menu => $value) {
				$tmp = substr( $menu, (4-strlen($menu)) );
				$this->set( $tmp, ( $value != '-1' ? $value : $default ) );
			}
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getInstance
	 * Purpose:		Called to create an instance of the class
	 * As of:		version 2.0
	\* ------------------------------------------------------------ */
	public static function getInstance($page = 'default', $force = false)
	{
		static $instances = array();
		
		if ($force && isset($instances[$page]))
			unset ($instances[$page]);
		
		if (!isset ($instances[$page])) {
			$instances[$page] = new JwhmcsParse($page);
		}
		
		return $instances[$page];
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		get
	 * Purpose:		Called to retrieve internal variables
	 * As of:		version 2.0
	\* ------------------------------------------------------------ */
	public function get($name = null, $prime = 'vars')
	{
		if ($name)
		{
			return ( isset( $this->parse[$prime][$name] ) ? $this->parse[$prime][$name] : false );
		}
		else
		{
			return $this->parse;
		}
	}
	
	
	public function hashCreate()
	{
		$params		= & JwhmcsParams :: getInstance();
		$salt		=   mt_rand();
		$secret		=   $params->get( 'Secret' );
		$signature	=   base64_encode( hash_hmac( 'sha256', $salt, $secret, true ) );
		
		return array( 'signature' => $signature, 'salt' => $salt );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		set
	 * Purpose:		Called to set internal variables
	 * As of:		version 2.0
	\* ------------------------------------------------------------ */
	public function set($name, $value, $prime = 'vars')
	{
		$this->parse[$prime][$name] = $value;
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		setData
	 * Purpose:		Called to set the parsing data
	 * As of:		version 2.0
	\* ------------------------------------------------------------ */
	public function setData(&$site)
	{
		// Make the replacements to the URLS, HREFs, etc...
		$needles	= $this->_getNeedles();
		$site		= $this->_findNeedles( $needles, $site );
		
		// Fix the menu style so the correct menu is active
		$site	= $this->_menuStyling($site);
		
		// Replace Title and Breadcrumbs
		$site	= $this->_breadCrumber($site);
		
		// Split the site setting the html variables
		$this->_splitSite($site);
	}
	
	
	/**
	 * Creates an array of needles to find
	 * @access		private
	 * @version		2.4.16
	 * @version		2.4.9		- Changed SCRIPT regex to limit //prepended scripts (lazy scheme methods)
	 * 
	 * @return		array
	 * @since		2.0.0
	 */
	private function _getNeedles() {
		$params		= & JwhmcsParams::getInstance();
		$vars		= & JwhmcsVars::getInstance();
		
		$filename	= $vars->get( 'filename' );
		$unicode	= ( $params->get( 'AdvUnicode' ) ? 'u' : '' );
		
		/* ----------- *\
		 * Find Array:
		 *  [0] = Debug name
		 * 	[1] = regular expression
		 *  [2] = replacement value
		 *  [3] = t:f - true to replace entire content; false to parse url
		 *  [4] = t:f - true to replace entire scheme and host; false to only prepend
		 *  [5] = t:f - true to replace scheme (ssl for css, js and imgs)
		 *   
		 */
		
		// <link> Replacements
		$find[0][0] = '&lt;link&gt;';
		$find[0][1] = '/(?P<front><link.+?href=\"?\'?)\/?(?P<link>[^>\"\']+)(?P<back>\'?\"?.*?\/?>)/' . $unicode;
		$find[0][2] = $this->get( 'imgurl' );
		$find[0][3] = false;
		$find[0][4]	= true; 
		$find[0][5] = true;
		
		// <a href> Replacements
		$find[1][0] = '&lt;a href&gt;';
		$find[1][1] = '/(?P<front><a.+?href=\'?\"?)\/?(?P<link>[^>\"\']+)(?P<back>\"?\'?.*?>)/' . $unicode;
		$find[1][2] = $this->get( 'homeurl' );
		$find[1][3] = false;
		$find[1][4]	= false;
		$find[1][5] = false;
		
		// <script> Replacements
		$find[2][0] = '&lt;script src&gt;';
		$find[2][1] = '/(?P<front><script[^>]+?src=[\"\'])\/?(?P<link>[^\/]+[^>\"\']+)(?P<back>\'?\"?.*?>)/' . $unicode;
		$find[2][2] = $this->get( 'imgurl' );
		$find[2][3] = false;
		$find[2][4]	= true;
		$find[2][5] = true;
		
		// <img> Replacements
		$find[3][0] = '&lt;img src&gt;';
		$find[3][1] = '/(?P<front><img.+?src=\"?\'?)\/?(?P<link>[^>\"\']+)(?P<back>\"?\'?.*?>)/' . $unicode;
		$find[3][2] = $this->get( 'imgurl' );
		$find[3][3] = false;
		$find[3][4]	= true;
		$find[3][5] = true;
		
		// "style" Replacements
		$find[4][0] = 'css url()';
		$find[4][1] = '/(?P<front>style=\"?\'?[^>]+?url\(\"?\'?)\/?(?P<link>[^\)]+\..{3})(?P<back>\"?\'?\);?[^>]*>)/' . $unicode . 'i';
		$find[4][2] = $this->get( 'imgurl' );
		$find[4][3] = false;
		$find[4][4]	= true;
		$find[4][5] = true;
		
		// <style> Replacements
		$find[5][0] = '&lt;style&gt;';
		$find[5][1] = '/(?P<front>{[\w\s]*[^}]*background[-\w]*:[^\)]*url\(\"?\'?)\/?(?P<link>[^\)]+\..{3})(?P<back>\"?\'?\)[^}]*})/' . $unicode . 'i';
		$find[5][2] = $this->get( 'imgurl' );
		$find[5][3] = false;
		$find[5][4]	= true;
		$find[5][5] = true;
		
		// <base> Replacements
		$find[6][0] = '&lt;base&gt;';
		$find[6][1]	= '/(?P<front><base.+?href=\"?\'?)(?P<link>https?:\/\/[^>\'\" ]+)(?P<back>\'?\"?.*?\/?>)/' . $unicode . 'i';
		$find[6][2]	= rtrim($this->get( 'newbase' ), '/').'/';
		$find[6][3] = true;
		$find[6][4]	= true;
		$find[6][5] = false;
		
		// onmouseover/out Replacements
		$find[7][0]	= 'mouseover/out';
		$find[7][1]	= '/(?P<front>onmouse.+?=\"?\'?javascript:this.src=\"?\'?)(?P<link>https?:\/\/[^>\'\" ]+)(?P<back>\'?\"?[^>]*?)/' . $unicode . 'i';
		$find[7][2]	= $this->get( 'imgurl' );
		$find[7][3] = false;
		$find[7][4]	= true;
		$find[7][5] = true;
		
		if ( $params->get( 'MenuStyle' ) == 'yoo' ) {
			// Finds styles that are declared @imports (stupid Yootheme templates)
			$find[8][0] = 'style url()';
			$find[8][1] = '#(?P<front><style>[^>]*@import url\()(?P<link>[^\)]*)(?P<back>\))#' . $unicode . 'i';
			$find[8][2] = $this->get( 'imgurl' );
			$find[8][3] = false;
			$find[8][4]	= true;
			$find[8][5] = true;
			
			$find[9][0] = 'template url()';
			$find[9][1] = '#(?P<front>url\(\')(?P<link>[^\']*)(?P<back>\'\))#' . $unicode . 'i';
			$find[9][2] = $this->get( 'imgurl' );
			$find[9][3] = false;
			$find[9][4]	= true;
			$find[9][5] = true;
		}
		
		// Catches scripts using the Windows.DOM to write an asset to the screen... ? yikes
		$find[10][0] = 'Windows DOM Asset Images';
		$find[10][1] = '/(?P<front>{[\w\s]*[^}]*[^\)]*image\(\"?\'?)\/?(?P<link>[^\)]+\..{3})(?P<back>\"?\'?\)[^}]*})/' . $unicode . 'i';
		$find[10][2] = $this->get( 'imgurl' );
		$find[10][3] = false;
		$find[10][4] = true;
		$find[10][5] = true;
		
		// "in-line style declaration" Replacements
		$find[11][0] = 'inline declaration url()';
		$find[11][1] = '/(?P<front>{\"?\'?[^}]+?url\(\"?\'?)\/?(?P<link>[^\)]+\..{3})(?P<back>\"?\'?\);?[^}]*})/' . $unicode . 'i';
		$find[11][2] = $this->get( 'imgurl' );
		$find[11][3] = false;
		$find[11][4]	= true;
		$find[11][5] = true;
		
		return $find;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_findNeedles
	 * Purpose:		Run an array of needles against the site
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	private function _findNeedles(&$needles, &$site) {
		$params	= & JwhmcsParams::getInstance();
		$vars	= & JwhmcsVars::getInstance();
		$debug	= '';
		$cnt	= 0;
		$item	= false;
		
		foreach ($needles as $needle):
			preg_match_all($needle[1], $site, $matches, PREG_SET_ORDER);
			
			foreach ($matches as $match):
				$cnt++;
				
				// Hang on to original match so we can find it again later
				$item[$cnt]['find']	= $match[0];
				$item[$cnt]['type']	= $needle[0];
				$item[$cnt]['regx'] = $needle[1];
				$item[$cnt]['nedl'] = $needle[2];
				
				// Check to see if we are replacing the entire find
				if ($needle[3] == true) {
					$item[$cnt]['repl']	= $match['front'].$needle[2].$match['back'];
					continue;
				}
				
				// Parse the match and the replacement into pieces
				$furl = & JwhmcsUri::getInstance($match['link'], true);
				$nurl = & JwhmcsUri::getInstance($needle[2], true);
				
				// Debug
				$item[$cnt]['furl'] = @parse_url( $match['link'] );
				$item[$cnt]['rurl'] = $furl;
				
				// Test to see if we got nothing but a fragment
				if ($furl->isFragment()) {
					$item[$cnt]['repl'] = $match[0];
					continue;
				}
				
				// If we found a path, we need to prepend a slash now
				if ($furl->getPath()) {
					$furl->setPath( '/' . $furl->getPath() );
				}
				
				// Check to see if we replace the entire scheme (css, js, imgs)
				//   Note:  The scheme should already be handled when needle built
				if ($needle[4] == true) {
					$turl = & JwhmcsUri::getInstance($this->get( 'homeurl' ));
					
					if ($furl->getHost()) {
					//if (isset($furl['host'])) {
					//	if ($turl['host'] == $furl['host']) {
						if ( $turl->getHost() == $furl->getHost() ) {
							
							//$furl['host'] = $nurl['host'];
							$furl->setPath( $this->_checkDuplicatePaths( $furl->getPath(), $nurl->getPath() ) );
							$furl->setHost( $nurl->getHost() );
							//$furl->setHost( $nurl->toString( array( 'host', 'path' ) ) );
						}
					}
					else {
						//$furl['host'] = $nurl['host'];
						$furl->setPath( $this->_checkDuplicatePaths( $furl->getPath(), $nurl->getPath() ) );
						
						//$furl->setHost( $nurl->toString( array( 'host', 'path' ) ) );
						$furl->setHost( $nurl->getHost() );
						//$furl->setHost( $nurl->getHost() );
					}
					//$furl['scheme']	= $nurl['scheme'];
					$furl->setScheme( $nurl->getScheme() );
					$filler	= $this->_buildUrl($furl); 
					$item[$cnt]['repl'] = $match['front'].$filler.$match['back'];
					continue;
				}
				
				// Check to see if the found item has a scheme (and host).  If so then
				//   assume we leave host / scheme alone unless we update the scheme
				//if (isset($furl['scheme'])) {
				if ($furl->getScheme()) {
					if ($needle[5]) {
						//$furl['scheme'] = $nurl['scheme'];
						$furl->setScheme( $nurl->getScheme() );
					}
					
					// Test the Joomla URL against the found url, and if the same,
					//	 replace the found URL with the new url
					/*$turl = parse_url($this->get( 'homeurl' ));
					if ($turl['host'] == $furl['host']) {
						$furl['host'] = $nurl['host'];
						$furl['path'] = $this->_checkDuplicatePaths($furl['path'], $turl['path']);
					}
					unset ($turl);
					*/
					$filler = $this->_buildUrl($furl);
					$item[$cnt]['repl'] = $match['front'].$filler.$match['back'];
					continue;
				}
				// We are going to force absolute paths here since there is not
				//	 scheme set, and therefore no host - necessary for subdomains
				else {
					//$furl['scheme'] = $nurl['scheme'];
					//$furl['host'] = $nurl['host'];
					$furl->setScheme( $nurl->getScheme() );
					$furl->setHost( $nurl->getHost() );
					
				}
				
				// Check to see if there are duplicate paths
				//if (isset($nurl['path']) && isset($furl['path'])) {
				if (($nurl->getPath()) && ($furl->getPath())) {
					//$furl['path']  = $this->_checkDuplicatePaths($furl['path'], $nurl['path']);
					$furl->setPath( $this->_checkDuplicatePaths( $furl->getPath(), $nurl->getPath() ) );
					
				}
				
				$filler = $this->_buildUrl($furl);
				$item[$cnt]['repl'] = $match['front'].$filler.$match['back'];
				
			endforeach; // Match foreach
		endforeach; // Needle foreach
		
		$type	= false;
		$predub	= false;
		
		// Perform actual replacements here
		if ($item) {
			$predub = null;
			foreach ($item as $run) {
				if ($run['type'] != $type) {
					$debug .= '<div class="debugHeader">Needle Type:  '.$run['type'].'<a name="'.$run['type'].'" /></div>';
					$debug .= '<div class="debugH2 debugFound">Regular Expression is:  '.htmlentities($run['regx']).'</div>';
					$debug .= '<div class="debugH2 debugReplace">Needle is:  '.htmlentities($run['nedl']).'</div>';
					$type = $run['type'];
					$predub .= "<a href='#{$type}'>{$type}</a><br />";
				}
				$debug	.= '<div class="debugCommon debugBorder"><div class="debugLeft debugFound">This is what was found</div><div class="debugRight">'.htmlentities($run['find']).'</div></div>';
				$debug	.= '<div class="debugCommon"><div class="debugLeft debugReplace">This is what is to replace it</div><div class="debugRight" >'.htmlentities($run['repl']).'</div></div>';
				$debug	.= '<div class="debugCommon"><div class="debugLeft debugFound">Found URL Parsed:</div><div class="debugRight"><pre>'.( isset( $run['furl'] ) ? print_r($run['furl'],1) : false ).'</pre></div></div>';
				$debug	.= '<div class="debugCommon"><div class="debugLeft debugReplace">Replacement URL Parsed:</div><div class="debugRight"><pre>'.( isset( $run['rurl'] ) ? print_r($run['rurl'],1) : false ).'</pre></div></div>';
				$site = str_replace($run['find'], $run['repl'], $site);
			}
		}
		$debug .= "<style>
					.debugFound { background-color: #FFFFCC; }
					.debugReplace { background-color: #CCFFCC }
					.debugH2 { font-family: Arial; font-size: medium; clear: both; padding: 0; font-weight: bold; }
					.debugHeader { border-top: 2px solid #000; font-family: Arial; font-size: x-large; clear: both; padding: 0; font-weight: bold; background-color: #FFCCCC; }
					.debugCommon { border-top: 1px dotted #888; font-family: Arial; font-size: small; clear: both; }
					.debugBorder { border-top: 1px solid #000; padding-top: 5px; margin-top: 5px; }
					.debugLeft { width: 250px; text-align: right; float: left; font-style: italic; }
					.debugRight { float: left; padding-left: 10px; font-weight: bold; }
				</style>";
		if ($params->get( 'Debug' ) == 1) echo $predub . $debug;
		return $site;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_buildUrl
	 * Purpose:		Build a url and return it to the calling method
	 * As of:		version 2.0.0
	\* ------------------------------------------------------------ */
	private function _buildUrl($url)
	{
		$scheme = $url->getScheme();
		
		if (! is_null( $scheme ) ) {
			if ( ($scheme == 'javascript') && ( ( $url->getPath() == "/;" )  || ( $url->getPath() == ";" ) ) ) return 'javascript:;';
			if ( ( $scheme == 'javascript' ) && (! is_null( $url->getPath() ) ) ) return 'javascript:' . ltrim($url->getPath(),'/');
		}
		
		return $url->toString();
		/*
		// Test for the path
		if (isset($url['path'])) {
			if ( count($url['path'] > 1 )) {
				$url['path'] = '/'.ltrim($url['path'], '/');
			}
		}
		// Test to see if the scheme is set, if so the host must also be
		if (isset($url['scheme'])) {
			if ($url['scheme'] == 'javascript') {
				$url['scheme'] .= ':';
			}
			else {
				$url['scheme']	.= '://';
			}
		}
		else {
			$url['scheme']	= '';
			$url['host']	= '';
		}
		return $url['scheme'].$url['host'].$url['path'].(isset($url['query'])?'?'.$url['query']:'').(isset($url['fragment'])?'#'.$url['fragment']:'');
		*/
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_parseMenuStyles
	 * Purpose:		This function parses the various menu styles that
	 * 					are found on many different templates.
	 * 				
	 * As of:		version 1.5.3b6 (November 2009)
	 * 
	 * Significant Revisions:
	 * 	1) 2.0 - Nov 2009
	 *  	-> Database, variable, curl and parameters moved to class
	\* ------------------------------------------------------------ */
	private function _menuStyling($site)
	{
		$db		= & JwhmcsDBO::getInstance();
		$params = & JwhmcsParams::getInstance();
		$vars	= & JwhmcsVars::getInstance();
		
		$filename	= $vars->get( 'filename' );
		$page		= $this->getPage( $filename );
		$unicode	= ( $params->get( 'AdvUnicode' ) ? 'u' : '' );
		
		switch ($params->get( 'MenuStyle' ))
		{
			// Gavick Menu Style
			case 'gavick':
				$find[0][0] = '&lt;menu - a&gt;';
				$find[0][1]	= '#(?P<front><a.+?class="[^"]*?)(?P<link>)(?P<back>"[^>]*?id="menu'.$page.'")#i';//.+?class=\"?\'?[^\"\']*)(?P<link>item'.$page.'[^\'\"]*)(?P<back>[^>]*>)#i';
				$find[0][2]	= ' active';
				$find[0][3]	= true;
				$find[0][4] = false;
				$find[0][5] = false;
				
				$site = $this->_findNeedles($find, $site);
				
				$find[0][0] = '&lt;menu - li&gt;';
				$find[0][1]	= '#(?P<front><li.+?class="[^"]*?)(?P<link>)(?P<back>".*?id="menu'.$page.'")#i';//.+?class=\"?\'?[^\"\']*)(?P<link>item'.$page.'[^\'\"]*)(?P<back>[^>]*>)#i';
				$find[0][2]	= ' active';
				$find[0][3]	= true;
				$find[0][4] = false;
				$find[0][5] = false;
				
				$site = $this->_findNeedles($find, $site);
				break;
			// Joomlr Menu Style
			case 'joomlr':
				$parent		= $this->_getParentMenu($page);
				
				$find[0][0] = '&lt;menu - Joomlr&gt;';
				$find[0][1]	= '/(?P<front><li[^>]+?id=\"?\'?item-'.$page.'[^>]*)(?P<link>)(?P<back>[^>]*>)/i';
				$find[0][2]	= ' class="current active" ';
				$find[0][3]	= true;
				$find[0][4] = false;
				$find[0][5] = false;
				$site = $this->_findNeedles($find, $site);
			// S5 Menu Style
			case 's5':
				$pmenu = $this->_getParentMenu($page);
				$find[0][0] = '&lt;menu&gt;';
				$find[0][1] = sprintf('/(?P<front><li?)(?P<link>)(?P<back>>.*(?:%s|%s).*%s.*<\/li>)/' . $unicode . 'i', preg_quote(trim($pmenu['link']), '/'), preg_quote(trim($pmenu['alias']), '/'), preg_quote(trim($pmenu['name']), '/'));
				$find[0][2] = ' class="active"';
				$find[0][3] = true;
				$find[0][4] = false;
				$find[0][5] = false;
				$site = $this->_findNeedles($find, $site);
				break;
			// Yoo Theme style template
			case 'yoo':
				$cnt	= 1;
				$sid	= $page;
				for ($i=0; $i<$cnt; $i++) {
					$query	= 'SELECT parent, ordering, name, sublevel FROM `#__menu` WHERE `#__menu`.`id` = '.$sid;
					$db->setQuery($query);
					$result	= $db->loadAssocList();
					
					if ( count( $result ) > 0 ) {
						foreach($result as $row) {
							$sublvl = $row[ 'sublevel' ];
							$menus[$sublvl] = array('parent' => ($sublvl + 1), 'ordering' => $row[ 'ordering' ], 'name' => $row[ 'name' ]);
						}
						if ($sublvl != 0) {
							$cnt++;
							$sid = $menus[$sublvl]['parent'];
							unset ($menus[$sublvl]);
						}
					}
				}
				
				if ( count( $menus ) == 0 )
					break;
				
				foreach ($menus as $menu) {
					$find[0] = array(	'&lt;menu&gt;',
										sprintf('/(?P<front><li[^>]+class=\"?\'?[^\"\'>]*)(?P<link>level%d item%d)(?P<back>[^\"\']*\'?\"?[^>]*>)/i', $menu['parent'], $menu['ordering']),
										sprintf('level%d item%d active current', $menu['parent'], $menu['ordering']),
										true, false, false);
					$find[1] = array(	'&lt;menu&gt;',
										sprintf('/(?P<front><a[^>]+class=\"?\'?[^\"\'>]*)(?P<link>level%d item%d)(?P<back>[^\"\']*\'?\"?[^>]*>)/i', $menu['parent'], $menu['ordering']),
										sprintf('level%d item%d active current', $menu['parent'], $menu['ordering']),
										true, false, false);
					
					// Call up the regexer to make replacements
					$site = $this->_findNeedles($find, $site);
				}
				break;
			// Artisteer
			case 'artisteer':
				$find[0][0] = '&lt;menu&gt;';
				//$find[0][1]	= '/(?P<front><li.+?class=\"?\'?[^\"\']*)(?P<link>item'.$page.'[^\"\']*)(?P<back>\'?\"?[^>]*>)/i';
				$find[0][1]	= '/(?P<front><li.+?class=\"?\'?[^\"\']*)(?P<link>item'.$page.'[^\'\"]*)(?P<back>[^>]*>)/i';
				$find[0][2]	= 'item'.$page.' active';
				$find[0][3]	= true;
				$find[0][4] = false;
				$find[0][5] = false;
				
				$find[1][0] = '&lt;menu 2&gt;';
				$find[1][1]	= '/(?P<front><li.+?class=\"?\'?[^\"\']*)(?P<link>item-'.$page.'[^\'\"]*)(?P<back>[^>]*>)/i';
				$find[1][2]	= 'item-'.$page.' active';
				$find[1][3]	= true;
				$find[1][4] = false;
				$find[1][5] = false;
				$site = $this->_findNeedles($find, $site);
				
				//$find[0][1]	= '/(?P<front><li.+?class=\"?\'?[^\"\']*)(?P<link>item'.$page.'[^\"\']*)(?P<back>\'?\"?[^>]*>)/i';
				$find[0][1]	= '`(?P<front><li[^>]*?item'.$page.'[^>]*?>[^/]*?<a)(?P<link> )(?P<back>[^>]*>)`i';
				$find[0][2]	= ' class="active" ';
				$find[0][3]	= true;
				$find[0][4] = false;
				$find[0][5] = false;
				$find[1][1]	= '`(?P<front><li[^>]*?item-'.$page.'[^>]*?>[^/]*?<a)(?P<link> )(?P<back>[^>]*>)`i';
				$find[1][2]	= ' class="active" ';
				$find[1][3]	= true;
				$find[1][4] = false;
				$find[1][5] = false;
				$site = $this->_findNeedles($find, $site);
				break;
			case 'joomlart':
				$find[0][0] = '&lt;menu&gt;';
				$find[0][1] = '/(?P<front><a.+?class=\"?\'?[^\"\']*)(?P<link>)(?P<back>[^>]*id="menu'.$page.'"[^>]*>)/i';
				$find[0][2]	= ' active';
				$find[0][3]	= true;
				$find[0][4] = false;
				$find[0][5] = false;
				$site = $this->_findNeedles($find, $site);
				break;
				
			// Default Joomla menu styling
			default:
				$parent		= $this->_getParentMenu($page);
				
				// Joomla! 2.5 Style?
				$find[0][0] = '&lt;menu - standard&gt;';
				//$find[0][1]	= '/(?P<front><li.+?class=\"?\'?[^\"\']*)(?P<link>item'.$page.'[^\"\']*)(?P<back>\'?\"?[^>]*>)/i';
				$find[0][1]	= '/(?P<front><li.+?class=\"?\'?[^\"\']*)(?P<link>item-'.$page.')(?P<back>[^>]*>)/i';
				$find[0][2]	= 'item-'.$page.' active';
				$find[0][3]	= true;
				$find[0][4] = false;
				$find[0][5] = false;
				
				// Joomla! 1.5 Style
				$find[1][0] = '&lt;menu - standard&gt;';
				//$find[0][1]	= '/(?P<front><li.+?class=\"?\'?[^\"\']*)(?P<link>item'.$page.'[^\"\']*)(?P<back>\'?\"?[^>]*>)/i';
				$find[1][1]	= '/(?P<front><li.+?class=\"?\'?[^\"\']*)(?P<link>item'.$page.')(?P<back>[^>]*>)/i';
				$find[1][2]	= 'item'.$page.' active';
				$find[1][3]	= true;
				$find[1][4] = false;
				$find[1][5] = false;
				
				// Legacy List / rhuk Pill Menu
				$parent		= $this->_getParentMenu($page);
				$find[2][0] = '&lt;menu - rhuk pill&gt;';
				$find[2][1] = sprintf( '/(?P<front><ul.*?<a href=\"?\'?%1$s\"?\'?)(?P<link>)(?P<back>[^>]*>%2$s<\/a>)/i', preg_quote( $parent['link'], '/' ), preg_quote( $parent['name'], '/' ) );
				$find[2][2] = ' id="active_menu-nav" ';
				$find[2][3] = true;
				$find[2][4] = false;
				$find[2][5] = false;
				
				// Legacy Menus
				$find[3][0] = '&lt;menu - legacy vertical&gt;';
				$find[3][1] = sprintf( '/(?P<front><div class=\"?\'?[^\"?\'?]*module_menu[^\"?\'?]*\"?\'?>[.\s\S]*?<a href=\"?\'?%1$s\"?\'?)(?P<link>)(?P<back>[^>]*>%2$s<\/a>)/i', preg_quote( $parent['link'], '/' ), preg_quote( $parent['name'], '/' ) );
				$find[3][2] = ' id="active_menu" ';
				$find[3][3] = true;
				$find[3][4] = false;
				$find[3][5] = false;
				
				$site = $this->_findNeedles($find, $site);
				break;
		}
//		$this->set( 'site', $site );
		return $site;
	}
	
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getParentMenu
	 * Purpose:		This function pulls the parent menu of any menu sent.
	 * As of:		version 2.0.2 (February 2010)
	\* ------------------------------------------------------------ */
	private function _getParentMenu($id = null)
	{
		global $db;
		
		if (is_null($id)) return false;
		
		$query	= 'SELECT parent, link, name, alias FROM `#__menu` WHERE `#__menu`.`id` = '.$id;
		$db->setQuery($query);
		if ($result = $db->loadAssoc()) {
			if ($result['parent'] != '0') {
				return $this->_getParentMenu($result['parent']);
			} else {
				return $result;
			}
		} else return false;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_breadCrumber
	 * Purpose:		This function replaces the breadcrumbs found in Joomla
	 * 					with the breadcrumbs sent to it by the hook file.
	 * As of:		version 1.5.3b6 (November 2009)
	 * 
	 * Significant Revisions:
	 * 	1) 2.0.0 - Nov 2009
	 *  	* Database, variable, curl and parameters moved to class
	\* ------------------------------------------------------------ */
	private function _breadCrumber($site)
	{
		$vars	= & JwhmcsVars::getInstance();
		
		$needle[0] = '/(?P<front><title>)(?P<link>[^<\/]+?)(?P<back><\/title>)/';
		$needle[1] = $vars->get( 'pagetitle' );
		
		preg_match_all($needle[0], $site, $matches, PREG_SET_ORDER);
		$find	= $matches[0][0];
		$repl	= $matches[0]['front'].$needle[1].$matches[0]['back'];
		$title	= $matches[0]['link'];
		$site = str_replace($find, $repl, $site);
		unset ($needle, $find, $repl);
		
		$needle[0] = sprintf('/(?P<front><span.+?class=\"[^\"]*breadcrumbs[^\"]*\"[^>]*>[\w\s]*.*)(?P<link>%s)(?P<back><\/span>)/i', $title);
		$needle[1] = $vars->get( 'title' );
		
		preg_match_all($needle[0], $site, $matches, PREG_SET_ORDER);
		
		if ( empty( $matches ) ) return $site; // If nothing found return
		
		$find	= $matches[0][0];
		$repl	= $matches[0]['front'].$needle[1].$matches[0]['back'];
		$site = str_replace($find, $repl, $site);
		
		return $site;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_splitSite
	 * Purpose:		This method splits the template along the needle
	 * 				points and returns
	 * As of:		version 1.5.0 (August 2009)
	 * 
	 * Significant Revisions:
	 * 	2.0.2 (Feb 2010)
	 * 		+ Added character set check / replace
	 * 		+ Added ID tag to identify WHMCS content for styling
	 * 		* Corrected "offline" not pulling htmlftr properly
	\* ------------------------------------------------------------ */
	private function _splitSite ($haystack)
	{
		$vars	= & JwhmcsVars::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		$needle		= $this->get( 'breakpcs' );
		$replace	= $this->get( 'rep_content' );
		
		$pcs		= explode($needle, $haystack);
		
		for($i=0; $i<count($pcs); $i++) {
			$exists = preg_match($replace, $pcs[$i]);
			if ($exists) $hit = $i;
		}
		
		$htmlhdr = null;
		$htmlftr = null;
		$hdr = array_slice($pcs, 0, $hit);
		for ($i=0; $i<count($hdr); $i++) $htmlhdr.= $hdr[$i];
		$ftr = array_slice($pcs, $hit+1);
		for ($i=0; $i<count($ftr); $i++) $htmlftr.= $ftr[$i];
		
		// Add ID tag to style WHMCS content specifically
		$htmlhdr .= '<div id="jwhmcs-wrapper">';
		$htmlftr  = '</div>'.$htmlftr;
		
		// v 1.5.3 - Add hidden div for offline site
		if ($vars->get( 'offline' ))
		{
			$htmlhdr .= '<div style="display: none; ">';
			$htmlftr  = '</div>'.$htmlftr;
		}
		
		// Is WHMCS in utf-8?  If not we must convert the Joomla content
		if (($this->whmcs_charset != 'utf-8' && trim($this->whmcs_charset) != '' ) && ($params->get( 'AdvConvertcharset' ) == 1 )) {
			$find[0][0] = '&lt;charset&gt;';
			$find[0][1] = '/(?P<front><meta.*charset=\"?)(?P<link>utf-8)(?P<back>.*\/>)/ui';
			$find[0][2] = $this->whmcs_charset;
			$find[0][3] = true;
			$find[0][4] = false;
			$find[0][5] = false;
			
			$htmlhdr = $this->_findNeedles($find, $htmlhdr);
			$htmlhdr = iconv("UTF-8", sprintf("%s//IGNORE//TRANSLIT", $this->whmcs_charset), $htmlhdr);
			$htmlftr = iconv("UTF-8", sprintf("%s//IGNORE//TRANSLIT", $this->whmcs_charset), $htmlftr);
		}
		
		$this->set( 'htmlhdr', base64_encode($htmlhdr) );
		$this->set( 'htmlftr', base64_encode($htmlftr) );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkDuplicatePaths (private)
	 * Purpose:		This method checks two paths for being identical
	 * As of:		version 2.0.0 (January 2010)
	\* ------------------------------------------------------------ */
	private function _checkDuplicatePaths($orig, $new)
	{
		// The original path is coming out of the template
		// The new path is held in the needle
		
		$npath = explode('/', trim($new, '/'));
		$upath = explode('/', trim($orig, '/'));
		
		$start = false;
		// Take the first path item from original and check for existance in new path
		if (in_array($upath[0], $npath) ) {
			$start = array_search($upath[0], $npath);
		}
		
		// We know that we found the first item in the new path, now compare the rest of the path to see if it matches
		if ($start !== false) {
			$chop = true;
			for ($i=0; $i<count($npath); $i++) {
				if ($npath[$start+$i] != $upath[$i]) {
					$chop = false;
					break;
				}
			}
			if ($chop) {
				array_splice($npath, $start);
			}
		}
		
		// Reassemble the needle now and return
		return '/' . implode('/', $npath).'/'.ltrim($orig, '/');
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	getPage
	 * Purpose:		This method gets the item id from parameters
	 * As of:		version 2.1.0 (January 2010)
	\* ------------------------------------------------------------ */
	function getPage ($filename = null )
	{
		$params = & JwhmcsParams::getInstance();
		
		// Get default first
		$fetch = "MenuDefault";
		$default	= $params->get( $fetch, 'menu' );
		
		if (is_null($filename)) return $default;
		
		$fetch = "Menu".ucfirst($filename);
		$specific	= $params->get( $fetch, 'menu' );
		
		return ($specific ? $specific : $default );
	}
	
	
	/**
	 * Method to retrieve the language from Joomla properly
	 * @access		private
	 * @version		2.4.16
	 * @version		2.4.12		- Nov 2012: default language not being retrieved if unmatched WHMCS language selected
	 * @param		string		- $lang: contains the lowercase language from WHMCS (ie english, turkish, dutch)
	 * 
	 * @return		string containing matched short code (ie en-GB, tr-TR, nl-NL) as set in the Joomla languages datatable
	 * @since		2.4.7
	 */
	private function _getLanguage( $lang = null )
	{
		if ( $lang == null ) return 'en-GB';
		
		$db			=   ( class_exists('JFactory') ? JFactory :: getDbo() : JwhmcsDBO :: getInstance() );
		$query		=   "SELECT `key`, `value` FROM #__jwhmcs_config WHERE type = 10 AND `key` LIKE 'LangJoom%'";
		$db->setQuery( $query );
		
		$results	=   $db->loadObjectList();
		
		foreach ( $results as $result ) {
			if ( $result->value == $lang ) {
				
				$value = str_replace( 'LangJoom', '', $result->key );
				
				// Try J2.5+ first
				$query = "SELECT `title` as `name`, `lang_code` as `code`, `sef` as `shortcode` FROM #__languages WHERE `sef` = '{$value}' AND `published` = 1";
				$db->setQuery( $query );
				$match	= $db->loadObject();
				
				if ( $match != null ) return $match->code;
				
				// Try J1.5 then
				$query = "SELECT `name`, `code`, `shortcode` FROM #__languages WHERE `shortcode` = '{$value}' AND `published` = 1";
				$match	= $db->loadObject();
				
				if ( $match != null ) return $match->code;
			}
		}
		
		// =================================================
		// We are still here so let's use the default value
		// =================================================
		$query		=   "SELECT `key`, `value` FROM #__jwhmcs_config WHERE type = 10 AND `key` = 'LangDefault'";
		$db->setQuery( $query );
		
		$results	=   $db->loadObject();
		
		return $results->value;
	}
}