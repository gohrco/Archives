<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.4.16 ( $Id: default.php 450 2012-03-29 14:28:04Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      2.1.0
 * 
 * @desc       Change Username View - default layout:  The default layout for the changeusername view
 *  
 */

defined('_JEXEC') or die('Restricted access');
JHTML::_( 'behavior.formvalidation' );
JHTML::_( 'behavior.mootools' );

// Available variables from $this->data[]:
//			joomlaid, type, whmcsid, whmcsapi, action, result, client, userid, id, firstname, lastname, companyname, email, address1, address2, city, state, postcode, country, 
//			countryname, phonenumber, notes, password, currency, cctype, cclastfour, securityqid, securityqans, groupid, status, credit, taxexempt, latefeeoveride, 
//			overideduenotices, language, lastlogin, customfields1, customfields2, customfields3, billingcid, currency_code, stats, numpaidinvoices, paidinvoicesamount, 
//			numdueinvoices, dueinvoicesbalance, numcancelledinvoices, cancelledinvoicesamount, numrefundedinvoices, refundedinvoicesamount, numcollectionsinvoices, 
//			collectionsinvoicesamount, income, creditbalance, productsnumactive, productsnumtotal, productsnumactivehosting, productsnumhosting, productsnumactivereseller, productsnumreseller, 
//			productsnumactiveservers, productsnumservers, productsnumactiveother, productsnumother, numactivedomains, numdomains, numacceptedquotes, numquotes, numactivetickets,
//			numtickets, numaffiliatesignups, 

$data = $this->data;
?>

<div class="componentheading">
	<?php echo JText::sprintf( "COM_JWHMCS_CHANGEUSERNAME_HEADING", $data['firstname'], $data['lastname'] ); ?>
</div>

<form action="<?php echo JRoute::_( "index.php?option=com_jwhmcs&controller=changeusername&task=submit" ); ?>" method="post" name="registerForm" id="registerForm">
<table class="contentpaneopen">
	<tr>
		<td>
			<table cellpadding="0" cellspacing="0" border="0" width="100%" class="contentpane">
				<tr>
					<td valign="top">
						<?php echo JText::_( "COM_JWHMCS_CHANGEUSERNAME_INTRO" ); ?>
					</td>
				</tr>
			</table>
			<table cellpadding="0" cellspacing="0" border="0" width="100%" class="contentpane">
				<tr>
					<td colspan="2" height="54px" valign="middle">
						<div class="servermsg checking" id="servermsg"><?php echo JText::_( "COM_JWHMCS_CHANGEUSERNAME_DESC_USERNAME" ); ?></div>
					</td>
				</tr>
				<tr>
					<td width="30%" height="40">
						<label id="usernamelbl" for="username">
							<?php echo JText::_( "COM_JWHMCS_CHANGEUSERNAME_LABEL_USERNAME" ); ?>
						</label>
					</td>
					<td>
						<input type="text" name="username" id="username" size="40" value="<?php echo $data['firstname'].'.'.$data['lastname']; ?>" class="inputbox required" maxlength="50" onchange="resetValid(); jwhmcs_submitbutton('validate')" onkeypress="return onKeypress(event); " /> 
					</td>
				</tr>
				<tr>
					<td width="30%">&nbsp;</td>
					<td>
						<input type="button" class="button" name="validate" id="validate" onClick="jwhmcs_submitbutton('validate')" value="Validate Username" onmouseover="this.setStyle('background-color', '#eeffee') " onmouseout="this.setStyle('background-color', '#eeeeee') " />
						<input type="button" class="button" name="submitit" id="frmsubmit" onClick="jwhmcs_submitbutton('submit')" value="Continue" onmouseover="this.setStyle('background-color', '#eeffee') " onmouseout="this.setStyle('background-color', '#eeeeee') " disabled="true" />
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<input type="hidden" name="whmcsid" value="<?php echo $data['whmcsid']; ?>" />
<input type="hidden" name="joomlaid" id="joomlaid" value="<?php echo $data['joomlaid']; ?>" />
<input type="hidden" name="password" value="<?php echo $data['password']; ?>" />
<input type="hidden" name="validusername" id="validusername" value="0" />
<input type="hidden" name="thisurl" id="thisurl" value="<?php echo $this->uriString; ?>" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>