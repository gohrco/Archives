<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator v2.4 - Joomla! Package
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    2.4.16 ( $Id: default.php 574 2012-10-03 13:30:28Z steven_gohigher $ )
 * @author     Go Higher Information Services, LLC
 * @since      2.1.0
 * 
 * @desc       This file contains the default controller class allowing the system to intereact with the data based upon actions
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * Default controller is used to handle tasks to perform for the user by the system
 * @version 2.4.16
 * 
 * @since	1.5.0
 * @author Steven
 */
class JwhmcsControllerDefault extends JwhmcsController
{
	/**
	 * Constructor Task
	 * @access		public
	 * @version		2.4.16
	 * 
	 * @since		1.5.0
	 */
	public function __construct()
	{
		// If the view hasn't been set, set it to default
		if (is_null(JwhmcsHelper :: get( 'view'))) JwhmcsHelper :: set('view', 'default' );
		
		parent::__construct();
	}
	
	
	/**
	 * Task to handle cron tasks being setup to synchronize users etc
	 * @access		public
	 * @TODO		Verify routing is working for the cron task
	 * @TODO		Document changes to cron mechanism
	 * @version		2.4.16
	 * 
	 * @since		1.5.3
	 */
	function cron()
	{
		// 0:  Initialize variables
		$app	= & JFactory::getApplication();
		$params	= & JwhmcsParams::getInstance();
		$this->addModelPath( JPATH_COMPONENT_ADMINISTRATOR.DS.'models' );
		
		$db		= & JFactory::getDBO();
		$uri	= & JURI::getInstance();
		$model	= & $this->getModel( 'sync' );
		
		// 1:  Check for secret value from querystring
		if (!($secret = JwhmcsHelper :: get( 'secret' )))
			return false;
		
		// 2:  Compare against parameter secret value (false == fail)
		if ($secret != $params->get( 'Secret'))
			return false;
		
		// 3:  Pull action from querystring to run
		if (!($action = JwhmcsHelper :: get( 'action' )))
			return false;
		
		// 4:  Run action
		if (! method_exists($model, $action))
			exit('No method');
		
		if (! ($cid = JwhmcsHelper :: get( 'cid', array(0), 'post', 'array' )))
			$cid = array();
		
		$model->$action($cid);
	}
	
	
	/**
	 * Task to handle a login coming from WHMCS side of things
	 * @access		public
	 * @version		2.4.16
	 * 
	 * @since		1.5.3
	 */
	function whmcs_login()
	{
		$app		= & JFactory::getApplication();
		$db			= & JFactory::getDBO();
		$params		= & JwhmcsParams::getInstance();
		
		// 1: Retrieve variables based on token
		$vars	= JwhmcsHelper::getSession( JwhmcsHelper :: get( 'token' ));
		
		foreach ($vars as $k => $v) {
			$var[$k] = $v;
			if (in_array($k, array('username', 'passwd', 'password'))) continue;
			JwhmcsHelper :: set( $k, $v );
		}
		
		$fromWhmcs	=   ( JwhmcsHelper :: get('whmcs')=="1" ? true : ( $vars['whmcs'] == '1' ? true : false ) );
		
		// Test to see if we are using User Integration, if not bypass login and return
		if ($params->get( 'UserEnable' ) ) {
			// 2: Set the return redirect (jwhmcs.php)
			$remember			= ( isset( $vars['remember'] ) && $vars['remember'] == 'yes' ? true : false );
			$options			= array('remember' => $remember, 'return' => $var['return'], 'silent' => true, 'whmcs' => $fromWhmcs);
			$credentials		= array('username' => $var['username'], 'password' => $var['passwd']);
			
			//preform the login action
			$success = $app->login($credentials, $options);
			
			if ( $success ) {
				$controller = & JwhmcsController :: getInstance( 'Jwhmcs' );
				$controller->redirect();
				return;
			}
		}
		
		// We are declaring this global in the AUTH plugin - but if not active we must use a default error message
		global $jwhmcs_error;
		$error	= ( isset( $jwhmcs_error->error_message ) ? $jwhmcs_error->error_message : 'AUTH01P030' );
		
		// If we are here then login failed, so determine where to return to
		if ($origin = JwhmcsHelper :: get( 'origin' ) ) {
			$org	= & JURI::getInstance(base64_decode($origin));
			$org->setVar('incorrect', 'true');
			$org->setVar( 'msg', $error );
			$return = $org->toString();
		}
		// No return variable specified so go to Joomla home
		elseif ( ! $return = JwhmcsHelper :: get( 'return' ) ) {
			$uri	= & JURI::getInstance();
			$return	=   JRoute::_( $uri->base() );
		}
		// Return variable specified and assumed to be base64 encoded
		else {
			$return = trim( base64_decode( $return ), '?' );
			
			$ret = & JURI::getInstance($return);
			if ( $fromWhmcs ) {
				$req		= explode( "/", $ret->getPath() );
				$use		= (int) ( count($req) - 1 );
				$req[$use]	= "clientarea.php";
				
				$ret->setPath( implode( "/", $req) );
				$ret->setVar('incorrect', 'true');
				$ret->setVar( 'msg', $error );
			}
			$return = $ret->toString();
		}
		
		// If we are returning to WHMCS, empty the message queue so we don't get some ugly messages upon returning to Joomla
		if ( $fromWhmcs ) {
			$session = JFactory::getSession();
			$session->set('application.queue', null );
		}
		
		$app->redirect( $return );
	}
	
	
	/**
	 * Task to handle logging out from WHMCS side of things (req for J! 2.5+)
	 * @access		public
	 * @version		2.4.16
	 * 
	 * @since		2.3.4
	 */
	public function whmcs_logout()
	{
		$app		= & JFactory::getApplication();
		$db			= & JFactory::getDBO();
		$params		= & JwhmcsParams::getInstance();
		
		// 1: Retrieve variables based on token
		$vars	= JwhmcsHelper::getSession( JwhmcsHelper :: get( 'token' ));
		
		if ( $vars["task"] != "ulogout" ) {
			jexit(JText::_('JInvalid_Token'));
		}
		
		$app->logout();
	}
}