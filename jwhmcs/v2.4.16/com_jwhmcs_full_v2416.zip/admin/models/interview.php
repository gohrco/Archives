<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: interview.php 636 2013-03-13 02:13:48Z steven_gohigher $
 * @since      2.0.2
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );
jimport( 'joomla.installer.installer' );
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');
jimport('joomla.filesystem.path');
jimport('joomla.client.ftp');

include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.filehandler.php');

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelInterview
 * Purpose:		Provide object for data for interview process
 * As of:		version 2.0.2 (March 2010)
\* ------------------------------------------------------------ */
class JwhmcsModelInterview extends JwhmcsModel
{
	var $buffer = null;
	
	/* ------------------------------------------------------------ *\
	 * Function:	__construct
	 * Purpose:		Builds class object upon calling
	 * As of:		version 2.0.2 (March 2010)
	 * 
	 * Significant Revisions:
	 *  2.1.0 (Apr 2010)
	 *  	* Modified parameters to reflect database change
	\* ------------------------------------------------------------ */
	function __construct() {
		parent::__construct();
		
		$params = & JwhmcsParams::getInstance();
		$this->comid = $this->_comId();
		
		$this->plugins = array(	'auth'		=> array('folder' => 'authentication', 	'element' => 'jwhmcs_auth', 	'path' => 'plg_jwhmcs_auth'		),
								'sysm'		=> array('folder' => 'system', 			'element' => 'jwhmcs_sysm', 	'path' => 'plg_jwhmcs_sysm'		),
								'sysmlang'	=> array('folder' => 'system', 			'element' => 'jwhmcs_sysmlang', 'path' => 'plg_jwhmcs_sysmlang'	),
								'user'		=> array('folder' => 'user', 			'element' => 'jwhmcs_user', 	'path' => 'plg_jwhmcs_user'		),
								'jauth'		=> array('folder' => 'authentication', 	'element' => 'joomla', 			'path' => '' 					)
		);
		$this->mtypes = array(	'hidden'	=> array('menutype' => 'jwhmcs-hidden',	'title' => 'JWHMCS Hidden Menu', 'desc' => 'This menu was created by the J!WHMCS Installer to store the Logged In and Logged Out pages'	),
								'client'	=> array('menutype' => 'client-menu',	'title' => 'Client Menu',		'desc' => 'This menu was created to be displayed on the client pages')
		);
		$this->mitems = array(	'hidden'	=> 	array( 
									'register'	=>	array( "Registration",	"jwhmcs-registration",	"index.php?option=com_jwhmcs&view=register",				"component",	1, $this->comid, 3, ""),
									'logout'	=>	array( "Logged Out",	"jwhmcs-logged-out",	"index.php?option=com_jwhmcs&view=default",					"component",	1, $this->comid, 2, ""),
									'login'		=>	array( "Logged In",		"jwhmcs-logged-in",		"index.php?option=com_jwhmcs&view=default",					"component",	1, $this->comid, 1, "")
												),
								'client'	=> array(
									'logout'	=>	array( "Logout",					"jwhmcs-logout",			sprintf("%s/jwhmcs.php?task=ulogout", rtrim( $params->get( 'ApiUrl' ), "/" )),			"url",	1, 0, 10, ""),
									'addfunds'	=>	array( "Add Funds",					"jwhmcs-add-funds",			sprintf("%s/clientarea.php?action=addfunds", rtrim( $params->get( 'ApiUrl' ), "/" )),	"url",	1, 0, 9, ""),
									'myemails'	=>	array( "My Emails",					"jwhmcs-my-emails",			sprintf("%s/clientarea.php?action=emails", rtrim( $params->get( 'ApiUrl' ), "/" )),		"url",	1, 0, 8, ""),
									'mysupport'	=>	array( "My Support Tickets",		"jwhmcs-my-support-tickets",sprintf("%s/supporttickets.php", rtrim( $params->get( 'ApiUrl' ), "/" )),				"url",	1, 0, 7, ""),
									'myinvoice'	=>	array( "My Invoices",				"jwhmcs-my-invoices",		sprintf("%s/clientarea.php?action=invoices", rtrim( $params->get( 'ApiUrl' ), "/" )),	"url",	1, 0, 6, ""),
									'mydomains'	=>	array( "My Domains",				"jwhmcs-my-domains",		sprintf("%s/clientarea.php?action=domains", rtrim( $params->get( 'ApiUrl' ), "/" )),	"url",	1, 0, 5, ""),
									'myproduct' =>	array( "My Products / Services",	"jwhmcs-my-products",		sprintf("%s/clientarea.php?action=products", rtrim( $params->get( 'ApiUrl' ), "/" )),	"url",	1, 0, 4, ""),
									'mydetails' =>	array( "My Details",				"jwhmcs-my-details",		sprintf("%s/clientarea.php?action=details", rtrim( $params->get( 'ApiUrl' ), "/" )),	"url",	1, 0, 3, ""),
									'carea'		=>	array( "Client Area",				"jwhmcs-client-area",		sprintf("%s/clientarea.php", rtrim( $params->get( 'ApiUrl' ), "/" )),					"url",	1, 0, 2, ""),
									'cportal'	=>	array( "Client Portal",				"jwhmcs-client-portal",		sprintf("%s/index.php", rtrim( $params->get( 'ApiUrl' ), "/" )),						"url",	1, 0, 1, "")
												)
		);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	instInitialize
	 * Purpose:		Initialize the installation
	 * As of:		version 2.1.0 (May 2010)
	\* ------------------------------------------------------------ */
	function instInitialize()
	{
		$jname			=   "JWHMCS Integrator";
		$path			=   trim( urldecode( JRequest::getVar( 'whmcspath' ) ) );
		$rununinstall	=   ( JRequest::getVar( 'rununinstall' ) ? true : false );
		$params			= & JwhmcsParams::getInstance();
		$paramupgrade	=   false;
		
		$data['task'] = ( $rununinstall ? 4 : 1 );
		
		if ( preg_replace( "/[a-zA-Z.-]/", "", $params->get( 'Version' ) ) < preg_replace( "/[a-zA-Z.-]/", "", JWHMCS_VERS ) )
		{
			$data['task'] = 2;
			$prevvers = $params->get( 'Version' );
		}
		else
		{
			$data['task'] = 1; // Must be installed right?
		}
		
		switch($data['task']):
		case 1:		// Installation task determined
			$uri = & JURI::getInstance();
			$uri->setPath( $this->_trimAdmin( $uri->getPath() ) );
			$params->set( 'Debug', 1, false, 'global' );
			$params->set( 'MenuDefault', 1, false, 'menu' );
			$params->set( 'MenuStyle', 'joomla', false, 'menu' );
			$params->set( 'JoomlaUrl', $uri->toString(array('scheme', 'host', 'path')), false, 'global' );
			$params->set( 'RenderImageurl', $uri->toString(array('scheme', 'host', 'path')), false, 'style' );
			$params->set( 'RedirLoginurl', $uri->toString(array('scheme', 'host', 'path')), false, 'user' );
			$params->set( 'RedirLogouturl', $uri->toString(array('scheme', 'host', 'path')), false, 'user' );
			$params->set( 'Version', JWHMCS_VERS, false, 'global' );
			$params->saveAll();
			
			$data['nextstep']	= 101;
			$data['message'][]	= "New Install of version ".JWHMCS_VERS." Proceeding";
			break;
		case 2:		// Upgrade task determined
			$data['nextstep']	= 201;
			$data['message'][]	= "Upgrade of version ".$prevvers." to ".JWHMCS_VERS." Proceeding";
			
			
			$uri = & JURI::getInstance();
			$uri->setPath( rtrim($uri->getPath(), 'administrator/index.php' ) );
			if ($params->get( 'Debug' ) === false )				$params->set( 'Debug', 1, false, 'global' );
			if ($params->get( 'MenuDefault' ) === false )		$params->set( 'MenuDefault', 1, false, 'menu' );
			if ($params->get( 'MenuStyle' ) === false )			$params->set( 'MenuStyle', 'joomla', false, 'menu' );
			if ($params->get( 'JoomlaUrl' ) === false )			$params->set( 'JoomlaUrl', $uri->toString(array('scheme', 'host', 'path')), false, 'global' );
			if ($params->get( 'RenderImageurl' ) === false )	$params->set( 'RenderImageurl', $uri->toString(array('scheme', 'host', 'path')), false, 'style' );
			if ($params->get( 'RedirLoginurl' ) === false )		$params->set( 'RedirLoginurl', $uri->toString(array('scheme', 'host', 'path')), false, 'user' );
			if ($params->get( 'RedirLogoouturl' ) === false )	$params->set( 'RedirLogouturl', $uri->toString(array('scheme', 'host', 'path')), false, 'user' );
			//$params->set( 'Version', JWHMCS_VERS, false, 'global' );
			$params->saveAll();
			break;
		case 4:		// Uninstall task determined
			$data['nextstep']	= 401;
			$data['message'][]	= "Uninstallation Proceeding";
			break;
		case 8:		// Running install again
			$data['nextstep']	= 201;
			$data['message'][]	= "Running Installation of version ".JWHMCS_VERS." again";
			break;
		endswitch;
		
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	instPlugins
	 * Purpose:		Handles the installation process for plugins
	 * As of:		version 2.1.0 (May 2010)
	\* ------------------------------------------------------------ */
	function instPlugins($step, $verbose = true)
	{
		$params			= & JwhmcsParams::getInstance();
		
		switch ($step):
		
		/* ----------------------------------------------------------------- STEP 101 *\
		 * INSTALLATION PROCEDURE - Install Authentication Plugin
		\* -------------------------------------------------------------------------- */
		case 101:				// Install Authentication Plugin
			$data['message'][]	= $this->_pluginHandler('auth', 'install');
			$data['nextstep'] = $step + 1;
			break;
		case 201:				// Upgrade Authentication Plugin
			$data['message'][]	= $this->_pluginHandler('auth', 'reinstall', $verbose);
			$data['nextstep'] = $step + 1;
			break;
			
		/* ----------------------------------------------------------------- STEP 102 *\
		 * INSTALLATION PROCEDURE - Install System Plugin
		\* -------------------------------------------------------------------------- */
		case 102:				// Install System Plugin
			$data['message'][]	= $this->_pluginHandler('sysm', 'install');
			$data['nextstep'] = $step + 1;
			break;
		case 202:				// Upgrade System Plugin
			$data['message'][]	= $this->_pluginHandler('sysm', 'reinstall', $verbose);
			$data['nextstep'] = $step + 1;
			break;
			
		/* ----------------------------------------------------------------- STEP 103 *\
		 * INSTALLATION PROCEDURE - Install System Language Plugin
		\* -------------------------------------------------------------------------- */
		case 103:				// Install System Language Plugin
			$data['message'][]	= $this->_pluginHandler('sysmlang', 'install');
			$data['nextstep'] = $step + 1;
			break;
		case 203:				// Upgrade System Language Plugin
			$data['message'][]	= $this->_pluginHandler('sysmlang', 'reinstall', $verbose);
			$data['nextstep'] = $step + 1;
			break;
		
		/* ----------------------------------------------------------------- STEP 104 *\
		 * INSTALLATION PROCEDURE - Install User Plugin
		\* -------------------------------------------------------------------------- */
		case 104:				// Install User Plugin
		case 204:				// Upgrade User Plugin
			$data['message'][]	= ( $step == 104 ? $this->_pluginHandler('user', 'install', $verbose) : $this->_pluginHandler('user', 'reinstall', $verbose) );
			$updates			= $this->_pluginHandler('user', 'update', $verbose, array('ordering' => 10001));
			
			// If we need error messages then run through each update as an array
			if ( $verbose )
				foreach ($updates as $update) $data['message'][] = $update;
				
			// If not, be sure updates is true or else return false for entire process
			else
				if (! $updates ) $data['message'] = array( 0 => false );
			
			$data['nextstep'] = $step + 3;
			break;
		
		/* ----------------------------------------------------------------- STEP 107 *\
		 * INSTALLATION PROCEDURE - Create Hidden Menu
		\* -------------------------------------------------------------------------- */
		case 107:			// Create Hidden Menu
		case 207:			// Create Hidden Menu
			$data['message'][]	= $this->_menuHandler('hidden', 'typeadd', null, $verbose);
			$msg				= $this->_menuHandler('hidden', 'itemsadd', null, $verbose);
			$data['message']	= array_merge($data['message'], $msg);
			
			// Retrieve IDs of corresponding menu items
			$params->set( 'RenderLoggedin',  $this->_menuHandler('hidden', 'itemexists', 'login', false ), false, 'style' );
			$params->set( 'RenderLoggedout', $this->_menuHandler('hidden', 'itemexists', 'logout', false ), false, 'style' );
			$params->saveAll();
			
			$data['nextstep'] = $step + 3;
			break;
		endswitch;
		
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	instApi
	 * Purpose:		Handles the installation process for plugins
	 * As of:		version 2.1.0 (May 2010)
	\* ------------------------------------------------------------ */
	function instApi($step, $verbose = true)
	{
		$params = & JwhmcsParams::getInstance();
		
		$apiurl	= & JURI::getInstance(trim( urldecode( JRequest::getVar( 'whmcsurl' ) ) ) );
		
		$params->set( 'ApiUrl', $apiurl->toString(), false, 'global' );
		$params->set( 'ApiUsername', trim( urldecode( JRequest::getVar( 'jwhmcsadminus' ) ) ), false, 'global' );
		$params->set( 'ApiPassword', trim( urldecode( JRequest::getVar( 'jwhmcsadminpw' ) ) ), false, 'global' );
		$params->set( 'ApiAccesskey', trim( urldecode( JRequest::getVar( 'accesskey' ) ) ), false, 'global' );
		$params->saveAll();
		
		$data = $this->_getApiConnection();
		
		$data['nextstep'] = ( $data['valid']===false ? $step : $step + 5 );
		
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	instFiles
	 * Purpose:		Handles the installation process for WHMCS Files
	 * As of:		version 2.1.0 (May 2010)
	\* ------------------------------------------------------------ */
	function instFiles($step, $verbose = true)
	{
		$params	= & JwhmcsParams::getInstance();
		$files	= & JwhmcsFilehandler::getInstance();
		
		$useftp =   ( $params->get( 'FtpUse' ) ? true : false );
		
		switch ($step):
		/* ----------------------------------------------------------------- STEP 120 *\
		 * INSTALLATION PROCEDURE - Install Root Files
		\* -------------------------------------------------------------------------- */
		case 120:			// Install Root Files
		case 220:			// Upgrade Root Files
			
			$tmp = $files->copy( JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.'whmcs'.DS.'jwhmcs.php', 'jwhmcs.php', true );
			
			if ( $tmp === false ) {
				$data['nextstep'] = 950;
				break;
			}
			
			$result[]	= $tmp;
			
			$files->read( 'src', JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.'whmcs'.DS.'jconfig.php' );
			$buffer		= sprintf( $files->buffer, JPATH_CONFIGURATION, 'configuration.php' );
			
			$files->setBuffer( $buffer );
			
			$result[]	= $files->write( 'dst', 'jconfig.php', true );
			
			$data['nextstep']	= $step + 5;
			
			break;
		
		/* ----------------------------------------------------------------- STEP 125 *\
		 * INSTALLATION PROCEDURE - Install Includes Files (Hooks and API)
		\* -------------------------------------------------------------------------- */
		case 125:			// Install Includes Files
		case 225:			// Upgrade Includes Files
			
			$files->foldercopy( JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.'whmcs'.DS.'includes', 'includes', true );
			$files->foldercopy( JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.'whmcs'.DS.'modules', 'modules', true );
			
			$data['nextstep'] = $step + 5;
			break;
			
		/* ----------------------------------------------------------------- STEP 130 *\
		 * INSTALLATION PROCEDURE - Retrieve and update settings
		\* -------------------------------------------------------------------------- */
		case 130:
		case 230:
			
			$jcurl	= & JwhmcsCurl::getInstance();
			
			// Use new API interface
			$jcurl->setAction('jwhmcsconfig', array("init" => "2" ) );
			$whmcs	= $jcurl->loadResult();
			
			$data['message'][] = JText::_( $whmcs['message'] );
			unset ($whmcs);
			
			// Use new API interface
			$jcurl->setAction('jwhmcsgetsettings', array("get" => "Version,SystemURL,SystemSSLURL,DefaultCountry,Template,Charset,NOMD5,RequiredPWStrength" ) );
			$whmcs	= $jcurl->loadResult();
			
			$uri = JURI::getInstance($whmcs['systemurl']);
			$ssl = false;
			
			if (! isset( $whmcs['systemsslurl'] ) ) $whmcs['systemsslurl'] = null;
			if (! isset( $whmcs['nomd5'] ) ) $whmcs['nomd5'] = false;
			
			if (trim($whmcs['systemsslurl'])) {
				$suri = JURI::getInstance($whmcs['systemsslurl']);
				$ssl = $suri->getScheme() == 'https' ? true : false;
			}
			
			$params->set( 'ApiUrl', $uri->toString(), false, 'global' );
			$params->set( 'RenderSslenable', ($ssl ? 1 : 0), false, 'style' );
			$params->set( 'WhmcsVersion', $whmcs[ 'version' ], false, 'whmcs' );
			$params->set( 'WhmcsTemplate', $whmcs[ 'template' ], false, 'whmcs' );
			$params->set( 'WhmcsSystemurl', $whmcs[ 'systemurl' ], false, 'whmcs' );
			$params->set( 'WhmcsSystemsslurl', $whmcs[ 'systemsslurl' ], false, 'whmcs' );
			$params->set( 'WhmcsDefaultcountry', $whmcs[ 'defaultcountry' ], false, 'whmcs' );
			$params->set( 'WhmcsRequiredpwstrength', $whmcs[ 'requiredpwstrength' ], false, 'whmcs' );
			$params->set( 'WhmcsNomd5', $whmcs[ 'nomd5' ], false, 'whmcs' );
			$params->set( 'WhmcsCharacterset', $whmcs[ 'charset' ], false, 'whmcs' );
			$params->set( 'PreviousVersion', $whmcs[ 'version' ], false, 'install' );
			$params->set( 'PreviousTemplate', $whmcs[ 'template' ], false, 'install' );
			$params->set( 'PreviousRequiredpwstrength', $whmcs[ 'requiredpwstrength' ], false, 'install' );
			
			$params->saveAll();
			
			$template	= ($whmcs['template'] == 'default' ? 'jwhmcs-default' : 'jwhmcs-portal' );
			$serverip	= isset($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : $_SERVER['LOCAL_ADDR'];
			
			//$jcurl->setAction('jwhmcsgetsettings', array("set" => "Template=$template;RequiredPWStrength=0" ) );
			$jcurl->setAction('jwhmcsgetsettings', array("set" => "RequiredPWStrength=0" ) );
			$wset	= $jcurl->loadResult();
			
			//$jcurl->setAction('jwhmcsgetsettings', array("addip" => $serverip ) );
			//$wset	= $jcurl->loadResult();
			
			$data['message'][] = $wset['message'];
			$data['nextstep']	= $step + 5;
			break;
			
		/* ----------------------------------------------------------------- STEP 135 *\
		 * INSTALLATION PROCEDURE - Install Template Files
		\* -------------------------------------------------------------------------- */
		case 135:			// Install Template Files
		case 235:			// Upgrade Template Files
			
			$data['nextstep'] = $step + 5;
			break;
			/*
			$wvers	= str_replace( ".", "", $params->get( 'WhmcsVersion' ) );
			
			$vers	= "v" . ( $wvers <= 410 ? '4.0.2' :
							( $wvers <  420 ? "4.1.2" : 
							( $wvers <  430 ? "4.2.1" : 
							( $wvers <  440 ? "4.3.1" : 
							( $wvers <  450 ? "4.4.1" :
							( $wvers <	500 ? "4.5.1" :
								"5.0.0"
							) ) ) ) ) );
			$src	= JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.'whmcs'.DS.'templates'.DS.$vers.DS;
			$tpl	= 'templates';
			
			if ( $files->folderduplicate( $tpl.'/default', $tpl.'/jwhmcs-default', true ) ) {
				$files->foldercopy( $src . 'jwhmcs-default', $tpl . '/jwhmcs-default', true );
			}
			
			if ( $files->folderduplicate( $tpl.'/portal', $tpl.'/jwhmcs-portal', true ) ) {
				$files->foldercopy( $src . 'jwhmcs-portal', $tpl . '/jwhmcs-portal', true );
			}
			
			// WHMCS v5 template
			if ( $wvers >= 500 ) {
				if ( $files->folderduplicate( $tpl.'/classic', $tpl.'/jwhmcs-classic', true ) ) {
					$files->foldercopy( $src . 'jwhmcs-classic', $tpl . '/jwhmcs-classic', true );
				}
			}
			
			$files->setBackup( true );
			$files->foldercopy( $src.'orderforms', $tpl.'/orderforms', true );
			
			if ( ( $vers == "v4.3.1") OR ( $vers == "v4.4.1" ) ) {
				$files->foldercopy( $src . 'order', 'order', true );
			}
			
			$data['nextstep'] = $step + 5;*/
			break;
		
		/* ----------------------------------------------------------------- STEP 140 *\
		 * INSTALLATION PROCEDURE - Install Image Files
		\* -------------------------------------------------------------------------- */
		case 140:			// Install Image Files
		case 240:			// Upgrade Image Files
			$src	= JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.'whmcs'.DS.'images';
			$img	= 'images';
			
			$files->foldercopy( $src, $img , true );
			
			$data['nextstep'] = $step + 1;
			break;
			
		/* ----------------------------------------------------------------- STEP 141 *\
		 * INSTALLATION PROCEDURE - Create cache directory
		\* -------------------------------------------------------------------------- */
		case 141:			// Create cache directory
		case 241:			// Create cache directory
			
			$files->setSrc( JPATH_ROOT.DS.'cache'.DS.'jwhmcs', 'folder' );
			$files->foldercreate( 'src' );
			
			$data['nextstep'] = $step + 4;
			break;
			
		/* ----------------------------------------------------------------- STEP 142 *\
		 * INSTALLATION PROCEDURE - Install Customized files for complicated installs
		\* -------------------------------------------------------------------------- */
		case 142:			// Install Configuration, classes and custom jconfig file
		case 242:			// Upgrade Configuration, classes and custom jconfig file
			
			$files->copy( JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.'whmcs'.DS.'jconfig.php', 'jconfig.php', true );
			$files->copy( JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.'whmcs'.DS.'jwhmcs.php', 'jwhmcs.php', true );
			
			$params	= & JwhmcsParams::getInstance();
			$jcurl	= & JwhmcsCurl::getInstance();
			$jcurl->setCall();
			
			$url = rtrim( $params->get( 'ApiUrl' ), '/' ).'/jwhmcs.php?task=checkinstall&joomadmin='.$params->get( 'Secret' );
			$jcurl->set(CURLOPT_URL, $url);
			$jcurl->setRoot('PARAM');
			$report = $jcurl->loadResult();
			
			if ( $report['result'] == 'succes' ) {
				$data['nextstep']	= $step + 8;
				return $data;
			}
			
			// Ensure if Windows the directory separator is double slashed so it isn't lost
			$ds = $report['dirsep'];
//			$ds = addslashes($report['dirsep']);
			$curdir	 = addslashes($report['curdir']);
			$firString = $curdir.$ds.'jwhmcs';
			$secString = "configuration.php' );
if (! defined(JWHMCS_BASE_PATH) )	define( 'JWHMCS_BASE_PATH', JPATH_CONFIG.DS );
if (! defined(JWHMCS_CLASS_PATH) )	define( 'JWHMCS_CLASS_PATH', JWHMCS_BASE_PATH );
// echo ('";
			
			// Custom Jconfig file
			$files->setOverwrite( true );
			$files->setDst( 'jconfig.php' );
			
			$buffer		= $files->read( 'src', JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.'whmcs'.DS.'jconfig.php' );
			$buffer		= sprintf( $buffer, $firString, $secString );
			
			$files->setBuffer( $buffer );
			$result[]	= $files->write( 'dst', 'jconfig.php', true );
			
			// Create remote jwhmcs folder
			$files->setDst( 'jwhmcs', 'folder' );
			
			// Joomla Configuration file
			$files->copy( JPATH_CONFIGURATION.DS.'configuration.php', "jwhmcs".$ds."configuration.php", true );
			
			// Classes directory
			$files->foldercopy ( JPATH_COMPONENT_ADMINISTRATOR.DS.'classes', 'jwhmcs', true );
			
			// Curl again to see if the configuration works now
			$result = $this->verifyFiles(0);
			
			if ($result['error']) {
				$data['nextstep']	= ( $step < 200 ? 998 : 988 );
			}
			else {
				$data['nextstep']	= $step + 8;
			}
			
			return $data;
			break;
		endswitch;
		
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	instWrapup
	 * Purpose:		Handles the installation process wrap up tasks
	 * As of:		version 2.0.2 (March 2010)
	 * 
	 * Significant Revisions:
	 *  2.1.1 (May 2010)
	 *  	M `process` renamed to `instWrapup`
	 *  	D removed most of steps and broke into separate functions
	 *  2.1.0 (Apr 2010)
	 *  	* Modified parameters to reflect database change
	\* ------------------------------------------------------------ */
	function instWrapup($step, $instverb = true)
	{
		$jname			=   "JWHMCS Integrator";
		$path			=   trim( urldecode( JRequest::getVar( 'whmcspath' ) ) );
		$rununinstall	=   ( JRequest::getVar( 'rununinstall' ) ? true : false );
		$params			= & JwhmcsParams::getInstance();
		$paramupgrade	=   false;
		
		switch ($step):
			
		/* ----------------------------------------------------------------- STEP 160 *\
		 * INSTALLATION PROCEDURE - Create Client Menu
		\* -------------------------------------------------------------------------- */
		case 160:			// Install Create Client Menu
		case 260:			// Upgrade Create Client Menu
			$data['message'][]	= $this->_menuHandler('client', 'typeadd', null, $instverb);
			$data['message']	= array_merge($data['message'], $this->_menuHandler('client', 'itemsadd', null, $instverb));
			
			$data['nextstep'] = ( $step + 10 );
			break;
		
		/* ----------------------------------------------------------------- STEP 170 *\
		 * INSTALLATION PROCEDURE - Synchronize Users
		\* -------------------------------------------------------------------------- */
		case 170:			// Install sync users
		case 280:			// Upgrade sync users
			
			$sync = & JwhmcsModel::getInstance('sync', 'JwhmcsModel');
			$user = & JwhmcsModel::getInstance('usermgr', 'JwhmcsModel');
			
			$result['sync'] = $sync->reload();
			$result['user'] = $user->matchAll();
			
			$txt[1][1] = JText::_( 'INSTALL_USER_SYNC_INSTALL_YES' );
			$txt[1][0] = JText::_( 'INSTALL_USER_SYNC_INSTALL_NO' );
			$txt[2][1] = JText::_( 'INSTALL_USER_SYNC_UPGRADE_YES' );
			$txt[2][0] = JText::_( 'INSTALL_USER_SYNC_UPGRADE_NO' );
			
			$data['message'][] = $result['sync'] ? "WHMCS Database Table reloaded" : "There was an error reloading the WHMCS Database table";
			$data['message'][] = $txt[ ( $step == 170 ? 1 : 2 ) ][ ( $result['user'] ? 1 : 0 ) ];
			
			$data['nextstep'] = ($step == 170 ? 999 : 989 );
			break;
		
		/* ----------------------------------------------------------------- STEP 280 *\
		 * UPGRADE ONLY PROCEDURE - Database Updates
		\* -------------------------------------------------------------------------- */
		case 270:
			
			$params		= & JwhmcsParams::getInstance();
			$prevvers 	=   $params->get( 'Version' );
			
			/**
			 * Version 2.4.10 corrected a database issue
			 */
			if ( version_compare( $prevvers, '2.4.10', 'l' ) ) {
				$db = & JFactory :: getDbo();
				$query	= "DROP TABLE IF EXISTS `#__jwhmcs_user`";
				$db->setQuery( $query );
				$db->query();
				
				$query	= "DROP TABLE IF EXISTS `#__jwhmcs_usersub`";
				$db->setQuery( $query );
				$db->query();
				
				$query	= "CREATE TABLE IF NOT EXISTS `#__jwhmcs_user` ( `id` INT(10) NOT NULL AUTO_INCREMENT, `fname` TEXT NULL, `lname` TEXT NULL, `cname` TEXT NULL, `email` TEXT NOT NULL, `address1` TEXT NULL, `address2` TEXT NULL, `city` TEXT NULL, `state` TEXT NULL, `postal` TEXT NULL, `country` TEXT NULL, `phonenumber` TEXT NULL, PRIMARY KEY (`id`) ) ENGINE = MyISAM CHARACTER SET `utf8`";
				$db->setQuery( $query );
				$db->query();
				
				$query	= "CREATE TABLE IF NOT EXISTS `#__jwhmcs_usersub` ( `id` INT(10) NOT NULL AUTO_INCREMENT, `fname` TEXT NULL, `lname` TEXT NULL, `cname` TEXT NULL, `email` TEXT NOT NULL, `address1` TEXT NULL, `address2` TEXT NULL, `city` TEXT NULL, `state` TEXT NULL, `postal` TEXT NULL, `country` TEXT NULL, `phonenumber` TEXT NULL, PRIMARY KEY (`id`) ) ENGINE = MyISAM CHARACTER SET `utf8`";
				$db->setQuery( $query );
				$db->query();
			}
			
			// Now go back up and resync the database
			$data['nextstep'] = 280;
			break;
			
		// ================================================================= STEP 950
		// THIS IS TO CATCH MISSING WHMCS FILES SO WE DONT DO SOMETHING WRONG
		// ==========================================================================
		case 950:
			$data['message'][]	= $this->_pluginHandler('auth', 'deactivate' );
			$data['message'][]	= $this->_pluginHandler('sysm', 'deactivate' );
			$data['message'][]	= $this->_pluginHandler('sysmlang', 'deactivate' );
			$data['message'][]	= $this->_pluginHandler('user', 'deactivate' );
			$data['message'][]	= $this->_pluginHandler('jauth', 'activate' );
			$data['message'][]	= "Please install the WHMCS Addon Module now";
			$data['nextstep']	= 1000;
			break;
			
		/* ----------------------------------------------------------------- STEP 988 *\
		 * ABORT PROCEDURE - Deactivate plugins, reactivate J! plugins
		\* -------------------------------------------------------------------------- */
		case 988:			// Upgrade aborted - deactivate new plugins, reactivate Joomla
			$data['message'][]	= $this->_pluginHandler('auth', 'deactivate' );
			$data['message'][]	= $this->_pluginHandler('sysm', 'deactivate' );
			$data['message'][]	= $this->_pluginHandler('sysmlang', 'deactivate' );
			$data['message'][]	= $this->_pluginHandler('user', 'deactivate' );
			$data['message'][]	= $this->_pluginHandler('jauth', 'activate' );
			$data['message'][]	= "Installation aborted by user";
			
		/* ----------------------------------------------------------------- STEP 989 *\
		 * WRAPUP PROCEDURE - Final task just in case we add something later
		\* -------------------------------------------------------------------------- */
		case 989:			// Upgrade wrap up - write log file
			
			$params->set( 'Version', JWHMCS_VERS, false, 'global' );
			$params->saveAll();
			
			$data['message'][]	= "Upgrade completed";
			$data['nextstep']	= 1000;
			break;
		/* ----------------------------------------------------------------- STEP 998 *\
		 * ABORT PROCEDURE - Deactivate plugins, reactivate J! plugins
		\* -------------------------------------------------------------------------- */
		case 998:			// Installation aborted - deactivate new plugins, reactivate Joomla
			
			$data['message'][]	= "$jname Authentication Plugin ".( $this->_pluginHandler( 'auth', 'deactivate' ) ? "deactivated" : "failed to deactivate" );
			$data['message'][]	= "$jname System Plugin ". ( $this->_pluginHandler( 'sysm', 'deactivate' ) ? "deactivated" : "failed to deactivate" );
			$data['message'][]	= "$jname System Language Plugin " . ( $this->_pluginHandler( 'sysmlang', 'deactivate' ) ? "deactivated" : "failed to deactivate" );
			$data['message'][]	= "$jname User Plugin " . ( $this->_pluginHandler( 'user', 'deactivate' ) ? "deactivated" : "failed to deactivate" );
			$data['message'][]	= "Joomla Authentication Plugin " . ( $this->_pluginHandler( 'jauth', 'activate' ) ? "reactivated" : "FAILED TO REACTIVATE - DO NOT LOG OUT OF JOOMLA BEFORE RE-ENABLING JOOMLA PLUGIN!" );
			$data['message'][]	= "Installation aborted by user";
			
		/* ----------------------------------------------------------------- STEP 999 *\
		 * WRAPUP PROCEDURE - Final task just in case we add something later
		\* -------------------------------------------------------------------------- */
		case 999:			// Interview wrap up - write log file
			$data['message'][]	= "Installation completed";
			$data['nextstep']	= 1000;
			break;
		endswitch;
		$data['message'][] = '<hr size="1" style="margin: 0; padding: 0px; " />';
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	verifyPath
	 * Purpose:		Verify Path to WHMCS
	 * As of:		version 2.1.0 (May 2010)
	\* ------------------------------------------------------------ */
	function verifyPath( $step, $verbose = true )
	{
		$params = & JwhmcsParams::getInstance();
		$path	=   trim( urldecode( JRequest::getVar( 'whmcspath' ) ) );
		
		$options['path']	= $path;
		
		$valid	= JwhmcsFilehandler::verify( $options, 'path' );
		$data['nextstep']	= $step;
		
		switch ($valid):
		case "-4":
			$msg = "Installer is unable to write to the WHMCS installation directory, bypassing file installation.";
			break;
		case "-3":
			$msg = "The path `$path` exists but the file `dologin.php` cannot be found (" . $path.DS.'dologin.php'.")";
			break;
		case "-2":
			$msg = "The path `$path` exists but the file `configuration.php` cannot be found (" . $path.DS.'configuration.php'.")";
			break;
		case "-1":
			$msg = "Please enter a path to validate";
			break;
		case "1":
			$data['nextstep']	= $step + 5;
			$params->saveAll();
			$msg = "WHMCS Path validated proceeding with installation";
			break;
		endswitch;
		
		$data['valid']		= $valid;
		$data['message'][]	= $msg;
		
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	verifyFtp
	 * Purpose:		Verify FTP credentials
	 * As of:		version 2.1.0 (May 2010)
	\* ------------------------------------------------------------ */
	function verifyFtp($step)
	{
		$options = array();
		$options['hostname']	=   JRequest::getVar('hostname');
		$options['port']		=   JRequest::getVar('port');
		$options['username']	=   JRequest::getVar('username');
		$options['password']	=   JRequest::getVar('password');
		
		$valid	= JwhmcsFilehandler::verify( $options, 'ftp');
		
		$data['nextstep']	= $step;
		
		switch ($valid):
		case 1:
			$data['nextstep']	= $step + 5;
			$data['message'][]	= "Connected and WHMCS located!";
			break;
		case 2:
			$data['message'][]	= sprintf("Failed to connect to %s:%s", JRequest::getVar( 'hostname' ), JRequest::getVar( 'port' ) );
			break;
		case 3:
			$data['message'][]	= sprintf("Connected to %s however the credentials are incorrect", JRequest::getVar( 'hostname' ));
			break;
		case 4:
			$data['message'][]	= sprintf("Connected to server however was unable to locate the WHMCS installation" );
			break;
		endswitch;
		
		$data['status'] = $valid;
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	verifyFiles
	 * Purpose:		Verify Files were transferred over
	 * As of:		version 2.1.0 (May 2010)
	\* ------------------------------------------------------------ */
	function verifyFiles($step)
	{
		$params	= & JwhmcsParams::getInstance();
		$jcurl	= & JwhmcsCurl::getInstance();
		$jcurl->setCall();
		
		$url = rtrim( $params->get( 'ApiUrl' ), '/' ).'/jwhmcs.php?task=checkinstall&joomadmin='.$params->get( 'Secret' );
		$jcurl->set(CURLOPT_URL, $url);
		$jcurl->setRoot('PARAM');
		$report = $jcurl->loadResult();
		
		if ($report['result'] == 'success') {
			$data['message'][]	= "Files installed and verified";
			$data['error']		= false;
			$data['nextstep']	= $step + 5;
		}
		elseif ($report['result'] == 'error') {
			if ($report['code'] == 'ERR001' ) {
				$data['message'][]	= "File verification failed - attempting recovery";
				$data['error']		= true;
				$data['nextstep']	= $step - 3;
			}
			else {
				$data['message'][]	= "File verification failed - aborting for manual install";
				$data['error']		= true;
				$data['nextstep']	= ( $step < 200 ? 998 : 988 );
			}
		}
		else
		{
			$data['nextstep'] = ( $step < 200 ? 998 : 988 );
		}
		
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	verifyLicense
	 * Purpose:		Verify license for product is legit
	 * As of:		version 2.1.0 (May 2010)
	\* ------------------------------------------------------------ */
	function verifyLicense($step)
	{
		$params = & JwhmcsParams::getInstance();
		
		$license = trim( urldecode( JRequest::getVar( 'license' ) ) );
		
		if ($license) {
			$params->set( 'License', '', true, 'global' );
			$params->set( 'LicenseKey', $license, true, 'global' );
		}
		else
		{
			$data['valid']		= false;
			$data['message'][]	= "Please Enter Your License";
			$data['nextstep']	= $step;
			return $data;
		}
		
		// Remove license.txt file in case legacy installation
		$oldfile	= JPATH_COMPONENT_ADMINISTRATOR.DS.'license.txt';
		if ( JFile::exists( $oldfile ) )
		{
			JFile::delete( $oldfile );
		}
		
		$data = $this->checkLicense();
		 
		if ($data['valid'] == 1) {
			$data['message'][]	= "License validated";
			$data['nextstep'] = ( $step + 10 );
		} else {
			$data['nextstep'] = $step;
		}
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	process
	 * Purpose:		Called by Ajax to fix issue
	 * As of:		version 2.1.1 (June 2010)
	\* ------------------------------------------------------------ */
	function process( $step, $verbose = false )
	{
		switch( $step ):
		
		/* ----------------------------------------------------------------- STEP  20 *\
		 * FIX INSTALLATION - Hidden Menu reinstall
		\* -------------------------------------------------------------------------- */
		case 20:
			$result = $this->instPlugins( 107, $verbose );
			break;
		
		/* ----------------------------------------------------------------- STEP  30 *\
		 * FIX INSTALLATION - Client Menu reinstall
		\* -------------------------------------------------------------------------- */
		case 30:
			$result = $this->instWrapup( 160, $verbose );
			break;
		
		/* ----------------------------------------------------------------- STEP 100 *\
		 * FIX INSTALLATION - Authentication Plugin
		\* -------------------------------------------------------------------------- */
		case 100:
			$result = $this->instPlugins( 201, $verbose );
			break;
			
		/* ----------------------------------------------------------------- STEP 110 *\
		 * FIX INSTALLATION - System Plugin
		\* -------------------------------------------------------------------------- */
		case 110:
			$result	= $this->instPlugins( 202, $verbose );
			break;
			
		/* ----------------------------------------------------------------- STEP 120 *\
		 * FIX INSTALLATION - System Language Plugin
		\* -------------------------------------------------------------------------- */
		case 120:
			$result	= $this->instPlugins( 203, $verbose );
			break;
			
		/* ----------------------------------------------------------------- STEP 130 *\
		 * FIX INSTALLATION - User Plugin
		\* -------------------------------------------------------------------------- */
		case 130:
			$result	= $this->instPlugins( 204, $verbose );
			break;
			
		/* ----------------------------------------------------------------- STEP 200 *\
		 * FIX INSTALLATION - WHMCS Root Files Installed
		\* -------------------------------------------------------------------------- */
		case 200:
			$result	= $this->instFiles( 220, $verbose );
			break;
			
		/* ----------------------------------------------------------------- STEP 210 *\
		 * FIX INSTALLATION - WHMCS Hook Files Installed
		\* -------------------------------------------------------------------------- */
		case 210:
			$result	= $this->instFiles( 225, $verbose );
			break;
			
		/* ----------------------------------------------------------------- STEP 220 *\
		 * FIX INSTALLATION - WHMCS API Files Installed
		\* -------------------------------------------------------------------------- */
		case 220:
			$result	= $this->instFiles( 225, $verbose );
			break;
			
		/* ----------------------------------------------------------------- STEP 230 *\
		 * FIX INSTALLATION - WHMCS Template Files Installed
		\* -------------------------------------------------------------------------- */
		case 230:
			$result	= $this->instFiles( 235, $verbose );
			break;
			
		endswitch;
		
		return true;
	}
	
	
	/* ----------------------------------------- *\
	 *              SUB FUNCTIONS                *
	\* ----------------------------------------- */
	
	
	private function _trimAdmin( $url )
	{
		$find = "administrator/index.php";
		
		if ( substr( $url, -23 ) == $find )
		{
			return substr_replace( $url, "", -23 );
		}
		return $url;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_pluginHandler (private)
	 * Purpose:		Takes care of all plugin handling for installer
	 * As of:		version 2.0.2 (March 2010)
	\* ------------------------------------------------------------ */
	private function _pluginHandler( $plugin, $task = 'exists', $verbose = true, $options = null )
	{
		// Initialize variables first
		$plg		= $this->plugins[$plugin];
		$db			= & JFactory::getDBO();
		$path		= JPATH_COMPONENT_ADMINISTRATOR.DS.'files'.DS.$plg['path'];
		$installer	= new JInstaller;
		$isLegacy	=   version_compare( JVERSION, '1.6.0', 'ge' ) ? false : true;
		
		// Make a query to the database to retrieve the plugin id if it is there
		if ( $isLegacy ) {
			$query	= "SELECT `id`, `published`, `params` FROM #__plugins WHERE `element` = '" . $plg['element'] . "' AND `folder` = '" . $plg['folder'] ."'";
		}
		else {
			$query	= "SELECT `extension_id` as 'id', `enabled` as 'published', `params` FROM #__extensions WHERE `element` = '" . $plg['element'] . "' AND `folder` = '" . $plg['folder'] ."'";
		}
		
		$db->setQuery($query);
		$result	= $db->loadAssoc();
		
		// Switch off on tasks
		switch($task):
		
		// Check if the plugin exists
		case 'exists':
			
			// If not verbose then send either the id or false back
			if (! $verbose) return ( $result ? $result['id'] : false );
			
			return ( $result ? JText::sprintf( "INSTALL_PLG_DOESEXIST", $plg['element'] ) : JText::sprintf( 'INSTALL_PLG_ERROR_7', $plg['element'] ) );
			break;
		
		// Activate or Deactivate the plugin
		case 'activate':
		case 'deactivate':
			
			// Set the value based on the task
			$pub	= ( $task == 'activate' ? 1 : 0 );
			
			// Set the text response based on the task
			$txt	= ( $task == 'activate' ? '' : 'de' );
			
			// Make a call to do the update
			$update	= ( $isLegacy ? array( 'published' => $pub ) : array( 'enabled' => $pub ) );
			$return = $this->_pluginHandler($plugin, 'update', false, $update);
			
			// If not verbose then send back the result as it was received
			if (! $verbose) return $return;
			
			return ( $return ? JText::sprintf( 'INSTALL_PLG_ACTIVAT_SUCCESS', $plg['element'], $txt ) : JText::sprintf( 'INSTALL_PLG_ERROR_4', $txt, $plg['element'] ) );
			break;
			
		// Install the plugin
		case 'install':
			
			// First check to see if the source files exist
			if (! JFolder::exists($path))
				return (! $verbose ? false : JText::sprintf( 'INSTALL_PLG_ERROR_1', $plg['element'] ) );
			
			// Now check to see if it already exists - if it does, uninstall so we can install the new one
			if ($result) {
				if (! $this->_pluginHandler( $plugin, 'uninstall', false ) )
					return (! $verbose ? false : JText::sprintf( 'INSTALL_PLG_ERROR_2', $plg['element'] ) );
			}
			
			// Now perform the actual installation
			if (! $installer->install($path))
				return (! $verbose ? false : JText::sprintf( 'INSTALL_PLG_ERROR_3', $plg['element'] ) );
			else
				if (! $this->_pluginHandler( $plugin, 'activate', false ) ) {
					return (! $verbose ? false : JText::sprintf( 'INSTALL_PLG_ERROR_8', $plg['element'] ) );
				} else {
					return (! $verbose ? true : JText::sprintf( "INSTALL_PLG_INSTALL_SUCCESS", $plg['element'] ) );
				}
			break;
			
		// Uninstall the plugin
		case 'uninstall':
			
			// Lets see if we found the plugin
			if ($result) {
				
				// Perform uninstall
				$return = $installer->uninstall( 'plugin', $result['id'] );
				
				// If not verbose then send back the result as it was received
				if (! $verbose) return $return;
				
				return ( $return ? JText::sprintf( 'INSTALL_PLG_UNINSTA_SUCCESS', $plg['element'] ) : JText::sprintf( 'INSTALL_PLG_ERROR_5', $plg['element'] ) );
			}
			// Plugin wasn't found
			else {
				
				// If not verbose then send back false else send back text
				return (! $verbose ? false : JText::sprintf('INSTALL_PLG_ERROR_6', $plg['element'] ) );
			}
			break;
		case 'update':
			
			// Test first to see if we received options and if they are an array
			if (is_null($options) || (! is_array($options))) {
				
				// If not verbose then send back false else send back text
				return (! $verbose ? false : JText::sprintf( 'INSTALL_PLG_ERROR_A', $plg['element'] ) );
			}
			
			// Initialize query array
			$q = array();
			
			// Cycle through each option creating the queries
			foreach ($options as $k => $v) {
				if ( $isLegacy ) {
					$q[] = sprintf("UPDATE `#__plugins` SET `%s` = '%s' WHERE `id` = %d", $k, $v, $result['id'] );
				}
				else {
					$q[] = sprintf("UPDATE `#__extensions` SET `%s` = '%s' WHERE `extension_id` = %d", $k, $v, $result['id'] );
				}
			}
			
			// Cycle through each query
			foreach ($q as $query)
			{
				$db->setQuery($query);
				$result = $db->query();
				
				// If the update failed - Note: if failure occurs, the whole process fails and is sent back
				if (! $result) {
					
					// If not verbose then send back false else send back text
					return (! $verbose ? false : JText::sprintf( 'INSTALL_PLG_ERROR_9', $plg['element']) );
				}
				else {
					
					// Create the messages to send back
					$return[] = JText::sprintf( 'INSTALL_PLG_UPDATE_SUCCESS', $plg['element'], $k, $v );
				}
			}
			
			// Clean up return variable - if not verbose just send back true
			return (! $verbose ? true : $return );
			break;
			
		case 'reinstall':
			
			// Save the current parameters if they exist
			$current = ($result ? $result['params'] : '' );
			
			// Call Installer method
			if (! $this->_pluginHandler( $plugin, 'install', false) ) {
				
				// If not verbose then send back false else send back text
				return (! $verbose ? false : JText::sprintf( 'INSTALL_PLG_ERROR_B', $plg['element'] ) );
			}
			
			// Update parameters with originals
			if (! $this->_pluginHandler( $plugin, 'update', false, array('params' => $current) ) ) {
				
				// If not verbose then send back false else send back text
				return (! $verbose ? false : JText::sprintf( 'INSTALL_PLG_ERROR_C', $plg['element'] ) );
			}
			
			if ( $plugin == 'auth' ) $this->_pluginHandler( $plugin, 'reorder', $verbose );
			if ( $plugin == 'sysm' ) $this->_pluginHandler( $plugin, 'reorder', $verbose );
			
			// Return true if not verbose else return text
			return (! $verbose ? true : JText::sprintf( 'INSTALL_PLG_REINSTALL_SUCCESS', $plg['element'] ) );
			break;
			
		case 'reorder' :
			
			// Init
			$cond	= array();
			$name	= (! $isLegacy ? 'extension' : 'plugin' );
			
			// Grab the Joomla Table Handler
			$table = & JTable :: getInstance( "{$name}" );
			
			// First set a bogus order value
			$table->load( $result['id'] );
			$table->ordering = 100;
			$table->store();
			
			if (! $isLegacy ) {
				$cond[0]	= 'type = '. $db->Quote($table->type);
				$cond[1]	= 'folder = '. $db->Quote($table->folder);
			}
			else {
				$cond[0]	= 'type = '. $db->Quote( $result['id'] );
				$cond[1]	= 'folder = '.$db->Quote($table->folder).' AND ordering > -10000 AND ordering < 10000 AND client_id = ' . (int) $table->client_id;
			}
			
			$table->load( $cond[0]);
			$table->reorder( $cond[1] );
			
			// Now set the correct order value
			$table->load( $result['id'] );
			$table->ordering = 0;
			$table->store();
			
			$table->load( $cond[0]);
			$table->reorder( $cond[1] );
			
			// Return true if not verbose else return text
			return (! $verbose ? true : JText::sprintf( 'INSTALL_PLG_REORDER_SUCCESS', $plg['element'] ) );
			
			break;
		endswitch;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_menuHandler (private)
	 * Purpose:		Takes care of all menu handling for installer
	 * As of:		version 2.0.2 (March 2010)
	\* ------------------------------------------------------------ */
	private function _menuHandler($name, $task = 'typeexists', $item = null, $verbose = true)
	{
		// Initialize variables
		$db			= & JFactory::getDBO();
		$menu		= $this->mtypes[$name];
		$isLegacy	=   version_compare( JVERSION, '1.6.0', 'ge' ) ? false : true;
		
		// If no item sent we can't declare mitem
		if ( $item != null )
			$mitem	= $this->mitems[$name][$item];
		
		// Switch off on tasks
		switch ($task):
		
		// Check if the menu type exists
		case 'typeexists':
			
			// Query to see if the menu type exists
			$query = sprintf("SELECT `id` FROM `#__menu_types` WHERE `menutype` = '%s'", $menu['menutype']);
			$db->setQuery($query);
			$result = $db->loadResult();
			
			// If not verbose then send back false or id
			if (!$verbose) return $result;
			
			// Build text response based on result
			$does = ( $result ? '' : 'not ' );
			return JText::sprintf( 'INSTALL_MENU_TYPE_EXIST', $menu['title'], $does );
			break;
			
		// Add the menu type to the database
		case 'typeadd':
			
			// Check to see if the menu type doesn't exist
			if (! $this->_menuHandler($name, 'typeexists', null, false)) {
				
				// Query to add menu type to database
				$query = "INSERT INTO `#__menu_types` (`menutype`, `title`, `description`) VALUES ".
							"('".$menu['menutype']."', '".$menu['title']."', '".$menu['desc']."')";
				$db->setQuery($query);
				$result = $db->query();
				
				// If not verbose then send back result
				if (! $verbose) return $result;
				
				// Build text response based on result
				$was = ( $result ? '' : 'not ' );
				return JText::sprintf( 'INSTALL_MENU_TYPE_ADD', $menu['title'], $was );
			}
			// Menu type does exist
			else {
				
				// If not verbose send back false else send back text
				return (! $verbose ? false : JText::sprintf( 'INSTALL_MENU_TYPE_EXIST', $menu['title'], '') );
			}
			break;
			
		// Check if the menu item exists already
		case 'itemexists':
			
			// Query for the menu item
			$query = sprintf("SELECT `id` FROM `#__menu` WHERE `menutype` = '%s' AND `alias` = '%s'", $menu['menutype'], $mitem[1]);
			$db->setQuery($query);
			$result = $db->loadResult();
			
			// If not verbose then send back result
			if (! $verbose) return $result;
			
			// Build text response based on result
			$does = ( $result ? 'already exists' : 'does not exist' );
			return JText::sprintf( 'INSTALL_MENU_ITEM_EXIST', $mitem[0], $menu['title'], $does);
			break;
			
		// Add the menu item to the database
		case 'itemadd':
			
			// Chceck to make sure the menu item doesn't already exist
			if (! $this->_menuHandler($name, 'itemexists', $item, false)) {
				
				if ( $isLegacy ) {
					// Query to add menu item to the database
					$query	= "INSERT INTO `#__menu` (`menutype`, `name`, `alias`, `link`, `type`, `published`, `componentid`, `ordering`, `params`) VALUES
					('".$menu['menutype']."', '{$mitem[0]}', '{$mitem[1]}', '{$mitem[2]}', '{$mitem[3]}', '{$mitem[4]}', '{$mitem[5]}', '{$mitem[6]}', '{$mitem[7]}')";
					$db->setQuery($query);
					$result	= $db->query();
				}
				else {
					$table	= & JTable::getInstance( "Menu", "JTable", array() );
					$data	= $this->_menuHandler( $name, 'compiledata', $item, $verbose );
					$table->bind( $data );
					$table->check();
					$result = $table->store();
					
					$query = "UPDATE `#__menu` SET `parent_id` = '1', `level` = '1' WHERE `id` = '{$table->get( "id" )}'";
					$db->setQuery( $query );
					$db->query();
				}
				
				// If not verbose then send back result
				if (! $verbose) return $result;
				
				// Build response based on result
				$was = ( $result ? '' : 'not ' );
				return JText::sprintf( 'INSTALL_MENU_ITEM_ADD', $mitem[0], $menu['title'], $was );
			}
			// The menu item exists already
			else {
				
				// If not verbose then send back false else send back text
				return (! $verbose ? false : JText::sprintf( 'INSTALL_MENU_ITEM_EXIST', $mitem[0], $menu['title'], 'already exists' ) );
			}
			break;
			
		// Add multiple items to the database
		//		Note that only a verbose response is possible
		case 'itemsadd':
			
			// Cycle through each menu item
			foreach ($this->mitems[$name] as $k => $v ){
				
				// Build response array
				$return[] = $this->_menuHandler($name, 'itemadd', $k );
			}
			
			// Send back response
			return $return;
			break;
		case 'compiledata':
			$data = array();
			$data['menutype']		= $menu['menutype'];
			$data['title']			= $mitem[0];
			$data['alias']			= $mitem[1];
			$data['link']			= $mitem[2];
			$data['type']			= $mitem[3];
			$data['published']		= $mitem[4];
			$data['ordering']		= $mitem[6];
			$data['component_id']	= $this->comid;
			$data['params']			= array( "menu-anchor_title" => "", "menu-anchor_css" => "", "menu_image" => "", "menu_text" => 1 );
			$data['level']			= "1";
			$data['access']			= "1";
			$data['language']		= "*";
			return $data;
			break;
		endswitch;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_setToArray (private)
	 * Purpose:		Sets an array forcing all to lowercase
	 * As of:		version 2.0.2 (March 2010)
	\* ------------------------------------------------------------ */
	private function _setToArray($settings)
	{
		foreach ($settings as $v) {
			$ret[strtolower($v['setting'])] = $v['value'];
		}
		return $ret;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_comId (private)
	 * Purpose:		Retrieves the id for the component
	 * As of:		version 2.0.2 (March 2010)
	\* ------------------------------------------------------------ */
	private function _comId()
	{
		$db =& JFactory::getDBO();
		
		// Find the installed instance of com_jwhmcs and pull the id for storage
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$query	= 'SELECT `extension_id` FROM #__extensions WHERE `element`="com_jwhmcs" AND `type`="component"';
		}
		else {
			$query	= 'SELECT `id` FROM #__components WHERE `option`="com_jwhmcs"';
		}
		
		$db->setQuery($query);
		return $db->loadResult();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getApiConnection (private)
	 * Purpose:		Checks the Connection to the API
	 * As of:		version 2.0.2 (March 2010)
	\* ------------------------------------------------------------ */
	private function _getApiConnection()
	{
		$jcurl = & JwhmcsCurl::getInstance();
		
		$jcurl->setAction('getclientsdata', array('clientid' => 1));
		$data	= $jcurl->loadResults();
		
		if (is_array($data[0])) $data = $data[0];
		
		if ($jcurl->info['http_code'] != '200') {
			$ret['valid'] = false;
			$ret['message'][] = "Error connecting to API";
		}
		elseif ( $data['result'] == 'success' ) {
			$ret['valid'] = true;
			$ret['message'][] = 'API Successfully connected!';
		}
		else {
			if ($data['message'] == 'Client Not Found' || $data['message'] == 'Client ID Not Found') {
				$ret['valid'] = true;
				$ret['message'][] = 'API Successfully connected!';
			}
			elseif (empty($data)) {
				$ret['valid'] = false;
				$ret['message'][] = $jcurl->info['http_code'].' received with URL';
			}
			else {
				$ret['valid'] = false;
				$ret['message'][] = $data['message'];
			}
			
		}
		
		return $ret;
	}
}