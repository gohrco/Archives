<?php
/**
 * Group Management Controller for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: sync.php 469 2012-05-04 20:04:56Z steven_gohigher $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );


/**
 * JWHCMS Sync Controller
 * @author		Steven
 * @version		2.4.2
 *
 * @since		1.5.1
 */
class JwhmcsControllerSync extends JwhmcsController
{
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		2.4.2
	 * 
	 * @since		1.5.1
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Task to requery the WHMCS API for the current info and restore it
	 * @access		public
	 * @version		2.4.2
	 *
	 * @since		1.5.1
	 */
	public function requery()
	{
		$model	= $this->getModel( 'sync' );
		$post	= JwhmcsHelper :: get( 'cid', array(0), 'post', 'array' );
		$model->requery($post);
		
		$msg = JText::_( "COM_JWHMCS_SYNC_CTRL_REQUERY" );
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=sync', $msg );
	}
	
	
	/**
	 * Task to empty and reload the user table
	 * @access		public
	 * @version		2.4.2
	 *
	 * @since		1.5.1
	 */
	public function reload()
	{
		$model	= $this->getModel( 'sync' );
		$model->reload();
		
		$msg = JText::_( "COM_JWHMCS_SYNC_CTRL_REBUILD" );
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=sync', $msg );
	}
	
	
	/**
	 * Task to search empty WHMCS ID positions for missing data
	 * @access		public
	 * @version		2.4.2
	 *
	 * @since		1.5.1
	 */
	public function refresh()
	{
		$model	= $this->getModel( 'sync' );
		$model->refresh();
		
		$msg = JText::_( "COM_JWHMCS_SYNC_CTRL_REFRESH" );
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=sync', $msg );
	}
}