<?php
/**
 * Default Controller for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: default.php 469 2012-05-04 20:04:56Z steven_gohigher $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );


/**
 * JwhmcsControllerDefault class is the default task handler for the admin area
 * @version		2.4.8
 *
 * @since		1.5.0
 * @author		Steven
 */
class JwhmcsControllerDefault extends JwhmcsController
{
	
	/**
	 * Constructor task
	 * @access		public
	 * @version		2.4.8
	 * 
	 * @since		1.5.1
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Task to redirect to the license checker
	 * @access		public
	 * @version		2.4.8
	 * 
	 * @since		2.0.0
	 */
	public function license()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=install&task=license', null );
	}
	
	
	/**
	 * Task to redirect to the api cnxn handler
	 * @access		public
	 * @version		2.4.8
	 * 
	 * @since		2.0.0
	 */
	public function apiconxn()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=install&task=apiconxn', null );
	}
	
	
	/**
	 * Task to redirect to the configuration handler
	 * @access		public
	 * @version		2.4.8
	 * 
	 * @since		2.0.0
	 */
	public function config()
	{
		$this->setRedirect( 'index.php?option=com_jwhmcs&controller=config', null );
	}
}