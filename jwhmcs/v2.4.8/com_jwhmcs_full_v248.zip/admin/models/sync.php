<?php
/**
 * Group Management Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: sync.php 469 2012-05-04 20:04:56Z steven_gohigher $
 * @since      1.5.1
 */

// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model
include_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'classes'.DS.'class.curl.php');


/**
 * Used to handle sync requests from the view and controller of J!WHMCS Integrator
 * @version		2.4.8
 *
 * @author		Steven
 * @since		1.5.1
 */
class JwhmcsModelSync extends JwhmcsModel
{
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		2.4.8
	 * 
	 * @since		1.5.1
	 */
	public function __construct()
	{
		parent::__construct();
		
		$app	= & JFactory::getApplication();
		
		// Get pagination request variables
		$limit			= $app->getUserStateFromRequest('global.list.limit', 'limit', $app->getCfg('list_limit'), 'int');
		$limitstart		= $app->getUserStateFromRequest('com_jwhmcs.limitstart', 'limitstart', 0, 'int');
		$search			= $app->getUserStateFromRequest('articleelement.search',				'search',			'',	'string');
		$search			= JString::strtolower($search);
		
		// In case limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
		$this->setState('search', $search);
		
		$array = JwhmcsHelper :: get('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
	}
	
	
	/**
	 * Retrieves the data from the database
	 * @access		public
	 * @version		2.4.8
	 * @param		string		- $task: the current task
	 * 
	 * @return		object containing data
	 * @since		1.5.1
	 */
	public function getData($task = null)
	{
		// Initialization
		$app	= & JFactory::getApplication();
		$db		= & JFactory::getDBO();
		$uri	= & JURI::getInstance();
		
		$filter_order		= $app->getUserStateFromRequest( "com_jwhmcs.filter_order",		'filter_order',		'a.name',	'cmd' );
		$filter_order_Dir	= $app->getUserStateFromRequest( "com_jwhmcs.filter_order_Dir",	'filter_order_Dir',	'',			'word' );
		$filter_type		= $app->getUserStateFromRequest( "com_jwhmcs.filter_type",		'filter_type', 		0,			'string' );
		$search				= $app->getUserStateFromRequest( "com_jwhmcs.search",			'search', 			'',			'string' );
		$search				= JString::strtolower( $search );
		
		$limit				= $app->getUserStateFromRequest( 'global.list.limit', 'limit', $app->getCfg('list_limit'), 'int' );
		$limitstart			= $app->getUserStateFromRequest( 'com_jwhmcs.limitstart', 'limitstart', 0, 'int' );
		
		// 1:  Switch on task
		switch ($task):
		default:
			$query	= " ( SELECT SQL_CALC_FOUND_ROWS '1' AS 'type', w.* FROM #__jwhmcs_user AS w ) 
						UNION ALL
						( SELECT '5' AS 'type', c.* FROM #__jwhmcs_usersub AS c ) ORDER BY lname";
						
			$db->setQuery($query, $limitstart, $limit);
			$items	= $db->loadObjectList();
			
			// Fetch Pagination
			$db->setQuery('SELECT FOUND_ROWS();');
			jimport('joomla.html.pagination');
			$pagination = new JPagination($db->loadResult(), $this->getState('limitstart'), $this->getState('limit') );
			
			$data->items		= $items;
			$data->pagination	= $pagination;
		endswitch;
		
		return $data;
	}
	
	
	/**
	 * Method to requery the WHMCS API
	 * @access		public
	 * @version		2.4.8
	 * @version		2.0.0		- December 2009: added JwhmcsCurl usage / dropped _wCurl function
	 *
	 * @since		1.5.1
	 */
	public function requery($cid)
	{
		// 0:  Initialize Variables
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$cnt	=   0;
		$cot	=   0;
		
		// 1:  For each cid, pull current WHMCS user data
		foreach ($cid as $id)
		{
			$tmp = explode(",", $id);
			switch ($tmp[1]):
			case '1':
				$jcurl->setAction('getclientsdata', array('clientid' => $tmp[0]));
				$acct[$cnt] = $jcurl->loadResult();
				$cnt++;
				break;
			case '5':
				$jcurl->setAction('jwhmcsgetcontact', array('get' => 'id='.$tmp[0]));
				$sub[$cot] = $jcurl->loadResult();
				$cot++;
				break;
			endswitch;
		}
		
		$qmain = "UPDATE %1\$s SET fname=%2\$s, lname=%3\$s, cname=%4\$s, email=%5\$s, address1=%6\$s, address2=%7\$s, city=%8\$s, state=%9\$s, postal=%10\$s, country=%11\$s, phonenumber=%12\$s WHERE id=%13\$d";
		
		if (count($acct) > 0) {
			foreach ($acct as $item) {
				if ($item['result'] == 'success') {
					$query = sprintf($qmain, '#__jwhmcs_user', $db->Quote($item['firstname']), $db->Quote($item['lastname']), $db->Quote($item['companyname']), $db->Quote($item['email']), $db->Quote($item['address1']), $db->Quote($item['address2']), $db->Quote($item['city']),$db->Quote($item['state']), $db->Quote($item['postcode']), $db->Quote($item['country']), $db->Quote($item['phonenumber']), $item['id']);
				}
				else {
					$query = 'DELETE FROM #__jwhmcs_user WHERE id='.$item['id'];
				}
				$db->setQuery($query);
				$db->query();
			}
		}
		
		if (count($sub)>0) {
			foreach ($sub as $item) {
				if ($item['result'] == 'success') {
					$query = sprintf($qmain, '#__jwhmcs_usersub', $db->Quote($item['firstname']), $db->Quote($item['lastname']), $db->Quote($item['companyname']), $db->Quote($item['email']), $db->Quote($item['address1']), $db->Quote($item['address2']), $db->Quote($item['city']),$db->Quote($item['state']), $db->Quote($item['postcode']), $db->Quote($item['country']), $db->Quote($item['phonenumber']), $item['id']);
				}
				else {
					$query = 'DELETE FROM #__jwhcms_usersub WHERE id='.$item['id'];
				}
				$db->setQuery($query);
				$db->query();
			}
		}
		return;
	}
	
	
	/**
	 * Reloads the WHMCS user info from WHMCS directly
	 * @access		public
	 * @version		2.4.8
	 * @version		2.1.0		- April 2010: modified parameters to reflect database change
	 * @version		2.0.0		- December 2009: replaced _wCurl with JwhmcsCurl
	 *
	 * @return		boolean
	 * @since		1.5.1
	 */
	public function reload()
	{
		// 0:  Initialize Variables
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		$data	=   array();
		$act	=   array();
		$sub	=   array();
		
		// 1:  Empty current jwhmcs_user table
		$query	= 'TRUNCATE TABLE #__jwhmcs_user';
		$db->setQuery($query);
		$db->query();
		
		$query	= 'TRUNCATE TABLE #__jwhmcs_usersub';
		$db->setQuery($query);
		$db->query();
		
		// 2:  Retrieve information from root file
		$jcurl->setAction('jwhmcssync', array('task' => 'get' ) );
		$jcurl->setParse( false );
		
		$data	=   $jcurl->loadResults();
		$data	=   my_xml2array($data);
		$data	=   $data[0];
		$jcurl	= & JwhmcsCurl::getInstance( true );
		$client	=   array();
		
		unset( $data['name'], $data['attributes'] );
		
		for ($i=0; $i < count( $data ); $i++ )
		{
			if ( $data[$i]['name'] == 'result' ) {
				if ( $data[$i]['value'] == "error" ) {
					return true;
					break;
				}
				else {
					continue;
				}
			}
			unset( $data[$i]['name'] );
			for ($j=0; $j < count( $data[$i] ); $j++)
			{
				$client[$i][$data[$i][$j]['name']] = ( isset( $data[$i][$j]['value'] ) ? $data[$i][$j]['value'] : null );
			}
		}
		
		// 3:  Store gathered data
		$query_useract	= 'INSERT INTO #__jwhmcs_user (`id`, `fname`, `lname`, `cname`, `email`, `address1`, `address2`, `city`, `state`, `postal`, `country`, `phonenumber`) VALUES ';
		$query_usersub	= 'INSERT INTO #__jwhmcs_usersub (`id`, `fname`, `lname`, `cname`, `email`, `address1`, `address2`, `city`, `state`, `postal`, `country`, `phonenumber`) VALUES ';
		
		// 4:  Build Query
		foreach ( $client as $item )
		{
			$qitem = ' ('	
						.$db->Quote( $item['id'] ) . ', '
						.$db->Quote( $item['firstname'] ) . ', '
						.$db->Quote( $item['lastname'] ) . ', '
						.$db->Quote( $item['companyname'] ) . ', '
						.$db->Quote( $item['email']) . ', '
						.$db->Quote( $item['address1'] ) . ', '
						.$db->Quote( $item['address2'] ) . ', '
						.$db->Quote( $item['city'] ) . ', '
						.$db->Quote( $item['state'] ) . ', '
						.$db->Quote( $item['postcode'] ) . ', '
						.$db->Quote( $item['country'] ) . ', '
						.$db->Quote( $item['phonenumber'] ) . ')';
			if ( $item['type'] == '1' ) {
				$act[] = $qitem;
			}
			elseif ( $item['type'] == '5' ) {
				$sub[] = $qitem;
			}
		}
				
		if ( count($act) > 0 ) {
			$queryt = $query_useract.implode(',', $act);
			$db->setQuery($queryt);
			$db->query();
		}
		if ( count( $sub) > 0 ) {
			$queryt = $query_usersub.implode(',', $sub);
			$db->setQuery($queryt);
			$db->query();
		}
		unset ($sub, $act, $qitem, $queryt);
		
		$this->_timeStamp();
		
		$jcurl = JwhmcsCurl::getInstance( true );
		// 5:  Return
		return true;
	}
	
	
	/**
	 * Method to find missing users and add them into the database
	 * @access		public
	 * @version		2.4.8
	 * @version		2.1.0		- April 2010: modified parameters to reflect database usage
	 * @version		2.0.0		- December 2009: replaced _wCurl with JwhmcsCurl usage
	 *
	 * @return		boolean
	 * @since		1.5.3
	 */
	public function refresh ()
	{
		// 0:  Initialize variables
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		$chkids = array();
		$data	= array();
		
		// 1:  Select current ids from jwhmcs_user table
		$query	= 'SELECT id FROM #__jwhmcs_user ORDER BY id DESC';
		$db->setQuery($query);
		$curids	= $db->loadResultArray();
		
		$maxid = $curids[0] + 20;
		
		// 2:  Assemble array of potential ids to check
		for ($i=1; $i<=$maxid; $i++) {
			$chkids[$i] = true;
		}
		
		// 3:  Set each id that already exists to false
		foreach ($curids as $curid) {
			$chkids[$curid] = false;
		}
		
		// 4:  One by one, pull user data from WHMCS
		for($i=1; $i<=$maxid; $i++):
			
			if ($chkids[$i]===false)
			{
				continue;
			}
			
			$jcurl->setAction('getclientsdata', array('clientid' => $i));
			$whmcs	= $jcurl->loadResult();
			
			if ($whmcs['result']=='success')
			{
				$data[]	= $whmcs;
				if ($i>$maxid)
					$maxid = $i;		// Reset maximum to new highest
			}
		endfor;
		
		// 5:  Store gathered data
		if (count($data) > 0) {
			$query	= 'REPLACE INTO #__jwhmcs_user (`id`, `fname`, `lname`, `cname`, `email`, `address1`, `address2`, `city`, `state`, `postal`, `country`, `phonenumber`) VALUES '; 
			foreach ($data as $item):
				$q[]	= ' ('	.$db->Quote($item['userid']).', '
								.$db->Quote($item['firstname']).', '
								.$db->Quote($item['lastname']).', '
								.$db->Quote($item['companyname']).', '
								.$db->Quote($item['email']).', '
								.$db->Quote($item['address1']).', '
								.$db->Quote($item['address2']).', '
								.$db->Quote($item['city']).', '
								.$db->Quote($item['state']).', '
								.$db->Quote($item['postcode']).', '
								.$db->Quote($item['country']).', '
								.$db->Quote($item['phonenumber']).')';
			endforeach;
			$query	= $query.implode(',', $q);
			$db->setQuery($query);
			$db->query();
		}
		
		$this->_timeStamp();
		
		// 7:  Return
		return true;
	}
	
	
	/* ----------------------------------------- *\
	 *              SUB FUNCTIONS                *
	\* ----------------------------------------- */
	
	
	/**
	 * Method to create a timestamp for the last sync report
	 * @access		private
	 * @version		2.4.8
	 * @version		2.1.0		- April 2010: modified parameters to reflect database change
	 * 
	 * @since		2.0.3
	 */
	private function _timeStamp()
	{
		$params	= & JwhmcsParams::getInstance();
		
		$date = & JFactory::getDate();
		$params->set( 'LastSync', $date->toUnix(), true, 'user' );
		return;
	}
}


function my_xml2array($__url)
{
    $xml_values = array();
    $contents = $__url;
    $parser = xml_parser_create('');
    if(!$parser)
        return false;

    xml_parser_set_option($parser, XML_OPTION_TARGET_ENCODING, 'UTF-8');
    xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
    xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
    xml_parse_into_struct($parser, trim($contents), $xml_values);
    xml_parser_free($parser);
    if (!$xml_values)
        return array();
   
    $xml_array = array();
    $last_tag_ar =& $xml_array;
    $parents = array();
    $last_counter_in_tag = array(1=>0);
    foreach ($xml_values as $data)
    {
        switch($data['type'])
        {
            case 'open':
                $last_counter_in_tag[$data['level']+1] = 0;
                $new_tag = array('name' => $data['tag']);
                if(isset($data['attributes']))
                    $new_tag['attributes'] = $data['attributes'];
                if(isset($data['value']) && trim($data['value']))
                    $new_tag['value'] = trim($data['value']);
                $last_tag_ar[$last_counter_in_tag[$data['level']]] = $new_tag;
                $parents[$data['level']] =& $last_tag_ar;
                $last_tag_ar =& $last_tag_ar[$last_counter_in_tag[$data['level']]++];
                break;
            case 'complete':
                $new_tag = array('name' => $data['tag']);
                if(isset($data['attributes']))
                    $new_tag['attributes'] = $data['attributes'];
                if(isset($data['value']) && trim($data['value']))
                    $new_tag['value'] = trim($data['value']);

                $last_count = count($last_tag_ar)-1;
                $last_tag_ar[$last_counter_in_tag[$data['level']]++] = $new_tag;
                break;
            case 'close':
                $last_tag_ar =& $parents[$data['level']];
                break;
            default:
                break;
        };
    }
    return $xml_array;
} 