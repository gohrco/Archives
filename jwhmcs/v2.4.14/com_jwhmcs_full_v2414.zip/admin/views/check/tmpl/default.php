<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_( 'behavior.mootools' );
jimport('joomla.html.pane');

$pane =& JPane::getInstance('tabs');

$data = $this->data;

echo $pane->startPane( 'tabs' );
echo $pane->startPanel( JText::_( "COM_JWHMCS_CHECK_VIEW_TAB_JOOMLA" ), 'joomla_check' );
?>
<table class="checkStarttbl toolbar">
	<tr>
		<td class="checkStartimg button">
			<a class="button" href="#" onclick="beginCheck(10,30,this); return false;" id="joomla_check_href1">
			<span class="checkStarttxt icon-48-checkrun"><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_BEGINCHECK" ); ?></span></a>
		</td>
	</tr>
</table>

<table class="admintable">
	<tbody>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_COMPONENTINSTALLED" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep10"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage10">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_HIDDENMENU" ); ?>
			</td>
			<td width="50px">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep20"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage20">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_CLIENTMENU" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep30"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage30">&nbsp;</div>
			</td>
		</tr>
	</tbody>
</table>

<?php 
echo $pane->endPanel();
echo $pane->startPanel( JText::_( "COM_JWHMCS_CHECK_VIEW_TAB_PLUGIN" ), 'plugin_check' );
?>
<table class="checkStarttbl toolbar">
	<tr>
		<td class="checkStartimg button">
			<a class="button" href="#" onclick="beginCheck(100,130,this); return false;" id="plugin_check_href1">
			<span class="checkStarttxt icon-48-checkrun"><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_BEGINCHECK" ); ?></span></a>
		</td>
	</tr>
</table>

<table class="admintable">
	<tbody>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_PLUGINAUTH" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep100"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage100">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_PLUGINSYSM" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep110"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage110">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_PLUGINLANG" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep120"></div></div>
			</td>
			<td>
				<div class="ajaxMessage" id="checkMessage120">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_PLUGINUSER" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep130"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage130">&nbsp;</div>
			</td>
		</tr>
	</tbody>
</table>

<?php
echo $pane->endPanel();
echo $pane->startPanel( JText::_( "COM_JWHMCS_CHECK_VIEW_TAB_WHMCS" ), 'whmcs_check' );
?>
<table class="checkStarttbl toolbar">
	<tr>
		<td class="checkStartimg button">
			<a class="button" href="#" onclick="beginCheck(200,220,this); return false;" id="whmcs_check_href1">
			<span class="checkStarttxt icon-48-checkrun"><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_BEGINCHECK" ); ?></span></a>
		</td>
	</tr>
</table>
<table class="admintable">
	<tbody>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_WHMCSROOT" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep200"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage200">&nbsp;</div>
			</td>
		</tr><!-- 
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_WHMCSHOOK" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep210"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage210">&nbsp;</div>
			</td>
		</tr> -->
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_WHMCSAPI" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep210"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage210">&nbsp;</div>
			</td>
		</tr><!-- 
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_WHMCSTMPL" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep230"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage230">&nbsp;</div>
			</td>
		</tr> -->
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_WHMCSDB" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep220"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage220">&nbsp;</div>
			</td>
		</tr>
	</tbody>
</table>
<?php
echo $pane->endPanel();
echo $pane->startPanel( JText::_( "COM_JWHMCS_CHECK_VIEW_TAB_PRODUCT" ), 'product_check' );
?>
<table class="checkStarttbl toolbar">
	<tr>
		<td class="checkStartimg button">
			<a href="#" onclick="beginCheck(300,310,this); return false;" id="product_check_href1">
			<span class="checkStarttxt icon-48-checkrun"><?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_BEGINCHECK" ); ?></span></a>
		</td>
	</tr>
</table>
<table class="admintable">
	<tbody>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_PRODLIC" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep300"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage300">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				<?php echo JText::_( "COM_JWHMCS_CHECK_VIEW_TEXT_APICNXN" ); ?>
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep310"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage310">&nbsp;</div>
			</td>
		</tr>
		
	</tbody>
</table>
<?php
echo $pane->endPanel();
echo $pane->endPane();
?>


<form action="index.php" method="post" name="adminForm" id="adminForm">
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="thisUrl" id="thisUrl" value="<?php echo $data->thisUrl; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="controller" value="check" />
<input type="hidden" name="step" id="step" value="10" />
<input type="hidden" name="laststep" id="laststep" value="" />
</form>