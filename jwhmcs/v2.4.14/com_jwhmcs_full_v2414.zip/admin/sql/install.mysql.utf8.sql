CREATE TABLE IF NOT EXISTS `#__jwhmcs_config` (
	`type` INT(10) NOT NULL DEFAULT '1',
	`key` VARCHAR(100) NOT NULL,
	`value` TEXT NOT NULL,
	`field` INT(10) NOT NULL DEFAULT '1',
	`order` INT(10) NOT NULL DEFAULT '10',
	PRIMARY KEY (`key`)
) ENGINE = MyISAM CHARACTER SET `utf8`;


CREATE TABLE IF NOT EXISTS `#__jwhmcs_group` (
	`id` INT(10) NOT NULL AUTO_INCREMENT,
	`fname` TEXT NULL,
	`lname` TEXT NULL,
	`cname` TEXT NULL,
	`email` TEXT NOT NULL,
	`password` TEXT NULL,
	PRIMARY KEY (`id`)
) ENGINE = MyISAM CHARACTER SET `utf8`;


CREATE TABLE IF NOT EXISTS `#__jwhmcs_sess` (
	`token` VARCHAR(255) NOT NULL,
	`value` TEXT NOT NULL,
	`uid` INT(10) NOT NULL,
	`uem` VARCHAR(255) NOT NULL,
	`upw` VARCHAR(255) NOT NULL
) ENGINE = MyISAM CHARACTER SET `utf8`;


CREATE TABLE IF NOT EXISTS `#__jwhmcs_user` (
	`id` INT(10) NOT NULL AUTO_INCREMENT,
	`fname` TEXT NULL,
	`lname` TEXT NULL,
	`cname` TEXT NULL,
	`email` TEXT NOT NULL,
	`address1` TEXT NULL,
	`address2` TEXT NULL,
	`city` TEXT NULL,
	`state` TEXT NULL,
	`postal` TEXT NULL,
	`country` TEXT NULL,
	`phonenumber` TEXT NULL,
	PRIMARY KEY (`id`)
) ENGINE = MyISAM CHARACTER SET `utf8`;


CREATE TABLE IF NOT EXISTS `#__jwhmcs_usersub` (
	`id` INT(10) NOT NULL AUTO_INCREMENT,
	`fname` TEXT NULL,
	`lname` TEXT NULL,
	`cname` TEXT NULL,
	`email` TEXT NOT NULL,
	`address1` TEXT NULL,
	`address2` TEXT NULL,
	`city` TEXT NULL,
	`state` TEXT NULL,
	`postal` TEXT NULL,
	`country` TEXT NULL,
	`phonenumber` TEXT NULL,
	PRIMARY KEY (`id`)
) ENGINE = MyISAM CHARACTER SET `utf8`;


CREATE TABLE IF NOT EXISTS `#__jwhmcs_xref` (
	`xref_a` INT( 10 ) NOT NULL ,
	`xref_type` ENUM('1','2','3','4', '5', '6', '7', '8', '9') NOT NULL DEFAULT '1',
	`xref_b` INT( 10 ) NOT NULL
) ENGINE = MyISAM CHARACTER SET `utf8`;