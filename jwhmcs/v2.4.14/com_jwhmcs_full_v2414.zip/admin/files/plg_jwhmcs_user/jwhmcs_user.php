<?php
/**
 * J!WHMCS Integrator - User Plugin
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * @version    $Id: jwhmcs_user.php 605 2012-11-09 16:44:30Z steven_gohigher $
 * @since      1.5.0
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.router' );
jimport( 'joomla.environment.uri' );
jimport( 'joomla.plugin.plugin' );

$path	= JPATH_ADMINISTRATOR . '/components/com_jwhmcs/jwhmcs.helper.php';
if ( file_exists( $path ) ) require_once( $path );


/**
 * User - JWHMCS plugin
 * @version		2.4.14
 *
 * @since		1.5.0
 * @author		Steven
 */
class plgUserJwhmcs_user extends JPlugin
{
	/**
	 * Stores if we need to revert a setting for changing the lock downs
	 * @access		public
	 * @since		2.2.0 (?)
	 * @var			boolean
	 */
	public $changeLock	= false;	// New with WHMCS 4.3 - lockable fields
	
	
	/**
	 * Indicates the user plugin should redirect
	 * @access		public
	 * @since		2.4.12
	 * @var			boolean
	 */
	public $redirect	= true;
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		2.4.14
	 * @param		unknown_type	$subject
	 * @param		unknown_type	$config
	 * 
	 * @since		1.5.0
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		
		if ( version_compare( JVERSION, '1.6.0', 'ge' ) ) {
			$this->loadLanguage();
		}
		
	}
	
	
	/**
	 * Event triggered prior to saving a user
	 * @access		public
	 * @version		2.4.14
	 * @param		object		$user
	 * @param		boolean		$isnew
	 * 
	 * @since		2.2.0 (?)
	 */
	public function onUserBeforeSave( $user, $isnew )
	{
		if (! class_exists('JwhmcsParams') )	return;
		if ( defined( 'JWHMCS_AUTH' ) )			return;	// This must be coming from our own authentication plugin - don't try to add it back to WHMCS (loop)
		if ( defined( 'COMMUNITY_COM_PATH' ) )	return;	// Jom Social work around
		
		// Integrator / Belong catch all
		if ( defined( 'INTLOGIN' ) ) return;
		
		// If we can't load the helper then bail
		if (! class_exists( 'JwhmcsHelper' ) ) return;
		
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		if ((! $params->get( 'UserEnable' )) || (! $params->get( 'Enable' )))
			return;	// Don't run if product or user integration disabled
		
		if ( $isnew )
			return;	// Nothing to do if this is new
		
		if (! $params->get( 'WchangeLockables' ) )
			return; // We aren't allowed to change the lockable fields
		
		$jcurl->setAction( 'jwhmcsgetsettings', array( "get" => "ClientsProfileUneditableFields" ) );
		$whmcs	= $jcurl->loadResult();
		
		if ( $whmcs['result'] != 'success' )
			return; // Either a problem with api or WHMCS version not applicable
		
		$this->changeLock = $whmcs['clientsprofileuneditablefields'];
		
		$jcurl->setAction( 'jwhmcsgetsettings', array( "set" => "ClientsProfileUneditableFields=" ) );
		$whmcs = $jcurl->loadResult();
		
		if ( $whmcs['result'] != 'success' )
			$this->changeLock = false;
		
		return;
	}
	
	
	/**
	 * Event triggered after a user is stored in Joomla!
	 * @access		public
	 * @version		2.4.14
	 * @version		2.1.0	- Modified paramters to reflect database change (April 2010)
	 * @version		2.0.2	- Corrected company name not being passed to add client (Feb 2010)
	 * @version		1.5.3	- Check for password being reset by user added (Oct 2009)
	 * @version		1.5.1	- Encrypt passwords for user edits - WHMCS<4.1 bug (Sep 2009)
	 * @param		unknown_type	$user
	 * @param		boolean			$isnew
	 * @param		boolean			$succes
	 * @param		JErrorObject	$msg
	 * 
	 * @since		1.5.0
	 */
	public function onUserAfterSave($user, $isnew, $succes, $msg)
	{
		if (! class_exists('JwhmcsParams') ) return;
		if ( defined( 'JWHMCS_AUTH' ) ) return;	// This must be coming from our own authentication plugin - don't try to add it back to WHMCS (loop)
		if ( defined( 'COMMUNITY_COM_PATH' ) ) return;	// Jom Social work around
		
		// Integrator / Belong catch all
		if ( defined( 'INTLOGIN' ) ) return;
		
		// If we can't load the helper then bail
		if (! class_exists( 'JwhmcsHelper' ) ) return;
		
		$app	= & JFactory::getApplication();
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		if ((! $params->get( 'UserEnable' )) || (! $params->get( 'Enable' )))
			return;	// Don't run if product or user integration disabled
		
		// Check if the user is new - if so then addclient function
		if ($isnew):
			$action	= 'addclient';
			if (JwhmcsHelper :: get( 'usedata' )):
				$company = (JwhmcsHelper :: get('company') ? JwhmcsHelper :: get('company') : JwhmcsHelper :: get('companyname'));
				$fields['firstname']	= JwhmcsHelper :: get( 'firstname' );
				$fields['lastname']		= JwhmcsHelper :: get( 'lastname' );
				$fields['companyname']	= $company;
				$fields['address1']		= JwhmcsHelper :: get( 'address1' );
				$fields['address2']		= JwhmcsHelper :: get( 'address2' );
				$fields['city']			= JwhmcsHelper :: get( 'city' );
				$fields['state']		= JwhmcsHelper :: get( 'state' );
				$fields['postcode']		= JwhmcsHelper :: get( 'postcode' );
				$fields['country']		= JwhmcsHelper :: get( 'country' );
				$fields['phonenumber']	= JwhmcsHelper :: get( 'phonenumber' );
				$fields['currency']		= '1';
			else:
				$name = explode(' ', $user['name']);
				if (count($name)< 2) $name[1] = $name[0]; 
				$fields['firstname']	= $name[0];
				$fields['lastname']		= $name[1];
				$fields['address1']		= $params->get( 'WuserDefaultaddress' );
				$fields['city']			= $params->get( 'WuserDefaultcity' );
				$fields['state']		= $params->get( 'WuserDefaultstate' );
				$fields['postcode']		= $params->get( 'WuserDefaultpostal' );
				$fields['country']		= $params->get( 'WuserDefaultcountry' );
				$fields['phonenumber']	= $params->get( 'WuserDefaultphone' );
				$fields['currency']		= '1';
			endif;
			$fields['email']		= $user['email'];
			$fields['password2']	= JwhmcsHelper :: get( 'password' );
		else:
			
			// Retrieve existing whmcsid from xref db based on user_id
			$query = 'SELECT `xref_b` as `clientid`, `xref_type` FROM #__jwhmcs_xref '
						.'WHERE xref_a='.$user['id'].' AND xref_type BETWEEN 1 AND 9';
			$db->setQuery($query);
			$result = $db->loadAssoc();
			
			if (!$result)
				return;
			
			$type	= $this->_getType( $result['xref_type'] );
			$wuser	= JwhmcsHelper::getWhmcsUser( $result['clientid'], 'id', $type );
			$passwd	= $this->_getPassword( $wuser, $type );
			
			if (! $wuser )
				return;	// No user found to update
			
			switch ( $type ):
			case 'client':
				
				// Create the fields array for retrieving existing WHMCS user
				$action					= 'updateclient';
				$fields['clientid']		= $result['clientid'];
				$fields['email']		= $user['email'];
				if ( $passwd )
					$fields['password2']= $passwd;
				
				$fields['jwhmcs']		= 1;
				
				if ($app->isAdmin())
					$fields['status']	= (JwhmcsHelper :: get( 'block' )==1?'Inactive':'Active');
				
				break;
			case 'contact':
				$action = 'jwhmcsgetcontact';
				$newPw	= $passwd ? ";password={$passwd}" : "";
				
				$status	= '';
				if ( $app->isAdmin() )
					$status	= ";subaccount=" . ( JwhmcsHelper :: get( 'block' ) == 1 ? 0 : 1 );
					
				$fields['set']			= "id={$wuser['id']};email={$user['email']}" . $newPw . $status;
				
				break;
			endswitch;
		endif;
		
		// Pass function and parameters to cURL getting back the whmcs_id
		$jcurl->setAction($action, $fields);
		$whmcs	= $jcurl->loadResult();
		
		if ($isnew):
			// Store this new id w/ the user id in the xref db
			$query = 'INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) '
						.'VALUES ('.$user['id'].', 1, '.$whmcs['clientid'].')';
			$db->setQuery($query);
			$db->query();
		else:
			
			// WHMCS 4.3 - if lockable fields set, reset them here
			if ( $this->changeLock !== false ) {
				$jcurl->setAction( 'jwhmcsgetsettings', array( "set" => "ClientsProfileUneditableFields={$this->changeLock}" ) );
				$lockresults = $jcurl->loadResult();
			}
			
			if ($app->isAdmin())
				return;		// Don't redirect to WHMCS if Administrator
			
			// ===========================================
			// Community Builder stores user twice, second
			// appears as an edit - if we dont redirect dont
			// ===========================================
			if (! $this->redirect )
				return;
			
			if ( JwhmcsHelper :: checkRoute( 'pwreset' ) ) return; // We dont want to redirect if we are resetting password
			
			$store = array( "clientid"	=> $whmcs["clientid"],
							"email"		=> $fields["email"],
							"password"	=> $fields["password2"],
							'timestamp'	=> $this->_get_timestamp()
							);
			
			// Store data for next jump
			$token = JwhmcsHelper::storeSession( $store );
			
			// Create URL for redirecting to WHMCS for loggin in
			$uri = & JURI::getInstance($params->get( 'ApiUrl' ));
			$uri->setScheme( 'http' . ( $params->get( 'RedirGatewayssl' ) ? 's' : '' ) );
			$uri->setPath( $uri->getPath() . '/jwhmcs.php' );
			$uri->setVar( 'task', 'ulogin' );
			$uri->setVar( 'a', $token );
			$uri->setVar( 'jwhmcs', '1' );
			$url = $uri->toString();
			$app->redirect($url);
		endif;
		
		
		// ===========================================
		// If new Joomla user with activation req'd
		// we do not want to redirect to WHMCS
		// ===========================================
		if ( $isnew && ( $params->get( 'RegMethod' ) == 2 ) ) {
			$usersConfig	= & JComponentHelper::getParams( 'com_users' );
			$useractivation	= (int) $usersConfig->get( "useractivation" );
			if ( $useractivation !== 0 ) $this->redirect = false;
		}
	}

	
	/**
	 * Event triggered prior to deletion of a user in Joomla!
	 * @access		public
	 * @version		2.4.14
	 * @param		JUser Object	$user
	 * 
	 * @since		1.5.0
	 */
	public function onUserBeforeDelete($user)
	{
		// If we can't load the helper then bail
		if (! class_exists( 'JwhmcsHelper' ) ) return;
	}
	
	
	/**
	 * Event triggered after deletion of a user in Joomla!
	 * @access		public
	 * @version		2.4.14
	 * @param		unknown_type	$user
	 * @param		boolean			$succes
	 * @param		JErrorObject	$msg
	 * 
	 * @since		1.5.0
	 */
	public function onUserAfterDelete($user, $succes, $msg)
	{
		// If we can't load the helper then bail
		if (! class_exists( 'JwhmcsHelper' ) ) return;
	}

	
	/**
	 * Event triggered at user login
	 * @access		public
	 * @version		2.4.14
	 * @version		2.1.0	- Modified parameters to reflect database change (Apr 2010)
	 * @param		array		- $user: contains the user array
	 * @param		array		- $options: contains options
	 * 
	 * @since		1.5.0
	 */
	public function onUserLogin($user, $options)
	{
		// 0:  Initialize variables
		if (! class_exists('JwhmcsParams') ) return;
		$db		= & JFactory::getDBO();
		$params	= & JwhmcsParams::getInstance();
		$app	= & JFactory::getApplication();
		$field	=   array();
		
		// If we can't load the helper then bail
		if (! class_exists( 'JwhmcsHelper' ) ) return;
		
		// Integrator / Belong catch all
		if ( defined( 'INTLOGIN' ) ) return;
		
		if ($app->isAdmin())
			return; // Dont run in admin
		
		if ((! $params->get( 'UserEnable' )) || (! $params->get( 'Enable' )) || (! $this->redirect ) )
			return;	// Don't run if product or user integration disabled
		
		if ( $user['type'] != 'jwhmcs_auth' )
			return; // Something else authenticated, so we dont have a clear password to send to WHMCS
		
		// Check to make sure user can login to WHMCS
		if ( $this->_checkLogin($user) !== true )
			return;
		
		// 2:  Store variables to database and get token back from function
		$juri = & JURI::getInstance();
		
		$field['email']		= $user['email'];
		$field['password']	= $user['password'];
		if ($goto = JwhmcsHelper :: get( 'goto' )) $field['goto'] = $goto;
		
		$jwhmcstask = JwhmcsHelper :: get( 'jwhmcstask' );
		if ( trim ($jwhmcstask) == '' ) $jwhmcstask = 'ulogin';
		
		$field['remember']	= ( isset( $options['remember'] ) && $options['remember'] ? 'on' : '' );
		$field['return']	= $this->_getReturn($options);
		$field['timestamp'] = $this->_get_timestamp();
		
		$token = JwhmcsHelper::storeSession($field);
		
		$uri = & JURI::getInstance($params->get( 'ApiUrl' ), true);
		$uri->setScheme( 'http' . ( $params->get( 'RedirGatewayssl' ) ? 's' : '' ) );
		$uri->setPath( $uri->getPath() . '/jwhmcs.php' );
		$uri->setVar( 'task', $jwhmcstask );
		$uri->setVar( 'a', $token );
		$uri->setVar( 'jwhmcs', '1' );
		
		// 3:  Create URL for redirecting to WHMCS for loggin in
		$url = $uri->toString();
		
		/**
		 * Application->Login handles the cookie when remember me checked
		 * In J! 2.5 we are setting the redirect url to the controller and returning
		 * In J! 1.5 we are creating the cookie and redirecting ourselves (ugly) 
		 */
		if ( version_compare( JVERSION, '1.6.0', 'l' ) ) {
			if ( isset( $options['remember'] ) && $options['remember'] ) {
				jimport('joomla.utilities.simplecrypt');
				jimport('joomla.utilities.utility');
			
				// Create the encryption key, apply extra hardening using the user agent string
				$agent = @$_SERVER['HTTP_USER_AGENT'];
				// Ignore empty and crackish user agents
				if ($agent != '' && $agent != 'JLOGIN_REMEMBER') {
					$key = JUtility::getHash($agent);
					$crypt = new JSimpleCrypt($key);
					$rcookie = $crypt->encrypt(serialize(array( 'username' => $user['username'], 'password' => $user['password_clear'] ) ) );
					$lifetime = time() + 365*24*60*60;
					setcookie( JUtility::getHash('JLOGIN_REMEMBER'), $rcookie, $lifetime, '/' );
				}
			}
		}
		
		return JwhmcsHelper :: redirect( $url );
	}

	
	/**
	 * Event triggered on user logout
	 * @access		public
	 * @version		2.4.14
	 * @version		2.1.0	- Modified parameters to reflect database change (Apr 2010)
	 * @param		array		- $user: logged out user array
	 * 
	 * @since		1.5.0
	 */
	public function onUserLogout( $user )
	{
		if (! class_exists('JwhmcsParams') ) return;
		$params	= & JwhmcsParams::getInstance();
		$app	= & JFactory::getApplication();
		
		// If we can't load the helper then bail
		if (! class_exists( 'JwhmcsHelper' ) ) return;
		
		// Integrator / Belong catch all
		if ( defined( 'INTLOGIN' ) ) return;
		
		if ($app->isAdmin())
			return; // Dont run in admin
		
		if ((! $params->get( 'UserEnable' )) || (! $params->get( 'Enable' )))
			return;	// Don't run if product or user integration disabled
		
		// Since we are the last user plugin to run before redirection kill cookie
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			setcookie( JApplication::getHash( 'JLOGIN_REMEMBER' ), false, time() - 86400, '/' );
		}
		else {
			setcookie( JUtility::getHash('JLOGIN_REMEMBER'), false, time() - 86400, '/' );
		}
		
		// Create URL for redirecting to WHMCS for loggin out
		$uri = & JURI::getInstance($params->get( 'ApiUrl' ));
		$uri->setScheme( 'http' . ( $params->get( 'RedirGatewayssl' ) ? 's' : '' ) );
		$uri->setPath( $uri->getPath() . '/jwhmcs.php' );
		$uri->setVar( 'task', 'ulogout' );
		$uri->setVar( 'jwhmcsout', '1' );
		$url = $uri->toString();	// 'http'.($params->get( 'RedirGatewayssl' )?'s':'').'://'.$params->get( 'ApiUrl' ).'/logout.php?goto=jwhmcs';
		$app->redirect($url);
	}
	
	
	/**
	 * Checks the login to see if we need to do more things prior to sending to WHMCS
	 * @access		private
	 * @version		2.4.14
	 * @param		array		- $user: contains the user
	 * 
	 * @return		boolean
	 * @since		1.5.1
	 */
	private function _checkLogin(&$user)
	{
		// 0:  Initialize variables
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		// 1:  Set query to pull xref table to check type
		$query = 'SELECT `xref_a` as `joomlaid`, `xref_type` as `type`, `xref_b` as `clientid` FROM #__jwhmcs_xref AS x INNER JOIN #__users AS a ON x.xref_a = a.id '
					.'WHERE a.username ="'.$user['username'].'" AND xref_type BETWEEN 1 AND 9';
		$db->setQuery($query);
		$result = $db->loadAssoc();
		
		// 2:  Test for types, failing if none found
		if (!$result)	// User isn't matched to anyone in WHMCS don't bother logging in
			return false;
		
		$type	= $this->_getType( $result['type'] );
		
		switch ($result['type']):
		case 1:			// Everything is ok - user already matched up
		case 5:			// Subaccount user is matched without issue
			return true;
			break;
		case 2:			// User was matched up by Admin, change pw in WHMCS
		case 3:			// User account added by admin in Joomla, change pw in WHMCS
		case 6:			// Subaccount was matched up by Admin, change pw in WHMCS
		case 7:			// Subaccount was added by admin in Joomla, change pw in WHMCS (used?)
			// Retrieve matching data from WHMCS
			$whmcs	= JwhmcsHelper::getWhmcsUser( $user['email'], 'email', $type );
			$whmcs['xref_type']	= ( $type == 'client' ? 2 : 6 );
			
			// Test password in WHMCS first
			$testpw	= $this->_testWhmcsPassword($whmcs['password'], $user['password']);
			
			// If correct we will update xref
			if ($testpw) {
				$return = true;
			}
			// Password is incorrect, so can we resync it?
			elseif ($params->get( 'WuserAutosync')) {
				$change = $this->_changeWhmcsPassword($whmcs['id'], $user['password'], $whmcs['xref_type']);
			
				// Negative result on change
				if (! $change)
					return false;
			}
			// Password is incorrect and we can't resync it
			else {
				return false;
			}
			
			$query	= "UPDATE `#__jwhmcs_xref` SET `xref_type` = ".( $whmcs['xref_type'] == 2 ? "1" : "5" )." WHERE xref_a = {$result['joomlaid']} AND xref_b = {$result['clientid']}";
			$db->setQuery($query);
			return $db->query();
			
			break;
		case 4:			// User belongs to a group
			$query	= 'SELECT u.`password` as `passwd`, u.`email` as `email` '
						.' FROM #__jwhmcs_group as u '
						.' WHERE u.id = '.$result['clientid'];
			$db->setQuery($query);
			
			if ($result = $db->loadAssoc()) {
				$user['email']		= $result['email'];
				$user['username']	= $result['username'];
				$user['password']	= $result['passwd'];
				$return = true;
			}
			else
				$return = false;
			
			break;
		case 8:
		case 9:
			$uri = & JURI::getInstance();
			$app = & JFactory::getApplication();
			
			// We have to store the password for the next jump
			$token = JwhmcsHelper::storeSession( array( 'password' => $user['password'] ) );
			
			$uri->setVar( 'option',	'com_jwhmcs' );
			$uri->setVar( 'controller',	'changeusername' );
			$uri->setVar( 'view',	'changeusername' );
			$uri->setVar( 'layout',	'default' );
			$uri->setVar( 'task',	'display' );
			$uri->setVar( 'token',	$token );
			if ( JwhmcsHelper :: get( 'jwhmcs' ) ) $uri->setVar( 'jwhmcs', JwhmcsHelper :: get( 'jwhmcs' ) );
			
			$query = $uri->getQuery();
			
			$url = JRoute::_( "index.php?{$query}" );
			
			JwhmcsHelper :: redirect( $url );
			
		endswitch;
		
		// 3:  Return true or false
		if ($return)
			return true;
		
		return false;
	}
	
	
	/**
	 * Method to test the WHMCS password
	 * @access		private
	 * @version		2.4.14
	 * @param		string		- $encoded: the encoded password from WHMCS
	 * @param		string		- $clear: the password to test
	 * 
	 * @return		boolean
	 * @since		2.1.0
	 */
	private function _testWhmcsPassword($encoded, $clear)
	{
		$jcurl	= & JwhmcsCurl::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		if ($params->get( 'WhmcsNomd5' )) {	// We are not using MD5
			$jcurl->setAction('decryptpassword', array('password2' => $encoded));
			$whmcs	= $jcurl->loadResult();
			
			if ($whmcs['result'] == 'success') { 
				$return = ( $whmcs['password'] == $clear ? true : false );
			}
		}
		else {	// We are using MD5 here
			$testpw = JwhmcsHelper::encodePassword( "whmcs", $encoded, $clear );
			$return = ( $testpw == $encoded ? $testpw : false );
		}
		return $return;
	}
	
	
	/**
	 * Retrieves the password
	 * @access		private
	 * @version		2.4.14
	 * @param		array		- $wuser: the whmcs user
	 * @param		string		- $type: indicates which type of user we have
	 * 
	 * @return		string or false on fail
	 * @since		2.1.2
	 */
	private function _getPassword( $wuser, $type )
	{
		$newPassword	= ( ( $pass = JwhmcsHelper :: get( 'password1' ) ) ? $pass : ( $pass = JwhmcsHelper :: get( 'password' ) ) ? $pass : false );
		 
		if ( $newPassword === false ) {
			return false;
		}
		else 
		{
			return $this->_findWhmcsPassword( ($type == 'client' ? $wuser['clientid'] : $wuser['id'] ), $newPassword, $type );
		} 
	}
	
	
	/**
	 * Builds the password for storage in WHMCS
	 * @access		private
	 * @version		2.4.14
	 * @param		integer		- $clientid: the whmcs user id
	 * @param		string		- $password: the clear password
	 * @param		string		- $type: indicates the type of user
	 * 
	 * @return		string
	 * @since		2.1.0
	 */
	private function _findWhmcsPassword($clientid, $password, $type = 'client' )
	{
		$jcurl			= & JwhmcsCurl::getInstance();
		$params			= & JwhmcsParams::getInstance();
		$usepassword	=   $password;
		
		// If WHMCS version 4.1 or higher, return password clear text
		if ( ( str_replace(".", "", $params->get( 'WhmcsVersion' ) ) < 410 ) || $type == 'contact' ) {
			// We must encode the password for WHMCS < 4.1
			switch ( $type ):
			case 'contact':
				$jcurl->setAction( "jwhmcsgetcontact", array( 'get' => "id={$clientid}" ) );
				break;
			case 'client':
				$jcurl->setAction ( "getclientpassword", array( 'userid' => $clientid ) );
				break;
			endswitch;
			
			$whmcs	= $jcurl->loadResult();
			
			// Explode password hash to get salt and resalt new password and return
			$pwexp	= explode(':', $whmcs['password']);
			$usepassword = md5($pwexp[1].$password).':'.$pwexp[1];
		}
		
		return $usepassword;
	}
	
	
	/**
	 * Method to update a WHMCS password
	 * @access		private
	 * @version		2.4.14
	 * @param		integer		- $clientid: whmcs client id
	 * @param		string		- $password: the clear password to set to
	 * @param		integer		- $type: indicates client (2) or subaccount (6)
	 * 
	 * @return		boolean
	 * @since		2.1.0
	 */
	private function _changeWhmcsPassword($clientid, $password, $type = 2)
	{
		$jcurl			= & JwhmcsCurl::getInstance();
		
		$usepassword	=   $this->_findWhmcsPassword($clientid, $password);
		
		// Subaccounts
		if ($type == 6 ) {
			$fields['set']			= "id={$clientid};password=$usepassword";
			$action = 'jwhmcsgetcontact';
		}
		// Regular clients
		else {
			$fields['clientid']		= $clientid;
			$fields['password2']	= $usepassword;
			$action = 'updateclient';
		}
		
		$jcurl->setAction($action, $fields);
		$whmcs	= $jcurl->loadResult();
		
		return ( $whmcs['result']=='success' ? true : false );
	}
	
	
	/**
	 * Retrieves the return value
	 * @access		private
	 * @version		2.4.14
	 * @version		2.4.12		- November 2012: added check for return to ensure a full url
	 * @version		2.0.4		- March 2010: corrected return variable issue
	 * @param		array		- $options: passed options 
	 * 
	 * @return		string either of url or base64 encoded
	 * @since		2.0.2
	 */
	private function _getReturn(&$options)
	{
		$juri	= & JURI::getInstance();
		$params	= & JwhmcsParams::getInstance();
		
		if (JwhmcsHelper :: get( 'whmcs' ) || JwhmcsHelper :: get( 'return' )) {
			//echo base64_decode( JwhmcsHelper :: get( 'return' ) ); die();
			// See if we are dealing with an internal URI and set URL properly
			if ( Juri::isInternal( base64_decode( JwhmcsHelper :: get( 'return' ) ) ) ) {
				$juri	= new JUri ( $params->get( 'JoomlaUrl' ) );
				$ruri	= new Juri ( base64_decode( JwhmcsHelper :: get( 'return' ) ) );
				
				$jpath	= $juri->getPath();
				$rpath	= $ruri->getPath();
				
				// We have to test the path to see if it is absolute or relative
				if ( strpos( $rpath, '/' ) === false ) {
					$juri->setPath( rtrim( $juri->getPath(), '/' ) . '/' . $ruri->getPath() );
				}
				else {
					$juri->setPath( $ruri->getPath() );	
				}
				
				$juri->setQuery( $ruri->getQuery() );
				
				return base64_encode( $juri->toString() );
			}
			else return JwhmcsHelper :: get( 'return' );
		}
		
		return base64_encode( $params->get( 'RedirLoginurl' ) );
	}
	
	
	/**
	 * Retrieve the type of user based on the xref type
	 * @access		private
	 * @version		2.4.14
	 * @param		integer		- $xref_type: the xref type from the database for the user
	 * 
	 * @return		string containing type or false if unknown
	 * @since		2.0.0
	 */
	private function _getType( $xref_type )
	{
		$check	= array(	'client'	=> array( 1, 2, 3, 8 ),
							'contact'	=> array( 5, 6, 7, 9 ),
							'group'		=> array( 4 )
		);
		
		foreach ( $check as $type => $xrefs ) {
			if ( in_array( $xref_type, $xrefs ) ) return $type;
		}
		
		return false;
	}
	
	
	/**
	 * Single location to retrieve a timestamp
	 * @access		private
	 * @version		2.4.14
	 * 
	 * @return		integer containing timestamp
	 * @since		2.3.6
	 */
	private function _get_timestamp()
	{
		$ts		= null;
		$otz	= date_default_timezone_get();
		date_default_timezone_set( 'UTC' );
		$ts		= strtotime(gmdate("M d Y H:i:s", time())) + 30;
		date_default_timezone_set($otz);
		return $ts;
	}
	
	
	/**
	 * onBeforeStoreUser - Joomla 1.5 compatibility
	 * @access		public
	 * @version		2.4.14
	 *
	 * @since		2.4.0
	 */
	public function onBeforeStoreUser( $user, $isnew, $newuser = array() ) {
		$result = $this->onUserBeforeSave( $user, $isnew, $newuser );
		return $result;
	}
	
	
	/**
	 * onAfterStoreUser - Joomla 1.5 compatibility
	 * @access		public
	 * @version		2.4.14
	 *
	 * @since		2.4.0
	 */
	public function onAfterStoreUser( $user, $isnew, $success, $msg ) {
		$result = $this->onUserAfterSave( $user, $isnew, $success, $msg );
		return $result;
	}
	
	
	/**
	 * onLoginUser - Joomla 1.5 compatibility
	 * @access		public
	 * @version		2.4.14
	 *
	 * @since		2.4.0
	 */
	public function onLoginUser( $user, $options ) {
		$result = $this->onUserLogin( $user, $options );
		return $result;
	}
	
	
	/**
	 * onLogoutUser - Joomla 1.5 compatibility
	 * @access		public
	 * @version		2.4.14
	 *
	 * @since		2.4.0
	 */
	public function onLogoutUser( $user, $options = array() ) {
		$result = $this->onUserLogout( $user, $options );
		return $result;
	}
	
	
	/**
	 * onAfterDeleteUser - Joomla 1.5 compatibility
	 * @access		public
	 * @version		2.4.14
	 *
	 * @since		2.4.0
	 */
	public function onBeforeDeleteUser( $user, $succes = null, $msg = null ) {
		$result = $this->onUserBeforeDelete( $user );
		return $result;
	}
	
	
	/**
	 * onAfterDeleteUser - Joomla 1.5 compatibility
	 * @access		public
	 * @version		2.4.14
	 *
	 * @since		2.4.0
	 */
	public function onAfterDeleteUser( $user, $succes, $msg ) {
		$result = $this->onUserAfterDelete( $user, $succes, $msg );
		return $result;
	}
	
	
	/**
	 * Event called when gathering update sites to check for updates
	 * @access		public
	 * @version		2.4.14
	 *
	 * @return		array
	 * @since		2.4.0
	 */
	public function getUpdateSite()
	{
		return array(
				'extensionName'				=> 'plg_jwhmcs_user',
				'options' => array(
						'extensionTitle'	=> 'J!WHMCS Integrator User Plugin',
						'storage'			=> 'database',
						'storagePath'		=> null,
						'extensionType'		=> 'plugin',
						'updateUrl'			=> 'https://www.gohigheris.com/updates/jwhmcs/plugins/user'
				)
		);
	}
}