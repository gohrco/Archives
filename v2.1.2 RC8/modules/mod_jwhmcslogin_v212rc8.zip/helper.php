<?php
/**
 * @package		J!WHMCS Integrator:  Login Module
 * @copyright	Copyright (C) 2010 Go Higher Information Services
 * @license		GNU General Public License version 2, or later
 * @version		$Id$
 * @since		2.0.0
 */


class modJwhmcsloginHelper
{
    
	function __construct()
	{
		parent::__construct();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	getData
	 * Purpose:		Retrieves the data for logged in users 
	 * As of:		version 2.0 (January 2010)
	\* ------------------------------------------------------------ */
	function getData( & $params, & $jparams, $status, $contact = false )
	{
		$jcurl	= JwhmcsCurl::getInstance();
		if ( $contact )
		{
			$jcurl->setAction( 'jwhmcsgetcontact', array("get" => "id={$status}" ) );
		}
		else
		{
			$jcurl->setAction('getclientsdata', array('clientid' => $status));
		}
		$whmcs	= $jcurl->loadResult();
		$tmp	= self::getCommon( $params, $jparams, $status );
		foreach ($tmp as $k => $v) $whmcs[$k] = $v;
		return (object) $whmcs;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	getCommon
	 * Purpose:		Retrieves common variables for module 
	 * As of:		version 2.0 (January 2010)
	 * 
	 * Significant Revisions
	 *  2.1.0 (Apr 2010)
	 *  	* Modified parameter retrieval for form action
	\* ------------------------------------------------------------ */
	function getCommon( & $params, & $cparams, $status )
	{
		$uri = & JURI::getInstance( $cparams->get( 'ApiUrl' ));
		$uri->setScheme( 'http' . (JRequest::getVar( 'usessl' ) ? 's' : '' ) );
		
		$return->scheme		= $uri->getScheme().'://';
		$return->whmcsurl	= $uri->toString();
		$return->return		= self::getReturnURL( $params, ($status ? 'RenderLoggedout' : 'RenderLoggedin' ));
		if (!$return->return) unset($return->return);
		
		return $return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	getReturnURL
	 * Purpose:		creates the return url for the form 
	 * As of:		version 2.0 (January 2010)
	\* ------------------------------------------------------------ */
	function getReturnURL($params, $type)
	{
		$uri = & JURI::getInstance();
		$curOption = JRequest::getVar('option');
		$curView = JRequest::getVar('view');
		
		if($itemid =  $params->get($type)) {
			$menu =& JSite::getMenu();
			$item = $menu->getItem($itemid);
			$url = JRoute::_($item->link.'&Itemid='.$itemid, false);
		}
		else {
			if (($curOption == 'com_jwhmcs') && ($curView == 'default')) return false;
			
			if (! $params->get( "redirectsuccess" ) )
				$url = JRoute::_($uri->toString());
			else
				$url = JRoute::_($params->get( "redirectsuccess" ) );
		}
		
		return base64_encode($url);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	isLoggedin
	 * Purpose:		Check the status of the current user 
	 * As of:		version 2.0 (January 2010)
	\* ------------------------------------------------------------ */
	function isLoggedin( & $params )
	{
		// Initialize variables
		$user		= & JFactory::getUser();
		$curOption	= JRequest::getVar('option');
		$curView	= JRequest::getVar('view');
		
		// Check Joomla User object to see if logged in
		if (! $user->guest) {
			$whmcsid = self::getWhmcsId($user->id);
			if ($whmcsid === false) {
				return true;
			}
			else {
				return $whmcsid;
			}
		}
		
		// Check variables for option and view to see if we are rendering site
		if (($curOption == 'com_jwhmcs') && ($curView == 'default')) {
			if ($clientid = JRequest::getVar('clientid'))
			{
				if ( $contactid = JRequest::getVar( 'contactid' ) )
					return $contactid;
				else
					return $clientid;
			}
		}
		return false;
	}
	
	
	function isContact( $userid )
	{
		// An id wasn't sent back by isLoggedin so they can't be a contact
		if ( ( $userid === true ) || ( $userid === false ) )
			return false;
		
		if ( $contactid = JRequest::getVar( 'contactid' ) )
			return true;
		
		$db	= & JFactory::getDBO();
		
		$query	=  "SELECT `xref_type` FROM #__jwhmcs_xref WHERE xref_b = {$userid} AND xref_type IN (5,6,7,9)";
		$db->setQuery( $query );
		
		if (! $result = $db->loadObject() )
			return false;
		else
			return true;
	}
	
	/* ------------------------------------------------------------ *\
	 * Function:	getWhmcsId
	 * Purpose:		Retrieve the WHMCS ID for a Joomla ID 
	 * As of:		version 2.0 (January 2010)
	\* ------------------------------------------------------------ */
	function getWhmcsId( $id )
	{
		// Initialize variables
		$db		= & JFactory::getDBO();
		
		$query	=  "SELECT `xref_a`, `xref_type`, `xref_b`
					FROM #__jwhmcs_xref
					WHERE xref_a= $id AND xref_type BETWEEN 1 AND 7";
		$db->setQuery($query);
		
		if (! $results = $db->loadObject() ) {
			return false;
		}
		
		if ($results->xref_type == '4') {
			$query = "SELECT `email` FROM #__jwhmcs_group WHERE id = ".$results->xref_b;
			$db->setQuery($query);
			$email = $db->loadResult();
			
			$jcurl = JwhmcsCurl::getInstance();
			$jcurl->setAction('getclientsdatabyemail', array('email' => $email));
			$whmcs	= $jcurl->loadResult();
			return $whmcs['userid'];
		}
		elseif ( $results->xref_type > '4' ) {
			$jcurl = JwhmcsCurl::getInstance();
			$jcurl->setAction('jwhmcsgetcontact', array('get' => "id={$results->xref_b}"));
			$whmcs	= $jcurl->loadResult();
			return $whmcs['userid'];
		}
		else {
			return $results->xref_b;
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	getStylesheet
	 * Purpose:		Pulls a custom style sheet or standard sheet 
	 * As of:		version 2.1.0 (April 2010)
	\* ------------------------------------------------------------ */
	function getStylesheet()
	{
		global $mainframe;
		
		// Build the template and base path for the layout
		$tPath	= JPATH_BASE.DS.'templates'.DS.$mainframe->getTemplate().DS.'html'.DS.'mod_jwhmcslogin'.DS;
		$tUrl	= "templates/".$mainframe->getTemplate()."/html/mod_jwhmcslogin/";
		$bUrl	= "modules/mod_jwhmcslogin/tmpl/";
		
		// If the template has a layout override use it
		if (file_exists($tPath)) {
			return $tUrl;
		} else {
			return $bUrl;
		}
	}
}
?>