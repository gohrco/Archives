<?php //00920
/**
 * ---------------------------------------------------------------------
 * In Touch v2.0.6
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 March 14
 * version 2.0.6
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPqGlY4Rm2d5fcPWTPI5REB1ENiR0ZynaIfcidS6eneFsfWZGp5Ja7O6jpcNqUX/5oRm/ART+
X/4XhGkhOnw03cBZn8EM16y0y782x7yt0+3U4zgUHQ/sQ6fUm2sFI5lRIZjak5/eIx8aUQSibyLA
6mVnNhFiWmJPsKRKgNBdfxoOiF11FnUj22YSZG+LDNrPTXNP3Ulk3WcnGdyxNvjgSJNJvD5tvzb1
waGHtUfEtUHABxQX6ghSUpZfFmJ8CxOHfRz1psrtc/HYUqFsw5R0HeT4b1u0OUOz86WrdmWnFcdp
s9YPqbin8rxGwgdmFuBrKq9qO5wbLOZidJG0Bgv9fYwbMOEyEQSmbiGWrVJqkNKb82Qzel8hxHfG
+O6o4VyaD1T2itTJXSkLSPE0C2WpAyPvxzmsDJldnM5p57pNDt/W6jLmcH57gwJlka5UdmdFNily
Hqf7Qcg/pomnEtC8/CSvY8TIK858HgCkIieRqhr0CLwWfxKW5JV5UZ7i1wgUKQdhNF/X2/cRP77F
KNBkjzVBFr6CEaJtZIy/vJjeDGOrWRVLCrdjKWB4a5ph/CSGcdEmQPrGhKni+Sy=