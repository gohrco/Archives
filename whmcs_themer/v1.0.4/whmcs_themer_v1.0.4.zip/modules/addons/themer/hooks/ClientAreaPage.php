<?php //00920
/**
 * ---------------------------------------------------------------------
 * In Touch v2.0.6
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 March 14
 * version 2.0.6
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPut19HglAvvTedUmELaIVsy1CwCZjXtQNUz8O2aAU7Pd47eMDLMEfOI/pd6Uo4TEcbeqJixo
x1ebMca6W+f41JSu3UdBIff1G+1GbWoHVfCtXsScUTJfoPMn+Ksue+E5uqG+xIxf1B6jUmYjPA+J
XBGd7dwxOI8kB/YN0Dxm/KnomCKCGDTz3DFGNsyMlsKno0TSapIgt+FFZWGX4nujETN2q48Q3dfG
WHu6f5ymmXTfR8/SV8P8OtXxEEa/1CWpjX6blq7FRNURQ5iPZNP1aAKnFjRb7d2zvqN95nB4E4iM
rOfXQedrBa7SSFhxLnEm2jh5WvrFLLr9QZZeBW/biG7fZQLAIae06nUp7VL3UU1pz5zWY2VOL+TY
wkIXXzddJmB8UZAezMY6lnMCSHW/hM/YoZK/kiVVM+MTlEM3UCrKGQilX/ZA5k1ZSULR02N4aJsO
pgOhODfmzRiTSEK+cZjsKee0XX3imFsTD0Q07M+Qb0Twckhpm+FHXGwTwMdidaewDF/+m04To5sk
RwgRp4Isrx5QMRUbsdoiQs4b3KazrFZelBreGOO=