<?php //00920
/**
 * ---------------------------------------------------------------------
 * In Touch v2.0.6
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 March 14
 * version 2.0.6
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cP/VP4CidWUdiAWs5w0rkLiNGH9Sws7D2nj8Q1ab32wNXbMmzEO3Ftj3VyOfHKyRp6L3HeA3e
CgidTim6QlTgeiTrAfoG6ffYGbsXyj+5x9Cr4+Vob1yrhlI7o1F+kZwRic/ECRqLhvorun90fgxf
ODGjPUQqOwScsv82+CwRIwoGlr4iGO3t2w1QBKiobZYSZTfJYM9DXfme70JCSRGuNHFyjuY7TWf8
TCO8kVnK3vUhNEqWiVkVZKefUpZfFmJ8CxOHfRz1psrtcnPcZJlzC0B4mwFW4HuOfHr1LsGefeRI
TPzp6sOiQSAIdHVYo6kiuBy3eKwVT9RwKUKwWGh4uZ88uMreRQhPo9IPshW2FWLPwPr1M3uaCwc8
E/89dS5YRU33NilEzsCXXxNbmdoFm4kM1e46VY4C+yE7Fm9S/hJLHW5COy9zx96yf3aTw3ihKY5i
5m6xwLMUv1E50QmBqN2tihnd8eOqcHv9ohf+TpPr2Rruy2WhKStAyoZbri7noDFeNBAM3S42V0rt
FztoFbcelfr6fyUWWuVgs7CZzFJSyPSg6AyOT3w0MkV1WdAzKM8amoIpV2TqRvFqZV+XE3u9qlz+
weuYMvy5Qc7kuwChJtwuEDqvfUk3a+XZ9kIIdNHqHNzNOuc2xYaL4d48A0LQDeL+P8kavi6XbT5r
Ay6NkXxP476CvfyooJRjIUPaAN5E5ItWL84IbI035tpzYB22zdKeHFaKvfig3BSpM57Yd0HfVZIb
2RzOfyKIjtMEAXMjIGp/2nfWanD6neypWaPfeovnCHoKEZ2AathHDS1L1TevofWPE+feEqxVWZtC
LXXDPEqhzeAvvuDguS3O+z7snYIHjPm1294C6RzfCDAsHvovah0FhZamNW3hSa2ey14/zscjXMUA
n0Nm2CKk0IH7KzST5fJjRpEhBqG1lPvvsL7DXYhGQdsXNwbHVgJ0r4PnzxmwvRx5eLk3ey9+oR2b
iAO7Rlcp20KZqpGuKBwZdBavB+6P8Pc5hSeJcWS4GzVnYzwj2fN+x6bwa78D5dQ8GEU4mYk2kyqm
td25W95iysQso+iH2N48M+OkEdAjbA9AGKi5T/2bRUZWnISjoCA2crTmBpBLR2+wRN6Ra7XKGBAj
qaKl4caotov1vOToFVE2N4nWQnnAh6tlOaSeDdF1JayoldqKbmafVLMEocoJonJkLd8/Y9w/2NC4
z+ZhJA6a+GcrnBx+8ztmkezSzbQ7CByj5DeI9eJp9kLyRAjrxoHWGZqwJcc/ZrS3npA2ZXjl1MMA
KcawG2WKlNFmXRcya0kZRl4st8nO1sEXS2kEKJC5O1FWfNmv/zu0iWolT9HlIRJJ4yzV1WeQZHGs
lVaGRIzBb/np7CxjNH3z6oOtlPIHz3BEK7Sh7XoP2lvLhsmdjwlMgHtEEPbrjJVeug8tvrFEcAWT
GuLlA0JlzaxmkvELhXi9dzYi1/OLOTTn4SNFYTFPNztRfnRpkAcnixthcLKbE8v3dpywTl8pYgn/
smLLYzPvnh9GZ0mA4khxV7Eu5P7edifqrBinshhzzBJIomSZlwe9AXdL3QxpuxOBSrGEQpsOQpFo
6PHUHcrSxeKQJHcXB4zI5OuAeteRe5i5knsepqomdBnkovDGE+2BkWEZ3tQ4vwRKWjoxzblflVnm
wfid74xjC1J/wpfnNGCSHhhFqL3EqFcomPwShNWZEEWB4wvcccrDUv//pHfjXCxmzs4+JqEfffhu
3xhFEo+mT0SccoY+u4YGMDp8Fa0eGf6EhbkSUHPBj1dSedBITAVvTMl7CrSlpQm58vQfO5d5UfLN
K/uTsfLs4W3egquAhjPl2mwJrbW8BRGWuX1NkAKjpPKoPb06O32+tUQQJuQcyXikk3e9tLtYjb2l
dipvgZTY1LPaNA83XFKnivCliwvjy1IX0EtdwdFoGCGXqMMenc65uTqaHYEBUOs0TkvxNLZiD9fe
dV6irHoQqVYXxxQsFSiB7ez6CKUBx21ezV60P6jnNdlmZnvoKPVyvI9a1ZFNHAcQDLEUV+lTs2SI
lZQQ2cJNythbqw6cnUtW0F/R0NjTyyi/j9lQYHGu63MNZu/xHG7nxv1QM+nb0+UajF6b/EYEPHXw
sNHuvvqVAww+i1Ql3rRhmoxBteyDqF499MER8udg2Pj/em5co7Exo8Vw1VBVX+rMyI/vJb2S1T/I
Ph/i6kceYejyNYFpJ/xtmaAuaRyT5KJk0rax/WC7P4AbacJMLhBCQnO829tfIb6JEseLPDnHJWLG
JZRXnYgajKxzDOcjNSaLbCywsHFooMAIM/R3OyI+Ktcbnlw8BURT0WFK5eHUQXKrz3wpT95mmtqb
fzgkhafXZSSBFrnPkQXZz7tp0MKa3/ID2klMUc/HNp+IRpdds3jDrDsa+fynpXI+X0kiev4RZlPx
56LtyOMNZla/wjC9nAnqsbqPk51oYMDuVmr4oi9o1c24G3trz+npZSSwjaE0u/iN3AZT5hloaGt8
BAaQsfh6uf5Jg0uKZr/tJx+0WmxfbYDZZnsalhyU0PUAp4OeMdZdxZN4KBulBKj0DwLsp3EqiRY9
fVFoKHxIfmb9cm3ggsaIXKhQSe8C097o/XK95K1VrbxtgsA5W8u1sD4NbZfihSh2Dny8JTpxisfb
+dyI/Hmwwssk/WdteOd17y567CiFetM7mdILplxmb3c3JaCATH/lM+M9Cexgg6pKfv1rCTsp7XQ1
hxzotauEKeqLttxgatJC94liFK5LzMqaHeEL9XU9sN9tS6OPKExI0TjwjqMACWs7EuAo9633iiZ9
v0TebOakHWtR81rwE/VpBrlyf7U2LzvY64QJJN5+3a3vZBRcad868Ur8dz3rY22nA7CrdGGAwu++
QdkVV4DaqnMnDa1AfkTVDPCH887xR36lbwM+JMObW+YcIOA7nM1eLNgEK2D1r9fdW489GO1ItkyN
QUlyJmjFI/TXMyNms0keTfou/qPwaAbF7AbUTFl0GksCB1qgkezYaJ3N4jbiBExLVNUIWK1ULfON
FfM+t0pykM5ymOY6mh6LqX62HIct758GL/ANsAoDbTMn/By2KDb83pqMYlEUkd5yls4bUaZaHbGB
g5CUmMschFmIw2TLgMjGdPEjc93/JvQdScpVCUbeTf5QXWQdXJbP/vSYwqZDZXJLdEz1h0aubbvM
JvMeSjjNoW7s9tPdpFAv6n0kp+OE5QY1myP/6louHX2ATAOJl9YcciOtJtikG8oYQ2CbreafQ+L/
sKxzsOQ5EUkk1Zko8MLJQpRSbCvaK2sre+apUhJR3byh7NCrxD9uNGo1u2gXfPKN//IRFdOt7Dbu
VetkIZ1eEtSQhrPf13aMMLGuI45p1VfzRi5r/imrFpw2r7053SMMMPDzk/3V2G7wXPJYJbjM/NnB
yeYf9j+LUfERR/oXC1B7kMi+4PyW7AXxuQdNmQpD4/XvzKdFcRt3H/EKl4HdTlzWqlA8e+rA2JSH
xbrPaD6mQR2f/zOQ/qyoU16YTfBMOgSVj4+b4lbaFh1ufPD1hFh9ftBF5pB3Kefoqoizi2+fTP/k
tOIs/fUn3sC5wtBuykbWCVNjLzGvRvljmd8fbZThQe7eZxlIQvsnys/25drfVzaL10XNPHBWZzAd
Qx73WmHd9gvYKuex1LdDHDwlruHaKq9DwFJmNqpY5akAfRTBOQIj3/rVQkrBqSpMEl4QuWRRsytZ
nLMNeLiWhrxANG8qesF+UjvfgxSnxzoMvq41SqN/xfHRWpEVTPAs2wCrKiu4OfkaXoVFv8derlaj
f3EL77/+3y+QOs/f/UrBAOiK7PfH/j9srG4RtmFD7HWsxKhskmu+swQwOMIw9Wl1lpL6xLhKCHYx
atbVu8fHSMSrO/GP/bRbkVt/7RWlkW3Xlst84Ga2mNsaVYaukVB4aamaDXK0WFxuiyR5k5f550Jh
w2yN2Ez1rFMKiug2XXPa93TX48JZ2C8XDhoGPTmajqhaEYNIYwbg8MYb4x9Tql3gRCJ1zZQXlybP
JMXhjxgpiSCHNR3NQBNPgDWoX0KOfI/kMm1DTIPB4XoGU/dFlo6wUIC4OIIG9V2Fi9248pNCirzv
RyBp5DbllqmcQour/3YylJXrWVfRm45IQwP/JWQxJ+nKCOHO278hDqdpRq2CjqZPELej1MXEuW/6
S5oL0k1R98YLMVGgL73FMWO7U2cYNm9Ozl+gdKUAG9+zhMuWTlnHawDeZ7KWOEuZCT8OQ5SQmJwT
eKhekmyj0hvPUeR3oPqo0zt+JrMAibQWiO58FJS8muOtJVbotgf/2vl3MJtjnH0qjA4W/2jHANop
6S5EGRJajzceEdsEz1QUz1oCGV4EmEd6zOyVJ3l8ahFlUXW3pgNXFUWRvV9BzeACLykwW5PARdHT
tjeFPC/eAWFQnzAxAZUuvCYVPusdPOyWLOnM7NtNa78167bJxOehexzpgcbrL3wo6xOlPtvuoxRW
HpDn4eI7kP9iy7HjqLoBnUthLKvk8+YYwjwGC/1AGvlsdyM7M+jHq/2sjGyIaAkPmfxeEN2L1vyM
pDsQerEPWKchKJi+T6/0r18ZbkHbZFDEHlp0tbmtOtU/+Mk8Zs0K5dpQ+xZwi3tTBnwNqpi5qVq/
gQEyrK2uLWwea797oRYkag8IK3CgzJ4GDbVFjZNNJ0SeonrWMvU9eMNNzVb36nfuNMNy5y32wJWe
iQIPnuQK4fE0vOOTjQGwst5Xz0ak+eAWIJeF8Ztqp26tSFKE/t6jFnZMlvdgp3XLj2TSRCp+acmN
mU3R0gejn3Bk0jEuBXDdeQj/WAW7bgQEbUVWI9+z5AdOJYaraT31RJFpz+/NB4QMMdkigy1wGMYW
djhKrBmoaWb4VhGw2BzZkOS/jBZyXMpciuLRkHebkGDwq2WHKO8DwmkVM6/HyCalWFXtvGS01qn6
BIcAugZLtx1jE/NLL5s8CvUJjZS1wF2gQmFDUP+3L/+/yuTzxgCsoV0NVH3DzXxK74LO/4gqc2yZ
+1sMaNj8PhgDxQ1s/QhBWCRyOL4WlxavaUtqFwR7q4PvFcI99OPb5nh2ILGgL8QYu4fxWcPBAqB5
9LHdD0PntFHtIGRtAD7M9tmIwzxLx3xm7YhOaa9WtXJ1Zj2gPpjxwEDt/tvz7d6zqPmJAe0QVjep
SnuImmUugbjg5pHoywQd9A2QuWbN5WxnMJyRCDWvx/zFfaZkHujuciOqoaymWBDxi6xfI6/hrF5n
iSPfIFJ/9oJKbRgxHJ7sc/8UnYGjWrO0PsJgh6dYDLubCiNdY9mg7muNXByP1E1zY9ExiO4+T6lC
4QP6H56+QhuS7YVn9kArqr5og7yQQmeJyNxi+bO/ZfiGHjzqwIvhf3i166zQpxwdbr/e9A9Ksx8l
r8l6/ntl44zuuii0x8hYCD1m9EiKjK8eaEzKYzxjkPSz1la5LNF5X0bhnXkx7JJj5V3ToV4JvSxR
ZlhLf51Nk43gJl+vHrh/K12oQTJHMqwxZ6MtstTXvkCiji3FTI1f1Hh0C62wID4FXwga+/LTgfsz
Hn8QraqF6KtADPLym4x/tixWB/jGLgP7i0Ivm/eN1FOVYW+QnTjY38iZGZC3626J4XX6QY2qzikw
APoFvYS/ov7ywEvAiGZ0AjPyKNGuINxQ7Zcic9m+M5iYgVo8NwNi7vasMKQ+BeST/EpD33Pb8CHF
S93IkHoIbw5/m2vQEGMgSJM37v08c2xCyHMk2gjPOL3aWRoM+cCuTqx+5SiZrdLR3g9cx7+Cnc95
wPN6bX8rJztcBpiAYXP5W1aARidR9O1uAPRnP00Zr15GqGIYrz+4OK9aTtWSRRvq6cRSoZBLpRog
ZC/nCPyefJdiPqXNusGKgh+aLWwWYNwTCR24/Nwktwk5vD3l2AoJsoLSf0sa90q8210WB03X3o6d
468m091QjV/CVehzcCmfZzcFxy690XV1Mh/Tb6YkBxzW+L9nwrVaxV6hiV+KOsksb62NHKg6eH6u
Pq36M1D4ksoyOt+wMoA8R0v7Hjk9rT5TehVO3cOVmup2KP9+w/to3sb9hEpvKvZJHaK1djKQ8nso
0f60f6Sf5Nryzw3VZlpDq/bN4roil/B/9UgfiBKzaiQUoPsHcxBl5eykz0t5KhnsV0T4PiVkH+lv
m38aZ+tco9FNG2zpHdDyEmKnVA4mXhl/ju4dAbQsbgctxiBzYqWUUqXPJk7AiE/hGUXANadrpOow
14ilzLakjoeBBo41rb5dLOLXH9OpXrhTqjg4LsJxz+1tyEEjMV3Ydmie61KD5CvNz9wOGSHZuUWz
DHKVinkyrR4HSbWd2yzcdmdtlcORJqHNp3xRF+UHnXw2KroH4SJt74+Gptven4V/YVJBz9IjSXGx
iNwPsn9Q+tq94LjyuZWHbuUMB76ACrIu0mplBSWBOcAhPAA9dnJSLOrrAUVENly7BesSVgzP8Has
lkEsDvsT4g7LpVH0TRn2eIdOE5EjJucqYQHTuto016dXC0FmuctTiJyW2EHYBREPsmG8bkJuSlnS
g/64PJdsL1kmFRDdL8dTtU+v7jf4s8gnErlDK0teT6Z3UR48/ZbA7ITpxQkdkX4HoFTTpKgA48Qk
4RALWmB/dVTPLhijvUv6Jb31g8KL5mQmf6z8k5w6IFTUpPkD5A17Lwrv9f0fFgVFTBVasningJe0
i8+f/wJK6k75re22WTcpakltS9lWzZXR9cXXu7afw3tBL8NtmC+fY6jsTUaN4PW3p0HMMSy0HhHT
suUlA+rL/SIrHkLjAIstJiYXetvyljJk7F74znmBZpy97EUsaO0xd90vECmUf8yINKictDWYeNhb
moa9cSOdgLDCQ/rnn2Fv16KmU8x70bdO0lHkFu60s4TtVySnrc0X6qGM87BEZ2b9EyB31xd1hNHj
m6APQ89BaY+fd5GYeIISkwd+b4fN5xEdSIGoj0CKwrwi6rjsKYInpHEKsiIV6MjMfnWAP6VgFLJf
v9492tG8pP+V2u/VFdJh8BaJ9zrbEdbHWCgimEFjezVcVaAC67u+LscszWGkXoQXY2I1/FdcSrLV
eckVT7KTmfF6b6UVtAd4m2oHcBgpEtT6rr7lI6Owkr1hoo+uQ3byJwgGbkYvimdGdXWYBYJoRZBr
jEFH0n2XRqyPBol9vr8p2oGBaIQ3UNUOnpl09BCtV3hm2o4IXa9ycEbxWfKG2gJ6edYTosjMN+G8
EPvCQIi+0pAiHki+MZ/lwE5uUcYp6Eh64V6k7ayqik/8ZxW9qn+TrMeAKoKvGMu8oKAPbek0S6kF
9OZ7JCNR8e98KAMNfG+MMz6AxypkMzeEWjJKU8JlVr64ZZAWxccSlQHmUtswS5Q8XxoY6b208qo1
FxMyzlNX/wDrPXUV8UWf89SYFiSppyXX5oJ+C4IGil8P9npVFdweA0y92DizO6QlPUNzpFQ18Ula
jtax1pk+mojJVfT4s2Vj0RiHQN91ut/CkBNQMa5d2tNEBizMdxGTQuQ225HibLTpivqQLZYDz/lt
NnIvWkZy8wHv4AqOMbD17O3SJnbIeQYBD58EapX3B33Me4WS9UfPToG0UNXUlzApzIAZEt9W8I1/
pf5nUydzA535LsQKsUR2Rwjua7wZDjD8vgwg45qopxx5IRNpwDZrKVfjT1XKvYFT6hdbMWI2X7uO
7eE01zhf8occKnv2TBMwF+CNixwdoBNqO5HomzTReqDoWRCXL1I7izukERSp7D8LgQFCLey5DSES
NCfNrkq5hLJcKbQaRGIJI4e/zHQybxe/O3g1/ong6XgUVthIR9hxkVZ8148AonvIdd/y9K3AMxUu
thRw1fEtHi6jRE7VSsY3L8C9190gAoZq194+TDR3Y7a6YtRjIAEsH3W7oxzfPNTQwU+TxMxzNJrx
XImnbbKMECh5EAXkCN6I1dcxp8ical8qCODQE8GpaCSwP7+vrVqqWeoSXJCbgX9j2T4HSrkVjUNU
bc+gaOUkJe1umhrJpTOGI9xbhSBkb8/30BJXaDE9ls/P5VFm8vFQm+A/e8sqH0dROh1FXErT12bQ
IqbJZH44JDoupvAIXCUN7RqBNnFXRZhJr5RK8bW2A+xbum0zDQNtkQVsQTPQXQgIuV+Gxt2SbRlc
j7TREJha5VFpdzREz5P9iWBG4qnfTVhw7AFegD/+ukof9TrLcr5TcB5J2NIa8UjI7aeLuPEGK2hW
3vu2HNs4LQaW+l8gbf20uEzWMfldiuqRsGzl2C2raUvc3Ugd9tXLnLbb/+nbRxxEyOigCwUaX2Sc
rz5zK4daJGvnlKXpIHFoviyz8OZ+r5sGx0KQTbyrWE2MP/Hps/BINPgSrCfryWRHZepDotylZlM7
6mK9k5GFnlfWn2Izmz1h//8iEVD22lW0g6FB4QKFL/ltbfhFVxLES5aDKkHLhtIEYTdj1k6MAaBW
cPzFvGlnkuJ2fGugLp3g7lbyUVG8hd4YL7hs1xTCSVnzuL0KmzoESl0uxGQObOcZuOTbrskPlVhC
vX2aZnBnuSjNPObzyPCYvLaQg11qNNaKL7fqrYmENcZrhfbuhkYDcphPk0gDXP76MNb+KBV9VUrl
lhwhxfFHGY+w00HQUJiiCunKDTf6FodaV2Tcrq6bNyOByFdx6TZlnbUa/k++AutBab3I/rTlB1Ok
sY6Ry3VIqNUqYEJEgSaWPOel7xzLJeUFDyCZgmy5zinHOJghC4ThKQggyyINRrHFvI/zVGHxTNsf
gLfGgXROywqPOk+O4G4NNlLGCG/isn3LRTEzsiHceBq6wbCBNsSJeTbjhrqmxvTlCWpKq1Fk7z06
Sr2nqnKIpkn3755Qwdlq5r/OezJxa/WonBrLPYUrFlr6l44C7qliJgBpykxjkd8JOq5A9ZG+9SC9
fWKeQpVf5qLH4tKVofI6Y80XbM/Ho0RDmqik8OWz3V86r+0PHqc4Mx2wlrEuHXgB3AFBUPvMd4Nw
0+nrRhjhkkiKFZ8f1eg6PORS91anV1VgcX6PR9a2EICzen9uAEprnIMSsSMMXDyb1he6aUusEuMQ
2yDxipePgXn/KKcHctnFFuMJXbwd6g9gGdDR+fGUAsJkIR9iNYJHkabepxysGP1LbMaitFsjb85W
6drFPzVaXYoqVhzrK33UQ96bH5nrUWtYxWeJELU1EC8ZK8tT/xZMi6DboTTTRnrLVnMmEF6LsxLc
9Drm0bXiz1emXswENRGfCFwcH107kaZxLOozuOfgvpx3kuEffYYG5dZ9+Om/UWiNjdQm0jdC6Akw
UvJNybANwJcZqD0NMn2ad5919rWP1Fu7xunfTFHxBUQQe3HvuuCfopIyumoQ99Dc8hKZRQit3Ioo
jlOX557sKFkGSpSlUFdO8AJcNSuRnj9ptuEnJg62BB8p53AnFNJYX+FulKuFB9VlKOHRqPoTHd7j
w+WAGGCvjbh4i639wrVXL8RVQf/XyIV5QwtwGIEzYKPZY1bOUFPjUq42Ys0PcB01sVy4Kz0hWKzU
3gXhwkZYogbHCmYnd7KpQ+KFW4YsXSMPAwv2pUS5Lk8c2g4qdYMjHo2Ua8h2iklplvaLqDrovE1d
2a8ZCCpGPSgLtskaGgluLEsJHc3cmIrJZtuzq5/DMlo+gkYj6r3b1Lpk1qAqv0mkB+7y1zhZFbc3
BbW1nNh//UbFxOdUPyBtc5oRJECgXutDDi6+yLpBc8DhIHbIC3xI5IzzRfL/2yMvDDSREHaMJHax
q25PRQA9DQ1EAQtrtjN5ZnoP/NaCPWXpSG0bjTVJU7vhydhuJxYDcWu6erdD1nTJMV4zMSAWOmrk
1xWewKdYctVfJreQ0seoq1ZOrxzWULAdyU2BuIXo9P1ewwZTxAKMX6r2mrruTFuZWiusoWzeQ+P8
opiZE2Ok7mwt8TZa9xjRBgSvcmmcqSeXvftasp0wjGeMGDYIj2y+o9ciZnzkFpbC9NP/f8TpGgKS
cAhpyY6xofPVd5adiaQp2HDdGjLDhDrYE1C76BVQKEUu8DIh8qtnuvBe75Fqrpk5KQVHG0SKtaYn
jt9ua3uDFul7fesGcpTRq/b34nyJjhuTaSP2vbnQS2d1WqpFbWztzrIiiAA+HHAwXU7MEUzxhbaF
smHADw4exLXWPg/VhsXSgig5skV2upOU7oBcAflOiqoVG7bLEoGMbhnfi9kSMI+im61LxxJR/quY
z6O51TvhtfBMjl5kosMWum8uFJIDr4qxzC2nkaqKri/jxt7W3He379WE8FsGGoe++uuHd2a/tOsp
ffpUYaG5gXgAwOLrVi6oK0OkyO2fVofV+OU2nkPxn++LH1GpIVR5PjsejbecpCsv9bPTYwEhHDtE
mIx02msuOqK53e4LEdmmig8H6EwOz5BtXNv/LSJn6HUMFS8Jh6CdOiTdDYfWPcfoe2+G6+7GS1Ls
+0BWQkphbDrWBZ+gzQ1Hzwpp5ijTUCXBC6oRIlO69kp10fdt9xk06LHwGpjD1HC5CKSOsdnsM4Id
dEaxUm==