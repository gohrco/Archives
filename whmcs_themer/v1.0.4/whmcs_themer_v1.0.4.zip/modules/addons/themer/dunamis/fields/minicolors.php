<?php //00920
/**
 * ---------------------------------------------------------------------
 * In Touch v2.0.6
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 March 14
 * version 2.0.6
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPoh0++clWS3EeWrkoatIUxrU6Ah4inAmECv5Y7ziUKsDhHPSOHgcQS/REWx3bxU90P+vae89
2v3FLGTc55QO48jVIhc8ApgB81uh7osHn1BQQbit+qp2pniNZkGc8AV0ZcP9cEsJBJ8LtbrRcIUC
LworrrWhJfpHyZTQ0B+sCdW3bl58HltdAW5faLt7riVO3lhHcC7tMzeMYyocPu/jwkhDjJNTL+vC
13vZOrWnAGXAJJ2S4jfnnNiuwJy4o3Es4QM/GSzjTvkgNvmzYBMAIhFT3kaUk2ld7mYNI988ZjDV
t9ypVYhIdPBi3YGAy7FUKYhKGilk+ItshTcl/KExFkm+kSFS2WPt/jgOg728ZuUUn5U7lE9gf42i
b2cAQWRC2CgweP6G49rbOB2kjDlsnUkuQeINuJyG4TECOOap+pqjalYeUqbeQ9oJ69YU2WmAQa9i
4hqiu/bTjF6N4ptOfKt1vlunEwHJTkEOyPISxkq1gcWJyXYdTEXw0/duc4VXCqjkH35XlEn1SyHP
hPx+7oGv/tF4Mcmo1vF4bobvGzRnIYnla7uCs4eGJvKEOmFqQY1rOB30zFXF4Ghw4W0tD/F/3Sop
ymBsXOnubc40iEkLdLZCHozmCD/+cgEwMFZaBHyBBqeo2aN5YpXVcLFz2b7mUzLf1p4SMiiVhtgF
KzsMJ3xj8RSSKINF49AjrE8AYILBY/X3ptHSJrpXyfVe2cgkrqPNhKaXfEKGnWwXG5I4mBMczwX8
dLrd1PY1ErR7pF8bBLxh67tuctnlH3dsBvT4NUf3qD7qKwWed9zsifzAO/kwOWct9za1BWu3M9nJ
pGfRLZis+U9uQ0kk5IlGR/3lnT+8dPMDQpjRyWqM1XVzZHAf4W5BZeq5u88vulk1R2Rz5q41qmTf
zZMv5AFJbFZcfrrThWPlTTuvjh3RJzRxv3r5tJ2JXMNnLID+Ld5oUdmMOgXu3njzyN9dFObsPrUn
h7yoYJZ/xME70OY9MFAqBONprxVBaeuc2dTCuQfeyYPXt0Krrg/CItgOCUYRQeDC2MMeVtcVhwBT
MsFxx2TVA3Taa/tiCmlsk6ohlIAxocQm8tUTLAuag2LY22IY2KIGFh13k+J2Ute63sgpW8xQ554n
v5WE0k7Qldq7pdg52YTLlVWZKFUcnKUS7sYNPxMfmXLA7iKwRmKZ5pg5hlIJftvy1o7PPW9PoqZC
0F7lX16+6Y8OCRPUXoPBAoU/YA6Zq05eq/ic+4wF4SI+ehDjuw9oqoW+C7qxJuZdBbpOBI4AFdvl
S1djdNBd2rRtPV7/5PiAv5XDaz2mOr2ZxYqXBhmba1o05JvpwSRMtdsET7znxLQU+/5VrEzHuLMA
VpTHfJfrn4E2uhTgczx+NPwOTE++E34axXBcYJPfI1mmdg9cXn/bxvLNJptrQUDDgWRFJZDsj36h
RZF9RhygZl10YBfzheb2eTb9GQUvejQkd8jyjbHyu4E3Vw3e5qySvxuc1I9NmtdPZoWf4L58Ur5R
2RaqsNtOVNR63R3BYOHAQPxe28mduuOTIA4H56kR0yr8oE98T/5pucuJez87jpBhJNBWOPKiujHD
jlOLDEr2jWiG8nYGCzvnQdDgmQBvohHay+R3o8nJnpauaClLOuJocLtzKnswBy8EIz2p/bOCR4yM
mrhjkCfy0uf+QGO0kswqj6aVyGepVcVkPGcFYtyhU2qhEjpql5P94bSVKDvRd0mjXMTabzJTXhcp
HV5ybF556rpwjwhkpmEbVQdLDfKac4wS8Kxa/S7IsB0P7mSVP55XlHmsokZvOBaMts/RbZAJ8UAc
rxKKj6xXa31HEVIu75Cpzt9ty4txNOmidbLyEkrzwjAB63xXIE/Zu+xqTanKaFSzsVYazrs45e0/
UgDFN3JNtgEFVKINDHarWBjKVZJR+gRNLO+shUwjyKZBO9tvsa5XpAS4GxjIxW6enuNMjI/0xoHF
jWi7eNRzatw4kv9/ylNVDH5hkaWMUjALcE+eGY/MBo2VlXGDddg6uTR3Ze6ti4WdFs+U2ptZOF5J
8xmEK/n/DP/Ko7ote/7XWnuEQhI/MvsXl6Bc2b70oWIMVYdd99NE+R+6BIipFSmTsRVsTYswrqLV
ERRgGXiEL3qxTfABQw3NZbfDgxbG3fHp89ueunX9XsRwEQouCnhU2oMTqXSt4lk5aob+Z02RZtNu
4ZJi0GPPbmfGeilDz7xPBOulyfI7L0qwmc31ipcUeNvLRJDeTqgFMYvWZer8V3DJT/ue+yrr5J6W
ls0sm16OQJuOgsKQVr4q9pGLYpVeYbBw3ObamWsCN17fY/5A4lkslprf1fCLXg2/5e7kSqlb3Q90
/2WJ5VdkVbINyYLYIw80186eZLPNJ9INN4GLIw6NjRXObi6NRhXdj+80d1ycdqIF/YWiIYs/TRxa
jL+XL5UlfJy7ecESheHsIfEMECZxTMwB0vanHEpE9nxjAx6lvfpN7Re4SNaNY5PpwHS7QLto2fLm
dO+8YNJ7ypQniG+d+97yqfvrx5rgLnV1llfG76CCHwPWaWNGQfgq1eXJKfPOK6n0FrgwVjuHlyxm
JA5NPXwX8Mj6tgGhbhuYL2JFhiQ+b01PtlbIZKTiEuskmDMWmmbtt/ADaOmaQOXvoTmAqNppOsne
5/w+OSWrZ/MeqPd77ckXZH38azN84eS/zk+Uabvyza2zd3wKsapOFjzxcfzxLmz3L0b5AnZ6fF5Y
1z1uzljKn/6glv6sJG==