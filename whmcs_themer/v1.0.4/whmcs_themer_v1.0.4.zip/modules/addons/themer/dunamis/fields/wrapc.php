<?php //00920
/**
 * ---------------------------------------------------------------------
 * In Touch v2.0.6
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 March 14
 * version 2.0.6
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPmnnqq7lqYTsui16OXAGeTxTD+l9LMxEAOQi86II34LVX0Nnr3R+jB3K9K1NbCdFnrB1JCcT
Tj1LeQcZO8C6N3UfRvoe5HZ5Hkdi3v1cy3+LVK4nIfGXz0BFyZAINdNynV3EmoLGTDNiZ7H9o5C5
rA7ZMdfgJL6oSNJZ93DDPQg2vKHuL/6QIQHzOMGXqkEcFGcsC1NyXg34xUG4vfN2NtX3RLQhP9Yd
vKRdqnY4fgCjVRaXcJOrUpZfFmJ8CxOHfRz1psrtcpLbxBUcXQlWRy+skXv8xUT5/uM9ZH3UCm6J
gEMGCsDsi365RBWFido+Tzlz4SgVXamo4jsAMDZspzFcbXTuOYOv2UThN3yIQuXfX9k6YuyBpUP6
8XfqbOjBxf4P/kVAAiKOeUVcFOCVZfrmY5n/6mAuzUz9+5a03MlsQiQj3+20BaZAsdF4tDfpt+QX
aq/vnwJf2QexWxLBvsXUgp+TXzEkNsCErySE7ZQkV9rvB+sV26IUfduffKqNWdNlH2L++VCZ3TD1
tpNQ1MTXw12DVj8SCpk8zHQHLDa0pSDc/LuUQgMyqCg3xPN99gM4yA9+oUCwPzblG/2fzuJVseoc
7bwbUqt5I/BnKrjPxaQEtF0JTGpKmrm32rS7hYiod9yaJcBPszOAdgWxYDV/cmScov441uT6JsYb
8Cwstdsy7GBcrtKSEjXU2XtghOha59aq0XbQ/RmuAFiRDGVQlDUKBTETPoU0Q4GE9Mteq5B0bPT1
0H2o7YKb+p4TNcFggcIpzk6bbxBYUcQq4upCxQppIg5dy95ENI3SzEbYEPyedkMzTZs2WsTYE00B
zjdU118Y9jLiZA4AJ0FTBQQXWqG35SvXVvCdvTPtJkwOLHrbFRm9+kQEMzCuqvnd186zlkp/V0Pw
diuNPigCm6qgNfKcA/dr3UiHwExIl1pbUqHqxGZlnNPw2VrmTKweIxRZLbDWkSZMVE7/EFy8G3fE
kOINUpRXZLjFnR1q497wNWLnbQJLYNef7BE1xDNL/WJFGJJiRoH308v0hgitdnMLJ6bhC5wacsPy
XIQ+T4JsRM1JAeWRMI0Do2EcZs9gtecvWkvDEBiIp9diDeb7f/fhC0UKjqLK9EHmRj+m2ZHXhW57
GHfsT6G0af1OWJCG7FmT6QrS4YgUxK+1r9aFSMLT5CIGsfMgxrI6wIDx8YUJ4LChep6+DeakNUCt
nIdrArtMM++Qybpcc5aZRYexVKb1AMpaC/ndKQbDAlfmuRGHR6Sj/MGekpE9FlFZ7RSVhJFCPURn
7Du/KBylurUUORuV9TDVuzNOu59OKsu916f560sl+NxvUW==