<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.1.0
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 October 15
 * version 2.1.0
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPvdBiYWdSmSFAXyd2/cjbK66mddENe7XcDgCcRbkAqMGL9My5yEIu8MPpDHMAFCx8yYtQgI1
STv8S9tstgOVBKvtjJEeoJf+ZQEnzewJs2tBlpX/gODxa7Qb3GLrwjmFhHIdtPadpH25ZGHrVtF2
NZwzABpbQYNtKCYF5euLyUbbgg0suErmOADzrQUFJq/qL95+eCAsSRRR6RqPlMijc5o+02l6jyYb
7nzBtT+MckT9E+2PUs01excorSQAGpjhXshsjNYfxQ0WQF75xx7VaVB4+azGVtgp8VymKc7viO1Z
6gutyqJSgRhQTAJpY5zWc00f/DlGivOfzA31FLsNjBBYVowu4EdytJRMwK3MIGmpIvK5KNPoFTQu
1TKEcW4tidaLBeKWdUEiFlDEzJkOYPCU3Sj3LozdOv2iymoYCPK7vKcJhxUb3xbj9AIc+OJztj/b
ABnMlhim5IuYodLB9Vn2e0z16AxGsAAUFUqgBXql9ABLYlDS6Ha56KBKL2fvleOuL3VNcbvGdDOs
T+J49dJ01FoxW9LlJKkiJ7AB+aVaobeXKUCfGvSbRKM8Skjs/xmiJbJojpiovuOTUFKUAQuhnwYS
2jXBZ4X3wMToO8/ymrVZ30dJNiml/mDpy6akdnQh3bTqpPINEm7xRkMFBg4ERszxgblxN1F0AI+E
Jw7xoPl6Zv8x0KRtzb+giGpQYPr2eU0VwMLFgvb+CBakS+65yaaEJG36mQkYH1NObfqrAZG0/0wd
qmUXyPAkZjRzNiMAVtE7pFJhsXpisKpX4SU1PqMwu1C2bpRmhIBCK43yh4SgK8B+QHGCbXeeuw4H
Dcw0lb05ofWEiDjSWRQE71ASrcsNuZDmZGT2nrkbMXTjdEapcBpWU6d/jvj2St7WAY5y8AgI4h2g
RXsvCCz0931nTizSqmJ7SvNDW+nZmyLEa7NBXvCzVNoyrryXlRoNG7ysH3svpYqB8Wbi2YBxqFDQ
Wop1DszgHMXy39XTF/xkGIgsV0I6kljsRTyRpyqQVfDHrqFwcFgj5GEfo1BbJ4p/aDypdqy4Pjns
TVD69n34Xx9bGbBjfrvlJCFzWErGMYKFfHd6y5RLHxRWZClbWkJYN1rLmmHyYJH2afUfvT9NBuX7
wiX3D5XA3e/Q7P2ydwnUUKNRw3Cck5mxW/b9FZw36Prm14MwVOhQd5+sA6Uvax0ukxDaROcbTjXv
r7JwDaTzmROADapg9ojnb/WlykwlDMdavL1yTyxzXx2Fy5N1Iqt4KwRiqDCB7P7s+gdarYHTlncQ
ZBlgqjDjYnmqZRvwhglNE/nCvXFnmwhoIzbvasDoppc4PvoRBmognu2csFyjqGKCKXZ2iFlSoW1p
CV8raTLvRMNVEqAfIkjLqnAUkGgsGwlBUM09GNQ9fso///Nd8JPFTO2vqthGzrPc0dXmG5JMTqF0
i8Ofj/gCO29pIBsQ/Zl+MVbiEPfyy30nE+ism30n/czr4bbrQea7BEU0gaFeDGCZq/ubBDvoOxXe
izFTNtI+PwdPla6vdCNkt0mg01nnLzE+sK1PIFw5uk3uKtGPetpL4vAHgDlSShAN8e04ntDv2r1n
ZAzTHZ3ocmllqBRXtwfJYuv+9MCeBer1SR1M6DP1W5BzYjr46yu7W3irRJ+W/AUFC6biAIl7jKy4
/n4bysUjEvtV7Uc1vlHglzK1uRbtnAsxvhBFIS92mekb834EJAzSdTom+9Tk5YDkx1uLk0hxy42i
b0Iee+aU1s5iuivqV8gJxKP5YYFawk+bsuRBxivQXmzsaaS1p5ttVV1uW1wL8tjXyW39CN0QEgYr
0Re01YbIDzolsN/iTeVfvke7Hm0ScNdMb1Qni9MW/NaKsAewjsNEMMCiDIntWH86cbgiMk9FHaQ1
EtYL/ukpkgiKxkaRgbrn2HfijbaNSBJ0424VU2/F6Zliw/pM/rREAyry02Y8jT3VkuPT2QT9O9wF
vWTRK+dPYW8L3guZcys+gklqVk0uCgr/uAPyx25VBJKwHrYLy5nXLvVhRhPfpcie1dIgw4XvwoA8
pkd0oXK+sVm7NQ1XHXWemUXXaJ+/IUae6TDkdPwdCVua64p6Fhh8SRir8S/jJopJi/DDPeJVgnW0
QyIk94vtgc5TOY61jKUAlRwbNCbeSLRjekLIlgUSXWRwtXhnPUUKYBSbBjUhNPd7jgWtCIUlhpks
Kc3nfM0k3V45ydNvIBOBfgz0t9sCsq6UBcqMvMGM/NN1Au7108yNB0maRU3Ei1CJ4WWHr9GtlCS0
8ZXFEgn6XczR9zn7lmhBUCE+/zbpBifTa+/Cd7Y+NKGgAleoqN+rXvCa55irsg1POBIoDdv+HRoe
KoKTGUzVUIkwKQOvgcFPTi/7n/VXRnVLSlnVolWan3PhTXr6jqQBjy3sYsHjY9ysG+0KcTHu3sUv
R1gyo23YMWPyHsjoIvWDGNQ+hzczVNeEBJYFViuAjb32demP28zUWRYau7xPVhKQYAAaz1MeZYNL
XtxhYnn416G6KagPqZZ7q7qHfbaGCUH5ZUghjmxeCCZYybhc21J9N/eBYvx5FiL9jZ0FrXtvILp+
WvXshVkZ31n87pToPyGXp/bpwf1zWLr0JBqbKKSJqFZBTbgKoC0fWkiS3p1WstX0fR0VW2ofNeNd
Pu0zkFhIQCJ3moe+ofbJ3qrq52DYrv9zqjKiyDJAVBdurL6kIRuaBl5BoLq2EA3PMoYgKSxbtLJ8
Iu3k+W2ZHF7KOyUB3A4etAbHBMi4dDGF7KA010GaHzQiub0Rk46vkX5B6vG4WayxniQrbWSM+eI3
pA/9szOEQgIEoW2J/4DKjs2YHz/XY3xClqvkraoZH130jm4Iy7MyRlAJBKQ7dFy9H6HYol/eTPMO
n/ODqYibiG7F0ikkOutW6m5Rv/nocgkxAkhvDuEJ/B8/lNHRvF8LJcbojrOT5Xb13AsXV74eUQnL
f692rs8xsJwD1mDjsjA2wqs5SICOJulgXs1p6VUTc58RUlWd77nfGOMFYJ/2C4t2003DPhg1nWBx
969LMpeY/s+zQmWYscJeFx6QDLe47i/wqPgaV4bNa0rb2llrQoYuPWN3f2q46tsMzR6XniNgDwck
xXJATmIDbagAUCfTQKZKVjYhrECOfN4Q/rijhXiUvvHQsisma7HqjZ5kWSZIdA5NKo9IvqJ0fp5B
XQrOc5w5VfXd+iegWRgNpO+/XHGAzalb7LEGgKAJ5k6AVP5mYo/yfsaaanqjxSepfrkhjklW0xVm
Ge6pp56r2CoN89DA8cRNRXSZbmz4N8WNBAxWTcYCIxwF5MkIebTR6sIRsZIdXK5cmLTBGqF69ZCu
WRgs5H+v+sVFapI0rWbzZxuojy7CI6q8Hh6C+sLp3QklpSsBAR6ZkPqlan2l95D/57eWlLTZUZjd
03J4KXnJRgl5ZTuxZB1kUk2y4I992oeLZcFltP3zFjVgao3mehe1svsDSut7riY/uQzgQ83KW0mO
jIiAAjgOCO1eS6eUWXFD0qWK/RlOf9B3W7C7YkxEulLp2l/8wlhOsX6KQ24i9kIiINVgaOdCQnze
VtSiaKYaXmJEx36N3TxgzZ8i32GLh+KLp2E7LUXcvJtxdeaXbl0PTFrK62IVNU3vNkulbhXSSXQ3
/s6zSN1+ijvImH1q8CJF+8wLcrIdlViPHksBiiskjwBoK7dr8Lqzyr6vaHqE1cqkwLjdAtwFHzJG
ppOO3ZRZqntFnv2OudmKIrT+W7RSuJrnsRc51iBjAcjehT1q/wISj2D13Pyt9Dlxk1lmshAToz69
oMKei+Ijlz2/eMmj4GPaqsV1GAomSbVErRGF6dUvN0NuEx8KzFuqPS6tUpvK+nSixb5zbPXNor1m
rOksczDscawDaAzspZNLxOHZmCOlufvFJ2VwniympuFcp5AZJarD3xeHiAZZU351p4h7NY3eEOmv
FxwfvehSnTlfzJXPYrVz1c0jCAklBmdo8uOpIaubB2osEoRutI7dAHMg+Qr/Wtt9Ygg2bwJJTEmY
X0q06eRtUdBVNZXIGWJ1J7Dki2OIu7Mw5iGV8CvVYhioPsmWdHh61sOBZaGVXeGet0orJzY8XiaX
tMcuG0hUsZVI5v7wqtO0i6yj6hWnbwfb7TIAeNaSWK71j6nc9dCj/ggVWanjvEQOWQtBIHmQ7J4W
CI/bxhHVHs7fimHcy4NQeSmZvdbSAU+KA/Ie139GDk9u1lVIEjew+XMaWIZ5NR6YfA8XQNbTEeNj
r3c0yuKBSAJr0T5zK7QTcRkzAg5waxmMRMunw1irbcoX5DdJIOq8aY2uA6CDCGSshlF+if3syGsT
ELfTGngUmt+lNlx+EET3I7kWPWI0UzgD6NAJERTboXEiRHI2GJ1WWP0mSLFKkZPhbtzsBDBje1tz
FVtDrYH93q8UOKDsaLafJdW2JiCdEGQw76EI02921+lIgyvypPb2Dl/FDU8S/dkyZnCkfKqnzSXb
LVdMYHuqZhaZodkjJzL2QkHfvTrX5oaKsWmDNUiTzel19M91+5tzfyZcwg6koTrla66yKN131rYd
zVYLtR57PDe8rUixH28l8NV78yyHYPcxkykBYUC03GZdhg1ekSozG2N/G7NUQd0nf6/i8p1NuMpp
UH8+Cqr5jUGErGh4psoDBPJjwt2NBqj1Rdy6uSXD1vNLh95/iq6Tny46Y/FxD+ylfd56NHinXKlr
5Q84sVAPC+tdiJArf5RBPwkLLdNoxinskRCQdTU2/bJawtfG1AzBXqcLGD3os/jDJq/2+K1ceVQS
keVI4bPqdIZBIG8bdJs357DOFvwfseVUoimTliuDXEnqk4WEpmOrw3catKZiz7VM8OGZHdbngsVY
2hPmy73iabkZyplQjjt5dlmQ/lLD0IZ3h1UGDYnY++mgqIPd4eO0inCAEqcJ5ZNpV31ah7kHIA2S
ufhK+hhLJAYw3fVfEqEKoBJd1cRnEkEdsDpNIKOoSuj3n+79CGYoBF465/knh31NGl3iCkdbE9Y5
E2bX9yLB4hql/G+K18lM6rwM6e5lircCkNaDcF2mBHIiSQDNA10GvkbVqI1lIGtHaUGTg/tdnuYb
GzOqGc0f1yFLS5ENvLYM1kA/elskGC8KvO9jl2050GGhQkXUNwgo74CLjYLOU48266JZlL9EA9Zf
X60ZvlTf9tm4Fsk6f6taM7xNW0opg6WUshphZA3MXqJ712aefzqMM54sqt1pJuTKzYottwnXgQNL
a04RBzg+RTJ9u5H3FH0SImGswuLDA9YdPwtCKZHvY8CEndJQqEzSJTgs1/w2loKQ99gAP/LAhYta
k1hJ20AqUojWSyHddE58OVjWUx9ptiLsI231HAY6O3Ifa5DrJXRmhh24cOQFfzqdPDBq6j6tckir
q0tH5xAYu25gL6Hrtufm7OdUgc/EogcRErbzSq6J7L1a3bBiO/WPuTbyVC/8PBOC1mfu5LZ/FpTY
1eb/HeXxOGqunJAzANHrYc41bG72UFz5vixc9TTy8gFV6O39JVys+KVt21c67n0aM0cplQn0QIsE
0doj5mq6M1xyUwifibDPMAxOEAGzARlqB0BuVHjHnfFIaq4pwNqtcaZEgScDs+CPmMJEq9wTLXZb
Xona3UfiMHyWMd8f0w9fEbkjl4wIc1Li1ohCA0A3k82RDXW+P8xWn3bs2vnwH6ZZQuJ293WA7Z6k
oU+UlE7K9GQcKQV1q59HmsGJaD5CkNlc3NKjkzbvdPY0dYrRX81npg8xM/wlfIbh7UUMZ9Uh9lPo
LD0cXLTnu8JtRe/TNL6PANQ6+XGtRg9scpbiiZSipuXcbgtb2Muo1x5VHn0qTa/dXcqR2FxA3+Jz
+NYFcoy7li6btk5vHkPWfmHKzniZYSTK0UTyPGOzu+VxXY8YC7+i1rfwRVg77RsYAk/mR1H1oTVQ
TJKoV0buwSN1F/Tspot6/CF7gGVKTzw6HBbVYxxeVpT75VtmxeD+f95oS/xvPXXvoQRID2ZSPFG5
rEKcJRyZsthG+fCkMWBRQwJ/X//KojIbJWQcrZHyL2e+O82UAroBSHkfKzxs89pQtEdoUVRRB6Wi
/0oLIyQLSC+jU8bTgEr0O6xzOkWKpfueTy27VHmtrEZ6ACNY3aI9nbzno1WeBZcp7pCBMfO47mPG
ePCbtcXphpKb2ThBSWowAzwWV3fwT9rBg6CUCZV/rYrNsX6awR2De3HPbIFbh7oYmlMCVfBnZgTM
+rLO+q2M6wS/H0FyCqCq+qOpKklVVhi+QTRqcTDSYTTdd5/XCY6OnIV/1as/zz5PyXZ2OMzn+emO
XNcbCIvPRI7SYKg0707buuXZYClNZ32wVY7+6ef4Yb9qPzO7u22szCPt7FDoUTwh9Bd0rIHktIPT
AByCkCwIODfLSquYwnlFcgp3z+W3b2IkBelLKc3lcBxgIIeoj++oYEPHKLG/tFANV0fz/B9WC04S
ARe+Pb46SUOQ05YpomO8WZ0dAM96bi/OUX0vY47vqWj8uEZObQo9YQUjyRnSh/xqfqRtQmS/+r3l
1/yZhoexgYg/brviQoMH7G3f73+ZvlfaMC9hY6W6tEryunuLFekx1IzqNmkac+502OL2Ks65+5Ee
ZD27wP+AUr4pGGOBc09ndy4XW/Ro1kRKXlV8ELkrnDaOYoYR6XeOTmQP5ZlddPi8nWKfS8s8kRPs
m454UeIwDRjldV90J0ixiqS12TF4+/+MwAqWZ7Xq0cikXvzrhWNWJLgkWspa+KM3BAvpWChzOTQU
UECYgu0qwdmk5tChYJ4AAUMaOe9Ae5gnA29iLCwIP4NMYFOux01SC+hzBm0C+T6CbjdtyBdcBLc1
5UpZM1y26XejE/Wen+71n7ojAcrfQRq0WY0Z6Ga3/+fgLwUGUht4rLA9UdOLu1PWexDIW8fyhW7Y
dzg/aOijNwlxCWAHC4bZbutSFfN8DbuPEv0Kj3Fufx0L1uIZV087Dh9Yl3I/tC4ScMKigbStMzLP
Wv/5L9HBpMjVMt4YUcZY3bdC4Rb+0VfbH/+ZvuGWE6kgoZLZsAJyJL78pL2ekMkLTAk+vys3SfVB
nS40M9YPus4Wn+jiS6mq/1kp1+kqJhwpA7AqP1JZCuCWIBVmATBPbJZ3k35SCDH8EJ6tB30lkxzR
vgIx9522/XUG3+/qvCKdDA+r69MvSWz+CNImYoHnFUYhUipI6vkorKUPEBx/XLLVBkCS9GBEEPsb
Fc6jMdWAetmg4kQDmTuIiPyLilzgYrSZcseMQxE091MIer+Gg4ij4f1+AIykAsKk0GoMXtX5eBji
WF2+P4jgCg6CM7J5J39b94P73tz9OyuSUDTvdTi80lM17ebKmZ9bU8yCrAg9MnA9I3EROt8iLtMb
DKTrTAkbtSOCMKlMNVMPT7iTzCV/Na0OUJv+vJlln5qXH5H+SZwFECaLSN07BYr8Kl2R/1QrtIPq
kXP4AiE1D1vHUClqYlXe23B0vKRplcr46gB/MR4OGHmoATWRX4lPMWzwicH5gm/LY0TxfrO6CylS
smYoovlcTG1C8lFYnE+rIKhr0rycAxtXSTQ3ZjyQV2aP5F/TWCQMY8+CgZdLhOYxsVTeyYVn1avx
jbp1qT5rEzFIAiLu1tcC4bpKYLns/3/4ltidjDkcp3JO5O6XsGxaQogUFcSS8N++U60VzfMh2PuX
vbDC2qoC4xBDoZRj1I4Qnc0BMwnZ6aTzxmwEkXqWyso8Azk0pWFVtPBG6ImsYRb9CeLF97C2jfSn
9J2rym9dcx+b52WU9QLjaJfFaz5ZmiZkqh+39lmsofsF4TjhKNSvKRKw+K1STYIFqs531g9LfcV/
VA2r2NCMGj6hatkXihdz2RzqNfyts/K0sHLn//yfbI5A91gnqPUi3InWFeexFkOkGS1QGSPjDvQz
rU/pqNrD88CCtM1C/xtP79PI0+hILG48qhFtSFhrZrBTF/K8W1AAZT5t96xFNY9RVBN/mK7ns3uu
cuhrBDX5bdBzWc9QIddY22d4vbmJvvTS3xbRnMCFqX0ZOTjDpedSgOPsWLWOEoqlKHBRRscZcls7
t0iN2ByK3sIvKkybh1JR1/wZ/gsrDEc+T2jGIylIYmKB9PQRHnXtzRcJe988C78zqjNByORC6J+2
3N+l231VwaOxaaQVhHm49FBeWvk6XwO27HsA8fzHGp6Az8ke922Y/Y/WtL9bXpEsQsYUaPEgdaVF
C3/W3AQ5Ah9JQVzgFoN7HWvloXCMMYplPeIA1n6xV4m07OxhZ6KTJNJ/uLacm1c3IUz6TLMgEzm2
k4fKWIAo3OcWi7WBWf9henp/7yrjGGGGT4yDj5/dJKX5b+C8LPYnyGM6W7tEdk+Oi951ny86kelg
HclA5MffmCimXC1f36nbpkkenFYL1lFht5jfgXXKH5WadWVuSblJbjQ0ElouphVqof0zuv2tldEF
3/+9tTYx/pyHmkrFhfcYKRnqifUJx8PV8vtZV816eV20t57pbtZiSaGSJOg79FajcR+moKHeobf9
MYbsPJFdIghMqscfR4DfB+u8o5Z3AhAGYBKtjOs8zAjRVM4T1WwaZ+pe750ogk6ydY8hmguBG61H
QLQQ+WyKa3P8eBuuM/+sCMjYpZAG8yhpIl6ya1a0sr91ycQl/Z7wLpXueiISK+5QFvUZtQNJPGDG
y+YDt2u+sm5tkKh9nfF+u0c6QoXSA9lZKoKhDGVeabQRVhDbn1MdD5/xTH+iPd9QTZJTUV50Pi93
kG6vmg3pjQXuylIeBvGpw4B8Qyt7794NxKdP+01S5+XF/3uYeNLXsQjUL80uCk0C7mQnFqt/biVE
anARHsEtGvnyDjoUf/Pr228YxmdbdipheAnMg5ByJgnH6f6VlDJoQeLnp54US6BxT6RrzqyNgYai
7A+iLnW+NWrJP82ZSRsBKHQbIY3DdnU1rkkHIxFDmbLdTPEFwD+3Qu4aaQrzOxiUtv4YD22Wug+6
1cJFem9gFcLY9GXJFz/UJSU5htpxsF0pZxxuwc9syW0EfqSzZUHipaOceRkihSauvRlfJW6uXP/+
cUzTm/xZ1FKJaNGdwXU2JJf4/L0kypctgl+KP0tDBKRSdgVN3Fji13MbG55hN6SnkAzJsQYbfuD8
GO6FBfCNilFX00hbg9FFcO+4c0GU+mqh0GrEE39x5/tgQv95diQj3sZQQ1GsECLF6MqNX6ScJZG0
L8TyWKmbn/qmht2Gyr6H7BLv0b440WG7THffmpJjkfoXAA3UBBYnR+YUlT6T/E2L6uDsCk+1OKCK
7D/j8QqwdHUOUT4p3s1pPQX/gXECI9G00isRZsWQmOaM/lwXTt9PH4UMP3SlMag1GGegK1RnSAc4
mjY8STWdnlzovQm7FvWkno9ACnY08x5/NNR07NTP+yr4Dqbik4bqvQRd+dYzspRnsWtaNzi7V0gj
/y66LrQptmoLwUYJ4MNhCIMEExe+m40ojNNgDWOA27lgmKqkVXgLueV8II9pYdUJhnbouEFbiFVP
bU8nl5EYhuNf7CoCWv78JLtnnBFGF+VxcQvRbWHyT/6LNogRnOUDyjtd/Tz28Bxsyrt3XOmW6UiW
myKqLFxMqZ0knjyrATmkUe9TzWQBW4f2A2v+8K0hQk4sVIvUn/hlGFHW9Db3dP2xMIP2NOrw31Pk
Ew+H7Cnmch9+WXirWcOd/m9eeH4x3RG09IqTKR/pJaJ5nLHvL73J0HPiBDAWGXmAwbu1bMoRp/Oo
CwTLmGOdf30SUii4ISDUaOaWHPzC0VR6k0xTXDVPkoHs+v8tg7O4vXVSyH7WB4LgeCcnVyEHuETY
SYlN7K/ku01f41yTCDBu0/ky7ll8tEETOnHnFvJ0qNdnoQZB+ggreE8zIQjgyxjhVtebsRsY3/pT
Qt1Fcrir7AD73WQPYQItsD7AEiYaUDMskRNtE99zHcEqr8B9cdoWBN8fCQsneDzR8lcmrhDGYJe5
yn21OeimWwxpXVcpLprKq1B5IHCVhSmDPkjdfzrUBcRkbNAvwVVdjr4P1XsdS1vUvzTxq8y7nkPi
8tJRNwcoFmEAVtgXxos/Uon2DVLtVpsUaXjWBs1cbb1IPUYvjFFLtWQB2YrRtPFThQGO/qxmg9LB
20BoqbClRUR86Qrz/Ldydph6GK9I0TQiLbH0agh5e7XLTEAAJNbRiviD6fdQ8VcDwiKK1bOC43dn
YGAve18trylnBiiEwvTW4luNedzfUDZWXtz9Lv3aJN0bVlJKCORRSPEb7Y6QYtL7oK4K0Y7U5aIH
4xklr4CdOdd4ej3ulZIbsg8pq6h83wQ6+kkst3AFW3Gvozg2nFAgZC6Ws8xQEJDC2r8vqNYnyB8Q
BJihRFHLLzYtCQckb7p+oogi7epDVsHdWENrAxoZFHTnYtPuxz7AeYah/j8jtPig8QUtyAeZNIwF
DNK2pgBEvwMa/oS6QMB/Zjo/slJty5YbX3r4dyC84mdviToTuhcp9QfBe8xdGvGf+sk9HhBx5R9Z
G1qWL1V8LzwKwc8owV5v2ykRNF1JevD6/KpcNsRhDk7VTKg8U5sxQImm4CEii3TDfiCVJAk2OVZH
kLL0rDx8aIqDKU5oeE34deJBW7F8bTr660vOH9hdsOvvrgvzWbhPcTpfYTKFdxAx3/Lc