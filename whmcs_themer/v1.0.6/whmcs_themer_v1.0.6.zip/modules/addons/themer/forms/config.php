<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.1.0
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 October 15
 * version 2.1.0
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPp9nJZ3Itx87lyFR4ugfUjVLNe+dhsz6Oi027DI5gIggMQmdUh/LQycoFg+rI2awe9fQY+Gq
Us8Aq+IUfu6bGnA/i/NdgsymF+wz07mVUAZBtVDmz/7buOuxK4jWP4wKSkfR91bztohuzOZ5KyO2
QcXBxhbHoqfAncuCs6Ir7Nr7IuW4A86xos/kObC+7cwTflo/OSEDJWPF3Q0fWZcno3MJiVGtg+VH
uMT+zlhBRo1eds2U+GoSZhcorSQAGpjhXshsjNYfxQ0MQS5+BovrUO0r1n9GbvZk6aav9fJcvbeD
R2hqEQTbw5rcZphvVe2KYOAtDhbvefWGP13Pkj8QowvNHDxZCrdVgQq/9D5RC00PrRu3EamC92t7
A2u3EXculQzHclHnjGnBgLCufy/wqT15MHXA5yiJagtRRB4XJUncqo4MXtPaNXhrxLYBBIzQPX7I
2/jmvsDhyFnmvL9MpDz8cQO93aw6/W1ltMIXKscEVtlqVrZeLU5xVzkEieI5kEEp6A+6xuH60Rs9
PH0H5Ti+fHh1X70o/4m/E95tVsN+ocgQltiIMmW8rvnHzIsrcKasbQ1baqkDVloEZlkGtWk9xyxp
2e1F3irqUfei0oJRc0kzeS6mtRk76j42l4zWP89quNmke1T6KYQAYp0fFIdLIYa3xIywN95A4/lK
f/3nlOJlr/1wQ5EmbsS/FiYA/jZ05bfgC7Hux+a3T/wHeggO7o6sfiPH/bOeaKXXueYnerreIMj4
kk8BAz9yO+Tfj7boyX5yQfNS5TaPGJ8+8ECsuwpj2kDYwesPR3UVwVFreXJGrG26+weOGiHOtZ6e
fyb8HFvkWbFdQ8+nRQopYzoekmlr0U8KtjWLRgZiDxF+97blfvultSytWdKDGecorRGvGiAeBGZA
Nx7IeA1cjRyJjVw2daJtgBxfCdcQvFMsCYSKFXAVoZG/OO8Vh01oukQshQx9dL1GrlZyd8TN7Z3/
Bhqg1aL6e/73CARAkQ7ImPFGWAxbRIlqCQ2ZQR7cudiWRTowFIQ4IIktY7ArNnsOgx7S8MEBQyZE
zVchQVEB3/KahtJnBHS8yeM6rp0uElSbfdWBqgBYq3xZJL99NrYjt9wfkK3UwhzEZpqEJj7yhbgD
KX2lQATgYcKi5A720WtHtdQJwe4r126UDmh4EDvYK2tkla+56R5esHZvwnAogy86NpWnLfFEm1Yn
Z+oIkoMgoHp5bLozg3DGXiMT1/9CIp2GBxFZA4dIEACPkDOpjBY2CY4UeTOXPmJU6+wUDdgKZIhc
KdSlytZfM6xfDQ52waZ2u1QcYNxL/37yVjQv3mYXPlA6kA+avOy/AGy69/dQiCnlLEMNyyKCV3I9
OKDVkOMGK72+68D/zMlRx7dMt25At5MDdOGjdkl6pTnYnDXXd8pSdkXYrIvhqRX70YBvYvCTrHcU
uOo3TO8D3HzZqQs9Keo/BoSOYLMLE2fUQWTMfTqGOxHT0G8E4V1iUFw387ud6RpcIhkKKloatsYI
Ee1BVnUyWQKVHMHEqfeL1XPbOg6GGQ3A1ILFdgbs8yKCTc0m7p1kQf3xn5ditx/gEjFHTZbh8Ahd
/UIioEck3zvXbdCJEZuXMJhmkTlFwgCD1019C6W1yf8cSOBvBTf1kXLaR0Svw5F7ghd0IS2S1BQr
LamJp+M0qRI00fBOT8ul4HokbHuEHzcl0BGRfX+X7af+i5GNi5S=