

DROP TABLE IF EXISTS `mod_themer_settings`;

-- command split --


DROP TABLE IF EXISTS `mod_themer_themes`;


