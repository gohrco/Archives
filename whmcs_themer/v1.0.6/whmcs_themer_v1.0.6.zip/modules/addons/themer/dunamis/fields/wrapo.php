<?php //00922
/**
 * ---------------------------------------------------------------------
 * In Touch v2.1.0
 * ---------------------------------------------------------------------
 * 2013 Go Higher Information Services, LLC.  All rights reserved.
 * 2013 October 15
 * version 2.1.0
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Go Higher Information Services  may terminate this license
 * if you don't comply with any of the terms and conditions set forth in
 * our end user license agreement(EULA).  In such event, licensee agrees
 * to return licensor or destroy all copies of software upon termination
 * of the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPpI6YSNHQNBgk3KSvlLqk3DHdjXrQcZKowgiJWEDym9eRPc8vjpTorx1XbpKEyuF5wDjOedJ
oo+uZHvlxcdB/J/o5vFeq4nZZiwPktef8jiFMMHTAKmGS+wgDRoS06QCbiTJfBhbqEtSCWYe7eUo
gDEGwhrMgIuwWmKAZEvMsI7UxVOu0XBoYc5haqwHvmDTjj6Qq7yZBw9JYwf0QtJwZxUaJpJ+jsRL
qjlTt12jnD/FkhQBcyPRkRBLnef3Esk7QlQrUAdje6XieaX+3mLxkT3BXIXsEkj+vs5V/OrpWI5S
K/qKjN8MHjLsZ7XFPYSOW6hzItAmOny5MBrmHiCRZHvE9vDgk1/u4/QIjsHi2HbUvF4W5uoam7hx
322SqFhidVCa6ja77g/XVFItuGFW8y7igPq45SGrPLz+hG8T+67GF+CNzQcy8PmVFhDJFPa/ISXg
S2joxnCSA30P9E/x6MwH/GLjH8lVoGmdPjLz/ErZuHGOJN5p73HWtfDcJCn9HWEI+xLPCQyqfi/R
oRV+sAtk5/Cq2jLd68d3wR5VP+Iumn4uZXYcFi1ltgzVv9JWd/ZIW0Hlnso4wfT4kVGpL9ucQnU5
3SyqSFPLTrpkpY4MQiUkmDfgxHeZxqOGdJ3H3TAHDw8isgZfXzKGu8Q1B4dhmIP9g5HaczEuv0Fn
TpGfgt4DvrqJJSlu+q2S0G9wdQyK6MWYvq+iMECplbcEtM9i1+v1UmTc+/a22sEUG7Z3qLPUSj0a
zUFkZ8j+ZTLbzIDaQ1SNAvaWOk+i3U3x4CfX+tKPfyrbQAFuzETBOvbDU2XZVP6NoZ/jDyWVgRP4
FJa72kHj4pVwAIlCysXW77l+BEZmG2u3/aw5tR5uRihf0i2rpeQKYxhrS4yk2i2k/bLDM8o/0AOo
BLvSrKdH5tfk8fvciBlYE0TqGtIiWOfGNQTyCae9Z18/mfuP5nPd+wgTaf6GuPwSH97OJS7v94OM
oMCKQthW4anHMP6dbVUDHxrBIMW51nC2EDKbqmNoy7uM2xlFkqzgRZEAinpWVPsB8EfdkITMp1vh
h7KkOAJVlbYUK3NlSWbi7UBjh9H1w8aS5YAhdRsAM+0xOvJerasSf0CHS7i7qX6NZ1Pvtcw1cOmf
DoB5mP9uquikXBocGulZ3dcBD1UQfJErqyctI9IIvHL56pHoxEJHyr0i0F+KdLN7sTfE+aSFkeok
prlVPvOFeqAQLrkQd8BR/bzpYFLtIlgokpxNHki9YqVCQ0Gi51kPLQDr4jFF7p6U8IgX51s11apc
CEwziNHyEGqvEmJn/RVImv8qKQ3Yv69SZgTD2kndRO8Gc6mR8OqV/zUZVdIu/m+bZqaPvUXviOlF
GPFHwHEOwLsVHs3HDVku9Feo8uA/yyK3XFRHGWYR3mBlyEqOo+qHX6FWCuA+GGFTVG/89iHuGjPY
qw4Uo0n+0bS2f73HAKeFhqa8vCj+lPAHmJYxE254NPjYrzBzad4ch1QWUzQ6IyIqgqqmAzUIjDJW
Bz5qPV/ABvUsm/Bxcv8JorQ55jRKQM77SOcb0ebIcllodv5pM2Q/nx7XsTCK+Ws069LoPI1Z1yzY
YPUjP7r4pJeJgY5rKHAMBEStgCK5GhAAmHi4046NSW07G0sQMurYsE0tT1lIrvmZynRKH0maTJrU
k9RvOqkNswwxPYEUTiDLvWBwN0J9bLCh7qoHbMdY/5zrrgaViVhjxnHlppTnve/zhp+kxmkEKAFn
TvQFFRCxjF7GEmlNM9uuu+EV7FUTbKS7mekFR42oTkhAwYFoKxyXO3IDijjv1CP/iAj63jstJMrU
HFVcdanWlxSRhGRbMrsiPpbAfz4XDixY25SKFijuY6bICBClZEH6dyLk92avZojLcscVnfDCJBQ3
1oi5wubF4P2Bic1Q5wiDiFNppNYD7XP/f8d77TcmBUZuaelm4ff1vUZEni5oV+8MY6pgMXvEGjuE
pSEnIpuP8fOOISaoN8nmnxKgy7Zvjz3QQTQnw/vBIlEtVHkevMZrTCgPAUu280qI8ZJVIm8MC6vR
212jgWQEUYW=