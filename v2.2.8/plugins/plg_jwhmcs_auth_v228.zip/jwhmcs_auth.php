<?php
/**
 * J!WHMCS Integrator - Authentication Plugin
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: jwhmcs_auth.php 226 2011-05-27 19:19:31Z steven_gohigher $
 * @since      1.5.1
 * 
 * @desc		This plugin handles authentication of the user in case they use
 * 				their email address instead of their Joomla username.
 */


// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.application.component.helper' );

$curlfile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jwhmcs'.DS.'classes'.DS.'class.curl.php';
if (is_readable($curlfile)) include_once($curlfile);

/* ------------------------------------------------------------ *\
 * Class:		plgAuthenticationPlg_auth_jwhmcs
 * Purpose:		This plugin allows the user to login with either the
 * 				email address or their username from Joomla
\* ------------------------------------------------------------ */
class plgAuthenticationJwhmcs_auth extends JPlugin
{
	private $e		= false;	// Error holder
	private $whmcs	= false;	// Is this coming from whmcs? T/F
	
	/* ------------------------------------------------------------ *\
	 * Method:		plgAuthenticationPlg_auth_jwhmcs
	 * Purpose:		Constructor function
	\* ------------------------------------------------------------ */
	function plgAuthenticationJwhmcs_auth(& $subject, $config)
	{
		parent::__construct($subject, $config);
		
		$this->loadLanguage( 'com_jwhmcs' );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		onAuthenticate
	 * Purpose:		Handles user authentication procedure for customer
	 * As of:		1.5.1
	 * 
	 * Significant Updates:
	 * 	2.1.0 (Apr 2010)
	 * 		+ Added authentication of subaccounts from WHMCS
	 * 		* Completely revamped to streamline process
	 * 		* Modified parameters to reflect database change
	 *  2.0.2 (Mar 2010)
	 *  	* Modified response when getting results for email to look for array of array
	\* ------------------------------------------------------------ */
	function onAuthenticate( $credentials, &$options, &$response )
	{
		global $mainframe;
		
		if (! class_exists('JwhmcsParams') ) return;
		$db				= & JFactory::getDBO();
		$jcurl			= & JwhmcsCurl::getInstance( true );
		$params			= & JwhmcsParams::getInstance();
		$this->whmcs	=   $options['whmcs'];
		
		if (! $params->get( 'Enable' )) {
			$response->status = JAUTHENTICATE_STATUS_FAILURE;
			$response->error_message = JText::_('AUTH_ERROR_DISABLED');
			return false;
		}
			
		if (! $params->get( 'UserEnable' )) {
			$response->status = JAUTHENTICATE_STATUS_FAILURE;
			$response->error_message = JText::_('AUTH_ERROR_USERINT_DISABLED');
			return false;
		}
		
		jimport('joomla.user.helper');
		jimport ('joomla.error.log');
		$conditions = '';
		
		// Verify password isn't empty before doing anything
		if (empty($credentials['password']))
		{
			return $this->_errorHandler( $options['whmcs'], $response, 'AUTH00P000' );
		}
		
		// Find out if email being used
		$isemail = $this->_checkEmail($credentials['username']);
		
		// If this is an email and not an admin area...
		if ($isemail && (! $mainframe->isAdmin())) {
			// Run authentication against WHMCS
			if (! ($wuser = $this->_authWhmcs($credentials, $response) ) )
				return false; // Find a way to not throw errors if authentication itself fails $this->_errorHandler( $options['whmcs'], $response, 'AUTH02P001' );;
		}
		// If this is a username...
		else {
			// Run authentication against Joomla
			if (! ($juser = $this->_authJoomla($credentials, $response) ) )
				return false; // Find a way to not throw errors if authentication itself fails $this->_errorHandler( $options['whmcs'], $response, 'AUTH01P001' );;
			
			// Administrators get off here...
			if ($mainframe->isAdmin())
				return true;
		}
		
		/* ---------------------------------------------------------------------- *\
		 * At this point the user is authenticated against either Joomla or WHMCS
		\* ---------------------------------------------------------------------- */
		$whereby 	= ($isemail ? "xref_b={$wuser['id']} " : "xref_a={$juser->id} ");
		$subacct	= ( isset( $wuser["subaccount"] ) ? $wuser["subaccount"] : false );
		$xref_type	= "BETWEEN 1 AND 9";
		
		if ( ( $isemail ) AND ( $subacct ) ) {
			$xref_type = "IN ( 5, 6, 7, 9 )";
		}
		elseif ( ( $isemail ) AND (! $subacct ) ) {
			$xref_type = "IN ( 1, 2, 3, 4, 8)";
		}
		
		// If we have arrived here then user has authenticated, now we need to pull Joomla user
		$query	= "SELECT xref_a as joomlaid, xref_type as type, xref_b as clientid FROM #__jwhmcs_xref WHERE {$whereby} AND xref_type {$xref_type}";
		$db->setQuery($query);
		$joom	= $db->loadObjectList();
		
		$joom	= $this->_checkOrphaned($joom, ($isemail ? 'joomla' : 'whmcs') );
		
		// Check to see if the matchedup user is actually a member of a group
		$isgroup	= ( $isemail ? false : $this->_checkGroup( $joom, $credentials ) );
		
		// Test to ensure there is a joom
		if ($joom):
			// Get matching Joomla info
			if ($isemail) {
				// No matching Joomla info found
				if (! ($juser = $this->_getJoomlaData($joom->joomlaid, 'id')) ) {
					$this->_removeXref($joom->joomlaid, $joom->type, $joom->clientid);
					unset($joom);
				}
				// We did find the matching info now should we reset the password?
				else {
					if (! $this->_handlePassword('joomla', $juser, $joom, $credentials) )
					{
						return $this->_errorHandler( $options['whmcs'], $response );
					}
				}
			}
			// Or get matching WHMCS info
			else {
				// No matching WHMCS info found
				if (! ($wuser = $this->_getWhmcsData($joom->clientid, 'id', ( $joom->type == '8' ? 'client' : 'contact' ) ) ) ) {
					$this->_removeXref($joom->joomlaid, $joom->type, $joom->clientid);
					unset($joom);
				}
				// We did find the matching info in WHMCS, so should we reset the password?
				else {
					if (! $isgroup ) {
						if (! $this->_handlePassword('whmcs', $wuser, $joom, $credentials) )
						{
							return $this->_errorHandler( $options['whmcs'], $response );
						}
					}
				}
			}
		endif; // End testing through joom variable
		
		// Matching user doesn't exist in xref or was removed b/c it doesn't exist in Joomla
		if ((! $joom) && ($isemail))
		{
			// Retrieve matching user in Joomla by email
			$juser = $this->_getJoomlaData($wuser['email'], 'email');
			
			// No matching user found
			if (! $juser)
			{
				// Can we add them?
				if ($params->get( 'JuserAutoadd' )) {
					$juser = $this->_addJoomlaUser($wuser, $credentials, $response);
				}
				// We aren't allowed by parameters to add new Joomla user so we fail since we must have a Joomla user to login with
				else
				{
					return $this->_errorHandler( $options['whmcs'], $response, 'AUTH01P003' );
				}
			}
		}
		// Matching user doesn't exist in xref or was removed b/c it doesn't exist in WHMCS
		elseif ((! $joom) && (! $isemail))
		{
			// Retrieve matching user in WHMCS by email
			$wuser = $this->_getWhmcsData($juser->email, 'email', 'client');
			
			if (! $wuser )
			{
				$wuser = $this->_getWhmcsData($juser->email, 'email', 'contact' );
			}
			
			// No matching user found
			if (! $wuser) {
				// Can we add them?
				if ($params->get( 'WuserAutoadd' )) {
					$wuser = $this->_addWhmcsUser($juser, $credentials, $response);
				}
				// We aren't allowed by parameters to add a new user to WHMCS, but they are authenticated in Joomla so return true
				else {
					$user = JUser::getInstance($juser->id);
					$response->fullname 	= $user->name;
					$response->username		= $user->username;
					$response->email		= $user->email;
					$response->password		= $credentials['password'];
					$response->password_clear = $credentials['password'];
					$response->status		= JAUTHENTICATE_STATUS_SUCCESS;
					$response->error_message = '';
					return true;
				}
			}
		}
		
		// Error trapping in case Joomla / WHMCS users not created or are empty
		if (( empty( $juser->id ) ) || ( empty ( $wuser['id'] ) ) )
		{
			return $this->_errorHandler( $options['whmcs'], $response, 'AUTH00P001' );
		}
		
		// Both users have been created or gathered so lets match em up
		if (! $joom) {
			$justore = ( $params->get( 'JusernameStore' ) == '8' ? true : false );  // If we want to request the username check parameter here
			$type = ($isemail ? ( $justore ? ( $wuser['xref_type'] == 2 ? 8 : 9 ) : $wuser['xref_type'] ) : 2 );
			$query = "INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) VALUES ({$juser->id}, {$type}, {$wuser['id']})";
			$db->setQuery($query);
			$db->query();
		}
		
		// Return response object true
		$user = JUser::getInstance($juser->id);
		
		// Test to see if the user is blocked and remove password so can't login to WHMCS
		if ( ( $user->get( 'block' ) == 1 ) && (! $params->get( 'JuserPendingallow' ) ) )
		{
			$credentials['password'] = '';
			$response->type	= '';
		}
		elseif ( ( $user->get( 'block' ) == 1 ) && ( $params->get( 'JuserPendingallow' ) ) )
		{
			$ubind = array( 'block' => false );
			
			$juser = JUser::getInstance($user->id); 
			
			if (! $juser->bind($ubind, 'usertype') ) return $this->_errorHandler( $options['whmcs'], $response, 'AUTH01P025' );
			if (! $juser->save() ) return $this->_errorHandler( $options['whmcs'], $response, 'AUTH01P026' );
			$user = JUser::getInstance( $juser->id );
		}
		
		$response->fullname 	= $user->name;
		$response->username		= $user->username;
		$response->email		= (! $isgroup ? $user->email : $credentials['username'] );
		$response->password		= $credentials['password'];
		$response->password_clear = $credentials['password'];
		$response->status		= JAUTHENTICATE_STATUS_SUCCESS;
		$response->error_message = '';
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_authWhmcs
	 * Purpose:		Authenticates against WHMCS
	 * As of:		2.1.0
	\* ------------------------------------------------------------ */
	function _authWhmcs($credentials, &$response)
	{
		// Start by getting client data
		$type	= 'client';
		$whmcs = $this->_getWhmcsData($credentials['username'], 'email', $type );
		
		if (! $whmcs ) {
			$type	= 'contact';
			$whmcs = $this->_getWhmcsData( $credentials['username'], 'email', $type );
		}
		
		// result failed - no user found by that email
		if ( $whmcs['result'] != 'success' )
			return $this->_errorHandler( $this->whmcs, $response, 'AUTH02P010' );
		
		$isActive	= $this->_isActive( $whmcs, $type );
		if (! $isActive ) return $this->_errorHandler( $this->whmcs, $response, 'AUTH02P001' );
		
		if (! $this->_testWhmcsPassword($whmcs['password'], $credentials['password']))
			return $this->_errorHandler( $this->whmcs, $response, 'AUTH02P011' );
		
		return $whmcs;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_authJoomla
	 * Purpose:		Authenticates against Joomla
	 * As of:		2.1.0
	\* ------------------------------------------------------------ */
	function _authJoomla($credentials, &$response)
	{
		global $mainframe;
		
		$params = & JwhmcsParams::getInstance();
		$user	=   $this->_getJoomlaData($credentials['username'], 'username');
		
		// result failed - no user found by that username
		if (!$user)
			return $this->_errorHandler( $this->whmcs, $response, 'AUTH01P010' );
		
		// If the user is set to be blocked and we can't override then fail
		if ( ( $user->block ) && (! $params->get( 'JuserPendingallow' ) ) )
			return $this->_errorHandler( $this->whmcs, $response, 'AUTH01P004' );
		
		// If the passwords don't match then fail
		if (! $this->_testJoomlaPassword($user->password, $credentials['password']))
			return $this->_errorHandler( $this->whmcs, $response, 'AUTH01P011' );
		
		// If we are actually an administrator and we have authenticated then set response
		if ($mainframe->isAdmin()) {
			$response->email			= $user->email;
			$response->fullname			= $user->name;
			$response->status			= JAUTHENTICATE_STATUS_SUCCESS;
			$response->error_message	= '';
		}
		
		return $user;
	}
		
	
	/**
	 * Retrieves data from WHMCS for an account with a given method
	 * @access		private
	 * @version		2.2.8
	 * @param 		string		- $method: contains email address or id to retrieve for
	 * @param 		string		- $by: either email or id
	 * @param 		string		- $type: either client or contact
	 * 
	 * @return		array containing data or false on failure
	 * @since		2.10
	 */
	function _getWhmcsData( $method, $by = 'email', $type = 'client' )
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance( array( "force" => true ) );
		$params	= & JwhmcsParams::getInstance();
		
		switch ($type):
		case 'client':
			if ($by == 'email') {
				$jcurl->setAction('getclientsdatabyemail', array('email' => $method));
			}
			else {
				$jcurl->setAction('getclientsdata', array('clientid' => $method));
			}
			
			$whmcs	= $jcurl->loadResults();
			
			// WHMCS v421:  Now receive array of array -- need to test for it
			if ( isset($whmcs[0]['result']) ) $whmcs = $whmcs[0];
			
			if (( isset($whmcs['result'])) && ($whmcs['result'] == 'success')) {
				$whmcs['xref_type'] = 2;
				$ret = $whmcs;
			}
			else {
				$ret = false;
			}
			
			break;
		
		case 'contact':
			$jcurl->setAction('jwhmcsgetcontact', array("get" => "$by=$method"));
			$whmcs = $jcurl->loadResult();
			
			if ($whmcs['result'] == 'success') {
				$whmcs['userid'] = $whmcs['id'];
				$whmcs['xref_type'] = 6;
				$ret = $whmcs;
			}
			else {
				$ret = false;
			}
			
			break;
		endswitch;
		
		return $ret;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_getJoomlaData
	 * Purpose:		Retrieves data from Joomla
	 * As of:		2.1.0
	\* ------------------------------------------------------------ */
	function _getJoomlaData($method, $by = 'username')
	{
		$db = & JFactory::getDBO();
		
		$query	= "SELECT a.* FROM `#__users` AS a WHERE {$by}={$db->Quote($method)}";
		$db->setQuery($query);
		return $db->loadObject();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_handlePassword
	 * Purpose:		Common function for handling either J or W password
	 * As of:		2.1.0
	\* ------------------------------------------------------------ */
	function _handlePassword($type, $user, &$joom, &$credentials)
	{
		$jcurl			= & JwhmcsCurl::getInstance( true );
		$params			= & JwhmcsParams::getInstance();
		$usepassword	=   $credentials['password'];
		
		switch ($type):
		case 'joomla':
			// Check first to see if the Joomla user is disabled
			if (! $params->get( 'JuserPendingallow' ) )
			{
				if ( $user->block == true ) 
				{
					$this->e	= 'AUTH01P001';
					return false;
				}
			}
			
			// Test the current password
			$testpw = $this->_testJoomlaPassword($user->password, $credentials['password']);
			
			if ($testpw)
				return true; // Password is the same so send back
			
			// Password is not the same, but the user authenticated against Whmcs, can we update Joomla password?
			if ($params->get( 'JuserAutosync' ))
			{
				$ubind = array('password' => $credentials['password'], 'password2' => $credentials['password'], 'block' => false );
				
				$juser = JUser::getInstance($user->id); 
				if (! $juser->bind($ubind, 'usertype') )
				{
					$this->e	= 'AUTH01P021';
					return false;
				}
				if (! $juser->save() )
				{
					$this->e	= 'AUTH01P022';
					return false;
				}
			}
			else
			{	// Can't update Joomla password so fail
				$this->e	= 'AUTH01P000';
				return false;
			}
			break;
		case 'whmcs':
			// Test the current password 
			$testpw = $this->_testWhmcsPassword($user['password'], $credentials['password']);
			
			if ($testpw)
				return; // Password is the same so send back
			
			if ( $params->get( 'WuserAutosync' ) )
			{
				// If WHMCS version 4.1 or higher, return password clear text
				if (str_replace(".", "", $params->get( 'WhmcsVersion' ) ) < 410 ) {
					// We must encode the password for WHMCS < 4.1
					$jcurl->setAction('getclientpassword', array('userid' => $user['id']));
					$whmcs	= $jcurl->loadResult();
					
					// Explode password hash to get salt and resalt new password and return
					$pwexp	= explode(':', $whmcs['password']);
					$usepassword = md5($pwexp[1].$password).':'.$pwexp[1];
				}
				
				// Subaccounts
				if ($joom->type == 6) {
					$fields['set']			= "id={$user['id']};password=$usepassword";
					$action = 'jwhmcsgetcontact';
				}
				// Regular clients
				else {
					$fields['clientid']		= $user['id'];
					$fields['password2']	= $usepassword;
					$action = 'updateclient';
				}
				
				$jcurl->setAction($action, $fields);
				$whmcs	= $jcurl->loadResult();
			}
			else
			{
				$this->e	= 'AUTH02P000';
				return false;
			}
			break;
		endswitch;
		
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_removeXref
	 * Purpose:		Remove an xref
	 * As of:		2.1.0
	\* ------------------------------------------------------------ */
	function _removeXref($a, $t, $b)
	{
		$db = & JFactory::getDBO();
		
		$query = "DELETE FROM #__jwhmcs_xref WHERE xref_a={$a} AND xref_type={$t} AND xref_b={$b}";
		$db->setQuery($query);
		$db->query();
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_addJoomlaUser
	 * Purpose:		Add a Joomla user
	 * As of:		2.1.0
	\* ------------------------------------------------------------ */
	function _addJoomlaUser($whmcs, $credentials, &$response)
	{
		define('JWHMCS_AUTH', true); // Set so we don't try to add the new user to WHMCS
		
		// Add user to J! database
		$acl	= &JFactory::getACL();
		$user	= JFactory::getUser(0);	
		$usersConfig	=& JComponentHelper::getParams( 'com_users' );
		
		$newUsertype = $usersConfig->get( 'new_usertype' );
		if (!$newUsertype)
			$newUsertype = 'Registered';
		
		// Build the user array for binding
		$ubind	= $this->_buildUserinfo( $whmcs, $credentials );
		$ubind['email']		= $whmcs['email'];
		$ubind['gid']		= $acl->get_group_id( '', $newUsertype, 'ARO' );
		$ubind['password']	= $credentials['password'];
		$ubind['password2']	= $credentials['password'];
		$ubind['sendEmail']	= 0;
		$ubind['block']		= 0;
		
		// Bind the post array to the user object
		if (! $user->bind( $ubind ) )
			return $this->_errorHandler( $this->whmcs, $response, 'AUTH01P023' );
		
		$date =& JFactory::getDate();
		$user->set('registerDate', $date->toMySQL());
		
		// If there was an error with registration, set the message and display form
		if (! $user->save() )
			return $this->_errorHandler( $this->whmcs, $response, 'AUTH01P024' );
		
		return $user;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_addWhmcsUser
	 * Purpose:		Adds a WHMCS user
	 * As of:		2.1.0
	\* ------------------------------------------------------------ */
	function _addWhmcsUser($user, $credentials, &$response)
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance( true );
		$params	= & JwhmcsParams::getInstance();
		
		$fields['firstname']	= $credentials['username'];
		$fields['lastname']		= '(web site user)';
		$fields['address1']		= $params->get( 'WuserDefaultaddress' );
		$fields['city']			= $params->get( 'WuserDefaultcity' );
		$fields['state']		= $params->get( 'WuserDefaultstate' );
		$fields['postcode']		= $params->get( 'WuserDefaultpostal' );
		$fields['country']		= $params->get( 'WuserDefaultcountry' );
		$fields['phonenumber']	= $params->get( 'WuserDefaultphone' );
		$fields['currency']		= '1';
		$fields['email']		= $user->email;
		$fields['password2']	= $credentials['password'];
		
		// 4a1b: Send to curl for adding user and get id back
		$jcurl->setAction('addclient', $fields);
		$whmcs	= $jcurl->loadResult();
		
		// 4a1c: Add new user to xref DB
		$query = 'INSERT INTO `#__jwhmcs_xref` (`xref_a`, `xref_type`, `xref_b`) '
					.'VALUES ("'.$user->id.'", "1", '.$whmcs['clientid'].')';
		$db->setQuery($query);
		$db->query();
		
		return $this->_getWhmcsData( $whmcs['clientid'], 'id', 'client' );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_parseJPassword (private)
	 * Purpose:		This function parses and returns encrypted Joomla
	 * 				password for comparison purposes.
	 * ------------------------------------------------------------ */
	private function _parseJPassword($curpass, $newpass)
	{
		$parts	= explode( ':', $curpass );
		$crypt	= $parts[0];
		
		if ( count( $parts ) > 1 )
		{
			$salt = $parts[1];
			$ret['password']	= JUserHelper::getCryptedPassword( $newpass, $salt );
			$ret['salted']		= $ret['password'].':'.$salt;
		} else {
			$ret['password']	= JUserHelper::getCryptedPassword( $newpass );
			$ret['salted']		= $ret['password'];
		}
		return $ret;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_parseWPassword (private)
	 * Purpose:		This function parses and returns encrypted WHMCS
	 * 				password for comparison purposes.
	 * ------------------------------------------------------------ */
	private function _parseWPassword($encoded, $clear)
	{
		$pwexp	= explode(':', $encoded);
		return md5($pwexp[1].$clear).':'.$pwexp[1];
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_testJoomlaPassword
	 * Purpose:		Validates a Joomla Password
	 * As of:		2.1.0
	\* ------------------------------------------------------------ */
	private function _testJoomlaPassword($encoded, $clear)
	{
		$testpw = $this->_parseJPassword($encoded, $clear);
		return ($testpw['salted'] == $encoded ? true : false);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_testWhmcsPassword (private)
	 * Purpose:		Validates a WHMCS Password
	 * 
	 * Significant Updates:
	 * 	2.1.0 (Apr 2010)
	 * 		* Modified parameters to reflect database change
	 * ------------------------------------------------------------ */
	private function _testWhmcsPassword($encoded, $clear)
	{
		$jcurl	= & JwhmcsCurl::getInstance( true );
		$params	= & JwhmcsParams::getInstance();
		
		if ($params->get( 'WhmcsNomd5' )) {	// We are not using MD5
			$jcurl->setAction('decryptpassword', array('password2' => $encoded));
			$whmcs	= $jcurl->loadResult();
			
			if ($whmcs['result'] == 'success') { 
				$return = ( $whmcs['password'] == $clear ? true : false );
			}
		}
		else {	// We are using MD5 here
			$testpw = $this->_parseWPassword($encoded, $clear);
			$return = ( $testpw == $encoded ? $testpw : false );
		}
		return $return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkOrphaned (private)
	 * Purpose:		Checks xref for orphans left behind
	 * As of:		1.5.1
	 * 
	 * Significant Updates:
	 * 	2.1.0 (Apr 2010)
	 * 		* Modified parameters to reflect database change
	 * ------------------------------------------------------------ */
	private function _checkOrphaned($xref, $system)
	{
		$db		= & JFactory::getDBO();
		$jcurl	= & JwhmcsCurl::getInstance( true );
		
		for ($i=0; $i<count($xref); $i++):
			$x = $xref[$i];
			switch($system):
			case 'joomla':	// We are testing for a set of Joomla IDs
				// Add error testing for xref'd Joomla ID
				$query = 'SELECT a.id FROM #__users as a WHERE id='.$x->joomlaid;
				$db->setQuery($query);
				$joom	= $db->loadResult();
				
				if (!$joom):
					$query = 'DELETE FROM #__jwhmcs_xref WHERE xref_a='.$x->joomlaid.' AND xref_type='.$x->type.' AND xref_b='.$x->clientid;
					$db->setQuery($query);
					$db->query();
					unset($xref[$i]);
				else:
					$ret = $xref[$i];
				endif;
				break;
			case 'whmcs':	// We are testing for a set of WHMCS IDs
				if ($x->type==4):
					// Pull the email and password from jwhmcs_user table
					$query	= 'SELECT grp.email as email FROM #__jwhmcs_group AS grp WHERE id='.$x->clientid;
					$db->setQuery($query);
					
					if ($joom = $db->loadObject()):
						$action				= 'getclientsdatabyemail';
						$fields['email']	= $joom->email;
					else:
						// WHMCS account must not exist, so break switch and reloop
						break;
					endif;
				else:
					$action				= 'getclientsdata';
					$fields['clientid']	= $x->clientid;
				endif;
				
				$jcurl->setAction($action, $fields);
				$whmcs	= $jcurl->loadResult();
				
				if ($whmcs['result']!='success'):
					$query = 'DELETE FROM #__jwhmcs_xref WHERE xref_a='.$x->joomlaid.' AND xref_type='.$x->type.' AND xref_b='.$x->clientid;
					$db->setQuery($query);
					$db->query();
					unset($xref[$i]);
				else:
					$ret = $xref[$i];
				endif;
				break;
			endswitch;
		endfor;
		
		if (count($xref)==0)
			$ret = null;
		
		return $ret;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkGroup (private)
	 * Purpose:		This function checks the xref_type field prior to
	 * 				pulling data for authentication against WHMCS just
	 * 				in case they belong to a group.  If so, (type 4)
	 * 				then their credentials are changed to match correct
	 * 				credentials for group.
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	private function _checkGroup(&$xref, &$credentials)
	{
		// 0:  Check type to see if we need to continue
		if ($xref->type<>4)
			return false;
		
		// 1:  We need this, so lets initialize variables 
		$db	= &JFactory::getDBO();
		
		// 2:  Use clientid to pull user from jwhmcs_group table to retrieve pw
		$query	= 'SELECT grp.email, grp.password FROM #__jwhmcs_group AS grp WHERE grp.id='.$xref->clientid;
		$db->setQuery($query);
		if ($res = $db->loadObject()) {
			$credentials['password']	= $res->password;
			$credentials['username']	= $res->email;
		}
		else {
			return false;
		}
		
		$whmcs = $this->_getWhmcsData($res->email, 'email', 'client');
		$xref->clientid = $whmcs['id'];
		
		return true;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_checkEmail (private)
	 * Purpose:		This function checks the username for an email
	 * As of:		2.0.0
	\* ------------------------------------------------------------ */
	private function _checkEmail($username)
	{
		$params	= & JwhmcsParams::getInstance();
		
		// If we aren't even supposed to authenticate against Whmcs, then return false regardless
		if (! $params->get( 'WuserAuthenticate' ) )
			return false;
		
		// This is the pattern we are using to test for
		$pattern = "/\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,5}\b/i";
		$match = preg_match($pattern, $username);
		
		if (!$match)
			return false;
		elseif ($match > 0)
			return true;
		else
			return false;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_isActive (private)
	 * Purpose:		This function determines if an account is active
	 * As of:		2.12 rc2
	\* ------------------------------------------------------------ */
	private function _isActive( $whmcs, $type )
	{
		switch ( $type ):
		case 'client':
			if ( isset( $whmcs['status'] ) )
			{
				$ret = $whmcs['status'] == 'Active' ? true : false ;
			}
			else
			{
				// Need to figure out how to test for status when it isn't being passed back by WHMCS
				$ret = true;
			}
			break;
		case 'contact':
			$ret	= ( $whmcs['subaccount'] == 1 ? true : false );
			break;
		endswitch;
		return $ret;
	}
	
	
	private function _buildUserinfo( $whmcs, $credentials )
	{
		$params		= & JwhmcsParams::getInstance();
		
		$data		= array();
		$user		= '';
		$firstname	= $whmcs['firstname'];
		$lastname	= $whmcs['lastname'];
		$company	= $whmcs['company'];
		
		switch ($params->get( 'JusernameStore' )):
		case '1':						// firstname.lastname
			$user = "{$firstname}.{$lastname}";
			break;
		case '2':						// lastname.firstname
			$user = "{$lastname}.{$firstname}";
			break;
		case '8':						// Request username at login
		case '3':						// random
			for ($i=0; $i<12; $i++) {
				$d = rand(1,30)%2;
				$user .= ( $d ? chr(rand(65,90)) : chr(rand(48,57)));
			}
			$user = ucfirst(strtolower($user));
			break;
		case '4':						// f.lastname
			$user = substr( $firstname, 0, 1 ).".{$lastname}";
			break;
		case '5':						// firstname.l
			$user = "{firstname}.".substr( $lastname, 0, 1 );
			break;
		case '6':						// firstname
			$user = "{$firstname}";
			break;
		case '7':						// lastname
			$user = "{$lastname}";
			break;
		endswitch;
		
		// If we aren't authenticating against WHMCS and assumign emails are Joomla usernams then we set the username to the email address
		if (! $params->get( "WuserAuthenticate" ) ) $user = $whmcs['email'];
		
		switch ($params->get( 'JuserStore' )):
		case '3':
			$name = (! empty( $company ) ? ' ('. $company .')' : '' );
		case '1':
			$name = $firstname . ' ' . $lastname . $name;
			break;
		case '4':
			$name = (! empty( $company ) ? ' (' . $company . ')' : '' );
		case '2':
			$name = $lastname . ', ' . $firstname . $name;
			break;
		endswitch;
		
		$data['name']		= $this->_decode( $name );
		$data['username']	= $this->_decode( $user, true );
		return $data;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_errorHandler (private)
	 * Purpose:		This function wraps error handling and returns false
	 * As of:		2.1.2
	\* ------------------------------------------------------------ */
	private function _errorHandler( $whmcs = false, &$response, $code = null )
	{
		$params	= & JwhmcsParams::getInstance();
		$debug	=   $params->get( 'Debug' );
		
		// If we are sending a code directly here
		if ( $code !== null ) $this->e = $code;
		
		$response->status = JAUTHENTICATE_STATUS_FAILURE;
		$response->error_message = $this->error;
		JError::raiseWarning( $this->e, ( $whmcs ? $this->e : JText::_( $this->e ) . ( $debug ? "  ({$this->e})" : "" ) ) );
		return false;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_decode (private)
	 * Purpose:		decodes non-utf8 characters for storage
	 * As of:		2.2
	\* ------------------------------------------------------------ */
	private function _decode($source, $strip = false )
	{
		// entity decode
		$trans_tbl = get_html_translation_table(HTML_ENTITIES);
		foreach($trans_tbl as $k => $v) {
			if ( $strip ) $ttr[$v] = "";
			else $ttr[$v] = utf8_encode($k);
		}
		$source = strtr($source, $ttr);
		// convert decimal
		$source = preg_replace('/&#(\d+);/me', ( $strip ? "" : "utf8_encode(chr(\\1))" ), $source); // decimal notation
		// convert hex
		$source = preg_replace('/&#x([a-f0-9]+);/mei', ( $strip ? "" : "utf8_encode(chr(0x\\1))" ), $source); // hex notation
		return $source;
	}
}