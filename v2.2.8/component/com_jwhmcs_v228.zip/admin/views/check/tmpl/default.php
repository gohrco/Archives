<?php  defined('_JEXEC') or die('Restricted access');

JHTML::_( 'behavior.mootools' );
jimport('joomla.html.pane');

$pane =& JPane::getInstance('tabs');

$data = $this->data;

$imgbase = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/';
$j32jwhmcs = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-jwhmcs.png';
$j32helppage = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-helppage.png';
$j48check = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-48-chinst.png';
$j32checkfix = $imgbase.'j-32-checkfix.png';
$j32yes = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-yes.png';
$j16yes = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-16-yes.png';
$j32no = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-32-no.png';
$j16no = JURI::base().'components/'.JRequest::getCmd('option','com_jwhmcs').'/assets/icons/j-16-no.png';
?>

<style type="text/css">
	.icon-48-chinst { background-image: url('<?php echo $j48check; ?>'); }
	.icon-32-jwhmcs { background-image: url('<?php echo $j32jwhmcs; ?>'); }
	.icon-32-helppage { background-image: url('<?php echo $j32helppage; ?>'); }
	.ajaxStatus		{ width: 100%; padding: 0px; margin: 0px auto; height: 32px; }
	.checkStarttbl	{ width: 400px; }
	.checkStartimg	{ width: 100px; text-align: center; }
	.checkStarttxt	{ font-size: xx-large; font-weight: bold; width: inherit !important; display: inline !important; line-height: 48px; padding-left: 10px; vertical-align: top;  }
	.checkFix		{ float: right; width: 150px; height: 32px; background-image: url(<?php echo $j32checkfix; ?>); background-repeat: no-repeat; font-size: x-large; padding-left: 36px; }
	.stepTitle		{ width: 280px; }
	.stepIcon		{ width: 50px; }
	.stepText		{ width: 600px; }
	.admintable		{ width: 100% !important; }
</style>

<?php 
echo $pane->startPane( 'tabs' );
echo $pane->startPanel( 'Joomla Check', 'joomla_check' );
?>
<table class="checkStarttbl toolbar">
	<tr>
		<td class="checkStartimg button">
			<a class="button" href="#" onclick="beginCheck(10,30,this); return false;" id="joomla_check_href1"><img src="<?php echo $imgbase.'j-48-checkrun.png'; ?>" />
			<span class="checkStarttxt">Begin Check</span></a>
		</td>
	</tr>
</table>

<table class="admintable">
	<tbody>
		<tr>
			<td class="stepTitle">
				Component Installed
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep10"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage10">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				Hidden Menu Created
			</td>
			<td width="50px">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep20"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage20">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				Client Menu Created
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep30"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage30">&nbsp;</div>
			</td>
		</tr>
	</tbody>
</table>

<?php 
echo $pane->endPanel();
echo $pane->startPanel( 'Plugin Check', 'plugin_check' );
?>
<table class="checkStarttbl toolbar">
	<tr>
		<td class="checkStartimg button">
			<a class="button" href="#" onclick="beginCheck(100,130,this); return false;" id="plugin_check_href1"><img src="<?php echo $imgbase.'j-48-checkrun.png'; ?>" />
			<span class="checkStarttxt">Begin Check</span></a>
		</td>
	</tr>
</table>

<table class="admintable">
	<tbody>
		<tr>
			<td class="stepTitle">
				Authentication - J!WHMCS
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep100"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage100">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				System - J!WHMCS
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep110"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage110">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				System - J!WHMCS Language 
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep120"></div></div>
			</td>
			<td>
				<div class="ajaxMessage" id="checkMessage120">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				User - J!WHMCS
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep130"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage130">&nbsp;</div>
			</td>
		</tr>
	</tbody>
</table>

<?php
echo $pane->endPanel();
echo $pane->startPanel( 'WHMCS Check', 'whmcs_check' );
?>
<table class="checkStarttbl toolbar">
	<tr>
		<td class="checkStartimg button">
			<a class="button" href="#" onclick="beginCheck(200,240,this); return false;" id="whmcs_check_href1"><img src="<?php echo $imgbase.'j-48-checkrun.png'; ?>" />
			<span class="checkStarttxt">Begin Check</span></a>
		</td>
	</tr>
</table>
<table class="admintable">
	<tbody>
		<tr>
			<td class="stepTitle">
				Root Files Installed
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep200"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage200">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				Hook Files Installed
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep210"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage210">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				Custom API Files Installed
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep220"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage220">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				Template Directories Installed
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep230"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage230">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				Database Initialized (on WHMCS)
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep240"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage240">&nbsp;</div>
			</td>
		</tr>
	</tbody>
</table>
<?php
echo $pane->endPanel();
echo $pane->startPanel( 'Product Check', 'product_check' );
?>
<table class="checkStarttbl toolbar">
	<tr>
		<td class="checkStartimg button">
			<a href="#" onclick="beginCheck(300,310,this); return false;" id="product_check_href1"><img src="<?php echo $imgbase.'j-48-checkrun.png'; ?>" />
			<span class="checkStarttxt">Begin Check</span></a>
		</td>
	</tr>
</table>
<table class="admintable">
	<tbody>
		<tr>
			<td class="stepTitle">
				Product License
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep300"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage300">&nbsp;</div>
			</td>
		</tr>
		<tr>
			<td class="stepTitle">
				API Connection
			</td>
			<td class="stepIcon">
				<div class="ajaxStatus">
				<div class="ajaxStatus" id="checkStep310"></div></div>
			</td>
			<td class="stepText">
				<div class="ajaxMessage" id="checkMessage310">&nbsp;</div>
			</td>
		</tr>
		
	</tbody>
</table>
<?php
echo $pane->endPanel();
echo $pane->endPane();
?>


<form action="index.php" method="post" name="adminForm" id="adminForm">
<input type="hidden" name="option" value="com_jwhmcs" />
<input type="hidden" name="thisUrl" id="thisUrl" value="<?php echo $data->thisUrl; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="controller" value="check" />
<input type="hidden" name="step" id="step" value="10" />
<input type="hidden" name="laststep" id="laststep" value="" />
</form>

<script language="javascript">
function beginCheck(step,last,caller)
{
	$('laststep').setProperty('value', last);
	
	for(i=step; i<=last; i=i+10) {
		ajaxStatus = document.getElementById('checkStep'+i);
		ajaxStatus.removeClass('ajaxLoading').removeClass('ajaxSuccess').removeClass('ajaxError').removeClass('ajaxAlert');
		ajaxMessage = document.getElementById('checkMessage'+i);
		ajaxMessage.setHTML('');
	}
	runCheck(step);
}

function beginFix(step)
{
	ajaxStatus = document.getElementById('checkStep'+step);
	ajaxStatus.removeClass('ajaxLoading').removeClass('ajaxSuccess').removeClass('ajaxError').removeClass('ajaxAlert');
	ajaxMessage = document.getElementById('checkMessage'+step);
	ajaxMessage.setHTML('');
	runFix(step);
}
</script>