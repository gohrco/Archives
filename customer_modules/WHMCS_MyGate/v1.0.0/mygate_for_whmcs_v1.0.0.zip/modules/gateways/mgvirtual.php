<?php
/**
 * MyGate Payment Module for WHMCS
 * WHMCS MyGate Module:  My Virtual
 *
 * @package    MyGate Payment Module for WHMCS
 * @copyright  2014 Living Technologies.  All rights reserved.
 * @license    Commercial EULA
 * @version    1.0.0 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      1.0.0
 *
 * @desc       This file is the gateway file for My Virtual
 *
 */


if (! defined( "WHMCS" ) ) die( "This file cannot be accessed directly" );

/**
 * Configuration function
 * @access		public
 * @version		1.0.0
 * 
 * @return		array  
 * @since		1.0.0
 */
function mgvirtual_config() {
	$configarray = array(
			"FriendlyName"	=>	array(
					"Type"	=>	"System",
					"Value"	=>	"MyGate - My Virtual Gateway"
			),
			"testmode"	=>	array(
					"FriendlyName"	=>	"Test Mode",
					"Description"	=>	"Tick this to enable test mode if using the live environment.",
					"Type"			=>	"yesno",
			),
			"merchantid"	=>	array(
					"FriendlyName"	=>	"Merchant ID",
					"Description"	=>	"Enter your Merchant ID in the field provided.",
					"Type"			=>	"text",
			),
			"applicationid"	=>	array(
					"FriendlyName"	=>	"Application ID",
					"Description"	=>	"Enter your Application ID in the field provided.",
					"Type"			=>	"text",
			),
			"devmode"	=>	array(
					"FriendlyName"	=>	"Developer Mode",
					"Description"	=>	"Tick this to use the development mode instead of live mode.",
					"Type"			=>	"yesno",
			),
			"devmerchantid"	=>	array(
					"FriendlyName"	=>	"DEV Merchant ID",
					"Description"	=>	"Enter your Merchant ID from the Development Site in the field provided.",
					"Type"			=>	"text",
			),
			"devapplicationid"	=>	array(
					"FriendlyName"	=>	"DEV Application ID",
					"Description"	=>	"Enter your Application ID from the Development Site in the field provided.",
					"Type"			=>	"text",
			),
	);
	
	return $configarray;
}


/**
 * Provide the form for redirecting to MyGate
 * @access		public
 * @version		1.0.0
 * @param		array
 * 
 * @return		string
 * @since		1.0.0
 */
function mgvirtual_link( $params )
{
	// We objectify things in 2014
	$params	=	(object) $params;
	$client	=	(object) $params->clientdetails;
	
	// Lets see what mode we are using
	switch( $params->devmode ) :
	case 'on' :	// DEVELOPER MODE
		
		$formaction	=	'https://dev-virtual.mygateglobal.com/PaymentPage.cfm';
		$merchantid	=	$params->devmerchantid;
		$appid		=	$params->devapplicationid;
		
		break;
	default:	// LIVE MODE
		
		$formaction	=	'https://virtual.mygateglobal.com/PaymentPage.cfm';
		$merchantid	=	$params->merchantid;
		$appid		=	$params->applicationid;
		
	endswitch;
	
	// Set our redirect URLs
	$urlsuccess	=	//$params->systemurl	.	'/modules/gateways/mgvirtual_cb_success.php';
	$urlfailed	=	$params->systemurl	.	'/modules/gateways/callback/mgvirtual.php';
	
	// Set our mode
	$testmode	=	$params->testmode == 'on' ? '0' : '1';
	
	// Miscellaneous variables
	$invoiceid	=	$params->invoiceid;
	$merchant	=	$params->companyname;
	$total		=	$params->amount;
	$currency	=	$params->currency;
	$ipaddress	=	( isset( $GLOBALS['_SERVER']['SERVER_ADDR'] ) ? $GLOBALS['_SERVER']['SERVER_ADDR'] : ( isset( $GLOBALS['_SERVER']['REMOTE_ADDR'] ) ? $GLOBALS['_SERVER']['REMOTE_ADDR'] : null ) );
	
	$form	=	<<< FORM

<form name="Virtual Post" action="{$formaction}" method="post">
	<input type="hidden" name="Mode"						value="{$testmode}" />
	<input type="hidden" name="txtMerchantID"				value="{$merchantid}" />
	<input type="hidden" name="txtApplicationID"			value="{$appid}" />
	<input type="hidden" name="txtMerchantReference"		value="{$invoiceid}" />
	<input type="hidden" name="txtRedirectSuccessfulURL"	value="{$urlsuccess}" />
	<input type="hidden" name="txtRedirectFailedURL"		value="{$urlfailed}" />
	<input type="hidden" name="txtPrice"					value="{$total}" />
	<input type="hidden" name="txtCurrencyCode"				value="{$currency}" />
	<input type="hidden" name="txtDisplayPrice"				value="{$total}" />
	<input type="hidden" name="txtDisplayCurrencyCode"		value="{$currency}" />
	<input type="hidden" name="IPAddress"					value="{$ipaddress}" />
	<input type="hidden" name="Variable1"					value="{$params->returnurl}" />
	<input type="hidden" name="Variable2"					value="{$invoiceid}" />
	<input type="submit" name="submit" value="Process Transaction">
</form>
FORM;
	
	// Development
	if ( $params->devmode == 'on' ) {
		echo '<pre>'.htmlentities( $form ).'</pre>';
	}
	
	// Catch failed transactions here
	if ( isset( $_COOKIE['mgvmsg'] ) ) {
		$message	=	$_COOKIE['mgvmsg'];
		setcookie( 'mgvmsg', '', time() - 3600 );
		
		$form	=	<<< MESSAGE
<div style="width: 300px; margin: 10px auto; text-align: center; border: 1px solid #660000; font-weight: bold; padding: 5px; color: #660000; background-color: #FFDDDD; ">{$message}</div>
{$form}
MESSAGE;
	}
	
	return $form;
}


?>