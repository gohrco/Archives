<?php
/**
 * MyGate Payment Module for WHMCS
 * WHMCS MyGate Module:  My Enterprise
 *
 * @package    MyGate Payment Module for WHMCS
 * @copyright  2014 Living Technologies.  All rights reserved.
 * @license    Commercial EULA
 * @version    1.0.0 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      1.0.0
 *
 * @desc       This file is used to translate the response coming from the Soap Client
 *
 */


if (! defined( "WHMCS" ) ) die( "This file cannot be accessed directly" );


/**
 * SoapResponse class
 * @desc		This is used to provide an object for translating the soap client response
 * @author		Steven
 *
 */
class SoapResponse
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.0.0
	 *
	 * @since		1.0.0
	 */
	public function __construct( $response )
	{
		if ( is_array( $response ) ) {
			foreach( $response as $row ) {
				$parts	=	explode( '||', $row );
				$this->set( $parts[0], $parts[1] );
			}
		}
	}
	
	
	/**
	 * Getter method
	 * @access		public
	 * @version		1.0.0
	 * @param		string
	 * @param		varies
	 * 
	 * @return		varies
	 * @since		1.0.0
	 */
	public function get( $name, $default = false )
	{
		return ( isset( $this->$name ) ? $this->$name : $default );
	}
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		1.0.0
	 * @param		string
	 * @param		varies
	 * 
	 * @since		1.0.0
	 */
	public function set( $name, $value )
	{
		$this->$name	=	$value;
		
		if ( $name == 'Error' && $value ) {
			$this->ErrorDescription = $this->translateError( $value );
		}
		
		if ( $name == 'Warning' && $value ) {
			$this->WarningDescription = $this->translateError( $value );
		}
	}
	
	
	/**
	 * Translates an error code into a string
	 * @access		public
	 * @version		1.0.0
	 * @param		string
	 * 
	 * @return		string
	 * @since		1.0.0
	 */
	public function translateError( $code = null )
	{
		switch ( $code ) {
			case '1001' :	return "An incorrect gatewayid was specified. The Gateway ID corresponds to the bank / acquirer that the merchant account is linked to. Refer to Data Element 1.";
			case '1002' :	return "An MerchantID was specified. This will identify the customer account on the MyGate platform. . Refer to Data Element 2.";
			case '1003' :	return "An incorrect MerchantID was specified. This will identify the customer account on the MyGate platform. . Refer to Data Element 2.";
			case '1004' :	return "An ApplicationID was not specified. Please ensure that a valid ApplicationID is entered. Your ApplicationID can be retrieved from the integration email or from the MyGate Web Console. Refer to Data Element 3";
			case '1005' :	return "An incorrect Application ID was specified. This will identify the Application that is linked to the customer account on the MyGate platform. Refer to Data Element 3";
			case '1006' :	return "An Action was not specified. Please enter one of the following Actions: (1,2,3,4). Refer to Data Element 4";
			case '1007' :	return "An Incorrect Action was specified. A valid Action is one of the following: (1,2,3,4). Refer to Data Element 4";
			case '1008' :	return "An incorrect TransactionIndex was specified. Please ensure that a valid transaction index was entered. Refer to Data Element 5";
			case '1009' :	return "A Terminal was not specified. Please check that you have entered a Terminal. Refer to Data Element 6";
			case '1010' :	return "An invalid terminal was specified. A terminal is an alphanumeric string with a minimum of 4 and a maximum of 16 characters. Refer to Data Element 6";
			case '1011' :	return "A Mode was not entered. Please ensure that a mode has been entered in order to complete the transaction. Refer to Data Element 7";
			case '1012' :	return "An incorrect Mode was specified. Please enter Mode '0' for test or Mode '1' for Live. Refer to Data Element 7'";
			case '1013' :	return "A MerchantReference was not entered. The MerchantRefernce links the payment to a specific client. Refer to Data Element 8";
			case '1014' :	return "An incorrect MerchantReference was entered. A MerchantReference is an alphanumeric string containing a minimum of 4 to 16 Characters. A MerchantReference cannot contain symbols or have spaces. Refer to Data Element 8";
			case '1015' :	return "An Amount was not entered. Please ensure that a valid Amount is entered. Refer to Data Element 9";
			case '1016' :	return "A Zero Amount was entered. An Amount indicates the value of the transaction that needs to be processed. Refer to Data Element 9";
			case '1017' :	return "An incorrect Amount was entered. The amount that was entered needs to be entered in the following format: 50.00. Refer to Data Element 9";
			case '1018' :	return "A Currency was not specified. Refer to Data Element 10";
			case '1019' :	return "A TransactionIndex is required. The transaction index is required in order to process the transaction. Refer to Data Element 5";
			case '1020' :	return "An incorrect type was inserted. Enter the correct Card Type to complete the transaction. Refer to Data Element 12";
			case '1021' :	return "An invalid Card Type was specified. A valid Card Type is a number from 1 to 4. Refer to Data Element 12";
			case '1022' :	return "The Card Number is required. A card number needs to be specified in order to complete the transaction. Refer to Data Element 14";
			case '1023' :	return "An invalid Currency was specified. Describe requirements of ISO4217. Refer to Data Element 10";
			case '1024' :	return "An incorrect Card Number was specified. The correct Card Number is required as it gets sent to the bank for Authorization. Refer to Data Element 14";
			case '1025' :	return "This Credit Card Verification Number is required. Please insert a correct Credit Card Verification Number. Refer to Data Element 16";
			case '1026' :	return "An incorrect Card Verification Number has been entered. Refer to Data Element 16";
			case '1027' :	return "An Expiry Month is required. The Expiry Month needs to be entered in order to complete this transaction. Refer to Data Element 17";
			case '1028' :	return "An Expiry Year is required. The Expiry Year needs to be entered in order to complete the transaction. Refer to Data Element 18";
			case '1029' :	return "An incorrect Expiry Month was entered. The correct Expiration Month of the credit card needs to entered in order to complete the transaction. Refer to Data Element 17";
			case '1030' :	return "An incorrect Expiry Year was entered. The correct Expiration year of the credit card need to entered in order to complete the transaction. Refer to Data Element 18";
			case '1031' :	return "The expiry date is in the past. The expiration date entered was invalid. Please ensure that a valid expiration date is entered to complete the transaction. Refer to Data Element 90";
			case '1032' :	return "An account type was not entered. Please ensure that an account type is entered in order to complete the transaction. Refer to Data Element 13";
			case '1033' :	return "An incorrect Account Type was entered. The Account Type is a number between 1 and 3 and it needs to be specified in order to complete the transaction. Refer to Data Element 13'";
			case '1034' :	return "A Card Holder was not entered. Please ensure that a Card Holder is entered to complete the transaction. Refer to Data Element 15";
			case '1035' :	return "An Incorrect Card Holder was entered. The Card Holder name needs to be an alphanumeric string with a max length of 255 characters. Refer to Data Element 15";
			case '1036' :	return "An incorrect CVV was entered for this card type. The CVV is the 3 digit number displayed at the back of the credit card. Refer to Data Element 16";
			case '1037' :	return "An incorrect budget was entered. A budget is indicated by 1 or 0. Refer to Data Element 19";
			case '1038' :	return "A Budget period was not entered. Please ensure that a Budget period is entered in order to complete the transaction. Refer to Data Element 19";
			case '1039' :	return "An invalid Budget period was entered. A budget period is between 1 - 24 months. Refer to Data Element 20";
			case '1040' :	return "A Cashback amount was not entered. Please ensure that a Cashback amount has been entered. Refer to Data Element 11";
			case '1041' :	return "A zero Cashback amount is not allowed. The cashback amount needs to have a value. Please indicate the Cashback amount to complete the transaction. Refer to Data Element 11";
			case '1042' :	return "An invalid cashback Amount was specified. {Describe requirements of ISO4217}. Refer to Data Element 11";
			case '1043' :	return "An incorrect authorization was entered. Please ensure that a valid authorization number was entered in order to complete the transaction. Refer to Data Element 21";
			case '1044' :	return "An incorrect budget was entered. Please ensure that one of the following budget numbers are entered: 0 or 1. Refer to Data Element 19";
			case '1045' :	return "An authorisation number was not entered. The authorisation number is required to complete this transaction. Refer to Data Element 21";
			case '1046' :	return "A PIN was not entered. Please ensure that a PIN is entered. Refer to Data Element 22";
			case '1047' :	return "An invalid PIN was entered. Please specify a valid PIN. Refer to Data Element 22";
			case '1048' :	return "An eCommerceindicator was not entered. Please ensure that an eCommerceIdicator has been entered. Refer to Data Element 24";
			case '1049' :	return "An Incorrect eCommerceIndicator was entered. Please anter a valid eCommerce indicator. Refer to Data Element 24";
			case '1050' :	return "A verifiedByVisaXID was not specified. Please check that you have entered a verifiedByVisaXID. Refer to Data Element 25";
			case '1051' :	return "An invalid verifiedByVisaXID was specified. A valid verifiedByVisaXID was expected. Refer to Data Element 25";
			case '1052' :	return "A verifiedByVisaCAVV was not specified. Please check that you have entered a verifiedByVisaCAVV. Refer to Data Element 26";
			case '1053' :	return "An invalid verifiedByVisaCAVV was specified. A valid verifiedByVisaCAVV was expected. Refer to Data Element 26";
			case '1054' :	return "A secureCodeUCAF was not specified. Please check that you have entered a secureCodeUCAF.";
			case '1055' :	return "An invalid secureCodeUCAF was specified. A valid secureCodeUCAF was expected.";
			case '1056' :	return "This service must be called using SSL (https).";
			case '1057' :	return "A UCI was not specified. Please check that you have entered a UCI.";
			case '1059' :	return "A IP Address was not specified. Please check that you have entered a IP Address.";
			case '1060' :	return "An invalid Public IP Address was specified. This will be returned if the IP Address you are coming from is invalid or is within a local (127.0.0.1, etc) IP range.";
			case '1061' :	return "A Shipping Country Code was not specified. Please check that you have entered a Shipping Country Code.";
			case '1062' :	return "An invalid Shipping Country Code was specified. A valid Shipping Country Code is expected - 2 alphabetical characters.";
			case '1063' :	return "An invalid PurchaseItemsID was specified. I";
			case '1064' :	return "An invalid GateWayID was specified.";
			case '1065' :	return "Cardholder enrolled, successful authentication, unsuccessful signature verification.";
			case '1066' :	return "Cardholder enrolled, unsuccessful authentication, successful signature verification.";
			case '1067' :	return "verifiedByVisaXID required when eCommerceIndicator = 05.";
			case '1068' :	return "verifiedByVisaCAFF required when eCommerceIndicator = 05.";
			case '1078' :	return "An invalid Date From value was specified. This needs to be in the format: yyyy/MM/dd hh:mm yyyy/MM/dd hh:mm";
			case '1080' :	return "An invalid Date To value was specified. This needs to be in the format: yyyy/MM/dd hh:mm";
			case '1081' :	return "Neither a TransactionIndex nor a date range was specified. At least one of these values are required.";
			case '1090' :	return "A carrier name was not specified. Please check that you have entered a carrier name.";
			case '1091' :	return "An invalid carrier name was specified. A valid carrier name is expected - an...19.";
			case '1092' :	return "A ticket nr was not specified. Please check that you have entered a ticketnr.";
			case '1093' :	return "An invalid Ticket Nr was specified. A valid ticket nr is expected - an...15.";
			case '1094' :	return "A plan nr was not specified. Please check that you have entered a plan nr.";
			case '1095' :	return "An invalid plan nr was specified. A valid plan nr is expected - an2.";
			case '1096' :	return "An invoice nr was not specified. Please check that you have entered an invoice nr.";
			case '1097' :	return "An invalid invoice nr was specified. A valid invoice nr is expected - an6.";
			case '1098' :	return "A passenger name was not specified. Please check that you have entered a passenger name.";
			case '1099' :	return "An invalid passenger name was specified. A valid passenger name is expected - ans...29.";
			case '1099' :	return "An invalid passenger name was specified. A valid passenger name is expected - ans...29.";
			case '1100' :	return "A customer ref was not specified. Please check that you have entered a customer ref.";
			case '1101' :	return "An invalid customer ref was specified. A valid customer ref is expected - ans...20.";
			case '1102' :	return "A travel agency code was not specified. Please check that you have entered a travel agency code.";
			case '1103' :	return "An invalid travel agency code was specified. A valid travel agency code is expected - an8.";
			case '1104' :	return "A ticket agency name was not specified. Please check that you have entered a ticket agency name.";
			case '1105' :	return "An invalid ticket agency name was specified. A valid ticket agency name is expected - an...25.";
			case '1106' :	return "A ticket issue address was not specified. Please check that you have entered a ticket issue address.";
			case '1107' :	return "An invalid ticket issue address was specified. A valid ticket issue address is expected - ans...16.";
			case '1108' :	return "A date ticket issue was not specified. Please check that you have entered a date ticket issue.";
			case '1109' :	return "An invalid date ticket issue was specified. A valid date ticket issue is expected - YYYYMMDD.";
			case '1110' :	return "An amount total fare was not specified. Please check that you have entered an amount total fare.";
			case '1111' :	return "An invalid amount total fare was specified. A valid amount total fare is expected - n12.";
			case '1112' :	return "An amount total fees was not specified. Please check that you have entered an amount total fees.";
			case '1113' :	return "An invalid amount total fees was specified. A valid amount total fees is expected - n12.";
			case '1114' :	return "An amount total taxes was not specified. Please check that you have entered an amount total taxes.";
			case '1115' :	return "An invalid amount total taxes was specified. A valid amount total taxes is expected - n12.";
			case '1116' :	return "An amount original invoice was not specified. Please check that you have entered an amount original invoice.";
			case '1117' :	return "An invalid amount orignal invoice was specified. A valid amount original invoice is expected - n12.";
			case '1118' :	return "An original currency code was not specified. Please check that you have entered an original currency code.";
			case '1119' :	return "An invalid original currency code was specified. A valid original currency code is expected - n3.";
			case '1120' :	return "A leg nr was not specified. Please check that you have entered a leg nr.";
			case '1121' :	return "An invalid leg nr was specified. A valid leg nr is expected - n2.";
			case '1122' :	return "A leg carrier code was not specified. Please check that you have entered a leg carrier code.";
			case '1123' :	return "An invalid leg carrier code was specified. A valid leg carrier code is expected - an2.";
			case '1124' :	return "A leg flight nr was not specified. Please check that you have entered a leg flight nr.";
			case '1125' :	return "An invalid leg flight nr was specified. A valid leg flight nr is expected - ans5.";
			case '1126' :	return "A leg departure airport was not specified. Please check that you have entered a leg departure airport.";
			case '1127' :	return "An invalid leg departure airport was specified. A valid leg departure airport is expected - an5.";
			case '1128' :	return "A leg stopover code was not specified. Please check that you have entered a leg stopover code.";
			case '1129' :	return "An invalid leg stopover code was specified. A valid leg stopover code is expected - an1.";
			case '1130' :	return "A leg destination code was not specified. Please check that you have entered a leg destination code.";
			case '1131' :	return "An invalid leg destination code was specified. A valid leg destination code is expected - an5.";
			case '1132' :	return "A leg date of travel was not specified. Please check that you have entered a leg date of travel.";
			case '1133' :	return "An invalid leg date of travel was specified. A valid leg date of travele is expected - YYYYMMDD.";
			case '1134' :	return "A leg departure time was not specified. Please check that you have entered a leg departure time.";
			case '1135' :	return "An invalid leg departure time was specified. A valid leg departure time is expected - HHMM.";
			case '1136' :	return "A leg departure time segment code was not specified. Please check that you have entered a leg departure time segment code.";
			case '1137' :	return "An invalid leg departure time segment code was specified. A valid leg departure time segment code is expected - as1.";
			case '1138' :	return "A leg arrival time was not specified. Please check that you have entered a leg arrival time.";
			case '1139' :	return "An invalid leg arrival time was specified. A valid leg arrival time is expected - HHMM.";
			case '1140' :	return "A leg arrival time segment code was not specified. Please check that you have entered a leg arrival time segment code.";
			case '1141' :	return "An invalid leg arrival time segment code was specified. A valid leg arrival time segment code is expected - as1.";
			case '1142' :	return "A leg class of travel was not specified. Please check that you have entered a leg class of travel.";
			case '1143' :	return "An invalid leg class of travel was specified. A valid leg class of travel is expected - an2.";
			case '1144' :	return "A leg coupon nr was not specified. Please check that you have entered a leg coupon nr.";
			case '1145' :	return "An invalid leg coupon nr was specified. A valid leg coupon nr is expected - ans1.";
			case '1146' :	return "A leg conjunction ticket nr was not specified. Please check that you have entered a leg conjunction ticket nr.";
			case '1147' :	return "An invalid leg conjunction ticket nr was specified. A valid leg conjunction ticket nr is expected - an...15.";
			case '1148' :	return "A leg exchange ticket nr was not specified. Please check that you have entered a leg exchange ticket nr.";
			case '1149' :	return "An invalid leg exchange ticket nr was specified. A valid leg exchange ticket nr is expected - an...15.";
			case '1150' :	return "A leg fare basis code was not specified. Please check that you have entered a leg fare basis code.";
			case '1151' :	return "An invalid leg fare basis code was specified. A valid leg fare basis code is expected - an...15.";
			case '1152' :	return "A leg amount fare was not specified. Please check that you have entered a leg amount fare.";
			case '1153' :	return "An invalid leg amount fare was specified. A valid leg amount fare is expected - n12.";
			case '1154' :	return "A leg amount fees was not specified. Please check that you have entered a leg amount fees.";
			case '1155' :	return "An invalid leg amount fees was specified. A valid leg amount fees is expected - n12.";
			case '1156' :	return "A leg amount texes was not specified. Please check that you have entered a leg amount texes.";
			case '1157' :	return "An invalid leg amount taxes was specified. A valid leg amount texes is expected - n12.";
			case '1158' :	return "A leg amount departure tax was not specified. Please check that you have entered a leg amount departure tax.";
			case '1159' :	return "An invalid leg amount departure tax was specified. A valid leg amount departure tax is expected - n12.";
			case '1160' :	return "A leg endorsements or restrictions was not specified. Please check that you have entered a leg endorsements or restrictions.";
			case '1161' :	return "An invalid leg endorsements or restrictions was specified. A valid leg endorsements or restrictions is expected - ans...20.";
			case '2001' :	return "The specified gateway does not exist or is invalid. Please ensure that one of the following Gateways are entered: 01,21,22,23,24,25,26. Refer to Data Element 1";
			case '2002' :	return "The MerchantID entered is cancelled. Contact MyGate to reactivate Refer to Data Element 2";
			case '2003' :	return "The ApplicationID entered does not exist. Please ensure that a valid ApplicationID is entered. Refer to Data Element 3";
			case '2004' :	return "The transactionIndex entered does not exist. Please ensure that a valid TransactionIndex is entered to complete the transation. Refer to Data Element 5";
			case '2005' :	return "A duplicate merchant reference was found. Please ensure that a Unique MerchantReference is entered. Refer to Data Element 8";
			case '2006' :	return "A credit action cannot be implemented without a debit action on a transaction. Refer to Data Element 4";
			case '2007' :	return "A ReverseAuthorisation action has already been implemented for this transaction. Only 1 action can be made on this transaction. Refer to Data Element 4";
			case '2008' :	return "A Debit action has already been implemented for this transaction. A ReverseAuthorisation cannot be performed on a settled transaction.";
			case '2009' :	return "A Credit action has already been implemented for this transaction. No more actions can be performed on this Transaction";
			case '2010' :	return "Authorisation Action has not yet been performed. All transactions have to begin with the authorisation action 1. See data element 4";
			case '2011' :	return "A debit action has already been performed on this transaction. An action 3 cannot be performed twice on the same transaction.";
			case '2012' :	return "An authorisation action has already been performed on this transaction. An action cannot be performed twice on the same transaction";
			case '2013' :	return "Only a successful authorization and budget can preced a budget reversal.";
			case '2014' :	return "Only a successful AUTHORISEREFUND can preced a AUTHORISEREFUNDREVERSAL";
			case '2015' :	return "Only a successful AUTHORISEREFUND can preced a REFUND";
			case '2016' :	return "Only a successful AUTHORISEREFUND and REFUND can preced a REFUNDREVERSAL";
			case '2017' :	return "Only a successful AUTHORISECASHADVANCE can preced an AUTHORISECASHADVANCEREVERSAL";
			case '2018' :	return "Only a successful AUTHORISECASHADVANCE can preced a CASHADVANCE";
			case '2019' :	return "Only a successful AUTHORISECASHADVANCE and CASHADVANCE can preced a CASHADVANCEREVERSAL";
			case '2020' :	return "An Incorrect Relationship with Gateway, Application and Merchant. Please ensure that the MerchantID, ApplicationID and gateway that was entered are correct";
			case '2021' :	return "An invalid Shipping Country Code was specified. Please provide a valid shipping country code. Refer to Data Element 30";
			case '2022' :	return "Only a successful AUTHORISEPURCHASE and PURCHASE can preceed a VOID.";
			case '2023' :	return "Only a successful AUTHORISEPURCHASE, PURCHASE and PURCHASEREVERSAL can preceed a VOID.";
			case '2024' :	return "Only a successful PURCHASE with auth code can preceed a VOID.";
			case '2025' :	return "Only a successful CREDIT can preceed a VOID.";
			case '2050' :	return "An incorrect amount of decimal places was passed.";
			case '4001' :	return "Mode Denied. Application Status is developing. Please contact MyGate.";
			case '4002' :	return "Invalid Card for Live Mode. Test Card not allowed to be used Live Mode. Refer to Data Element 7";
			case '4003' :	return "Merchant ID is Inactive. Refer to Data Element 2";
			case '4004' :	return "Merchant ID is Suspended. Refer to Data Element 2";
			case '4005' :	return "Merchant ID has been Removed. Refer to Data Element 2";
			case '4006' :	return "Application ID is Inactive. Refer to Data Element 3";
			case '4007' :	return "Application ID is Suspended. Refer to Data Element 3";
			case '4008' :	return "Application ID has been Removed. Refer to Data Element 3";
			case '4009' :	return "The IP Address is not in the list of allowed IP Addresses for this Application.";
			case '4010' :	return "The gateway that your trying to use, has been set to inactive. Refer to Data Element 1";
			case '4011' :	return "The gateway that your trying to use, is no longer in use. Refer to Data Element 1";
			case '4012' :	return "The currency you have specified is not listed under the allowed list of currencies for your application. Refer to Data Element 10";
			case '4013' :	return "The currency you have specified is invalid. Refer to Data Element 10";
			case '4014' :	return "This transaction amount exceeds the transaction limit for your application. Refer to Data Element 9";
			case '4015' :	return "This transaction amount exceeds the cumulative transaction limit for your application. Refer to Data Element 9";
			case '4016' :	return "The card type you have specified is not listed under the allowed list of card types for your application. Refer to Data Element 12";
			case '4017' :	return "The account type you have specified is not listed under the allowed list of account types for your application. Refer to Data Element 13";
			case '4018' :	return "Budget transactions are not allowed for your application. Refer to Data Element 19";
			case '4019' :	return "The eCommerceIndicator you have specified is not listed under the allowed list of eCommerceIndicators for your application.";
			case '5001' :	return "Gateway not configured for Live Transactions Refer to Data Element 1";
			case '5002' :	return "Your bank declined the transaction. Contact your bank.";
			case '5003' :	return "An unexpected error occurred. Please retry the Transaction.";
			case '6001' :	return "This transaction has been declined by BLS.";
			case '6002' :	return "This transaction has been declined by BLS.";
			case '6003' :	return "This transaction has been declined by BLS.";
			case '6004' :	return "This transaction has been declined by BLS.";
			case '6005' :	return "This transaction has been declined by Global IP Recognition Settings.";
			case '6006' :	return "The fraud module determined that this transaction was not safe for processing. This was determined by the IP Verification Service Procedure.";
			case '6007' :	return "This transaction has been declined by RFI procedures.";
			case '6008' :	return "This transaction has been declined by RSI procedures.";
			case '6009' :	return "This transaction has been declined by UCI procedures.";
			case '6999' :	return "The Fraud Module encountered an error during processing.";
			case '7001' :	return "The Client Token is required for all tokenization transactions.";
			case '7002' :	return "The Client Token needs to be in an alphanumeric format with no special characters.";
			case '7003' :	return "No associated card details could be located with the specified token.";
			case '7004' :	return "The specified token is set to deregistered and cannot be used for processing.";
			case '8001' :	return "Transaction Mode was Ignored. Refer to Data Element 7";
			case '8002' :	return "Transaction Amount was Ignored. Refer to Data Element 9";
			case '8003' :	return "Credit Card Type was Ignored. Refer to Data Element 12";
			case '8004' :	return "Credit Card Number was Ignored. Refer to Data Element 14";
			case '8005' :	return "CCV Number was Ignored. Refer to Data Element 16";
			case '8006' :	return "Expiry Month was ignored. Refer to Data Element 17";
			case '8007' :	return "Expiry Year was ignored. Refer to Data Element 18";
			case '8008' :	return "Cumulative Transaction Limit Almost Exceeded";
			case '8009' :	return "Transaction Limit has been exceeded.";
			case '8010' :	return "Cumulative Transaction Limit exceeded.";
			case '8011' :	return "Transaction Index was ignored. Refer to Data Element 5";
			case '8012' :	return "Currency was ignored. Refer to Data Element 10";
			case '8013' :	return "Account Type was ignored. Refer to Data Element 13";
			case '8014' :	return "Card Holder was ignored. Refer to Data Element 15";
			case '8015' :	return "Budget was ignored. Refer to Data Element 19";
			case '8016' :	return "Budget Period was ignored. Data Element 20";
			case '8017' :	return "Cashback Amount was ignored. Refer to Data Element 11";
			case '8018' :	return "Authorisation was ignored. Refer to Data Element 11";
			case '8019' :	return "PIN was ignored";
			case '8020' :	return "Terminal was ignored";
			case '8021' :	return "ClientReference was ignored";
			case '8022' :	return "eCommerceIndicator was ignored";
			case '8023' :	return "verifiedByVisaXID was ignored";
			case '8024' :	return "verifiedByVisaCAVV was ignored";
			case '8025' :	return "secureCodeUCAF was ignored";
			case '8026' :	return "UCI was ignored";
			case '8027' :	return "IP Address was ignored";
			case '8028' :	return "Shipping Country Code was ignored";
			case '8029' :	return "This transaction has been flagged by the Card Number Blacklist Procedure.";
			case '8030' :	return "This transaction has been flagged by the Country Code Blacklist Procedure.";
			case '8031' :	return "This transaction has been flagged by the IP Address Blacklist Procedure.";
			case '8032' :	return "This transaction has been flagged by the Unique Client Identifier Blacklist Procedure.";
			case '8033' :	return "This transaction has been flagged by the GIR Procedure.";
			case '8034' :	return "This transaction has been flagged by the IVS Procedure.";
			case '8035' :	return "This transaction has been flagged by the RFI Procedure";
			case '8036' :	return "This transaction has been flagged by the RSI Procedure.";
			case '8037' :	return "This transaction has been flagged by the UCI Procedure.";
			case '8038' :	return "Card Number Blacklist procedure was not performed on this transaction";
			case '8039' :	return "Country Code Blacklist procedure was not performed on this transaction.";
			case '8040' :	return "IP Address Blacklist procedure was not performed on this transaction.";
			case '8041' :	return "Unique Client Identifier Blacklist procedure was not performed on this transaction.";
			case '8042' :	return "GIR procedure was not performed on this transaction.";
			case '8043' :	return "IVS procedure was not performed on this transaction.";
			case '8044' :	return "RFI procedure was not performed on this transaction.";
			case '8045' :	return "RSI procedure was not performed on this transaction.";
			case '8046' :	return "UCI procedure was not performed on this transaction.";
			case '8047' :	return "PurchaseItemsID Was Ignored";
			case '9001' :	return "An unexpected error has occurred. Please try again later";
			case '9002' :	return "You requested functionality that has not been implemented on this gateway yet.";
			case '9003' :	return "This card type has not yet been implemented on this gateway.";
			case '9004' :	return "The fraud module returned an unexpected status.";
			case '9005' :	return "The fraud module returned an unexpected result.";
			case '9998' :	return "There was an error in the Consummation object.";
		}
	}
	
	
	/**
	 * Converts the object into an array
	 * @access		public
	 * @version		1.0.0
	 * 
	 * @return		array
	 * @since		1.0.0
	 */
	public function toArray()
	{
		$vars	=	get_object_vars( $this );
		return $vars;
	}
}