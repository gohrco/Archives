<?php
/**
 * MyGate Payment Module for WHMCS
 * WHMCS MyGate Module:  My Enterprise
 *
 * @package    MyGate Payment Module for WHMCS
 * @copyright  2014 Living Technologies.  All rights reserved.
 * @license    Commercial EULA
 * @version    1.0.0 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      1.0.0
 *
 * @desc       This file is the gateway file for My Enterprise
 *
 */

// Include our required WHMCS items
require "../../../init.php";
$whmcs->load_function( "gateway" );
$whmcs->load_function( "invoice" );
$whmcs->load_function( "client" );
$whmcs->load_function( "cc" );

// Grab our response handler
include dirname( __DIR__ ) . DIRECTORY_SEPARATOR . 'mygate' . DIRECTORY_SEPARATOR . 'soapresponse.php';


// Get our gateway variables
$GATEWAY		=	(object) getGatewayVariables( 'mgenterprise' );
$invoiceid		=	$_GET['invoiceid'];
$invoiceid		=	checkCbInvoiceID( $invoiceid, $GATEWAY->name );
$carddetails	=	getCCVariables( $invoiceid );
checkCbTransID( $input->MD );

// Build our common object
foreach ( $carddetails as $k => $v ) {
	$GATEWAY->$k	=	$v;
}

// Sanity checks
$input		=	$_POST;
ksort( $input );
$input		=	(object) $input;

// Lets see what mode we are using
switch( $GATEWAY->devmode ) :
case 'on' :	// DEVELOPER MODE

	$soapurl	=	'https://dev-3dsecure.mygateglobal.com/ws3DSecure.wsdl';
	$merchantid	=	$GATEWAY->devmerchantid;
	$appid		=	$GATEWAY->devapplicationid;
	$gatewayid	=	$GATEWAY->devgatewayid;

break;
default:	// LIVE MODE

	$soapurl	=	'https://3dsecure.mygateglobal.com/ws3DSecure.wsdl';
	$merchantid	=	$GATEWAY->merchantid;
	$appid		=	$GATEWAY->applicationid;
	$gatewayid	=	$GATEWAY->gatewayid;

endswitch;


//Once the card holder has been posted back, we verify the results but dont actually do anything with that for some reason
$TransactionId	=	$input->MD;
$PAResPayload	=	$input->PaRes;

$client			=	new SoapClient( $soapurl );
$results		=	new SoapResponse( $client->authenticate(
		$input->MD, 				//TransactionID
		$input->PaRes				//PaRes
) );

$data				=	mgenterprise_capture( $GATEWAY, $input->MD );
$callbacksuccess	=	false;

// Successful capture
// ------------------
if ( $data['status'] == 'success' ) {
	logTransaction( $GATEWAY->name . ' 3D Capture', $data["rawdata"], "Successful" );
	addInvoicePayment( $invoiceid, $data["transid"], "", "", "mgenterprise", "on" );
	sendMessage( "Credit Card Payment Confirmation", $invoiceid );
	$callbacksuccess = true;
}
else {
	logTransaction( $GATEWAY->name . ' 3D Capture', $data["rawdata"], "Failed" );
}

// Send a message just in case
// ---------------------------
if (! $callbacksuccess ) {
	sendMessage( "Credit Card Payment Failed", $invoiceid );
}

mgenterprise_wipecookies();
callback3DSecureRedirect( $invoiceid, $callbacksuccess );

?>