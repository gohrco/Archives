<?php
/**
 * MyGate Payment Module for WHMCS
 * WHMCS MyGate Module:  My Virtual
 *
 * @package    MyGate Payment Module for WHMCS
 * @copyright  2014 Living Technologies.  All rights reserved.
 * @license    Commercial EULA
 * @version    1.0.0 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      1.0.0
 *
 * @desc       This file is the gateway file for My Virtual
 *
 */


// Include our required WHMCS items
include("../../../dbconnect.php");
include("../../../includes/functions.php");
include("../../../includes/gatewayfunctions.php");
include("../../../includes/invoicefunctions.php");

// Get our gateway variables
$GATEWAY	=	(object) getGatewayVariables( 'mgvirtual' );

// Sanity checks
$input		=	$_POST;
ksort( $input );
$input		=	(object) $input;

if (! $GATEWAY->type ) {
	die( "Module Not Activated" );
}

// Translate our variables
$returnurl	=	$input->VARIABLE1;
$invoiceid	=	$input->VARIABLE2;
$transid	=	$input->_TRANSACTIONINDEX;
$amount		=	$input->_AMOUNT;
$fee		=	0;

// Ensure we have a legit invoice
$invoiceid	=	checkCbInvoiceID( $invoiceid, $GATEWAY->name );
checkCbTransID( $transid );

if ( isset( $input->_ERROR_CODE ) && $input->_ERROR_CODE ) {
	// We have a declined transaction
	logTransaction( $GATEWAY->name, (array) $input, "Unsuccessful" );
	
	$message	=	$input->_ERROR_MESSAGE;
	
	if ( $GATEWAY->testmode == 'on' ) {
		$message	.=	' (' . $input->_ERROR_CODE . ' - ' . $input->_ERROR_DETAIL . ')';
	}
	
	// Set our cookie so we have something to see on invoice page
	setcookie( 'mgvmsg', $message, time() + 30, '/' );
	
}
else {
	// We should be okay here
	addInvoicePayment( $invoiceid, $transid, $amount, $fee, 'mgvirtual' );
	logTransaction($GATEWAY->name, (array) $input, "Successful" );
}

header( "Location: " . $returnurl );
exit;

?>