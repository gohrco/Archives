<?php
/**
 * MyGate Payment Module for WHMCS
 * WHMCS MyGate Module:  My Enterprise
 *
 * @package    MyGate Payment Module for WHMCS
 * @copyright  2014 Living Technologies.  All rights reserved.
 * @license    Commercial EULA
 * @version    1.0.0 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      1.0.0
 *
 * @desc       This file is the gateway file for My Enterprise
 *
 */


if (! defined( "WHMCS" ) ) die( "This file cannot be accessed directly" );

include_once __DIR__ . DIRECTORY_SEPARATOR . 'mygate' . DIRECTORY_SEPARATOR . 'soapresponse.php';


/**
 * Function to gather configuration settings for gateway
 * @version		1.0.0
 * 
 * @return		array
 * @since		1.0.0
 */
function mgenterprise_config()
{
	$configarray = array(
			"FriendlyName"	=>	array(
					"Type"	=>	"System",
					"Value"	=>	"MyGate - My Enterprise Gateway"
			),
			"testmode"	=>	array(
					"FriendlyName"	=>	"Test Mode",
					"Description"	=>	"Tick this to enable test mode if using the live environment.",
					"Type"			=>	"yesno",
			),
			"merchantid"	=>	array(
					"FriendlyName"	=>	"Merchant ID",
					"Description"	=>	"Enter your Merchant ID in the field provided.",
					"Type"			=>	"text",
			),
			"applicationid"	=>	array(
					"FriendlyName"	=>	"Application ID",
					"Description"	=>	"Enter your Application ID in the field provided.",
					"Type"			=>	"text",
			),
			"institution"	=>	array(
					"FriendlyName"	=>	"Gateway ID",
					"Type"			=>	"dropdown",
					"Options"		=>	"FNB,ABSA,NedBank,SBSA",
			),
			"devmode"	=>	array(
					"FriendlyName"	=>	"Developer Mode",
					"Description"	=>	"Tick this to use the development mode instead of live mode.",
					"Type"			=>	"yesno",
			),
			"devmerchantid"	=>	array(
					"FriendlyName"	=>	"DEV Merchant ID",
					"Description"	=>	"Enter your Merchant ID from the Development Site in the field provided.",
					"Type"			=>	"text",
			),
			"devapplicationid"	=>	array(
					"FriendlyName"	=>	"DEV Application ID",
					"Description"	=>	"Enter your Application ID from the Development Site in the field provided.",
					"Type"			=>	"text",
			),
	);
	
	return $configarray;
}


/**
 * Function to perform 3D Secure transaction
 * @version		1.0.0
 * @param		array
 * 
 * @return		string
 * @since		1.0.0
 */
function mgenterprise_3dsecure( $params )
{
	extract( mgenterprise_buildcalldata( $params, null, '3dsecure' ) );
	
	// We objectify things in 2014
	// ---------------------------
	$params	=	(object) $params;
	$client	=	(object) $params->clientdetails;
	
	// Lookup client to see if we need to do 3dsecure process
	$client		=	new SoapClient( $soapurl );
	$results	=	new SoapResponse( $client->lookup(
			$merchantid,						// Merchant ID
			$appid,								// Application ID
			$testmode,							// Test Mode
			$cardnumber, 						// Credit Card Number
			$cardexpiry,						// Expiry Date (YYMM)
			$amount,							// Transaction Amount
			$useragent,							// The HTTP User Agent
			$browseragent,						// The HTTP Browser Header
			'INV' . $invoiceid,					// MerchantReference
			'',									// The Order Desc
			'N',								// Is the transaction recurring
			'',									// What is the recurring frequency
			'',									// When is the last debit date
			''									// The amount of months the recurring debits will continue
	) );
	
	// We have results without errors
	// ------------------------------
	if ( $results->get( 'Result' ) == '0' ) {
		
		// Customer is enrolled in 3d secure
		// ---------------------------------
		if ( $results->get( 'Enrolled' ) == 'Y' ) {
			
			logTransaction( $params->name . ' 3D Secure', $results->toArray(), "Success" );
			
			$callback	=	$params->systemurl	.	'/modules/gateways/callback/mgenterprise.php?invoiceid=' . $invoiceid;
			
			if ( $params->devmode == 'on' || $params->testmode == 'on' ) {
				$html		=	<<< HTML
<form name="frmLaunchACS" method="POST" action="{$results->get( 'ACSUrl' )}">
	<table align="center"  width='50%' style="border:1px solid black;">
		<tr>
			<td align="center" colspan="2" style="background-color:Red; font-size:16px;">
				<font color="FFFFFF">Posting data to the Issuer ACS server</font>
			</td>
		</tr>
		<tr>
			<td >
				<div align="right">PaReq :</div>
			</td>
			<td >
				<textarea cols="50" rows="5" style="width:400" name="PaReq" >{$results->get( 'PAReqMsg' )}</textarea>
			</td>
		</tr>
		<tr>
			<td >
				<div align="right">TermUrl :</div>
			</td>
			<td >
				<input type="text" style="width:400" name="TermUrl" value="{$callback}"/>
			</td>
		</tr>
		<tr>
			<td >
				<div align="right">Transaction Index</div>
			</td>
			<td >
				<input type="text" style="width:400" name="MD" value="{$results->get( 'TransactionIndex' )}"/>
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<noscript>
					<div align="center">
						<input type="submit" value="Submit Form" style="width:250" >
					</div>
				</noscript>
			</td>
		</tr>
	</table>				
</form>
HTML;
			}
			else {
				$html		=	<<< HTML
<form name="frmLaunchACS" method="POST" action="{$results->get( 'ACSUrl' )}">
	<input type="hidden" name="PaReq" value="{$results->get( 'PAReqMsg' )}" />
	<input type="hidden" name="TermUrl" value="{$callback}" />
	<input type="hidden" name="MD" value="{$results->get( 'TransactionIndex' )}" />
	<noscript>
		<center>
			<font color="red">
				<h2>Processing your Payer Authentication Transaction</h2>
				<h3>JavaScript is currently disabled or is not supported by your browser.</h3>
				<h4>Please click Submit to continue the processing of your transaction.</h4>
			</font>
			<input type="submit" value="Submit">
		</center>
	</noscript>
</form>
HTML;
			}
			
			// Outta here
			return $html;
		}
		
		// Customer is NOT enrolled in 3d secure
		// ---------------------------------
		else {
			logTransaction( $params->name . ' 3D Secure', $results->toArray(), "Success - Customer Not Enrolled" );
			
			// Capture anyway
			$result	=	mgenterprise_capture( $params, $results->get( 'TransactionIndex' ) );
			
			if ( $result['status'] == 'success' ) {
				logTransaction( $params->name . ' No 3D Capture', $result["rawdata"], "Successful" );
				addInvoicePayment( $params->invoiceid, $result["transid"], "", "", "mgenterprise", "on" );
				sendMessage( "Credit Card Payment Confirmation", $params->invoiceid );
				mgenterprise_wipecookies();
				header( "Location: viewinvoice.php?id=" . $params->invoiceid . "&paymentsuccess=true" );
				exit();
			}
			else {
				logTransaction( $params->name . ' No 3D Capture', $results['rawdata'], "Failed" );
			}
		}
	}
	
	// 3D Secure Failed For Some Reason
	// --------------------------------
	else {
		logTransaction( $params->name . ' 3D Secure', $results->toArray(), "Failed" );
	}
	
	mgenterprise_wipecookies();
	return 'declined';
}


/**
 * Capture facility for getting money :)
 * @version		1.0.0
 * @param		array
 * @param		string
 * 
 * @return		array
 * @since		1.0.0
 */
function mgenterprise_capture( $params, $transxnid = '' ) 
{
	$data	=	array(
		'status'	=>	'success',
		'transid'	=>	'',
		'rawdata'	=>	null,
	);
	
	extract( mgenterprise_buildcalldata( $params, $transxnid, 'capture' ) );

	
	// Make our call
	// --------------
	$api		=	new SoapClient( $soapurl );
	$results	=	new SoapResponse( $api->fProcessAndSettle(
			$gatewayid,				// Gateway ID
			$merchantid,			// Merchant ID
			$appid,					// Application ID
			$transxnid,				// Transaction ID
			'Website',				// Terminal Value
			$testmode,				// Mode value
			'INV' . $invoiceid,		// Merchant Reference - Invoice ID
			$amount,				// Amount to charge
			$currency,				// Currency value (ZAR)
			'',						// Cash Back Amount (ha)
			$cardtype,				// Card Type
			'',						// Account Type
			$cardnumber,			// Credit Card Number
			$cardholder,			// Card Holder
			$cardccvnumber,			// CCV Number
			$cardmonth,				// Card Expiration Month (MM)
			$cardyear,				// Card Expiration Year (YYYY)
			$budgetuse,				// Budget Value
			$budgetterm,			// Budget Period
			'',						// Authorization Number
			'',						// PIN Number
			'',						// Debug Mode
			'',						// eCommerce Indicator?
			'',						// Verified by Visa something
			'',						// Verified by Visa CAFF
			'',						// Secure Code UCASF
			'',						// UCI
			$ipaddress,				// IP Address
			'',						// Country Code for shipping - Fraud Module
			''						// Purchase Items ID
	));
	
	// Save to our data array
	// ----------------------
	$data['rawdata']	=	$results->toArray();
	
	// We have results without errors
	// ------------------------------
	if ( $results->get( 'Result' ) != '0' ) {
		$data['status']		=	'declined';
	}
	else {
		$data['transid']	=	$results->get( 'TransactionIndex' );
	}
	
	return $data;
}


/**
 * Refund process
 * @version		1.0.0
 * @param		array 
 *
 * @return		array
 * @since		1.0.0
 */
function mgenterprise_refund( $params )
{
	$params	=	(object) $params;
	$data	=	array(
			'status'	=>	'success',
			'transid'	=>	'',
			'rawdata'	=>	null,
	);
	
	extract( mgenterprise_buildcalldata( $params, $params->transid, 'refund' ) );
	
	// Make our call
	// --------------
	$api		=	new SoapClient( $soapurl );
	$results	=	new SoapResponse( $api->fProcess(
			$gatewayid,				// Gateway ID
			$merchantid,			// Merchant ID
			$appid,					// Application ID
			'4',					// Action #
			$transxnid,				// Transaction ID
			'Website',				// Terminal Value
			$testmode,				// Mode value
			'INV' . $invoiceid,		// Merchant Reference - Invoice ID
			$amount,				// Amount to charge
			$currency,				// Currency value (ZAR)
			$chargebackamount,		// Cash Back Amount (ha)
			$cardtype,				// Card Type
			'',						// Account Type
			$cardnumber,			// Credit Card Number
			$cardholder,			// Card Holder
			$cardccvnumber,			// CCV Number
			$cardmonth,				// Card Expiration Month (MM)
			$cardyear,				// Card Expiration Year (YYYY)
			$budgetuse,				// Budget Value
			$budgetterm,			// Budget Period
			'',						// Authorization Number
			'',						// PIN Number
			'',						// Debug Mode
			'',						// eCommerce Indicator?
			'',						// Verified by Visa something
			'',						// Verified by Visa CAFF
			'',						// Secure Code UCASF
			'',						// UCI
			$ipaddress,				// IP Address
			'',						// Country Code for shipping - Fraud Module
			''						// Purchase Items ID
	));
	
	// Save to our data array
	// ----------------------
	$data['rawdata']	=	$results->toArray();
	
	// We have results without errors
	// ------------------------------
	if ( $results->get( 'Result' ) >= '0' ) {
		$data['transid']	=	$results->get( 'TransactionIndex' );
	}
	else {
		$data['status']		=	'declined';
	}
	
	return $data;
}


/**
 * Common method for determining a card type
 * @version		1.0.0
 * @param		array
 * 
 * @return		string
 * @since		1.0.0
 */

function mgenterprise_cardtype( $params )
{
	$params	=	(object) $params;
	$type	=	$params->cardtype;
	switch ( strtolower( $type ) ) {
		case 'american express':	return '1';
		case 'discover':			return '2';
		case 'mastercard':			return '3';
		case 'visa':				return '4';
		case 'diners' :				return '5';
		default:
			_e($params);
			_e(strtolower( $type ),1);
	}
}


/**
 * Determine the correct Gateway ID based on configuration settings
 * @version		1.0.0
 * @param		array
 * 
 * @return		string
 * @since		1.0.0
 */
function mgenterprise_gatewayid( $params )
{
	// We objectify things in 2014
	// ---------------------------
	$params	=	(object) $params;
	
	switch( $params->devmode ) {
		case 'on' :					$gatewayid	=	'01';	break;
		default:
			
			$gateways	=	array(
				'FNB'		=>	21,
				'ABSA'		=>	22,
				'NedBank'	=>	23,
				'SBSA'		=>	24,
			);
			
			$gatewayid	=	$gateways[$params->institution];
			break;
	}
	
	return $gatewayid;
}


/**
 * Common method for grabbing the budget value
 * @version		1.0.0
 * @param		array
 * 
 * @return		string
 * @since		1.0.0
 */
function mgenterprise_grabbudget( $params )
{
	if ( isset( $_POST['ccbudgetslxn'] ) && $_POST['ccbudgetslxn'] ) {
		setcookie( 'mgebudget', "{$_POST['ccbudgetslxn']}", time() + 600 );
		return $_POST['ccbudgetslxn'];
	}
	else if ( isset( $_COOKIE['mgebudget'] ) ) {
		$data	=	$_COOKIE['mgebudget'];
		return $data;
	}
	
	return '';
}


/**
 * Common method for getting our ccv number properly
 * @version		1.0.0
 * @param		array
 *
 * @return		string
 * @since		1.0.0
 */
function mgenterprise_grabccv( $params )
{
	$params	=	(object) $params;
	
	if ( isset( $params->cccvv ) ) {
		setcookie( 'mgeccvtmp', $params->cccvv, time() + 600 );
		$data	=	$params->cccvv;
	}
	else if ( isset( $_COOKIE['mgeccvtmp'] ) ) {
		$data	=	$_COOKIE['mgeccvtmp'];
		setcookie( 'mgeccvtmp', '', time() - 3600 );
	}
	
	return $data;
}


/**
 * Common place to build our data
 * @version		1.0.0
 * @param		array
 * @param		string
 * @param		string
 * 
 * @return		array
 * @since		1.0.0
 */
function mgenterprise_buildcalldata( $params, $transxnid, $task = 'capture' )
{
	// We objectify things in 2014
	// ---------------------------
	$params	=	(object) $params;
	$client	=	(object) $params->clientdetails;
	
	// Determine our URL first
	// -----------------------
	switch( $task ) {
		case 'capture' :
		case 'refund' :
			
			switch( $params->devmode ) {
				case 'on' :			$soapurl	=	'https://dev-enterprise.mygateglobal.com/5x0x0/wsCCPayments.wsdl';		break;
				default:			$soapurl	=	'https://enterprise.mygateglobal.com/5x0x0/wsCCPayments.wsdl';			break;
			}
			
			break;
		case '3dsecure' :
			
			switch( $params->devmode ) {
				case 'on' :			$soapurl	=	'https://dev-3dsecure.mygateglobal.com/ws3DSecure.wsdl';				break;
				default:			$soapurl	=	'https://3dsecure.mygateglobal.com/ws3DSecure.wsdl';					break;
			}
			
			break;
	}
	
	// Lets see what mode we are using
	// -------------------------------
	switch( $params->devmode ) {
		case 'on' :	// DEVELOPER MODE
			
			$merchantid	=	$params->devmerchantid;
			$appid		=	$params->devapplicationid;
			
			break;
		default:	// LIVE MODE
			
			$merchantid	=	$params->merchantid;
			$appid		=	$params->applicationid;
			
			break;
	}
	
	$gatewayid			=	mgenterprise_gatewayid( $params );
	$chargebackamount	=	'';
	
	// Grab our budget cookie if set
	// -----------------------------
	$budgetterm	=	mgenterprise_grabbudget( $params );
	$budgetuse	=	( $budgetterm ? '1' : '0' );
	
	
	// Set our mode
	// ------------
	$testmode		=	$params->testmode == 'on' ? '0' : '1';
	$ipaddress		=	( isset( $GLOBALS['_SERVER']['SERVER_ADDR'] ) ? $GLOBALS['_SERVER']['SERVER_ADDR'] : ( isset( $GLOBALS['_SERVER']['REMOTE_ADDR'] ) ? $GLOBALS['_SERVER']['REMOTE_ADDR'] : null ) );
	$browseragent	=	$_SERVER['HTTP_USER_AGENT'];
	$useragent		=	$_SERVER['HTTP_ACCEPT'];
	
	// Invoice Variables
	// -----------------
	$invoiceid	=	$params->invoiceid;
	$amount		=	$params->amount;
	$currency	=	$params->currency;
	
	// Credit Card Details
	// -------------------
	$cardtype		=	mgenterprise_cardtype( $params );
	$cardccvnumber	=	mgenterprise_grabccv( $params );
	$cardnumber		=	$params->cardnum;
	$cardexpiry		=	substr( $params->cardexp, 2 ) . substr( $params->cardexp, 0, 2 );
	$cardstart		=	$params->cardstart;
	$cardissuenum	=	$params->cardissuenum;
	$cardholder		=	$client->firstname . ' ' . $client->lastname;
	$cardmonth		=	substr( $params->cardexp, 0, 2 );
	$cardyear		=	'20' . substr( $params->cardexp, 2 );
	
	// Zero out some fields for refund purposes
	// ----------------------------------------
	if ( $task == 'refund' ) {
		$chargebackamount	=	$amount;
		$amount				=
		$currency			=
		$cardtype			=
		$cardnumber			=
		$cardholder			=
		$cardccvnumber		=
		$cardmonth			=
		$cardyear			=
		$budgetuse			=
		$budgetterm			=
		$ipaddress			=	'';
	}
	
	// Send the data back
	// ------------------
	$data	=	compact(
			'transxnid', 'soapurl', 'merchantid', 'appid', 'gatewayid', 'budgetuse', 'budgetterm',
			'testmode', 'ipaddress', 'browseragent', 'useragent',
			'invoiceid', 'amount', 'currency', 'chargebackamount',
			'cardtype', 'cardnumber', 'cardexpiry', 'cardstart', 'cardissuenum', 'cardholder', 'cardmonth', 'cardyear', 'cardccvnumber'
	);
	
	return $data;
}


/**
 * Common means to wipe out sensitive cookies
 * @version		1.0.0
 *
 * @since		1.0.0
 */
function mgenterprise_wipecookies()
{
	setcookie( 'mgebudget', '', time() - 3600 );
	setcookie( 'mgeccvtmp', '', time() - 3600 );
}

?>