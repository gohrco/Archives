<?php
/**
 * MyGate Payment Module for WHMCS
 * WHMCS MyGate Module:  My Enterprise
 *
 * @package    MyGate Payment Module for WHMCS
 * @copyright  2014 Living Technologies.  All rights reserved.
 * @license    Commercial EULA
 * @version    1.0.0 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      1.0.0
 *
 * @desc       This file is used to execute hooks in the system
 *
 */


if (! defined( "WHMCS" ) ) die( "This file cannot be accessed directly" );


/**
 * Function to add straight or budget selection to form
 * @access		public
 * @version		1.0.0
 * @param		array
 * 
 * @return		HTML formatted string
 * @since		1.0.0
 */
function mgenterprise_straightorbudget( $vars )
{
	$vars	=	(object) $vars;
	$html	=	null;
	
	// Build our options first
	// --------------------------
	$options	=	array(
			'06'	=>	'6 Months',
			'12'	=>	'12 Months',
			'18'	=>	'18 Months',
			'24'	=>	'24 Months',
			'30'	=>	'30 Months',
			'36'	=>	'36 Months',
			'42'	=>	'42 Months',
			'48'	=>	'48 Months',
			'54'	=>	'54 Months',
			'60'	=>	'60 Months',
	);
	
	$optnhtml	=	null;
	
	foreach( $options as $k => $v ) {
		$optnhtml	.=	'<option value="' . $k . '">' . $v . '</option>';
	}
	
	// Credit Card Page
	// ------------------------
	if ( ( $GLOBALS['templatefile'] == 'creditcard' && $_SESSION['orderdetails']['PaymentMethod'] == 'mgenterprise' ) ) {
		
		// We must pull the balance 
		// ------------------------
		if ( str_replace( 'R', '', str_replace( 'ZAR', '', $GLOBALS['balance'] ) ) < 1000 ) return;
		
		$table	=	'<div class="control-group"><label class="control-label">Straight or Budget</label><div class="controls"><label style="display: inline;"><input type="radio" value="0" name="ccbudget" checked />&nbsp;Straight</label><br><label style="display: inline;"><input type="radio" value="1" name="ccbudget" />&nbsp;Budget</label></div></div><div class="control-group"><label for="ccbudgetslxn" class="control-label">Budget Term</label><div class="controls"><select name="ccbudgetslxn">' . $optnhtml . '</select></div></div>';
		
		$html	=	<<< HTML
		<script type="text/javascript">
			jQuery( 'div.col2half > div.internalpadding' ).find( 'p.textcenter' ).before( '{$table}' );
		</script>
HTML;
	}
	
	// Shopping Card Page
	// ------------------------
	if ( $vars->filename == 'cart' && $GLOBALS['templatefile'] == 'viewcart' && isset( $vars->gateways['mgenterprise'] ) ) {
		
		if ( $vars->rawtotal < 1000 ) return;
		
		$table	=	'<tr id="budgetselxn" style="display: none; " class="newccinfo"><td class="fieldlabel">Payment Method</td><td class="fieldarea"><input type="radio" name="ccbudget" value="0" checked /> Straight<br /><input type="radio" name="ccbudget" value="1" /> Budget: <select name="ccbudgetslxn">' . $optnhtml . '</select></td></tr>';
		
		$html	=	<<< HTML
				<script type="text/javascript">
					jQuery( '#ccinputform table tbody' )
						.append( '{$table}' );
					
					if ( jQuery( '#pgbtnmgenterprise' ).is( ':checked' ) ) {
						jQuery( '#budgetselxn' ).show();
					}
					
					jQuery( 'input:radio[name="paymentmethod"]' )
						.change( function() {
								if ( jQuery( '#pgbtnmgenterprise' ).is( ':checked' ) ) {
									jQuery( '#budgetselxn' ).show();
								}
								else {
									jQuery( '#budgetselxn' ).hide();
								}
					});
				</script>
HTML;
		
		// Wipe out our cookie
		// --------------------
		setcookie( 'mgebudget', '', time() - 3600 );
	}
	
	return $html;
}


/**
 * Function to intercept a posted field and store as a cookie
 * @version		1.0.0
 * @param		array
 *
 * @since		1.0.0
 */
function mgenterprise_budgetcatch($vars)
{
	// See if we have a budget selection
	if ( isset( $_POST['ccbudget'] ) && $_POST['ccbudget'] == '1' && isset( $_POST['ccbudgetslxn'] ) ) {
		setcookie( 'mgebudget', $_POST['ccbudgetslxn'], time() + 180 );
		return true;
	}
	
	return false;
}


add_hook("ClientAreaFooterOutput", 1, "mgenterprise_straightorbudget");
add_hook( "PreShoppingCartCheckout", 1, "mgenterprise_budgetcatch" );
