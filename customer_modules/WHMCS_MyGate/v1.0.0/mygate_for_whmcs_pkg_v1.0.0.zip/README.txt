=========================================================================
  WHMCS MyGate Payment Gateways
-------------------------------------------------------------------------
	author      Go Higher Information Services, LLC
 	link        http://www.livingtechnologies.co.za/
 	copyright   2014 Living Technologies.  All rights reserved.
 	license     Commercial EULA
 	version     1.0.0
=========================================================================

1. Product Installation
-------------------------------------------------------------------------
The MyGate Payment Gateways includes the following files within the primary archive:
 
 mygate_for_whmcs_pkg_v1.0.0.zip
   |- /docs (PHP Reference Documentation)
   |- CHANGELOG
   |- mygate_for_whmcs_v1.0.0.zip
   |- README.txt (this file)
 
To install the product follow these steps:

1)  Extract the main file (mygate_for_whmcs_pkg_v1.0.0.zip) to a folder on your machine.

		mygate_for_whmcs_pkg_v1.0.0.zip            => /mygate
		
2)  Within that folder, extract each of the two zip archives into their own folders so that:

		mygate_for_whmcs_v1.0.0.zip      => /mygate/whmcs

3)  With the files extracted, connect to your web server using FTP, SFTP or another method.  Change your
    local directory to the location of the /mygate folder you created in #1 above.
    
4)  Navigate on the server to the location of your WHMCS installation.

5)  Upload the files and folders from the /mygate/whmcs folder to your [server]/whmcs folder.


2. MyGate - My Virtual Gateway Configuration
-------------------------------------------------------------------------
To configure the My Virtual Gateway product, follow these steps.

1)  Log into WHMCS / admin area with a full admin username and password.

2)  Navigate to Setup > Payments > Payment Gateways

3)  In the dropdown at the top, select `MyGate - My Virtual Gateway`
          
4)  Click on Activate

5)  Once the page reloads you will see the configuration settings available for the gateway module:
          a. Show on Order Form:  This should be checked if you want your customers to use it
          b. Display Name:  This can be any name you want to refer to it on the front end (something usable for your customers)
          c. Test Mode:  With this enabled, you can run test cards through the gateway without transactions actually taking place
          d. Merchant ID:  This is your Merchant ID provided by MyGate
          e. Application ID:  This is your Application ID provided by MyGate for the My Virtual integration application
          f. Developer Mode:  Tick this for development purposes (do not use in live environment)
          g. DEV Merchant ID:   (do not use in live environment)
          h. DEV Application ID:  (do not use in live environment)
          i. Convert To For Processing:  Ensure this matches the currency you are approved to transact in with MyGate
          
6)  Click on Save Changes

7)  Log into your My Gate Console

8)  Navigate to Products > Payment Gateway > Settings > Gateway

9)  On the row that corresponds to your Application ID as set above click on the Configure Settings button (note if you don't see
    the application in the list you must add the application in the permissions for your account under Users > Edit Permissions).

10) In the `Add New Referral URL (http://) field be sure to have these URLs in place:
          a.  http://yourwhmcsdomain/whmcs/cart.php
          b.  http://yourwhmcsdomain/whmcs/viewinvoice.php
          
11) Hit Save in the bottom right corner


3. MyGate - My Enterprise Gateway Configuration
-------------------------------------------------------------------------
To configure the My Enterprise Gateway product, follow these steps.

1)  Log into WHMCS / admin area with a full admin username and password.

2)  Navigate to Setup > Payments > Payment Gateways

3)  In the dropdown at the top, select `MyGate - My Enterprise Gateway`
          
4)  Click on Activate

5)  Once the page reloads you will see the configuration settings available for the gateway module:
          a. Show on Order Form:  This should be checked if you want your customers to use it
          b. Display Name:  This can be any name you want to refer to it on the front end (something usable for your customers)
          c. Test Mode:  With this enabled, you can run test cards through the gateway without transactions actually taking place
          d. Merchant ID:  This is your Merchant ID provided by MyGate
          e. Application ID:  This is your Application ID provided by MyGate for the My Virtual integration application
          f. Gateway ID:  You must select which bank your Merchant Account is held with that connects to your MyGate account
          g. Developer Mode:  Tick this for development purposes (do not use in live environment)
          h. DEV Merchant ID:   (do not use in live environment)
          i. DEV Application ID:  (do not use in live environment)
          j. Convert To For Processing:  Ensure this matches the currency you are approved to transact in with MyGate
          
6)  Click on Save Changes

7)  Log into your My Gate Console

8)  Navigate to Products > Payment Gateway > Settings > Gateway

9)  On the row that corresponds to your Application ID as set above click on the Configure Settings button (note if you don't see
    the application in the list you must add the application in the permissions for your account under Users > Edit Permissions).

10) In the `Add New Referral IP Address (e.g. 192.168.0.1) enter your server's IP Address and press Add

11) If you want to ensure every transaction processed has a unique merchant reference (invoice number) then check the box
    correlating to Merchant Reference Number.  Note that this number in the MyGate module for WHMCS is using a merchant reference of
    'INVxxxx' where the xxxx corresponds to the actual invoice number from WHMCS.  Using this option may result in unexected refusals
    to process transactions.

12) Hit Save in the bottom right corner