<?php //00928
/**
 * ---------------------------------------------------------------------
 * MyGate Payment Module for WHMCS v1.0.1
 * ---------------------------------------------------------------------
 * 2014 Living Technologies.  All rights reserved.
 * 2014 September 12
 * version 1.0.1
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Living Technologies  may  terminate  this  license  if you
 * don't  comply with any of  the terms and conditions  set forth in our
 * end user license agreement(EULA).   In such event, licensee agrees to
 * return licensor or destroy all copies of software upon termination of
 * the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPmTHEHOMzu5P+vkiDGVdhUlicSLdtvcEfPwiWG4MvpfDlSuU0D4X1REnkaPrXmWtznKZ+8p2
wHKw+5YM9qSp543fMteP/J0UR9NX+baxbKvAj2sJngeQxTFSrnjVkReBOy6B84k/7LYNLCNmDX/9
8Brt/sFwJKouLBNJxyRCuf7F0A1+uEqfa6+Qk+D0y3copevywHWLvU3MjwyPiFn1xrdJ2iXgde+W
+0ap9AkHWJ+LP1p3lrpxo1TZfmbGu0ycq9fejmv0Rq5boyNw9yV6K3ri2i+kYyv+/znPQIc2Z3kF
ZdfCUwQlLSBoR4mh4aCRrlA2uxxWCMsJ2mb/q3SxOWkQON3xrsHOP4Y0YXs2Q5lx9vBCWJCoNQKd
u8zoi8BeKampGhuBgwNOgQam8ReUgtWMzVhXGW7xMy18na7RgG9/G1+Ec4D2LYQ1/7GMlc8BG21O
tU55hsNS8PQgKwp5xFq3xb5VOUy/Unpm2borJRmY7yIbMGIrkl4KS5HpOWk4tZdYJmtSBct5hXsC
LOMhZmIwGpVe0W/mEl+DSv6nRFdVXIWf/wQT8G70jj8SjEJkp7z8TRIiHi2VVCVBobKMbXaV9NPj
jCCEZFPicDZVWXoV4nj6MWSJsrN/GlJpfFRX0XxLq29LY065dDVaKgvmhD5hmrUA14zcLxrJ8bu1
EUtSNV+d/h2ktQlfTEQAerxHEQaxJWEAcW5iSJQrpqlHXT+ix05S2VaxC6Szl6lyHgP+dCQ/w7g2
Z4t46dn3Zrh/+Qkcdt+jKeNQI4/leWPRzqTQ8UJOBgOElWezX5HV8Itz1djjiar6+vJZ6d0r0R3E
TA0i7YAoBB3w268In+DqK+3BerS72ZKBgtHds+luAxrg0hrJYWU5fikCSaCzv/cw5N4uX4evtOdI
s6uXAD3WofcPgaeikyQqbXTa/gmeyvSgqSEX2DwKxMDQBp5O6pPWx8/AppQ2UhkjDYToOCRr2l8m
t7i8ST2vxHsyZuOUd+5Ba3qRYAp4upJOMx5chduzeg2MFZVNji1z6Ktu8yWASJ7gUpPDhsc932CF
bXfdY2DwCTZUXSCr2XbYkpL58Kg0r+LIfVx9o091ft4ma3TPdy5PIBsNcD4Jg9xcEMnLOEuL95dS
7G5bf2ip4KZrO8loeFFNbqLUGzkB9pBSUKMrEJ3EDu6MDJ26HNFKgVMxxdO1HY0w69AvRp/q2DA+
L1D/P800wg9bc00Ngrqk08AXgEZ4KrSEaZkbVnx7jtczM2P/Fxu7Wdr4yZQOQ1UItZf9VWYQdyPl
2WDIw7tWiMj/AiHgXCAcwh7900vyWEzk/uD3Ic8qPhlDGWtyyONaUxO/Dbph4sALInBnDJhpZ4uY
lM9TxG7woUh8qF5/4DRlpyJDK4guoYV06xshJJk6f8OGqHCbfy4Jv2ONKdMlpZNnys4fasi9y6Rz
1ANYat6jz/SB9ZgzRCVIRmjMrzauEg+OcYupK4pCbGgssCAm0C6T7fmu2XyUbZ8xulNG7GZqRdMl
/RopwM/tJe5kcqmRJbidFYiU4uEmBhuLcPbydEPrC11v+SNuXct7L739MaWQcw9yqRW9c4aROtSu
OzrftjgFs0na0Lq1HLO/3vS2pe3KH3rwZ8P5W6XcVVnYn8yR/NzOn9KT9VEWNWceYDO8Xmco9s7o
VKuWayC+bNS+TNXbAg1iPPBHcoJjSh3iBKE4C7H2S0vDO71fB2zSW5ih8EeVmg9Vwp0A0P3zD0m/
E6la59qao7+WOYmVo2GqJqmoW6d9KLtkKjtys+wuW8dp3SLVWCmjH9u7o3wwe7idNKAucphoh81r
A93HM2pBFhYfOzndb6Wmh9Lx8htgrcSgnFqHD01oE6wwnsxuyB8UMPpnYwK+vTKsWyyAuS6w4T1T
fO7E+8abQKphDt3IDshAOPpASoJ0KPzZOqpyKg3YBc+E/Z5C/NbCG6Z1mONtJci05vonluDSOPVV
l/zkl7xyu13rCtcHiC33B+wGdn0YtfdT8nQI64bGNPur7SIPPXMnaxEHoUNAFj3ua3XqWTLmKelv
wbbN70QpBqsYOmCPM7Ae1SLXBdgjHjA3l6Nz/BIzy+UdEGoZoAt+xtrM5W0Jc5uX50jAZnn9hrsa
MaeVavMcI7cI8OdzWRiT2hYTJgq+7CRDC7+Tcbz5aTflTKxNow/VAR/eR5clTVDxcb8s4coe54mh
ylZqxNiaPdvnty3g3f8m+yGDBlgZvg5shHiCcq/cX8iZMH1Lm3irvRIHdrWQJu6wubG3lfzMApPQ
STwGU/27TpzhWzXrFg1Nd2KxdyBhjyyef8wOKQXc+Iom8VZB+++T4mQZ9dtvtn3rkct+Cj6y1zuc
+NCzi74wSsyF4C9WX+BEunIg9Xxm3gRizImMNE4lYBUsSBrFljgbb+TFdciwtgzLD6zsdZwC1Skp
AEHn8uiK6sT5FTtd93C763jNLT/cSluMZaE5RlkDoI3z0aww78sMZ8GaPAJSyRsWG/YTHhMiWCon
cluuimgU8g1GiVvQnjFv3zEDKdv1+PK5TFxFyh1ytuk7GO0VKtSIxnKbv7D+43fvBAjD3hwLcvsF
hi8PvUieqcdmZjkw0ClWYU71PBm22X7VV/ftA81AQhzqhh5+XX1HpvERc8fM1ztebqP3KWZ7VkKq
wk1MqH9C64Nhfato6K27BZ4L4TtjWRI9WqMJpQ/0anpu+9E5WW+BtBq0c73/jCQ1fncZBrjKVF7L
UYNz/RsIKgzfDM6IhsoezOr3HjKLr6Yu/MGBpfOteZ5EFPX+zLoNouMTxa7A6zHQ/kx7TVnO9JkP
l2qd/3PAWRwqPfWtpwzv5QM67SP/tGUpibaM6s8G28WRseFGGslMmrJDloF+BNR2VgzFTsJnxMB/
o1E8OFPyLEK1QVMnkFwYzj6XvlHmG0IP0b49QENVptvJYZNF1S24SZJA740t4RTH+tKR93huwg5t
vnY1BUpbIJkdG8FkJzFdN0issKWENKrw/uA8ZiYNZwYsiQElOldGGE2gEn8LLOSMVSp8ElFI2yLa
9NYXWfV/PGC+HzhtUstM9nAKqHT6+6V7D8SbGfrdIT+4xjI7f6Orj7VjfLazMabykjy5LQ9tVR0o
LIln83GI5VGnt1C+OYaInXMicYgG/nh895QMlfLBCTj/Cac6SWQs1IeQG5tARP3vm0fgLG/gdSui
L03e9GmNdLnirUDdeMnTOyonw55dvji6vywBXtuBku5cFco4Ei/t17MKojC2PJ3rwwXhmI6wsGf+
3ktJg//fIpxbomLU5k7ZlCW1/4P38QGLxWfve2gHWaHrjJFhk4QYkJa8uIUul7qDz71sZfCQJP4l
4DY2vVVS/qFR7dObHmbQPCtRZR3APrDcvIyxAq9F2pwR9b4Q9tY0c2HFRlof2bk7/pC2MIqd8z1v
O9JSQXpGfHp59lryNocLcD8YMRjxFLxZ334gIoVM+GGMAmwA1zgcpzr9iySBXXlHf085inzo4mYd
v06wN8pwCcOuxmtVjC4bOHuR6YOCDr8/+1kAWh0gH7sEnBXraY+UHbVN2W1niQZ6kU0C1doyNO+2
AGXPQn9sULaKgjstUn9jbEYuNeddvTYhKIJfDK2h8sKBZXIAjXRymo+XYXqW2pqUBQnzNLxUL2ja
WDilLAZTCXLZGowGijaqhGauMfnRvhtE9CdNfPdhiCPW/aUlci2VJ7QvzgIkAUfJVzdvds+WwaEC
s9lLqa9Gc2EHg/HohufRMXuVXc/C3+Q3EAX2RjwJWGQu1JBPxIOdh/uj8knKi3D0GzTiwfxDynmI
VAT1G0l70IjDg2qTp128twBO3mVGACQOrke4LctfzFpLPul/ywjrQuOl1FAQf9KpqHkO1tMIQLN1
ARRCuStMymNlvYkbQgr6+c9QRdnMNreU8tsoH9F31P2GRDPoaPVHZNcMM//8zka2kiufbdMiUC6e
E40xeTtnoAozQNfaEsBZG+V6MBuEMwCQiiu7GhdXDuCm79hW2XSnxKxDrdmnp8QhFaRHPucArHdn
BkClvt1fx+olRHRF93zEjW8X0BShp6ajQSMwE8oMvl2XqB8CFGItGkFNLuWv9Yolnc7YkN6jG7UG
soxnkoN6PiB39xhdXCkuG6yDc3tRYZHyzrbSlnnk5RsCb4ybLG0/E1duwm0jkK4P/bsRtTbDy/8Z
td/MP5Ma8SW6TpedgyU61qorJG58PNUs5PpLx+pqLnmlVA4isxjBxOderWfvqTHHhQ/yLoIJiWso
AQiwTpCbAo7raWElQ02F7bYnvoynxhqhys8OqvGrTBpo1GB0K/N/l0EeG9sHnepEAJTqS0xtyhoq
8LMDXDmMHS0tUmizqwjRuO8xW1WF0HyNsbD2NA5onRXmvpPq