<?php //00928
/**
 * ---------------------------------------------------------------------
 * MyGate Payment Module for WHMCS v1.0.1
 * ---------------------------------------------------------------------
 * 2014 Living Technologies.  All rights reserved.
 * 2014 September 12
 * version 1.0.1
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Living Technologies  may  terminate  this  license  if you
 * don't  comply with any of  the terms and conditions  set forth in our
 * end user license agreement(EULA).   In such event, licensee agrees to
 * return licensor or destroy all copies of software upon termination of
 * the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPsc5E6j/Ke5C4a2jIBMohdS8+ulBRHp1Tie5+2qJoolKGyyEWZGzJ/6/TPLQbFOFgus2IV8p
+sHsR3fHBL8TevrKjCKGZz3rvAjB6WQxKrSJ8H6oOGks1fSK+ly6sa4nev+USMU/OaafXLz0bdm5
NoKJwfkLy05bW8noX7XhjA6z0GJUnIPVMnI5xXemfqn2SdC4ufjBjB7NMaMu1Kl5TaSlIjk0t98c
g2O5Vf9n1OyD10l+gU1rOyl85sEd2L3W3oRGccYt3a1lt5dvs0wOYc3xtiKCTmq06t9XSwZUSl0J
rmQzoj+BjrbBslCTx+g0RQhZYH3QU8WSfmFXP9O98Gsl1HlDU5iCixI2UX8j3a89fHfV8mB5YAkx
MxcP/q99A4Yg7bcvD3zKDZX0NOxn9jCRKWFAs4bYmDixI98sRHczu1BeHxUshkESW+aMvpqckFhR
MMr+FYKmZIf7AvOf1fG115RvdBmD3xwLvv3KY18L3NuqNev5YKtIsRDcX5wuLwfKFzyWEyo7A2yN
F/cLmbY7HQCD01TwXeWHbwbxrCdTbc+Fnsq/vAXbowW1Izz4QrMysllqefnPMEQCw0SYP+TUeJP2
Vfqqw++rEtHCNot9emKiDhdsgR61BC5yzyh+ON3F6fRF6HJ1SxBE8S1Zz3WLH5rV0wCP9TejmfaP
6WppwqvI/RJ1oZMYxX+Qab8U59ENeVBTDoWa6kSXu7ZNgzUuWfRPXWevXXP0gfDFag58OaKCLeZI
pbhWH6Wv3v7ajc9B83MgD4ycQU2OtL92NKNPYfp/BU35ZJzLFtptMT8KcMSZQXwtentDkObsQyGI
JRV+PzJOD2Dfb+sH8MIbsp4Kdyfvo0SLChnKiaC80PN5B1DTY6vYITVC3nITfrO5KVeMcYC5aLJq
YeYN7EC27XdrKMlvTHtXT3YSLphczipYpnaVNGtbbp1efaI+TLeShdFyBP/erzyvQ4XoIDQcHvE2
tMCHoz58W2PRq7xcPBVmfYeIaXmjF+XEb5udmlG24rPvz/NqYiL71zXG9e/2HMMT/SwEyTlLyKpJ
Oy377Vq8Oow1y0690xhWXI4Ui+Y8airoPQDcYetESXUAyCwXCch5DTcmbbbDoACo7QUSdunh0fBc
CKCu/LRHukJjcS5PwcubbmG2ZnG76EU/ttp/a1d99Z5RHx37KcptKtIlLbUHDglJnNH4jU4R/BZY
otLhcaKzVJX4RqkyaNiHOvHDCSnjIA1Wx0BxodSIsuGZc6m3nSvQce0M53VMb+gIXx4ee+p2IFt8
CrAK+AjUl4h5TeyFcP0LV8cr4KC8H3HZLRYeLcL4VqQ8mBfiv8bDhdSL/IjsG4wx6/ycMmlk7wiA
24aAYJi6Sk9coIDRMeat6mL7ZYDsM9jtDEuJ1TiuPuvG6AD+51KRHtPTygCjrAHIwR0M4JqtOeM6
Wr3Fz08ReIfs/0oegiUGDso9wHgt4ncigMtK1Gt4zgmoHwLvijItoohC2IfLXtM+n9Q87lvxFtGJ
p0SRgKDhhvhxm+HdYBUY70rxky7Cc1jiQGhOlw5YyHDC3AqLBOkMNJIL+oxjZvmPz3Px+scM/s1S
CTPjOxu+8VJMSkn8emNE1Dl1Cr0HujuvsB23T4Grqy2O6mrXCqLlP6A7K/tr07SiyBw2FXMM1GNt
juLKzTF6M69FkllPfCkVTaXweJZld5PIlQTTY1DMmg+FRgIYD/yBG4xsNkjxQ/3W2Uv1l1DIr7TD
eqKNDhT7XJlTCxJxGIzgy0k3WV/WxG0vU7KOZGc6tsYUqDGqt4X4ruImVT9aT078q6g5dnSzz9Pe
E/uDAyi4MMrErfrFO+OmTRi56VNlqBbEDcv+e8M6/TqU/9utGFggUjybyG4IyqO7Qv2qnrGriSNS
RuT3ZrZIGozDjUCAdiwrpPup4yWlZRpHDF+0K6walAiiXHj6i5aIT7SDwBRUlINW+dW1nmJXTnv9
PuAzcvOKkRiOTkcJvDMju+aAHKf+FbEkC47YnLT6u9S0Za+gRx7quL+WjfyLjetS3t2dfuJDbkij
JPXP6USiR958eYYbbgwiqTbv34Aka2qeCTc9iDyxD4WKPW8MvVRQD97EeY7EBV+dH4XRqPhNpQWd
b4RVa9+NiQvqHQQktl4PtFrHo1arlOqnZ/0Yq/gzCNxSUKHMhaXI2O9REjDdTU6+mnQEduumUTIR
JQkfnMikBEkt6LBGcFj8vxQtw4o6K8P5P5fYyRQac5KLWzIY6eVhwtbazZTlYt8PVep6ANSIzr3v
fOXPAWATaOhRFbbbmeRdu0OVGhlAPe6EHZEhEFIzFanmo6T1oBsOT5XsCmyLqVZqVlwrjHJz23zb
jAl6B2tFkiaLkewS0CRvdSNuFwDjcXTVgMQmEnClxyQ8m9aNMuMXXTkCIJa5uuagXp2PiG9qK4Rm
6xqcA7Nm6c0ieXmMWkPFku1bl/RHh9/uP6Fe5SuNGJfL8DVFdbZXi720L2WUPkxTqmuxgnRM5Usk
OVrwOTZiXUxzuGxn6z+tQpCmGaxWVG+BWqty6BzOuiIeaKPXGbq2pqz3XyL061DgDH3WnaTJBP+2
c2KxAnFBd0M+m5BfyFJPlgVMI2YQ9usHpy6MNrxmphoynZ1MRoSmzkgoQpQcaOlYGhVGGBKw74X9
LgAJbo25Pr98p9eJR5QE5F+V/J8bQkw4Lf3Udx2cqS2qcL1ngcsEN2p5WDCK0wD7UbYoAbv4OSol
4PL5yyASBjLTRlgg/YDxv/9+9OVmok+55H74srOMWGb+K1Z96Yrt7Gb60vMDVOYlEHd31VmIVFpp
1I5BCIzLJinpIa+hSAuiyenB9hHFxdSrl29PTLQS5eZa/Dqz4TK7695W7T9XKr+zGf97TyL1E2bu
WI+CBKX69GzREhod7QoF4vLe3NFCIPtZx5HlLF2wuyKJwGqM6yxbfgt2LISl3m7SDy+XIUvd9PUP
Ob8QA2A22Q+tJfEUdU1CPAuFJnJmSB8hryK0+m5DeLkwnAp/Sbb9OymiE2vsM2oACLtFRgVemwCz
DMorRd3fKJ6gR8zxXM61gXEBOYyhwtpgEv55GiPOFZqmxu2SUas3/OqF4WmlCUnrm8D7fEZ0UiG+
+U81WIZuYuPmnmKsVGs3cLw+eKuLvzZmbeP6sypC87nVD5KYdZAdDGQ+7HWn6PtU8vr8GuIOoINq
Ll0nycrzNRRSoc4gD7O1nQqMKgrDjlF0DTgHROd561TyTgMcB/0wDgI+GBSgyYqqzqvvIpDpLbDh
4bjQVRp9y5khkTRt/kCvnynRAu6F5Kkj1JAy+7ruJWxyKz15UlD2iaQ8lhVCljghmElaD4uDMr8Z
yG+ZStwXJYOt3loSeETCXcP04SGNuwMHHOgt9P62cdwNCp4LzNxtzesLw0Snsr9OrcNG+WJXy0gw
AK+AdlrxhI+Oj19mtGVDiYxQWG9CiIBs842pU0B3HAS54Z7hadh/rnufhXE3mg5IlcmHaGCUSaqi
xp/fSl8Unv8FKdQeUqrEdDpWlLVNsm8q/ojBDYaui3T/oDQEMKtRf2SNsZODzrrGoTeCD58XjEPn
+iCtoHqsNaElgtRoKypRFNOGc9PR0v+khowFdA8XqkmdooxdOkzRu1u97LQg1LueN8jgh4zSW/Aj
30ypLsw/DLwQXQ/FAiLJeCwEm3DE/sg40DJmqSSZpE/0++XwWbvs9M1VVZXs8o/8xlf5TnCg260G
sQ5OZe/WB9uZpbjLx+jdwDS0XvDRyqf1Xfs/3itJDcit22EtiGEbjniRAM3uvRhe7JUl6r7eZ8Jh
lAKvVwV5S4AaVlzLOaji8u2XQe8xgP6b8O3By1sceu2IaoncDyz/rIyc4USdG3Jys8nDMx19rVSA
kW87kHPsAXZ8zuCBdn7H1xCduPS1XS9tpcaANY6YrtzumupsBuTSv+nZJkqaB2AF6aF6XvBepf2V
smTISCOpXZQJaTmVVOW81St85GwM3KtgeuXC51oExPyhqOpXJAEyB0qiRypn9MwsQvbj8Q/+TvLJ
ub8dEOUE7MEAphordSK0eis6XFVynehYzZ3HvH+ERlycJdEIQQ1oRFWoPG1h+MPdu0N7vl/hmG4X
RC89LBzQlLIaEt67La9dX2N/Rsd5nwrtvnTjB8Yfuo2tt0m8t60A/oYKZvRA4z0lXAXt2YmSLzSu
6Aa2yA6cEASmggJPWY6JUbkYuBk4DgZD2kLDnpHSgebWpAYiw2TthqDMeci99I9Db6kB5bQeXrvz
ipKcPIkD1bzc3SvM8O99W6jUSXFKjl+AMa21JLnuTqJeKBJzQwYV9Bi1sDf5BBn3w5RgRvFW9fR9
Oq49tP6F9FOJCDgbTnUyW92/ka9hOwMgth0rw1CRie8sBdE+uhqrwvvCAbK2XkPiuZirDZZRzReR
v6QO//LRDSKS6mhICoefn0l3HYslC82Z3oU6Dn3UeHjxkM5gz9Wbmc/7BcTTZpXWN34xUa9UMRhp
AjGIbWLudSjoy0lCqNTNeQOAtk0XIN6k303bPxytGAX6Uvc9p21mFmONo7/k8+RVTa34wei3//vq
bR79P49axAK6IoIHE9zJoQoAEoZZbSwN+hdCDnhw2LYPjt+BAnjMUEkFxepYLTLEqLYLdYoiPv3E
mxyrWKhi3pSBKIGwwsrHSzq8BIdR4HZpqj+LwkIhuFi/KwtLqMOFZonsBLgpUBzeWfkC4+Sqf84P
0z3O+HZCVT2iIunll7Mci/Q/AWHCqdLVK60f3I6F68bnkh/lPZaNY+p/3guWYxaYCeyWYVD/ORjY
l4hq/d41k9q++HiBIC3/51HtuHImc2dFbix2gY/sZOpCi4lVidLATELKTmi2oe4KVFdJjzg96PV1
PdigGnagTc2a9ZscGqR5Nv6FX1nexiqatJMmEa7nGZwxWuKQmQ3R/UNF+U59wDuZ7mdHGh93dGQH
PisybkJU5+nQCs/kA+1qKuSR/k3oWeWSbHKU0D+iYVzzwWlrJjojMvs5zZzPZMxUDCCRRxu8e+Zp
i2b/oZRadmIXDOg6o7mKuzqCP0nHQMPOr/P3Y/FVh1lvp7gSqdOIG+K990xT8hVHQqqse7e9acya
bcKYI90ZwnMGQZt3BejqZ/gLZ6pnQH3RTruOppfO+76uCdpFZ83Tt3V10Nif9v4njSnTD2YtmSOg
ZFccO/FLJF3wL0JX3MfHEiP4KeAtNWRd/dxXoXiqk35L4IZ0VW+9vpS3h8FR11Btm/nqeceJfLjS
aivnxmfN2NBrhDimt7KYlA7Mhz5HFb/N/H7qGBoLGOJVA4eob62A5xfM1nTz4+f951Au5KGMJvDt
VzAUXOQPnIkKZm0lpR3tJ2J3JWEVNBzm8Gf7kzBO++MLVPTlA7lnVZO0vVX2gBNvva0rS4AJiHSu
srISpOwOzYbUSiFBj4ibCtRyimJzh3O29xhmxo8czsePFVjbevBEYO4VEhUK50X69Sm1KBz69gQx
/EY/kVyXI+drtP5AMAFPQ8RDBIVhj6iqIQytNGaDQlA+qMOFgp5Ibzzf8uPLDNigm7eH9Nxb808Y
nU3WnoyC/xmg+wBmcemT8/v1kk2L+Iu=