<?php //00928
/**
 * ---------------------------------------------------------------------
 * MyGate Payment Module for WHMCS v1.0.1
 * ---------------------------------------------------------------------
 * 2014 Living Technologies.  All rights reserved.
 * 2014 September 12
 * version 1.0.1
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Living Technologies  may  terminate  this  license  if you
 * don't  comply with any of  the terms and conditions  set forth in our
 * end user license agreement(EULA).   In such event, licensee agrees to
 * return licensor or destroy all copies of software upon termination of
 * the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPvRoLot5Qgm2X3Z23ch7wN6C5D6lcVyJDEHCPXQ+gUazrQ+1eaigSUP2h43HZZBqxzFQHf0l
uu6w9gq80U0mVeCwg3z4WxuPtvBhX7lrni7Pih+RxYHE4wbbztrBq+6z5rzhwtiqwh5VofR8DEi6
as6jz9GgtpWvFT6KNAkhFOB4c8q59aE/94ShKeG5Hh57lFFLcF/4KHIgxKuQ5vqU+tpFRHBj/uWS
SS/bFy5E6jSM8/QEsI+ErCWNOwS9KE0F9j2QQBSEG6yMPbM+dm5oXpdSCZdlJ0pFN//+4ELh53gH
Ed/XMqH9HTVmpjAvaPVSBjd9XaOs2TBF//AGT4jL3AJX5QxpjR/DZw/D/1VecFvhrh8JUU+DEfuB
zmYF1D75iwkXa7nxqxGj+AwWgMVtpKeAkdsFV2KARBe7Vgf/fEypULcG4S1CNnxsIptnfQdPyyWa
ObIXDid0NCJEWztzd1u5e2vyaMEzJm9+ye0TkmpfpdSgTq7s9Pd17g1okpGFZIrWri8n/pK78EqG
bhwW5SQK8G863tMzAOxiZqDMqkk1C2M/d1txe2qbSQe7TfXOrlB8rmXcJQdym/xWNA+h+d7VHmLM
MYTKq1FWNiwX6rjQzBLwOwR8fcv0TvmGLOR6ZY644lLsxiT5ZGRM0DihU6OSpBSS4954I5ud/DRv
DudKJd3fKTO0H4mMRMsssW1TIW81CYikwsP3TiprJNRKzQhSX7/lnzCSUkcBWDng8Yh/fP13O2UA
kv53nxmsE0jUl6GKwQjwdkLfz5joB0/x8kJaWD1e0RI8lI0CZz+K/2DbA/wIiBYHWAvuPzECf09y
3L460diHv+Yg4TthHDrULMCGBNmIWY3l9UK+gmmFU8DsxdGErGtLiLjyC57hv4L16qPPRjpyYqzj
ZxXaHwhTevETZPQIGfjsbpf8i+cK4w5k/Mc9o6KPOfyLXsjaG0Wgjj+OxsuGGiQuqV3CvyfbfHZ0
vbaTFYZ/hJrCydzVl+C9RSKsKwBibtDvZIalaIOUg2/wlswv/oxMAy/ISDgg+Wq2evkOZBjAqA2o
jPuQ1lDqxUkeaybDzfM4bAR42+8OFQ1K2KmtLCl/8RJ+a+AI3kglrsoLtXBN7UaCoGKfDvh93pXH
Sk6IAiw2VjIEKHqJEe6+NeUfLkK4xKzi79g6SlUPzqKgXSnWIyjx4iTDx+HRrC02OsTAu6LD3DYd
x0C3V1a1J3+WgFT5XuYZ4n3Ub8F0Md0J3/uXStfNnwGED7j/3PSF7lJhoVwrL5MqX4XRIzoyvkb/
Ia7WqdgUK286qxUoVzMykCcYr9hlICx5yZIBKUdtmF9DLl/LaXuOgDcnEEeXkFpehZyCSg+nGC+M
Ed2lp0BOd8ut/jfvx3RoVsxgqsIYsVCAGGrfD1i6wyEvRM023PqSACYFAMk9PphXruU9j9fpFu7S
2QivZ9H2Ki0CPBzkOqmG3eJPjz+W5EoHaIi6w3uA7aEy7t3KstE9Jf9prSrsMaY91muN4MR7mcF2
wtT0OJuNfcl424p0tnm18audadCV26ZQVJbWyzJoWAW8yREWu8aBb09J/yrv3AFb7QUv1vRsCPV8
wzu92bHv7dSzPDnXO0+9QmA9SV0hMc66Jqk+QFY/6tM/50nfIN/RD3UbYPx6zir71R6I2wUbE2Pi
cPnlH7zd/nC5HKJNKkXY072jqBTzcuDaQLbsnHuc0yU+gytGvG9WnrOb/AzGHmCsKAz5kIzxipXO
cmjYFrielfBH5frL5iGI6DBo2ZyIZBIVdb3INTIWw1Q7JXhfKsFN0qbxU7V2uyvD7QgXGzzr/ket
mQguFcPc6j9mh5EU/n02lNbW25Z5D5Vx3G8Axco/kldBDnU4j+anVSJSOh3g1X2r19qBzqke57Ue
94UM68DRm0oR1LwkMzV3KvACjyX3hYSbBBZr+5xsykmhmlVKH2Y97FdLHjR97gX9RwCHoNkaimpK
MA0KmPCnI3wIP3A5R3zH0xwlUfxgPOQZvVxSHdkxj2WCf5qdkdlbAxNS7dnD4bkP98evcWGD/wFt
TszZNzB4u4ZjilvbXXtibuFedJHArqdIotoMPh+6jQbInRsquHWCntpbg1s4EPuUZUmCXu4rH55F
23hzR3v8cYaLUrfz4uXylCdtsPhT9yYoUWAYiVBaOdVPqmpT4OJXB6uIiW8QAWwd11ZDDKkzIcZ/
Qg4UMMjAt7HbXU3Nd8AxBKmsdHN0f2PD5zGZFoEIMOsjMEkonNz6af5judlz1C8PuubRZ+hch2xQ
bL1ob4oCumXDxCU71ofUIBOxbNb2BkGTTr76pX4uObBdntaV3uST/LU8VsLcd7ETty4N34bWJpZk
yHnKqoW/il3GR/yeHXrkaN+87tOoTgyM5+Vmy4ytxTLumJv+np1/YA65MvHpWe+fDdTBPUYU5n3E
376ros04B3e2mHb9UKlgSpFQun4ItKUIF/rhEyUsUwv7swe0HRRUyroj0xJnFlAiMgNcSrJMBPxD
sY+eAbJwTIDNEi4qSs7rMn+hOqORkuHwsOBC2+1V2cuU/Cx5GayfSzK+dJG4Ukbbmmq4m5zEO9Lm
3PMtUgPUxsku8zQrWNoGcyCYsxDIJXHdlxHvQNSavnjt7DDv3+HxFseL7qES+/w/Vubl3f0ujPX7
1EQ3IRqshi5jCmzMzrox35KD9L9/klpk1QaCJHRwBc7o8tYXLMqg/na8b4YCbcZwEi03ssM1g2NK
oL1wm1NohLY4JEzBtHCuDRblQ/+xqeDniINCrpIEQtzECFwt2Qkppluh/vvxEz7vbLUCbwXe6jfd
nvN3TMJTwnJUwrjECsKfT9EvmGo1D8qNE1L4ErnMtwi3U/pxjE1szuMUYdMWyG+4y7DsNQ+PA5ID
zIUT6QXfQ2svtrwRtlm0jz9Jtc5QdEoIcC47Wz+aKA0z8/QPQeZVJoaRRDzRbGy1aQVUB9rFaWtQ
m++3mOAKVkGHAvVfr5GHcF0pj1w9IsqBpeS/+uCEy1kvok5yg3lAOpPikVllxg6NxxoEI554P8je
eJFBIDi1EgTNz0SVuXjeBn3anWBRaSFqMEsqlIrLocakiXAo7TastnB0UeUbFtNn/MBY15c42dJE
KWchmR1wucVMDSQmJf2y0KFvAFGqjd92d5kDH0uj/GFbefjx/AoYkV+bZmD3I7NjR1RILmm5QZ5G
UrYt/fTXzzfuMBLpUfbprlCUdALyxU6LU/S43BJHVzNCxoxslFtEkSrWOPpNmqmaNucVKtPfQhYb
RYOnanr3GHKFNL5v9WK7r9T2YBxu6B078zRWGwxrcWzkpyHLGbVJLxtxTSy/tPkqYnG6xnhylxEd
aRtNXULJRDcwycvgpUAlzeJvaYapFmGbhr/dxMso8tow+ChvRiRR7qJ6COBnAThvrjegOJIhAZhn
0I7FVc/e/ROAjbGich5pSDDlXL42XFKgj0gJEGUysJCPDwaOV8BxTUzjWrR4I7sBVGpPYwdGAv06
P15MqYZItjv/d+Iq7udXuU+v0wMAGoW3HjTrMH2k0+5zSBLqSDdp0TAn8fWiQJiQXgU6L+/UpKwS
1H+7D018ByF35ODGUokVYOXyartG9bahKnD1/uRzw8eQLDFYHBVDPEimjgCNouZQheKprqOvAypb
LAJup54hvDK9Ml+hc9DJU4wV5JdxfEKbj7eVJ/Rcc+k/a0ekaubN31N7wFffrLEVgo60EthS+c8H
9VXpo4ICv1eEPv2rpw4NW/nzJchGizf4/wYH3YS12nsF+crWfHHcAAMfhgZPhqrbTDtSkhjRBE2u
ZSvmTtbpPJwQM/1Gne5E4CGiOnQGqq+TBVu+ZFCIht4AI8SOHXZNhaE7c8bRAvOEn1UJxnKMaFRp
9C6dMIufB7MOf+2Q/jDmJX4weOHfv38bpbXg3Q6hzxhyRHSk7wW7NsbT2g4Y/o61QbKgAhf8xZFq
OsXBkHmAhTpsHMSzmuihDKrkgq2xDcK1Rknask9zPYUduaRa6D2lToBO9bT8zsLoVvEossVnSIOT
LfAaQ0EGeR4LIt3E+yvadCO5SQUdFgZsninidiq+uqFizXdZtn4LPF9dEQt5VlC3pbhjr1hamlcl
OGrA0J7Z1PzPXGrDnuKJhfuvW15reUS5t2VzDOgcNgUSCrCVpRMlNqh6PpKsHnIJvTSCF/8f++4V
VH+gfrGdiRcrtyC5JjhdaUHYU+loMawz7LrlXqYyB7cHMbhmL1QbCk8Jj8FQuP8otYBUXrgHqYOc
7ittAciBQ5UILXhDpyL5yD6ZkNwdv8f4ayhrsCjfwQR/glpK390LL/1KMopUd1IlomiioVMvbUbl
ZfrLvqwOxWXJLhb1psNbR1pqdKgQeyhj+syGRQ7yi7DgoiKU0FXKE+SYxphqxaHItZSH16e+cXjp
6k52yBRNNrxqJ/mUlvGBjghZtjjN8m2RH5s96dDYALxpepA6t3QnDUzSWMc8dFC7zINUfUTC5Idz
816wnClUvu76MHf+jk+SfqfwAxysdLUBNIvD4W4294QwJjXwqxBoGkus9KK4z4LletEKdEaO36YE
p4gIV7BjH7uHIQF0kRo5DeV3KgY/XeRDPi3xx3M7jEDLZbS=