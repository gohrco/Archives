<?php //00928
/**
 * ---------------------------------------------------------------------
 * MyGate Payment Module for WHMCS v1.0.1
 * ---------------------------------------------------------------------
 * 2014 Living Technologies.  All rights reserved.
 * 2014 September 12
 * version 1.0.1
 * ---------------------------------------------------------------------
 * 
 * This software is furnished under a license and may be used and copied
 * only  in  accordance  with  the  terms  of such  license and with the
 * inclusion of the above copyright notice.  This software  or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person.  No title to and  ownership of the  software is  hereby
 * transferred.
 *
 * You may not reverse  engineer, decompile, defeat  license  encryption
 * mechanisms, or  disassemble this software product or software product
 * license.   Living Technologies  may  terminate  this  license  if you
 * don't  comply with any of  the terms and conditions  set forth in our
 * end user license agreement(EULA).   In such event, licensee agrees to
 * return licensor or destroy all copies of software upon termination of
 * the license.
 *
 * Please see the EULA file for the full End User License Agreement.
 *
 */
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if((@$__id[1])==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted. Ensure that you use binary mode when transferring files with FTP and disable the 'TAR smart cr/lf feature' if using WinZIP\n");}if(function_exists('_il_exec')){return _il_exec();}die('The file <b>'.__FILE__.'</b> has been encoded with the <a href="http://www.ioncube.com">ionCube PHP Encoder</a> and requires the free '.basename($__ln).' <a href="http://www.ioncube.com/loader_download/">ionCube PHP Loader</a> to be installed.');

?>
HR+cPmmXH+jsfhlC6+pIoCGdylZQIR3CjPTuqyL9iMj4rvwlScPcM1d+Y4nQgxD9y7F5QInUnQO4
v9/iHSua9k27igv2kOn+ooPhS/KrS8C61ziAMfLEnKY8aI0PURx7SOY9ZFHKJPrYSyCRzwvUudRB
sY1xn5IDcJ4OwYVdNVjsNoMJfiCGh3ylg5EKJvT6ECQ5xmborbiQ1Pgx78AzndUVVObKUbMariXn
AW7xr/a2YDP38u0txMsBwyWNOwS9KE0F9j2QQBSEG6yoPL3rsZlnd6KutHtlL1BFAF/srpP3zo9I
svbyy5d3xtSg78FGAAjPOKYOn7c1jpjzhwfVqy9V/MbW/4qK6BFLV3zqFZ956dXaIX1pvmPXzJes
gktVVMdz0uKIuaqf/P3+DP8OZFs0y51+/wxP8ERghZ9JLMO3SufiqLGU7F94q0w+DfnaS2/Rvf5v
3T2hXMziTdxEdacsLOaZY5yNwnqthzXOsYFlzwNR39d1PDi3qE0Q9TsZGZLk1JqwYkBe/Otwyo7a
ylLKNVNwirosI7z5bAf91ymdISdHzgUryXNegu779rMHMmKbAYqnB5jJbLpoocL7UBcC/kSRWvM8
rpszsuoJ0zhmaLVvO+LEgYEMBu5m5l3TdMgyfZ9zhdTzplbkIb48jknzm16G7NeHX0mh/o6oMbXc
R3ZM3GjEyJQQ2b3MZXF07a1uDWWgEJ3G6oUjGhgBFjIAqctWKdAYmVeiCJXWjvlDwsQAD6ENuIu7
FOfF3kxZlMbNVLBaf11eaup53DoZtHI2gVjqNJK3xWkrKvRNGEDyhFYiC2hMi5//XsKQBLVn74Eu
LQQ/JpBLrMooNu+YVF9i4btX1ABgJ1croRfG+YnNb+iaaW/mJs0SaCDweJeMEwIA9gYCkG3iXU8Y
jWpMdAkzmhuYiFRHjkEf9ARTic58krPm1g9AwQD3r87OrQctfDhmmeAymii9+XPO4PSMs4O9OJ8h
gdVXvejriFa9sqTHBg6RLw5U59JgEpFw//+v2vNnpDl3nAx2+olWs58mB9A0NcFnmOKvgogM2ynM
Ui7uW6fqDx9Qf6HhtOMOsrlik7fuODo/7PzKuFSsmScATAsx/u/jxPpsnyX/1M4Rkf0wLHOE/Yki
gdBkFW9JzH4ANET5FhXzPT54yb1TCmT1Yn1WwtQQvCIUkNvlPkUO4NwF0Th6g3u6QZ1MEWUoOCFf
BvGobluzSwTCKUysDj06miJ63arFxY1W/DYCyos/vNQ/agl2xsmkbFdRW5o8EaS9aWY4DpCTiYrs
wuqDPQgDG1jquhBmVBciwjKGjAWjorouZqgEGWFiCOk8Ul+c0lHsk12CuDk4Ci+FY4OuhcCO3lru
7AiLcF/p30cXA2hwG1Ku0ryTLbNL/b/TScV87cLE8DdlbhwVtvgu/l7zw1k2qq/FjkFwBj3lEZK5
I52hwGe+9CEol3JpYkXD/blkcwqP3IOaEpG3QRaFGyBYZ1vJlOyGki5U/xcfidaXnvJlSz0BsuaL
VEM7E5An4/DyxEeMLU6CkHTIA8ldtS5Y+v1swUi9ycqlyv5yZsau6C9tf/9FWxYr+MxIQ4M/9iTl
ClGScMZ8rPwqhaeJ44l1Cl5OyEuLLoZkYlc/J1UZ77riwc7GGgm/cAlbqTak1qlwHvLH+DI1M/7O
Ba+T8gDR2oXRWy52kex06K3gcnXcHU/febrTy2Lc556nJq4ZrrfFz2Yb8/A514s8DFst9mFdks3O
o2cStyEyB68eJoIxdynxGzw0kAqrCvl+ysApFb+ZABKjdeQ27v9bi+H5lT6fezL5O2a2CI82IQVd
TYNXh/sDDzZxibm1zbZLE65VOiZkyo5fQPWIKvzzlPO1vI3ZM1/MpF1B2rNHMUq82nuHFjg6/yvH
TxS+Vlrv4YMBde/r2VknOIFf9nQt2E3S5YWRJEHM5kz62/E0I7FHZg7KNpb15TEVKL9x8zK/JqMj
xN/qxDvuEKE94navsfzEP1hyI9KJJLw28Lj3q1pdmmT1wghmfdOJdSPLuZt/gv8cCOKIq55lXhuE
endiayotQz1T2itYz39APGd/9QnfqeEEbcf03RAe6E40q2A2r4QzQoihQ4PCtmmig8d/33kSc9+t
twY6OhN+rXu2jIbxwqbj/YqdxNnUMgYxVrMbnSDfnvwtQnoczcU8wAAtbxR3/cqvB4g9/vEc5RcB
vv8xGyxNYvPpAWh+QcZilY944vb9bePnupT/KH5yGOWl64Yti+9XGz+UOikIWOdlA+vJOcvvnUaI
jj72o6GPh+MzmJ1QSyODZOc21rslQL0ip8vn4no34ovJKD/XE1XpzC9+QN0W7mkP3ceAiqKdRFEF
rrWj39HuQK8JWB+37s5WEzyZGujXVar4Nbabg1wW2VsyswO8GP67bEhB8st+nwcmJMy2qDGqJJIU
hFM75PCJQoXWC4b8dg+XfR7x5X5dD6UEdnwUEomwbUjlhey86d8DvVD+dfF9lENtNJWFb2u5ERQ7
Iody/LnLtsSOCqKUchDx1OvtU602hi9TLw7QJn+2Pr/9Wg868Wb7GU8J6cJzTW5XyVJ4pRyW9Q8M
ZZ6J0qHd9IdjZ0CYBtYDVaOWRkpZmtdJADj2NhUzMYEkvONioDnuiY4LvK6fVj8+47GSMP0Hkh5M
/MbnLx5ds/Wt/VlRcuCe7tZt1v5iNlOSwen2RZVBLhsELDNhwSby9tQWTH7VKa5RUvDIjAGK6yZ1
SD51axNvHGAg/QA8hfeaeW5ajqZ89ugGmxVtB3lJ0jm16FrZuX5wc4qttwZv0VaHErl53SUz4Ki1
zHdviXI6LKijuDve4CgWYiWWkGVse+Ff7jhDBjz6GxibqeVi2HTgLH4vlDvO9ZrXAXo7iawubZ5u
Vxx0prgv