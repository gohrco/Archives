<?php
/**
 * J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: jwhmcs_sysm.php 199 2010-04-23 20:40:44Z Steven $
 * @since      2.1.1
 * 
 * @desc		This plugin redirects links to option=com_user&task=register to
 * 				the J!WHMCS component (com_jwhmcs) user registration to request
 * 				information from end customer for WHMCS.
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.plugin.plugin');

$curlfile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jwhmcs'.DS.'classes'.DS.'class.curl.php';
if (is_readable($curlfile)) include_once($curlfile);

/**
 * System Plugin
 *
 * @package		J!WHMCS Integrator 
 * @since 		1.5.0
 */
class plgContentJwhmcs_pricing extends JPlugin {

	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param object $subject The object to observe
	 * @param 	array  $config  An array that holds the plugin configuration
	 * @since 1.5
	 */
	function plgContentJwhmcs_pricing(& $subject, $config)
	{
		parent::__construct($subject, $config);
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	onPrepareContent
	 * Purpose:		Prior to content rendering plugin prices
	 * As of:		version 2.1.1 (June 2010)
	\* ------------------------------------------------------------ */
	function onPrepareContent( &$article, &$plgparams, $page=0 )
	{
		global $mainframe;
		
		if (! class_exists('JwhmcsCurl') ) return true;
		if (! class_exists('JwhmcsParams') ) return true;
		
		$params = & JwhmcsParams::getInstance();
		
		if( $mainframe->isAdmin() )
			return true;
		
		if ( JString::strpos( $article->text, '{whmcs|' ) === false )
			return true;
			
		$regex = '/{whmcs\s*\|(?<type>[^\|}]*)\|(?<id>[^\|}]*)\|(?<freq>[^\|}]*)[^}]*}/i';
		
		if (! $this->params->get( 'enabled', 1 ) )
		{
			$article->text = preg_replace( $regex, '', $article->text );
			return true;
		}
		
		preg_match_all( $regex, $article->text, $matches, PREG_SET_ORDER );
		
		$count = count( $matches[0] );
		
		if ( $count )
		{
			foreach ( $matches as $match )
			{
				$price	= '';
				$by = ( is_numeric( $match['id'] ) ? 'id' : 'name' );
				$price	= $this->_getPrice( $match['type'], $match['id'], $match['freq'], $by );
				$article->text = str_replace( $match[0], $price, $article->text );
			}
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getPrice
	 * Purpose:		Actually performs the price retrieval
	 * As of:		version 2.1.1 (June 2010)
	\* ------------------------------------------------------------ */
	protected function _getPrice( $type, $id, $freq, $by = 'id' )
	{
		$jcurl	= JwhmcsCurl::getInstance();
		
		$type	= $this->_getType( strtolower( $type ) );
		$freq	= $this->_getFreq( strtolower( $freq ) );
		
		$jcurl->setAction('jwhmcsgetpricing', array("price" => "$type,$id,$freq", "by" => "$by" ));
		$whmcs	= $jcurl->loadResult();
		
		if( $whmcs['result'] == 'success' )
		{
			return $whmcs['price'];
		}
		else
		{
			return '';
		}
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getType
	 * Purpose:		Wrapper to ensure we retrieve a correct type
	 * As of:		version 2.1.1 (June 2010)
	\* ------------------------------------------------------------ */
	protected function _getType( $type )
	{
		switch( $type ):
		case 'product':
			return 'product';
		case 'addon':
			return 'addon';
		case 'config':
			return 'configoptions';
		case 'domainaddon':
			return 'domainaddon';
		case 'domainreg':
			return 'domainregister';
		case 'domaintrans':
			return 'domaintransfer';
		case 'domainrenew':
			return 'domainrenew';
		endswitch;
		
		// Just in case I miss one
		return $type;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getFreq
	 * Purpose:		Wrapper to ensure we retrieve the wrapper
	 * As of:		version 2.1.1 (June 2010)
	\* ------------------------------------------------------------ */
	protected function _getFreq( $freq )
	{
		switch( $freq ):
		case 'monsetup':
			return 'msetupfee';
		case 'qtrsetup':
			return 'qsetupfee';
		case 'semsetup':
			return 'ssetupfee';
		case 'annsetup':
			return 'asetupfee';
		case 'biasetup':
			return 'bsetupfee';
		case 'trisetup':
			return 'tsetupfee';
		case 'monprice':
			return 'monthly';
		case 'qtrprice':
			return 'quarterly';
		case 'semprice':
			return 'semiannually';
		case 'annprice':
			return 'annually';
		case 'biaprice':
			return 'biennially';
		case 'triprice':
			return 'triennially';
		endswitch;
		
		// Just in case they add one
		return $freq;
	}
}