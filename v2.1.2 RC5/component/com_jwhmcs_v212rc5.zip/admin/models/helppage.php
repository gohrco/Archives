<?php
/**
 * Help Page Model for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id$
 * @since      2.1.0
 */
 
// Deny direct access to this file
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsModelHelppage
 * Extends:		JwhmcsModel
 * Purpose:		Used as the model for providing support
 * As of:		version 2.1.0
\* ------------------------------------------------------------ */
class JwhmcsModelHelppage extends JwhmcsModel
{
	
	/* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Needed for building the class
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	function __construct()
	{
		parent::__construct();
	}
}