<?php
/**
 * Belong
 * System - Belong Plugin:  API Update User Group Task
 *
 * @package    Belong
 * @copyright  2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.0.3 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.0.0
 *
 * @desc       This is the Update User Groups Task for the Belong API
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Update User Groups Belong API Class
 * @version		2.0.3
 *
 * @since		2.0.0
 * @author		Steven
 */
class UpdateusergroupsBelongAPI extends BelongAPI
{
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		2.0.3
	 *
	 * @since		2.0.0
	 */
	public function execute()
	{
		// Ensure we don't recursively undo ourselves
		if (! defined( 'INTLOGIN' ) ) define( 'INTLOGIN', true );
		
		$db		=	JFactory :: getDbo();
		$email	=	$this->getVar( 'email', false, 'string' );
		$groups	=	$this->getVar( 'groups', array(), 'array' );
		
		// Ensure we have an email to update with
		if (! $email ) {
			$this->error( JText :: _( 'BELONG_API_UPDATEUSERGROUPS_NOEMAIL' ) );
		}
		
		$query	= 'SELECT id FROM #__users WHERE email = ' . $db->Quote( $email );
		$db->setQuery($query, 0, 1);
		$jid	= $db->loadResult();
		
		
		// User not found so bail
		if (! $jid ) {
			$this->error( sprintf( JText :: _( 'BELONG_API_UPDATEUSERGROUPS_NOTFOUND' ), $email ) );
		}
		
		// WE DO ALL THIS BECAUSE OF A BUG IN JOOMLA GRRRRR
		$user = JUser::getInstance( (int) $jid );
		
		// We sent over all groups we belong to, so lets drop them and reload them
		foreach( $user->groups as $k => $t ) {
			if ( $k == 2 ) continue;
			unset( $user->groups[$k] );
			$user->save();
		}
		
		foreach ( $groups as $grp ) {
			JUserHelper :: addUserToGroup( (int) $jid, $grp );
		}
		
		$this->success( 'User updated' );
	}
}