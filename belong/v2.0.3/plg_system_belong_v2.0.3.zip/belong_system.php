<?php
/**
 * Belong
 * Belong - System: API Handler Plugin
 * 
 * @package    Belong
 * @copyright  2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.0.3 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.0.0
 * 
 * @desc       This is the System File for intercepting API requests for Belong
 * 
 */


/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
defined( 'BELONG_FILEPATH' ) or define( 'BELONG_FILEPATH', dirname( __FILE__) . DIRECTORY_SEPARATOR );
/*-- Security Protocols --*/


/**
 * System - Integrator plugin
 * @version		2.0.3
 * 
 * @since		2.0.0
 * @author		Steven
 */
class plgSystemBelong_system extends JPlugin
{
	
	/**
	 * Indicates we are enabling the plugin
	 * @access		private
	 * @var			boolean
	 * @since		2.0.0
	 */
	private $_enabled	=	false;
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		2.0.3
	 * @param		unknown_type $subject
	 * @param		unknown_type $config
	 * 
	 * @since		2.0.0
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		
		$this->loadLanguage();
		
		$app	=	JFactory :: getApplication();
		
		// Run through tests
		// -----------------
		// Ensure we have a token set
		if (! $this->params->get( 'token' ) ) {
			// Not admin don't show error message
			if (! $app->isAdmin() ) return;
				
			// Show error message
			$this->_displayError( 'BELONG_CONFIG_NOTOKEN' );
			return;
		}
		
		// See if we still have the component in place (can't double include BelongAPI class)
		if ( file_exists( JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_belong' . DIRECTORY_SEPARATOR . 'class.api.php' ) ) {
			// Not admin don't show error message
			if (! $app->isAdmin() ) return;
			
			// Show error message
			$this->_displayError( 'BELONG_CONFIG_REMOVELEGACY' );
			return;
		}
		
		// All good, lets go
		$this->_enabled	=	true;
	}
	
	
	/**
	 * Joomla onAfterInitialise system level event
	 * @access		public
	 * @version		2.0.3
	 * 
	 * @since		2.0.0
	 */
	public function onAfterInitialise()
	{
		// Ensure we can run this
		if (! $this->_enabled ) return;
		
		// Initialize common things
		$app	= & JFactory :: getApplication();
		$method	=	$this->_getMethod();
		
		// Update sessions if need be (due to group update potentiality)
		$this->_updateSessions();
		
		// See if we should do anything
		if (! ( $belong	=	$this->_get( 'belong', false, 'string', $method ) ) ) {
			// If we aren't getting the belong variable than we should assume this is a normal request
			// and send the user on their way
			return;
		}
		
		
		// ==============================================================
		//	We have a Belong request so lets test the signature
		// ==============================================================
		
		// See if we have matching signatures
		$postsig	=	(string) $this->_get( 'apisignature', false, 'string', $method );
		$headsig	=	(string) $this->_get( 'HTTP_BELONGREQUESTSIGNATURE', false, 'string', 'server' );
		
		if ( $postsig !== $headsig ) {
			$this->_fail( JText :: _( 'BELONG_API_BADSIGNATURE' ) );
		}
		
		// Test the signature - randomize head / post sig use
		$_received_signature	=	(string) ( rand( 0, 1 ) == '1' ? $headsig : $postsig );
		$_generatedsignature	=	(string) $this->_generateSignature();
		
		// Bail if the signatures dont match
		if ( $_received_signature !== $_generatedsignature ) {
			$this->_fail( JText :: _( 'BELONG_API_BADSIGNATURE' ) );
		}
		
		// Test the timestamp to ensure recent request
		$gmt		=	new DateTime( null, new DateTimeZone('GMT') );
		$current	=	$gmt->format("U");
		$timestamp	=	$this->_get( 'apitimestamp', 0, $method );
		
		// Test the timestamp
		if ( ( $current - $timestamp ) > 120 ) {
			// The request is older than 2 minutes... something isn't right
			$this->_fail( JText :: _( 'BELONG_API_OLDREQUEST' ) );
		}
		
		
		// ================================================================
		//	Lets find the base for the API
		// ================================================================
		
		// Take the Belong Request to get the base loaded
		$parts		=	explode( "/", trim( $belong, '/' ) );
		$apiversion	=	array_shift( $parts );
		$apirequest	=	array_shift( $parts );
		
		// Find the api path
		$apipath	=	BELONG_FILEPATH . 'api' . DIRECTORY_SEPARATOR;
		
		// Permit possibilities of versioned API
		$apiversion	=	$this->_findApiversion( $apiversion );
		$apipath	.=	$apiversion . DIRECTORY_SEPARATOR;
		
		// Be sure we dont fail ugly - we must have the base
		if (! file_exists(  $apipath . 'base.php' ) ) {
			// If for some reason we don't have the base file for the API for Belong there may
			// have been a problem during installation.
			$this->_fail( sprintf( JText :: _( 'BELONG_API_BASE_NOPATH' ), $apipath . 'base.php' ) );
		}
		
		// Load the base api file
		@require_once( $apipath . 'base.php' );
		
		$classname	= 'BelongAPI';
		
		// Be sure we dont fail ugly - we must have the base
		if (! class_exists( $classname ) ) {
			// If for some reason we don't have the base class but was able to find the file something
			// is fishy so bail
			$this->_fail( sprintf( JText :: _( 'BELONG_API_BASE_NOCLASS' ), $classname ) );
		}
		
		
		// =============================================================
		//	Now lets find the actual request
		// =============================================================
		
		// API classname
		$apiclassname	= ucfirst( $apirequest ) . $classname;
		
		// Find the api filename
		// @TODO:  Check for safe mode as file exists may fail otherwise
		if ( file_exists( $apipath . strtolower( $apirequest ) . '.php' ) ) {
			@require_once( $apipath . strtolower( $apirequest ) . '.php' );
		}
		
		// Be sure we dont fail ugly
		if (! class_exists( $apiclassname ) ) {
			$this->_fail( sprintf( 'API Method `%s` is unknown.', $apirequest ) );
		}
		
		// Initialize the class and execute
		$api	= new $apiclassname();
		$api->execute();
		
	}
	
	
	/**
	 * Common method for displaying an error message
	 * @access		private
	 * @version		2.0.3 ( $id$ )
	 * @param		string		- $msg: the message to display
	 *
	 * @since		1.0.0
	 */
	private function _displayError( $msg = null )
	{
		// Translate string first
		$msg	= JText :: _( $msg );
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JFactory::getApplication()->enqueueMessage( "{$msg}" );
		}
		else {
			JError::raiseNotice( 100, "{$msg}" );
		}
	}
	
	
	/**
	 * Method for calling up a failed response
	 * @access		private
	 * @version		2.0.3
	 * @param		mixed		- $message: the message to fail on
	 *
	 * @since		2.0.0
	 */
	private function _fail( $message )
	{
		$string	= json_encode( array( 'result' => 'error', 'error' => $message ) );
		exit( $string );
	}
	
	
	/**
	 * Method for determining the requested API version
	 * @access		private
	 * @version		2.0.3
	 * @param		md5 string		- $sent: we should be sent an md5 hashed string of the intended version
	 * 
	 * @return		string containing found matching hashed version or 2.0 as the default
	 * @since		2.0.0
	 */
	private function _findApiversion( $sent = null )
	{
		$apipath	=	BELONG_FILEPATH . 'api' . DIRECTORY_SEPARATOR;
		
		$dh		= opendir( $apipath );
		$data	=	array();
		while( ( $filename = readdir( $dh ) ) !== false ) {
			if ( in_array( $filename, array( '.', '..', 'index.html' ) ) ) continue;
			$data[md5( $filename )]	= $filename;
		}
		
		if ( isset( $data[$sent] ) ) return $data[$sent];
		else return '2.0';
	}
	
	
	/**
	 * Method to generate a signature
	 * @access		private
	 * @version		2.0.3
	 * 
	 * @return		string
	 * @since		2.0.0
	 */
	private function _generateSignature()
	{
		$method	=	$this->_getMethod();
		$token	=	$this->params->get( 'token' );
		$uri	=	clone JUri :: getInstance();
		$append	=	null;
		
		if ( $method == 'post' ) {
			$post	=	$_POST;
			ksort( $post );
			
			foreach ( $post as $k => $v ) {
				if ( $k == 'apisignature' ) continue;
				$append	.=	$k . $this->_get( $k, null, 'string', 'post' );
			}
		}
		else if ( $method == 'get' || $method == 'put' ) {
			$uri->delVar( 'apisignature' );
		}
		
		return base64_encode( hash_hmac( 'sha256', $uri->toString() . $append, $token, true ) );
	}
	
	
	/**
	 * Provides single instance of version logic for retrieving variable
	 * @access		private
	 * @version		2.0.3
	 * @param		string		- $var: the variable sought
	 * @param		mixed		- $default: if not set return this
	 * @param		string		- $filter: variable filter
	 * @param		string		- $hash: where the variable should come from
	 * $param		integer		- $mask: an optional mask for Joomla
	 *
	 * @return		value of variable or default
	 * @since		2.0.0
	 */
	private function _get( $var, $default = null, $filter = 'none', $hash = 'default', $mask = 0 )
	{
		if ( version_compare( JVERSION, '1.7.0', 'ge' ) ) {
			$app	= & JFactory :: getApplication();
			if ( $hash == 'default' ) {
				return $app->input->get( $var, $default, $filter );
			}
			else {
				return $app->input->$hash->get( $var, $default, $filter );
			}
		}
		else {
			$value	= JRequest :: getVar( $var, $default, $hash, $filter, $mask );
			// If we are resetting pw on front end, post is empty for some reason
			if ( empty( $value ) && $var == 'post' ) $value = JRequest::get( 'post' );
			return $value;
		}
	}
	
	
	/**
	 * Provides a common means of getting the method of the call
	 * @access		private
	 * @version		2.0.3
	 * 
	 * @return		lowercase string
	 * @since		2.0.0
	 */
	private function _getMethod()
	{
		if ( version_compare( JVERSION, '1.7.0', 'ge' ) ) {
			$app	= & JFactory :: getApplication();
			return strtolower( $app->input->getMethod() );
		}
		else {
			return strtolower( JRequest :: getMethod() );
		}
	}
	
	/**
	 * Method to update a session for a logged in user
	 * @access		private
	 * @version		2.0.3
	 * 
	 * @since		2.0.0
	 */
	private function _updateSessions()
	{
		// Initiate some items
		$session	=	JFactory::getSession();
		$instance	=	$session->get('user');
		
		// Bail if we aren't logged in
		if (! is_a( $instance, 'JUser' ) || $instance->guest ) {
			return;
		}
		
		// Load the user from the database
		$dbuser		= new Juser( $instance->get( 'id' ) );
		$changes	= false;
		
		foreach( array( 'email', 'username', 'name' ) as $item ) {
			if ( $dbuser->get( $item ) == $instance->get( $item ) ) continue;
			$instance->set( $item, $dbuser->get( $item ) );
			$changes	= true;
		}
		
		if ( $changes ) {
			$instance->set( 'email', $dbuser->get( 'email' ) );
			$session->set( 'user', $instance );
		}
	}
}