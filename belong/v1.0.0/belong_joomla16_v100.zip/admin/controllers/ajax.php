<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla controllerform library
jimport('joomla.application.component.controlleradmin');

class BelongControllerAjax extends JControllerAdmin
{
	public function apicnxn()
	{
		$app	= & JFactory::getApplication();
		$model	=   $this->getModel( 'ajax' );
		$data	=   $model->apicnxn();
		echo $this->buildResponse($data);
		$app->close();
	}
	
	
	public function getproductaddons()
	{
		$app	= & JFactory::getApplication();
		$model	=   $this->getModel( 'ajax' );
		$data	=   $model->getproductaddons();
		echo json_encode( $data );
		$app->close();
	}
	
	function buildResponse($data) {
		$return[] = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>";
		$return[] = "<root><param>";
		foreach ($data as $k => $v) {
			if (is_array($v)) {
				foreach ($v as $k2 => $v2) {
					$sub[] = '<'.$k.'><![CDATA['.$v2.']]></'.$k.'>';
				}
				$return[] = '<'.$k.'s>'.implode("\n", $sub).'</'.$k.'s>';
			}
			else {
				$return[] = '<'.$k.'><![CDATA['.$v.']]></'.$k.'>';
			}
		}
		$return[] = "</param></root>";
		
		return implode("", $return);
	}
}