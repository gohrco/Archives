<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.0 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This file is a utility helper for Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
jimport( 'joomla.user.helper' );
require_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'class.curl.php' );
require_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'class.api.php' );

/**
 * BelongHelper class is a utility class for common tasks
 * @version 1.0.0
 * 
 * @since	1.0.0
 * @author	Steven
 */
class BelongHelper
{
	/**
	 * Handles inclusion of media items into views
	 * @access	public
	 * @version	1.0.0
	 * @param	string		$media - contains filename/type
	 * 
	 * @since	1.0.0
	 */
	public function addMedia( $media = null )
	{
		if ( $media == null ) return;
		
		list( $filename, $type ) = explode( "/", $media );
		
		switch ( $type ):
		case 'css':
			$document = JFactory::getDocument();
			$document->addStylesheet( JURI::root(true) . '/media/com_belong/css/' . $filename . '.css' );
			break;
		case 'javascript':
		case 'js':
			$document = JFactory::getDocument();
			$document->addScript( JURI::root(true) . '/media/com_belong/js/' . $filename . '.js' );
			break;
		endswitch;
	}
	
	
	/**
	 * Add the toolbar buttons based on permissions
	 * @access		public
	 * @version		1.0.0
	 * @param		string		- $view: the originating view
	 * @param		string		- $task: the task being utilized
	 * @param		JObject		- $canDo: contains permissions user has
	 * 
	 * @since		1.0.0
	 */
	public function addToolbar( $view, $task = null, $canDo = null )
	{
		if ( $canDo == null ) $canDo = self :: getActions();
		
		switch ( $view ) :
		
		case 'default' :
			
			JToolBarHelper :: title( JText::_( 'COM_BELONG' ), 'belong.png' );
			
			// Toolbar buttons
			if ( $canDo->get( 'core.admin' ) ) {
				JToolBarHelper :: preferences(	'com_belong', '550', '875', 'JToolbar_Options', '', 'window.location.reload()' );
			}
			
			break;
		
		case 'rule' :
			
			JRequest::setVar('hidemainmenu', true);
			
			switch ( $task ) {
				// new
				case true:
					
					$title = JText::_( 'COM_BELONG_RULE_TITLE_ADD' );
					$cancel	= 'JTOOLBAR_CANCEL';
					
					break;
				// edit
				case false:
					
					$title = JText::_( 'COM_BELONG_RULE_TITLE_EDIT' );
					$cancel	= 'JTOOLBAR_CLOSE';
					
					break;
			}
			
			JToolBarHelper :: title( $title, 'rules.png' );
			JToolBarHelper :: apply( 'rule.apply' );
			JToolBarHelper :: save( 'rule.save' );
			JToolBarHelper :: save2new( 'rule.save2new' );
			JToolBarHelper :: cancel( 'rule.cancel', $cancel );
			
			break;
		                                                   
		case 'rules' :
			
			JToolBarHelper :: title( JText::_( 'COM_BELONG_RULES_TITLE' ), 'rules.png' );
			
			JToolBarHelper :: custom( 'display', 'belong.png', 'belong.png', 'COM_BELONG', false );
			JToolBarHelper :: custom( 'products', 'product.png', 'product.png', 'COM_BELONG_BUTTON_PRODUCT', false );
			JToolBarHelper :: custom( 'productrulesets', 'productrulesets.png', 'productrulesets.png', 'COM_BELONG_BUTTON_PRODUCTRULESETS', false );
			JToolBarHelper :: divider();
			JToolBarHelper :: addNew( 'rule.add' );
			JToolBarHelper :: editList( 'rule.edit' );
			JToolBarHelper :: deleteList( '', 'rules.delete' );
			
			break;
			
		case 'product' :
			
			JRequest::setVar('hidemainmenu', true);
			
			switch ( $task ) {
				// new
				case true:
					
					$title = JText::_( 'COM_BELONG_PRODUCT_TITLE_ADD' );
					$cancel	= 'JTOOLBAR_CANCEL';
					
					break;
				// edit
				case false:
					
					$title = JText::_( 'COM_BELONG_PRODUCT_TITLE_EDIT' );
					$cancel	= 'JTOOLBAR_CLOSE';
					
					break;
			}
			
			JToolBarHelper :: title( $title, 'products.png' );
			JToolBarHelper::apply('product.apply');
			JToolBarHelper::save( 'product.save' );
			JToolBarHelper::save2new('product.save2new');
			JToolBarHelper::cancel( 'product.cancel', $cancel );
			
			break;
			
		case 'products' :
			
			JToolBarHelper :: title( JText::_( 'COM_BELONG_PRODUCTS_TITLE' ), 'products.png' );
			JToolBarHelper :: spacer();
			
			JToolBarHelper :: custom( 'display', 'belong.png', 'belong.png', 'COM_BELONG', false );
			JToolBarHelper :: custom( 'rules', 'rules.png', 'rules.png', 'COM_BELONG_BUTTON_RULES', false );
			JToolBarHelper :: custom( 'productrulesets', 'productrulesets.png', 'productrulesets.png', 'COM_BELONG_BUTTON_PRODUCTRULESETS', false );
			JToolBarHelper :: divider();
			JToolBarHelper :: addNew( 'product.add' );
			JToolBarHelper :: editList( 'product.edit' );
			JToolBarHelper :: deleteList( '', 'products.delete' );
			
			break;
			
		case 'productruleset' :
			
			JRequest::setVar('hidemainmenu', true);
			
			switch ( $task ) {
				// new
				case true:
					
					$title = JText::_( 'COM_BELONG_PRODUCTRULESET_TITLE_ADD' );
					$cancel	= 'JTOOLBAR_CANCEL';
					
					break;
				// edit
				case false:
					
					$title = JText::_( 'COM_BELONG_PRODUCTRULESET_TITLE_EDIT' );
					$cancel	= 'JTOOLBAR_CLOSE';
					
					break;
			}
			
			JToolBarHelper :: title( $title, 'productrulesets.png' );
			JToolBarHelper :: apply('productruleset.apply');
			JToolBarHelper :: save( 'productruleset.save' );
			JToolBarHelper :: save2new('productruleset.save2new');
			JToolBarHelper :: cancel( 'productruleset.cancel', $cancel );
			
			break;
			
		case 'productrulesets' :
			
			JToolBarHelper :: title( JText::_( 'COM_BELONG_PRODUCTRULESETS_TITLE' ), 'productrulesets.png' );
			
			JToolBarHelper :: custom( 'display', 'belong.png', 'belong.png', 'COM_BELONG', false );
			JToolBarHelper :: custom( 'products', 'product.png', 'product.png', 'COM_BELONG_BUTTON_PRODUCT', false );
			JToolBarHelper :: custom( 'rules', 'rules.png', 'rules.png', 'COM_BELONG_BUTTON_RULES', false );
			JToolBarHelper :: divider();
			JToolBarHelper :: publish('productrulesets.publish', 'JTOOLBAR_PUBLISH', true);
			JToolBarHelper :: unpublish('productrulesets.unpublish', 'JTOOLBAR_UNPUBLISH', true);
			JToolBarHelper :: divider();
			JToolBarHelper :: addNew( 'productruleset.add' );
			JToolBarHelper :: editList( 'productruleset.edit' );
			JToolBarHelper :: deleteList( '', 'productrulesets.delete' );
			
			break;

		case 'apicnxn' :
			
			JToolBarHelper :: title( JText::_( 'COM_BELONG_APICNXN_TITLE' ), 'apicnxn.png' );
			JToolBarHelper :: custom( 'display', 'save.png', 'save.png', 'JSAVE', false );
			break;
			
		case 'email' :
			
			$title = JText::_( 'COM_BELONG_EMAIL_TITLE' );
			
			JToolBarHelper :: title( $title, 'email.png' );
			JToolBarHelper :: custom( 'display', 'belong.png', 'belong.png', 'COM_BELONG', false );
			JToolBarHelper :: divider();
			JToolBarHelper :: custom( 'email.find', 'email.png', 'email.png', 'COM_BELONG_EMAIL_CHECK_BUTTON', false );
			
			break;
			
		case 'help' :
			
			JToolBarHelper :: title( JText::_( 'COM_BELONG_HELP_TITLE' ), 'help.png' );
			
			break;
			
		endswitch;
	}
	
	
	/**
	 * Determines if a username is actually an email address
	 * @access	public
	 * @version	2.3.0
	 * @param 	string		$username - Contains suspect username
	 * 
	 * @return	True if email, false if not
	 * @since	2.0.0
	 */
	public function is_email( $username )
	{
		$pattern = "/\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,5}\b/i";
		$match = preg_match( $pattern, $username );
		
		return ( $match > 0 );
	}
	
	
	/**
	 * Finds a user's products from WHMCS
	 * @access		public
	 * @version		1.0.0
	 * @param		integer		- $clientid: the found clientid for the WHMCS user
	 * 
	 * @return		array of products or false on error / empty
	 * @since		1.0.0
	 */
	public function findProducts( $clientid = 0 )
	{
		$debug		=   BelongDebug :: getInstance();
		$api		= & IntApi :: getInstance();
		$response	=   $api->get_user_products( array( 'clientid' => $clientid ) );
		
		// Problem connecting!
		if (! isset( $response['result'] ) ) {
			$debug->add( 'The API connection may not be functioning properly - no readable response from WHCMS %s', print_r( $response, 1 ) );
			return false;
		}
		
		// No result
		if ( $response['result'] == 'error' ) {
			$debug->add( $response['message'] );
			return false;
		}
		
		// No products found
		if ( empty( $response['products'] ) ) {
			$debug->add( 'No products were found for this user.' );
			return false;
		}
		
		// Send back just the products
		return $response['products'];
	}
	
	
	/**
	 * Finds the rulesets from the database and cleans them up for use
	 * @access		public
	 * @version		1.0.0
	 * 
	 * @return		array of rulesets or false on error or no rulesets found
	 * @since		3.0.0
	 */
	public function findRulesets()
	{
		$debug		=   BelongDebug :: getInstance();
		$db			= & JFactory :: getDbo();
		$query		=   $db->getQuery( true );
		
		$query->select( 'DISTINCT p.pid, p.aid, r.data as rule' )
				->from( '#__belong_productrulesets rs' )
				->innerJoin( '#__belong_products p ON p.id = rs.pid' )
				->innerJoin( '#__belong_rules r ON r.id = rs.rid' )
				->where( 'rs.published=1' )
				->order( 'priority' );
		
		$db->setQuery( $query );
		$results	= $db->loadObjectList();
		
		if ( ( empty( $results ) ) || (! is_array( $results ) ) ) {
			$debug->add( 'No active rulesets were found to apply!' );
			return false;
		}
		
		$data	=   array();
		foreach ( $results as $i => $result ) {
			$results[$i]->rule = json_decode( $result->rule, true );
			
			$rid = $result->pid . '|' . $result->aid;
			if (! isset( $data[$rid] ) ) {
				$data[$rid] = array();
			}
			
			$rule = array();
			foreach( array( 'product', 'addon' ) as $ptype ) {
				foreach( array( 'active', 'pending', 'suspended', 'terminated', 'fraud', 'cancelled' ) as $type ) {
					$rule[ucfirst( $ptype ) . '|' . ucfirst( $type )] = array( 'action' => $result->rule[$ptype . $type . 'groupaxn'], 'group' => $result->rule[$ptype . $type . 'group'] );
				}
			}
			$data[$rid][] = $rule;
		}
		
		return $data;
	}
	
	
	/**
	 * Finds a user's clientid from WHMCS
	 * @access		public
	 * @version		1.0.0
	 * @param		mixed		- $id: can be an integer or an email address
	 * @param		string		- $source: indicates id is from Joomla or WHMCS
	 * @param		bool		- $debug: true to return log info
	 * 
	 * @return		array containing clientid, joomla_userid and email address or false on error
	 * @since		1.0.0
	 */
	public function findUser( $id, $source = 'whmcs' )
	{
		$api	= & IntApi :: getInstance();
		$db		= & JFactory :: getDbo();
		$debug	=   BelongDebug :: getInstance();
		$data	=   array();
		
		if ( self :: is_email( $id ) ) {
			$wuser = $api->get_user( array( 'email' => $id ) );
			
			// Can't find user - fail
			if ( $wuser['result'] == 'error' ) {
				$debug->add( 'Unable to locate WHMCS user through API (%s)', $id);
				return false;
			}
			
			$query	= $db->getQuery( true );
			$query->select( 'id' )
					->from( '#__users' )
					->where( 'email = ' . $db->Quote( $id ) );
			$db->setQuery($query, 0, 1);
			$jid	= $db->loadResult();
			
			// Can't find local user - fail
			if ( $jid == null ) {
				$debug->add( 'Unable to locate Joomla user in database (email = %s)', $id);
				return false;
			}
			
			$data['clientid']	= $wuser['userid'];
			$data['joomlaid']	= $jid;
			$data['email']		= $id;
		}
		else {
			if ( $source == 'joomla' ) {
				$juser	= JFactory :: getUser( $id );
				
				// Juser doesn't match sent id - fail
				if ( $juser->id != $id ) {
					$debug->add( 'Unable to locate Joomla user in the database matching id %s', $id);
					return false;
				}
				
				$wuser	= $api->get_user( array( 'email' => $juser->email ) );
				
				// Can't find user - fail
				if ( $wuser['result'] == 'error' ) {
					$debug->add( 'Unable to locate WHMCS user through API with matching Joomla email address of %s', $juser->email );
					return false;
				}
				
				$data['clientid']	= $wuser['userid'];
				$data['joomlaid']	= $id;
				$data['email']		= $juser->email;
			}
			else {
				
				$wuser	= $api->get_user( array( 'clientid' => $id ) );
				
				$query	= $db->getQuery( true );
				$query->select( 'id' )
						->from( '#__users' )
						->where( 'email = ' . $db->Quote( $wuser['email'] ) );
				$db->setQuery($query, 0, 1);
				$jid	= $db->loadResult();
				
				// Can't find local user - fail
				if ( $jid == null ) {
					$debug->add( 'Unable to locate Joomla user with email %s from WHMCS', $wuser['email']);
					return false;
				}
				
				$data['clientid']	= $id;
				$data['joomlaid']	= $jid;
				$data['email']		= $wuser['email'];
			}
		}
		
		return $data;
	}
	
	
	/**
	 * Handles running the rulesets for front and backend processes
	 * @access		public
	 * @version		1.0.0
	 * @param		mixed		- $id: can be an integer representing a WHMCS or Joomla user id or a string containing an email address
	 * @param		string		- $source: where we are calling from (whmcs or joomla)
	 * @param		bool		- $debug: if we want the debug log returned to us (backend purposes)
	 * 
	 * @return		bool or array containing debug log
	 * @since		1.0.0
	 */
	public function runRulesets( $id, $source = 'whmcs', $debug = false )
	{
		$db		= & JFactory :: getDbo();
		$debug	=   BelongDebug :: getInstance( true );
		
		// Grab the clientid from WHMCS
		if (! ( $user = self :: findUser( $id, $source ) ) ) {
			// Unable to find the client id so return false
			$debug->add( 'Breaking at runRulesets / findUser' );
			return $debug->on ? $debug->send() : false;
		}
		
		// Pull the users products from WHMCS
		if (! ( $products = self :: findProducts( $user['clientid'] ) ) ) {
			// No products, can't do anything
			$debug->add( 'Breaking at runRulesets / findProducts' );
			return $debug->on ? $debug->send() : false;
		}
		
		if (! ( $rulesets = self :: findRulesets() ) ) {
			// No rulesets, can't do anything
			$debug->add( 'Breaking at runRulesets / findRulesets' );
			return $debug->on ? $debug->send() : false;
		}
		
		// Create add/drop arrays
		$add_groups		= array();
		$drop_groups	= array();
		
		// Cycle through products and add to appropriate arrays
		foreach ( $products as $product ) {
			
			// Cycle through the addons first
			foreach( $product['addons'] as $addons ) {
				$paid	= $product['pid'] . '|' . $addons['aid'];
				
				// If we have a matching ruleset and it has rules (array) then proceed
				if ( ( isset( $rulesets[$paid] ) ) && ( is_array( $rulesets[$paid] ) ) ) {
					
					foreach( $rulesets[$paid] as $ruleset ) {
						
						// Set the rules
						$rule	= $ruleset['Addon|' . $addons['status']];
						$prod	= $ruleset['Product|' . $product['status']];
						
						if ( ( $rule['action'] == 'add' ) && ( $prod['action'] == 'add' ) ) {
							$add_groups[]	= $rule['group'];
						}
						else if ( ( $rule['action'] == 'add' ) && ( $prod['action'] == 'nothing' ) ) {
							$add_groups[]	= $rule['group'];
						}
						else if ( $rule['action'] == 'drop' ) {
							$drop_groups[]	= $rule['group'];
						}
						else if ( $prod['action'] == 'drop' ) {
							$drop_groups[]	= $rule['group'];
						}
					}
				}
			}
			
			// Cycle through products without any addons
			$paid	= $product['pid'] . '|0';
			
			if ( ( isset( $rulesets[$paid] ) ) && ( is_array( $rulesets[$paid] ) ) ) {
				
				foreach( $rulesets[$paid] as $ruleset ) {
					
					$rule	= $ruleset['Product|' . $product['status']];
					
					if ( $rule['action'] == 'add' ) {
						
						$add_groups[]	= $rule['group'];
					}
					else if ( $rule['action'] == 'drop' ) {
						$drop_groups[]	= $rule['group'];
					}
				}
			}
		}
		
		$groupnames	= self :: getGroupnames();
		$add_groups = array_flip( $add_groups );
		foreach( $add_groups as $addId => $junk ) {
			$add_groups[$addId] = $groupnames[$addId];
		}
		
		$drop_groups = array_flip( $drop_groups );
		foreach ( $drop_groups as $dropId => $junk ) {
			$drop_groups[$dropId] = $groupnames[$dropId];
		}
		
		$debug->add( 'User should be added to these groups:<br/><div style="padding-left: 20px; ">%s</div>', (! empty( $add_groups ) ? '-- ' . implode( '<br/>-- ', $add_groups ) : '<em>none</em>' ) );
		$debug->add( 'User should be dropped from these groups:<br/><div style="padding-left: 20px; ">%s</div>', (! empty( $drop_groups ) ? '-- ' . implode( '<br/>-- ', $drop_groups ) : '<em>none</em>' ) );
		
		// NOTE:  BUG IN JUSERHELPER :: SETUSERGROUPS
		
		// Grab current user groups
		$current_groups	= JUserHelper :: getUserGroups( $user['joomlaid'] );
		$current_groups	= array_flip( $current_groups );
		$debug->add( 'User belongs to these groups:<br/><div style="padding-left: 20px; ">%s</div>', (! empty( $current_groups ) ? '-- ' . implode( '<br/>-- ', $current_groups ) : '<em>none</em>' ) );
		
		// Process drop groups first
		foreach ( $drop_groups as $groupId => $drname ) {
			JUserHelper :: removeUserFromGroup( $user['joomlaid'], $groupId );
		}
		
		$current_groups = array_diff_key( $current_groups, $drop_groups );
		$debug->add( 'After dropping from groups user now belongs to these groups:<br/><div style="padding-left: 20px; ">%s</div>', (! empty( $current_groups ) ? '-- ' . implode( '<br/>-- ', $current_groups ) : '<em>none</em>' ) );
		
		// Process add groups
		$set_groups		= $current_groups + $add_groups;
		$set_groups		= array_unique( $set_groups );
		ksort( $set_groups );
		$debug->add( 'After adding the groups, the user will finally belong to these groups:<br/><div style="padding-left: 20px; ">%s</div>', (! empty( $set_groups ) ? '-- ' . implode( '<br/>-- ', $set_groups ) : '<em>none</em>' ) );
		
		// Set the user groups 
		foreach ( $set_groups as $groupId => $drname ) {
			JUserHelper :: addUserToGroup( $user['joomlaid'], $groupId );
		}
		
		return $debug->on ? $debug->send() : true;
	}
	
	
	/**
	 * Gets actions that are permitted for a user to perform
	 * @access		public
	 * @version		1.0.0
	 * @param		integer		- $sliderId: if supplied contains the slider id of the module being checked
	 * 
	 * @return		JObject containing action sets
	 * @since		1.00
	 */
	public function getActions( $sliderId = 0 )
	{
		$user		= JFactory::getUser();
		$result		= new JObject;
		
		$assetName	= "com_belong" . ( empty( $sliderId ) ? "" : ".slider." . (int) $sliderId );
		$actions	= array(	'core.admin',
								'core.manage',
								'core.create',
								'core.edit',
								'core.delete'
		);
		
		foreach ($actions as $action) {
			$result->set($action,        $user->authorise($action, $assetName));
		}
		
		return $result;
	}
	
	
	/**
	 * Retrieves the user group names from the database
	 * @access		public
	 * @version		1.0.0
	 * 
	 * @return		array of names with groupid as key
	 * @since		1.0.0
	 */
	public function getGroupnames()
	{
		$db	= & JFactory :: getDbo();
		
		$query	= $db->getQuery( true );
		$query->select( 'id,title' )
				->from( '#__usergroups' )
				->order( 'id' );
		
		$db->setQuery( $query );
		$results	= $db->loadObjectList();
		$data		= array();
		
		foreach( $results as $result ) {
			$data[$result->id] = $result->title;
		}
		
		return $data;
	}
}


/**
 * BelongDebug class is a utility class to assist in debugging and for responding to backend
 * @version 1.0.0
 * 
 * @since	1.0.0
 * @author	Steven
 */
class BelongDebug
{
	/**
	 * Set to true if debug is on
	 * @access		public
	 * @var			boolean
	 * @since		1.0.0
	 */
	public $on = false;
	
	/**
	 * Contains the log messages
	 * @access		private
	 * @var			array
	 * @since		1.0.0
	 */
	private $log = array();
	
	
	/**
	 * Constructor class
	 * @access		public
	 * @version		1.0.0
	 * @param		bool		- $enable: turn debug on or off
	 * 
	 * @since		1.0.0
	 */
	public function __construct( $enable = false )
	{
		$this->on = $enable;
	}
	
	
	/**
	 * Instantiation method
	 * @access		public
	 * @version		1.0.0
	 * @param		bool		- $enable: turn debug on or off
	 * 
	 * @return		BelongDebug class object
	 * @since		1.0.0
	 */
	public function getInstance( $enable = false )
	{
		static $static;
		
		if (! is_object( $static ) ) {
			$static = new BelongDebug( $enable );
		}
		
		return $static;
	}
	
	
	/**
	 * Adds a message to the log
	 * @access		public
	 * @version		1.0.0
	 * 
	 * @since		1.0.0
	 */
	public function add()
	{
		$args	= func_get_args();
		if ( count( func_get_args() ) > 1 ) {
			$this->log[] = call_user_func_array( 'sprintf', $args );
		}
		else {
			$this->log[] = $args[0];
		}
	}
	
	
	/**
	 * Sends the log out
	 * @access		public
	 * @version		1.0.0
	 * 
	 * @return		array of logged messages
	 * @since		1.0.0
	 */
	public function send()
	{
		return $this->log;
	}
}