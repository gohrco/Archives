<?php


// import Joomla table library
jimport('joomla.database.table');
 
class BelongTableRules extends JTable
{
	
	public function __construct( &$db ) 
	{
		parent::__construct( '#__belong_rules', 'id', $db );
	}
	
	
	public function bind($array, $ignore = '') 
	{
		if (isset($array['data']) && is_array($array['data'])) 
		{
			// Convert the params field to a string.
			$parameter = new JRegistry;
			$parameter->loadArray($array['data']);
			$array['data'] = (string)$parameter;
		}
		return parent::bind($array, $ignore);
	}
 
	/**
	 * Overloaded load function
	 *
	 * @param       int $pk primary key
	 * @param       boolean $reset reset data
	 * @return      boolean
	 * @see JTable:load
	 */
	public function load($pk = null, $reset = true) 
	{
		if (! parent::load($pk, $reset)) {
			return false;
		}
		
		if ( is_string( $this->data ) ) {
			$this->data = json_decode( $this->data );
		}
		
		return true;
	}
}