<?php


// import Joomla table library
jimport('joomla.database.table');
 
class BelongTableProductrulesets extends JTable
{
	
	public function __construct( &$db ) 
	{
		parent::__construct( '#__belong_productrulesets', 'id', $db );
	}
	
	
	public function move($delta, $where = '')
	{
		// If the change is none, do nothing.
		if (empty($delta)) {
			return true;
		}
		
		// Initialise variables.
		$k		= $this->_tbl_key;
		$row	= null;
		$query	= $this->_db->getQuery(true);
		
		// Select the primary key and ordering values from the table.
		$query->select($this->_tbl_key.', priority');
		$query->from($this->_tbl);
		
		// If the movement delta is negative move the row up.
		if ($delta < 0) {
			$query->where('priority < '.(int) $this->priority);
			$query->order('priority DESC');
		}
		// If the movement delta is positive move the row down.
		elseif ($delta > 0) {
			$query->where('priority > '.(int) $this->priority);
			$query->order('priority ASC');
		}
		
		// Add the custom WHERE clause if set.
		if ($where) {
			$query->where($where);
		}

		// Select the first row with the criteria.
		$this->_db->setQuery($query, 0, 1);
		$row = $this->_db->loadObject();

		// If a row is found, move the item.
		if (! empty( $row ) ) {
			// Update the ordering field for this instance to the row's ordering value.
			$query = $this->_db->getQuery(true);
			$query->update($this->_tbl);
			$query->set('priority = '.(int) $row->priority);
			$query->where($this->_tbl_key.' = '.$this->_db->quote($this->$k));
			
			$this->_db->setQuery($query);

			// Check for a database error.
			if (!$this->_db->query()) {
				$e = new JException(JText::sprintf('JLIB_DATABASE_ERROR_MOVE_FAILED', get_class($this), $this->_db->getErrorMsg()));
				$this->setError($e);

				return false;
			}

			// Update the ordering field for the row to this instance's ordering value.
			$query = $this->_db->getQuery(true);
			$query->update($this->_tbl);
			$query->set('priority = '.(int) $this->priority);
			$query->where($this->_tbl_key.' = '.$this->_db->quote($row->$k));
			$this->_db->setQuery($query);

			// Check for a database error.
			if (!$this->_db->query()) {
				$e = new JException(JText::sprintf('JLIB_DATABASE_ERROR_MOVE_FAILED', get_class($this), $this->_db->getErrorMsg()));
				$this->setError($e);

				return false;
			}

			// Update the instance value.
			$this->priority = $row->priority;
		}
		else {
			// Update the ordering field for this instance.
			$query = $this->_db->getQuery(true);
			$query->update($this->_tbl);
			$query->set('priority = '.(int) $this->priority);
			$query->where($this->_tbl_key.' = '.$this->_db->quote($this->$k));
			$this->_db->setQuery($query);

			// Check for a database error.
			if (!$this->_db->query()) {
				$e = new JException(JText::sprintf('JLIB_DATABASE_ERROR_MOVE_FAILED', get_class($this), $this->_db->getErrorMsg()));
				$this->setError($e);

				return false;
			}
		}

		return true;
	}
	
	
//	
//	
//	public function bind($array, $ignore = '') 
//	{
//		if (isset($array['pdata']) && is_array($array['pdata'])) 
//		{
//			// Convert the params field to a string.
//			$parameter = new JRegistry;
//			$parameter->loadArray($array['pdata']);
//			$array['pdata'] = (string)$parameter;
//		}
//		
//		if (isset($array['statusorder']) && is_array($array['statusorder'])) 
//		{
//			// Convert the params field to a string.
//			$parameter = new JRegistry;
//			$parameter->loadArray($array['statusorder']);
//			$array['statusorder'] = (string)$parameter;
//		}
//		return parent::bind($array, $ignore);
//	}
 
//	/**
//	 * Overloaded load function
//	 *
//	 * @param       int $pk primary key
//	 * @param       boolean $reset reset data
//	 * @return      boolean
//	 * @see JTable:load
//	 */
//	public function load($pk = null, $reset = true) 
//	{
//		if (! parent::load($pk, $reset)) {
//			return false;
//		}
//		
//		if ( is_string( $this->pdata ) ) {
//			$this->pdata = json_decode( $this->pdata );
//		}
//		
//		if ( is_string( $this->statusorder ) ) {
//			$this->statusorder = json_decode( $this->statusorder );
//		}
//		
//		return true;
//	}
}