<?php
// No direct access
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.tooltip');

$form	= $this->form->getFieldset( 'details' );
?>
<form action="<?php echo JRoute::_('index.php?option=com_belong&layout=edit&id=' . (int) $this->item->id ); ?>"
      method="post" name="adminForm" id="belong-form">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BELONG_PRODUCTRULESET_EDIT_RULEDETAILS' ); ?></legend>
		<ul class="adminformlist">
			<li><?php echo $form['jform_pid']->label;echo $form['jform_pid']->input;?></li>
		</ul>
		
		<ul class="adminformlist">
			<li><?php echo $form['jform_rid']->label;echo $form['jform_rid']->input;?></li>
		</ul>
	</fieldset>
	
	<div>
		<input type="hidden" name="task" value="productruleset.edit" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>