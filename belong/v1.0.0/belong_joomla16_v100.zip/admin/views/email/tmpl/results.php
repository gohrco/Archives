<?php
// No direct access
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.tooltip');

?>

<table class="adminlist">

	<!-- BEGIN BODY -->
	
	<tbody>
		
		<?php foreach( $this->results as $i => $result ) : ?>
		
		<tr class="row<?php echo $i % 2; ?>">
			<td>
				<h3><?php echo $result; ?></h2>
			</td>
		</tr>
		
		<?php endforeach; ?>
		
	</tbody>
	
	<!-- END BODY -->
	<!-- BEGIN HEADER -->
	
	<thead>
		
		<tr>
			<th>
				<?php echo JText::_( 'COM_BELONG_EMAIL_HEADING_RESULTS' ); ?>
			</th>
		</tr>
		
	</thead>
	
	<!-- END HEADER -->
	<!-- BEGIN FOOTER -->
	
	<tfoot>
		
		<tr>
			<td colspan="1">&nbsp;</td>
		</tr>
		
	</tfoot>
	
	<!-- END FOOTER -->

</table>

<form action="<?php echo JRoute::_('index.php?option=com_belong'); ?>" method="post" name="adminForm" id="belong-form">
	
	<div>
		<input type="hidden" name="task" value="" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>