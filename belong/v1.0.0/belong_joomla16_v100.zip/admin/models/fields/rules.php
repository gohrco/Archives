<?php

defined('JPATH_BASE') or die;

jimport('joomla.html.html');
jimport('joomla.form.formfield');
jimport('joomla.form.helper');
JFormHelper::loadFieldClass('list');

class JFormFieldRules extends JFormFieldList
{
	protected $type = 'Rules';

	protected function getOptions()
	{
		$db	= & JFactory::getDbo();
		
		$query	= "SELECT `id` as 'value', `name` as 'text' FROM #__belong_rules ORDER BY `name`";
		$db->setQuery( $query );
		$options	= $db->loadObjectList();
		
		if ( $this->value == 0 ) {
			$blank	= array( 'value' => '0', 'text' => '-- Select a Rule --' );
			array_unshift( $options, (object) $blank );
		}
		
		return $options;
	}
}
