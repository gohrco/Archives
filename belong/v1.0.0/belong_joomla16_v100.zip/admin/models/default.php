<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.0 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This file is the default model for Belong
 *  
 */
 
/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );	// Import model
/*-- Security Protocols --*/

class BelongModelDefault extends JModel
{
	
	function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Creates icons for display on the default page
	 * @access		public
	 * @version		1.0.0
	 * @param		JObject		- $canDo: permissions user has
	 * 
	 * @return		array containing icon definitions
	 * @since		1.0.0
	 */
	function getIconDefinitions( $canDo )
	{
		$ret = array();
		
		if ( $canDo->get( 'core.manage' ) ) {
			$ret[] = $this->_makeIconDefinition( 'product-48.png', JText::_('COM_BELONG_BUTTON_PRODUCT'), 'products' );
			$ret[] = $this->_makeIconDefinition( 'rules-48.png', JText::_('COM_BELONG_BUTTON_RULES'), 'rules' );
			$ret[] = $this->_makeIconDefinition( 'productrulesets-48.png', JText::_('COM_BELONG_BUTTON_PRODUCTRULESETS'), 'productrulesets' );
			$ret[] = $this->_makeIconDefinition( 'apicnxn-48.png', JText::_('COM_BELONG_BUTTON_APICNXN'), 'apicnxn' );
			$ret[] = $this->_makeIconDefinition( 'email-48.png', JText::_('COM_BELONG_BUTTON_EMAIL'), 'email' );
		}
		
		$ret[] = $this->_makeIconDefinition( 'help-48.png', JText::_('COM_BELONG_BUTTON_HELP'), 'help');
		
		return $ret;
	}
	
	
	public function getRemotesettings()
	{
		$api	= IntApi::getInstance();
		$data	= $api->get_remote_settings();
		
		if ( $data['result'] == 'success' ) {
			return $data;
		}
		else {
			//return false;
		}
		
		return $data;
	}
	
	
	/**
	 * Retrieves the status of the API connection
	 * @access		public
	 * @version		1.0.0
	 * 
	 * @return		true on success or string containing failed message
	 * @since		1.0.0
	 */
	public function getStatus()
	{
		$api	= IntApi::getInstance();
		$data	= $api->ping();
		
		if ( $data['result'] == 'success' ) {
			return true;
		}
		else {
			return ( isset( $data['message'] ) ? $data['message'] : $data['data'] );
		}
	}
	
	
	private function _makeIconDefinition($iconFile, $label, $controller = null, $view = null, $task = null )
	{
		return array(
			'icon'		=> $iconFile,
			'label'		=> $label,
			'controller'=> $controller,
			'view'		=> ( $view == null ? $controller : $view ),
			'task'		=> $task
		);
	}
}