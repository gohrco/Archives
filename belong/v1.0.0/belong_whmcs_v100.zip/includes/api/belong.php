<?php
/**
 * Belong
 * 
 * @package    WHMCS Package
 * @copyright  2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.0 ( $Id: webhostingslider.php 4 2011-04-13 13:16:15Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.00
 * 
 * @desc       This is the main controller file for the backend of the Web Hosting Slider
 * 
 *-------------------------------------------------------------------------------------------------------------------------------
 * Functionality for `webhostingslider` API Interface
 * 		Purpose
 * 			Provides a custom interface to return necessary variables for the slider configuration in Joomla
 * 			
 * 		Variables:
 * 			task	=>	info			- returns the version of this file
 * 						getcurrencylist	- returns a list of currencies
 * 						getproductlist	- returns a list of products
 * 						getproducts		- returns specific products
 * 							prods	=> comma separated list of product ids
 * 						gettlds			- returns list of top level domains
 * 			
 * 		Usage:
 * 			Curl to the WHMCS API interface with an array of values containing the task and additional variables if needed
 * 
 * 		Examples:
 * 			action	=> belong
 * 			task	=> getproductlist
 * 			prods	=> 2,4,6
 *-------------------------------------------------------------------------------------------------------------------------------
 */

// Be sure a task is set
if (! isset ( $task ) ) {
	$task = 'info';
}

// Create object
$belong = new Belong();
$belong->$task();

/**
 * Performs necessary actions for the Web Hosting Slider component in Joomla
 * @access		public
 * @version		1.0.0
 * 
 * @author		Steven
 * @since		1.00
 */
class Belong
{
	/**
	 * The default character set
	 * @var		string
	 */
	protected $charset	= "UTF-8";
	
	/**
	 * Stores conversion function existance
	 * @var		boolean
	 */
	protected $iconv	= false;
	
	
	/**
	 * The current version of this file
	 * @var		string
	 */
	protected $version = '1.0.0';
	
	
	/**
	 * Stores the version of WHMCS being run
	 * @var 	string
	 */
	protected $whmcsver	= null;
	
	/**
	 * Constructor
	 * @access		public
	 * @version		1.0.0
	 * 
	 * @since		1.00
	 */
	public function __construct()
	{
		define( 'BAPI', true );
		$this->_createObjectvars();
	}
	
	
	/**
	 * Returns the specific information about this file
	 * @access		public
	 * @version		1.0.0
	 *	
	 * @since		1.00
	 */
	public function info()
	{
		require_once( WHMCS_ROOT . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR . 'addons' . DIRECTORY_SEPARATOR . 'belong' . DIRECTORY_SEPARATOR . 'factory.php' );
		
		$config = BFactory :: getConfig();
		
		$rows['enabled'] = $config->get( 'Enabled', false );
		$rows['modvers'] = $config->get( 'Version', '1.0.0' );
		$rows['apivers'] = $this->version;
		
		$this->_close( $rows );
	}
	
	
	/**
	 * Returns the avialable products for selection in the backend
	 * @access		public
	 * @version		1.0.0
	 * 
	 * @since		1.00
	 */
	public function getproductlist()
	{
		global $hidden;
		
		$rows	= array();
		
		$where = '';
		if ( $hidden == '0' ) {
			$where	= " WHERE p.hidden <> 'on' AND (	( p.stockcontrol <> 'on' )
							OR
							( p.stockcontrol = 'on' AND p.qty > 0 )
							)";
		}
		
		$query	=   "SELECT p.id as `id`, 
							p.name as `name`, 
							p.servertype as `moduletype`, 
							g.name as `group`
					FROM tblproducts p
							INNER JOIN tblproductgroups g ON p.gid = g.id" . $where;
		
		$result	= mysql_query( $query );
		
		while ( $row = mysql_fetch_assoc( $result ) )
		{
			$rows['products'][] = $row;
		}
		
		if ( empty( $rows ) )
		{
			$rows['result']		= 'error';
			$rows['message']	= "There are no products to retrieve";
		}
		$this->_close( $rows );
	}
	
	
	public function getproductaddons()
	{
		global $pid;
		
		$query	=	"SELECT *
					 FROM `tbladdons`";
					 
		$result	= mysql_query( $query );
		$rows	=   array();
		
		while( $row = mysql_fetch_assoc( $result ) ) {
			$pids	= explode(',', $row['packages'] );
			
			if ( in_array( $pid, $pids ) ) {
				$rows['addons'][] = array( 'id' => $row['id'], 'name' => $row['name'] );
			}
		}					
		
		
		$query	=   "SELECT p.configoption7
					 FROM `tblproducts` p
					 WHERE p.id = {$pid}
					 	AND p.servertype = 'licensing'";
		
		$result	= mysql_query( $query );
		
		if( $result ) {
			$support	= mysql_result( $result, 0 );
			
			if (! empty( $support ) ) {
				$parts		= explode( "|", $support );
				$id			= array_shift( $parts );
				
				$add_to_array	= true;
				foreach ( $rows['addons'] as $addon ) {
					if ( $addon['id'] == $id ) {
						$add_to_array = false;
						break;
					}
				}
				
				if ( $add_to_array ) {
					$rows['addons'][] = array( 'id' => $id, 'name' => implode( "|", $parts ) );
				}
			}
		}
		
		if ( empty( $rows ) )
		{
			$rows['result']		= 'error';
			$rows['message']	= "There are no product addons to retrieve";
		}
		$this->_close( $rows );
	}
	
	
	public function getuserproducts()
	{
		global $clientid;
		$rows = array();
		
		$query	= "	SELECT h.id as id, h.domainstatus as status, h.packageid as pid
						FROM tblhosting h
						WHERE h.userid = {$clientid}";
		
		$result	= mysql_query( $query );
		
		while( $row = mysql_fetch_assoc( $result ) ) {
			$row['addons'] = array();
			
			$query = "	SELECT o.id as id, h.packageid as pid, o.status as status, o.addonid as aid
						FROM tblhosting h
							INNER JOIN tblhostingaddons o ON ( h.id = o.hostingid )
						WHERE h.userid = {$clientid}
							AND o.hostingid = {$row['id']}";
			
			$sesult = mysql_query( $query );
			
			while ( $sow = mysql_fetch_assoc( $sesult ) ) {
				$row['addons'][] = $sow;
			}
			
			$rows['products'][]	= $row;
		}
		
		if ( empty( $rows ) )
		{
			$rows['result']		= 'error';
			$rows['message']	= "There are no product addons to retrieve";
		}
		$this->_close( $rows );
	}
	
	
	/**
	 * Closes the application
	 * @access		private
	 * @version		1.0.0
	 * @param		mixed		- $data: the data to send back to the calling application
	 * @param		boolean		- $first: if true this is the first run (allows recursion)
	 * 
	 * @since		3.0.0
	 */
	private function _close( $data, $first = true )
	{
		if ( $this->iconv ) {
			foreach ( $data as $key => $value ) {
				if ( is_array( $value ) ) {
					$value = $this->_close( $value, false );
				} else {
					$data[$key] = iconv( "{$this->charset}", "UTF-8//TRANSLIT", $value );
				}
			}
		}
		
		if (! $first ) return $data;
		
		if (! isset( $data['result'] ) ) $data['result'] = 'success';
		echo json_encode( $data ); 
	}
	
	
	/**
	 * Retrieves the character set that is used in WHMCS
	 * @access		private
	 * @version		1.0.0
	 * 
	 * @since		1.00
	 */
	private function _createObjectvars()
	{
		$config	= array( "Charset", "Version" );
		$values	= array();
		
		foreach ( $config as $c ) {
			$query	= "SELECT `value` FROM `tblconfiguration` WHERE `setting` = '{$c}'";
			$result	= mysql_query( $query );
			while ( $row = mysql_fetch_assoc( $result ) ) {
				$values[$c] = $row['value'];
			}
		}
		
		$this->charset	= strtoupper( $values["Charset"] );
		$this->whmcsver	= $values["Version"];
		$this->iconv = ( function_exists( "iconv" ) ? ( $this->charset == "UTF-8" ? false : true ) : false );
		
		return;
	}
	
	
	/**
	 * UTF8 encodes a string
	 * @access		private
	 * @version		1.0.0
	 * @param		string		- $str: string to encode
	 * 
	 * @return		utf8 encoded string
	 * @since		1.00
	 */
	private function _utf8_ensure( $str )
	{
		return $this->_seems_utf8($str)? $str: utf8_encode($str);
	}
	
	
	/**
	 * Tests to see if a string is utf8 encoded
	 * @access		private
	 * @version		1.0.0
	 * @param		string		- $Str: string to check
	 * 
	 * @return		boolean - true if utf8 false if not
	 * @since		1.00
	 */
	private function _seems_utf8( $Str )
	{
		for ($i=0; $i<strlen($Str); $i++)
		{
			if ( ord($Str[$i]) < 0x80 ) continue; # 0bbbbbbb
			elseif ( (ord($Str[$i]) & 0xE0) == 0xC0 ) $n=1; # 110bbbbb
			elseif ( (ord($Str[$i]) & 0xF0) == 0xE0 ) $n=2; # 1110bbbb
			elseif ( (ord($Str[$i]) & 0xF8) == 0xF0 ) $n=3; # 11110bbb
			elseif ( (ord($Str[$i]) & 0xFC) == 0xF8 ) $n=4; # 111110bb
			elseif ( (ord($Str[$i]) & 0xFE) == 0xFC ) $n=5; # 1111110b
			else return false; # Does not match any model
				
			for ( $j=0; $j<$n; $j++ )
			{ # n bytes matching 10bbbbbb follow ?
				if ( (++$i == strlen($Str)) || ((ord($Str[$i]) & 0xC0) != 0x80) )
				return false;
			}
		}
		return true;
	}
}


?>