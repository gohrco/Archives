<?php
/**
 * Belong
 * WHMCS - Configuration File
 * 
 * @package    WHMCS Package
 * @copyright  2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.0 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This file is used to handle configuration values needed by Belong
 *  
 */

/*-- Security Protocols --*/
defined( 'WHMCS' ) or die( 'Restricted access' );
/*-- Security Protocols --*/


/**
 * Config Class
 * @version		1.0.0
 * 
 * @since		1.0.0
 * @author		Steven
 */
class BConfig extends BObject
{
	/**
	 * Stored by WHMCS to control who has access to the Belong module (not used by Integrator)
	 * @access		public
	 * @version		1.0.0
	 * @var			string
	 */
	public $access			= null;
	
	/**
	 * The global override for the module
	 * @access		public
	 * @version		1.0.0
	 * @var			string
	 */
	public $Enabled			= "No";
	
	/**
	 * Stores the URL to the Integrator - no index.php
	 * @access		public
	 * @version		1.0.0
	 * @var 		string
	 */
	public $JoomlaUrl	= null;
	
	/**
	 * The Username for the Integrator API User
	 * @access		public
	 * @version		1.0.0
	 * @var			string
	 */
	public $ApiUsername	= null;
	
	/**
	 * The Password for the Integrator API User
	 * @access		public
	 * @version		1.0.0
	 * @var			string
	 */
	public $ApiPassword	= null;
	
	/**
	 * Stored by WHMCS to indicate the version of the Integrator currently installed in the database
	 * @access		public
	 * @version		1.0.0
	 * @var			string
	 */
	public $version			= "1.0.0";
	
	/**
	 * Catchall for any missing variables - we need to define them
	 * @access		private
	 * @version		1.0.0
	 * @var			array
	 */
	private $data			= array();
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.0.0
	 * 
	 * @since		1.0.0
	 */
	public function __construct()
	{
		$this->load();
	}
	
	
	/**
	 * Binds an array or object of data to the data field for saving
	 * @access		public
	 * @version		1.0.0
	 * @param		array or object	- $data: contains the data to save to the database
	 * 
	 * @since		1.0.0
	 */
	public function bind( $data = array() )
	{
		$bind	= array();
		foreach ( $data as $k => $v ) $bind[$k] = $v;
		$this->data	= $bind;
	}
	
	
	/**
	 * Loads the data from the database and sets it to this object
	 * @access		public
	 * @version		1.0.0
	 * @param		string		- $setting: permits an individual setting to be loaded
	 * 
	 * @since		1.0.0
	 */
	public function load( $setting = null )
	{
		$where	= ( $setting != null ? " AND `setting` = '{$setting}'" : "" );
		
		$db = & BFactory::getDbo();
		$db->setQuery( "SELECT `setting`, `value` FROM tbladdonmodules WHERE `module` = 'belong'".$where );
		$settings	= $db->loadObjectList();
		
		if ( $setting != null ) {
			return (! is_array( $settings ) ? false : $row[0]->value );
		}
		
		foreach ( $settings as $row ) {
			$var = $row->setting;
			if ( $var == "Debug" ) {
				$this->$var = ( $row->value == "Yes" ? true : false );
			}
			else {
				$this->$var = $row->value;
			}
		}
	}
	
	
	/**
	 * Saves any bound data to the database
	 * @access		public
	 * @version		1.0.0
	 * 
	 * @since		1.0.0
	 */
	public function save()
	{
		$data	= $this->data;
		$db = & BFactory::getDbo();
		foreach ( $data as $key => $val ) {
			if ( $this->load( $key ) === false ) {
				$query	= sprintf( "INSERT INTO tbladdonmodules (`module`, `setting`, `value`) VALUES ('belong', %s, %s)",
							$db->Quote( $key ),
							$db->Quote( $val ) );
			}
			else {
				$query	= sprintf( "UPDATE tbladdonmodules SET `value` = %s WHERE `module` = 'belong' AND `setting` = %s",
							$db->Quote( $val ),
							$db->Quote( $key ) );
			}
			$db->setQuery( $query );
			$db->query();
		}
		$this->data = array();
		$this->load();
	}
}