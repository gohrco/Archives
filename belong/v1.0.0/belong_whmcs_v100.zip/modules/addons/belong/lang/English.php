<?php

// Handles the admin translations
$intlang = array(
	'admin_outputhdr'	=> 'API Connection Health Check',
	'admin_labelcnxn'	=> 'Connection Made',
	'admin_labelsets'	=> 'API Credentials',
	'admin_msg01'		=> 'Connection made successfully!',
	'admin_msg02'		=> 'API Credentials Validated!',
	'admin_err01'		=> 'This message received trying to ping your Joomla site:  `%s`.  Please check your settings and try again',
	'admin_err02'		=> 'Connection settings must be valid',
	'admin_err03'		=> 'Message received: %s',
	
	// Configuration area translations
	'cfg_name'			=> 'Belong',
	'cfg_desc'			=> 'This addon allows for group management in Joomla 1.6+ based on product status.  It functions as a subscription handler for WHMCS.',
	
	'cfg_enablelabel'		=> 'Globally Enabled',
	'cfg_enabledesc'		=> 'This is a global override setting.  Setting this to disabled will disable all calls to the remote Joomla application for group management purposes.',
	
	'cfg_joomlaurllabel'	=> 'Joomla URL',
	'cfg_joomlaurldesc'		=> 'Please enter the URL to your installation of Joomla 1.6.  Only include the base path, such as `http://yourdomain.com/joomla`, do not include filenames or SEO rewritten urls.',
	
	'cfg_apiuserlabel'	=> 'Joomla API Username',
	'cfg_apiuserdesc'	=> 'Enter the API Username for Joomla you setup on the Joomla side of the product.',
	
	'cfg_apipasslabel'	=> 'Joomla API Password',
	'cfg_apipassdesc'	=> 'Enter the API Password for the Joomla API user you entered above (set in the Joomla > User Manager).',
	
);

$intlang["err01"] = "Login Details Incorrect. Please try again.";
?>