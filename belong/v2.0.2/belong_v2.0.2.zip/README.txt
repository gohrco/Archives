Belong by Go Higher Information Services, LLC
------------------------------------------------------------------------

 Release Version: 2.0.2
    Release Date: 2013 July 11

 PLEASE READ ALL THE ENCLOSED INSTRUCTIONS

        Forums: https://forum.gohigheris.com
       Support: https://support.gohigheris.com
 Documentation: https://www.gohigheris.com/documentation
   Client Area: https://client.gohigheris.com


[ CONTENTS ] 
------------------------------------------------------------------------

1. Server Requirements
2. Version 2.0.2 Release Notes
3. What's Included and What to do First
4. New Installation Instructions
5. Upgrade Instructions


[ SERVER REQUIREMENTS ]
------------------------------------------------------------------------

1. Joomla 2.5 or above
2. WHMComplete Solution (WHMCS) version 5.0 or above
3. PHP Version 5.x or later
4. MySQL Version 5.x or later
5. Curl Support (with SSL)
6. Dunamis Framework (please check compatibility chart for this version) 


[ VERSION 2.0.2 RELEASE NOTES ]
------------------------------------------------------------------------

To review the details and notes for Belong version 2.0.2 release,
please visit our web site at:

https://www.gohigheris.com/


[ NEW INSTALLATION INSTRUCTIONS ]
------------------------------------------------------------------------

Installation instructions are available through our documentation located
at:

https://www.gohigheris.com/documentation/


[ UPGRADE INSTRUCTIONS ]
------------------------------------------------------------------------

Upgrade instructions are available through our documentation located at:

https://www.gohigheris.com/documentation/