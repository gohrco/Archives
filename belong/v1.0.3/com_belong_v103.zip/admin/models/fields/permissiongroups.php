<?php
/**
* Belong
*
* @package    Belong
* @copyright  2012 Go Higher Information Services.  All rights reserved.
* @license    GNU General Public License version 2, or later
* @version    1.0.3 ( $Id$ )
* @author     Go Higher Information Services
* @since      1.0.3
*
* @desc       This file is a utility helper for Belong
*
*/

/*-- Security Protocols --*/
defined('JPATH_PLATFORM') or die;

/*-- Localscope import --*/
jimport('joomla.html.html');
jimport('joomla.form.formfield');
jimport('joomla.event.dispatcher');


/**
 * JFormFieldPermissionGroups is used to retrieve permission groups from Belong and plugins
 * @version 1.0.3
 * 
 * @since	1.0.3
 * @author	Steven
 */
class JFormFieldPermissiongroups extends JFormField
{
	/**
	 * Name of this field type
	 * @access		protected
	 * @since		1.0.3
	 * @var			string
	 */
	protected $type = 'Permissiongroups';
	
	
	/**
	 * Gets the input for the form
	 * @access		protected
	 * @version		1.0.3
	 * 
	 * @return		string containing HTML form
	 * @since		1.0.3
	 */
	protected function getInput()
	{
		// Initialize variables.
		$data		= array();
		$options	= array();
		$attr		= '';
		
		// Initialize some field attributes.
		$attr .= $this->element['class'] ? ' class="'.(string) $this->element['class'].'"' : '';
		$attr .= ((string) $this->element['disabled'] == 'true') ? ' disabled="disabled"' : '';
		$attr .= $this->element['size'] ? ' size="'.(int) $this->element['size'].'"' : '';
		$attr .= $this->multiple ? ' multiple="multiple"' : '';
		
		// Initialize JavaScript field attributes.
		$attr .= $this->element['onchange'] ? ' onchange="'.(string) $this->element['onchange'].'"' : '';
		
		// Iterate through the children and build an array of options.
		foreach ($this->element->children() as $option) {
			
			// Only add <option /> elements.
			if ($option->getName() != 'option') {
				continue;
			}
			
			// Create a new option object based on the <option /> element.
			$tmp = JHtml::_('select.option', (string) $option['value'], trim((string) $option), 'value', 'text', ((string) $option['disabled']=='true'));
			
			// Set some option attributes.
			$tmp->class = (string) $option['class'];
			
			// Set some JavaScript option attributes.
			$tmp->onclick = (string) $option['onclick'];
			
			// Add the option object to the result set.
			$options[] = $tmp;
		}
		
		$data[] = array( 'items' => $this->getJoomlagroups(), 'text' => 'Joomla (local)' );
		
		// Get all the other extended groups
		JPluginHelper :: importPlugin( 'belong' );
		
		$dispatcher		= & JDispatcher :: getInstance();
		$more			=   $dispatcher->trigger( 'onGetPermissionGroups', array( $data ) );
		
		if (! empty( $more ) ) $data = $more[0];
		
		//return 
		return JHtml::_('select.groupedlist', $data, $this->name, array( 'list.attr' => $attr, 'list.select' => $this->value ) );
	}
	
	
	/**
	 * Retrieves the Joomla usergroups
	 * @access		private
	 * @version		1.0.3
	 * 
	 * @return		array of HTML option tags
	 * @since		1.0.3
	 */
	private function getJoomlagroups()
	{
		$db = JFactory::getDbo();
		$db->setQuery(
					'SELECT a.id AS value, a.title AS text, COUNT(DISTINCT b.id) AS level' .
					' FROM #__usergroups AS a' .
					' LEFT JOIN #__usergroups AS b ON a.lft > b.lft AND a.rgt < b.rgt' .
					' GROUP BY a.id' .
					' ORDER BY a.lft ASC'
		);
		$options = $db->loadObjectList();
		
		// Check for a database error.
		if ($db->getErrorNum()) {
			JError::raiseNotice(500, $db->getErrorMsg());
			return null;
		}
		
		for ($i = 0, $n = count($options); $i < $n; $i++) {
			$options[$i]->text = str_repeat('- ', $options[$i]->level).$options[$i]->text;
		}
		
		return $options;
	}
}