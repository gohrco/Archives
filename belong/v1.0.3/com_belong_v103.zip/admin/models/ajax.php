<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.3 ( $Id: ajax.php 36 2012-02-20 13:00:31Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the ajax model file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die();
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.helper' );
jimport( 'joomla.application.component.model' );
/*-- File Inclusions --*/

/**
 * Belong Ajax Model
 * @author		Steven
 * @version		1.0.3
 * 
 * @since		1.0.0
 */
class BelongModelAjax extends JModel
{
	
	/**
	 * Called to check the API connection from the "API Connection" feature
	 * @access		public
	 * @version		1.0.3
	 * 
	 * @return		array containing results
	 * @since		1.0.0
	 */
	public function apicnxn()
	{
		$apiurl	= rtrim(trim( urldecode( JRequest::getVar( 'apiurl' ) ) ), '/' );
		
		// If we didn't get a URL then don't continue
		if (! $apiurl ) {
			$data['result'] = 'error';
			$data['message'] = 'No URL entered';
			return $data;
		}
		
		// Be sure to urldecode the variables
		$apiusername	= urldecode( JRequest::getVar( 'apiusername' ) );
		$apipassword	= urldecode( JRequest::getVar( 'apipassword' ) );
		$apiaccesskey	= trim( urldecode( JRequest::getVar( 'apiaccesskey' ) ) );
		
		// If the accesskey should be empty, set it to null
		if (! $apiaccesskey ) {
			$apiaccesskey = null;
		}
		
		// If there wasn't a username or password then don't continue
		if ((! $apiusername ) || (! $apipassword ) ) {
			$data['result']	= 'error';
			$data['message']	= "Please enter a " . ((! $apiusername ) ? "API Username" : "API Password" );
			return $data;
		}
		
		// If the password has an & we can't authenticate (WHMCS filters them out)
		if ( strpos( $apipassword, "&" ) !== false ) {
			$data['result']	= 'error';
			$data['message']	= "Your API password cannot contain an ampersand.";
			return $data;
		}
		
		$data	= array( 'ApiUrl' => $apiurl, 'ApiUsername' => $apiusername, 'ApiPassword' => $apipassword, 'ApiAccesskey' => $apiaccesskey );
		
		// Save the API variables to the database
		$table = & JTable::getInstance( 'extension' );
		$table->load( array( 'element' => 'com_belong', 'type' => 'component' ) );
		$table->save( array( 'params' => $data ) );
		
		$api	= BelongApi::getInstance( array( 'ApiUrl' => $apiurl, 'ApiUsername' => $apiusername, 'ApiPassword' => $apipassword, 'ApiAccesskey' => $apiaccesskey ) );
		$ping	= $api->ping();
		
		if (! isset( $ping['result'] ) ) {
			return array( 'result' => 'error', 'message' => 'Problem connecting to the API' );
		}
		
		if ( $ping['result'] != 'success' ) {
			return array( 'result' => 'error', 'message' => ( isset( $ping['data'] ) ? $ping['data'] : $ping['message'] ) );
		}
		
		return array( 'result' => 'success', 'message' => 'Successfully connected!' );
	}
	
	
	/**
	 * Retrieves available product addons
	 * @access		public
	 * @version		1.0.3
	 * 
	 * @return		array containing results
	 * @since		1.0.0
	 */
	public function getproductaddons()
	{
		if (! ( $pid = JRequest::getVar( 'pid', false ) ) ) {
			return array( 'result' => 'error' );
		}
		
		$api = BelongApi::getInstance();
		$data	= $api->get_product_addons( array( 'pid' => $pid ) );
		
		if (! isset( $data['result'] ) ) {
			return array( 'result' => 'error', 'message' => 'Problem connecting to the API' );
		}
		
		if ( $data['result'] != 'success' ) {
			return array( 'result' => 'error', 'message' => $data['message'] );
		}
		
		// If no addons - return single item
		if (! isset( $data['addons'] ) ) {
			return array( 'result' => 'success', 'message' => array( array( 'id' => '0', 'name' => $data['message'] ) ) );
		}
		
		array_unshift( $data['addons'], array( 'id' => '0', 'name' => '-- Select an addon --' ) );
		return array( 'result' => 'success', 'message' => $data['addons'] );
		
	}
}