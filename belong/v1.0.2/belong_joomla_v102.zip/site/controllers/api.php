<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.2 ( $Id: api.php 33 2012-01-14 16:56:05Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This file is the API controller for handling interaction between the Belong on WHMCS and Joomla 1.6
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * API Controller Class Object
 * @version		1.0.2
 * 
 * @since		1.0.0
 * @author		Steven
 */
class BelongControllerApi extends JController
{
	/**
	 * Contains an array of return variables to send back to calling site
	 * @access		public
	 * @var			array
	 * @since		1.0.0
	 */
	public $_returnmsg = array();
	
	/**
	 * Constructor
	 * @access		public
	 * @version		1.0.2
	 * 
	 * @since		1.0.0
	 */
	public function __construct()
	{
		// Be sure to check for this in plugins
		if (! defined( "BELONG_API" ) ) define ( "BELONG_API", true );
		
		$task	= JRequest :: getVar( 'task', 'ping' );
		
		// Let's login first
		if ( JRequest::getVar( "task" ) != "ping" ) {
			$this->_login();
		}
		
		parent::__construct();
		
	}
	
	
	/**
	 * Called up by WHMCS when a product status is changed
	 * @access		public
	 * @version		1.0.2
	 * 
	 * @since		1.0.0
	 */
	public function belong()
	{
		$model = $this->getModel( 'api' );
		
		if ( ( $err = $model->belong() ) ) {
			$this->_setMessage( "Updated", false ); 
		}
		else {
			$this->_setError( $err, false );
		}
		$this->_close();
	}
	
	
	/**
	 * Called up by WHMCS when running a cron job
	 * @access		public
	 * @version		1.0.2
	 * 
	 * @since		1.0.2
	 */
	public function cron()
	{
		$model = $this->getModel( 'api' );
		
		if ( ( $err = $model->cron() ) ) {
			$this->_setMessage( 'Updated', false );
		}
		else {
			$this->_setError( $err, false );
		}
		$this->_close();
	}
	
	
	/**
	 * Simple function to check the status of the api username / password to ensure they connect
	 * @access		public
	 * 
	 * @since		1.0.0
	 */
	public function login()
	{
		$this->_setMessage( "Validated", false );
		$this->_close();
	}
	
	
	/**
	 * Simple function to check status of connection
	 * @access public
	 * 
	 * @since  1.0.0
	 */
	public function ping()
	{
		$this->_setMessage( "Pong", false );
		$this->_close();
	}
	
	
	/**
	 * **********************************************************************
	 * PRIVATE METHODS BELOW
	 * **********************************************************************
	 */
	
	
	/**
	 * Closes the application
	 * @access		private
	 * @version		1.0.2
	 * 
	 * @since		1.0.0
	 */
	private function _close()
	{
		$app	= JFactory::getApplication();		// Get the application
		$msg	= $this->get( "_returnmsg", null );	// Grab the message
		echo json_encode( $msg );					// Send message
		$this->_logout();
		$app->close();								// Close application
	}
	
	
	/**
	 * Logs the API user in
	 * @access		private
	 * @version		1.0.2
	 * 
	 * @return 		boolean true on success, closes application if failure
	 * @since 		1.0.0
	 */
	private function _login()
	{
		// Be sure to set the constant so we don't try to add the user to WHMCS!
		if (! defined( "INTLOGIN" ) ) define( "INTLOGIN", true );
		
		$app			=   JFactory::getApplication();
		$user			=   JFactory::getUser();
		$guest			=   $user->get( "guest", 1 );
		$options		=   array( "silent" => false, 'integrator' => true );
		
		if ( ( $guest != 1 ) AND (! $user->authorise( "manage", "com_belong" ) ) ) {
			$app->logout( $user->get( "id" ), $options );
			$guest = 1;
		}
		
		if ( $guest == 1 ) {
			
			$credentials	= & JRequest::getVar( 'credentials', array(), 'post' );
			
			$err = $app->login( $credentials, $options );
			
			if (! $app->login($credentials, $options) ) {
				// Login failed
				$this->_setError( 'LOGIN_ERRORLOGIN' );
				$this->_close();
			}
		}
		
		$user			=   JFactory::getUser();
		
		if (! $user->authorise( "manage", "com_belong" ) ) {
			// Log this user out
			$app->logout( $user->get( "id" ), $options );
			
			// User not authorised
			$this->_setError( 'LOGIN_ERRORAUTH' );
			$this->_close();
		}
		
		return true;
	}
	
	
	/**
	 * Logs the API user out
	 * @access		private
	 * @version		1.0.2
	 * @param		int		- $id: the joomla id of the api admin user
	 * 
	 * @since		1.0.0
	 */
	private function _logout( $id = null )
	{
		$options = array( "silent" => false, 'integrator' => true );
		$app = JFactory :: getApplication();
		$app->logout( $id, $options );
		return;
	}
	
	/**
	 * Sets an error message
	 * @access		private
	 * @version		1.0.2
	 * @param 		varies		- $msg: Contains the error message to throw back
	 * @param		boolean		- $trans: Should the message be translated ? true if so
	 * 
	 * @since		1.0.0
	 */
	private function _setError( $msg, $trans = true )
	{
		$this->set( "_returnmsg", array( "result" => "error", "data" => ( $trans ? $this->_trans( $msg ) : $msg ) ) );
	}
	
	
	/**
	 * Sets a successful message
	 * @access		private
	 * @version		1.0.2
	 * @param		varies		- $msg: Contains the data to send back
	 * @param		boolean		- $trans: Should the message be translated ? true if so
	 * 
	 * @since		1.0.0
	 */
	private function _setMessage( $msg, $trans = true )
	{
		$this->set( "_returnmsg", array( "result" => "success", "data" => ( $trans ? $this->_trans( $msg ) : $msg ) ) );
		return;
	}
	
	
	/**
	 * Translates a string
	 * @access		private
	 * @version		1.0.2
	 * @param		string		- $msg: the string to translate
	 * 
	 * @return		string containing translated message
	 * @since		1.0.0
	 */
	private function _trans( $msg )
	{
		return JText::_( 'COM_BELONG_API_' . strtoupper( $msg ) );
	}
}