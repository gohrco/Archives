<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.2 ( $Id: ajax.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the ajax controller file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die('Restricted access');
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.controlleradmin');
/*-- File Inclusions --*/

/**
 * Belong Ajax Controller
 * @author		Steven
 * @version		1.0.2
 * 
 * @since		1.0.0
 */
class BelongControllerAjax extends JControllerAdmin
{
	/**
	 * Checks the API connection
	 * @access		public
	 * @version		1.0.2
	 * 
	 * @since		1.0.0
	 */
	public function apicnxn()
	{
		$app	= & JFactory::getApplication();
		$model	=   $this->getModel( 'ajax' );
		$data	=   $model->apicnxn();
		echo $this->buildResponse($data);
		$app->close();
	}
	
	
	/**
	 * Retrieves available product addons via ajax
	 * @access		public
	 * @version		1.0.2
	 * 
	 * @since		1.0.0
	 */
	public function getproductaddons()
	{
		$app	= & JFactory::getApplication();
		$model	=   $this->getModel( 'ajax' );
		$data	=   $model->getproductaddons();
		echo json_encode( $data );
		$app->close();
	}
	
	
	/**
	 * Builds a XML response for ajax
	 * @access		private
	 * @version		1.0.2
	 * @param		array		- $data: the data to create a response for
	 * 
	 * @return		string containing xml response
	 * @since		1.0.0
	 */
	private function buildResponse($data) {
		$return[] = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>";
		$return[] = "<root><param>";
		foreach ($data as $k => $v) {
			if (is_array($v)) {
				foreach ($v as $k2 => $v2) {
					$sub[] = '<'.$k.'><![CDATA['.$v2.']]></'.$k.'>';
				}
				$return[] = '<'.$k.'s>'.implode("\n", $sub).'</'.$k.'s>';
			}
			else {
				$return[] = '<'.$k.'><![CDATA['.$v.']]></'.$k.'>';
			}
		}
		$return[] = "</param></root>";
		
		return implode("", $return);
	}
}