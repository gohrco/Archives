<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.2 ( $Id: email.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the email controller for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die('Restricted access');
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.controllerform' );
jimport( 'joomla.user.helper' );
/*-- File Inclusions --*/

/**
 * Belong Email Controller
 * @author		Steven
 * @version		1.0.2
 * 
 * @since		1.0.0
 */
class BelongControllerEmail extends JControllerForm
{
	/**
	 * Find task
	 * @access		public
	 * @version		1.0.2
	 * 
	 * @since		1.0.0
	 */
	public function find()
	{
		JRequest :: setVar( 'view', 'email' );
		JRequest :: setVar( 'layout', 'find' );
		
		parent::display();
	}
	
	
	/**
	 * Runs the ruleset against the selected user
	 * @access		public
	 * @version		1.0.2
	 * 
	 * @since		1.0.0
	 */
	public function run()
	{
		JRequest :: setVar( 'view', 'email' );
		JRequest :: setVar( 'layout', 'results' );
		
		// Handle rulesets
		BelongHelper :: runRulesets( JRequest :: getVar( 'wid', 0 ), 'whmcs' );
		
		parent::display();
	}
}