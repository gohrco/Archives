<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.2 ( $Id: rules.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the rules table file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die('Restricted access');
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.database.table');
/*-- File Inclusions --*/

/**
 * Belong Rules Table
 * @author		Steven
 * @version		1.0.2
 * 
 * @since		1.0.0
 */
class BelongTableRules extends JTable
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.0.2
	 * @param		JDatabase object	- $db: db instance
	 * 
	 * @since		1.0.0
	 */
	public function __construct( &$db ) 
	{
		parent::__construct( '#__belong_rules', 'id', $db );
	}
	
	/**
	 * Binds an array of data to the object
	 * @access		public
	 * @version		1.0.2
	 * @param		array		- $array: data to bind
	 * @param		string		- $ignore: items to ignore
	 * 
	 * @return		parent :: bind()
	 * @since		1.0.0
	 */
	public function bind($array, $ignore = '') 
	{
		if (isset($array['data']) && is_array($array['data'])) 
		{
			// Convert the params field to a string.
			$parameter = new JRegistry;
			$parameter->loadArray($array['data']);
			$array['data'] = (string)$parameter;
		}
		return parent::bind($array, $ignore);
	}
 
	/**
	 * Overloaded load function
	 *
	 * @param       int $pk primary key
	 * @param       boolean $reset reset data
	 * @return      boolean
	 * @see JTable:load
	 */
	public function load($pk = null, $reset = true) 
	{
		if (! parent::load($pk, $reset)) {
			return false;
		}
		
		if ( is_string( $this->data ) ) {
			$this->data = json_decode( $this->data );
		}
		
		return true;
	}
}