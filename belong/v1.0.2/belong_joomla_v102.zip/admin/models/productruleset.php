<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.2 ( $Id: productruleset.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the productruleset model file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die();
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.modeladmin');
/*-- File Inclusions --*/

/**
 * Belong Productruleset Model
 * @author		Steven
 * @version		1.0.2
 * 
 * @since		1.0.0
 */
class BelongModelProductruleset extends JModelAdmin
{
	/**
	 * Grabs the table
	 * @access		public
	 * @version		1.0.2
	 * @param		string		- $type: indicates which table
	 * @param		string		- $prefix: indicates the prefix
	 * @param		array		- $config: configuration array
	 * 
	 * @return		JTable object
	 * @since		1.0.0
	 */
	public function getTable( $type = 'Productrulesets', $prefix = 'BelongTable', $config = array() ) 
	{
		return JTable::getInstance($type, $prefix, $config);
	}
	
	
	/**
	 * Retrieves the form for display
	 * @access		public
	 * @version		1.0.2
	 * @param		array		- $data: placeholder only
	 * @param		bool		- $loadData: tells to load the data or not
	 * 
	 * @return		JForm object or false on error
	 * @since		1.0.0
	 */
	public function getForm($data = array(), $loadData = true) 
	{
		// Get the form.
		$form = $this->loadForm('com_belong.productruleset', 'productruleset',
		                        array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form)) 
		{
			return false;
		}
		
		return $form;
	}
	
	
	/**
	 * Called to load the form data
	 * @access		protected
	 * @version		1.0.2
	 * 
	 * @return		array of data for form
	 * @since		1.0.0
	 */
	protected function loadFormData() 
	{
		// Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_belong.edit.productruleset.data', array());
		if ( empty( $data ) ) 
		{
			$data = $this->getItem();
		}
		return $data;
	}
	
	
	/**
	 * Allows for saving the order
	 * @access		public
	 * @version		1.0.2
	 * @param		array		- $pks: pieces of the form
	 * @param		array		- $order: corresponding order
	 * 
	 * @return		bool
	 * @since		1.0.0
	 */
	public function saveorder($pks = null, $order = null)
	{
		// Initialise variables.
		$table		= $this->getTable();
		$conditions	= array();
		$user = JFactory::getUser();

		if ( empty( $pks ) ) {
			return JError::raiseWarning(500, JText::_($this->text_prefix.'_ERROR_NO_ITEMS_SELECTED'));
		}
		
		// Cycle through order values ensuring uniques
		asort( $order );
		$used	= array();
		foreach( $order as $pk => &$o ) {
			if ( in_array( $o, $used ) ) {
				$o = end( $used ) + 1;
			}
			$used[] = $o;
		}
		ksort( $order );
		
		// update ordering values
		foreach ($pks as $i => $pk) {
			$table->load((int) $pk);

			// Access checks.
			if (! $this->canEditState( $table ) ) {
				// Prune items that you can't change.
				unset($pks[$i]);
				JError::raiseWarning(403, JText::_('JLIB_APPLICATION_ERROR_EDITSTATE_NOT_PERMITTED'));
			}
			else if ($table->priority != $order[$i]) {
				$table->priority = $order[$i];

				if (!$table->store()) {
					$this->setError($table->getError());
					return false;
				}

				// Remember to reorder within position and client_id
				$condition = $this->getReorderConditions($table);
				$found = false;

				foreach ($conditions as $cond) {
					if ($cond[1] == $condition) {
						$found = true;
						break;
					}
				}

				if (!$found) {
					$key = $table->getKeyName();
					$conditions[] = array ($table->$key, $condition);
				}
			}
		}

		// Execute reorder for each category.
		foreach ($conditions as $cond) {
			$table->load($cond[0]);
			$table->reorder($cond[1]);
		}

		// Clear the component's cache
		$this->cleanCache();

		return true;
	}
}