<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.2 ( $Id: products.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the products model file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die();
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.modellist');
/*-- File Inclusions --*/ 

/**
 * Belong Products Model
 * @author		Steven
 * @version		1.0.2
 * 
 * @since		1.0.0
 */
class BelongModelProducts extends JModelList
{
	
	/**
	 * Retrieves the data from the database for display
	 * @access		protected
	 * @version		1.0.2
	 * 
	 * @return		JDatabaseQuery object
	 * @since		1.0.0
	 */
	protected function getListQuery()
	{
		// Create a new query object.		
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		// Select some fields
		$query->select('id,name');
		// From the hello table
		$query->from('#__belong_products');
		return $query;
	}
}