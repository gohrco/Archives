<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.2 ( $Id: view.html.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the main view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.view' );
include_once( JPATH_COMPONENT_ADMINISTRATOR . DS . 'helper.php' );
/*-- File Inclusions --*/

/**
 * Belong Default View
 * @author		Steven
 * @version		1.0.2
 * 
 * @since		1.0.0
 */
class BelongViewDefault extends JView
{
	
	/**
	 * Display view
	 * @access		public
	 * @version		1.0.2
	 * @param		string		- $tpl: contains a template to overload with
	 * 
	 * @return		parent :: display()
	 * @since		1.0.0
	 */
	public function display($tpl = null)
	{
		$model	= & $this->getModel('default');
		$user	= & JFactory::getUser();
		$task	=   JRequest::getVar( 'task' );
		$status	=   $this->get( 'Status' );
		
		if ( $status ) {
			$this->remote = $this->get( 'Remotesettings' );
		}
		
		// Retrieve ACL permitted actions
		$canDo	= BelongHelper :: getActions();
		
		$icons = $model->getIconDefinitions( $canDo );
		
		BelongHelper :: addMedia( 'admin.main/css' );
		BelongHelper :: addToolbar ( 'default', $task, $canDo );
		
		$this->assignRef('icondefs', $icons); // Icon definitions
		$this->assignRef('data',	$params);
		$this->assignRef( 'status',	$status );
		
		parent::display($tpl);
	}
}