<?php
/**
 * Belong
 * Belong - System: API Handler Plugin
 *
 * @package    Belong
 * @copyright  2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.0.0 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.0.0
 *
 * @desc       This is the installation script executed by Joomla! 2.5+
 *
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( "joomla.filesystem.file" );


/**
 * plgsystembelong_system installation Script
 * @version		2.0.0
 *
 * @since		2.0.0
 * @author		Steven
 */
if (! class_exists( 'plgsystembelong_systemInstallerScript' ) ) {	// Workaround for Installation purposes
	class plgsystembelong_systemInstallerScript
	{
		/**
		 * Run at the time of upgrade only
		 * @access		public
		 * @version		2.0.0
		 * @param		JApplication object	- $parent: calls this function
		 *
		 * @since		2.0.0
		 */
		public function install( $parent )
		{
			return;
		}


		/**
		 * Run at the time of uninstallation only
		 * @access		public
		 * @version		2.0.0
		 * @param		JApplication object	- $parent: calls this function
		 *
		 * @since		2.0.0
		 */
		public function uninstall( $parent )
		{
			return;
		}


		/**
		 * Run at the time of upgrade only
		 * @access		public
		 * @version		2.0.0
		 * @param		JApplication object	- $parent: calls this function
		 *
		 * @since		2.0.0
		 */
		public function update( $parent )
		{
			return;
		}


		/**
		 * Runs prior to installation, upgrade or uninstallation
		 * @access		public
		 * @version		2.0.0
		 * @param		string				- $type: the task being performed (install, upgrade etc)
		 * @param		JApplication object	- $parent: calls this function
		 *
		 * @since		2.0.0
		 */
		public function preflight( $type, $parent )
		{
			return;
		}


		/**
		 * Runs after installation, upgrade
		 * @access		public
		 * @version		2.0.0
		 * @param		string				- $type: the task being performed (install, upgrade etc)
		 * @param		JApplication object	- $parent: calls this function
		 *
		 * @since		2.0.0
		 */
		public function postflight( $type, $parent )
		{
			$path			=	JPATH_PLUGINS		. DIRECTORY_SEPARATOR
							.	'system'			. DIRECTORY_SEPARATOR
							.	'belong_system'		. DIRECTORY_SEPARATOR;
			
			JFile :: move( '_belong_system_30.xml', 'belong_system.xml', $path );
			
			return;
		}
	}
}