<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.5 ( $Id: api.php 39 2012-03-06 16:39:06Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This file contains the api model which allows the api interface to interact with the data
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
jimport( 'joomla.application.component.model' );	// Import model
require_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'helper.php' );
/*-- Localscope import --*/

/**
 * API model class object
 * @version		1.0.5
 * 
 * @since		1.0.0
 * @author		Steven
 */
class BelongModelApi extends JModel
{
	
	public $runerror = null;
	
	/**
	 * Constructor
	 * @access		public
	 * @version		1.0.5
	 * 
	 * @since		1.0.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Handles an individual request for update
	 * @access		public
	 * @version		1.0.5
	 * 
	 * @return		bool
	 * @since		1.0.0
	 */
	public function belong()
	{
		$debug			=   BelongDebug :: getInstance( true );
		
		if (! ( $email = JRequest :: getVar( 'email', null ) ) ) {
			$this->set( 'runerror', 'No email address provided to Belong' );
			return false;
		}
		
		if (! BelongHelper :: runRulesets( $email, 'whmcs', false ) ) {
			$this->set( 'runerror', end( $debug->send() ) );
			return false;
		}
		
		return true;
	}
	
	
	/**
	 * Handles a cron request
	 * @access		public
	 * @version		1.0.5
	 * 
	 * @return		bool
	 * @since		1.0.0
	 */
	public function cron()
	{
		$debug	= BelongDebug :: getInstance( true );
		
		if (! BelongHelper :: runCron() ) {
			$this->set( 'error', end( $debug->send() ) );
			return false;
		}
		
		return true;
	}
}