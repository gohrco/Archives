<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.5 ( $Id: view.html.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the rule view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.view' );
include_once( JPATH_COMPONENT_ADMINISTRATOR . DS . 'helper.php' );
/*-- File Inclusions --*/

/**
 * Belong Rules View
 * @author		Steven
 * @version		1.0.5
 * 
 * @since		1.0.0
 */
class BelongViewRules extends JView
{
	
	/**
	 * Display view
	 * @access		public
	 * @version		1.0.5
	 * @param		string		- $tpl: contains a template to overload with
	 * 
	 * @return		parent :: display()
	 * @since		1.0.0
	 */
	function display( $tpl = null )
	{
		$items		=   $this->get( 'Items' );
		$pagination	=   $this->get( 'Pagination' );
		
		if ( count( $errors = $this->get( 'Errors' ) ) ) {
			JError::raiseError( 500, implode('<br />', $errors ) );
			return false;
		}
		
		// Retrieve ACL permitted actions
		$canDo	= BelongHelper :: getActions();
		
		BelongHelper :: addMedia( 'admin.main/css' );
		BelongHelper :: addToolbar( 'rules', $task, $canDo );
		
		$this->items		= $items;
		$this->pagination	= $pagination;
		
		parent::display($tpl);
	}
}