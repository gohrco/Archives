<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.5 ( $Id: default.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the default layout for the email view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusion --*/
JHtml::_('behavior.tooltip');
/*-- File Inclusion --*/

?>
<form action="<?php echo JRoute::_('index.php?option=com_belong'); ?>"
      method="post" name="adminForm" id="belong-form">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BELONG_RULE_EDIT_RULEDETAILS' ); ?></legend>
		<ul class="adminformlist">
<?php foreach($this->form->getFieldset( 'details' ) as $field): ?>
			<li><?php echo $field->label;echo $field->input;?></li>
<?php endforeach; ?>
		</ul>
	</fieldset>
	
	<div>
		<input type="hidden" name="task" value="email.find" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>