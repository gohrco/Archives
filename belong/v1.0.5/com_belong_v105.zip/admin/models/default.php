<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.5 ( $Id: default.php 33 2012-01-14 16:56:05Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This file is the default model for Belong
 *  
 */
 
/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.model' );	// Import model
/*-- File Inclusions --*/

/**
 * Belong Default Model
 * @author		Steven
 * @version		1.0.5
 * 
 * @since		1.0.0
 */
class BelongModelDefault extends JModel
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.0.5
	 * 
	 * @since		1.0.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Creates icons for display on the default page
	 * @access		public
	 * @version		1.0.5
	 * @param		JObject		- $canDo: permissions user has
	 * 
	 * @return		array containing icon definitions
	 * @since		1.0.0
	 */
	public function getIconDefinitions( $canDo )
	{
		$ret = array();
		
		if ( $canDo->get( 'core.manage' ) ) {
			$ret[] = $this->_makeIconDefinition( 'product-48.png', JText::_('COM_BELONG_BUTTON_PRODUCT'), 'products' );
			$ret[] = $this->_makeIconDefinition( 'rules-48.png', JText::_('COM_BELONG_BUTTON_RULES'), 'rules' );
			$ret[] = $this->_makeIconDefinition( 'productrulesets-48.png', JText::_('COM_BELONG_BUTTON_PRODUCTRULESETS'), 'productrulesets' );
			$ret[] = $this->_makeIconDefinition( 'apicnxn-48.png', JText::_('COM_BELONG_BUTTON_APICNXN'), 'apicnxn' );
			$ret[] = $this->_makeIconDefinition( 'email-48.png', JText::_('COM_BELONG_BUTTON_EMAIL'), 'email' );
		}
		
		$ret[] = $this->_makeIconDefinition( 'help-48.png', JText::_('COM_BELONG_BUTTON_HELP'), null, null, 'help' );
		
		return $ret;
	}
	
	
	/**
	 * Retrieves the remote settings from WHMCS
	 * @access		public
	 * @version		1.0.5
	 * 
	 * @return		array of data or false on error
	 * @since		1.0.0
	 */
	public function getRemotesettings()
	{
		$api	= BelongApi::getInstance();
		$data	= $api->get_remote_settings();
		
		if ( $data['result'] == 'success' ) {
			return $data;
		}
		else {
			return false;
		}
		
		return $data;
	}
	
	
	/**
	 * Retrieves the status of the API connection
	 * @access		public
	 * @version		1.0.5
	 * 
	 * @return		true on success or string containing failed message
	 * @since		1.0.0
	 */
	public function getStatus()
	{
		$api	= BelongApi::getInstance();
		$data	= $api->ping();
		
		if ( $data['result'] == 'success' ) {
			return true;
		}
		else {
			return ( isset( $data['message'] ) ? $data['message'] : $data['data'] );
		}
	}
	
	
	/**
	 * Creates an icon definition
	 * @access		private
	 * @version		1.0.5
	 * @param		string		- $iconFile: image file name
	 * @param		string		- $label: label to use
	 * @param		string		- $controller: where to go
	 * @param		string		- $view: what to see
	 * @param		string		- $task: what to do
	 * 
	 * @return		array of items compiled for view
	 * @since		1.0.0
	 */
	private function _makeIconDefinition($iconFile, $label, $controller = null, $view = null, $task = null )
	{
		return array(
			'icon'		=> $iconFile,
			'label'		=> $label,
			'controller'=> $controller,
			'view'		=> ( $view == null ? $controller : $view ),
			'task'		=> $task
		);
	}
}