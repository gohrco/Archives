function getproductaddons( oid )
{
	var prod	= jQuery( '#product' );
	var adds	= jQuery( '#prodaddon' );
	var url		= jQuery( '#belongproductsurl' ).val();
	
	// Make the Ajax Call
	var resp	= jQuery.ajax({
					type: "POST",
					url: url + '/ajax.php',
					dataType: 'json',
					data: { task: 'getproductaddons',
							relid: prod.val()
					}
				});
	
	// Success
	resp.done( function( msg ) {
		adds.empty();
		var i;
		for ( i = 0; i < msg.length; ++i ) {
			var row = msg[i];
			adds.append( jQuery( "<option/>", {
				value: row.id,
				text: row.name
			}));
		};
		
		// If we passed an ID then select it
		if( typeof oid != 'undefined') {
			adds.find("option[value='"+oid+"']").attr("selected", "selected");
		}
	});
	
	// Failure
	resp.fail( function( jqXHR, msg ) {
		alert( msg );
	});
}