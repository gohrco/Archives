function checkApicnxn()
{
	var apiurl = encodeURIComponent( document.getElementById( 'apiurl' ).value );
	var apiusername	= encodeURIComponent( document.getElementById( 'apiusername' ).value );
	var apipassword = encodeURIComponent( document.getElementById( 'apipassword' ).value );
	var apiaccesskey = encodeURIComponent( document.getElementById( 'apiaccesskey' ).value );
	
	var apistatusimg = document.getElementById( 'apistatusimg' );
	var apistatusmsg = document.getElementById( 'apistatusmsg' );
	var apistatusdef = document.getElementById( 'apistatusmsgdefault' ).value;
	
	apistatusimg.removeClass( 'ajaxSuccess' ).removeClass( 'ajaxError' ).addClass( 'ajaxLoading' );
	apistatusmsg.innerHTML=apistatusdef;
	
	var xhr = createXHR();
	xhr.open("GET","index.php?option=com_belong&task=ajax.apicnxn&apiusername="+apiusername
			+"&apipassword="+apipassword
			+"&apiaccesskey="+apiaccesskey
			+"&apiurl="+apiurl,true);
	xhr.send( null );
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				try //Internet Explorer
				{
					xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
					xmlDoc.async="false";
					xmlDoc.loadXML(xhr.responseText);
				}
				catch(e)
				{
					try //Firefox, Mozilla, Opera, etc.
					{
						parser=new DOMParser();
						xmlDoc=parser.parseFromString(xhr.responseText,"text/xml");
					}
					catch(e) {alert(e.message)}
				}
				var result =xmlDoc.getElementsByTagName("param").item(0);
				
				var dsc = result.getElementsByTagName("result")[0].childNodes[0].nodeValue;
				var msg = result.getElementsByTagName("message")[0].childNodes[0].nodeValue;
				
				if (dsc == "success") {
					apistatusimg.removeClass('ajaxLoading').addClass('ajaxSuccess');
					document.getElementById('apiconnection').setAttribute("value", "1");
				}
				else {
					apistatusimg.removeClass('ajaxLoading').addClass('ajaxError');
				}
				apistatusmsg.innerHTML=msg;
			}
			else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function getproductaddons( oid ) {
	var pid = document.getElementById('jform_pid').value;
	var aid = document.getElementById( 'jform_aid');
	var cid	= jQuery( '#jform_pid_chzn' );
	var tbs = false;
	
	if ( cid.length > 0 ) {
		tbs = true;
	}
	
	aid.length = 0;
	
	var jsonRequest = new Request.JSON({url: 'index.php', 
		onSuccess: function(response){
			if ( response.result == 'success' ) {
				var items = response.message;
				
				Array.each(items, function(row){
					if ( row.id == oid ) {
						aid.add( new Option( row.name, row.id, false, true ) );
					}
					else {
						aid.add( new Option( row.name, row.id ) );
					}
				});
			}
			
			if ( tbs ) {
				jQuery( '#jform_aid' ).trigger( 'liszt:updated' );
			}
		}
	}).get({'pid': pid, 'task': 'ajax.getproductaddons', 'option': 'com_belong'});
}

function createXHR() {
	var xhr = null;
		if (window.XMLHttpRequest) {
			xhr = new XMLHttpRequest();
		} else if (window.ActiveXObject) {
			try {
				xhr = new ActiveXObject('Microsoft.XMLHTTP');
			} catch (e) {}
		}
	return xhr;
}




/**
 * Function to check for updates via ajax (backend)
 */
function checkForUpdates()
{
	var url = "index.php?option=com_belong";
	
	jQuery.ajax({
		type: 'POST',
		url: url,
		data: 'controller=ajax&task=checkforupdates',
	}).success( function ( msg ) {
		var obj = jQuery.parseJSON( msg );
		
		processUpdate( obj );
		
	});
}


/**
 * Processes response from update check
 * @version		@fileVers@
 * @since		2.4.0
 */
function processUpdate( response ) {
	
	var apistatuslnk = jQuery( '#belong_icon_updates_link' );
	var apistatusimg = jQuery( '#belong_icon_updates_img' );
	var apistatusmsg = jQuery( '#belong_icon_updates_title' );
	
	apistatusmsg.html( response.message );
	
	apistatusimg.attr( 'src', '');
	apistatusimg.attr( 'alt', '' );
	apistatusimg.addClass( 'ajaxicon' );
	
	if ( response.updates == '1' ) {
		apistatusimg.addClass( 'found' );
	}
	else if ( response.updates == '0' ) {
		apistatusimg.addClass( 'current' );
	}
	else if ( response.updates == '-1' ) {
		apistatusimg.addClass( 'unsupported' );
	} else {
		apistatusimg.addClass( 'stall' );
	}
	
	return;
}

