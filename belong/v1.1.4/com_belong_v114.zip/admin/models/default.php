<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.4 ( $Id: default.php 73 2012-09-20 15:06:02Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This file is the default model for Belong
 *  
 */
 
/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.model' );	// Import model
/*-- File Inclusions --*/

/**
 * Belong Default Model
 * @author		Steven
 * @version		1.1.4
 * 
 * @since		1.0.0
 */
class BelongModelDefault extends BelongModelAdmin
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.1.4
	 * 
	 * @since		1.0.0
	 */
	public function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Retrieves the form for display
	 * @access		public
	 * @version		1.1.4
	 * @param		array		- $data: placeholder only
	 * @param		bool		- $loadData: tells to load the data or not
	 *
	 * @return		JForm object or false on error
	 * @since		1.0.0
	 */
	public function getForm($data = array(), $loadData = true)
	{
		
	}
	
	
	/**
	 * Creates icons for display on the default page
	 * @access		public
	 * @version		1.1.4
	 * @param		JObject		- $canDo: permissions user has
	 * 
	 * @return		array containing icon definitions
	 * @since		1.0.0
	 */
	public function getIconDefinitions( $canDo )
	{
		$ret = array();
		
		if ( $canDo->get( 'core.manage' ) ) {
			$ret[] = $this->_makeIconDefinition( 'product-48.png', JText::_('COM_BELONG_BUTTON_PRODUCT'), null, 'belong_icon_products', 'products' );
			$ret[] = $this->_makeIconDefinition( 'rules-48.png', JText::_('COM_BELONG_BUTTON_RULES'), null, 'belong_icon_rules', 'rules' );
			$ret[] = $this->_makeIconDefinition( 'productrulesets-48.png', JText::_('COM_BELONG_BUTTON_PRODUCTRULESETS'), null, 'belong_icon_productrulesets', 'productrulesets' );
			$ret[] = $this->_makeIconDefinition( 'apicnxn-48.png', JText::_('COM_BELONG_BUTTON_APICNXN'), null, 'belong_icon_apicnxn', 'apicnxn' );
			$ret[] = $this->_makeIconDefinition( 'email-48.png', JText::_('COM_BELONG_BUTTON_EMAIL'), null, 'belong_icon_email', 'email' );
			$ret[] = $this->_makeIconDefinition( 'ajax-loader-48.gif', JText::_('COM_BELONG_BUTTON_UPDATESLOADING' ), 'updates', 'belong_icon_updates' );
		}
		
		$ret[] = $this->_makeIconDefinition( 'help-48.png', JText::_('COM_BELONG_BUTTON_HELP'), null, 'belong_icon_help', null, 'help' );
		
		return $ret;
	}
	
	
	/**
	 * Retrieves the remote settings from WHMCS
	 * @access		public
	 * @version		1.1.4
	 * 
	 * @return		array of data or false on error
	 * @since		1.0.0
	 */
	public function getRemotesettings()
	{
		$api	= BelongApi::getInstance();
		$data	= $api->get_remote_settings();
		
		if ( $data['result'] == 'success' ) {
			return $data;
		}
		else {
			return false;
		}
		
		return $data;
	}
	
	
	/**
	 * Retrieves the status of the API connection
	 * @access		public
	 * @version		1.1.4
	 * 
	 * @return		true on success or string containing failed message
	 * @since		1.0.0
	 */
	public function getStatus()
	{
		$api	= BelongApi::getInstance();
		$data	= $api->ping();
		
		if ( $data['result'] == 'success' ) {
			return true;
		}
		else {
			return ( isset( $data['message'] ) ? $data['message'] : $data['data'] );
		}
	}
	
	
	/**
	 * Creates an icon definition
	 * @access		private
	 * @version		1.1.4
	 * @param		string		- $iconFile: image file name
	 * @param		string		- $label: label to use
	 * @param		string		- $controller: where to go
	 * @param		string		- $id: the id of the image to use
	 * @param		string		- $view: what to see
	 * @param		string		- $task: what to do
	 * 
	 * @return		array of items compiled for view
	 * @since		1.0.0
	 */
	private function _makeIconDefinition($iconFile, $label, $controller = null, $id = null, $view = null, $task = null )
	{
		return array(
			'icon'		=> $iconFile,
			'label'		=> $label,
			'controller'=> $controller,
			'id'		=> $id,
			'view'		=> ( $view == null ? $controller : $view ),
			'task'		=> $task
		);
	}
}