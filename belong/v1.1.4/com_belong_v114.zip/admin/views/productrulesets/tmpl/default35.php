<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.4 ( $Id: default.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the default layout for the productrulesets view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusion --*/
JHtml::_('behavior.tooltip');
JHtml::_('behavior.multiselect');
JHtml::_('dropdown.init');
/*-- File Inclusion --*/

$listOrder	= $this->escape($this->state->get('list.ordering'));
$listDirn	= $this->escape($this->state->get('list.direction'));

$saveOrderingUrl = 'index.php?option=com_belong&task=ajax.productrulesetorder&tmpl=component';
JHtml::_('sortablelist.sortable', 'adminForm', 'adminForm', strtolower($listDirn), $saveOrderingUrl);

?>

<script type="text/javascript">
	Joomla.submitbutton = function( task ) { Joomla.submitform(task, document.getElementById('adminForm')); }
</script>

<form action="<?php echo JRoute::_('index.php?option=com_belong'); ?>" method="post" name="adminForm" id="adminForm">
	
	<table class="table">
		<thead>
			<tr>
				<th width="10%">
					<?php echo JHtml::_('grid.sort', '<i class="icon-menu-2"></i>', 'ordering', $listDirn, $listOrder, null, 'asc', 'JGRID_HEADING_ORDERING'); ?>
					
					<?php // echo JText::_( 'COM_BELONG_PRODUCTRULESET_HEADING_PRIORITY' ); ?>
					<?php // echo JHtml::_( 'grid.order',  $this->items, 'filesave.png', 'productrulesets.saveorder' ); ?>
				</th>
				<th width="20">
					<input type="checkbox" name="toggle" value="" onclick="Joomla.checkAll(this);" />
				</th>
				<th width="5%">
					<?php echo JText::_( 'JSTATUS' ); ?>
				</th>		
				<th>
					<?php echo JText::_('COM_BELONG_PRODUCTRULESET_HEADING'); ?>
				</th>
				<th width="5">
					<?php echo JText::_('COM_BELONG_PRODUCTRULESET_HEADING_ID'); ?>
				</th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="5"><?php echo $this->pagination->getListFooter(); ?></td>
			</tr>
		</tfoot>
		
		<tbody>
		
		<?php foreach($this->items as $i => $item): ?>
			<?php $link = JRoute::_( 'index.php?option=com_belong&task=productruleset.edit&id=' . $item->id ); ?>
			<tr class="row<?php echo $i % 2; ?>">
				<td>
					<span class="sortable-handler" rel="tooltip">
						<i class="icon-menu"></i>
					</span>
					<input type="text" style="display:none"  name="order[]" size="5" value="<?php echo $item->priority; ?>" class="width-20 text-area-order " />
				</td>
				<td>
					<?php echo JHtml::_('grid.id', $i, $item->id); ?>
				</td>
				<td class="center">
					<?php echo JHtml::_('jgrid.published', $item->published, $i, 'productrulesets.', true ); ?>
				</td>
				<td>
					Ruleset:  <em>apply</em> <a href="<?php echo $link; ?>"><strong><?php echo $item->product_name; ?></strong></a> <em>against</em> <a href="<?php echo $link; ?>"><strong><?php echo $item->rule_name; ?></strong></a> <em>rule</em>
				</td>
				<td>
					<?php echo $item->id; ?>
				</td>
			</tr>
		<?php endforeach; ?>
		
		</tbody>
		
	</table>
	<div>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>" />
		<input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn; ?>" />
		<?php echo JHtml::_( 'form.token' ); ?>
	</div>
</form>