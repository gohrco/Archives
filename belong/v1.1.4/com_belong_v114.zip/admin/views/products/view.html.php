<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.4 ( $Id: view.html.php 73 2012-09-20 15:06:02Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the products view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.view' );
include_once( JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'helper.php' );
/*-- File Inclusions --*/

/**
 * Belong Products View
 * @author		Steven
 * @version		1.1.4
 * 
 * @since		1.0.0
 */
class BelongViewProducts extends BelongViewExt
{
	
	/**
	 * Display view
	 * @access		public
	 * @version		1.1.4
	 * @param		string		- $tpl: contains a template to overload with
	 * 
	 * @return		parent :: display()
	 * @since		1.0.0
	 */
	public function display( $tpl = null )
	{
		$items		=   $this->get( 'Items' );
		$pagination	=   $this->get( 'Pagination' );
		
		if ( count( $errors = $this->get( 'Errors' ) ) ) {
			JError::raiseError( 500, implode('<br />', $errors ) );
			return false;
		}
		
		// Retrieve ACL permitted actions
		$canDo	= BelongHelper :: getActions();
		
		BelongHelper :: addMedia( 'admin.main.' . $this->_myvers . '/css' );
		BelongHelper :: addToolbar( 'products', null, $canDo );
		
		$this->items		= $items;
		$this->pagination	= $pagination;
		
		parent::display($tpl);
	}
}