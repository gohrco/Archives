<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.4 ( $Id: edit.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the edit layout for the rule view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusion --*/
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('behavior.keepalive');
/*-- File Inclusion --*/

$cycle = array( 'activegroup', 'pendinggroup', 'suspendedgroup', 'terminatedgroup', 'cancelledgroup', 'fraudgroup' );

?>

<script type="text/javascript">
	Joomla.submitbutton = function( task ) { Joomla.submitform(task, document.getElementById('belong-form')); }
</script>

<div class="tabWrapper">
	<form action="<?php echo JRoute::_('index.php?option=com_belong&layout=edit&id='.(int) $this->item->id); ?>" method="post" name="adminForm" id="belong-form">
	
	<ul class="nav nav-tabs">
	<li class="active"><a data-toggle="tab" href="#rule_details"><?php echo JText::_('COM_BELONG_RULE_EDIT_RULEDETAILS'); ?></a></li>
	<li><a data-toggle="tab" href="#product_rules"><?php echo JText :: _( 'COM_BELONG_RULE_EDIT_PRODUCT_RULESTATUS' ); ?></a></li>
	<li><a data-toggle="tab" href="#addon_rules"><?php echo JText :: _( 'COM_BELONG_RULE_EDIT_ADDON_RULESTATUS' ); ?></a></li>
	</ul>
	
	<div class="tab-content">
		
		<div id="rule_details" class="tab-pane active">
			
			<?php foreach($this->form->getFieldset( 'details' ) as $field): ?>
			
			<div class="control-group">
				<div class="control-label">
					<?php echo $field->label; ?>
				</div>
				<div class="controls">
					<?php echo $field->input; ?>
				</div>
			</div>
			
			<?php endforeach; ?>
			
		</div>
		
		<div id="product_rules" class="tab-pane">
			
			<?php foreach ( $cycle as $c ) :
				$fields = $this->form->getFieldset( 'product' . $c );
			?>
			
			<div class="control-group">
				<div class="control-label">
					<label class="hasTip" title="<?php echo JText::_( 'COM_BELONG_RULE_DESC_' . strtoupper( $c ) ); ?>">
						<?php echo JText::_( 'COM_BELONG_RULE_LABEL_' . strtoupper( $c ) ); ?>
					</label>
				</div>
				<div class="controls">
					<?php echo $fields['jform_data_product' . $c . 'axn']->input; ?>
					<?php echo $fields['jform_data_product' . $c]->input; ?>
				</div>
			</div>
			
		<?php endforeach; ?>
			
		</div>
		
		<div id="addon_rules" class="tab-pane">
			
			<?php foreach ( $cycle as $c ) :
				$fields = $this->form->getFieldset( 'addon' . $c );
			?>
			
			<div class="control-group">
				<div class="control-label">
					<label class="hasTip" title="<?php echo JText::_( 'COM_BELONG_RULE_DESC_' . strtoupper( $c ) ); ?>">
						<?php echo JText::_( 'COM_BELONG_RULE_LABEL_' . strtoupper( $c ) ); ?>
					</label>
				</div>
				<div class="controls">
					<?php echo $fields['jform_data_addon' . $c . 'axn']->input; ?>
					<?php echo $fields['jform_data_addon' . $c]->input; ?>
				</div>
			</div>
			
		<?php endforeach; ?>
			
		</div>
		
	</div>
	
	<input type="hidden" name="task" value="rule.edit" />
	<?php echo JHtml::_('form.token'); ?>
	
	</form>
	
</div>