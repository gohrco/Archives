<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.4 ( $Id: results25.php 73 2012-09-20 15:06:02Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the results layout for the email view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusion --*/
JHtml::_('behavior.tooltip');
/*-- File Inclusion --*/

?>

<table class="adminlist">

	<!-- BEGIN BODY -->
	
	<tbody>
		
		<?php foreach( $this->results as $i => $result ) : ?>
		
		<tr class="row<?php echo $i % 2; ?>">
			<td>
				<h3><?php echo $result; ?></h2>
			</td>
		</tr>
		
		<?php endforeach; ?>
		
	</tbody>
	
	<!-- END BODY -->
	<!-- BEGIN HEADER -->
	
	<thead>
		
		<tr>
			<th>
				<?php echo JText::_( 'COM_BELONG_EMAIL_HEADING_RESULTS' ); ?>
			</th>
		</tr>
		
	</thead>
	
	<!-- END HEADER -->
	<!-- BEGIN FOOTER -->
	
	<tfoot>
		
		<tr>
			<td colspan="1">&nbsp;</td>
		</tr>
		
	</tfoot>
	
	<!-- END FOOTER -->

</table>

<form action="<?php echo JRoute::_('index.php?option=com_belong'); ?>" method="post" name="adminForm" id="belong-form">
	
	<div>
		<input type="hidden" name="task" value="" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>