<?php
/**
 * Belong
 *
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.4 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      1.1.0
 *
 * @desc       This is a helper file for the update routines for Belong
 *
 * The methods and routines within this file are based partly upon the work of
 *   Nicholas K. Dionysopoulos / AkeebaBackup.com
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die();
/*-- Security Protocols --*/


/**
 * BelongStorageFile class object
 * @version		1.1.4
 * 
 * @since		1.1.0
 * @author		Steven
 */
class BelongStorageFile extends BelongStorage
{
	/**
	 * Stores the filename of the storage item
	 * @var		string
	 */
	private static $filename = null;
	
	/**
	 * Stores the path to the storage item
	 * @var		string
	 */
	private static $filepath = null;
	
	
	/**
	 * Method to load an extension into the storage object
	 * @access		public
	 * @version		1.1.4
	 * @param		object		- $config: contains the BelongUpdateConfig object to use for stettings
	 *
	 * @since		1.1.0
	 */
	public function load( $config )
	{
		$path	= $config['_storagePath'];
		$filename	= $config['_storagePath'] . DIRECTORY_SEPARATOR . $config['_extensionName'] . ".updates.ini";
		
		self :: $filename = $filename;
		
		jimport('joomla.registry.registry');
		self :: $registry = new JRegistry('update');
		
		jimport('joomla.filesystem.file');
		
		if ( JFile :: exists( self :: $filename ) ) {
			$data = json_decode( JFile :: read( self :: $filename ), 1 );
			self :: $registry->loadArray( $data );
		}
	}
	
	
	/**
	 * Method to save parameters to the database
	 * @access		public
	 * @version		1.1.4
	 *
	 * @since		1.1.0
	 */
	public function save()
	{
		jimport( 'joomla.filesystem.file' );
		$data = json_encode( self :: $registry->toArray() );
		JFile::write( self :: $filename, $data );
	}
}