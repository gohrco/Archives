<?php
/**
 * Belong
 *
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.4 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      1.1.0
 *
 * @desc       This is a helper file for the update routines for Belong
 * 
 * The methods and routines within this file are based partly upon the work of
 *   Nicholas K. Dionysopoulos / AkeebaBackup.com
 * 
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die();
/*-- Security Protocols --*/


/**
 * BelongUpdate class object
 * @version		1.1.4
 * 
 * @since		1.1.0
 * @author		Steven
 */
class BelongUpdate
{
	
	/**
	 * Method to create a sorted list of updates to display to user in update view
	 * @access		public
	 * @version		1.1.4
	 * @param		bool		- $force: indicates that the update should be forcibly retrieved
	 * 
	 * @return		array
	 * @since		1.1.0
	 */
	public function getSortedList( $force = false )
	{
		$updates	= self :: getUpdateInformation( $force );
		$data		= array( 'component' => array(), 'file' => array(), 'plugin' => array(), 'action' => false );
		
		foreach ( $updates as $element => $update ) {
			$c		= $update['config'];
			$u		= $update['update'];
			$temp	= array( 'name' => $c->get( '_extensionTitle' ), 'version' => 'Extension is current' );
			switch ( $c->get( '_extensionType', null ) ) {
				case 'component':
					if ( $u->hasupdate ) {
						$temp['version']	= $update['update']->version . ' (' . $update['update']->stability . ')';
						$data['action'] = true;
					}
					$data['component'][] = $temp;
					break;
				case 'file':
					if ( $element == 'file_whmcs_belong' ) {
						if ( $u->hasupdate ) {
							$temp['version'] = $u->version . ' (' . $u->stability . ')';
							$data['action'] = true;
						}
						$data['file'][] = $temp;
					}
					break;
				case 'plugin':
					if ( $u->hasupdate ) {
						$temp['version']	= $u->version . ' (' . $u->stability . ')';
						$data['action'] = true;
					}
					$data['plugin'][] = $temp;
					break;
			}
		}
		
		return $data;
	}
	
	
	/**
	 * Method to retrieve the updates from the Go Higher site
	 * @access		public
	 * @version		1.1.4
	 * @param		bool		- $force: indicates that the update should be forcibly retrieved
	 * 
	 * @return		array
	 * @since		1.1.0
	 */
	public function getUpdateInformation( $force = false )
	{
		require_once( dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'fetch.php' );
		
		$update	= new BelongUpdateFetch();
		$info	= $update->getUpdateInformation( $force );
		
		return $info;
	}
	
	
	/**
	 * Method to check to see if there are updates to apply
	 * @access		public
	 * @version		1.1.4
	 * 
	 * @return		integer
	 * @since		1.1.0
	 */
	public function hasUpdates()
	{
		$updates	= self :: getUpdateInformation();
		$exists		= 0;
		
		foreach ( $updates as $data ) {
			if ( $data['update']->stuck == 1 ) {
				$exists = -2;
			}
			else if ( $data['update']->hasupdate == 1 ) {
				$exists = 1;
				break;
			}
		}
		
		return $exists;
	}
}