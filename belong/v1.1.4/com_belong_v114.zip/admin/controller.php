<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.4 ( $Id: controller.php 73 2012-09-20 15:06:02Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the main controller file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.controller');
/*-- File Inclusions --*/


/**
 * Belong Controller class object
 * @version		1.1.4
 * 
 * @since		1.0.0
 * @author		Steven
 */
class BelongController extends BelongCtrlLegacy
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.1.4
	 * 
	 * @since		1.0.0
	 */
	public function __construct()
	{
		parent :: __construct();
		$this->registerTask( 'rules',			'display' );
		$this->registerTask( 'products',		'display' );
		$this->registerTask( 'productrulesets',	'display' );
	}
	
	
	/**
	 * Displays the backend to the user
	 * @access		public
	 * @version		1.1.4
	 * 
	 * @since		1.0.0
	 */
	public function display( $cachable = false )
	{
		$task = JRequest :: getVar( 'task', 'display' );
		
		if ( $task != 'display' ) {
			JRequest :: setVar( 'view', $task );
		}
		else {
			JRequest :: setVar( 'view', JRequest :: getCmd( 'view', 'default' ) );
		}
		
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JRequest :: setVar( 'layout', JRequest :: getCmd( 'layout', 'default' ) . '35' );
		}
		else {
			JRequest :: setVar( 'layout', JRequest :: getCmd( 'layout', 'default' ) . '25' );
		}
		
		parent :: display( $cachable );
	}
	
	
	/**
	 * Currently a redirecter to Go Higher for support
	 * @access		public
	 * @version		1.1.4
	 * 
	 * @since		1.0.0
	 */
	public function help()
	{
		$app = & JFactory :: getApplication();
		$redirect = 'https://www.gohigheris.com';
		$app->redirect( $redirect );
	}
	
	
	/**
	 * Redirects unmapped tasks to appropriate view
	 * @access		public
	 * @version		1.1.4
	 * @param		bool		- $cachable: tells Joomla if the template is cachable
	 * 
	 * @since		1.0.0
	 */
	public function task_redirect( $cachable = false )
	{
		JRequest :: setVar( 'view', JRequest :: getVar( 'task', 'default' ) );
		parent :: display( $cachable );
	}
}


class BelongControllerForm extends BelongCtrlForm
{
	/**
	 * Displays the backend to the user
	 * @access		public
	 * @version		1.1.4
	 *
	 * @since		1.0.0
	 */
	public function display( $cachable = false )
	{
		JRequest :: setVar( 'view', JRequest :: getCmd( 'view', 'default' ) );
	
		if ( version_compare( JVERSION, '3.0', 'ge' ) ) {
			JRequest :: setVar( 'layout', JRequest :: getCmd( 'layout', 'default' ) . '35' );
		}
		else {
			JRequest :: setVar( 'layout', JRequest :: getCmd( 'layout', 'default' ) . '25' );
		}
	
		parent :: display( $cachable );
	}
}