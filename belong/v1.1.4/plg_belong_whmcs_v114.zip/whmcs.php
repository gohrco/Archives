<?php
/**
* Belong
*
* @package    Belong
* @copyright  2012 Go Higher Information Services.  All rights reserved.
* @license    GNU General Public License version 2, or later
* @version    1.1.4 ( $Id: whmcs.php 72 2012-09-17 16:01:58Z steven_gohigher $ )
* @author     Go Higher Information Services
* @since      1.0.3
*
* @desc       This file is a utility helper for Belong
*
*/

/*-- Security Protocols --*/
defined('_JEXEC') or die;

/*-- Localscope import --*/
jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.database.database' );

if ( $path = JApplicationHelper :: getPath( 'helper', 'com_belong' ) ) {
	require_once( $path );
}

/**
 * Belong Plugin: WHMCS
 * Extends the Belong ruleset functionality to the originating WHMCS
 * @version		1.1.4
 * 
 * @since		1.0.5
 * @author		Steven
 */
class plgBelongWhmcs extends JPlugin
{
	/**
	 * Method to halt execution of plugin if a failure exists at setup
	 * @access		private
	 * @since		1.0.5
	 * @var			boolean
	 */
	private $enabled	= true;
	
	/**
	 * Stores queued sets to execute
	 * @access		private
	 * @since		1.0.5
	 * @var			array
	 */
	private $queue		= array();
	
	/**
	 * Indicates the use of a table prefix (needed b/c Joomla wont accept an empty prefix when setting up a database connection)
	 * @access		private
	 * @since		1.0.5
	 * @var			boolean
	 */
	private $useprefix	= false;
	
	/**
	 * Stores the vBulletin database object
	 * @access		private
	 * @since		1.0.5
	 * @var			JDatabase object
	 */
	private $vdb		= null;
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.1.4
	 * @param		string		$subject: passed by JPlugin 
	 * @param		array		$config:  passed by JPlugin
	 * 
	 * @since		1.0.5
	 */
	public function __construct( & $subject, $config )
	{
		parent::__construct($subject, $config);
		
		$this->loadLanguage();
	}
	
	
	/**
	 * Event called when gathering update sites to check for updates
	 * @access		public
	 * @version		1.1.4
	 *
	 * @return		array
	 * @since		1.1.0
	 */
	public function getUpdateSite()
	{
		return array(
				'extensionName'				=> 'plg_belong_whmcs',
				'options' => array(
						'extensionTitle'	=> 'Belong Joomla! WHMCS Plugin',
						'storage'			=> 'database',
						'storagePath'		=> null,
						'extensionType'		=> 'plugin',
						'updateUrl'			=> 'https://www.gohigheris.com/updates/belong/plugin/whmcs'
				)
		);
	}
	
	
	/**
	 * Event called when getting permission groups list
	 * @access		public
	 * @version		1.1.4
	 * @param		array		$data: an array of gathered permision groups
	 * 
	 * @return		array
	 * @since		1.0.5
	 */
	public function onGetPermissionGroups( & $data = array() )
	{
		if (! $this->enabled ) return $data;
		
		$api		= BelongApiExt :: getInstance( array( 'force' => true ) );
		$groups		= $api->get_permission_groups();
		
		if ( $groups['result'] != "success" ) return $data;
		
		for( $i=0; $i < count( $groups ); $i++ ) {
			if ( empty( $groups['groups'][$i] ) ) continue;
			$groups['groups'][$i] = (object) $groups['groups'][$i];
		}
		
		return array( 'items' => $groups['groups'], 'text' => JText :: _( 'PLG_BELONG_WHMCS_GROUP_LABEL' ) );
	}
	
	
	/**
	 * Event called to run the queue of users and update
	 * @access		public
	 * @version		1.1.4
	 * 
	 * @return		true
	 * @since		1.0.5
	 */
	public function onRunQueue()
	{
		$qs = $this->queue;
		
		foreach( $qs as $q ) {
			$this->_updateUser( $q['u'], $q['g'] );
		}
		
		return true;
	}
	
	
	/**
	 * Event to handle user permissions update
	 * @access		public
	 * @version		1.1.4
	 * @param		integer		$id: the Joomla id of the user to update
	 * @param		array		$add_groups: an array of user groups to add user to
	 * @param		array		$drop_groups: an array of user groups to drop user from
	 * 
	 * @return		true
	 * @since		1.0.5
	 */
	public function onUserUpdatePermissions( $id, $add_groups = array(), $drop_groups = array() )
	{
		if (! $this->enabled ) return;
		
		if (! isset( $add_groups['whmcs'] ) ) $add_groups['whmcs'] = array();
		if (! isset( $drop_groups['whmcs'] ) ) $drop_groups['whmcs'] = array();
		
		$debug	=   BelongDebug :: getInstance( true );
		$user	= & JFactory :: getUser( $id );
		
		// Grab the groups for output purposes only
		$api		= BelongApiExt :: getInstance( array( 'force' => true ) );
		$groups		= $api->get_permission_groups();
		$groups		= $this->_cleanGroups( $groups['groups'] );
		
		// Grab the vbuser and fail if not found
		$user		= $api->get_user( array( 'email' => $user->email ) );
		if ( $user['result'] != 'success' ) {
			$debug->add( JText::_( 'PLG_BELONG_WHMCS_NOUSER' ), $user->email );
			return;
		}
		
		$adds	=   reset( $add_groups['whmcs'] );
		$drops	=   reset( $drop_groups['whmcs'] );
		$curs	=   $user['groupid'];
		
		// Pre-processing
		if (! empty( $add_groups['whmcs'] ) )	$debug->add( JText::_( 'PLG_BELONG_WHMCS_ADDGROUPS' ), $groups[$adds] );
		if (! empty( $drop_groups['whmcs'] ) )	$debug->add( JText::_( 'PLG_BELONG_WHMCS_DROPGROUPS' ), $groups[$drops] );
		$debug->add( JText::_( 'PLG_BELONG_WHMCS_CURGROUPS' ),  $groups[$curs] );
		
		// Drop group if applicable
		if ( $curs == $drops ) {
			$curs = 0;
			$debug->add( JText::_( 'PLG_BELONG_WHMCS_AFTERDROPGROUPS' ), JText::_( 'PLG_BELONG_WHMCS_NOGROUP' ) );
		}
		
		// Add groups if applicable
		if (! empty( $adds ) ) {
			$curs = $adds;
			$debug->add( JText::_( 'PLG_BELONG_WHMCS_AFTERADDGROUPS' ), $groups[$curs] );
		}
		
		// Queue up for final run
		return $this->_enqueueUpdate( $user, $curs );
	}
	
	
	/**
	 * Cleans retrieved groups for internal use
	 * @access		private
	 * @version		1.1.4
	 * @param		array		$groups: contains the fetched groups from WHMCS
	 * 
	 * @return		array
	 * @since		1.0.5
	 */
	private function _cleanGroups( $groups = array() )
	{
		$data = array();
		foreach( $groups as $row ) {
			$tmp = explode( "|", $row['value'] );
			$data[$tmp[1]] = $row['text'];
		}
		return $data;
	}
	
	
	/**
	 * Enqueues a user update for run
	 * @access		private
	 * @version		1.1.4
	 * @param		array		$user: the WHMCS user to update
	 * @param		integer		$group: the group to set the user to
	 * 
	 * @return		true
	 * @since		1.0.5
	 */
	private function _enqueueUpdate( $user, $group )
	{
		$debug	=   BelongDebug :: getInstance( true );
		
		if (! isset( $this->queue[$user['userid']] ) ) $this->queue[$user['userid']] = array( 'u' => $user, 'g' => $group );
		else $debug->add( JText::_( 'PLG_BELONG_WHMCS_ERRORALREADYRUN' ), $user['email'] );
		
		return true;
	}
	
	
	/**
	 * Updates the vBulletin user directly
	 * @access		private
	 * @version		1.1.4
	 * @param		array		$user: the WHMCS user array to update user from
	 * @param		integer		$group: contains the group the user should belong to
	 * 
	 * @since		1.0.5
	 */
	private function _updateUser( $user, $group )
	{
		$post	= array( 'email' => $user['email'], 'groupid' => $group );
		
		$api		= BelongApiExt :: getInstance( array( 'force' => true ) );
		$groups		= $api->update_user_group( $post );
	}
	
	
	
}


/**
 * Belong API Extension
 * Extends the Belong API class with additional functionality
 * @version		1.1.4
 * 
 * @since		1.0.5
 * @author		Steven
 */
class BelongApiExt extends BelongApi
{
	/**
	 * Constructor methos
	 * @access		public
	 * @version		1.1.4
	 * @param		array		- $creds: credential array if known
	 * 
	 * @since		1.0.5
	 * @see			BelongApi::__construct()
	 */
	public function __construct( $creds = array() )
	{
		parent::__construct( $creds );
	}
	
	
	
	/**
	 * Creates an instance of object
	 * @access		public
	 * @version		1.1.4
	 * @param		array		- $options: array of options to set
	 * 
	 * @return		instance of BelongApiExt
	 * @since		1.0.5
	 * @see			BelongApi::getInstance()
	 */
	public function getInstance( $options = array() )
	{
		static $extinstance;
		
		if ( isset( $options['force'] ) ) {
			$force = true;
			unset( $options['force'] );
		}
		else $force = false;
		
		if ( (! is_object( $extinstance ) ) || ( $force === true ) ) {
			$extinstance = new self( $options );
		}
		
		return $extinstance;
	}
	
	
	
	/**
	 * Retrieves the client groups from WHMCS
	 * @access		public
	 * @version		1.1.4
	 * 
	 * @return		array
	 * @since		1.0.5
	 */
	public function get_permission_groups()
	{
		$post['action']	= 'belong';
		$post['task']	= 'getpermissiongroups';
		
		return $this->_call_api( $post );
	}
	
	
	/**
	 * Sets a user group in WHMCS
	 * @access		public
	 * @version		1.1.4
	 * @param 		array		- $post: array of post options to set
	 * 
	 * @return		array
	 * @since		1.0.5
	 */
	public function update_user_group( $post = array() )
	{
		$post['action']	= 'belong';
		$post['task']	= 'updateclientgroup';
		
		return $this->_call_api( $post );
	}
}