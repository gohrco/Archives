


DROP TABLE IF EXISTS `mod_belong_settings`;


-- command split --



DROP TABLE IF EXISTS `mod_belong_plugins`;


-- command split --


DROP TABLE IF EXISTS `mod_belong_products`;


-- command split --


DROP TABLE IF EXISTS `mod_belong_rules`;



-- command split --


DROP TABLE IF EXISTS `mod_belong_rulesets`;

