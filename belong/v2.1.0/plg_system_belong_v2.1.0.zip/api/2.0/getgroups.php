<?php
/**
 * Belong
 * System - Belong Plugin:  API Get Groups file
 *
 * @package    Belong
 * @copyright  2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.1.0 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.0.0
 *
 * @desc       This is the Get Groups File for handling all API requests for Belong
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Get Groups Belong API Class
 * @version		2.1.0
 *
 * @since		2.0.0
 * @author		Steven
 */
class GetgroupsBelongAPI extends BelongAPI
{
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		2.1.0
	 *
	 * @since		2.0.0
	 */
	public function execute()
	{
		$db = JFactory::getDbo();
		$db->setQuery(
					'SELECT a.id AS value, a.title AS text, COUNT(DISTINCT b.id) AS level' .
					' FROM #__usergroups AS a' .
					' LEFT JOIN #__usergroups AS b ON a.lft > b.lft AND a.rgt < b.rgt' .
					' GROUP BY a.id' .
					' ORDER BY a.lft ASC'
		);
		
		$groups	= $db->loadObjectList();
		
		// Check for a database error.
		if ($db->getErrorNum()) {
			$this->error( JText :: _( 'BELONG_API_GETGROUPS_DBERR' ) );
		}
		
		$this->success( $groups );
	}
}