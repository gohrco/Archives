<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.2 ( $Id: edit.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the edit layout for the rule view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusion --*/
JHtml::_('behavior.tooltip');
/*-- File Inclusion --*/

?>
<form action="<?php echo JRoute::_('index.php?option=com_belong&layout=edit&id='.(int) $this->item->id); ?>"
      method="post" name="adminForm" id="belong-form">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BELONG_RULE_EDIT_RULEDETAILS' ); ?></legend>
		<ul class="adminformlist">
<?php foreach($this->form->getFieldset( 'details' ) as $field): ?>
			<li><?php echo $field->label;echo $field->input;?></li>
<?php endforeach; ?>
		</ul>
	</fieldset>
	
	<?php 
	foreach ( array( 'product', 'addon' ) as $fieldset ) :
	?>
	
	<fieldset class="adminform" style="width: 45%; float: <?php echo ( $fieldset == 'product' ? 'left' : 'right' ); ?>; ">
		<legend><?php echo JText::_( 'COM_BELONG_RULE_EDIT_'.$fieldset.'_RULESTATUS' ); ?></legend>
		
		<?php
		$cycle = array( 'activegroup', 'pendinggroup', 'suspendedgroup', 'terminatedgroup', 'cancelledgroup', 'fraudgroup' );
		
		foreach ( $cycle as $c ) :
			$fields = $this->form->getFieldset( $fieldset . $c );
			
		?>
		
		<div style="width: 100%; margin: 15px 0 0;<?php if ( $c != 'fraudgroup' ) : ?> border-bottom: 1px solid #ccc; <?php endif; ?>">
			<div style="width: 25%;"><label class="hasTip" title="<?php echo JText::_( 'COM_BELONG_RULE_DESC_' . strtoupper( $c ) ); ?>"><?php echo JText::_( 'COM_BELONG_RULE_LABEL_' . strtoupper( $c ) ); ?></label></div>
			<div style="text-align: center; "><?php echo $fields['jform_data_' . $fieldset . $c . 'axn']->input; ?></div>
			<div><?php echo $fields['jform_data_' . $fieldset . $c]->input; ?></div>
			<div style="clear: both; ">&nbsp;</div>
		</div>
		
		<?php
		
		endforeach;
		
		?>
		
	</fieldset>
	
	<?php endforeach; ?>
	
	<div>
		<input type="hidden" name="task" value="rule.edit" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>