<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.2 ( $Id: products.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the products table file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die('Restricted access');
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.database.table');
/*-- File Inclusions --*/

/**
 * Belong Products Table
 * @author		Steven
 * @version		1.1.2
 * 
 * @since		1.0.0
 */
class BelongTableProducts extends JTable
{
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.1.2
	 * @param		JDatabase object	- $db: db instance
	 * 
	 * @since		1.0.0
	 */
	public function __construct( &$db ) 
	{
		parent::__construct( '#__belong_products', 'id', $db );
	}
	
	
	/**
	 * Binds an array of data to the object
	 * @access		public
	 * @version		1.1.2
	 * @param		array		- $array: data to bind
	 * @param		string		- $ignore: items to ignore
	 * 
	 * @return		parent :: bind()
	 * @since		1.0.0
	 */
	public function bind($array, $ignore = '') 
	{
		if (isset($array['pdata']) && is_array($array['pdata'])) 
		{
			// Convert the params field to a string.
			$parameter = new JRegistry;
			$parameter->loadArray($array['pdata']);
			$array['pdata'] = (string)$parameter;
		}
		
		if (isset($array['statusorder']) && is_array($array['statusorder'])) 
		{
			// Convert the params field to a string.
			$parameter = new JRegistry;
			$parameter->loadArray($array['statusorder']);
			$array['statusorder'] = (string)$parameter;
		}
		return parent::bind($array, $ignore);
	}
 
	/**
	 * Overloaded load function
	 *
	 * @param       int $pk primary key
	 * @param       boolean $reset reset data
	 * @return      boolean
	 * @see JTable:load
	 */
	public function load($pk = null, $reset = true) 
	{
		if (! parent::load($pk, $reset)) {
			return false;
		}
		
		if ( is_string( $this->pdata ) ) {
			$this->pdata = json_decode( $this->pdata );
		}
		
		if ( is_string( $this->statusorder ) ) {
			$this->statusorder = json_decode( $this->statusorder );
		}
		
		return true;
	}
}