<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.2 ( $Id: email.php 33 2012-01-14 16:56:05Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the email model file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die('Restricted access');
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.modeladmin' );
/*-- File Inclusions --*/

/**
 * Belong Email Model
 * @author		Steven
 * @version		1.1.2
 * 
 * @since		1.0.0
 */
class BelongModelEmail extends JModelAdmin
{
	
	/**
	 * Retrieves the user data from Joomla and WHMCS
	 * @access		public
	 * @version		1.1.2
	 * 
	 * @return		array of user data
	 * @since		1.0.0
	 */
	public function getFounduserData()
	{
		$form	= JRequest::getVar( 'jform', array() );
		
		if (! isset( $form['email'] ) ) {
			return false;
		}
		
		$email	= $form['email'];
		
		// Joomla user first...
		$db = JFactory :: getDbo();
		
		$query	= 'SELECT id FROM #__users WHERE email = ' . $db->Quote( $email );
		$db->setQuery($query, 0, 1);
		$jid	= $db->loadResult();
		
		if ( $jid != null ) {
			$juser	= JFactory :: getUser( $jid );
		}
		else {
			$juser	= (object) array( 'name' => null, 'username' => null, 'email' => null, 'usertype' => 'Not Found' );
		}
		
		// Now for the WHMCS User...
		$api	= & BelongApi :: getInstance();
		$wuser	=   $api->get_user( array( 'email' => $email ) );
		
		if ( $wuser['result'] == 'error' ) {
			$wuser	= (object) array( 'firstname' => null, 'lastname' => null, 'email' => null, 'usertype' => 'Not Found' );
		}
		else {
			$wuser['clientid'] = $wuser['id'];
			$wuser	= (object) $wuser;
		}
		
		$data	= array( 'joomla' => $juser, 'whmcs' => $wuser );
		
		return $data;
	}
	
	
	/**
	 * Retrieves the form for display
	 * @access		public
	 * @version		1.1.2
	 * @param		array		- $data: placeholder only
	 * @param		bool		- $loadData: tells to load the data or not
	 * 
	 * @return		JForm object or false on error
	 * @since		1.0.0
	 */
	public function getForm( $data = array(), $loadData = true ) 
	{
		// Get the form.
		$form = $this->loadForm('com_belong.email', 'email',
		                        array('control' => 'jform', 'load_data' => false ) );
		
		if (empty($form)) 
		{
			return false;
		}
		
		return $form;
	}
}