<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.2 ( $Id: controller.php 21 2011-10-15 02:21:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the main controller file for Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or exit('No direct script access allowed');
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.controller');
/*-- File Inclusions --*/

/**
 * Belong Controller class object
 * @version		1.1.2
 * 
 * @since		1.0.0
 * @author		Steven
 */
class BelongController extends JController
{
	/**
	 * Displays the front end, setting the default view if not set.
	 * @access		public
	 * @version		1.1.2
	 * 
	 * @since		1.0.0
	 */
	public function display()
	{
		// If the view hasn't been set, set it to default
		if (is_null(JRequest::getVar( 'view'))) JRequest::setVar('view', 'default' );
		
		// Call up the parent display task
		parent::display();
	}
}