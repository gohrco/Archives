<?php
/**
* Belong
*
* @package    Belong
* @copyright  2012 Go Higher Information Services.  All rights reserved.
* @license    GNU General Public License version 2, or later
* @version    1.1.0 ( $Id$ )
* @author     Go Higher Information Services
* @since      1.0.6
*
* @desc       This file is a utility helper for Belong
*
*/

/*-- Security Protocols --*/
defined('_JEXEC') or die;

/*-- Localscope import --*/
jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.http.transport.curl' );

if ( $path = JApplicationHelper :: getPath( 'helper', 'com_belong' ) ) {
	require_once( $path );
}

/**
 * Belong Plugin: Mailchimp
 * Extends the Belong ruleset functionality to a Mailchimp Account
 * @version		1.1.0
 * 
 * @since		1.0.6
 * @author		Steven
 */
class plgBelongMailchimp extends JPlugin
{
	/**
	 * Stores the mailchimp API Wrapper
	 * @access		private
	 * @since		1.0.6
	 * @var			JHttpTransportCurl object
	 */
	private $mailchimp		= null;
	
	/**
	 * Stores the mailchimp groups
	 * @access		private
	 * @since		1.0.6
	 * @var			array
	 */
	private	$mcgroups		= array();
	
	/**
	 * Stores the mailchimp group values for displaying to user
	 * @access		private
	 * @since		1.0.6
	 * @var			array
	 */
	private	$mcgrpvals		= array();
	
	/**
	 * Property to indicate if we are running as a cron or not
	 * @access		private
	 * @since		1.0.6
	 * @var			boolean
	 */
	private $cron			= false;
	
	/**
	 * Method to halt execution of plugin if a failure exists at setup
	 * @access		private
	 * @since		1.0.6
	 * @var			boolean
	 */
	private $enabled	= true;
	
	/**
	 * Stores queued sets to execute
	 * @access		private
	 * @since		1.0.6
	 * @var			array
	 */
	private $queue		= array();
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.1.0
	 * @param		string		$subject: passed by JPlugin 
	 * @param		array		$config:  passed by JPlugin
	 * 
	 * @since		1.0.6
	 */
	public function __construct( & $subject, $config )
	{
		parent::__construct($subject, $config);
		
		$this->loadLanguage();
		
		// Check for empty required first
		$apikey	= $this->params->get( 'apikey' );
		$usessl	= $this->params->get( 'apissl' ) == '1' ? true : false;
		
		if ( empty( $apikey ) ) {
			$this->enabled = false;
			return;
		}
		
		include_once( 'MCAPI.class.php' );
		
		$this->mailchimp = new MCAPI( $apikey );
		$this->mailchimp->useSecure( $usessl );
		
		if ( $this->mailchimp->ping() != "Everything's Chimpy!" ) {
			$this->enabled = false;
			return;
		}
		
	}
	
	
	/**
	 * Event called when gathering update sites to check for updates
	 * @access		public
	 * @version		1.1.0
	 * 
	 * @return		array
	 * @since		1.1.0
	 */
	public function getUpdateSite()
	{
		return array(
				'extensionName'				=> 'plg_belong_mailchimp',
				'options' => array(
						'extensionTitle'	=> 'Belong Joomla! Mailchimp Plugin',
						'storage'			=> 'database',
						'storagePath'		=> null,
						'extensionType'		=> 'plugin',
						'updateUrl'			=> 'https://www.gohigheris.com/updates/belong/plugin/mailchimp'
				)
		);
	}
	
	
	/**
	 * Event called when getting permission groups list
	 * @access		public
	 * @version		1.1.0
	 * @param		array		$data: an array of gathered permision groups
	 * 
	 * @return		array
	 * @since		1.0.6
	 */
	public function onGetPermissionGroups( & $data = array() )
	{
		if (! $this->enabled ) return $data;
		static $instance = null;
		if ( $instance == null ) {
			$groups		= $this->_getMailchimpgroups( false );
			if (! $groups ) return $data;
			$instance = array( 'items' => $groups, 'text' => JText :: _( 'PLG_BELONG_MAILCHIMP_GROUP_LABEL' ) );
		}
		return $instance;
	}
	
	
	/**
	 * Event called to run the queue of users and update
	 * @access		public
	 * @version		1.1.0
	 * 
	 * @return		true
	 * @since		1.0.6
	 */
	public function onRunQueue()
	{
		$qs		= $this->queue;
		$groups	= $this->_getMailchimpgroups( '' );
		$batch	= array();
		
		foreach( $qs as $q ) {
			$ruser	= $q['u'];
			$group_merge = $update = array();
			
			foreach (  $q['g'] as $membergroup ) {
				
				$parts			= explode( ':', $membergroup );
				$list_id		= $parts[0];
				$grouping_id	= $parts[1];
				
				if (! isset ( $update[$list_id][$grouping_id] ) ) 
					$update[$list_id][$grouping_id] = array();
				
				$update[$list_id][$grouping_id][]	= str_replace(',', '\,', $groups[$membergroup] );
			}
			
			foreach ( $update as $list_id => $update ) {
				foreach ( $update as $gid => $garray ) {
					if ( $gid == '0' ) continue;
					$group_merge[]	= array( 'id' => $gid, 'groups' => implode( ',', $garray ) );
				}
				
				if (! isset( $batch[$list_id] ) )
					$batch[$list_id] = array();
				
				$batch[$list_id][]	= array( 'EMAIL' => $ruser, 'GROUPINGS' => $group_merge );
			}
		}
		
		foreach ( $batch as $list_id => $b ) {
			$this->mailchimp->listBatchSubscribe( $list_id, $b, false, true, true );
		}
		
		return true;
	}
	
	
	/**
	 * Event to handle user permissions update
	 * @access		public
	 * @version		1.1.0
	 * @param		integer		$id: the Joomla id of the user to update
	 * @param		array		$add_groups: an array of user groups to add user to
	 * @param		array		$drop_groups: an array of user groups to drop user from
	 * @param		boolean		$cron: indicates this is a cron
	 * 
	 * @return		true
	 * @since		1.0.6
	 */
	public function onUserUpdatePermissions( $id, $add_groups = array(), $drop_groups = array(), $cron = false )
	{
		if (! $this->enabled ) return;
		if (! isset( $add_groups['mailchimp'] ) ) $add_groups['mailchimp'] = array();
		if (! isset( $drop_groups['mailchimp'] ) ) $drop_groups['mailchimp'] = array();
		if ( empty( $add_groups['mailchimp'] ) && empty( $drop_groups['mailchimp'] ) ) return;
		$this->cron = $cron;
		
		$debug	=   BelongDebug :: getInstance( true );
		$user	= & JFactory :: getUser( $id );
		$groups	=   $this->_getMailchimpgroups( true );
		
		// Grab the user and fail if not found
		$remote_user = $this->_getUser( $user->email );
		if ( $remote_user === false ) {
			$debug->add( JText::_( 'PLG_BELONG_MAILCHIMP_NOUSER' ), $user->email );
			unset( $groups, $user );
			return;
		}
		
		$adds	=   $add_groups['mailchimp'];
		$drops	=   $drop_groups['mailchimp'];
		$curs	=   $remote_user;
		$sets	=   array();
		
		// Pre-processing
		$dispadds	= $dispdrops = $dispcurs = array();
		
		if (! empty( $adds ) ) {
			foreach( $adds as $add ) $dispadds[$add] = $groups[$add];
			$debug->add( JText::_( 'PLG_BELONG_MAILCHIMP_ADDGROUPS' ), implode( '<br/>-- ', $dispadds ) );
		}
		
		if (! empty( $drops ) ) {
			foreach( $drops as $drop ) $dispdrops[$drop] = $groups[$drop];
			$debug->add( JText::_( 'PLG_BELONG_MAILCHIMP_DROPGROUPS' ), implode( '<br/>-- ', $dispdrops ) );
		}
		
		if (! empty( $curs ) ) {
			foreach( $curs as $cur ) $dispcurs[$cur]	= $groups[$cur];
			$debug->add( JText::_( 'PLG_BELONG_MAILCHIMP_CURGROUPS' ), implode( '<br/>-- ', $dispcurs ) );
		}
		
		// Drop groups from currents first
		if (! empty( $drops ) ) {
			$curs		= array_diff( $curs, $drops );
			$dispcurs	= array();
			foreach( $curs as $cur ) $dispcurs[$cur]	= $groups[$cur];
			$debug->add( JText::_( 'PLG_BELONG_MAILCHIMP_AFTERDROPGROUPS' ), implode( '<br/>-- ', $dispcurs ) );
		}
		
		// Add groups to current sets
		if (! empty( $adds ) ) {
			$curs		= array_unique( array_merge( $curs, $adds ) );
			$dispcurs	= array();
			foreach( $curs as $cur ) $dispcurs[$cur]	= $groups[$cur];
			$debug->add( JText::_( 'PLG_BELONG_MAILCHIMP_AFTERADDGROUPS' ), implode( '<br/>-- ', $dispcurs ) );
		}
		
		// Queue up for final run
		$this->_enqueueUpdate( $user, $curs );
		unset( $groups, $user, $curs, $drops, $adds );
		return true;
	}
	
	
	/**
	 * Enqueues a user update for run
	 * @access		private
	 * @version		1.1.0
	 * @param		array		$user: the user to update
	 * @param		string		$groups: the groups to set the user to
	 * 
	 * @return		true
	 * @since		1.0.6
	 */
	private function _enqueueUpdate( $user, $groups )
	{
		$debug	=   BelongDebug :: getInstance( true );
		
		if (! isset( $this->queue[$user->id] ) ) $this->queue[$user->id] = array( 'u' => $user->email, 'g' => $groups );
		else $debug->add( JText::_( 'PLG_BELONG_MAILCHIMP_ERRORALREADYRUN' ), $user->email );
		
		return true;
	}
	
	
	/**
	 * Method to get segment groupings from Mailchimp
	 * @access		private
	 * @version		1.1.0
	 * 
	 * @return		array
	 * @since		1.0.6
	 */
	private function _getGroupings()
	{
		static $groups = array();
		
		if ( empty( $groups ) ) {
			$lists	= $this->_getLists();
			if ( empty( $lists ) ) return $groups;
			$interests = array();
			foreach( $lists as $list ) {
				$groups[$list['id']]	= array( 'value' => $list['id'], 'text' => $list['name'], 'groupings' => array( array( 'value' => '0', 'text' => 'No Segment Group Selected', 'group' => array() ) ) );
				$interests[$list['id']] = $this->mailchimp->listInterestGroupings( $list['id'] );
				if ( empty( $interests[$list['id']] ) ) continue;
				foreach( $interests[$list['id']] as $interest ) {
					$listgroups = array();
					if (! empty( $interest['groups'] ) ) {
						foreach( $interest['groups'] as $group ) {
							$listgroups[] = array('value' => $group['bit'], 'text' => $group['name'] );
						}
					}
					$groups[$list['id']]['groupings'][]	= array( 'value' => $interest['id'], 'text' => $interest['name'], 'group' => $listgroups );
				}
			}
		}
		
		return $groups;
	}
	
	
	/**
	 * Method to get lists from Mailchimp
	 * @access		private
	 * @version		1.1.0
	 * 
	 * @return		array
	 * @since		1.0.6
	 */
	private function _getLists()
	{
		static $lists = array();
		
		if ( empty( $lists ) ) {
			$lists	= $this->mailchimp->lists();
			$lists	= $lists['data'];
		}
		
		return $lists;
	}
	
	
	/**
	 * Method to get a list of email addresses and values on Mailchimp
	 * @access		private
	 * @version		1.1.0
	 * @param		string		- $user: contains the email address if trying to retrieve just a single user
	 * 
	 * @return		array
	 * @since		1.0.6
	 */
	private function _getListEmail( $user = null )
	{
		/*
		static $emails	= array();
		
		if ( empty( $emails ) ) {
			
			$reverse	= $this->_getReverseList();
			
			foreach ( $this->_getLists() as $list ) {
				
				if ( $this->cron ) {
					$members	= $this->mailchimp->listMembers( $list['id'], 'subscribed', null, 0, 15000 );
				}
				else {
					$members	= array( 'total' => 1, 'data' => array( array( 'email' => $user ) ) );
				}
				
				$temp		= array();
				$cnt		= 0;
				$mcnt		= 0;
				foreach( $members['data'] as $member ) {
					$temp[] = $member['email'];
					$cnt++; $mcnt++;
					if ( $cnt == 50 || $mcnt == $members['total'] ) {
						$info	= $this->mailchimp->listMemberInfo( $list['id'], $temp );
						
						foreach ( $info['data'] as $item ) {
								
							foreach ( $item['merges']['GROUPINGS'] as $id => $grouping ) {
			
								if (! empty( $grouping['groups'] ) ) {
									$groups = preg_split( '#(?<!\\\\),#', $grouping['groups'] );
									for( $i=0; $i<count( $groups ); $i++ ) {
										$groups[$i] = $reverse[$list['id']][$grouping['id']][stripslashes( $groups[$i] )];
									}
								}
								else {
									$groups = array();
								}
			
								$item['merges']['GROUPINGS'][$id]['groups'] = $groups;
							}
								
							$emails[$item['email']][$list['id']] = $item['merges']['GROUPINGS'];
						}
			
						$cnt	= 0;
						$temp	= array();
					}
				}
			}
			
			unset( $reverse, $members, $temp, $info, $cnt, $mcnt );
		}
		
		return $emails;*/
	}
	
	
	/**
	 * Retrieves the Mailchimp arrays
	 * @access		private
	 * @version		1.1.0
	 * @param		boolean		$asArray: if true returns id => title, else returns array of objects
	 * 
	 * @return		array
	 * @since		1.0.6
	 */
	private function _getMailchimpgroups( $asArray = false )
	{
		static	$data	= array( 'true' => array(), 'false' => array(), 'null' => array() );
		
		$groups	= $this->_getGroupings();
		$check	= ( $asArray === true ? 'true' : ( $asArray === false ? 'false' : 'null' ) );
		
		if ( empty( $data[$check] ) ) {
			
			foreach( $groups as $list_id => $lists ) {
				
				// Test to see if we have groupings
				if ( empty( $lists['groupings'] ) )
				{	// We have no groupings so set true, null and false and loop back
					$data['true'][$list_id] 						= $lists['text'];
					$data['null'][$list_id] 						= $lists['text'];
					$data['false'][$this->_name . '|' . $list_id]	= $lists['text'];
					continue;
				}
				
				// We must have groupings then
				$prevalue	= $this->_name . '|';		// If false, we prepend mailchimp|
				$pretruetxt	= $lists['text'] . ': ';
				
				foreach ( $lists['groupings'] as $groupings ) {
					
					$subvalue	= $list_id . ':' . $groupings['value'];
					
					// Catch empties
					if ( empty( $groupings['group'] ) ) {
						
						$data['true'][$subvalue]	= $pretruetxt . $groupings['text'];
						$data['null'][$subvalue]	= null;
						$data['false'][$prevalue.$subvalue]	= $pretruetxt . $groupings['text'];
						
						continue;
					}
					
					
					foreach ( $groupings['group'] as $group ) {
						
						$value	= $subvalue . ':' . $group['value'];
						
						
						$data['true'][$value]	= $pretruetxt . $groupings['text'] . ' - ' . $group['text'];
						$data['null'][$value]	= $group['text'];
						$data['false'][$prevalue.$value]	=  str_repeat( '&nbsp;', 10 )  . '- ' . $groupings['text'] . ' - ' . $group['text'];
						
					}
					
					
				}
				
			}	// End FOREACH through groups
		}
		return $data[$check];
	}
	
	
	/**
	 * Method to get a list for figuring out which segment to use
	 * @acess		private
	 * @version		1.1.0
	 * 
	 * @return		array
	 * @since		1.0.6
	 */
	private function _getReverseList()
	{
		static $reverse = array();
		
		if ( empty( $reverse ) ) {
			
			foreach ( $this->_getGroupings() as $list_id => $items ) {
				if ( empty( $items ) || !is_array( $items ) ) continue;
			
				if (! isset( $reverse[$list_id] ) )
					$reverse[$list_id] = array();
			
				foreach( $items['groupings'] as $gs ) {
					if ( empty( $gs['group'] ) || !is_array( $gs['group'] ) ) continue;
					foreach( $gs['group'] as $group ) {
						$reverse[$list_id][$gs['value']][$group['text']] = $group['value'];
					}
				}
			}
		}
		
		return $reverse;
	}
	
	
	/**
	 * Retrieves the Mailchimp user
	 * @access		private
	 * @version		1.1.0
	 * @param		string		$user: the email address to retrieve the user for
	 * 
	 * @return		object
	 * @since		1.0.6
	 */
	private function _getUser ( $user )
	{
		$data	= array();
		$infos	= array();
		foreach ( $this->_getLists() as $list ) {
			$listmemberinfo		= $this->mailchimp->listMemberInfo( $list['id'], $user );
			if (! isset( $listmemberinfo['data'] ) || $listmemberinfo['errors'] > 0 ) continue;
			$infos[$list['id']]	= $this->_cleanUser( $listmemberinfo['data'], $list['id'] );
		}
		
		if ( empty( $infos ) ) return false;
		
		foreach ( $infos as $list_id => $groupings ) {
			if (! is_array( $groupings ) ) continue;
			foreach ( $groupings as $segments ) {
				if (! is_array( $segments ) ) continue;
				foreach ( $segments['groups'] as $segment ) {
					$data[]	= $list_id . ':' . $segments['id'] . ':' . $segment;
				}
			}
		}
		
		unset( $infos, $listmemberinfo );
		return $data;
		/*
		static $users		= array();
		
		if ( empty( $users ) ) {
			$groups	= $this->_getGroupings();
			$emails	= $this->_getListEmail( $user );
			
			foreach ( $emails as $email => $lists ) {
				$temp	= array();
				if (! is_array( $lists ) ) continue;
				foreach ( $lists as $list_id => $groupings ) {
					if (! is_array( $groupings ) ) continue;
					foreach ( $groupings as $segments ) {
						if (! is_array( $segments ) ) continue;
						foreach ( $segments['groups'] as $segment ) {
							$temp[]	= $list_id . ':' . $segments['id'] . ':' . $segment;
						}
					}
				}
				$users[$email]	= $temp;
			}
			unset( $groups, $emails, $temp, $lists, $groupings, $segments );
		}
		
		if (! isset( $users[$user] ) ) return false;
		
		return $users[$user]; */
	}
	
	
	/**
	 * Method to uniformly clean information passed back by Mailchimp API
	 * @access		private
	 * @version		1.1.0
	 * @param		array		- $info: contains the info sent back from MC
	 * @param		string		- $list_id: contains the list_id
	 * 
	 * @return		array
	 * @since		1.0.6
	 */
	private function _cleanUser( $info, $list_id )
	{
		if (! is_array( $info ) ) return array();
		$reverse	= $this->_getReverseList();
		$data		= array();
		
		foreach ( $info as $item ) {
		
			foreach ( $item['merges']['GROUPINGS'] as $id => $grouping ) {
					
				if (! empty( $grouping['groups'] ) ) {
					$groups = preg_split( '#(?<!\\\\),#', $grouping['groups'] );
					for( $i=0; $i<count( $groups ); $i++ ) {
						$groups[$i] = $reverse[$list_id][$grouping['id']][stripslashes( $groups[$i] )];
					}
				}
				else {
					$groups = array();
				}
					
				$item['merges']['GROUPINGS'][$id]['groups'] = $groups;
			}
		
			$data = $item['merges']['GROUPINGS'];
		}
		
		unset( $reverse );
		return $data;
	}
}