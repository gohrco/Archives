function checkApicnxn()
{
	var apiurl = encodeURIComponent( document.getElementById( 'apiurl' ).value );
	var apiusername	= encodeURIComponent( document.getElementById( 'apiusername' ).value );
	var apipassword = encodeURIComponent( document.getElementById( 'apipassword' ).value );
	var apiaccesskey = encodeURIComponent( document.getElementById( 'apiaccesskey' ).value );
	
	var apistatusimg = document.getElementById( 'apistatusimg' );
	var apistatusmsg = document.getElementById( 'apistatusmsg' );
	var apistatusdef = document.getElementById( 'apistatusmsgdefault' ).value;
	
	apistatusimg.removeClass( 'ajaxSuccess' ).removeClass( 'ajaxError' ).addClass( 'ajaxLoading' );
	apistatusmsg.innerHTML=apistatusdef;
	
	var xhr = createXHR();
	xhr.open("GET","index.php?option=com_belong&task=ajax.apicnxn&apiusername="+apiusername
			+"&apipassword="+apipassword
			+"&apiaccesskey="+apiaccesskey
			+"&apiurl="+apiurl,true);
	xhr.send( null );
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				try //Internet Explorer
				{
					xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
					xmlDoc.async="false";
					xmlDoc.loadXML(xhr.responseText);
				}
				catch(e)
				{
					try //Firefox, Mozilla, Opera, etc.
					{
						parser=new DOMParser();
						xmlDoc=parser.parseFromString(xhr.responseText,"text/xml");
					}
					catch(e) {alert(e.message)}
				}
				var result =xmlDoc.getElementsByTagName("param").item(0);
				
				var dsc = result.getElementsByTagName("result")[0].childNodes[0].nodeValue;
				var msg = result.getElementsByTagName("message")[0].childNodes[0].nodeValue;
				
				if (dsc == "success") {
					apistatusimg.removeClass('ajaxLoading').addClass('ajaxSuccess');
					document.getElementById('apiconnection').setAttribute("value", "1");
				}
				else {
					apistatusimg.removeClass('ajaxLoading').addClass('ajaxError');
				}
				apistatusmsg.innerHTML=msg;
			}
			else {
				alert('Error code ' + xhr.status);
			}
		}
	}
}


function checkForUpdates()
{
	var apistatuslnk = document.getElementById( 'belong_icon_updates_link' );
	var apistatusimg = document.getElementById( 'belong_icon_updates_img' );
	var apistatusmsg = document.getElementById( 'belong_icon_updates_title' );
	
	var jsonRequest = new Request.JSON({url: 'index.php', 
		onSuccess: function(response) {
			apistatusmsg.innerHTML=response.message;
			
			apistatusimg.setAttribute( 'src', '');
			apistatusimg.setAttribute( 'alt', '' );
			apistatusimg.addClass( 'ajaxicon' );
			
			if ( response.updates == '1' ) {
				apistatusimg.addClass( 'found' );
			}
			else if ( response.updates == '0' ) {
				apistatusimg.addClass( 'current' );
			}
			else if ( response.updates == '-1' ) {
				apistatusimg.addClass( 'unsupported' );
			} else {
				apistatusimg.addClass( 'stall' );
			}
		}
	}).get({'task': 'ajax.checkforupdates', 'option': 'com_belong'});
}


function getproductaddons( oid ) {
	var pid = document.getElementById('jform_pid').value;
	var aid = document.getElementById( 'jform_aid');
	
	aid.length = 0;
	
	var jsonRequest = new Request.JSON({url: 'index.php', 
		onSuccess: function(response){
			if ( response.result == 'success' ) {
				var items = response.message;
				
				Array.each(items, function(row){
					if ( row.id == oid ) {
						aid.add( new Option( row.name, row.id, false, true ) );
					}
					else {
						aid.add( new Option( row.name, row.id ) );
					}
				});
			}
		}
	}).get({'pid': pid, 'task': 'ajax.getproductaddons', 'option': 'com_belong'});
}

function createXHR() {
	var xhr = null;
		if (window.XMLHttpRequest) {
			xhr = new XMLHttpRequest();
		} else if (window.ActiveXObject) {
			try {
				xhr = new ActiveXObject('Microsoft.XMLHTTP');
			} catch (e) {}
		}
	return xhr;
}