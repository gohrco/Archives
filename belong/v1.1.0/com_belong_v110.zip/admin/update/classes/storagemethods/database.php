<?php
/**
 * Belong
 *
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.0 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      1.1.0
 *
 * @desc       This is a helper file for the update routines for Belong
 *
 * The methods and routines within this file are based partly upon the work of
 *   Nicholas K. Dionysopoulos / AkeebaBackup.com
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die();
/*-- Security Protocols --*/


/**
 * BelongStorageDatabase class object
 * @version		1.1.0
 * 
 * @since		1.1.0
 * @author		Steven
 */
class BelongStorageDatabase extends BelongStorage
{
	/**
	 * Stores the name of the extension we are using
	 * @var		string
	 */
	private static $extension	= null;
	
	/**
	 * Stores the type of extension we are using
	 * @var		string
	 */
	private static $exttype		= null;
	
	/**
	 * Stores the parameter key we are using in the params field
	 * @var		string
	 */
	private static $paramkey	= null;
	
	
	/**
	 * Method to load an extension into the storage object
	 * @access		public
	 * @version		1.1.0
	 * @param		object		- $config: contains the BelongUpdateConfig object to use for stettings
	 * 
	 * @since		1.1.0
	 */
	public function load( $config )
	{
		$db = & JFactory :: getDbo();
		
		// Set the extension to use in the DB
		if ( empty( $config['_extension'] ) )
			self :: $extension = $config['_extensionName'];
		else
			self :: $extension = $config['_extension'];
		
		// Set the extension type to use in the DB
		if ( empty( $config['_exttype'] ) )
			self :: $exttype = 'component';
		else
			self :: $exttype = $config['_exttype'];
		
		// Set the parameter key to use in the parameters field
		if ( empty( $config['_paramkey'] ) )
			self :: $paramkey = 'update';
		else
			self :: $paramkey = $config['_paramkey'];
		
		
		$sql = 'SELECT ' . $db->nameQuote( 'params' )
			 . ' FROM ' . $db->nameQuote( '#__extensions' )
			 . ' WHERE ' . $db->nameQuote( 'type' ) . '=' . $db->Quote( self :: $exttype )
			 . ' AND ' . $db->nameQuote( 'element' ) . '=' . $db->Quote( self :: $extension );
		
		$db->setQuery( $this->_createSql() );
		$raw = $db->loadResult();
		
		$params	= new JParameter( $raw );
		
		$data	= $params->getValue( self :: $paramkey, '' );
		
		jimport( 'joomla.registry.registry' );
		self::$registry = new JRegistry( 'update' );
		
		self::$registry->loadINI( $data );
	}
	
	
	/**
	 * Method to save parameters to the database
	 * @access		public
	 * @version		1.1.0
	 * 
	 * @since		1.1.0
	 */
	public function save()
	{
		$data	=   self :: $registry->toString( 'INI' );
		$db		= & JFactory :: getDBO();
		
		$db->setQuery( $this->_createSql() );
		
		$raw	= $db->loadResult();
		$params	= new JParameter( $raw );
		$params->setValue( self::$paramkey, $data );
		
		$data	= $params->toString( 'JSON' );
		$sql	= 'UPDATE ' . $db->nameQuote( '#__extensions' )
				. ' SET ' . $db->nameQuote( 'params' ) . ' = '.$db->Quote( $data )
				. ' WHERE ' . $db->nameQuote( 'element' ) . ' = ' . $db->Quote( self :: $extension )
				. ' AND ' . $db->nameQuote( 'type' ) . ' = ' . $db->Quote( self :: $extension );
		$db->setQuery( $sql );
		$db->query();
	}
	
	
	/**
	 * Method to create a commonly used SQL query
	 * @access		private
	 * @version		1.1.0
	 * 
	 * @return		string containg SQL
	 * @since		1.1.0
	 */
	private function _createSql()
	{
		$db	= & JFactory :: getDbo();
		$sql = 'SELECT ' . $db->nameQuote( 'params' )
		. ' FROM ' . $db->nameQuote( '#__extensions' )
		. ' WHERE ' . $db->nameQuote( 'type' ) . '=' . $db->Quote( self :: $exttype )
		. ' AND ' . $db->nameQuote( 'element' ) . '=' . $db->Quote( self :: $extension );
		
		return $sql;
	}
}