<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.0 ( $Id: controller.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the main controller file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.controller');
/*-- File Inclusions --*/


/**
 * Belong Controller class object
 * @version		1.1.0
 * 
 * @since		1.0.0
 * @author		Steven
 */
class BelongController extends JController
{
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.1.0
	 * 
	 * @since		1.0.0
	 */
	public function __construct()
	{
		parent :: __construct();
		$this->registerTask( 'rules',			'task_redirect' );
		$this->registerTask( 'products',		'task_redirect' );
		$this->registerTask( 'productrulesets',	'task_redirect' );
	}
	
	
	/**
	 * Displays the backend to the user
	 * @access		public
	 * @version		1.1.0
	 * 
	 * @since		1.0.0
	 */
	public function display( $cachable = false )
	{
		JRequest :: setVar( 'view', JRequest :: getCmd( 'view', 'Default' ) );
		parent :: display( $cachable );
	}
	
	
	/**
	 * Currently a redirecter to Go Higher for support
	 * @access		public
	 * @version		1.1.0
	 * 
	 * @since		1.0.0
	 */
	public function help()
	{
		$app = & JFactory :: getApplication();
		$redirect = 'https://www.gohigheris.com';
		$app->redirect( $redirect );
	}
	
	
	/**
	 * Redirects unmapped tasks to appropriate view
	 * @access		public
	 * @version		1.1.0
	 * @param		bool		- $cachable: tells Joomla if the template is cachable
	 * 
	 * @since		1.0.0
	 */
	public function task_redirect( $cachable = false )
	{
		JRequest :: setVar( 'view', JRequest :: getVar( 'task', 'default' ) );
		parent :: display( $cachable );
	}
}