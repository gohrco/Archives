DROP TABLE IF EXISTS `#__belong_rules`;
DROP TABLE IF EXISTS `#__belong_productrulesets`;
DROP TABLE IF EXISTS `#__belong_products`;