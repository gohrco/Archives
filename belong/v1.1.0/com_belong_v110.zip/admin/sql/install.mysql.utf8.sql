CREATE TABLE IF NOT EXISTS `#__belong_rules` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `data` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM; 

CREATE TABLE IF NOT EXISTS `#__belong_products` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` text,
  `pid` int(10) NOT NULL,
  `aid` int(10) DEFAULT NULL,
  `pdata` text NOT NULL,
  `statusorder` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;


CREATE TABLE IF NOT EXISTS `#__belong_productrulesets` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL,
  `rid` int(10) NOT NULL,
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `priority` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;