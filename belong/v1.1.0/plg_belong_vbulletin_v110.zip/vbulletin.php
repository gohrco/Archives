<?php
/**
* Belong
*
* @package    Belong
* @copyright  2012 Go Higher Information Services.  All rights reserved.
* @license    GNU General Public License version 2, or later
* @version    1.1.0 ( $Id: vbulletin.php 56 2012-04-11 00:37:22Z steven_gohigher $ )
* @author     Go Higher Information Services
* @since      1.0.3
*
* @desc       This file is a utility helper for Belong
*
*/

/*-- Security Protocols --*/
defined('_JEXEC') or die;

/*-- Localscope import --*/
jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.database.database' );

/**
 * Belong Plugin: vBulletin
 * Extends the Belong ruleset functionality to a local vBulletin
 * @version		1.1.0
 * 
 * @since		1.0.3
 * @author		Steven
 */
class plgBelongVbulletin extends JPlugin
{
	/**
	 * Method to halt execution of plugin if a failure exists at setup
	 * @access		private
	 * @since		1.0.3
	 * @var			boolean
	 */
	private $enabled	= true;
	
	/**
	 * Stores queued sets to execute
	 * @access		private
	 * @since		1.0.3
	 * @var			array
	 */
	private $queue		= array();
	
	/**
	 * Indicates the use of a table prefix (needed b/c Joomla wont accept an empty prefix when setting up a database connection)
	 * @access		private
	 * @since		1.0.3
	 * @var			boolean
	 */
	private $useprefix	= false;
	
	/**
	 * Stores the vBulletin database object
	 * @access		private
	 * @since		1.0.3
	 * @var			JDatabase object
	 */
	private $vdb		= null;
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.1.0
	 * @param		string		$subject: passed by JPlugin 
	 * @param		array		$config:  passed by JPlugin
	 * 
	 * @since		1.0.3
	 */
	public function __construct( & $subject, $config )
	{
		parent::__construct($subject, $config);
		
		$this->loadLanguage();
		
		// Build database
		$prefix	=  $this->params->get( 'dbpref' );
		$options = array(
			'host' => $this->params->get( 'dbhost' ),
			'user' => $this->params->get( 'dbuser' ),
			'password' => $this->params->get( 'dbpass' ),
			'database' => $this->params->get( 'dbname' ),
			'prefix' => $prefix
		);
		
		$this->vdb = JDatabase :: getInstance( $options );
		$this->useprefix = isset( $prefix ) ? true : false;
		
		// Make sure it is there...
		if (! $this->vdb->connected() ) {
			$this->enabled = false;
			return;
		}
	}
	
	
	/**
	 * Event called when gathering update sites to check for updates
	 * @access		public
	 * @version		1.1.0
	 *
	 * @return		array
	 * @since		1.1.0
	 */
	public function getUpdateSite()
	{
		return array(
				'extensionName'				=> 'plg_belong_vbulletin',
				'options' => array(
						'extensionTitle'	=> 'Belong Joomla! vBulletin Plugin',
						'storage'			=> 'database',
						'storagePath'		=> null,
						'extensionType'		=> 'plugin',
						'updateUrl'			=> 'https://www.gohigheris.com/updates/belong/plugin/vbulletin'
				)
		);
	}
	
	
	/**
	 * Event called when getting permission groups list
	 * @access		public
	 * @version		1.1.0
	 * @param		array		$data: an array of gathered permision groups
	 * 
	 * @return		array
	 * @since		1.0.3
	 */
	public function onGetPermissionGroups( & $data = array() )
	{
		if (! $this->enabled ) return $data;
		return array( 'items' => $this->_getVbgroups(), 'text' => JText :: _( 'PLG_BELONG_VBULLETIN_GROUP_LABEL' ) );
	}
	
	
	/**
	 * Event called to run the queue of users and update
	 * @access		public
	 * @version		1.1.0
	 * 
	 * @return		true
	 * @since		1.0.3
	 */
	public function onRunQueue()
	{
		$qs = $this->queue;
		
		foreach( $qs as $q ) {
			$this->_updateVbuser( $q['u'], $q['g'] );
		}
		
		return true;
	}
	
	
	/**
	 * Event to handle user permissions update
	 * @access		public
	 * @version		1.1.0
	 * @param		integer		$id: the Joomla id of the user to update
	 * @param		array		$add_groups: an array of user groups to add user to
	 * @param		array		$drop_groups: an array of user groups to drop user from
	 * 
	 * @return		true
	 * @since		1.0.3
	 */
	public function onUserUpdatePermissions( $id, $add_groups = array(), $drop_groups = array() )
	{
		if (! $this->enabled ) return;
		if (! isset( $add_groups['vbulletin'] ) ) $add_groups['vbulletin'] = array();
		if (! isset( $drop_groups['vbulletin'] ) ) $drop_groups['vbulletin'] = array();
		
		$debug	=   BelongDebug :: getInstance( true );
		$user	= & JFactory :: getUser( $id );
		$groups	=   $this->_getVbgroups( true );
		
		// Grab the vbuser and fail if not found
		$vbuser = $this->_getVbuser( $user->email );
		if ( empty( $vbuser ) ) {
			$debug->add( JText::_( 'PLG_BELONG_VBULLETIN_NOVBUSER' ), $user->email );
			return;
		}
		
		$adds	=   array_flip( $add_groups['vbulletin'] );
		$drops	=   array_flip( $drop_groups['vbulletin'] );
		$curs	=   array_flip( explode( ',', $vbuser->membergroupids ) );
		
		foreach( $adds as $addId => $junk ) $adds[$addId] = $groups[$addId];
		foreach( $drops as $dropId => $junk ) $drops[$dropId] = $groups[$dropId];
		foreach( $curs as $curId => $junk ) $curs[$curId] = $groups[$curId];
		
		// Pre-processing
		$debug->add( JText::_( 'PLG_BELONG_VBULLETIN_ADDGROUPS' ), implode( '<br/>-- ', $adds ) );
		$debug->add( JText::_( 'PLG_BELONG_VBULLETIN_DROPGROUPS' ), implode( '<br/>-- ', $drops ) );
		$debug->add( JText::_( 'PLG_BELONG_VBULLETIN_CURGROUPS' ), implode( '<br/>-- ', $curs ) );
		
		$curs	= explode( ',', $vbuser->membergroupids );		// Current group ids
		$drops	= $drop_groups['vbulletin'];					// Groups to drop from
		$sets	= array_diff( $curs, $drops );					// Get difference (remove drops from current)
		
		// Cycle through to catch empties and avoid a vB error
		for ( $i=0; $i<count($sets); $i++) {
			if ( empty( $sets[$i] ) ) unset( $sets[$i] );
		}
		
		$curs	= array_flip( $sets );
		foreach( $curs as $curId => $junk ) $curs[$curId] = $groups[$curId];
		
		$debug->add( JText::_( 'PLG_BELONG_VBULLETIN_AFTERDROPGROUPS' ), implode( '<br/>-- ', $curs ) );
		
		$sets	= array_unique( array_merge( $sets, $add_groups['vbulletin'] ) );	// Add user to add groups
		$curs	= array_flip( $sets );
		foreach( $curs as $curId => $junk ) $curs[$curId] = $groups[$curId];
		$debug->add( JText::_( 'PLG_BELONG_VBULLETIN_AFTERADDGROUPS' ), implode( '<br/>-- ', $curs ) );
		
		// These are our settings
		$membergroups	= implode( ',', $sets );
		$vbuser			= (array) $vbuser;
		
		// Queue up for final run
		return $this->_enqueueUpdate( $vbuser, $membergroups );
	}
	
	
	/**
	 * Enqueues a user update for run
	 * @access		private
	 * @version		1.1.0
	 * @param		array		$vbuser: the vbuser to update
	 * @param		string		$groups: the groups to set the user to
	 * 
	 * @return		true
	 * @since		1.0.3
	 */
	private function _enqueueUpdate( $vbuser, $groups )
	{
		$debug	=   BelongDebug :: getInstance( true );
		
		if (! isset( $this->queue[$vbuser['userid']] ) ) $this->queue[$vbuser['userid']] = array( 'u' => $vbuser, 'g' => $groups );
		else $debug->add( JText::_( 'PLG_BELONG_VBULLETIN_ERRORALREADYRUN' ), $vbuser['email'] );
		
		return true;
	}
	
	
	/**
	 * Retrieves the vBulletin Groups
	 * @access		private
	 * @version		1.1.0
	 * @param		boolean		$asArray: if true returns id => title, else returns array of objects
	 * 
	 * @return		array
	 * @since		1.0.3
	 */
	private function _getVbgroups( $asArray = false )
	{
		static $items = array();
		
		if ( empty( $items ) ) {
			$query = $this->vdb->getQuery(true);
			$query->select( "CONCAT( '" . $this->_name . "|', u.usergroupid ) as value, u.title as text, u.usergroupid as id" );
			$query->from( ( $this->useprefix ? '#__' : '' ) . 'usergroup u');
			
			$this->vdb->setQuery( $query );
			$items	= $this->vdb->loadObjectList();
		}
		
		if (! $asArray ) return $items;
		$data = array();
		foreach( $items as $row ) {
			$data[$row->id] = $row->text;
		}
		return $data;
	}
	
	
	/**
	 * Retrieves the vBulletin user
	 * @access		private
	 * @version		1.1.0
	 * @param		string		$email: the email address to retrieve the user for
	 * 
	 * @return		object
	 * @since		1.0.3
	 */
	private function _getVbuser ( $email )
	{
		$pref	= $this->useprefix ? '#__' : '';
		$query = $this->vdb->getQuery( true );
		$query->select( "u.userid, u.username, u.email, u.usergroupid AS group_id, g.title AS group_name, u.membergroupids, u.displaygroupid, u.password, u.salt as password_salt, u.usertitle, u.customtitle, u.posts, CASE WHEN f.field5 IS NULL OR f.field5 = '' THEN u.username ELSE f.field5 END AS name" );
		$query->from( $pref . "userfield as f" );
		$query->innerJoin( $pref . 'user AS u ON f.userid = u.userid' );
		$query->innerJoin( $pref . 'usergroup AS g ON u.usergroupid = g.usergroupid' );
		$query->where( 'u.email IN (\'' . $email . '\')' );
		
		$this->vdb->setQuery( $query );
		return $this->vdb->loadObject();
	}
	
	
	/**
	 * Updates the vBulletin user directly
	 * @access		private
	 * @version		1.1.0
	 * @param		array		$vbuser: the vbuser array to update user from
	 * @param		string		$membergroups: contains the membership groups the user should belong to
	 * 
	 * @since		1.0.4
	 */
	private function _updateVbuser( $vbuser, $membergroups )
	{
		$pref	= $this->useprefix ? '#__' : '';
		$query = $this->vdb->getQuery( true );
		$query->update( $pref . 'user' );
		$query->set( '`membergroupids`=' . $this->vdb->quote( $membergroups ) );
		$query->where( '`userid`='. $vbuser['userid'] );
		$this->vdb->setQuery( $query );
		$this->vdb->query();
	}
	
	
	
}