<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.4 ( $Id: productrulesets.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the productrulesets table file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die('Restricted access');
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.database.table');
/*-- File Inclusions --*/

/**
 * Belong Productrulesets Table
 * @author		Steven
 * @version		1.0.4
 * 
 * @since		1.0.0
 */
class BelongTableProductrulesets extends JTable
{
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.0.4
	 * @param		JDatabase object	- $db: db instance
	 * 
	 * @since		1.0.0
	 */
	public function __construct( &$db ) 
	{
		parent::__construct( '#__belong_productrulesets', 'id', $db );
	}
	
	
	/**
	 * Moves an item in the database
	 * @access		public
	 * @version		1.0.4
	 * @param		integer		- $delta: 1 or -1 based on action
	 * @param		string		- $where: can specify filter
	 * 
	 * @return		bool
	 * @since		1.0.0
	 */
	public function move($delta, $where = '')
	{
		// If the change is none, do nothing.
		if (empty($delta)) {
			return true;
		}
		
		// Initialise variables.
		$k		= $this->_tbl_key;
		$row	= null;
		$query	= $this->_db->getQuery(true);
		
		// Select the primary key and ordering values from the table.
		$query->select($this->_tbl_key.', priority');
		$query->from($this->_tbl);
		
		// If the movement delta is negative move the row up.
		if ($delta < 0) {
			$query->where('priority < '.(int) $this->priority);
			$query->order('priority DESC');
		}
		// If the movement delta is positive move the row down.
		elseif ($delta > 0) {
			$query->where('priority > '.(int) $this->priority);
			$query->order('priority ASC');
		}
		
		// Add the custom WHERE clause if set.
		if ($where) {
			$query->where($where);
		}

		// Select the first row with the criteria.
		$this->_db->setQuery($query, 0, 1);
		$row = $this->_db->loadObject();

		// If a row is found, move the item.
		if (! empty( $row ) ) {
			// Update the ordering field for this instance to the row's ordering value.
			$query = $this->_db->getQuery(true);
			$query->update($this->_tbl);
			$query->set('priority = '.(int) $row->priority);
			$query->where($this->_tbl_key.' = '.$this->_db->quote($this->$k));
			
			$this->_db->setQuery($query);

			// Check for a database error.
			if (!$this->_db->query()) {
				$e = new JException(JText::sprintf('JLIB_DATABASE_ERROR_MOVE_FAILED', get_class($this), $this->_db->getErrorMsg()));
				$this->setError($e);

				return false;
			}

			// Update the ordering field for the row to this instance's ordering value.
			$query = $this->_db->getQuery(true);
			$query->update($this->_tbl);
			$query->set('priority = '.(int) $this->priority);
			$query->where($this->_tbl_key.' = '.$this->_db->quote($row->$k));
			$this->_db->setQuery($query);

			// Check for a database error.
			if (!$this->_db->query()) {
				$e = new JException(JText::sprintf('JLIB_DATABASE_ERROR_MOVE_FAILED', get_class($this), $this->_db->getErrorMsg()));
				$this->setError($e);

				return false;
			}

			// Update the instance value.
			$this->priority = $row->priority;
		}
		else {
			// Update the ordering field for this instance.
			$query = $this->_db->getQuery(true);
			$query->update($this->_tbl);
			$query->set('priority = '.(int) $this->priority);
			$query->where($this->_tbl_key.' = '.$this->_db->quote($this->$k));
			$this->_db->setQuery($query);

			// Check for a database error.
			if (!$this->_db->query()) {
				$e = new JException(JText::sprintf('JLIB_DATABASE_ERROR_MOVE_FAILED', get_class($this), $this->_db->getErrorMsg()));
				$this->setError($e);

				return false;
			}
		}

		return true;
	}
}