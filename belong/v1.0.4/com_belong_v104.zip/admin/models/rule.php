<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.4 ( $Id: rule.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the rule model file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die();
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.modeladmin');
/*-- File Inclusions --*/

/**
 * Belong Rule Model
 * @author		Steven
 * @version		1.0.4
 * 
 * @since		1.0.0
 */
class BelongModelRule extends JModelAdmin
{
	/**
	 * Grabs the table
	 * @access		public
	 * @version		1.0.4
	 * @param		string		- $type: indicates which table
	 * @param		string		- $prefix: indicates the prefix
	 * @param		array		- $config: configuration array
	 * 
	 * @return		JTable object
	 * @since		1.0.0
	 */
	public function getTable( $type = 'Rules', $prefix = 'BelongTable', $config = array() ) 
	{
		return JTable::getInstance($type, $prefix, $config);
	}
	
	
	/**
	 * Retrieves the form for display
	 * @access		public
	 * @version		1.0.4
	 * @param		array		- $data: placeholder only
	 * @param		bool		- $loadData: tells to load the data or not
	 * 
	 * @return		JForm object or false on error
	 * @since		1.0.0
	 */
	public function getForm($data = array(), $loadData = true) 
	{
		// Get the form.
		$form = $this->loadForm('com_belong.rule', 'rule',
		                        array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form)) 
		{
			return false;
		}
		
		return $form;
	}
	
	
	/**
	 * Called to load the form data
	 * @access		protected
	 * @version		1.0.4
	 * 
	 * @return		array of data for form
	 * @since		1.0.0
	 */
	protected function loadFormData() 
	{
		// Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_belong.edit.rule.data', array());
		if ( empty( $data ) ) 
		{
			$data = $this->getItem();
		}
		return $data;
	}
}