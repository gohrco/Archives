<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.4 ( $Id: class.api.php 33 2012-01-14 16:56:05Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This file is the API handler and calls the curl object and returns responses to Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or exit('No direct script access allowed');
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.helper' );
require_once( 'class.curl.php' );
/*-- File Inclusions --*/

/**
 * BelongApi class object
 * @version		1.0.4
 * 
 * @since		1.0.0
 * @author		Steven
 */
class BelongApi extends JObject
{
	/**
	 * The default Belong option variables
	 * @access		public
	 * @var			array
	 * @since		1.0.0
	 */
	public $apioptions	= array();
	
	/**
	 * The default Belong Post variables
	 * @access		public
	 * @var			array
	 * @since		1.0.0
	 */
	public $apipost	= array();
	
	/**
	 * The Belong URL for the API interface
	 * @access		public
	 * @var			string
	 * @since		1.0.0
	 */
	public $apiurl	= null;
	
	/**
	 * Belong Curl Object
	 * @access		public
	 * @var			object
	 * @since		1.0.0
	 */
	public $curl	= null;
	
	/**
	 * Dont enable without settings to prevent error display
	 * @access		public
	 * @var			bool
	 * @since		1.0.0
	 */
	public $enabled	= false;
	
	/**
	 * Belong JParameters Object
	 * @access		public
	 * @var			object
	 * @since		1.0.0
	 */
	public $params	= array();
	
	/**
	 * Catchall for undeclared data
	 * @access		public
	 * @var 		array
	 * @since		1.0.0
	 */
	private $data	= array();
	
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.0.4
	 * 
	 * @since		1.0.0
	 */
	public function __construct( $creds = array() )
	{
		$params	= & JComponentHelper :: getParams( 'com_belong' );
		
		if ( empty( $creds ) ) {
			$apiurl	= $params->get( 'ApiUrl' );
			$apius	= $params->get( "ApiUsername" );
			$apipw	= $params->get( "ApiPassword" );
			$apikey	= $params->get( 'ApiAccesskey' );
			
		}
		else {
			$apiurl	= $creds['ApiUrl'];
			$apius	= $creds['ApiUsername'];
			$apipw	= $creds['ApiPassword'];
			$apikey	= $creds['ApiAccesskey'];
		}
		
		if ( empty( $apiurl ) ) return;
		
		$this->apiurl = trim( $apiurl );
		
		// Default POST VARIABLES
		$post		= array	(	"username" => $apius,
								"password" => md5( $apipw ),
								'responsetype'	=> 'json'
		);
		
		if (! empty( $apikey ) ) {
			$post['accesskey']	= $apikey;
		}
		
		$this->apipost	= $post;
		
		// Default CURL OPTIONS
		$options	= array(	'POST'				=> true,
								'TIMEOUT'			=> 30,
								'RETURNTRANSFER'	=> true,
								'POSTFIELDS'		=> array(),
								'FOLLOWLOCATION'	=> false,
								'HEADER'			=> true,
								'HTTPHEADER'		=> array( 'Expect:' ),
								'MAXREDIRS'			=> 5,
								'SSL_VERIFYHOST'	=> false,
								'SSL_VERIFYPEER'	=> false
		);
		$this->apioptions = $options;
		$this->params	= $params;
		$this->enabled	= true;
	}
	
	
	/**
	 * Getter method
	 * @access		public
	 * @version		1.0.4
	 * @param		string		- $name: the name of the property trying to be gotten
	 * 
	 * @return		mixed value of property or null if not set
	 * @since		1.0.0 
	 */
	public function __get( $name )
	{
		return ( isset( $this->data[$name] ) ? $this->data[$name] : null );
	}
	
	
	/**
	 * Setter method
	 * @access		public
	 * @version		1.0.4
	 * @param		string		- $name: the name of the property to set
	 * @param		mixed		- $value: the value to set the property to
	 * 
	 * @since		1.0.0
	 */
	public function __set( $name, $value )
	{
		$this->data[$name] = $value;
	}
	
	
	/**
	 * Calls up the debug screen from the API
	 * @access		public
	 * @version		1.0.4
	 * 
	 * @since		1.0.0
	 */
	public function debug()
	{
		echo $this->curl->debug();
	}
	
	
	/**
	 * Grabs a singleton instance of this object
	 * @access		public
	 * @version		1.0.4
	 * @param		boolean		- $force: if true creates a new object
	 * 
	 * @return		object of BelongApi class
	 * @since		1.0.0
	 */
	public function getInstance( $options = array() )
	{
		static $instance;
		
		$force = ( isset( $options['force'] ) ? $options['force'] : false );
		
		if ( (! is_object( $instance ) ) || ( $force === true ) ) {
			$instance = new self( $options );
		}
		
		return $instance;
	}
	
	
	/**
	 * Gets product addons from WHMCS
	 * @access		public
	 * @version		1.0.4
	 * @param		array		- $post: place holder
	 * 
	 * @return		array result of call
	 * @since		1.0.0
	 */
	public function get_product_addons( $post = array() )
	{
		$post['action']	= 'belong';
		$post['task']	= 'getproductaddons';
		
		return $this->_call_api( $post );
	}
	
	
	/**
	 * Gets remote settings from WHMCS
	 * @access		public
	 * @version		1.0.4
	 * 
	 * @return		array result of call
	 * @since		1.0.0
	 */
	public function get_remote_settings()
	{
		$post['action']	= 'belong';
		$post['task']	= 'info';
		
		return $this->_call_api( $post );
	}
	
	
	/**
	 * Gets a specific user from WHMCS
	 * @access		public
	 * @version		1.0.4
	 * @param		array		- $post: contains an email or clientid to fetch from
	 * 
	 * @return		array result of call
	 * @since		1.0.0
	 */
	public function get_user( $post = array() )
	{
		$post['action']	= 'getclientsdetails';
		
		return $this->_call_api( $post );
	}
	
	
	/**
	 * Gets all the users from WHMCS
	 * @access		public
	 * @version		1.0.4
	 * 
	 * @return		array result of call
	 * @since		1.0.0
	 */
	public function get_users()
	{
		$post['action']	= 'belong';
		$post['task']	= 'getusers';
		
		return $this->_call_api( $post );
	}
	
	
	/**
	 * Gets a users products from WHMCS
	 * @access		public
	 * @version		1.0.4
	 * @param		array		- $post: contains a clientid to fetch products for
	 * 
	 * @return		array result of call
	 * @since		1.0.0
	 */
	public function get_user_products( $post = array() )
	{
		$post['action']	= 'belong';
		$post['task']	= 'getuserproducts';
		
		return $this->_call_api($post);
	}
	
	
	/**
	 * Gets available products from WHMCS
	 * @access		public
	 * @version		1.0.4
	 * @param		array		- $post: place holder
	 * 
	 * @return		array result of call
	 * @since		1.0.0
	 */
	public function get_products( $post = array() )
	{
		$post['action']	= 'belong';
		$post['task']	= 'getproductlist';
		$post['hidden']	= ( $this->params->get( 'DisplayHidden', '0' ) );
		
		return $this->_call_api( $post );
	}
	
	
	/**
	 * Pings the Belong with the configuration settings provided to test connection
	 * @access		public
	 * @version		1.0.4
	 * @param		array		- $post: place holder
	 * 
	 * @return		boolean true or string response error
	 * @since		1.0.0
	 */
	public function ping( $post = array() )
	{
		$post['action']	= 'getadmindetails';
		
		return $this->_call_api( $post );
	}
	
	
	/**
	 * Wrapper for calling up the API interface
	 * @access		private
	 * @version		1.0.4
	 * @param		string		- $url: the url to connect to
	 * @param		array		- $post: any additional post variables to send
	 * @param 		array		- $options: any options to set
	 * 
	 * @return		json_decoded response
	 * @since		1.0.0
	 */
	private function _call_api( $post = array(), $options = array() )
	{
		if (! $this->enabled ) return false;
		
		$post		= array_merge( $this->apipost, $post );
		$options	= array_merge( $this->apioptions, $options );
		
		$this->curl = new BelongCurl( $this->apiurl );
		$this->curl->post( $post, $options );
		$result		= $this->curl->execute();
		
		if ( $result === false ) {
			// error trapping for debug purposes
			return array( 'result' => 'error', 'data' => $this->curl->has_errors() );
		}
		
		if ( $options['HEADER'] == TRUE ) {
			list( $header, $response ) = explode( "\r\n\r\n", $result, 2 );
		}
		else {
			$response = $result;
		}
		
		$return	= json_decode( $response, true );
		
		if (! isset( $return['result'] ) ) {
			return $response;
		}
		else {
			return $return;
		}
	}
}