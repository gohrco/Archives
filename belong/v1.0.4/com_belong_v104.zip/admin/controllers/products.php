<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.4 ( $Id: products.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the products controller file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.controlleradmin');
/*-- File Inclusions --*/

/**
 * Belong Products Controller
 * @author		Steven
 * @version		1.0.4
 * 
 * @since		1.0.0
 */
class BelongControllerProducts extends JControllerAdmin
{
	/**
	 * Retrieves the model for the controller
	 * @access		public
	 * @version		1.0.4
	 * @param		string		- $name: default to Product
	 * @param		string		- $prefix: default prefix to BelongModel
	 * 
	 * @return		BelongModelProduct model
	 * @since		1.0.0
	 */
	public function getModel( $name = 'Product', $prefix = 'BelongModel') 
	{
		$model = parent::getModel( $name, $prefix, array( 'ignore_request' => true ) );
		return $model;
	}
}