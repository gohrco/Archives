<?php
/**
* Belong
*
* @package    Belong
* @copyright  2012 Go Higher Information Services.  All rights reserved.
* @license    GNU General Public License version 2, or later
* @version    1.0.4 ( $Id$ )
* @author     Go Higher Information Services
* @since      1.0.4
*
* @desc       This file is a quick utility helper for Belong
*
*/

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
require_once( dirname(__FILE__) . DS . 'helper.php' );
