<?php
/**
 * Belong
 * User - Integrator Plugin
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.4 ( $Id: integrator_user.php 399 2012-02-27 04:35:22Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      3.0.0
 * 
 * @desc       This is the file executed by the User - Integrator plugin for handling calls to the Integrator and redirecting upon log in and out
 * 
 */


/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.router' );
jimport( 'joomla.environment.uri' );
jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.application.component.helper' );

if ( $path = JApplicationHelper :: getPath( 'helper', 'com_belong' ) ) {
	require_once( $path );
}
/*-- File Inclusions --*/

/**
 * User - Integrator plugin
 * @version		1.0.4
 * 
 * @since		3.0.0
 * @author		Steven
 */
class plgUserBelong extends JPlugin
{
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.0.4
	 * @param		unknown_type $subject
	 * @param		unknown_type $config
	 * 
	 * @since		3.0.0
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		$this->params->merge( JComponentHelper::getParams( "com_belong" ) );
		
		$this->loadLanguage();
		
	}
	
	
	/**
	 * Handles a change to user information by calling API (or reverting info if validation failed)
	 * @access		public
	 * @version		1.0.4
	 * @param		array		- $user: current user
	 * @param		boolean		- $isnew: true if new user
	 * @param		unknown		- $success: does nothing in J1.5
	 * @param		string?		- $msg: current errors
	 * 
	 * @since		3.0.0
	 */
	public function onUserAfterSave($user, $isnew, $succes, $msg)
	{
		$app	= & JFactory::getApplication();
		
		// We shouldn't run this if we are the administrator
		if ($app->isAdmin() ) {
			if (! $this->params->get( 'RunAtSaveAdmin' ) ) return;
		}
		else {
			if (! $this->params->get( 'RunAtSaveClient' ) ) return;
		}
		
		BelongHelper :: runRulesets( $user['email'], 'whmcs', false );
		
		return true;
	}
	
	
	/**
	 * Redirects user to the Integrator to complete log in
	 * @access		public
	 * @version		1.0.4
	 * @param		JUser object	- $user: current user
	 * @param		array			- $options: option array passed
	 * 
	 * @since		3.0.0
	 */
	public function onUserLogin($user, $options)
	{
		$app	= & JFactory::getApplication();
		
		// We shouldn't run this if we are the administrator
		if ($app->isAdmin()) return;
		
		// Don't run if we are set not to
		if(! $this->params->get( 'RunOnLogin' ) ) return;
		
		if ( $options['belong'] === true ) return;
		
		BelongHelper :: runRulesets( $user['email'], 'whmcs', false );
		
		return true;
	}
	
	
	
}