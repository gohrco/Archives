Belong by Go Higher Information Services
------------------------------------------------------------------------

 Release Version: 1.0.6
    Release Date: 2012 March 31

 PLEASE READ ALL THE ENCLOSED INSTRUCTIONS

        Forums: https://forum.gohigheris.com
       Support: https://support.gohigheris.com
 Documentation: https://www.gohigheris.com/documentation
   Client Area: https://client.gohigheris.com


[ CONTENTS ] 
------------------------------------------------------------------------

1. Server Requirements
2. Version 1.0.6 Release Notes
3. What's Included and What to do First
4. New Installation Instructions
5. Upgrade Instructions


[ SERVER REQUIREMENTS ]
------------------------------------------------------------------------

1. Joomla 2.5 or above
2. WHMComplete Solution (WHMCS) version 4.52 or above
3. PHP Version 5.x or later
4. MySQL Version 5.x or later
5. Curl Support (with SSL)


[ VERSION 1.0.6 RELEASE NOTES ]
------------------------------------------------------------------------

To review the details and notes for Belong version 1.0.6 release,
please visit our web site at:

https://www.gohigheris.com/


[ WHAT'S INCLUDED AND WHAT TO DO FIRST ]
------------------------------------------------------------------------

In this archive are the following files:
1. This README.txt file
2. A copy of the GPL v2 license
3. The Joomla component (indicated with 'joomla' within the filename)
4. The WHMCS addon module (indicated with the 'whmcs' within the filename)

Be sure that you extract this main archive into a folder on your local
machine.  For references in installation, this local folder will be referred
to as 'belong_local'

* EXTRACT THE WHMCS ADDON MODULE INTO A FOLDER CALLED 'whmcs' *

There is no need to extract the Joomla component locally, as this will be
installed in the manner typical of Joomla components.
 

[ NEW INSTALLATION INSTRUCTIONS ]
------------------------------------------------------------------------

The following instructions presume you have followed the instructions in the
section above entitles 'What's Included and What to do First'.  Please follow
these instructions in order - failure to do so may cause unwanted results.

For Joomla:
-----------
1.  Log into the backend of your Joomla site.
2.  Go to 'Extensions' > 'Extension Manager'.
3.  On the 'Install' area, click 'Browse' and locate the Joomla archive you
extracted into the 'belong_local' folder above.
4.  Click 'Upload & Install'.
5.  On the top menu bar, click on 'Users' > hover over 'Groups' > 'Add New Group'.
6.  Use the following settings for this new user group:
        Group Title:  'Belong API Access Group'
        Group Parent: 'Registered'
7.  Click 'Save & Close'.
8.  Again on the top menu bar, click on 'Users' > hover over 'Users' > 'Add New User'.
9.  Use the following settings for this new user group:
        Name:  Belong API User
        Login Name:  belongapi (you can set this to anything you like - just remember it)
        Password:  <you set> 
        Confirm Password: <you set>
        Email:  <you set>
        Assigned Groups:  'Belong API Access Group' ONLY - DO NOT GIVE IT MORE THAN THIS
10. Click 'Save & Close'.
11. On the top menu bar, click on 'Components' > 'Belong'
12. First things first, let's go to the 'Options' on the top right.
13. Click on 'API Access' tab.
14. Select the group 'Belong API Access Group' and change 'API Permissions' to 'Allowed'
15. Click 'Save & Close'

Now proceed to WHMCS:

For WHMCS:
----------
16. Using FTP, log into your web site containing WHMCS.
17. Upload the folders from the WHMCS archive that you extracted above up to
your root WHMCS folder.
18. Log into your administrative control panel for WHMCS (http://yoursite/admin)
19. Go to 'Settings' > 'Addon Modules'
20. Find the 'Belong' addon module and click 'Activate'
21. When the page reloads, change the settings to the following:
        Globally Enabled:  'No' (for now)
        Joomla URL:  Enter the URL to your Joomla web site
        Joomla API Username:  Enter the username for the 'Belong API User' you setup above
        Joomla API Password:  Enter the password for the 'Belong API User'
        Access Control:  Full Admin at least ... this is used by WHMCS for ACL purposes
22. Go to the bottom of the page and click 'Save Changes'.
23. Go to 'Addons' > 'Belong' (you may need to hit 'Save Changes' again for this to appear).
24. If your settings are correct, you should see a message indicating that a connection was
made successfully and that your API credentials are validated.  If so continue, if not
you will need to double check your settings you entered in #21 above.
25. Go to 'Settings' > 'Administrator Roles'.  If you already have an API role group setup,
you can proceed to #26.
    a. Click on 'Add New Role Group'.
    b. Call the new role group 'API Administrators' and click 'Continue'
    c. Select ONLY API Access at the bottom right of the permissions screen and click
	   'Save Changes'
26. Go to 'Settings' > 'Administrators'.  If you already have an API administrator setup,
you can proceed to #27 below.
    a. Click on 'Add New Administrator'.
    b. Enter the following for the settings:
        Administrator Role:  Select 'API Administrators'.
        First Name:  API
        Last Name:  Admin (Belong)
        Email Address:  apiadmin@yourdomain.com (or anything really)
        Username:  apiadmin
        Password:  <you set>
        Confirm:  <you set>
    c. Click 'Save Changes'.

Now go BACK to Joomla:

Joomla API Configuration:
-------------------------
27. Log back into Joomla backend.
28. On the top menu bar, click on 'Components' > 'Belong'
29. Click on the 'API Connection' button and enter the following information:
        a. WHMCS URL:  Enter the URL to your WHMCS application.  DO NOT include a filename
           or the subdirectories to the api, Belong will add those for you.
        b. API Username: Enter the username you setup in #26b above.
        c. API Password: Enter the password you setup in #26b above.
        d. API Access Key:  If you are using a mobile device from WHMCS, you may need to
           enter the API Access Key you have setup in your Configuration File.
    If it goes well, it should give you a green check mark with a 'Successfully Connected'
    message.  If not, correct the information until you get the green check mark and click
    'Save & Close' on the top right.
30. If you are successful, you will see an API message indicating such as well as an indication
    of the connectivity to the custom belong api calls on the WHMCS side.
    
You should now be all set to create rules and products.  For more information on configuration
settings and ruleset applications, visit our web site at https://www.gohigheris.com 


[ UPGRADE INSTRUCTIONS ]
------------------------------------------------------------------------

Upgrading Belong is a relatively painfree process:

For Joomla:
-----------
1.  Log into the backend of your Joomla site.
2.  Go to 'Extensions' > 'Extension Manager'.
3.  On the 'Install' area, click 'Browse' and locate the Joomla archive you
extracted into the 'belong_local' folder above (in 'Whats Included step).
4.  Click 'Upload & Install'.  Your Joomla component should now be upgraded.

For WHMCS:
----------
5.  Using FTP, log into your web site containing WHMCS.
6.  Upload the folders from the WHMCS archive that you extracted above up to
your root WHMCS folder.  Your WHMCS addon module should now be upgraded.

For more information on configuration settings and ruleset applications,
visit our web site at https://www.gohigheris.com 