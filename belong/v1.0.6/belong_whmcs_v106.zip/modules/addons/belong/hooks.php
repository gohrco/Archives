<?php
/**
 * Belong
 * WHMCS - Hook File
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.6 ( $Id: hooks.php 39 2012-03-06 16:39:06Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This file included in the hooks execution and calls appropriate functions for actions
 * 
 */

/*-- Security Protocols --*/
if (!defined("WHMCS")) die("This file cannot be accessed directly");
/*-- Security Protocols --*/

/*-- File Inclusions --*/
require_once( "factory.php" );
/*-- File Inclusions --*/

$B_hook = BFactory::getHook();
$B_log	= & BFactory::getLog();
BHook::addHooks();


/**
 * Runs rulesets at cron job
 * @version		1.0.6
 * @param		array		- $vars: any variables passed along
 * 
 * @since		1.0.0
 */
function belong_cron( $vars )
{
	global $B_hook, $B_log;
	
	$B_log->set( 'action', 'Cronjob' );
	$B_hook->cron();
	$B_log->write();
}


/**
 * Runs rulesets against when saving a product
 * @version		1.0.6
 * @version		1.0.4		- Added logging of hook point
 * @param		array		- $vars: any variables passed along
 * 
 * @since		1.0.0
 */
function belong_grab_globals( $vars )
{
	global $B_hook, $B_log;
	$vars['request'] = $GLOBALS['_REQUEST'];
	
	$B_log->set( 'action', 'AdminServiceEdit' );
	$B_hook->belong( $vars );
	$B_log->write();
}


/**
 * Runs rulesets against a user
 * @version		1.0.6
 * @version		1.0.4		- Added logging of hook point
 * @param		array		- $vars: any variables passed along
 * @param		string		- $action: contains the hook point where action performed
 * 
 * @since		1.0.0
 */
function belong_rulesets( $vars, $action ) {
	global $B_hook, $B_log;
	
	$B_log->set( 'action', $action );
	$result	= $B_hook->belong( $vars );
	$B_log->write();
}


function belong_rulesets_amc( $vars ) { belong_rulesets( $vars, 'AfterModuleCreate' ); }
function belong_rulesets_ams( $vars ) { belong_rulesets( $vars, 'AfterModuleSuspend' ); }
function belong_rulesets_amu( $vars ) { belong_rulesets( $vars, 'AfterModuleUnsuspend' ); }
function belong_rulesets_amt( $vars ) { belong_rulesets( $vars, 'AfterModuleTerminate' ); }
function belong_rulesets_amr( $vars ) { belong_rulesets( $vars, 'AfterModuleRenew' ); }
function belong_rulesets_aa( $vars )  { belong_rulesets( $vars, 'AddonActivation' ); }
function belong_rulesets_apu( $vars ) { belong_rulesets( $vars, 'AfterProductUpgrade' ); }

?>