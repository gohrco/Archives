<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.6 ( $Id: belong.php 21 2011-10-15 02:21:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the main file for Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die('Restricted access');

// Require the base controller
require_once (JPATH_COMPONENT.DS.'controller.php');
require_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'class.api.php' );
require_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'helper.php' );

// Require specific controller if requested
$controller = JRequest::getWord('controller', 'api');
require_once (JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php');

// Create the controller
$classname	= 'BelongController'.$controller;
$controller = new $classname();

// Perform the Request task
$controller->execute( JRequest::getWord('task'));

// Redirect if set by the controller
$controller->redirect();