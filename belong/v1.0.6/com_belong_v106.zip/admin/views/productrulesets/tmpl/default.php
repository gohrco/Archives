<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.6 ( $Id: default.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the default layout for the productrulesets view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusion --*/
JHtml::_('behavior.tooltip');
/*-- File Inclusion --*/

?>

<form action="<?php echo JRoute::_('index.php?option=com_belong'); ?>" method="post" name="adminForm">
	<table class="adminlist">
		
		<!-- BEGIN BODY -->
		
		<tbody>
		
		<?php foreach($this->items as $i => $item): ?>
			<?php $link = JRoute::_( 'index.php?option=com_belong&task=productruleset.edit&id=' . $item->id ); ?>
			<tr class="row<?php echo $i % 2; ?>">
				<td>
					<?php echo $item->id; ?>
				</td>
				<td>
					<?php echo JHtml::_('grid.id', $i, $item->id); ?>
				</td>
				<td>
					Ruleset:  <em>apply</em> <a href="<?php echo $link; ?>"><strong><?php echo $item->product_name; ?></strong></a> <em>against</em> <a href="<?php echo $link; ?>"><strong><?php echo $item->rule_name; ?></strong></a> <em>rule</em>
				</td>
				<td class="center">
					<?php echo JHtml::_('jgrid.published', $item->published, $i, 'productrulesets.', true ); ?>
				</td>
				<td class="order">
					<span><?php echo $this->pagination->orderUpIcon($i, true, 'productrulesets.orderup', 'JLIB_HTML_MOVE_UP', true ); ?></span>
					<span><?php echo $this->pagination->orderDownIcon($i, $this->pagination->total, true, 'productrulesets.orderdown', 'JLIB_HTML_MOVE_DOWN', true ); ?></span>
					
					<input type="text" name="order[]" size="5" value="<?php echo $item->priority;?>" class="text-area-order" />
					
				</td>
			</tr>
		<?php endforeach; ?>
		
		</tbody>
		
		<!-- END BODY -->
		<!-- BEGIN HEADER -->
		
		<thead>
			
			<tr>
				<th width="5">
					<?php echo JText::_('COM_BELONG_PRODUCTRULESET_HEADING_ID'); ?>
				</th>
				<th width="20">
					<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" />
				</th>			
				<th>
					<?php echo JText::_('COM_BELONG_PRODUCTRULESET_HEADING'); ?>
				</th>
				<th width="5%">
					<?php echo JText::_( 'JSTATUS' ); ?>
				</th>
				<th width="10%">
					<?php echo JText::_( 'COM_BELONG_PRODUCTRULESET_HEADING_PRIORITY' ); ?>
					<?php echo JHtml::_('grid.order',  $this->items, 'filesave.png', 'productrulesets.saveorder'); ?>
				</th>
				
			</tr>
			
		</thead>
		
		<!-- END HEADER -->
		<!-- BEGIN FOOTER -->
		
		<tfoot>
			
			<tr>
				<td colspan="5"><?php echo $this->pagination->getListFooter(); ?></td>
			</tr>
			
		</tfoot>
		
		<!-- END FOOTER -->
		
	</table>
	<div>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<?php echo JHtml::_( 'form.token' ); ?>
	</div>
</form>