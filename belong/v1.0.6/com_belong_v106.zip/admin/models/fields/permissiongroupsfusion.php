<?php
/**
* Belong
*
* @package    Belong
* @copyright  2012 Go Higher Information Services.  All rights reserved.
* @license    GNU General Public License version 2, or later
* @version    1.0.6 ( $Id: permissiongroupsfusion.php 44 2012-03-08 22:05:12Z steven_gohigher $ )
* @author     Go Higher Information Services
* @since      1.0.5
*
* @desc       This file is a utility helper for Belong
*
*/

/*-- Security Protocols --*/
defined('JPATH_PLATFORM') or die;

/*-- Localscope import --*/
jimport('joomla.html.html');
jimport('joomla.form.formfield');
jimport('joomla.event.dispatcher');


/**
 * JFormFieldPermissionGroupsfusion is used to retrieve only the fusion permission groups from Belong
 * @version 1.0.6
 * 
 * @since	1.0.5
 * @author	Steven
 */
class JFormFieldPermissiongroupsfusion extends JFormField
{
	/**
	 * Name of this field type
	 * @access		protected
	 * @since		1.0.5
	 * @var			string
	 */
	protected $type = 'Permissiongroupsfusion';
	
	
	/**
	 * Gets the input for the form
	 * @access		protected
	 * @version		1.0.6
	 * 
	 * @return		string containing HTML form
	 * @since		1.0.5
	 */
	protected function getInput()
	{
		// Initialize variables.
		$data		= array();
		
		// Get all the other extended groups
		JPluginHelper :: importPlugin( 'belong', 'fusion' );
		
		$more = array();
		$dispatcher		= & JDispatcher :: getInstance();
		$more			=   $dispatcher->trigger( 'onGetPermissionGroups', $more );
		
		if ( empty( $more ) || @empty( $more[0] ) ) {
			return '<input type="text" size="100" value="' . JText::_( 'PLG_BELONG_FUSION_GROUPS_INACTIVE' ) . '" disabled="disabled" style="border: 0px; " />';
		}
		
		$data	= $more[0]['items'];
		
		//return 
		return JHtml::_('select.genericlist', $data, $this->name, array( 'list.attr' => $attr, 'list.select' => $this->value ) );
	}
}