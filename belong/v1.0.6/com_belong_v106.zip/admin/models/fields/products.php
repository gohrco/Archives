<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.6 ( $Id: products.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the Products list form field file for the forms used in Belong
 *  
 */

/*-- Security Protocols --*/
defined('JPATH_BASE') or die;
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.html.html' );
jimport( 'joomla.form.formfield' );
jimport( 'joomla.form.helper' );
JFormHelper :: loadFieldClass( 'list' );
/*-- File Inclusions --*/

/**
 * Products form field
 * @author		Steven
 * @version		1.0.6
 * 
 * @since		1.0.0
 */
class JFormFieldProducts extends JFormFieldList
{
	/**
	 * Stores the type of object this is for reference
	 * @access		protected
	 * @since		1.0.0
	 * @var			string
	 */
	protected $type = 'Products';
	
	
	/**
	 * Retrieves the options to fill in for a dropdown field when called
	 * @access		protected
	 * @version		1.0.6
	 * 
	 * @return		array of option objects
	 * @since		1.0.0
	 */
	protected function getOptions()
	{
		$db	= & JFactory::getDbo();
		
		$query	= "SELECT `id` as 'value', `name` as 'text' FROM #__belong_products ORDER BY `name`";
		$db->setQuery( $query );
		$options	= $db->loadObjectList();
		
		if ( $this->value == 0 ) {
			$blank	= array( 'value' => '0', 'text' => '-- Select a Product --' );
			array_unshift( $options, (object) $blank );
		}
		
		return $options;
	}
}
