<?php


//
//	General Alert Values
//	------------------------------------------------------------------------
$lang['alert.success']				= 'Success!';
$lang['alert.error']				= 'An Error Occurred!';
$lang['alert.info']					= 'Reminder:';
$lang['alert.block']				= 'Warning!';

// v2.1.0
$lang['alert.dunamis.compatible']	=	'The version of Dunamis you are using is not compatible with this version of Belong.  Please upgrade Dunamis before proceeding.';

//
//	Alert Messages
//	------------------------------------------------------------------------
//		Licensing
$lang['alert.license.invalid']		= 'Your license is invalid!  Please check your license key before continuing.';
$lang['alert.license.saved']		= 'License successfully saved.';

//		Plugins
$lang['alert.plugins.deleted']		= 'Plugin successfully deleted.';
$lang['alert.plugins.saved']		= 'Plugin successfully saved.';
$lang['alert.plugins.save.notype']	= 'No plugin type was specified.';
$lang['alert.plugins.activated']	= 'Plugin successfully activated!';
$lang['alert.plugins.deactivated']	= 'Plugin has been deactivated.';

//		Configure
$lang['alert.configure.saved']		= 'Configuration settings have been saved to the database.';

//		Products
$lang['alert.products.deleted']		= 'Product successfully deleted.';
$lang['alert.products.saved']		= 'Product successfully saved.';

//		Rules
$lang['alert.rules.deleted']		= 'Rule succesfully deleted.';
$lang['alert.rules.saved']			= 'Rule succesfully saved.';

//		Rulesets
$lang['alert.rulesets.deleted']		= 'Ruleset succesfully deleted.';
$lang['alert.rulesets.saved']		= 'Ruleset succesfully saved.';

//
//	General Form Field Values
//	------------------------------------------------------------------------
$lang['form.submit']				= 'Submit';
$lang['form.close']					= 'Close';
$lang['form.cancel']				= 'Cancel';
$lang['form.edit']					= 'Edit';
$lang['form.delete']				= 'Delete';
$lang['form.toggleyn.enabled']		= 'Enabled';
$lang['form.toggleyn.disabled']		= 'Disabled';
$lang['form.button.addnew']			= 'Add New';

//
//	Admin Configuration Values
//		WHMCS > Setup > Addon Modules
//	------------------------------------------------------------------------
$lang['addon.title']		= 'Belong';
$lang['addon.author']		= '<div style="text-align: center; width: 100%; ">Go Higher<br/>Information Services, LLC</div>';
$lang['addon.description']	= 'This module permits you to create rules and rulesets for product activations and purchases and have other applications updated automatically.';


//
//	Admin Output - General Items
//		WHMCS > Addons > Belong
//	------------------------------------------------------------------------
$lang['admin.title']						= 'Belong %s';
$lang['admin.title.default']				= 
$lang['admin.title.default.default']		= '<small>Dashboard</small>';
$lang['admin.title.default.update']			= '<small>Update %s</small>';
$lang['admin.title.license']				= 
$lang['admin.title.license.default']		= '<small>Licensing</small>';
$lang['admin.title.license.save']			= '<small>Licensing :: Save License</small>';
$lang['admin.title.configure']				=
$lang['admin.title.configure.default']		= '<small>Configure</small>';
$lang['admin.title.configure.save']			= '<small>Configure :: Save Settings</small>';
$lang['admin.title.plugins']				=
$lang['admin.title.plugins.delete']			=
$lang['admin.title.plugins.default']		= '<small>Plugins</small>';
$lang['admin.title.plugins.addnew']			= '<small>Plugins :: Add New Plugin</small>';
$lang['admin.title.plugins.save']			= '<small>Plugins :: Save Plugin</small>';
$lang['admin.title.plugins.edit']			= '<small>Plugins :: Edit Plugin</small>';
$lang['admin.title.plugins.confirmdelete']	= '<small>Plugins :: Confirm Delete</small>';
$lang['admin.title.products']				= 
$lang['admin.title.products.delete']		= 
$lang['admin.title.products.default']		= '<small>Products</small>';
$lang['admin.title.products.addnew']		= '<small>Products :: Add New Product</small>';
$lang['admin.title.products.save']			= '<small>Products :: Save Product</small>';
$lang['admin.title.products.edit']			= '<small>Products :: Edit Product</small>';
$lang['admin.title.products.confirmdelete']	= '<small>Products :: Confirm Delete</small>';
$lang['admin.title.rules']					=
$lang['admin.title.rules.delete']			=
$lang['admin.title.rules.default']			= '<small>Rules</small>';
$lang['admin.title.rules.addnew']			= '<small>Rules :: Add New Rule</small>';
$lang['admin.title.rules.save']				= '<small>Rules :: Save Rule</small>';
$lang['admin.title.rules.edit']				= '<small>Rules :: Edit Rule</small>';
$lang['admin.title.rulesets']				=
$lang['admin.title.rulesets.delete']		=
$lang['admin.title.rulesets.default']		= '<small>Rulesets</small>';
$lang['admin.title.rulesets.addnew']		= '<small>Rulesets :: Add New Ruleset</small>';
$lang['admin.title.rulesets.save']			= '<small>Rulesets :: Save Ruleset</small>';
$lang['admin.title.rulesets.edit']			= '<small>Rulesets :: Edit Ruleset</small>';
$lang['admin.title.help']					=
$lang['admin.title.help.default']			= '<small>Help</small>';
$lang['admin.title.updates.default']		=	'<small>Update Manager</small>';

// Navigation Bar
$lang['admin.navbar.default']	= 'Dashboard';
$lang['admin.navbar.rulesets']	= 'Rulesets';
$lang['admin.navbar.rules']		= 'Rules';
$lang['admin.navbar.products']	= 'Products';
$lang['admin.navbar.plugins']	= 'Plugins';
$lang['admin.navbar.configure']	= 'Configure';
$lang['admin.navbar.updates']	= 'Updates';
$lang['admin.navbar.license']	= 'License';
$lang['admin.navbar.help']		= 'Help';
$lang['admin.navbar.onscreen']	= 'Onscreen Help';

//
//	Admin Output - Configuration Items
//		WHMCS > Addons > Belong > Configure
//	------------------------------------------------------------------------
$lang['admin.form.config.label.enable']			= 'Enable';
$lang['admin.form.config.label.apiuser']		= 'API User';
$lang['admin.form.config.label.showhidden']		= 'Show Hidden Products';
$lang['admin.form.config.label.dlid']			= 'Download ID';

$lang['admin.form.config.description.enable']		= 'This field actually enabled or disables the product globally.';
$lang['admin.form.config.description.apiuser']		= 'This field allows you to select which admin user to make system level calls to your local WHMCS.  This permits you to audit the system.';
$lang['admin.form.config.description.showhidden']	=	'This permits you to display products that you have set as hidden in WHMCS.  This is useful to enable if you have products inaccessible to your clients.  If once hidden you dont want to see them again, you can simply tick this and the product will not display in the product dropdown selection.';
$lang['admin.form.config.description.dlid']			=	'This is the Download ID available from our web site.  Simply retrieve it and enter it here for the update feature to work.  You must have an active Belong license to be able to download updates.';


//
//	Admin Output - Licensing Items
//		WHMCS > Addons > Belong > License
//	------------------------------------------------------------------------
$lang['admin.form.config.label.license']		= 'License';
$lang['admin.form.config.label.info']			= 'Licensed To';
$lang['admin.form.config.label.status']			= 'Status';

$lang['admin.form.config.description.license']	= 'Enter the license you received upon purchasing J!WHMCS Integrator from <a href="https://www.gohigheris.com/" target="_blank">Go Higher Information Services</a>.';
$lang['admin.form.config.description.status']	= 'This is the status of your Support and Upgrade pack.';

$lang['admin.form.config.info.registeredname']	= '<h4>%s</h4>';
$lang['admin.form.config.info.companyname']		= '<h6>%s</h6>';
$lang['admin.form.config.info.regdate']			= '<div><em>Registered on</em> <strong>%s</strong></div>';
$lang['admin.form.config.info.supnextdue']		= '<div class="alert alert-%s" style="margin-top: 12px; "><em>Support and Upgrade next due on</em> <strong>%s</strong></div>';
$lang['admin.form.config.info.invalidkey']		= '<div class="alert alert-error">The license you entered above is invalid.  Please double check the license and try again.</div>';
$lang['admin.form.config.info.invalidmsg']		= '<div class="alert alert-error">The license above came back with an error message: %s</div>';


$lang['hook.adminareaclientsummarypage.updatebutton']	= 'Update Permissions';


//	========================================================================
//	Admin Output - Page Specific
//	========================================================================
//	------------------------------------------------------------------------
//	Plugins Page
//		WHMCS > Addons > Belong > Plugins
//		as of 2.0.0
//	------------------------------------------------------------------------
// List
$lang['admin.list.plugins.hdr.id']				=	'ID';
$lang['admin.list.plugins.hdr.name']			=	'Name';
$lang['admin.list.plugins.hdr.type']			=	'Plugin Type';
$lang['admin.list.plugins.hdr.active']			=	'Active';
$lang['admin.list.plugins.hdr.actions']			=	'Actions';
$lang['admin.list.plugins.active.success']		=	'Active';
$lang['admin.list.plugins.active.important']	=	'Disabled';
// Edit
$lang['admin.plugin.form.label.name']			= 'Connection Name';
$lang['admin.plugin.form.description.name']		= 'Enter a name to easily identify this connection when selecting in a drop down list.';

$lang['admin.plugin.form.label.enable']			= 'Connection Enabled';
$lang['admin.plugin.form.description.enable']	= 'Indicate if this connection should be active or not';

$lang['admin.plugin.delete.dialog']				= '<p>Are you certain you wish to delete `%s` from the database?  Any rules relying on this plugin will also be deleted!</p>';

// Connection Specific fields
// ------------------------------------------------------------------------
// WHMCS
$lang['admin.plugin.form.whmcs.label.user']			= 'Admin User';
$lang['admin.plugin.form.whmcs.description.user']	= 'Select the admin user to be used to indicate who is making updates to clients.  This option would permit you to track changes made by the selected admin user.';

// Mailchimp
$lang['admin.plugin.form.mailchimp.label.apikey']	= 'API Key';
$lang['admin.plugin.form.mailchimp.description.apikey']	= 'This is the api key from your account which can be found at http://admin.mailchimp.com/account/api/';
$lang['admin.plugin.form.mailchimp.label.usessl']	= 'Use SSL';
$lang['admin.plugin.form.mailchimp.description.usessl']	= 'Do you want to use SSL across the API to Mailchimp (why not, right?)';

// Fusion
$lang['admin.plugin.form.fusion.label.apiurl']				= 'API URL';
$lang['admin.plugin.form.fusion.description.apiurl']		=	'Enter the URL to your API interface with Kayako Fusion. This can be found in the admin settings under API.';
$lang['admin.plugin.form.fusion.label.apikey']				=	'API Key';
$lang['admin.plugin.form.fusion.description.apikey']		=	'Enter the API Key from your Kayako Fusion installation.  This can be found in the admin settings under API.';
$lang['admin.plugin.form.fusion.label.apisecret']			=	'API Secret';
$lang['admin.plugin.form.fusion.description.apisecret']		=	'Enter the API Secret from your Kayako Fusion installation.  This can be found in the admin settings under API (note - this value is really long).';
$lang['admin.plugin.form.fusion.label.defaultgroup']		=	'Default Group';
$lang['admin.plugin.form.fusion.description.defaultgroup']	=	'Select the default group to use in your rules.  The default group is necessary because when a user is dropped from a higher group, they must be added back to the default group or Fusion will not work properly.';

// Joomla
$lang['admin.plugin.form.joomla.label.url']		=	'Joomla URL';
$lang['admin.plugin.form.joomla.desc.url']		=	'Enter the URL to the front end of your site.  Do not include any filenames or language sef that may be added to your URL by Joomla.  Ensure that you also include the proper scheme (http / https).';
$lang['admin.plugin.form.joomla.label.token']	=	'API Token';
$lang['admin.plugin.form.joomla.desc.token']	=	'Enter the unique token you created in the System - Belong plugin that you installed into Joomla.  This token must match exactly.';

// vBulletin
$lang['admin.plugin.form.vbulletin.label.path']	=	'Path to vBulletin';
$lang['admin.plugin.form.vbulletin.desc.path']	=	'This plugin requires the physical path to your vBulletin installation on the server (it must be located on the same server as this instance of WHMCS).  Please enter it here.';
$lang['admin.plugin.form.vbulletin.label.dbhost']	=	'Database Hostname';
$lang['admin.plugin.form.vbulletin.desc.dbhost']	=	'Enter the database hostname for the vBulletin connection.  Usually defaults to localhost.';
$lang['admin.plugin.form.vbulletin.label.dbuser']	=	'Database Username';
$lang['admin.plugin.form.vbulletin.desc.dbuser']	=	'Enter the username used to connect to the vBulletin database.';
$lang['admin.plugin.form.vbulletin.label.dbpass']	=	'Database Password';
$lang['admin.plugin.form.vbulletin.desc.dbpass']	=	'Enter the password used to connect to the vBulletin database.';
$lang['admin.plugin.form.vbulletin.label.dbname']	=	'Database Name';
$lang['admin.plugin.form.vbulletin.desc.dbname']	=	'Enter the name of the database found on the server.';
$lang['admin.plugin.form.vbulletin.label.dbpref']	=	'Database Prefix';
$lang['admin.plugin.form.vbulletin.desc.dbpref']	=	'Enter the prefix for the vBulletin database tables (leave blank for none).';


//	------------------------------------------------------------------------
//	Dashboard Page
//		WHMCS > Addons > Belong > Default
//		as of 2.0.0
//	------------------------------------------------------------------------
$lang['admin.default.body']		=	<<< HTML
<h2>Welcome to Belong 2.2!</h2>
<p>If you previous were using Belong 2.2 you'll obviously notice that the configuration, products and rules for Belong have moved from Joomla! over to WHMCS.  We did this because we realize not everyone uses Joomla on their site along with WHMCS, but may want to be able to leverage Belong to assign groups for vBulletin, WHMCS or Kayako Fusion.  We also moved everything within WHMCS to bring it closer to the source to improve reliability and responsiveness.</p>
<h3>What's New?</h3>
<p>Aside from the move to WHMCS, Belong 2.2 also uses a new API interface with Joomla and is built upon the Dunamis Framework which will improve update times when WHMCS rolls out new releases.</p>
<h3>Configuring Belong</h3>
<p>To configure Belong, please consult the Help feature in this product.  We are working to update our online documentation to bring it in line with version 2.2.</p>
HTML;
// Update Widget
$lang['admin.widget.header.updates']		= 'Software Updates';
$lang['admin.widget.body.updates.none']		=	'<p>You are running the latest version of Belong!</p>';
$lang['admin.widget.body.updates.error']	=	'<p>An error occurred checking for the latest updates:</p><pre>%s</pre>';
$lang['admin.widget.body.updates.exist']	=	'<p><strong>Belong version %s</strong> is available for download.  Please visit our web site at https://www.gohigheris.com to download the latest product.</p>';
// Configuration Widget
$lang['admin.widget.header.status']				= 'Product Configuration';
$lang['admin.widget.body.status.license']		=	'<p>Your license is coming back invalid and must be corrected first.</p>';
$lang['admin.widget.body.status.enable']		=	'<p>The product is disabled in the configuration settings.  No groups will be applied until this is enabled.</p>';
$lang['admin.widget.body.status.nogroups']		=	'<p>You haven\'t configured any groups yet in the product to apply.</p>';
$lang['admin.widget.body.status.noactivegrps']	=	'<p>You don\'t have any active groups in your configuration yet.</p>';
$lang['admin.widget.body.status.dupgroups']		=	'<p>You have duplicate active groups - only the group with the lowest ID number on the list will be applied for a given group, as you can only apply one group per client group.</p>';
$lang['admin.widget.body.status.good']			=	'<p>The basic configuration of your product checks out.  There should be minimal conflicts or issues experienced.</p>';

// License Widget
$lang['admin.widget.header.license']		= 'License Status';
$lang['admin.widget.body.license.success']	=	'<p>Your license is valid and current!</p>';
$lang['admin.widget.body.license.alert']	=	'<p>Your Support and Upgrade Pack expired on %s!  Please renew your Support and Upgrade Pack to ensure you have the latest updates available to you.</p>';
$lang['admin.widget.body.license.danger']	=	'<p>There is a problem with your license!</p><p>Please double check that your license key as entered is valid.  You will be unable to save or modify settings until the license is updated.</p>';
// Like Us Widget
$lang['admin.widget.header.likeus']		= '';
$lang['admin.widget.body.likeus']		=	'<p>If you find Belong useful please tell others about it by visiting WHMCS App Store and liking the product!</p>';


//	------------------------------------------------------------------------
//	Products Page
//		WHMCS > Addons > Belong > Products
//		as of 2.0.0
//	------------------------------------------------------------------------
// List
$lang['admin.list.products.hdr.id']			=	'ID';
$lang['admin.list.products.hdr.name']		=	'Name';
$lang['admin.list.products.hdr.product']	=	'Product (Group) - Module Type / Addon';
$lang['admin.list.products.hdr.actions']	=	'Actions';
$lang['admin.list.products.productname']	=	'%s ( %s ) - %s / %s';
// Delete Modals
$lang['admin.products.modal.delete.header']		=	'Delete Product';
$lang['admin.products.modal.delete.title']		=	'Confirm Delete Product Action';
$lang['admin.products.modal.delete.body']		=	'<p>Are you sure you want to delete this product? Doing so will cause all rulesets that depend on this product to exist to fail and may adversely affect your system.</p>';
// Add / Edit
$lang['admin.form.products.label.name']				=	'Friendly Name';
$lang['admin.form.products.description.name']		=	'Enter a friendly name to use for this product.  This name should make it easy for you to identify when listed or reported to you.';
$lang['admin.form.products.label.product']			=	'Product';
$lang['admin.form.products.description.product']	=	'Select the product from the dropdown to associate with this new product name.';
$lang['admin.form.products.label.prodaddon']		=	'Product Addon';
$lang['admin.form.products.description.prodaddon']	=	'(optional) Select a product addon to associate with this product.  If you select an addon here, then the product rule will apply against both the product and the addon and both must be valid for the rule to match.';
$lang['admin.form.prodaddon.option.none']			=	' - None Available - ';
$lang['admin.form.products.data.prodaddon.none']	=	'<em>none selected</em>';


//	------------------------------------------------------------------------
//	Rules Page
//		WHMCS > Addons > Belong > Rules
//		as of 2.0.0
//	------------------------------------------------------------------------
// List
$lang['admin.list.rules.hdr.id']			=	'ID';
$lang['admin.list.rules.hdr.name']			=	'Name';
$lang['admin.list.rules.hdr.actions']		=	'Actions';
// Delete Modals
$lang['admin.rules.modal.delete.header']	=	'Delete Rule';
$lang['admin.rules.modal.delete.title']		=	'Confirm Delete Rule Action';
$lang['admin.rules.modal.delete.body']		=	'<p>Are you sure you want to delete this rule? Doing so will cause all rulesets that depend on this rule to exist to fail and may adversely affect your system.</p>';
// Add / Edit
$lang['admin.form.rules.label.name']			=	'Rule Name';
$lang['admin.form.rules.description.name']		=	'Enter a friendly name to refer to this rule within Belong.';
$lang['admin.form.rules.productsgroup']			=	'Product Rules';
$lang['admin.form.rules.productsgroup.desc']	=	'These settings apply to a product.  If the client has the product in their products list and the rule matches what they have, then the group will either be added or removed from their account.  Note that the Green check adds the group to their account, the Red `x` removes the group from their account and the Black minus takes no action.';
$lang['admin.form.rules.label.productactive']			=	'Active Product';
$lang['admin.form.rules.description.productactive']		=	'Only applies if the product is active.';
$lang['admin.form.rules.label.productpending']			=	'Pending Product';
$lang['admin.form.rules.description.productpending']	=	'Only apply if the product is pending.';
$lang['admin.form.rules.label.productsuspended']		=	'Suspended Product';
$lang['admin.form.rules.description.productsuspended']	=	'Only apply if the product is suspended.';
$lang['admin.form.rules.label.productterminated']		=	'Terminated Product';
$lang['admin.form.rules.description.productterminated']	=	'Only apply if the product is terminated.';
$lang['admin.form.rules.label.productfraud']			=	'Fraud Product';
$lang['admin.form.rules.description.productfraud']		=	'Only apply if the product is marked as fraudulant.';
$lang['admin.form.rules.label.productcancel']			=	'Cancelled Product';
$lang['admin.form.rules.description.productcancel']		=	'Only apply if the product is cancelled.';
$lang['admin.form.rules.addonsgroup']				=	'Addon Rules';
$lang['admin.form.rules.addonsgroup.desc']			=	'These settings only apply to a product addon.  By setting values here, the rule must match both the product setting above as well as the addon rule here.  If the product you are using doesn\'t have an addon, then the setting below is disregarded.  If the client has the product addon attached to the product you match up to this rule, then the group will either be added or removed from their account.  Note that the Green check adds the group to their account, the Red `x` removes the group from their account and the Black minus takes no action.';
$lang['admin.form.rules.label.addonactive']				=	'Active Product Addon';
$lang['admin.form.rules.description.addonactive']		=	'Only applies if the product addon is active.';
$lang['admin.form.rules.label.addonpending']			=	'Pending Product Addon';
$lang['admin.form.rules.description.addonpending']		=	'Only apply if the product addon is pending.';
$lang['admin.form.rules.label.addonsuspended']			=	'Suspended Product Addon';
$lang['admin.form.rules.description.addonsuspended']	=	'Only apply if the product addon is suspended.';
$lang['admin.form.rules.label.addonterminated']			=	'Terminated Product Addon';
$lang['admin.form.rules.description.addonterminated']	=	'Only apply if the product addon is terminated.';
$lang['admin.form.rules.label.addonfraud']				=	'Fraud Product Addon';
$lang['admin.form.rules.description.addonfraud']		=	'Only apply if the product addon is marked as fraudulant.';
$lang['admin.form.rules.label.addoncancel']				=	'Cancelled Product Addon';
$lang['admin.form.rules.description.addoncancel']		=	'Only apply if the product addon is cancelled.';

$lang['admin.form.rules.data.group.none']	=	'- apply no group -';
$lang['admin.form.optn.add']	= '<i class="icon icon-ok-sign"> </i>';
$lang['admin.form.optn.none']	= '<i class="icon icon-minus"> </i>';
$lang['admin.form.optn.drop']	= '<i class="icon icon-remove-circle"> </i>';


//	------------------------------------------------------------------------
//	Rulesets Page
//		WHMCS > Addons > Belong > Rulesets
//		as of 2.0.0
//	------------------------------------------------------------------------
// List
$lang['admin.list.rulesets.hdr.id']				=	'ID';
$lang['admin.list.rulesets.hdr.name']			=	'Name';
$lang['admin.list.rulesets.hdr.productname']	=	'Product Name';
$lang['admin.list.rulesets.hdr.actions']		=	'Actions';
// Delete Modals
$lang['admin.rulesets.modal.delete.header']		=	'Delete Ruleset';
$lang['admin.rulesets.modal.delete.title']		=	'Confirm Delete Ruleset Action';
$lang['admin.rulesets.modal.delete.body']		=	'<p>Are you sure you want to delete this ruleset? Doing so will cause all permission dependancies to no longer be updated for the given matches and may adversely affect your system.</p>';
// Add / Edit
$lang['admin.form.rulesets.label.name']				=	'Ruleset Name';
$lang['admin.form.rulesets.description.name']		=	'Enter a name to call this ruleset.  This name should make it easy for you to identify when listed or reported to you.';
$lang['admin.form.rulesets.label.product']			=	'Product';
$lang['admin.form.rulesets.description.product']	=	'Select the product from your previously defined product list for this ruleset to apply to.';
$lang['admin.form.rulesets.label.rules']			=	'Select Rules';
$lang['admin.form.rulesets.description.rules']		=	'In the list on the right you will find the rules you have previously defined in Belong.  Drag the rule on the right side to the list on the left side to apply the rule to the selected product.';



//	------------------------------------------------------------------------
//	Updates and other sections
//		as of 2.0.0
//	------------------------------------------------------------------------
$lang['admin.plugins.noclientid']		= 'No client id was specified to check against.';
$lang['admin.plugins.nouserfound']		= 'No user found matching clientid `%s`';
$lang['admin.plugins.norulesapply']		= 'There are no rules that apply to the user with email address of `%s`.';
$lang['admin.plugins.clientnoupdate']	= 'No changes to make for user `%s` on `%s` because user already belongs to correct groups.';
$lang['admin.plugins.clientnotfoundon']	= 'User `%s` not found at `%s`';
$lang['admin.plugins.beforechanges']	= 'Groups the user belongs to before update: %s';
$lang['admin.plugins.rulesdrop']		= 'Groups the rules say the user should be dropped from: %s';
$lang['admin.plugins.rulesadd']			= 'Groups the rules say the user should be added to: %s';
$lang['admin.plugins.afterdrop']		= 'Groups the user belongs to after dropping groups: %s';
$lang['admin.plugins.afteradd']			= 'Groups the user belongs to after adding groups: %s';

$lang['admin.list.updates.emailhdr']	= 'User: %s';


//	------------------------------------------------------------------------
//	Help Page
//		WHMCS > Addons > Belong > Help
//		as of 2.0.0
//	------------------------------------------------------------------------
$lang['sidebar.header.overview']		=	'Product Overview';
$lang['sidebar.header.configure']		=	'Configuring Belong';
$lang['sidebar.header.plugins']			=	'Setting Up Plugins';
$lang['sidebar.header.troubleshoot']	=	'Troubleshooting';
$lang['sidebar.getstart']		=	'Getting Started';
$lang['help.body.getstart']	=	<<< HELP
<h4>What is Belong?</h4>
<p>Belong is a permission management tool built upon the Dunamis Framework within the WHMCS application.</p>
<h4>What does Belong allow me to do?</h4>
<p>Belong extends your product offerings by allowing you to change what permission groups a user has in other connections based on their product status in WHMCS.  This means you can restrict access to other areas of your website depending upon a client paying their bill or purchasing a certain product.</p>
<h4>...for example?</h4>
<ol>
<li>You sell hosting and have a very active and vibrant vBulletin forum, but you don't want the entire world to benefit from it, you want it to be a selling point for your hosting products.  With Belong, you can setup a ruleset that would add a client to a user group in vBulletin that has the ability to post, read forums or other capabilities you decide upon.</li>
<li>You have a large mailing list in Mailchimp, but it is quite unruly because it is hard to keep up with segments and keep your clients on the right lists.  With Belong, you can setup rules so they can be added to different segments based on their product statuses.  This would even permit you to move suspended clients to a group that starts sending periodic emails to try and salvage the client.</li>
<li>You sell software and use Joomla for managing downloads and your installation instructions.  With Belong, you can setup a ruleset so a client that has purchased a product with an active addon for support and upgrades can be added to a Joomla usergroup that has access to new downloads and documentation.</li>
</ol>
<p>These are just a few of the possibilities of using Belong.  Belong gives you freedom to bridge permission groups based on product sales, and the ease to change them later if you like.</p>
<h4>So what do I need to run Belong?</h4>
<p>Currently you must have:</p>
<ul>
<li>WHMCS version 5.3 or above</li>
<li>Dunamis Framework version 1.4.0 or above</li>
</ul>
<p>If you plan to use any of the plugins for Belong, their requirements are as follows:</p>
<ul>
<li>Joomla:  version 2.5 or 3.x</li>
<li>Kayako Fusion:  version 4.0 or above</li>
<li>Mailchimp:  must have an account :-)</li>
<li>vBulletin:  version 4 - version 5 has not been tested or verified to work</li>
<li>WHMCS:  version 5.3 or above</li>
</ul>
<h4>Useful Features</h4>
<ul>
<li>Unlimited products, rules and ruleset management capabilities</li>
<li>Permissions updated with run of nightly cron</li>
<li>Client profile screen has button to Update Permissions through Belong.</li>
</ul>
HELP;

//	=============================================

$lang['sidebar.plugins.whmcs']	=	'WHMCS';
$lang['help.body.pluginswhmcs']	=	<<< HELP
<p>The easiest plugin to setup and configure should be your local WHMCS - it already knows everything it needs to know about it.</p>
<p>To add the WHMCS plugin to Belong:</p>
<ol><li>From the Belong > Plugins page find the drop down on the right-top of the page.  It should appear with the list of available plugins in it.  Select the WHMCS plugin.</li>
<li>Next click `Add New`.</li>
<li>Give the connection a name you will be able to reference it by.</li>
<li>Toggle the `Connection Enabled` to the `Enabled` position.</li>
<li>Select an admin user for local API calls.  This option permits you to audit your application to see who or what application is doing what.</li>
<li>Click `Submit` and you are all set.</li>
</ol>
<p>You should now see your new connection using the plugin on the list in the Belong > Plugins screen.</p> 
HELP;

//	=============================================

$lang['sidebar.plugins.joomla']	=	'Joomla';
$lang['help.body.pluginsjoomla']	=	<<< HELP
<p>The Joomla plugins supports Joomla! 2.5 or 3.x and requires you to install the Belong plugin for Joomla.</p>
<h4>Install Plugin in Joomla</h4>
<p>Before you can use the plugin in Belong, you must add the Belong - System plugin for Joomla to your Joomla installation.  To do this:</p>
<ol><li>From the Joomla backend, navigate to the Extension Manager (Extensions > Extension Manger).</li>
<li>Under the Install section, select the Browse button to find the package file to install.</li>
<li>Locate the Belong plugin for Joomla file on your computer and select it.  Then click Upload and Install.</li>
<li>Next go to the Plugin Manager (Extensions > Plugin Manager).</li>
<li>Locate the `System - Belong: API Handler` plugin and click to edit it.</li>
<li>In the field `API Token` enter a unique token... the more complex the better.  Remember this token, you'll need it for the WHMCS side.</li>
<li>Set the status to Enabled and Save the plugin.  You should be all set on the Joomla side.</li>
</ol>
<h4>Activate the Plugin in WHMCS</h4>
<p>Once you have the plugin installed in Joomla and have setup an API token, you can add the plugin in WHMCS:</p>
<ol><li>From the Belong > Plugins page find the drop down on the right-top of the page.  It should appear with the list of available plugins in it.  Select the Joomla plugin name.</li>
<li>Next click `Add New`.</li>
<li>Give the connection a name you will be able to reference it by.</li>
<li>Toggle the `Connection Enabled` to the `Enabled` position.</li>
<li>Enter the URL to the FRONT end of your Joomla site.  Do not use your administrator URL!</li>
<li>Now enter the API Token you set in the System Plugin earlier.</li> 
<li>Click `Submit` and you are all set.</li>
</ol>
HELP;

//	=============================================

$lang['sidebar.plugins.kayako']	=	'Kayako Fusion';
$lang['help.body.pluginskayako']	=	<<< HELP
<p>The Kayako Fusion plugin supports Kayako Fusion version 4.0 and above.</p>
<h4>Activate API in Kayako Fusion</h4>
<p>Before you can use the plugin in Belong, you must activate the API interface in Kayako Fusion and also gather some information from there.  To do this:</p>
<ol><li>Log into the ADMIN panel of Kayako Fusion (note this will require administrative access to Kayako Fusion).  The admin panel is typically found by visiting http://your.Kayako.URL/admin.</li>
<li>Navigate to the `REST API` on the left side (directly beneath Settings) and click on the `Settings` link under it.</li>
<li>You should now see just the option to enable or disable the API.  Ensure that the API is enabled and click Update.</li>
<li>Next go to the link for the API Information under the REST API menu item.</li>
<li>You will see 3 or 4 values... you need the API Key, Secret Key and the API URL to configure the Plugin for Belong in WHMCS.  You may want to leave this screen open and move to another tab or browser to configure the plugin next.</li>
</ol>
<h4>Activate the Plugin in WHMCS</h4>
<p>With the API information from Kayako Fusion, you can add the plugin in WHMCS:</p>
<ol><li>From the Belong > Plugins page find the drop down on the right-top of the page.  It should appear with the list of available plugins in it.  Select `Kayako Fusion`.</li>
<li>Next click `Add New`.</li>
<li>Give the connection a name you will be able to reference it by.</li>
<li>Toggle the `Connection Enabled` to the `Enabled` position.</li>
<li>For the API URl, enter the setting found in your Fusion settings for the API URL EXACTLY as it appears there, including the question mark and path.</li>
<li>For the API Key, enter the setting found in your Fusion settings for the API Key EXACTLY as it appears there.</li>
<li>For the API Secret, enter the setting found in your Fusion settings for the Secret Key EXACTLY as it appears there (note that this is a very long string).</li>
<li>The default group should still be blank.</li>
<li>Click `Submit` and you are all set.</li>
</ol>
<h4>Configure the Default Group</h4>
<p>If your settings were taken and there isn't a problem connecting, then you can now go in and edit the plugin to select the default group.  You must select the default group so that if a user is dropped from a group due to a rule being applied to them, then Belong will set their default group as the fall back group.  Not setting this will result in user group updates failing.</p>
HELP;

//	=============================================

$lang['sidebar.plugins.mailchimp']	=	'Mailchimp';
$lang['help.body.pluginsmailchimp']	=	<<< HELP
<p>The Mailchimp plugin for Belong communicates directly with your Mailchimp account.  Note that Belong <u>will not</u> automatically add clients to your lists, but instead will only add them or remove them from segments.  To add them automatically, you should use the Mailchimp hook provided on the WHMCS Appstore (it's a freebie!).</p>
<h4>Retrieve your API Keys</h4>
<p>Mailchimp uses an API Key to authorize applications to perform actions.  To get your API Key from Mailchimp:</p>
<ol><li>Log into your Mailchimp account; once logged in hover over Account and click on API Keys and Authorized Apps.</li>
<li>Now click the button that says `Add A Key`.  When the key appears in the list, be sure to give it a useful label so you can identify it later.</li>
<li>Now you'll want to copy that API key (or leave this page open and open your WHMCS admin area in another tab or browser to add it to Belong).</li>
</ol>
<h4>Activate the Plugin in WHMCS</h4>
<p>With the API Key from Mailchimp, you can add the plugin in WHMCS:</p>
<ol><li>From the Belong > Plugins page find the drop down on the right-top of the page.  It should appear with the list of available plugins in it.  Select `Mailchimp`.</li>
<li>Next click `Add New`.</li>
<li>Give the connection a name you will be able to reference it by.</li>
<li>Toggle the `Connection Enabled` to the `Enabled` position.</li>
<li>For the API Key, enter the setting found in your Mailchimp API Keys area earlier EXACTLY as it appears there.</li>
<li>Toggle the use of SSL if you like (it doesn't hurt to enable it, and would be most secure).</li>
<li>Click `Submit` and you are all set.</li>
</ol>
HELP;

//	=============================================

$lang['sidebar.plugins.vbulletin']	=	'vBulletin';
$lang['help.body.pluginsvbulletin']	=	<<< HELP
<p>The vBulletin plugin for Belong works directly on the vBulletin database and must have access (remotely or locally) to the MySQL database.  It also support vBulletin version 4 only, though earlier versions and later versions may work they have not been tested.</p>
<h4>Activate the Plugin in WHMCS</h4>
<p>Be sure you have the database information used by vBulletin to manage your forum, then you can add the plugin in WHMCS:</p>
<ol><li>From the Belong > Plugins page find the drop down on the right-top of the page.  It should appear with the list of available plugins in it.  Select `vBulletin`.</li>
<li>Next click `Add New`.</li>
<li>Give the connection a name you will be able to reference it by.</li>
<li>Toggle the `Connection Enabled` to the `Enabled` position.</li>
<li>For the Database Hostname, enter the hostname to access your database.  For most, it should just be `localhost`.</li>
<li>For the Database Username, this should be the username that is used to connect to your database - this is different from any other account you may log into vBulletin with.</li>
<li>For the Database Password, this should be the password that is used to connect to your database.</li>
<li>For the Database Name, this is the actual database name in your database server that stores your vBulletin information.</li>
<li>The Database Prefix is optional, and is dependant on your configuration.  If you have one used in your database, then enter it here.</li>
<li>Click `Submit` and you are all set.</li>
</ol>
HELP;

//	=============================================

$lang['sidebar.license']		=	'License';
$lang['help.body.license']	=	<<< HELP
<p>Before configuring the Belong product, you will first need to enter your license under the `License` link found on the Belong navigation menu.</p>
<p>Your Belong license can be found by visiting our web site at <a href="https://www.gohigheris.com" target="blank">https://www.gohigheris.com</a> and logging in and navigating to `My Products / Services`.</p>
<p>Once you have the license key, enter it into the field for `License` and press `Submit` at the bottom.  If the license is valid and okay, you should see it come up as Active and your information as it is registered with us appear.</p>
<p>Your Belong license permits you to install Belong in a single WHMCS location, but you may connect as many sites and plugins as you like with it.</p> 
HELP;

//	=============================================

$lang['sidebar.productmgt']		=	'Product Management';
$lang['help.body.productmgt']	=	<<< HELP
<p>Products are setup in Belong to allow you to set different terms for a product to be used.  For example, you may have a product that has an addon associated with it, and only if that addon is present and active would you want a rule to be applied.  Using products in Belong permit you to do this.</p>
<h4>To setup a product</h4>
<ol><li>First you must have products configured in your WHMCS application.  If you have not already done so, stop now and create some products there.</li>
<li>Now go the Belong > Products and click on the `Add New` button on the top right.</li>
<li>Give the product an easy to remember name - this is for your reference only</li>
<li>Select the product in the first drop down.</li>
<li>Next select an addon you want to also use.  Note that this is completely optional, you can choose to leave it at `- None Available -` and the product will apply regardless of any addons.  Also note that only addons that are associated with the product you selected are shown.</li>
<li>Click Submit.</li>
</ol>
<p>All done adding a product to Belong.  To edit the product, find the product you want to edit and click the Edit button.  To delete it, just click the delete button.</p>
<p><strong>Note:</strong> Deleting a product is irreversible and any rulesets associated with it will no longer apply.</p>
HELP;

//	=============================================

$lang['sidebar.rulemgt']		=	'Rule Management';
$lang['help.body.rulemgt']	=	<<< HELP
<p>Rules rely upon plugins to be setup.  If you haven't already setup a plugin, please do so now.</p>
<h4>To setup a rule</h4>
<p>For best and consistant results, it is best to create a rule that applies to a single group rather than try to add to one group but remove from another.  This will keep rules simple and understandable - and achieve desired results.</p>
<ol><li>First you must have at least one plugin configured in Belong > Plugins.  If you have not already done so, stop now and configure a plugin there.</li>
<li>Now go the Belong > Rules and click on the `Add New` button on the top right.</li>
<li>Give the rule an easy to remember name - this is for your reference only</li>
<li>The next section entitled Product Rules applies only to status of a product.  Rulesets are used to match products to rules, so this section would apply to a clients product status.</li>
<li>For each status you can set which group to apply for a given status.  There are three buttons in front:<ul>
<li>Green Checkbox - clicking this button indicates the client will be added to the selected group.</li>
<li>Black Dash - this button indicates no change of status for the client (no action will be taken).</li>
<li>Red 'X' - this button indicates the client will be dropped from the selected group.</li></ul></li>
<li>The next section entitled Product Rules applies only to status of a product addon.  Rulesets are used to match products to rules, so this section would apply to a clients product addon status.</li>
<li>For each status you can set which group to apply for a given status.  There are three buttons in front:<ul>
<li>Green Checkbox - clicking this button indicates the client will be added to the selected group.</li>
<li>Black Dash - this button indicates no change of status for the client (no action will be taken).</li>
<li>Red 'X' - this button indicates the client will be dropped from the selected group.</li></ul></li>
<li>Click Submit.</li>
</ol>
<p>
HELP;

//	=============================================

$lang['sidebar.rulesetmgt']		=	'Ruleset Management';
$lang['help.body.rulesetmgt']	=	<<< HELP
<p>Rulesets match up your defined products and defined rules into rulesets.  They can apply many rules against the same product simultaneously. If you have not setup any products or rules in Belong, please do so now to setup a ruleset.</p>
<h4>To setup a ruleset</h4>
<ol><li>First you must have at least one rule and one product configured in Belong.  If you have not already done so, stop now and configure them.</li>
<li>Now go the Belong > Rulesets and click on the `Add New` button on the top right.</li>
<li>Give the ruleset an easy to remember name - this is for your reference only</li>
<li>Next select which of your defined products you want this ruleset to apply against.</li>
<li>In the area below you will see a green box and a yellow box.  The yellow box contains all your rules, the green box will contain any rules you may have previously set to this ruleset (if this is an edit).  To add a rule from the yellow box to the green box, simply click on it and drag it to the green box.  To remove a rule, click on the rule in the green box and drag it to the yellow box.</li>
<li>Click Submit.</li>
</ol>
<p>
HELP;

//	=============================================

$lang['sidebar.tslicense']		=	'Licensing Problems';
$lang['help.body.tslicense']	= <<< HELP
<h4>When I enter my license, nothing is saved and it is invalid.</h4>
<p>This happens if the database didn't get installed properly.  To resolve this, go back into WHMCS > Setup > Addon Modules and deactivate Belong.  Then Activate Belong and try again.  The database should now be reloaded.</p>
<h4>My license reports that it is invalid.  What do I do?</h4>
<p>If you enter your license in the field and it comes back indicating that it is invalid, then you may need to reissue your license on our site.  Visit our web site and log in, then navigate to view `My Products / Services` and click to manage the license.  Click to reissue the license and try saving the license again.  If it still isn't working, please contact us so we can assist directly.</p>
HELP;


//	=============================================

$lang['sidebar.tsrules']		=	'Problems with Rules';
$lang['help.body.tsrules']	= <<< HELP
<h4>One of my rules is listed as `Plugin Disabled`.  Why?</h4>
<p>In order for a rule to be active and applied against a user should a product match, the plugin must be active.  If the plugin is disabled, the rule will be disabled automatically.  To correct this, address the plugin in the Belong > Plugin manager to reactivate the plugin.</p>
HELP;


//	------------------------------------------------------------------------
//	Onscreen Assistance
//		as of 2.0.0
//	------------------------------------------------------------------------
$lang['onscreen.default.widgets']			=	"These provide a quick glance of important information for your product on the Dashboard.";
$lang['onscreen.license.license']			=	"This is the license you received from Go Higher IS for Belong.  You can find this by logging into our web site and visiting the Client Portal > My Products.";
$lang['onscreen.license.owner']				=	"This is the account information we have attached to your license.  If you feel this is incorrect, be sure to contact Go Higher IS to correct it or clarify any changes that need to be made.";


//	------------------------------------------------------------------------
//	Updates
//		as of 2.0.0
//	------------------------------------------------------------------------
$lang['updates.checking.title']		=	"Checking for Updates";
$lang['updates.checking.subtitle']	=	"Please wait...";

$lang['updates.none.title']		=	"Check Complete";
$lang['updates.none.subtitle']	=	"Your version %s is the latest release";

$lang['updates.exist.title']	=	"Updates Found!";
$lang['updates.exist.subtitle']	=	"Click to update";

$lang['updates.init.title']		=	"Downloading Update";
$lang['updates.init.subtitle']	=	"Downloading version %s...";

$lang['updates.download.title']		=	"Installing Update";
$lang['updates.download.subtitle']	=	"Installing version %s...";

$lang['updates.complete.title']		=	"Upgrade Complete!";
$lang['updates.complete.subtitle']	=	"Version %s installed";


?>