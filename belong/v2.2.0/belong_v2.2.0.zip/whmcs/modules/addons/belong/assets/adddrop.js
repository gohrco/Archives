

function adddrop( id, value ) {
	
	// Set this hidden ID value
	jQuery( "#" + id ).val(value);
	
	jQuery( "#" + id + "btn1" ).removeClass( 'btn-success' ).find( '.icon-white' ).removeClass( 'icon-white' );
	jQuery( "#" + id + "btn0" ).removeClass( 'btn-inverse' ).find( '.icon-white' ).removeClass( 'icon-white' );
	jQuery( "#" + id + "btn-1").removeClass( 'btn-danger' ).find( '.icon-white' ).removeClass( 'icon-white' );
	
	jQuery( "#" + id ).find( '.icon-white' ).removeClass( 'icon-white' );
	
	if ( value == 1 ) {
		jQuery( "#" + id + "btn" + value ).addClass( 'btn-success' );
	}
	else if ( value == 0 ) {
		jQuery( "#" + id + "btn" + value ).addClass( 'btn-inverse' );
	}
	else {
		jQuery( "#" + id + "btn" + value ).addClass( 'btn-danger' );
	}
	
	jQuery( "#" + id + "btn" + value ).find( 'i' ).addClass( 'icon-white' );
	
	
}