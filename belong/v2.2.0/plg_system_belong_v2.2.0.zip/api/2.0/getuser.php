<?php
/**
 * Belong
 * System - Belong Plugin:  API Get User file
 *
 * @package    Belong
 * @copyright  2013 Go Higher Information Services, LLC.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    2.2.0 ( $Id$ )
 * @author     Go Higher Information Services, LLC
 * @since      2.0.0
 *
 * @desc       This is the Get User File for handling all API requests for Belong
 *
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Get User Belong API Class
 * @version		2.2.0
 *
 * @since		2.0.0
 * @author		Steven
 */
class GetuserBelongAPI extends BelongAPI
{
	/**
	 * Method for executing on the API
	 * @access		public
	 * @version		2.2.0
	 *
	 * @since		2.0.0
	 */
	public function execute()
	{
		// Joomla user first...
		$db		=	JFactory :: getDbo();
		$email	=	$this->getVar( 'email', false, 'string' );
		
		// Ensure we have an email to get user for
		if (! $email ) {
			$this->error( JText :: _( 'BELONG_API_GETUSER_NOEMAIL' ) );
		}
		
		$query	= 'SELECT id FROM #__users WHERE email = ' . $db->Quote( $email );
		$db->setQuery($query, 0, 1);
		$jid	= $db->loadResult();
		
		// User not found so bail
		if (! $jid ) {
			$this->error( sprintf( JText :: _( 'BELONG_API_GETUSER_NOTFOUND' ), $email ) );
		}
		
		$juser	=	JFactory :: getUser( $jid );
		$data	=	array();
		$grab	=	array(
				'id',
				'name',
				'username',
				'email',
				'groups'
				);
		
		foreach ( $grab as $g ) {
			$value		= $juser->$g;
			$data[$g]	= $value;
		}
		
		$this->success( $data );
	}
}