<?php
/**
* Belong
*
* @package    Belong
* @copyright  2012 Go Higher Information Services.  All rights reserved.
* @license    GNU General Public License version 2, or later
* @version    1.1.1 ( $Id: fusion.php 65 2012-05-17 02:40:43Z steven_gohigher $ )
* @author     Go Higher Information Services
* @since      1.0.3
*
* @desc       This file is a utility helper for Belong
*
*/

/*-- Security Protocols --*/
defined('_JEXEC') or die;

/*-- Localscope import --*/
jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.http.transport.curl' );

if ( $path = JApplicationHelper :: getPath( 'helper', 'com_belong' ) ) {
	require_once( $path );
}

/**
 * Belong Plugin: vBulletin
 * Extends the Belong ruleset functionality to a local vBulletin
 * @version		1.1.1
 * 
 * @since		1.0.5
 * @author		Steven
 */
class plgBelongFusion extends JPlugin
{
	/**
	 * Stores the fusion http transport object
	 * @access		private
	 * @since		1.0.5
	 * @var			JHttpTransportCurl object
	 */
	private $fusion		= null;
	
	/**
	 * Stores the Fusion URI
	 * @access		private
	 * @since		1.0.5
	 * @var			JUri object
	 */
	private $fusionuri	= null;
	
	/**
	 * Method to halt execution of plugin if a failure exists at setup
	 * @access		private
	 * @since		1.0.5
	 * @var			boolean
	 */
	private $enabled	= true;
	
	/**
	 * Stores the post variables for the URI object
	 * @access		private
	 * @since		1.0.5
	 * @var			array
	 */
	private $post		= array();
	
	/**
	 * Stores queued sets to execute
	 * @access		private
	 * @since		1.0.5
	 * @var			array
	 */
	private $queue		= array();
	
	/**
	 * Indicates the use of a table prefix (needed b/c Joomla wont accept an empty prefix when setting up a database connection)
	 * @access		private
	 * @since		1.0.5
	 * @var			boolean
	 */
	private $useprefix	= false;
	
	/**
	 * Constructor method
	 * @access		public
	 * @version		1.1.1
	 * @param		string		$subject: passed by JPlugin 
	 * @param		array		$config:  passed by JPlugin
	 * 
	 * @since		1.0.5
	 */
	public function __construct( & $subject, $config )
	{
		parent::__construct($subject, $config);
		
		$this->loadLanguage();
		
		// Check for empty required first
		$uri	= $this->params->get( 'url' );
		$apikey	= $this->params->get( 'apikey' );
		$secret	= $this->params->get( 'secret' );
		$defgrp	= $this->params->get( 'defaultgroup' );
		
		if ( empty( $uri ) || empty( $apikey ) || empty( $secret ) ) {
			$this->enabled = false;
			return;
		}
		
		$this->fusionuri = new JUri( $uri );
		$this->fusionuri->setPath( rtrim( $this->fusionuri->getPath(), "/" ) . "/api/index.php" );
		
		// Build the Post variables next
		$apikey		=   $this->params->get( 'apikey' );
		$salt		=   mt_rand();
		$signature	=   base64_encode( hash_hmac( 'sha256', $salt, $this->params->get( 'secret' ), true ) );
		
		$this->post	=   array(	'apikey'	=> $apikey,
								'salt'		=> $salt,
								'signature'	=> $signature
		);
		
		$this->fusion = new JHttpTransportCurl( new JRegistry );
		
	}
	
	
	/**
	 * Event called when gathering update sites to check for updates
	 * @access		public
	 * @version		1.1.1
	 *
	 * @return		array
	 * @since		1.1.0
	 */
	public function getUpdateSite()
	{
		return array(
				'extensionName'				=> 'plg_belong_fusion',
				'options' => array(
						'extensionTitle'	=> 'Belong Joomla! Fusion (Kayako) Plugin',
						'storage'			=> 'database',
						'storagePath'		=> null,
						'extensionType'		=> 'plugin',
						'updateUrl'			=> 'https://www.gohigheris.com/updates/belong/plugin/fusion'
				)
		);
	}
	
	
	/**
	 * Event called when getting permission groups list
	 * @access		public
	 * @version		1.1.1
	 * @param		array		$data: an array of gathered permision groups
	 * 
	 * @return		array
	 * @since		1.0.5
	 */
	public function onGetPermissionGroups( & $data = array() )
	{
		if (! $this->enabled ) return $data;
		static $instance = null;
		if ( $instance == null ) {
			$groups		= $this->_getFusiongroups();
			if (! $groups ) return $data;
			$instance = array( 'items' => $this->_getFusiongroups(), 'text' => JText :: _( 'PLG_BELONG_FUSION_GROUP_LABEL' ) );
		}
		return $instance;
	}
	
	
	/**
	 * Event called to run the queue of users and update
	 * @access		public
	 * @version		1.1.1
	 * 
	 * @return		true
	 * @since		1.0.5
	 */
	public function onRunQueue()
	{
		$qs = $this->queue;
		
		foreach( $qs as $q ) {
			$this->_updateUser( $q['u'], $q['g'] );
		}
		
		return true;
	}
	
	
	/**
	 * Event to handle user permissions update
	 * @access		public
	 * @version		1.1.1
	 * @param		integer		$id: the Joomla id of the user to update
	 * @param		array		$add_groups: an array of user groups to add user to
	 * @param		array		$drop_groups: an array of user groups to drop user from
	 * 
	 * @return		true
	 * @since		1.0.5
	 */
	public function onUserUpdatePermissions( $id, $add_groups = array(), $drop_groups = array() )
	{
		if (! $this->enabled ) return;
		if (! isset( $add_groups['fusion'] ) ) $add_groups['fusion'] = array();
		if (! isset( $drop_groups['fusion'] ) ) $drop_groups['fusion'] = array();
		
		$debug	=   BelongDebug :: getInstance( true );
		$user	= & JFactory :: getUser( $id );
		$groups	=   $this->_getFusiongroups( true );
		$defgrp	=   $this->params->get( 'defaultgroup' );
		
		// Can't do anything if we don't have a default group set
		if ( empty( $defgrp ) ) {
			$debug->add( JText::_( 'PLG_BELONG_FUSION_NODEFGRP' ), $user->email );
			return;
		}
		
		// Grab the user and fail if not found
		$remote_user = $this->_getUser( $user->email );
		if (! $remote_user ) {
			$debug->add( JText::_( 'PLG_BELONG_FUSION_NOUSER' ), $user->email );
			return;
		}
		
		$adds	=   reset( $add_groups['fusion'] );
		$drops	=   reset( $drop_groups['fusion'] );
		$curs	=   $remote_user['usergroupid'];
		
		// Pre-processing
		if (! empty( $add_groups['fusion'] ) )	$debug->add( JText::_( 'PLG_BELONG_FUSION_ADDGROUPS' ), $groups[$this->_name.'|'.$adds] );
		if (! empty( $drop_groups['fusion'] ) )	$debug->add( JText::_( 'PLG_BELONG_FUSION_DROPGROUPS' ), $groups[$this->_name.'|'.$drops] );
		$debug->add( JText::_( 'PLG_BELONG_FUSION_CURGROUPS' ),  $groups[$this->_name.'|'.$curs] );
		
		// Drop group if applicable
		if ( $curs == $drops ) {
			$curs = $defgrp;
			$debug->add( JText::_( 'PLG_BELONG_FUSION_AFTERDROPGROUPS' ), $groups[$defgrp] );
		}
		
		// Add groups if applicable
		if (! empty( $adds ) ) {
			$curs = $adds;
			$debug->add( JText::_( 'PLG_BELONG_FUSION_AFTERADDGROUPS' ), $groups[$this->_name.'|'.$curs] );
		}
		
		// Queue up for final run
		return $this->_enqueueUpdate( $remote_user, $curs );
	}
	
	
	/**
	 * Enqueues a user update for run
	 * @access		private
	 * @version		1.1.1
	 * @param		array		$vbuser: the vbuser to update
	 * @param		string		$groups: the groups to set the user to
	 * 
	 * @return		true
	 * @since		1.0.5
	 */
	private function _enqueueUpdate( $user, $groups )
	{
		$debug	=   BelongDebug :: getInstance( true );
		
		if (! isset( $this->queue[$user['id']] ) ) $this->queue[$user['id']] = array( 'u' => $user, 'g' => $groups );
		else $debug->add( JText::_( 'PLG_BELONG_FUSION_ERRORALREADYRUN' ), $user['email'] );
		
		return true;
	}
	
	
	/**
	 * Retrieves the Fusion Usergroups
	 * @access		private
	 * @version		1.1.1
	 * @param		boolean		$asArray: if true returns id => title, else returns array of objects
	 * 
	 * @return		array
	 * @since		1.0.5
	 */
	private function _getFusiongroups( $asArray = false )
	{
		$uri = clone $this->fusionuri;
		$uri->setVar( 'e', '/Base/UserGroup' );
		
		$response	= $this->fusion->request( 'Get', $uri, $this->post );
		
		if ( $response->code != 200 ) return false;
		
		$result		= simpleXMLToArray( simplexml_load_string( $response->body ) );
		
		$items = array();
		foreach( $result['usergroup'] as $item ) {
			$items[] = (object) array( 'value' => $this->_name . '|' . $item['id'], 'text' => $item['title'] );
		}
		
		if (! $asArray ) return $items;
		
		$data = array();
		foreach( $items as $row ) {
			$data[$row->value] = $row->text;
		}
		return $data;
	}
	
	
	/**
	 * Retrieves the Fusion user
	 * @access		private
	 * @version		1.1.1
	 * @param		string		$email: the email address to retrieve the user for
	 * 
	 * @return		object
	 * @since		1.0.5
	 */
	private function _getUser ( $email )
	{
		static $fusers = array();
		
		if ( empty( $fusers ) ) {
			
			$count	= 0;
			$uri	= clone $this->fusionuri;
			$post	= $this->post;
			$run	= true;
			$marker	= null;
			$users	= array();
			
			while ( $run == true ) {
				if ( $count == 0 ) {
					$uri->setVar( 'e', '/Base/User/Filter/1/1000' );
				}
				else {
					$uri->setVar( 'e', '/Base/User/Filter/' . $marker . '/1000' );
				}
				
				$response	= $this->fusion->request( 'Get', $uri, $post );
				
				$xml		= simplexml_load_string( $response->body );
				$xusers		= simpleXMLToArray( $xml );
				
				foreach ( $xusers['user'] as $user ) {
					$users[]	= $user;
				}
				
				if ( count( $xusers['user'] ) == 1000 ) {
					$tmp = end( $users );
					$marker = $tmp['id'];
				} 
				else $run = false;
				
				$count++;
			}
			
			foreach( $users as $user ) {
				if (! isset( $user['email'] ) ) continue;
				if ( is_array( $user['email'] ) ) {
					foreach ( $user['email'] as $uem ) {
						if ( is_array( $uem ) ) foreach( $uem as $uemt ) {
							$fusers[$uemt] = $user;
						}
						else $fusers[$uem] = $user;
					}
				}
				else {
					$fusers[$user['email']] = $user;
				}
			}
		}
		
		return isset( $fusers[$email] ) ? $fusers[$email] : false;
	}
	
	
	/**
	 * Updates the Fusion user directly
	 * @access		private
	 * @version		1.1.1
	 * @version		1.1.1		May 2012: Curl class for Joomla not as robust as needed for PUT calls, changed to own curl class
	 * @param		array		$vbuser: the vbuser array to update user from
	 * @param		string		$membergroups: contains the membership groups the user should belong to
	 * 
	 * @since		1.0.5
	 */
	private function _updateUser( $remote_user, $membergroups )
	{
		$uri = clone $this->fusionuri;
		$uri->setVar( 'e', '/Base/User/' . $remote_user['id'] );
		
		$post					= $this->post;
		$post['fullname']		= $remote_user['fullname'];
		$post['usergroupid']	= intval( $membergroups );
		
		$options	= array(	'HEADER'			=> false,
				'RETURNTRANSFER'	=> true,
				'SSL_VERIFYPEER'	=> false,
				'SSL_VERIFYHOST'	=> false,
				'CONNECTTIMEOUT'	=> 2,
				'FORBID_REUSE'		=> true,
				'FRESH_CONNECT'		=> true,
				'HTTPHEADER'		=> array(),
		);
		
		$curl		= new BelongCurl();
		$response	= $curl->simple_put( $uri->toString(), $post, $options );
	}
}