<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.1 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the updates controller file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.controlleradmin');
include_once( JPATH_COMPONENT_ADMINISTRATOR . DS . 'update' . DS . 'belongupdate.php' );
/*-- File Inclusions --*/

/**
 * Belong Rules Controller
 * @author		Steven
 * @version		1.1.1
 * 
 * @since		1.1.0
 */
class BelongControllerUpdates extends JControllerAdmin
{
	
	/**
	 * Task that beings the update procedure
	 * @access		public
	 * 
	 * @since		1.1.0
	 */
	public function begin()
	{
		$result		= $this->setCredentials();
		
		// We must supply FTP creds still so throw an error
		if ( $result === true ) {
			JError::raiseWarning('SOME_ERROR_CODE', JText :: _( 'COM_BELONG_UPDATES_CREDENTIALS_MISSING' ) );
			$this->setRedirect( 'index.php?option=com_belong&controller=updates&view=updates' );
			$this->redirect();
		}
		else if ( $result === false ) {
			JError::raiseWarning('SOME_ERROR_CODE', JText :: _( 'COM_BELONG_UPDATES_FTPCREDENTIALS_MISSING' ) );
			$this->setRedirect( 'index.php?option=com_belong&controller=updates&view=updates' );
			$this->redirect();
		}
		else {
			$this->setRedirect( 'index.php?option=com_belong&task=updates.download' );
			$this->redirect();
		}
	}
	
	
	/**
	 * Task that downloads the updates locally
	 * @access		public
	 * 
	 * @since		1.1.0
	 */
	public function download()
	{
		$model		= $this->getModel();
		$creds		= $this->setCredentials();
		$updates	= BelongUpdate :: getUpdateInformation( true );
		
		foreach ( $updates as $update ) {
			if ( $update['update']->hasupdate ) {
				$update['update']->downloadURL .= $creds;
				$result	= $model->download( $update );
				
				if ( $result === false ) {
					$this->setRedirect( 'index.php?option=com_belong&controller=updates&view=updates' );
					$this->redirect();
				}
			}
		}
		
		$this->setRedirect( 'index.php?option=com_belong&task=updates.extract' );
		$this->redirect();
	}
	
	
	/**
	 * Task that extracts the updates locally
	 * @access		public
	 * 
	 * @since		1.1.0
	 */
	public function extract()
	{
		$model		=   $this->getModel();
		$updates	=   BelongUpdate :: getUpdateInformation( true );
		
		foreach ( $updates as $update ) {
			if ( $update['update']->hasupdate ) {
				$result = $model->extract( $update );
				
				// Problem with download / extraction
				if ( $result === false ) {
					JError::raiseWarning('SOME_ERROR_CODE', JText :: sprintf( 'COM_BELONG_UPDATES_ERROR_EXTRACT', $update['config']->get( '_extensionTitle' ) ) );
					$this->setRedirect( 'index.php?option=com_belong&controller=updates&view=updates' );
					$this->redirect();
				}
			}
		}
		
		$this->setRedirect( 'index.php?option=com_belong&task=updates.install' );
		$this->redirect();
	}
	
	
	/**
	 * Retrieves the model for the controller
	 * @access		public
	 * @version		1.1.1
	 * @param		string		- $name: default to Update
	 * @param		string		- $prefix: default prefix to BelongModel
	 * 
	 * @return		BelongModelUpdate model
	 * @since		1.1.0
	 */
	public function getModel( $name = 'Update', $prefix = 'BelongModel') 
	{
		$model = parent::getModel( $name, $prefix, array( 'ignore_request' => true ) );
		return $model;
	}
	
	
	/**
	 * Task that performs that actual update procedure
	 * @access		public
	 * 
	 * @since		1.1.0
	 */
	public function install()
	{
		$model		=   $this->getModel();
		$updates	=   BelongUpdate :: getUpdateInformation( true );
		$overall	=   true;
		
		foreach ( $updates as $update ) {
			if ( $update['update']->hasupdate ) {
				$result = $model->install( $update );
				
				if (! $result ) {
					$model->cleanup ( $update );
					$overall = false;
				}
				else {
					$cache = JFactory::getCache( 'mod_menu' );
					$cache->clean();
				}
			}
		}
		
		$this->setRedirect( 'index.php?option=com_belong&controller=updates&view=updates' );
		$this->redirect();
	}
	
	
	/**
	 * Method to set the credentials for downloading from Go Higher
	 * @access		private
	 * @version		1.1.1
	 * @param		string		- $client: ftp usually
	 *
	 * @return		string containing credentials for Go Higher, true if they ARE NOT set, false if they are set but the local client needs FTP credentials to function
	 * @since		1.1.0
	 */
	private function setCredentials( $client ='ftp' )
	{
		jimport( 'joomla.application.component.helper' );
		jimport( 'joomla.client.helper' );
		
		$params	= JComponentHelper::getParams( 'com_belong' );
		$user	= $params->get( 'ghUsername', '' );
		$pass	= $params->get( 'ghPassword', '' );
		
		if ( $user == '' || $pass == '' ) return true;
		
		if (! JClientHelper :: hasCredentials( $client ) ) {
			return false;
		}
		
		return '?username=' . $user . '&password=' . $pass;
	}
}