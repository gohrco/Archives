<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.1 ( $Id: edit.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the edit layout for the product view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusion --*/
JHtml::_('behavior.tooltip');
/*-- File Inclusion --*/

$form	= $this->form->getFieldset( 'details' );
?>
<form action="<?php echo JRoute::_('index.php?option=com_belong&layout=edit&id='.(int) $this->item->id); ?>"
      method="post" name="adminForm" id="belong-form">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BELONG_PRODUCT_EDIT_RULEDETAILS' ); ?></legend>
		<ul class="adminformlist">
			<li><?php echo $form['jform_name']->label;echo $form['jform_name']->input;?></li>
			<li><?php echo $form['jform_pid']->label;echo $form['jform_pid']->input;?></li>
			<li><?php echo $form['jform_aid']->label;echo $form['jform_aid']->input; ?></li>
		</ul>
	</fieldset>
	
	<div>
		<input type="hidden" name="task" value="product.edit" />
		<input type="hidden" name="original_aid" id="original_aid" value="<?php echo $form['jform_aid']->value; ?>" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>

<script type="text/javascript">
<!--
	window.addEvent('domready', function() {
		var oid = document.getElementById( 'original_aid' ).value;
		getproductaddons( oid );
	});
// -->
</script>