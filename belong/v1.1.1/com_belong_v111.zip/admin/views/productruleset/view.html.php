<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.1 ( $Id: view.html.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the productruleset view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.view');
/*-- File Inclusions --*/

/**
 * Belong Productruleset View
 * @author		Steven
 * @version		1.1.1
 * 
 * @since		1.0.0
 */
class BelongViewProductruleset extends JView
{
	
	/**
	 * Display view
	 * @access		public
	 * @version		1.1.1
	 * @param		string		- $tpl: contains a template to overload with
	 * 
	 * @return		parent :: display()
	 * @since		1.0.0
	 */
	public function display($tpl = null) 
	{
		// get the Data
		$form = $this->get( 'Form' );
		$item = $this->get( 'Item' );
 
		// Check for errors.
		if ( count( $errors = $this->get( 'Errors' ) ) ) 
		{
			JError::raiseError( 500, implode('<br />', $errors ) );
			return false;
		}
		
		// Assign the Data
		$this->form = $form;
		$this->item = $item;
 		$isnew		= ( $this->item->id == 0 );
		
		BelongHelper :: addMedia( 'admin.main/css' );
		BelongHelper :: addToolbar( 'productruleset', $isnew );
		
		// Display the template
		parent::display( $tpl );
	}
}