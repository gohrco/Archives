<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.1 ( $Id: default.php 51 2012-04-10 01:55:03Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the default layout for the default view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusion --*/
jimport('joomla.html.pane');
JHTML::_('behavior.mootools');
JHTML::_('behavior.tooltip');
/*-- File Inclusion --*/

$lang	= &JFactory::getLanguage();
$mediapath	= JURI::root()."media/com_belong/icons/";
?>
<style type="text/css">

span.hasTip {
	text-align: right !important;
	font-weight: bold !important;
}

</style>

<div id="cpanel" style="width: 98%; clear: both; ">
	<div style="width: 500px; float: left; ">
	
		<?php foreach ($this->icondefs as $icon):
			$imglnk	= JRoute::_('index.php?option=' . JRequest::getCmd( 'option','com_belong' ) . ( is_null( $icon['controller'] ) ? '' : '&amp;controller=' . $icon['controller'] ) . ( is_null( $icon['task'] ) ? '' : '&amp;task=' . $icon['task'] ) . ( is_null( $icon['view'] ) ? '' : '&amp;view='.$icon['view'] ) );
			$imgsrc	= $mediapath . $icon['icon'];
		?>
		
		<div style="float: left; ">
			<div class="icon" id="<?php echo $icon['id']; ?>">
				<a href="<?php echo $imglnk; ?>" id="<?php echo $icon['id']; ?>_link">
					<img
						src="<?php echo $imgsrc; ?>"
						border="0" alt="<?php echo $icon['label']; ?>"
						id="<?php echo $icon['id']; ?>_img" />
					<span id="<?php echo $icon['id']; ?>_title"><?php echo $icon['label']; ?></span>
				</a>
			</div>
		</div>
		
		<?php endforeach; ?>
		
	</div>
	<div id="jpmodules" style="width: 450px; float: right;">
		<h1 style="text-align: center; width: 100%; margin: 0px; padding: 0px; " class="title"><?php echo JText::_("COM_BELONG"); ?></h1>
		<h4 style="text-align: center; width: 100%; margin: 0px; padding: 0px; " class="title"><?php echo JText::sprintf("COM_BELONG_DEFAULT_VIEW_TEXT_VERSION", '1.1.1' ); //$this->data->get( "Version" ) ); ?></h4>
		
		<ul class="adminformlist">
		<li>
			<span><?php echo JText::_( "COM_BELONG_DEFAULT_APIRESULT" ); ?></span><br/>
			<input id="apiresult" class="readonly apiresult <?php echo ( $this->status === true ? 'success' : 'error' ); ?>" type="text" readonly="readonly" value="<?php echo JText::_( $this->status === true ? 'COM_BELONG_DEFAULT_APIRESULT_SUCCESS'  : $this->status ); ?>" size="50" />
		</li>
		</ul>
		
		<?php if ( $this->status === true ) : ?>
		
		<p>&nbsp;</p>
		<span><?php echo JText::_( "COM_BELONG_DEFAULT_REMOTE_ENABLED" ); ?></span>
		<ul class="adminformlist">
		<li>
			<input
				id="apiremoteresult"
				class="readonly apiresult <?php echo ( $this->remote['enabled'] == 'Yes' ? 'success' : 'error' ); ?>"
				type="text"
				readonly="readonly"
				value="<?php echo JText::_( $this->remote['enabled'] == 'Yes'
						? 'COM_BELONG_DEFAULT_APIRESULT_REMOTE_ENABLED_YES' 
						: 'COM_BELONG_DEFAULT_APIRESULT_REMOTE_ENABLED_NO'
				); ?>"
				size="50" />
		</li>
		<li>
			<input
				id="apiapivers"
				class="readonly apiresult <?php echo ( $this->remote['apivers'] == '1.1.1' ? 'success' : 'error' ); ?>"
				type="text"
				readonly="readonly"
				value="<?php echo ( $this->remote['apivers'] == '1.1.1'
						? JText :: sprintf( 'COM_BELONG_DEFAULT_APIRESULT_REMOTE_APIVERS_OK', $this->remote['apivers'] )
						: JText :: sprintf( 'COM_BELONG_DEFAULT_APIRESULT_REMOTE_APIVERS_BAD', $this->remote['apivers'], '1.1.1' ) ); ?>" size="50" />
		</li>
		<li>
			<input
				id="apiapivers"
				class="readonly apiresult <?php echo ( $this->remote['modvers'] == '1.1.1' ? 'success' : 'error' ); ?>"
				type="text"
				readonly="readonly"
				value="<?php echo ( $this->remote['modvers'] == '1.1.1'
						? JText :: sprintf( 'COM_BELONG_DEFAULT_APIRESULT_REMOTE_MODVERS_OK', $this->remote['modvers'] )
						: JText :: sprintf( 'COM_BELONG_DEFAULT_APIRESULT_REMOTE_MODVERS_BAD', $this->remote['modvers'], '1.1.1' ) ); ?>" size="50" />
		</li>
		</ul>
		
		<?php endif; ?>
		
	</div>
</div>
<form action="index.php" method="post" name="adminForm">
<input type="hidden" name="option" value="com_belong" />
<input type="hidden" name="controller" value="default" />
<input type="hidden" name="task" value="" />
</form>

<script type="text/javascript">
window.addEvent( 'domready', checkForUpdates() );
</script>