<?php
/**
 * Belong
 * 
 * @package    WHMCS Package
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.1 ( $Id: belong.php 49 2012-04-10 01:33:49Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the main controller file for the backend of the Belong
 * 
 */

// Shortcuts are nicer
if (! defined( 'DS' ) ) define( 'DS', DIRECTORY_SEPARATOR );

// Be sure a task is set
if (! isset ( $task ) ) {
	$task = 'info';
}

// Create object
$belong = new Belong();
$belong->$task();

/**
 * Performs necessary actions for the Belong component in Joomla
 * @access		public
 * @version		1.1.1
 * 
 * @author		Steven
 * @since		1.0.0
 */
class Belong
{
	/**
	 * The default character set
	 * @var		string
	 */
	protected $charset	= "UTF-8";
	
	/**
	 * Stores conversion function existance
	 * @var		boolean
	 */
	protected $iconv	= false;
	
	/**
	 * Stores the revision date of this file
	 * @var		string
	 */
	protected $revdate	= '2012 May 17';
	
	/**
	 * The current version of this file
	 * @var		string
	 */
	protected $version = '1.1.1';
	
	
	/**
	 * Stores the version of WHMCS being run
	 * @var 	string
	 */
	protected $whmcsver	= null;
	
	/**
	 * Constructor
	 * @access		public
	 * @version		1.1.1
	 * 
	 * @since		1.0.0
	 */
	public function __construct()
	{
		define( 'BAPI', true );
		$this->_createObjectvars();
	}
	
	
	/**
	 * Method for updating files on the WHMCS side of things
	 * @access		public
	 * @version		1.1.1
	 * 
	 * @since		1.1.0
	 */
	public function belong_update()
	{
		global $step, $url;
		
		$rows	= array( 'result' => 'error', 'message' => 'test', 'supported' => 'true' );
		
		switch ( $step ) {
			default:
			case '1':
				
				// Check if we have a URL to read
				if ( empty( $url ) ) {
					$rows['message'] = 'COM_BELONG_UPDATES_FILE_WHMCS_UPDATEERROR_1A';
					break;
				}
				
				// Check if we can read the URL
				if (! file_get_contents( $url ) ) {
					$rows['message'] = 'COM_BELONG_UPDATES_FILE_WHMCS_UPDATEERRRO_1B';
					break;
				}
				
				$rows['result'] = 'success';
				
				break;
			case '2':
				
				global $file_source, $file_dest, $is_dir;
				
				$dest		= rtrim( WHMCS_ROOT, DS ) . str_replace( '.myb', '.php', str_replace( '::::', DS, $file_dest ) );
				
				
				// Check and see if we are creating a directory
				if ( $is_dir == 'true' ) {
					if (! is_dir( $dest ) ) {
						$result = @mkdir( $dest );
					}
				}
				// If not, we need to copy the file
				else {
					$result	= @copy( $file_source, $dest );
				}
				
				if ( $result !== false ) {
					$rows['result'] = 'success';
				}
				
				break;
			case '3':
				
				$query	= "UPDATE `tbladdonmodules` SET `value`='" . $this->version . "' WHERE `module`='belong' AND `setting` = 'version'";
				
				if ( mysql_query( $query ) ) {
					$rows['result'] = 'success';
				}
				
				break;
				
		}
		
		$this->_close( $rows );
	}
	
	
	/**
	 * Returns the specific information about this file
	 * @access		public
	 * @version		1.1.1
	 *	
	 * @since		1.0.0
	 */
	public function info()
	{
		require_once( WHMCS_ROOT . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR . 'addons' . DIRECTORY_SEPARATOR . 'belong' . DIRECTORY_SEPARATOR . 'factory.php' );
		
		$config = BFactory :: getConfig();
		
		$rows['enabled'] = $config->get( 'Enabled', false );
		$rows['modvers'] = $config->get( 'version', '1.0.0' );
		$rows['apivers'] = $this->version;
		$rows['revdate'] = $this->revdate;
		$rows['platver'] = $this->whmcsver;
		
		$this->_close( $rows );
	}
	
	
	/**
	 * Method for retrieving permission groups in WHMCS
	 * @access		public
	 * @version		1.1.1
	 * 
	 * @since		1.0.5
	 */
	public function getpermissiongroups()
	{
		$rows	= array();
	
		$query	=   "SELECT CONCAT( 'whmcs|', g.id ) as `id`, g.groupname as `name` FROM `tblclientgroups` g ORDER BY `groupname`";
		$result	= mysql_query( $query );
		
		$rows['groups'][]	= array( 'value' => 'whmcs|0', 'text' => '(Leave Unset)' );
		
		while ( $row = mysql_fetch_assoc( $result ) ) {
			$rows['groups'][] = array( 'value' => $row['id'], 'text' => $row['name'] );
		}
		
		$this->_close( $rows );
	}
	
	
	/**
	 * Returns the avialable products for selection in the backend
	 * @access		public
	 * @version		1.1.1
	 * 
	 * @since		1.0.0
	 */
	public function getproductlist()
	{
		global $hidden;
		
		$rows	= array();
		
		$where = '';
		if ( $hidden == '0' ) {
			$where	= " WHERE p.hidden <> 'on' AND (	( p.stockcontrol <> 'on' )
							OR
							( p.stockcontrol = 'on' AND p.qty > 0 )
							)";
		}
		
		$query	=   "SELECT p.id as `id`, 
							p.name as `name`, 
							p.servertype as `moduletype`, 
							g.name as `group`
					FROM tblproducts p
							INNER JOIN tblproductgroups g ON p.gid = g.id" . $where;
		
		$result	= mysql_query( $query );
		
		while ( $row = mysql_fetch_assoc( $result ) )
		{
			$rows['products'][] = $row;
		}
		
		if ( empty( $rows ) )
		{
			$rows['result']		= 'error';
			$rows['message']	= "There are no products to retrieve";
		}
		$this->_close( $rows );
	}
	
	
	/**
	 * Returns the available product addons for a requested product id
	 * @access		public
	 * @version		1.1.1
	 * 
	 * @since		1.0.0
	 */
	public function getproductaddons()
	{
		global $pid;
		
		$query	=	"SELECT *
					 FROM `tbladdons`";
					 
		$result	= mysql_query( $query );
		$rows	=   array();
		
		while( $row = mysql_fetch_assoc( $result ) ) {
			$pids	= explode(',', $row['packages'] );
			
			if ( in_array( $pid, $pids ) ) {
				$rows['addons'][] = array( 'id' => $row['id'], 'name' => $row['name'] );
			}
		}					
		
		
		$query	=   "SELECT p.configoption7
					 FROM `tblproducts` p
					 WHERE p.id = {$pid}
					 	AND p.servertype = 'licensing'";
		
		$result	= mysql_query( $query );
		
		if( $result ) {
			$support	= mysql_result( $result, 0 );
			
			if (! empty( $support ) ) {
				$parts		= explode( "|", $support );
				$id			= array_shift( $parts );
				
				$add_to_array	= true;
				foreach ( $rows['addons'] as $addon ) {
					if ( $addon['id'] == $id ) {
						$add_to_array = false;
						break;
					}
				}
				
				if ( $add_to_array ) {
					$rows['addons'][] = array( 'id' => $id, 'name' => implode( "|", $parts ) );
				}
			}
		}
		
		if ( empty( $rows ) ) {
			$rows['message']	= "- No product addons available -";
		}
		$this->_close( $rows );
	}
	
	
	/**
	 * Gets all the users with the products for cron
	 * @access		public
	 * @version		1.1.1
	 * 
	 * @since		1.0.0
	 */
	public function getusers()
	{
		$rows	= array();
		$query	= "SELECT c.id, c.email FROM tblclients c ORDER BY email";
		$result	= mysql_query( $query );
		
		while ( $row = mysql_fetch_assoc( $result ) ) {
			$prods	= $this->getuserproducts( $row['id'] );
			
			if ( $prods['result'] == 'error' ) continue;
			
			$rows['users'][] = array( 'id' => $row['id'], 'email' => $row['email'], 'products' => $prods['products'] );
		}
		
		if ( empty( $rows ) ) {
			$rows['result']		= 'error';
			$rows['message']	= "There are no clients found to retrieve";
		}
		
		$this->_close( $rows );
	}
	
	
	/**
	 * Gets a user products
	 * @access		public
	 * @version		1.1.1
	 * @param		int		- $internalid: if being called internally, pass id
	 * 
	 * @return		array if internally called else null
	 * @since		1.0.0
	 */
	public function getuserproducts( $internalid = null )
	{
		if ( $internalid == null ) {
			global $clientid;
		}
		else {
			$clientid = $internalid;
		}
		
		$rows = array();
		
		$query	= "	SELECT h.id as id, h.domainstatus as status, h.packageid as pid
						FROM tblhosting h
						WHERE h.userid = {$clientid}";
		
		$result	= mysql_query( $query );
		
		while( $row = mysql_fetch_assoc( $result ) ) {
			$row['addons'] = array();
			
			$query = "	SELECT o.id as id, h.packageid as pid, o.status as status, o.addonid as aid
						FROM tblhosting h
							INNER JOIN tblhostingaddons o ON ( h.id = o.hostingid )
						WHERE h.userid = {$clientid}
							AND o.hostingid = {$row['id']}";
			
			$sesult = mysql_query( $query );
			
			while ( $sow = mysql_fetch_assoc( $sesult ) ) {
				$row['addons'][] = $sow;
			}
			
			$rows['products'][]	= $row;
		}
		
		if ( empty( $rows ) )
		{
			$rows['result']		= 'error';
			$rows['message']	= "There are no product addons to retrieve";
		}
		
		if ( $internalid == null ) {
			$this->_close( $rows );
		}
		else {
			return $rows;
		}
	}
	
	
	/**
	 * Method for updating a client group for a client
	 * @access		public
	 * @version		1.1.1
	 * 
	 * @since		1.0.5
	 */
	public function updateclientgroup()
	{
		global $email, $groupid;
		$client	= localAPI( 'getclientsdetails', array( 'email' => $email ) );
		$rows	= array();
		
		if (! isset( $client['userid'] ) ) {
			$rows['result']		= 'error';
			$rows['message']	= "No user could be found with email `{$email}`";
			return $this->_close( $rows );
		}
		
		$userid	= $client['userid'];
		
		$query	= "UPDATE `tblclients` SET `groupid`=" . (int) $groupid . " WHERE `id`=" . (int) $userid;
		
		if ( mysql_query( $query ) ) {
			$rows['result']		= 'success';
			$rows['message']	= "User successfully updated!";
		}
		else {
			$rows['result']		= 'error';
			$rows['message']	= "Unable to update the user group for `{$email}`";
		}
		
		$this->_close( $rows );
	}
	
	
	/**
	 * Closes the application
	 * @access		private
	 * @version		1.1.1
	 * @param		mixed		- $data: the data to send back to the calling application
	 * @param		boolean		- $first: if true this is the first run (allows recursion)
	 * 
	 * @since		1.0.0
	 */
	private function _close( $data, $first = true )
	{
		if ( $this->iconv ) {
			foreach ( $data as $key => $value ) {
				if ( is_array( $value ) ) {
					$value = $this->_close( $value, false );
				} else {
					$data[$key] = iconv( "{$this->charset}", "UTF-8//TRANSLIT", $value );
				}
			}
		}
		
		if (! $first ) return $data;
		
		if (! isset( $data['result'] ) ) $data['result'] = 'success';
		echo json_encode( $data ); 
	}
	
	
	/**
	 * Retrieves the character set that is used in WHMCS
	 * @access		private
	 * @version		1.1.1
	 * 
	 * @since		1.0.0
	 */
	private function _createObjectvars()
	{
		$config	= array( "Charset", "Version" );
		$values	= array();
		
		foreach ( $config as $c ) {
			$query	= "SELECT `value` FROM `tblconfiguration` WHERE `setting` = '{$c}'";
			$result	= mysql_query( $query );
			while ( $row = mysql_fetch_assoc( $result ) ) {
				$values[$c] = $row['value'];
			}
		}
		
		$this->charset	= strtoupper( $values["Charset"] );
		$this->whmcsver	= $values["Version"];
		$this->iconv = ( function_exists( "iconv" ) ? ( $this->charset == "UTF-8" ? false : true ) : false );
		
		return;
	}
	
	
	/**
	 * UTF8 encodes a string
	 * @access		private
	 * @version		1.1.1
	 * @param		string		- $str: string to encode
	 * 
	 * @return		utf8 encoded string
	 * @since		1.0.0
	 */
	private function _utf8_ensure( $str )
	{
		return $this->_seems_utf8($str)? $str: utf8_encode($str);
	}
	
	
	/**
	 * Tests to see if a string is utf8 encoded
	 * @access		private
	 * @version		1.1.1
	 * @param		string		- $Str: string to check
	 * 
	 * @return		boolean - true if utf8 false if not
	 * @since		1.0.0
	 */
	private function _seems_utf8( $Str )
	{
		for ($i=0; $i<strlen($Str); $i++)
		{
			if ( ord($Str[$i]) < 0x80 ) continue; # 0bbbbbbb
			elseif ( (ord($Str[$i]) & 0xE0) == 0xC0 ) $n=1; # 110bbbbb
			elseif ( (ord($Str[$i]) & 0xF0) == 0xE0 ) $n=2; # 1110bbbb
			elseif ( (ord($Str[$i]) & 0xF8) == 0xF0 ) $n=3; # 11110bbb
			elseif ( (ord($Str[$i]) & 0xFC) == 0xF8 ) $n=4; # 111110bb
			elseif ( (ord($Str[$i]) & 0xFE) == 0xFC ) $n=5; # 1111110b
			else return false; # Does not match any model
				
			for ( $j=0; $j<$n; $j++ )
			{ # n bytes matching 10bbbbbb follow ?
				if ( (++$i == strlen($Str)) || ((ord($Str[$i]) & 0xC0) != 0x80) )
				return false;
			}
		}
		return true;
	}
}
?>