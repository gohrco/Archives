<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.3 ( $Id: controller.php 73 2012-09-20 15:06:02Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the main controller file for Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or exit('No direct script access allowed');
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.controller');
require_once( JPATH_COMPONENT_ADMINISTRATOR.DIRECTORY_SEPARATOR.'helper.php' );
/*-- File Inclusions --*/

/**
 * Belong Controller class object
 * @version		1.1.3
 * 
 * @since		1.0.0
 * @author		Steven
 */
class BelongController extends BelongCtrlLegacy
{
	/**
	 * Displays the front end, setting the default view if not set.
	 * @access		public
	 * @version		1.1.3
	 * 
	 * @since		1.0.0
	 */
	public function display()
	{
		// If the view hasn't been set, set it to default
		if (is_null(JRequest::getVar( 'view'))) JRequest::setVar('view', 'default' );
		
		// Call up the parent display task
		parent::display();
	}
}