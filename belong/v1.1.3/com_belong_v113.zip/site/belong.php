<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.3 ( $Id: belong.php 73 2012-09-20 15:06:02Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the main file for Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die('Restricted access');

// Require the base controller
require_once (JPATH_COMPONENT.DIRECTORY_SEPARATOR.'controller.php');
require_once( JPATH_COMPONENT_ADMINISTRATOR.DIRECTORY_SEPARATOR.'class.api.php' );
require_once( JPATH_COMPONENT_ADMINISTRATOR.DIRECTORY_SEPARATOR.'helper.php' );

// Require specific controller if requested
$controller = JRequest::getWord('controller', 'api');
require_once (JPATH_COMPONENT.DIRECTORY_SEPARATOR.'controllers'.DIRECTORY_SEPARATOR.$controller.'.php');

// Create the controller
$classname	= 'BelongController'.$controller;
$controller = new $classname();

// Perform the Request task
$controller->execute( JRequest::getWord('task'));

// Redirect if set by the controller
$controller->redirect();