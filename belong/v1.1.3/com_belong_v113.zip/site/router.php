<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.3 ( $Id: router.php 21 2011-10-15 02:21:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the router file for Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or exit('No direct script access allowed');
/*-- Security Protocols --*/

/**
 * Router for building SEF link
 * @version		1.1.3
 * @param		array		$query - contains the query items of the url
 * 
 * @return		array of segments in order of assembly for the url
 * @since		1.0.0
 */
function BelongBuildRoute(&$query)
{
	$segments = array();
	
	return $segments;
}


/**
 * Parses the url for query items
 * @version		1.1.3
 * @param		array		$segments - items pulled in order from the URL
 * 
 * @return		array containing query items in key => value format
 * @since		1.0.0
 */
function BelongParseRoute($segments)
{
	$vars = array();
	
	return $vars;
}
