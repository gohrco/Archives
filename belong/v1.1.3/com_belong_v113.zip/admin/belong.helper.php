<?php
/**
* Belong
*
* @package    Belong
* @copyright  2012 Go Higher Information Services.  All rights reserved.
* @license    GNU General Public License version 2, or later
* @version    1.1.3 ( $Id: belong.helper.php 44 2012-03-08 22:05:12Z steven_gohigher $ )
* @author     Go Higher Information Services
* @since      1.0.4
*
* @desc       This file is a quick utility helper for Belong
*
*/

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );

/*-- Localscope import --*/
require_once( dirname(__FILE__) . DS . 'helper.php' );


if (! function_exists( 'simpleXMLToArray' ) ) {
	function simpleXMLToArray( SimpleXMLElement $xml, $attributesKey = null, $childrenKey = null, $valueKey = null )
	{
		if ( $childrenKey && ! is_string( $childrenKey ) ) {
			$childrenKey = '@children';
		}

		if ( $attributesKey && ! is_string( $attributesKey ) ) {
			$attributesKey = '@attributes';
		}

		if ( $valueKey && ! is_string( $valueKey ) ) {
			$valueKey = '@values';
		}

		$return	= array();
		$name	= $xml->getName();
		$_value	= trim((string)$xml);

		if (! strlen( $_value ) ) {
			$_value = null;
		}

		if ( $_value !== null ) {
			if ( $valueKey ) {
				$return[$valueKey] = $_value;
			}
			else {
				$return = $_value;
			}
		}

		$children	= array();
		$first		= true;

		foreach ( $xml->children() as $elementName => $child )
		{
			$value	= simpleXMLToArray( $child, $attributesKey, $childrenKey, $valueKey );

			if ( isset( $children[$elementName] ) ) {
				if ( is_array( $children[$elementName] ) ) {
					if ( $first ) {
						$temp	= $children[$elementName];
						unset( $children[$elementName] );
						$children[$elementName][]	= $temp;
						$first	= false;
					}
					$children[$elementName][]	= $value;
				}
				else {
					$children[$elementName]	= array( $children[$elementName], $value );
				}
			}
			else {
				$children[$elementName]	= $value;
			}
		}

		if ( $children ) {
			if ( $childrenKey ) {
				$return[$childrenKey] = $children;
			}
			else {
				$return	= array_merge( $return, $children );
			}
		}

		$attributes	= array();
		foreach ( $xml->attributes() as $name => $value )
		{
			$attributes[$name]	= trim($value);
		}

		if ( $attributes ) {
			if ( $attributesKey ) {
				$return[$attributesKey] = $attributes;
			}
			else {
				$return	= array_merge( $return, $attributes );
			}
		}

		return $return;
	}

}