<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.3 ( $Id: edit25.php 73 2012-09-20 15:06:02Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the edit layout for the productruleset view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusion --*/
JHtml::_('behavior.tooltip');
/*-- File Inclusion --*/

$form	= $this->form->getFieldset( 'details' );
?>
<form action="<?php echo JRoute::_('index.php?option=com_belong&layout=edit&id=' . (int) $this->item->id ); ?>"
      method="post" name="adminForm" id="belong-form">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_BELONG_PRODUCTRULESET_EDIT_RULEDETAILS' ); ?></legend>
		<ul class="adminformlist">
			<li><?php echo $form['jform_pid']->label;echo $form['jform_pid']->input;?></li>
		</ul>
		
		<ul class="adminformlist">
			<li><?php echo $form['jform_rid']->label;echo $form['jform_rid']->input;?></li>
		</ul>
	</fieldset>
	
	<div>
		<input type="hidden" name="task" value="productruleset.edit" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>