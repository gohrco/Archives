<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.3 ( $Id: default.php 26 2011-10-15 21:53:36Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the default layout for the api connection view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusion --*/
JHTML::_('behavior.tooltip');
JHTML::_('behavior.formvalidation');
/*-- File Inclusion --*/

?>

<script type="text/javascript">
	Joomla.submitbutton = function( task ) {
		if ( document.formvalidator.isValid(document.id('item-form'))) {
			
			Joomla.submitform(task, document.getElementById('item-form'));
		} else {
			alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED'));?>');
		}
	}
</script>

<form action="index.php" method="post" name="adminForm" id="item-form">

<div id="adminInput">
	<table class="admintable" width="675px" border="0">
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				<?php echo JText::_( "COM_BELONG_APICNXN_APIURL_LABEL" ); ?>
				</div>
				<div class="paramdesc">
				<?php echo JText::_( "COM_BELONG_APICNXN_APIURL_DESC" ); ?>
				</div>
			</td>
			<td rowspan="11" width="220px" valign="top">
				<div id="apistatus">
					<div id="apistatusimg"></div>
					<div id="apistatusmsg" style="width: 200px; margin: 0px auto; font-size: small; font-weight: bold; clear: both; padding: 10px; text-align: center; "></div>
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="text" name="apiurl" value="<?php echo $this->params->get( 'ApiUrl' ); ?>" size="40" style="font-size: 14px; " onChange="checkApicnxn();" id="apiurl" />
			</td>
		<tr><td>&nbsp;</td></tr>
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				<?php echo JText::_( "COM_BELONG_APICNXN_APIUSERNAME_LABEL" ); ?>
				</div>
				<div class="paramdesc">
				<?php echo JText::_( "COM_BELONG_APICNXN_APIUSERNAME_DESC" ); ?>
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="text" name="apiusername" value="<?php echo $this->params->get( 'ApiUsername' ); ?>" size="40" style="font-size: 14px; " id="apiusername" onChange="checkApicnxn();" />
			</td>
		</tr>
		<tr><td>&nbsp;</td></tr>
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				<?php echo JText::_( "COM_BELONG_APICNXN_APIPASSWORD_LABEL" ); ?>
				</div>
				<div class="paramdesc">
				<?php echo JText::_( "COM_BELONG_APICNXN_APIPASSWORD_DESC" ); ?>
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area required" type="password" name="apipassword" value="<?php echo $this->params->get( 'ApiPassword' ); ?>" size="40" style="font-size: 14px; " id="apipassword" onChange="checkApicnxn();" />
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td class="paramlabel">
				<div class="paramname">
				<?php echo JText::_( "COM_BELONG_APICNXN_APIACCESSKEY_LABEL" ); ?>
				</div>
				<div class="paramdesc">
				<?php echo JText::_( "COM_BELONG_APICNXN_APIACCESSKEY_DESC" ); ?>
				</div>
			</td>
		</tr>
		<tr>
			<td class="paramlist_value">
				<input class="text_area" type="text" name="apiaccesskey" value="<?php echo $this->params->get( 'ApiAccesskey' ); ?>" size="40" style="font-size: 14px; " id="apiaccesskey" onChange="checkApicnxn();" />
			</td>
		</tr>
	</table>
</div>
<input type="hidden" name="option" value="com_belong" />
<input type="hidden" name="apiconnection" id="apiconnection" value="0" />
<input type="hidden" name="task" value="apicnxn.save" />
<input type="hidden" id="apistatusmsgdefault" value="<?php echo JText::_( "COM_BELONG_APICNXN_AJAX_STATUSDEFAULT" ); ?>" />
</form>
<script language="javascript">
window.onload = checkApicnxn();
</script>