<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.3 ( $Id: view.html.php 73 2012-09-20 15:06:02Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the api connection view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.view');
jimport( 'joomla.application.component.helper' );
/*-- File Inclusions --*/

/**
 * Belong Apicnxn View
 * @author		Steven
 * @version		1.1.3
 * 
 * @since		1.0.0
 */
class BelongViewApicnxn extends BelongViewExt
{
	
	/**
	 * Display view
	 * @access		public
	 * @version		1.1.3
	 * @param		string		- $tpl: contains a template to overload with
	 * 
	 * @return		parent :: display()
	 * @since		1.0.0
	 */
	public function display($tpl = null) 
	{
		BelongHelper :: addMedia( 'admin.main.' . $this->_myvers . '/css' );
		BelongHelper :: addMedia( 'admin.ajax.' . $this->_myvers . '/css' );
		BelongHelper :: addMedia( 'admin.ajax.' . $this->_myvers . '/js' );
		BelongHelper :: addToolbar( 'apicnxn', null );
		
		$this->params	=	JComponentHelper::getParams( 'com_belong' );
		
		// Display the template
		parent::display( $tpl );
	}
}