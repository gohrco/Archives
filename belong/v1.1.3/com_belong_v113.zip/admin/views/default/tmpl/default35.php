<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.3 ( $Id: default.php 51 2012-04-10 01:55:03Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the default layout for the default view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusion --*/
jimport('joomla.html.pane');
JHTML::_('behavior.tooltip');
/*-- File Inclusion --*/

$lang	= &JFactory::getLanguage();
$mediapath	= JURI::root()."media/com_belong/icons/";

$reset		= 4;
$cnt		= 0;
?>
<style type="text/css">

span.hasTip {
	text-align: right !important;
	font-weight: bold !important;
}

</style>

<div class="row-fluid">
	<div class="span1"> </div>
	<div class="span6">
		<div class="row-fluid">
			<div class="span12 cpanel">
				<?php foreach ( $this->icondefs as $icon ) :
				$cnt++;
				$link	= JRoute::_('index.php?option=' . BelongHelper :: getCmd( 'option', 'com_belong' ) . ( is_null( $icon['controller']) ? '' : '&amp;controller='.$icon['controller']) . (is_null($icon['task']) ? '' : '&amp;task='.$icon['task']) . ( is_null($icon['view']) ? '' : '&amp;view='.$icon['view'] ));
				$imgsrc	= $mediapath . $icon['icon'];
				?>
				<a href="<?php echo $link; ?>" class="btn span1">
					<img src="<?php echo $imgsrc; ?>" border="0" alt="<?php echo $icon['label']; ?>" id="<?php echo $icon['id']; ?>_img" />
					<span class="linktitle" id="<?php echo $icon['id']; ?>_title"><?php echo $icon['label']; ?></span>
				</a>
				<?php 
				if ( $cnt == $reset ) : ?>
				</div></div>
				<div class="row-fluid"><div class="span12 cpanel">
				<?php $cnt = 0; ?>
				<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	
	<div class="span5">
		
		<div class="row-fluid">
			<div class="span12">
				<h1><?php echo JText::_("COM_BELONG"); ?> <small><?php echo JText::sprintf("COM_BELONG_DEFAULT_VIEW_TEXT_VERSION", BELONG_VERS ); ?></small></h1>
				<p>&nbsp;</p>
		
				<div class="form-horizontal">
					<div class="control-group">
						<input id="apiresult" class="readonly apiresult <?php echo ( $this->status === true ? 'success' : 'error' ); ?>" type="text" readonly="readonly" value="<?php echo JText::_( $this->status === true ? 'COM_BELONG_DEFAULT_APIRESULT_SUCCESS'  : $this->status ); ?>" size="50" />
					</div>
					
					<?php if ( $this->status === true ) : ?>
					<div class="control-group">
							<input
								id="apiremoteresult"
								class="readonly apiresult <?php echo ( $this->remote['enabled'] == 'Yes' ? 'success' : 'error' ); ?>"
								type="text"
								readonly="readonly"
								disabled="disabled"
								value="<?php echo JText::_( $this->remote['enabled'] == 'Yes'
										? 'COM_BELONG_DEFAULT_APIRESULT_REMOTE_ENABLED_YES' 
										: 'COM_BELONG_DEFAULT_APIRESULT_REMOTE_ENABLED_NO'
								); ?>"
								size="50" />
							<input
								id="apiapivers"
								class="readonly apiresult <?php echo ( $this->remote['apivers'] == '1.1.3' ? 'success' : 'error' ); ?>"
								type="text"
								readonly="readonly"
								value="<?php echo ( $this->remote['apivers'] == BELONG_VERS
										? JText :: sprintf( 'COM_BELONG_DEFAULT_APIRESULT_REMOTE_APIVERS_OK', $this->remote['apivers'] )
										: JText :: sprintf( 'COM_BELONG_DEFAULT_APIRESULT_REMOTE_APIVERS_BAD', $this->remote['apivers'], '1.1.3' ) ); ?>" size="50" />
							<input
								id="apiapivers"
								class="readonly apiresult <?php echo ( $this->remote['modvers'] == '1.1.3' ? 'success' : 'error' ); ?>"
								type="text"
								readonly="readonly"
								value="<?php echo ( $this->remote['modvers'] == '1.1.3'
										? JText :: sprintf( 'COM_BELONG_DEFAULT_APIRESULT_REMOTE_MODVERS_OK', $this->remote['modvers'] )
										: JText :: sprintf( 'COM_BELONG_DEFAULT_APIRESULT_REMOTE_MODVERS_BAD', $this->remote['modvers'], '1.1.3' ) ); ?>" size="50" />
						</div>
					</div>
						
					<?php endif; ?>
					
				</div>
			</div>
		</div>
	</div>
</div>

<form action="index.php" method="post" name="adminForm">
<input type="hidden" name="option" value="com_belong" />
<input type="hidden" name="controller" value="default" />
<input type="hidden" name="task" value="" />
</form>

<script type="text/javascript">
	jQuery.ready( checkForUpdates() );
</script>