<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.3 ( $Id$ )
 * @author     Go Higher Information Services
 * @since      1.1.0
 * 
 * @desc       This is the updates view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.view' );
include_once( JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'helper.php' );
include_once( JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'update' . DIRECTORY_SEPARATOR . 'belongupdate.php' );
/*-- File Inclusions --*/

/**
 * Belong Updates View
 * @author		Steven
 * @version		1.1.3
 * 
 * @since		1.1.0
 */
class BelongViewUpdates extends BelongViewExt
{
	
	/**
	 * Display view
	 * @access		public
	 * @version		1.1.3
	 * @param		string		- $tpl: contains a template to overload with
	 * 
	 * @return		parent :: display()
	 * @since		1.0.0
	 */
	function display( $tpl = null )
	{
		$updates	=   BelongUpdate :: getSortedList( true );
		
		// Retrieve ACL permitted actions
		$canDo	= BelongHelper :: getActions();
		
		BelongHelper :: addMedia( 'admin.main.' . $this->_myvers . '/css' );
		BelongHelper :: addToolbar( 'updates', null, $canDo );
		
		$this->updates		= $updates;
		
		parent::display($tpl);
	}
	
	
	/**
	 * Displays the proces view
	 * @access		public
	 * @version		1.1.3
	 * @param		string		- $tpl: conains the template to overload with
	 * 
	 * return		parent :: display()
	 * @since		1.1.0
	 */
	function process( $tpl = null )
	{
		$this->setLayout( 'process' );
		
		parent::display($tpl);
	}
}