<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.3 ( $Id: view.html.php 73 2012-09-20 15:06:02Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the email view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.view');
/*-- File Inclusions --*/

/**
 * Belong Email View
 * @author		Steven
 * @version		1.1.3
 * 
 * @since		1.0.0
 */
class BelongViewEmail extends BelongViewExt
{
	
	/**
	 * Display view
	 * @access		public
	 * @version		1.1.3
	 * @param		string		- $tpl: contains a template to overload with
	 * 
	 * @return		parent :: display()
	 * @since		1.0.0
	 */
	public function display($tpl = null) 
	{
		$layout	= JRequest :: getVar( 'layout', 'default' . $this->_myvers );
		
		switch ( $layout ) :
		
		case 'results25' :
		case 'results35' :
			
			$debug = BelongDebug :: getInstance();
			$this->results = $debug->send();
			
			break;
			
		case 'find25' :
		case 'find35' :
			
			$userdata	= $this->get( 'FounduserData' );
			
			// If we received data back then break for this layout
			if ( $userdata ) {
				$this->userdata = $userdata;
				break;
			}
			// Instead we received an error or a problem was found so go back
			else {
				$this->setLayout( 'default' . $this->_myvers );
				$layout = 'default';
			}
			
		case 'default25':
		case 'default35':
		default:
			
			// get the Data
			$form = $this->get( 'Form' );
			
			// Check for errors.
			if ( count( $errors = $this->get( 'Errors' ) ) ) {
				JError::raiseError( 500, implode('<br />', $errors ) );
				return false;
			}
			
			// Assign the Data
			$this->form = $form;
			
			break;
			
		endswitch;
		
		BelongHelper :: addMedia( 'admin.main.' . $this->_myvers . '/css' );
		BelongHelper :: addToolbar( 'email', $layout );
		
		// Display the template
		parent::display( $tpl );
	}
}