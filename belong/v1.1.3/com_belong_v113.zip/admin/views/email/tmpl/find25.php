<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.3 ( $Id: find25.php 73 2012-09-20 15:06:02Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the find layout for the email view file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusion --*/
JHtml::_('behavior.tooltip');
/*-- File Inclusion --*/

$joomla = $this->userdata['joomla'];
$whmcs	= $this->userdata['whmcs'];

if ( isset( $joomla->id ) && isset( $whmcs->id ) ) {
	$imglnk	= JRoute::_('index.php?option=com_belong&task=email.run&wid=' . $whmcs->clientid . '&jid=' . $joomla->id );
	$imgsrc	= JURI::root().'media/com_belong/icons/ajax-success.png';
	$lnktxt = JText::_( 'COM_BELONG_EMAIL_LINK_YES' );
}
else {
	$imglnk = JRoute::_( 'index.php?option=com_belong' );
	$imgsrc = JUri :: root() . 'media/com_belong/icons/ajax-error.png';
	$lnktxt = JText::_( 'COM_BELONG_EMAIL_LINK_NO' );
}
?>

<table class="adminlist">
	
	<!-- BEGIN BODY -->
	
	<tbody>
		
		<tr>
			<td width="40%" align="center" valign="top">
				<h2><?php echo $joomla->name; ?></h2>
				<h4><?php echo $joomla->username; ?></h4>
				<h4><?php echo $joomla->email; ?></h4>
			</td>
			<td width="40%" align="center" valign="top">
				<h2><?php echo $whmcs->firstname . ' ' . $whmcs->lastname; ?></h2>
				<h4><?php echo $whmcs->email; ?></h4>
			</td>
			<td align="center">
				<div id="cpanel" style="width: 98%; clear: both; ">
					<div style="float: left; ">
						<div style="float: left; ">
							<div class="icon">
								<a href="<?php echo $imglnk; ?>">
									<img
										src="<?php echo $imgsrc; ?>"
										border="0" alt="<?php echo $lnktxt; ?>" />
									<span><?php echo $lnktxt; ?></span>
								</a>
							</div>
						</div>
					</div>
				</div>
			</td>
		</tr>
		
	</tbody>
	
	<!-- END BODY -->
	<!-- BEGIN HEADER -->
	
	<thead>
		
		<tr>
			<th>
				<?php echo JText::_( 'COM_BELONG_EMAIL_HEADING_JOOMLA' ); ?>
			</th>
			<th>
				<?php echo JText::_( 'COM_BELONG_EMAIL_HEADING_WHMCS' ); ?>
			</th>
			<th>
				&nbsp;
			</th>
		</tr>
		
	</thead>
	
	<!-- END HEADER -->
	<!-- BEGIN FOOTER -->
	
	<tfoot>
		
		<tr>
			<td colspan="3">&nbsp;</td>
		</tr>
		
	</tfoot>
	
	<!-- END FOOTER -->
	
</table>

<div>
	<form action="<?php echo JRoute::_('index.php?option=com_belong'); ?>" method="post" name="adminForm" id="belong-form" >
		<input type="hidden" name="task" value="email.process" />
		<?php echo JHtml::_('form.token'); ?>
	</form>
</div>