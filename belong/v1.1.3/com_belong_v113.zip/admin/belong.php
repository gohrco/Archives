<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.3 ( $Id: belong.php 73 2012-09-20 15:06:02Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the main file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
define( 'BELONG_VERS', '1.1.3' );

if (! JFactory::getUser()->authorise( 'core.manage', 'com_belong' ) ) { 
	return JError::raiseWarning( 404, JText::_('JERROR_ALERTNOAUTHOR' ) );
}
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.controller');
require_once( JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'helper.php' );
require_once( JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'controller.php' );
/*-- File Inclusions --*/

$ctr_name = 'BelongController';

if( $ctr_file = JRequest :: getCmd ( 'controller', JRequest :: getCmd ( 'task', false ) ) ) {
	// Hnadle controller.task
	if ( strpos( $ctr_file, '.' ) !== false ) {
		$parts	= explode( '.', $ctr_file );
		$ctr_file = array_shift( $parts );
		
		JRequest :: setVar( 'task', implode( '.', $parts ) );
	}
	
	$path = JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'controllers' . DIRECTORY_SEPARATOR . $ctr_file . '.php';
	if ( file_exists( $path ) ) {
		require_once $path;
		$ctr_name	.= ucfirst( $ctr_file );
	}
}

$controller = new $ctr_name();
$controller->execute( JRequest::getVar( 'task' ) );
$controller->redirect();