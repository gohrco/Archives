<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.3 ( $Id: rule.php 73 2012-09-20 15:06:02Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the rule controller file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die('Restricted access');
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.controllerform');
/*-- File Inclusions --*/

/**
 * Belong Rule Controller
 * @author		Steven
 * @version		1.1.3
 * 
 * @since		1.0.0
 */
class BelongControllerRule extends BelongCtrlForm
{
	
}