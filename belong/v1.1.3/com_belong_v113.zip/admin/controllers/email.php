<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2012 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.1.3 ( $Id: email.php 73 2012-09-20 15:06:02Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the email controller for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined('_JEXEC') or die('Restricted access');
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport( 'joomla.application.component.controllerform' );
jimport( 'joomla.user.helper' );
/*-- File Inclusions --*/

/**
 * Belong Email Controller
 * @author		Steven
 * @version		1.1.3
 * 
 * @since		1.0.0
 */
class BelongControllerEmail extends BelongControllerForm
{
	/**
	 * Find task
	 * @access		public
	 * @version		1.1.3
	 * 
	 * @since		1.0.0
	 */
	public function find()
	{
		JRequest :: setVar( 'view', 'email' );
		JRequest :: setVar( 'layout', 'find' );
		
		parent::display();
	}
	
	
	/**
	 * Runs the ruleset against the selected user
	 * @access		public
	 * @version		1.1.3
	 * 
	 * @since		1.0.0
	 */
	public function run()
	{
		JRequest :: setVar( 'view', 'email' );
		JRequest :: setVar( 'layout', 'results' );
		
		// Handle rulesets
		BelongHelper :: runRulesets( JRequest :: getVar( 'wid', 0 ), 'whmcs' );
		
		parent::display();
	}
}