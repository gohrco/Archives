<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla modelform library
jimport('joomla.application.component.modellist');
 

class BelongModelProductrulesets extends JModelList
{
	protected function getListQuery()
	{
		// Create a new query object.		
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		
		$query->select( 	'pr.id, p.name as product_name, r.name as rule_name, pr.priority, pr.published' )
				->from(		'#__belong_productrulesets pr' )
				->innerJoin(	'#__belong_rules r ON r.id = pr.rid' )
				->innerJoin(	'#__belong_products p ON p.id = pr.pid' )
				->order( 'priority' );
				
		
		return $query;
	}
}