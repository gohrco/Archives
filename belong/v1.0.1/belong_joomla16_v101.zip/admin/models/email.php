<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla modelform library
jimport('joomla.application.component.modeladmin');

class BelongModelEmail extends JModelAdmin
{
	
	
	public function getFounduserData()
	{
		$form	= JRequest::getVar( 'jform', array() );
		
		if (! isset( $form['email'] ) ) {
			return false;
		}
		
		$email	= $form['email'];
		
		// Joomla user first...
		$db = JFactory :: getDbo();
		
		$query	= 'SELECT id FROM #__users WHERE email = ' . $db->Quote( $email );
		$db->setQuery($query, 0, 1);
		$jid	= $db->loadResult();
		
		if ( $jid != null ) {
			$juser	= JFactory :: getUser( $jid );
		}
		else {
			$juser	= (object) array( 'name' => null, 'username' => null, 'email' => null, 'usertype' => 'Not Found' );
		}
		
		// Now for the WHMCS User...
		$api	= & IntApi :: getInstance();
		$wuser	=   $api->get_user( array( 'email' => $email ) );
		
		if ( $wuser['result'] == 'error' ) {
			$wuser	= (object) array( 'firstname' => null, 'lastname' => null, 'email' => null, 'usertype' => 'Not Found' );
		}
		else {
			$wuser['clientid'] = $wuser['id'];
			$wuser	= (object) $wuser;
		}
		
		$data	= array( 'joomla' => $juser, 'whmcs' => $wuser );
		
		return $data;
	}
	
	
	public function getForm($data = array(), $loadData = true) 
	{
		// Get the form.
		$form = $this->loadForm('com_belong.email', 'email',
		                        array('control' => 'jform', 'load_data' => false ) );
		
		if (empty($form)) 
		{
			return false;
		}
		
		return $form;
	}
}