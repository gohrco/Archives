<?php

defined('JPATH_BASE') or die;

jimport('joomla.html.html');
jimport('joomla.form.formfield');
jimport('joomla.form.helper');
JFormHelper::loadFieldClass('list');

class JFormFieldApiproductList extends JFormFieldList
{
	protected $type = 'ApiproductList';
	
	protected function getOptions()
	{
		$options = array();
		
		$api		= IntApi::getInstance();
		$products	= $api->get_products();
		
		if ( $products['result'] != "success" ) return false;
		
		foreach ( $products["products"] as $product ) {
			$tmp = new stdClass();
			$tmp->value = $product["id"];
			$tmp->text	= "[{$product["group"]}] {$product["name"]} ({$product["moduletype"]})";
			$options[]	= $tmp;
			unset( $tmp );
		}
		
		return $options;
	}
}
