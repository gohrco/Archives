<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.1 ( $Id: belong.php 21 2011-10-15 02:21:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the main file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
define( 'BELONG_VERS', '1.0.1' );

if (! JFactory::getUser()->authorise( 'core.manage', 'com_belong' ) ) { 
	return JError::raiseWarning( 404, JText::_('JERROR_ALERTNOAUTHOR' ) );
}
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.controller');
require_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'helper.php' );
/*-- File Inclusions --*/

$controller = JController::getInstance( 'Belong' );
$controller->execute( JRequest::getVar( 'task' ) );
$controller->redirect();