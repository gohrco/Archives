<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.1 ( $Id: view.html.php 21 2011-10-15 02:21:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the main view file for the backend of Belong
 *  
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
include_once( JPATH_COMPONENT_ADMINISTRATOR . DS . 'helper.php' );

class BelongViewDefault extends JView
{
	
	public function display($tpl = null)
	{
		$model	= & $this->getModel('default');
		$user	= & JFactory::getUser();
		$task	=   JRequest::getVar( 'task' );
		$status	=   $this->get( 'Status' );
		
		if ( $status ) {
			$this->remote = $this->get( 'Remotesettings' );
		}
		
		// Retrieve ACL permitted actions
		$canDo	= BelongHelper :: getActions();
		
		$icons = $model->getIconDefinitions( $canDo );
		
		BelongHelper :: addMedia( 'admin.main/css' );
		BelongHelper :: addToolbar ( 'default', $task, $canDo );
		
		$this->assignRef('icondefs', $icons); // Icon definitions
		$this->assignRef('data',	$params);
		$this->assignRef( 'status',	$status );
		
		parent::display($tpl);
	}
}