<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla view library
jimport('joomla.application.component.view');
jimport( 'joomla.application.component.helper' );

class BelongViewApicnxn extends JView
{
	public function display($tpl = null) 
	{
		BelongHelper :: addMedia( 'admin.main/css' );
		BelongHelper :: addMedia( 'admin.ajax/css' );
		BelongHelper :: addMedia( 'admin.ajax/js' );
		BelongHelper :: addToolbar( 'apicnxn', $isnew );
		
		$this->params	=	JComponentHelper::getParams( 'com_belong' );
		
		// Display the template
		parent::display( $tpl );
	}
}