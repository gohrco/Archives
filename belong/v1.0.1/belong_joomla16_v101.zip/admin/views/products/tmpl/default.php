<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');

// load tooltip behavior
JHtml::_('behavior.tooltip');
?>

<form action="<?php echo JRoute::_('index.php?option=com_belong'); ?>" method="post" name="adminForm">
	<table class="adminlist">
		
		<!-- BEGIN BODY -->
		
		<tbody>
		
		<?php foreach($this->items as $i => $item): ?>
			<?php $link = JRoute::_( 'index.php?option=com_belong&task=product.edit&id=' . $item->id ); ?>
			<tr class="row<?php echo $i % 2; ?>">
				<td>
					<?php echo $item->id; ?>
				</td>
				<td>
					<?php echo JHtml::_('grid.id', $i, $item->id); ?>
				</td>
				<td>
					<a href="<?php echo $link; ?>"><?php echo $item->name; ?></a>
				</td>
			</tr>
		<?php endforeach; ?>
		
		</tbody>
		
		<!-- END BODY -->
		<!-- BEGIN HEADER -->
		
		<thead>
			
			<tr>
				<th width="5">
					<?php echo JText::_('COM_BELONG_PRODUCTS_HEADING_ID'); ?>
				</th>
				<th width="20">
					<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" />
				</th>			
				<th>
					<?php echo JText::_('COM_BELONG_PRODUCTS_HEADING_NAME'); ?>
				</th>
			</tr>
			
		</thead>
		
		<!-- END HEADER -->
		<!-- BEGIN FOOTER -->
		
		<tfoot>
			
			<tr>
				<td colspan="3"><?php echo $this->pagination->getListFooter(); ?></td>
			</tr>
			
		</tfoot>
		
		<!-- END FOOTER -->
		
	</table>
	<div>
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<?php echo JHtml::_( 'form.token' ); ?>
	</div>
</form>