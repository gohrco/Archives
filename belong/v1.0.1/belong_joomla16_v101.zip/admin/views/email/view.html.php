<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla view library
jimport('joomla.application.component.view');


class BelongViewEmail extends JView
{
	public function display($tpl = null) 
	{
		$layout	= JRequest :: getVar( 'layout', 'default' );
		
		switch ( $layout ) :
		
		case 'results' :
			
			$debug = BelongDebug :: getInstance();
			$this->results = $debug->send();
			
			break;
			
		case 'find' :
			
			$userdata	= $this->get( 'FounduserData' );
			
			// If we received data back then break for this layout
			if ( $userdata ) {
				$this->userdata = $userdata;
				break;
			}
			// Instead we received an error or a problem was found so go back
			else {
				$this->setLayout( 'default' );
				$layout = 'default';
			}
			
		case 'default' :
		default:
			
			// get the Data
			$form = $this->get( 'Form' );
			
			// Check for errors.
			if ( count( $errors = $this->get( 'Errors' ) ) ) {
				JError::raiseError( 500, implode('<br />', $errors ) );
				return false;
			}
			
			// Assign the Data
			$this->form = $form;
			
			break;
			
		endswitch;
		
		BelongHelper :: addMedia( 'admin.main/css' );
		BelongHelper :: addToolbar( 'email', $layout );
		
		// Display the template
		parent::display( $tpl );
	}
}