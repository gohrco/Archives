<?php


// import Joomla table library
jimport('joomla.database.table');
 
class BelongTableProducts extends JTable
{
	
	public function __construct( &$db ) 
	{
		parent::__construct( '#__belong_products', 'id', $db );
	}
	
	
	public function bind($array, $ignore = '') 
	{
		if (isset($array['pdata']) && is_array($array['pdata'])) 
		{
			// Convert the params field to a string.
			$parameter = new JRegistry;
			$parameter->loadArray($array['pdata']);
			$array['pdata'] = (string)$parameter;
		}
		
		if (isset($array['statusorder']) && is_array($array['statusorder'])) 
		{
			// Convert the params field to a string.
			$parameter = new JRegistry;
			$parameter->loadArray($array['statusorder']);
			$array['statusorder'] = (string)$parameter;
		}
		return parent::bind($array, $ignore);
	}
 
	/**
	 * Overloaded load function
	 *
	 * @param       int $pk primary key
	 * @param       boolean $reset reset data
	 * @return      boolean
	 * @see JTable:load
	 */
	public function load($pk = null, $reset = true) 
	{
		if (! parent::load($pk, $reset)) {
			return false;
		}
		
		if ( is_string( $this->pdata ) ) {
			$this->pdata = json_decode( $this->pdata );
		}
		
		if ( is_string( $this->statusorder ) ) {
			$this->statusorder = json_decode( $this->statusorder );
		}
		
		return true;
	}
}