<?php
/**
 * Belong
 * 
 * @package    Belong
 * @copyright  2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.1 ( $Id: products.php 21 2011-10-15 02:21:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This is the rules controller file for the backend of Belong
 *  
 */

/*-- Security Protocols --*/
defined( '_JEXEC' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/*-- File Inclusions --*/
jimport('joomla.application.component.controlleradmin');
/*-- File Inclusions --*/


class BelongControllerProducts extends JControllerAdmin
{
	
	public function getModel( $name = 'Product', $prefix = 'BelongModel') 
	{
		$model = parent::getModel( $name, $prefix, array( 'ignore_request' => true ) );
		return $model;
	}
}