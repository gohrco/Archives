<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla controllerform library
jimport( 'joomla.application.component.controllerform' );
jimport( 'joomla.user.helper' );

class BelongControllerEmail extends JControllerForm
{
	public function find()
	{
		JRequest :: setVar( 'view', 'email' );
		JRequest :: setVar( 'layout', 'find' );
		
		parent::display();
	}
	
	
	public function run()
	{
		JRequest :: setVar( 'view', 'email' );
		JRequest :: setVar( 'layout', 'results' );
		
		// Handle rulesets
		BelongHelper :: runRulesets( JRequest :: getVar( 'wid', 0 ), 'whmcs' );
		
		parent::display();
	}
}