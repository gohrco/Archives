<?php
/**
 * Belong
 * WHMCS - Hook File
 * 
 * @package    Belong
 * @copyright  2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.1 ( $Id: hooks.php 23 2011-10-15 16:56:29Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This file included in the hooks execution and calls appropriate functions for actions
 * 
 */

/*-- Security Protocols --*/
if (!defined("WHMCS")) die("This file cannot be accessed directly");
/*-- Security Protocols --*/

/*-- File Inclusions --*/
require_once( "factory.php" );
/*-- File Inclusions --*/

$B_hook = BFactory::getHook();
BHook::addHooks();


function belong_cron( $vars )
{
	global $B_hook;
	$B_hook->cron();
}


function belong_grab_globals( $vars )
{
	global $B_hook;
	$vars['request'] = $GLOBALS['_REQUEST'];
	$B_hook->belong( $vars );
}


function belong_rulesets( $vars ) {
	global $B_hook;
	$B_hook->belong( $vars );
}


?>