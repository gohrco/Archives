<?php
/**
 * Belong
 * WHMCS - Defines File
 * 
 * @package    Belong
 * @copyright  2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.1 ( $Id: defines.php 21 2011-10-15 02:21:13Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This file establishes any needed constants
 * 
 */

/*-- Security Protocols --*/
if (!defined("WHMCS")) die("This file cannot be accessed directly");
/*-- Security Protocols --*/

// Path to WHMCS ROOT
if (! defined( "WHMCS_ROOT" ) ) {
	define( "WHMCS_ROOT", dirname(dirname(dirname(dirname(__FILE__) ) ) ) . DIRECTORY_SEPARATOR );
}