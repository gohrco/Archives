<?php
/**
 * Belong
 * WHMCS - Hook File
 * 
 * @package    Belong
 * @copyright  2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.1 ( $Id: hook.php 23 2011-10-15 16:56:29Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This file handles hook calls from the WHMCS hook system
 * 
 */

/*-- Security Protocols --*/
defined( 'WHMCS' ) or die( 'Restricted access' );
/*-- Security Protocols --*/

/**
 * Hook Class
 * @version		1.0.1
 * 
 * @since		1.0.0
 * @author		Steven
 */
class BHook extends BObject
{
	/**
	 * Holds the API variables
	 * @access		private
	 * @version		1.0.1
	 * @var 		array
	 */
	private $api			= array();
	
	/**
	 * Holds a reference to the curl object
	 * @access		private
	 * @version		1.0.1
	 * @var			object
	 */
	private $curl			= null;
	
	/**
	 * Indicates if we should output debug info
	 * @access		private
	 * @version		1.0.1
	 * @var			boolean
	 */
	private $debug			= false;
	
	/**
	 * Holds the user variables
	 * @access		private
	 * @version		1.0.1
	 * @var 		array
	 */
	private $user			= array();
	
	/**
	 * Holds the visual variables
	 * @access		private
	 * @version		1.0.1
	 * @var 		array
	 */
	private $visual			= array();
	
	/**
	 * Constructor
	 * @access		public
	 * @version		1.0.1
	 * 
	 * @since		1.0.0
	 */
	public function __construct()
	{
		$debug		= & BFactory::getDebug();
		$this->curl	=   BFactory::getCurl();
		
		$this->_load_apisettings();
		
		$config			= BFactory::getConfig();
		$this->cnxnid	= $config->cnxnid;
		$this->debug	= $config->Debug;
		
		// We must be sure not to recursively do things so check for $BAPI variable
		if ( isset( $GLOBALS['BAPI'] ) ) {
			define( "BAPI", true );
			$debug->info( "Hook called by API" );
		}
	}
	
	
	/**
	 * Adds the hooks used by the Integrator to the WHMCS framework
	 * @access		public
	 * @version		1.0.1
	 * 
	 * @static
	 * @since		1.0.0
	 */
	public static function addHooks()
	{
		$config = & BFactory :: getConfig();
		
		if ( $config->get( 'Enabled' ) == 'Yes' ) {
			$hooks = array(
				'AfterModuleCreate'		=>	'belong_rulesets',
				'AfterModuleSuspend'	=>	'belong_rulesets',
				'AfterModuleUnsuspend'	=>	'belong_rulesets',
				'AfterModuleTerminate'	=>	'belong_rulesets',
				'AfterModuleRenew'		=>	'belong_rulesets',
				'AddonActivation'		=>	'belong_rulesets',
				'AdminServiceEdit'		=>	'belong_grab_globals',
				'AfterProductUpgrade'	=>	'belong_rulesets'
			);
			
			if ( $config->get( 'EnableCron' ) == 'Yes' ) {
				$hooks['DailyCronJob'] = 'belong_cron';
			}
			
			// Add the hooks to the WHMCS framework
			foreach ( $hooks as $point => $fnxn ) {
				add_hook( $point, 25, $fnxn );
			}
		}
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE CALLED DIRECTLY BY HOOK POINT
	 * **********************************************************************
	 */
	
	
	public function belong( $vars )
	{
		$debug		= & BFactory :: getDebug( array( 'script' => "Belong[hook]" ) );
		
		// Grab the email address from the vars
		$email		=   $this->_extract_email( $vars );
		
		// Try to find the client id if we can't find an email address
		if ( $email == null ) $email = $this->_extract_clientid( $vars );
		
		$this->api['uri']->setVar( 'task', 'belong' );
		
		$url		= $this->api['uri']->toString();
		$post		= array( 'email' => $email );
		
		$response	= $this->_call_api( $url, $post );
		
		if ( $response['result'] == 'success' ) {
			return true;
		}
		
		$debug->data( $response['data'] );
		return false;
	}
	
	
	public function cron()
	{
		$debug		= & BFactory :: getDebug( array( 'script' => "Belong[hook]" ) );
		
		$this->api['uri']->setVar( 'task', 'cron' );
		
		$url		= $this->api['uri']->toString();
		
		// Set timeout to 5 minutes
		$this->api['options']['TIMEOUT'] = 300;
		$response	= $this->_call_api( $url );
		
		if ( $response['result'] == 'success' ) {
			return true;
		}
		
		$debug->data( $response['data'] );
		return false;
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE API RELATED
	 * **********************************************************************
	 */
	
	
	/**
	 * Checks the login credentials against the Joomla site to ensure connectivity
	 * @access		public
	 * @version		1.0.1
	 * 
	 * @return		boolean true on success or string on error
	 * @since		1.0.0
	 */
	public function login()
	{
		$debug		= & BFactory :: getDebug( array( 'script' => "Login[hook]" ) );
		
		$this->api['uri']->setVar( 'task', 'login' );
		
		$url		= $this->api['uri']->toString();
		$response	= $this->_call_api( $url, array( 'email' => $email ) );
		
		if ( $response['result'] == 'success' ) {
			return true;
		}
		
		$debug->data( $response['data'] );
		return $response['data'];
	}
	
	
	/**
	 * Pings the Belong API to see if it is alive
	 * @access		public
	 * @version		1.0.1
	 * 
	 * @return		boolean true on connection
	 * @since		1.0.0
	 */
	public function ping()
	{
		$debug		= & BFactory::getDebug( array( 'script' => "Ping[hook]" ) );
		
		$this->api['uri']->setVar( 'task', 'ping' );
		
		$url		= $this->api['uri']->toString();
		$response	= $this->_call_api( $url );
		
		if ( $response['result'] == 'success' ) {
			return true;
		}
		
		$debug->data( $response['data'] );
		return $response['data'];
	}
	
	
	/**
	 * Wrapper for calling up the API interface
	 * @access		private
	 * @version		1.0.1
	 * @param		string		- $url: the url to connect to
	 * @param		array		- $post: any additional post variables to send
	 * @param 		array		- $options: any options to set
	 * 
	 * @return		json_decoded response
	 * @since		1.0.0
	 */
	private function _call_api( $url, $post = array(), $options = array() )
	{
		$post		= array_merge( $this->api['post'], $post );
		$options	= array_merge( $this->api['options'], $options );
		
		$result		= $this->curl->simple_post( $url, $post, $options );
		
		if ( $result === false ) {
			// error trapping for debug purposes
			return array( 'result' => 'error', 'data' => $this->curl->has_errors() );
		}
		
		if ( $options['HEADER'] == TRUE ) {
			list( $header, $response ) = explode( "\r\n\r\n", $result, 2 );
		}
		else {
			$response = $result;
		}
		
		$return	= json_decode( $response, true );
		
		if (! isset( $return['result'] ) ) {
			return $response;
		}
		else {
			return $return;
		}
	}
	
	
	/**
	 * **********************************************************************
	 * METHODS BELOW ARE PRIVATE FOR THIS OBJECT
	 * **********************************************************************
	 */
	
	
	/**
	 * Extracts the client id from a set of variables passed by hook points
	 * @access		private
	 * @version		1.0.1
	 * @param		array		- $vars: contains an array of values to cycle through
	 * 
	 * @return		integer containing userid or null on not found
	 * @since		1.0.0
	 */
	private function _extract_clientid( $vars )
	{
		$clientid = null;
		
		foreach ( $vars as $key => $value ) {
			if ( is_array( $value ) ) {
				$value = $this->_extract_clientid( $value );
				
				if ( $value != null ) {
					$clientid = $value;
					break;
				}
			}
			
			if ( $key == 'userid' ) {
				$clientid = $value;
				break;
			}
		}
		
		return $clientid;
	}
	
	
	/**
	 * Reliably extracts an email address from the vars passed by the hook points
	 * @access		private
	 * @version		1.0.1
	 * @param		array		- $vars: contains an array of values to cycle through
	 * 
	 * @return		string containing email address found or null
	 * @since		1.0.0
	 */
	private function _extract_email( $vars )
	{
		$email = null;
		
		foreach ( $vars as $key => $value ) {
			if ( is_array( $value ) ) {
				$value = $this->_extract_email( $value );
				
				if ( $value != null ) {
					if ( $this->is_email( $value ) ) {
						$email = $value;
						break;
					}
				}
			}
			
			if ( $key == 'email' ) {
				if ( $this->is_email( $value ) ) {
					$email = $value;
					break;
				}
			}
		}
		
		return $email;
	}
	
	
	/**
	 * Determines if a username is actually an email address
	 * @access	public
	 * @version	1.0.1
	 * @param 	string			- $value - Contains suspect $value
	 * 
	 * @return	True if email, false if not
	 * @since	1.0.0
	 */
	public function is_email( $value )
	{
		$pattern = "/\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,5}\b/i";
		$match = preg_match( $pattern, $value );
		
		return ( $match > 0 );
	}
	
	
	/**
	 * Loads the API settings
	 * @access		private
	 * @version		1.0.1
	 * 
	 * @since		1.0.0
	 */
	private function _load_apisettings()
	{
		$config			= BFactory::getConfig();
		
		// Set the API Uri object
		$uri		= new BUri( $config->JoomlaUrl );
		$uri->setPath( rtrim( $uri->getPath(), "/" ) . "/index.php" );
		$uri->setVar( 'option', 'com_belong' );
		$uri->setVar( 'controller', 'api' );
		$this->api['uri']	= $uri;
		
		// Set the default API post variables
		$post		= array( 'credentials' => array	(
								"username" => $config->ApiUsername,
								"password" => $config->ApiPassword
						)
		);
		$this->api['post'] = $post;
		
		$options	= array(	'POST'				=> true,
								'TIMEOUT'			=> 30,
								'RETURNTRANSFER'	=> true,
								'POSTFIELDS'		=> array(),
								'FOLLOWLOCATION'	=> false,
								'HEADER'			=> true,
								'HTTPHEADER'		=> array( 'Expect:' ),
								'MAXREDIRS'			=> 5,
								'SSL_VERIFYHOST'	=> false,
								'SSL_VERIFYPEER'	=> false
		);
		
		$this->api['options']	= $options;
		
		return;
	}
	
}