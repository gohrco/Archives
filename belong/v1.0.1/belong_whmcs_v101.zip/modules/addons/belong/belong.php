<?php
/**
 * Belong
 * Belong - Admin Module Base File
 * 
 * @package    Belong
 * @copyright  2011 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    1.0.1 ( $Id: belong.php 23 2011-10-15 16:56:29Z steven_gohigher $ )
 * @author     Go Higher Information Services
 * @since      1.0.0
 * 
 * @desc       This file is the root file loaded by WHMCS upon selection of the "Belong" addon
 * 
 */

/*-- Security Protocols --*/
if (!defined("WHMCS")) die("This file cannot be accessed directly");
/*-- Security Protocols --*/


/**
 * Configuration function called by WHMCS
 * 
 * @return An array of configuration variables
 * @since  1.0.0
 */
function belong_config()
{
	require_once( 'factory.php' );
	$lang	= & BFactory::getLang();
	
	$desc = "<div style='padding: 2px 20px 10px 10px; font-style: italic; '>%s</div>";
	$configarray = array(
		"name"			=> 'Belong',
		"version"		=> '1.0.1',
		"author"		=> "<div style='text-align: center; width: 100%; '>Go Higher<br/>Information Services</div>",
		"description"	=> $lang['cfg_desc'],
		"language"		=> "english",
		"fields"		=> array(
			"Enabled"				=> array (
				"FriendlyName"	=> $lang['cfg_enablelabel'],
				"Description"	=> sprintf( $desc, $lang['cfg_enabledesc'] ),
				"Type"			=> "dropdown",
				"Options"		=> "Yes,No"
			),
			"JoomlaUrl"			=> array (
				"FriendlyName"	=> $lang['cfg_joomlaurllabel'],
				"Type"			=> "text",
				"Size"			=> "40",
				"Description"	=> sprintf( $desc, $lang['cfg_joomlaurldesc'] )
			),
			"ApiUsername"	=> array(
				"FriendlyName"	=> $lang['cfg_apiuserlabel'],
				"Type"			=> "text",
				"Size"			=> "40",
				"Description"	=> sprintf( $desc, $lang['cfg_apiuserdesc'] )
			),
			"ApiPassword"	=> array(
				"FriendlyName"	=> $lang['cfg_apipasslabel'],
				"Type"			=> "text",
				"Size"			=> "40",
				"Description"	=> sprintf( $desc, $lang['cfg_apipassdesc'] )
			),
			"EnableCron"	=> array(
				"FriendlyName"	=> $lang['cfg_enablecronlabel'],
				"Type"			=> "dropdown",
				"Options"		=> "Yes,No",
				"Description"	=> sprintf( $desc, $lang['cfg_enablecrondesc'] )
			),
		)
    );
    return $configarray;
}


/**
 * Activation function called by WHMCS
 * 
 * @since  1.0.0
 */
function belong_activate()
{
	
}


/**
 * Deactivation function called by WHMCS
 * 
 * @since  1.0.0
 */
function belong_deactivate()
{
	
}


/**
 * Upgrade function called by WHMCS
 * @param  array		Contains the variables set in the configuration function
 * 
 * @since  1.0.0
 */
function belong_upgrade($vars)
{
	// Ensure backwards compatible to v4.41
	// Bug in WHMCS dox state to use vars['version']
	if ( isset( $vars['version'] ) ) {
		$version = $vars['version'];
	}
	
	
}


/**
 * Output function called by WHMCS
 * @param  array		Contains the variables set in the configuration function
 * 
 * @since 3.0.0
 */
function belong_output($vars)
{
	require_once( 'factory.php' );
	$INT_hook	= & BFactory::getHook();
	$intlang	= & BFactory::getLang();
	$message	=   false;
	
	if ( $_REQUEST['task'] == 'runCron' ) {
		$message = ( $INT_hook->cron() ? 'Cron Successfully Run' : 'Error Running Cron' );
	}
	
	// Test to be sure we are connected and then update settings
	$connected	= $INT_hook->ping();
	$validated	= $INT_hook->login();
	
	$msg			= array();
	$msg['cnxn']	= ( $connected === true ? $intlang['admin_msg01'] : sprintf( $intlang['admin_err01'], $connected ) );
	$msg['upd']		= ( $validated === true ? $intlang['admin_msg02'] : ( $connected === true ? sprintf( $intlang['admin_err03'], $validated ) : $intlang['admin_err02'] ) );
	
	$output		= <<< OUTPUT
<h3>{$intlang['admin_outputhdr']}</h3>
<table class="form" width="100%" border="0" cellspacing="2" cellpadding="3">
	<tr>
		<td width="20%" class="fieldlabel">{$intlang['admin_labelcnxn']}</td>
		<td class="fieldarea">{$msg['cnxn']}</td>
	</tr>
	<tr>
		<td class="fieldlabel">{$intlang['admin_labelsets']}</td>
		<td class="fieldarea">{$msg['upd']}</td>
	</tr>
</table>

<form method="post" action="{$vars['modulelink']}&task=runCron">

<table width="100%" border="0" cellpadding="3" cellspacing="2">
	<tr>
		<td width="20%">&nbsp;</td>
		<td><input type="submit" value="Manually Run Cron" /></td>
	</tr>
OUTPUT;

if ( $message ) {
$output .= <<< OUTPUT
	<tr>
		<td width="20%"&nbsp;</td>
		<td>{$message}</td>
	</tr>
OUTPUT;
}

$output .= <<< OUTPUT
</table>
</form>
OUTPUT;

	echo $output;
}


/**
 * Function to generate sidebar menu called by WHMCS
 * @param  array		Contains the variables set in the configuration function
 * 
 * @since  1.0.0
 */
function belong_sidebar($vars)
{
	
}
?>