J!WHMCS Integrator
------------------------------------------------------------------------

 Release Version: 2.1.2 RC11
    Release Date: 2010 November 1

 PLEASE READ ALL THE ENCLOSED INSTRUCTIONS

        Forums: http://gohigheris.com/forum
       Support: http://support.gohigheris.com
 Documentation: http://gohigheris.com/wiki
   Client Area: http://client.gohigheris.com


[ CONTENTS ]
------------------------------------------------------------------------

1. Server Requirements
2. Version 2.1.2 RC11 Release Notes
3. New Installation Instructions
4. Upgrade Instructions


[ SERVER REQUIREMENTS ]
------------------------------------------------------------------------

1. Joomla 1.5 (version 1.5.15 or above recommended)
2. WHMComplete Solution (WHMCS) version 4.0 or above (4.2.1 recommended)
3. PHP Version 5.x or later
4. MySQL Version 5.x or later
5. Curl Support (with SSL)
6. Ioncube Loaders Support (required for WHMCS portion of installation)
7. J!WHMCS Integrator version 2.1.1 or above


[ RELEASE NOTES ]
------------------------------------------------------------------------

To review the details and notes for the Version 2.1.2 RC11 release, please see:

http://gohigheris.com/wiki/Plugin_Pricing_Version_2.1.2 RC11_Release_Notes


[ INSTALLATION INSTRUCTIONS ]
------------------------------------------------------------------------

For instructions on performing a new installation of WHMCS, please see:

http://gohigheris.com/wiki/Plugin_Pricing_Version_2.1.2 RC11_Release_Notes#Install_Steps


[ USAGE INSTRUCTIONS ]
------------------------------------------------------------------------

The recommended steps for upgrading from an earlier version of J!WHMCS
Integrator to this latest release can be found at:

http://gohigheris.com/wiki/Plugin_Pricing_Version_2.1.2 RC11_Release_Notes#Usage
