<?php
/**
 * WHMCS User Synchrization View for J!WHMCS Integrator
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: view.html.php 1 2009-09-02 00:16:45Z Steven $
 * @since      1.5.0
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

/* ------------------------------------------------------------ *\
 * Class:		JwhmcsViewSync
 * Extends:		JView
 * Purpose:		Used as the WHMCS User Synchrization view
 * 
 * As of:		version 1.5.1
\* ------------------------------------------------------------ */
class JwhmcsViewInstall extends JView
{
	/* ------------------------------------------------------------ *\
	 * Method:		display
	 * Purpose:		Assembles the page for the application to send to
	 * 				the user
	 * 
	 * As of:		version 1.5.1
	\* ------------------------------------------------------------ */
	function display($tpl = null)
	{
		$model	= & $this->getModel( 'install' );
		$task	= JRequest::getVar( 'task' );
		$data	= $model->$task();
		
		switch($task):
		case 'apiconxn' :
			JToolBarHelper :: title( JText::_( 'JWHMCS_ADMIN_CHECK_API' ), 'apiconxn.png' );
			JToolBarHelper :: custom( 'apiconxnAccept', 'save.png', '', JText::_( 'JWHMCS_ADMIN_BUTTON_APICONSV' ), false, false );
			JToolBarHelper :: divider();
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
			break;
		case 'license' :
			JToolBarHelper :: title( JText::_( 'JWHMCS_ADMIN_CHECK_LIC' ), 'license.png' );
			JToolBarHelper :: custom( 'licenseReload', 'licreload.png', '', JText::_( 'JWHMCS_ADMIN_BUTTON_LICRELOAD' ), false, false );
			JToolBarHelper :: custom( 'licenseAccept', 'save.png', '', JText::_( 'JWHMCS_ADMIN_BUTTON_LICSAVE' ), false, false );
			JToolBarHelper :: divider();
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
			break;
		case 'interview':
			JToolBarHelper :: title( JText::_( 'JWHMCS_ADMIN_INSTALL_TITLE' ).': <small><small>[ ' . JText::_( 'JWHMCS_ADMIN_INSTALL_INTERVIEW' ).' ]</small></small>', 'settings.png' );
			JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
			break;
		case 'manual' :
		default:
			JToolBarHelper :: title( JText::_( 'JWHMCS_ADMIN_INSTALL_TITLE' ).': <small><small>[ ' . JText::_( 'JWHMCS_ADMIN_INSTALL_MANUAL' ).' ]</small></small>', 'install.png' );
			JToolBarHelper :: custom( 'cpanel', 'jwhmcs.png', 'jwhmcs.png', 'J!WHMCS', false, false );
			JToolBarHelper::divider();
			JToolBarHelper :: custom( 'helppage', 'helppage.png', 'helppage.png', 'Help', false, false );
		endswitch;
		
		JHTML::script('ajax.js', 'administrator/components/com_jwhmcs/js/', true);
		JHTML::stylesheet( 'install.css', 'administrator/components/com_jwhmcs/assets/' );
		
		$this->assignRef('data', $data);
		parent::display($tpl);
	}
}