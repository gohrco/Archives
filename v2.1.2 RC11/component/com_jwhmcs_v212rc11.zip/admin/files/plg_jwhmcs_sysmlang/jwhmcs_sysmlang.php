<?php
/**
 * J!WHMCS Integrator - System Language Plugin
 * 
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id: jwhmcs_sysm.php 99 2010-01-11 18:57:35Z Steven $
 * @since      2.0.2
 * 
 * @desc		This plugin handles adding the language=xx to external links
 * 				in the Joomla system that are tied to the component parameters.
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.plugin.plugin');

$curlfile = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jwhmcs'.DS.'classes'.DS.'class.curl.php';
if (is_readable($curlfile)) include_once($curlfile);

/**
 * System Language Plugin
 *
 * @package		J!WHMCS Integrator 
 * @since 		2.0.2
 */
class plgSystemJwhmcs_sysmlang extends JPlugin {

	/**
	 * Constructor
	 *
	 * For php4 compatability we must not use the __constructor as a constructor for plugins
	 * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
	 * This causes problems with cross-referencing necessary for the observer design pattern.
	 *
	 * @param object $subject The object to observe
	 * @param 	array  $config  An array that holds the plugin configuration
	 * @since 1.5
	 */
	function plgSystemJwhmcs_sysmlang(& $subject, $config)
	{
		parent::__construct($subject, $config);
	}
	
	
	function onAfterInitialise()
	{
		
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	onAfterRender
	 * Purpose:		Handle adding language= to links
	 * As of:		version 2.0.2 (March 2010)
	 * 
	 * Significant Revisions:
	 * 	2.1.0 (Apr 2010)
	 * 		* Modified parameters to reflect database change
	\* ------------------------------------------------------------ */
	function onAfterRender()
	{
		global $Itemid;
		if (! class_exists('JwhmcsParams') ) return;
		$params	= & JwhmcsParams::getInstance();
		$menu	= & JMenu::getInstance('site');
		
		if ($params->get( 'LangEnable' ) != 1 )
			return;
		
		if ((! $params->get( 'RenderEnable' )) || (! $params->get( 'Enable' )))
			return;	// Don't run if product or visual integration disabled
		
		$buffer =   JResponse::getBody();
		
		// Retrieve menu items to work with
		$menuarray = $this->_getMenuItems();
		if (! $menuarray) return;
		
		// Create replacement language tag
		$langarray = $this->_getLanguages();
		$langcurr	= & JFactory::getLanguage();
		$selected = $langarray[$langcurr->getTag()];
		
		// Perform replacements
		foreach($menuarray as $value) {
			$curItem = $menu->getItem($value);
			$curUri	 = & JURI::getInstance($curItem->link);
			$curUri->setVar( 'language', $selected );
			$newUri	 = $curUri->toString();
			$regex	 = sprintf( '`(href=")%s(")`', $curItem->link );
			$buffer	 = preg_replace( $regex, "$1$newUri$2", $buffer );
		}
		
		$regex		= array();
		$regex[]	= '`(?:http|https)://[^\?>]*index\.php\?[^"]*option=com_jwhmcs(?:[^">]*lang=(.{2})[^">]*)`';	// No SEF turned on
		$regex[]	= '`(?:http|https)://[^\?>]*index\.php\?(?:[^">]*lang=(.{2})[^">]*)option=com_jwhmcs`';			// SEF URLS only on
		//$regex[]	= '`http[s]*://[^"]*/(.{2})/component/jwhmcs/[^"]*`';											// Unused Duplicate?
		$regex[]	= '`(?:http|https)://[^\?>]*index\.php\/(.{2})\/jwhmcs-logged-(?:out|in)[^"]*`';				// SEF URLS and suffix added (no rewrite) 
		$regex[]	= '`(?:http|https)://[^\?>]*\/(.{2})\/jwhmcs-logged-(?:out|in)[^"]*`';							// SEF URLS and suffix and rewrite OR SEF and rewrite without suffix
		
		foreach ( $regex as $reg )
			$buffer = preg_replace( $reg, "<!-- LANGUAGE=$1 -->", $buffer );
		
		JResponse::setBody($buffer);
		return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getMenuItems (private)
	 * Purpose:		Handle adding language= to links
	 * As of:		version 2.0.2 (March 2010)
	 * 
	 * Significant Revisions:
	 * 	2.1.0 (Apr 2010)
	 * 		* Modified parameters to reflect database change
	\* ------------------------------------------------------------ */
	private function _getMenuItems()
	{
		$params	= & JwhmcsParams::getInstance();
		$menus	=   $params->getPrime('menu');
		
		unset($menus['MenuStyle']);
		
		foreach ($menus as $k => $v)
		{
			$return[] = $v;
		}
		return $return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Function:	_getLanguages (private)
	 * Purpose:		Handle adding language= to links
	 * As of:		version 2.0.2 (March 2010)
	 * 
	 * Notes:
	 * 		Need to move to Advanced Parameter settings
	\* ------------------------------------------------------------ */
	private function _getLanguages()
	{
		$params = & JwhmcsParams::getInstance();
		$jlangs =   $this->_getJlanguages();
		
		if (! is_array($jlangs))
			return array();
		
		foreach ($jlangs as $lang) {
			$language = $params->get( 'LangJoom'.$lang->shortcode );
			if (! $language) $language = $params->get( 'LangDefault' );
			$return[$lang->code] = $language;
		}
		return $return;
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		_getJlanguages (private)
	 * Purpose:		Retrieve language array from Joomla
	 * As of:		version 2.1.0
	\* ------------------------------------------------------------ */
	private function _getJlanguages()
	{
		$db = & JFactory::getDBO();
		
		$query = "SELECT `name`, `code`, `shortcode` FROM #__languages ORDER BY name";
		$db->setQuery($query);
		$langs = $db->loadObjectList();
		
		return $langs;
	}
}