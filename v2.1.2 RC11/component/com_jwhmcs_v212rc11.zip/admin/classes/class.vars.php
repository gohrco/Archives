<?php
/**
 * @package    J!WHMCS Integrator
 * @copyright  2009 - 2010 Go Higher Information Services.  All rights reserved.
 * @license    GNU General Public License version 2, or later
 * @version    $Id$
 * @since      1.5.3
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once ('class.database.php');

class JwhmcsVars
{
	
	/**
	 * @var instance to contain object when created
	 */
	private static $instance = null;
	
    /* ------------------------------------------------------------ *\
	 * Method:		__construct
	 * Purpose:		Called upon initialization of object class
	 * 
	 * As of:		version 1.5.3
	 * 
	 * Significant Revisions:
	 * 	none
	\* ------------------------------------------------------------ */
	private function __construct()
	{
		$this->vars = $this->_getVars();
		
		// Test to see if usessl passed by jwhmcs hook
		if (! $this->get( 'usessl' ) )	$this->set('usessl', false );
		
		// Test to see if the user is logged in
		if (! $this->get( 'loggedin' ) )	$this->set( 'loggedin', false );
		
		// If filename wasn't passed by variable, set the default to clientarea
		if (! $this->get( 'filename' ) )	$this->set( 'filename', 'clientarea' );
		
		// If no action is present, set it to false
		if (! $this->get( 'action' ) )	$this->set( 'action', false );
		
		// If no goto is present, set it to false
		if (! $this->get( 'goto' ) )		$this->set( 'goto', false );
	}
	
	
	/* ------------------------------------------------------------ *\
	 * Method:		getInstance
	 * Purpose:		Called to create an instance of the class
	 * 
	 * As of:		version 1.5.3
	 * 
	 * Significant Revisions:
	 * 	none
	\* ------------------------------------------------------------ */
	public static function getInstance()
	{
		if (self::$instance == null)
		{
			self::$instance = new self;
		}
		return self::$instance;
	}
	
	
	public function get($key, $prime = null)
	{
		if (!$prime) {
			if (!$this->_multiArrayKeyExists($key, $this->vars)) {
				// Error trapping for non-existant variable
				return false;
			}
			
			$prime = $this->_arrayFindPrimeKey($key, $this->vars);
		}
		return $this->vars[$prime][$key];
	}
	
	
	public function getMethod($prime)
	{
		if (array_key_exists($prime, $this->vars))
		{
			return $this->vars[$prime];
		}
		else
		{
			return false;
		}
	}
	
	
	public function set($key, $value, $prime = 'get')
	{
		if ($this->_multiArrayKeyExists($key, $this->vars))
			$prime = $this->_arrayFindPrimeKey($key, $this->vars);
		
		$this->vars[$prime][$key] = $value;
	}
	
	
	private function _getVars()
	{
		$tochk['server']	= $_SERVER;
		$tochk['get']		= $_GET;
		$tochk['post']		= $_POST;
		$tochk['files']		= $_FILES;
		$tochk['cookie']	= $_COOKIE;
		$tochk['session']	= $_SESSION;
		$tochk['request']	= $_REQUEST;
		
		$check = array('get', 'post', 'files', 'cookie', 'request');
		foreach ($tochk as $prime => $value)
		{
			if (isset($value))
			{
				foreach($value as $k => $v)
				{
					if (in_array($prime, $check)) $v = $this->_cleanVar($k, $v);
					$vars[$prime][$k] = $v;
				}
			}
		}
		return $vars;
	}
	
	
	private function _multiArrayKeyExists( $needle, $haystack )
	{
		foreach ( $haystack as $key => $value )
		{
			if ( $needle == $key )
				return true;
			
			if ( is_array( $value ) ) {
				if ( $this->_multiArrayKeyExists( $needle, $value ) == true )
				{
					return true;
				}
				else
				{
					continue;
				}
			}
		}
		
		return false;
	}
	
	
	private function _arrayFindPrimeKey($key, $form)
	{
		if (is_array($form))
		{
			if (array_key_exists($key, $form))
			{
				return true;
			}
		}
		else
		{
			return false;
		}
		foreach ($form as $k => $v)
		{
			$ret = & $this->_arrayFindPrimeKey($key, $form[$k]);
			if ($ret===true)	// Test if the key was found in the previous check
			{
				return $k;		// Return the primary key
			}
			if ($ret)
			{
				$ret[$k] = $ret;
				return $ret;
			}
		}
		return false;
	}
	
	
	private function _cleanVar($name, $var)
	{
		$excludes = array( 'pagetitle', 'passwd', 'password', 'username' );
		if (in_array($name, $excludes)) return $var;
		$var	= str_replace("<", "&lt;", $var);
		$var	= str_replace(">", "&gt;", $var);
		$var	= str_replace("(", "&#40;", $var);
		$var	= str_replace(")", "&#41;", $var);
		$var	= str_replace('"', "&#34;", $var);
		$var	= str_replace("'", "&#39;", $var);
		$var	= str_replace("#", "&#35;", $var);
		$var	= str_replace("&", "&#38;", $var);
		return $var;
	}
}